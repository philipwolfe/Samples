Public Class TravelAgency
    Inherits System.Web.UI.Page
    Protected WithEvents Calendar1 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents CrystalReportViewer1 As CrystalDecisions.Web.CrystalReportViewer
    Protected WithEvents cachedSeatSales1 As Airline.CachedSeatSales
        Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cachedSeatSales1 = New Airline.CachedSeatSales()
        '
        'cachedSeatSales1
        '
        Me.cachedSeatSales1.CacheTimeOut = System.TimeSpan.Parse("02:10:00")
        Me.cachedSeatSales1.IsCacheable = True
        Me.cachedSeatSales1.ShareDBLogonInfo = False

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DataBind()
    End Sub

End Class
