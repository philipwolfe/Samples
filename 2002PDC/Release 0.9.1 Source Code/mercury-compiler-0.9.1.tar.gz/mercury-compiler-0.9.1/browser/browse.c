/*
** Automatically generated from `browse.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__browse__init
ENDINIT
*/

#include "mercury_imp.h"
#include "browse.h"

#line 23 "browse.c"

Declare_static(mercury____Index___browse__browser_state_0__ua0_2_0);
Define_extern_entry(mercury__browse__init_state_3_0);
Declare_label(mercury__browse__init_state_3_0_i2);
Declare_label(mercury__browse__init_state_3_0_i3);
Define_extern_entry(mercury__browse__browse_7_0);
Declare_label(mercury__browse__browse_7_0_i2);
Declare_label(mercury__browse__browse_7_0_i3);
Declare_label(mercury__browse__browse_7_0_i4);
Declare_label(mercury__browse__browse_7_0_i5);
Declare_label(mercury__browse__browse_7_0_i6);
Declare_label(mercury__browse__browse_7_0_i7);
Declare_label(mercury__browse__browse_7_0_i8);
Declare_label(mercury__browse__browse_7_0_i9);
Define_extern_entry(mercury__browse__browse_external_7_0);
Declare_label(mercury__browse__browse_external_7_0_i2);
Declare_label(mercury__browse__browse_external_7_0_i3);
Declare_label(mercury__browse__browse_external_7_0_i4);
Declare_label(mercury__browse__browse_external_7_0_i5);
Declare_label(mercury__browse__browse_external_7_0_i6);
Declare_label(mercury__browse__browse_external_7_0_i7);
Declare_label(mercury__browse__browse_external_7_0_i8);
Declare_label(mercury__browse__browse_external_7_0_i9);
Define_extern_entry(mercury__browse__print_5_0);
Declare_label(mercury__browse__print_5_0_i2);
Declare_label(mercury__browse__print_5_0_i3);
Declare_label(mercury__browse__print_5_0_i4);
Declare_label(mercury__browse__print_5_0_i5);
Declare_label(mercury__browse__print_5_0_i6);
Declare_static(mercury__browse__browser_state_type_1_0);
Declare_label(mercury__browse__browser_state_type_1_0_i2);
Declare_label(mercury__browse__browser_state_type_1_0_i3);
Declare_label(mercury__browse__browser_state_type_1_0_i4);
Declare_static(mercury__browse__print_3_0);
Declare_label(mercury__browse__print_3_0_i2);
Declare_label(mercury__browse__print_3_0_i3);
Declare_label(mercury__browse__print_3_0_i7);
Declare_label(mercury__browse__print_3_0_i8);
Declare_label(mercury__browse__print_3_0_i10);
Declare_label(mercury__browse__print_3_0_i12);
Declare_label(mercury__browse__print_3_0_i6);
Declare_label(mercury__browse__print_3_0_i15);
Declare_static(mercury__browse__print_external_3_0);
Declare_label(mercury__browse__print_external_3_0_i3);
Declare_label(mercury__browse__print_external_3_0_i4);
Declare_label(mercury__browse__print_external_3_0_i6);
Declare_label(mercury__browse__print_external_3_0_i8);
Declare_label(mercury__browse__print_external_3_0_i2);
Declare_label(mercury__browse__print_external_3_0_i12);
Declare_label(mercury__browse__print_external_3_0_i13);
Declare_label(mercury__browse__print_external_3_0_i14);
Declare_label(mercury__browse__print_external_3_0_i16);
Declare_label(mercury__browse__print_external_3_0_i17);
Declare_static(mercury__browse__term_size_left_from_max_3_0);
Declare_label(mercury__browse__term_size_left_from_max_3_0_i2);
Declare_label(mercury__browse__term_size_left_from_max_3_0_i3);
Declare_label(mercury__browse__term_size_left_from_max_3_0_i4);
Declare_static(mercury__browse__browse_main_loop_5_0);
Declare_label(mercury__browse__browse_main_loop_5_0_i1003);
Declare_label(mercury__browse__browse_main_loop_5_0_i3);
Declare_label(mercury__browse__browse_main_loop_5_0_i5);
Declare_label(mercury__browse__browse_main_loop_5_0_i9);
Declare_label(mercury__browse__browse_main_loop_5_0_i10);
Declare_label(mercury__browse__browse_main_loop_5_0_i11);
Declare_label(mercury__browse__browse_main_loop_5_0_i12);
Declare_label(mercury__browse__browse_main_loop_5_0_i6);
Declare_label(mercury__browse__browse_main_loop_5_0_i13);
Declare_static(mercury__browse__run_command_6_0);
Declare_label(mercury__browse__run_command_6_0_i4);
Declare_label(mercury__browse__run_command_6_0_i2);
Declare_label(mercury__browse__run_command_6_0_i6);
Declare_label(mercury__browse__run_command_6_0_i9);
Declare_label(mercury__browse__run_command_6_0_i14);
Declare_label(mercury__browse__run_command_6_0_i16);
Declare_label(mercury__browse__run_command_6_0_i18);
Declare_label(mercury__browse__run_command_6_0_i20);
Declare_label(mercury__browse__run_command_6_0_i22);
Declare_label(mercury__browse__run_command_6_0_i12);
Declare_label(mercury__browse__run_command_6_0_i31);
Declare_label(mercury__browse__run_command_6_0_i34);
Declare_label(mercury__browse__run_command_6_0_i39);
Declare_label(mercury__browse__run_command_6_0_i37);
Declare_label(mercury__browse__run_command_6_0_i42);
Declare_label(mercury__browse__run_command_6_0_i43);
Declare_label(mercury__browse__run_command_6_0_i44);
Declare_label(mercury__browse__run_command_6_0_i47);
Declare_label(mercury__browse__run_command_6_0_i49);
Declare_label(mercury__browse__run_command_6_0_i46);
Declare_label(mercury__browse__run_command_6_0_i40);
Declare_label(mercury__browse__run_command_6_0_i54);
Declare_label(mercury__browse__run_command_6_0_i52);
Declare_label(mercury__browse__run_command_6_0_i61);
Declare_label(mercury__browse__run_command_6_0_i62);
Declare_label(mercury__browse__run_command_6_0_i59);
Declare_label(mercury__browse__run_command_6_0_i64);
Declare_label(mercury__browse__run_command_6_0_i1026);
Declare_label(mercury__browse__run_command_6_0_i74);
Declare_label(mercury__browse__run_command_6_0_i77);
Declare_label(mercury__browse__run_command_6_0_i75);
Declare_static(mercury__browse__portray_4_0);
Declare_label(mercury__browse__portray_4_0_i5);
Declare_label(mercury__browse__portray_4_0_i6);
Declare_label(mercury__browse__portray_4_0_i8);
Declare_label(mercury__browse__portray_4_0_i10);
Declare_label(mercury__browse__portray_4_0_i4);
Declare_label(mercury__browse__portray_4_0_i12);
Declare_label(mercury__browse__portray_4_0_i15);
Declare_label(mercury__browse__portray_4_0_i17);
Declare_label(mercury__browse__portray_4_0_i18);
Declare_label(mercury__browse__portray_4_0_i3);
Declare_label(mercury__browse__portray_4_0_i1008);
Declare_static(mercury__browse__portray_path_5_0);
Declare_label(mercury__browse__portray_path_5_0_i3);
Declare_label(mercury__browse__portray_path_5_0_i4);
Declare_label(mercury__browse__portray_path_5_0_i5);
Declare_static(mercury__browse__portray_verbose_4_0);
Declare_label(mercury__browse__portray_verbose_4_0_i3);
Declare_label(mercury__browse__portray_verbose_4_0_i4);
Declare_label(mercury__browse__portray_verbose_4_0_i6);
Declare_label(mercury__browse__portray_verbose_4_0_i8);
Declare_label(mercury__browse__portray_verbose_4_0_i2);
Declare_label(mercury__browse__portray_verbose_4_0_i10);
Declare_label(mercury__browse__portray_verbose_4_0_i13);
Declare_label(mercury__browse__portray_verbose_4_0_i15);
Declare_label(mercury__browse__portray_verbose_4_0_i16);
Declare_static(mercury__browse__portray_pretty_4_0);
Declare_label(mercury__browse__portray_pretty_4_0_i3);
Declare_label(mercury__browse__portray_pretty_4_0_i4);
Declare_label(mercury__browse__portray_pretty_4_0_i6);
Declare_label(mercury__browse__portray_pretty_4_0_i8);
Declare_label(mercury__browse__portray_pretty_4_0_i9);
Declare_label(mercury__browse__portray_pretty_4_0_i2);
Declare_label(mercury__browse__portray_pretty_4_0_i11);
Declare_label(mercury__browse__portray_pretty_4_0_i14);
Declare_label(mercury__browse__portray_pretty_4_0_i16);
Declare_label(mercury__browse__portray_pretty_4_0_i17);
Declare_static(mercury__browse__term_to_string_4_0);
Declare_label(mercury__browse__term_to_string_4_0_i5);
Declare_label(mercury__browse__term_to_string_4_0_i4);
Declare_label(mercury__browse__term_to_string_4_0_i6);
Declare_label(mercury__browse__term_to_string_4_0_i9);
Declare_label(mercury__browse__term_to_string_4_0_i3);
Declare_label(mercury__browse__term_to_string_4_0_i12);
Declare_label(mercury__browse__term_to_string_4_0_i13);
Declare_label(mercury__browse__term_to_string_4_0_i14);
Declare_label(mercury__browse__term_to_string_4_0_i16);
Declare_label(mercury__browse__term_to_string_4_0_i17);
Declare_label(mercury__browse__term_to_string_4_0_i20);
Declare_static(mercury__browse__term_to_string_list_7_0);
Declare_label(mercury__browse__term_to_string_list_7_0_i7);
Declare_label(mercury__browse__term_to_string_list_7_0_i6);
Declare_label(mercury__browse__term_to_string_list_7_0_i8);
Declare_label(mercury__browse__term_to_string_list_7_0_i1003);
Declare_label(mercury__browse__term_to_string_list_7_0_i9);
Declare_label(mercury__browse__term_to_string_list_7_0_i11);
Declare_label(mercury__browse__term_to_string_list_7_0_i5);
Declare_label(mercury__browse__term_to_string_list_7_0_i14);
Declare_label(mercury__browse__term_to_string_list_7_0_i15);
Declare_label(mercury__browse__term_to_string_list_7_0_i16);
Declare_label(mercury__browse__term_to_string_list_7_0_i18);
Declare_label(mercury__browse__term_to_string_list_7_0_i19);
Declare_label(mercury__browse__term_to_string_list_7_0_i23);
Declare_label(mercury__browse__term_to_string_list_7_0_i3);
Declare_static(mercury__browse__comma_args_2_0);
Declare_label(mercury__browse__comma_args_2_0_i3);
Declare_label(mercury__browse__comma_args_2_0_i5);
Declare_label(mercury__browse__comma_args_2_0_i8);
Declare_label(mercury__browse__comma_args_2_0_i9);
Declare_label(mercury__browse__comma_args_2_0_i7);
Declare_static(mercury__browse__term_to_string_pretty_2_7_0);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i5);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i4);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i6);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i7);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i9);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i10);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i3);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i12);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i14);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i13);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i16);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i17);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i18);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i19);
Declare_label(mercury__browse__term_to_string_pretty_2_7_0_i20);
Declare_static(mercury__browse__term_to_string_pretty_list_7_0);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i3);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i6);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i5);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i7);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i8);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i11);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i12);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i13);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i10);
Declare_label(mercury__browse__term_to_string_pretty_list_7_0_i14);
Declare_static(mercury__browse__comma_last_2_0);
Declare_label(mercury__browse__comma_last_2_0_i3);
Declare_label(mercury__browse__comma_last_2_0_i6);
Declare_label(mercury__browse__comma_last_2_0_i5);
Declare_label(mercury__browse__comma_last_2_0_i9);
Declare_label(mercury__browse__comma_last_2_0_i8);
Declare_label(mercury__browse__comma_last_2_0_i10);
Declare_static(mercury__browse__indent_2_0);
Declare_static(mercury__browse__unlines_2_0);
Declare_label(mercury__browse__unlines_2_0_i4);
Declare_label(mercury__browse__unlines_2_0_i5);
Declare_label(mercury__browse__unlines_2_0_i3);
Declare_static(mercury__browse__term_to_string_verbose_6_0);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i5);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i4);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i6);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i1012);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i7);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i9);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i3);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i12);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i1017);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i14);
Declare_label(mercury__browse__term_to_string_verbose_6_0_i16);
Declare_static(mercury__browse__term_to_string_verbose_2_7_0);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i5);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i4);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i6);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i7);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i9);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i10);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i3);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i12);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i13);
Declare_label(mercury__browse__term_to_string_verbose_2_7_0_i14);
Declare_static(mercury__browse__term_to_string_verbose_list_8_0);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i3);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i6);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i7);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i8);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i9);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i10);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i11);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i12);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i13);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i5);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i15);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i16);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i17);
Declare_label(mercury__browse__term_to_string_verbose_list_8_0_i18);
Declare_static(mercury__browse__write_path_4_0);
Declare_label(mercury__browse__write_path_4_0_i3);
Declare_label(mercury__browse__write_path_4_0_i8);
Declare_label(mercury__browse__write_path_4_0_i10);
Declare_label(mercury__browse__write_path_4_0_i12);
Declare_label(mercury__browse__write_path_4_0_i14);
Declare_label(mercury__browse__write_path_4_0_i15);
Declare_label(mercury__browse__write_path_4_0_i1009);
Declare_static(mercury__browse__write_path_2_4_0);
Declare_label(mercury__browse__write_path_2_4_0_i1006);
Declare_label(mercury__browse__write_path_2_4_0_i3);
Declare_label(mercury__browse__write_path_2_4_0_i8);
Declare_label(mercury__browse__write_path_2_4_0_i11);
Declare_label(mercury__browse__write_path_2_4_0_i13);
Declare_label(mercury__browse__write_path_2_4_0_i15);
Declare_label(mercury__browse__write_path_2_4_0_i16);
Declare_label(mercury__browse__write_path_2_4_0_i17);
Declare_label(mercury__browse__write_path_2_4_0_i6);
Declare_label(mercury__browse__write_path_2_4_0_i20);
Declare_label(mercury__browse__write_path_2_4_0_i22);
Declare_label(mercury__browse__write_path_2_4_0_i24);
Declare_label(mercury__browse__write_path_2_4_0_i26);
Declare_label(mercury__browse__write_path_2_4_0_i27);
Declare_static(mercury__browse__deref_subterm_3_0);
Declare_label(mercury__browse__deref_subterm_3_0_i2);
Declare_label(mercury__browse__deref_subterm_3_0_i3);
Declare_label(mercury__browse__deref_subterm_3_0_i1);
Declare_static(mercury__browse__dirs_to_ints_2_0);
Declare_label(mercury__browse__dirs_to_ints_2_0_i3);
Declare_label(mercury__browse__dirs_to_ints_2_0_i6);
Declare_label(mercury__browse__dirs_to_ints_2_0_i5);
Declare_label(mercury__browse__dirs_to_ints_2_0_i7);
Declare_label(mercury__browse__dirs_to_ints_2_0_i1);
Declare_static(mercury__browse__deref_subterm_2_3_0);
Declare_label(mercury__browse__deref_subterm_2_3_0_i1003);
Declare_label(mercury__browse__deref_subterm_2_3_0_i2);
Declare_label(mercury__browse__deref_subterm_2_3_0_i5);
Declare_label(mercury__browse__deref_subterm_2_3_0_i6);
Declare_label(mercury__browse__deref_subterm_2_3_0_i1);
Declare_static(mercury__browse__get_term_2_0);
Declare_static(mercury__browse__get_dirs_2_0);
Declare_static(mercury__browse__set_path_3_0);
Declare_label(mercury__browse__set_path_3_0_i3);
Declare_label(mercury__browse__set_path_3_0_i4);
Declare_label(mercury__browse__set_path_3_0_i5);
Declare_static(mercury__browse__change_dir_3_0);
Declare_label(mercury__browse__change_dir_3_0_i3);
Declare_label(mercury__browse__change_dir_3_0_i4);
Declare_static(mercury__browse__set_fmt_3_0);
Declare_static(mercury__browse__show_settings_4_0);
Declare_label(mercury__browse__show_settings_4_0_i2);
Declare_label(mercury__browse__show_settings_4_0_i5);
Declare_label(mercury__browse__show_settings_4_0_i6);
Declare_label(mercury__browse__show_settings_4_0_i7);
Declare_label(mercury__browse__show_settings_4_0_i8);
Declare_label(mercury__browse__show_settings_4_0_i9);
Declare_label(mercury__browse__show_settings_4_0_i10);
Declare_label(mercury__browse__show_settings_4_0_i11);
Declare_label(mercury__browse__show_settings_4_0_i4);
Declare_label(mercury__browse__show_settings_4_0_i13);
Declare_label(mercury__browse__show_settings_4_0_i14);
Declare_label(mercury__browse__show_settings_4_0_i15);
Declare_label(mercury__browse__show_settings_4_0_i16);
Declare_label(mercury__browse__show_settings_4_0_i17);
Declare_label(mercury__browse__show_settings_4_0_i18);
Declare_label(mercury__browse__show_settings_4_0_i19);
Declare_label(mercury__browse__show_settings_4_0_i20);
Declare_label(mercury__browse__show_settings_4_0_i21);
Declare_label(mercury__browse__show_settings_4_0_i22);
Declare_label(mercury__browse__show_settings_4_0_i23);
Declare_label(mercury__browse__show_settings_4_0_i24);
Declare_label(mercury__browse__show_settings_4_0_i25);
Declare_label(mercury__browse__show_settings_4_0_i26);
Declare_label(mercury__browse__show_settings_4_0_i27);
Declare_label(mercury__browse__show_settings_4_0_i28);
Declare_label(mercury__browse__show_settings_4_0_i29);
Declare_label(mercury__browse__show_settings_4_0_i30);
Declare_label(mercury__browse__show_settings_4_0_i31);
Declare_label(mercury__browse__show_settings_4_0_i32);
Declare_label(mercury__browse__show_settings_4_0_i33);
Declare_label(mercury__browse__show_settings_4_0_i34);
Declare_label(mercury__browse__show_settings_4_0_i35);
Declare_label(mercury__browse__show_settings_4_0_i36);
Declare_label(mercury__browse__show_settings_4_0_i37);
Declare_label(mercury__browse__show_settings_4_0_i38);
Declare_label(mercury__browse__show_settings_4_0_i39);
Declare_label(mercury__browse__show_settings_4_0_i40);
Declare_label(mercury__browse__show_settings_4_0_i41);
Declare_label(mercury__browse__show_settings_4_0_i42);
Declare_label(mercury__browse__show_settings_4_0_i43);
Declare_label(mercury__browse__show_settings_4_0_i44);
Declare_static(mercury__browse__simplify_2_0);
Declare_label(mercury__browse__simplify_2_0_i3);
Declare_label(mercury__browse__simplify_2_0_i5);
Declare_label(mercury__browse__simplify_2_0_i7);
Declare_label(mercury__browse__simplify_2_0_i9);
Declare_label(mercury__browse__simplify_2_0_i11);
Declare_label(mercury__browse__simplify_2_0_i13);
Declare_label(mercury__browse__simplify_2_0_i16);
Declare_label(mercury__browse__simplify_2_0_i15);
Declare_static(mercury__browse__write_string_debugger_4_0);
Declare_label(mercury__browse__write_string_debugger_4_0_i3);
Declare_label(mercury__browse__write_string_debugger_4_0_i5);
Declare_label(mercury__browse__write_string_debugger_4_0_i6);
Declare_static(mercury__browse__nl_debugger_3_0);
Declare_label(mercury__browse__nl_debugger_3_0_i3);
Declare_label(mercury__browse__nl_debugger_3_0_i5);
Declare_label(mercury__browse__nl_debugger_3_0_i6);
Declare_static(mercury__browse__write_int_debugger_4_0);
Declare_label(mercury__browse__write_int_debugger_4_0_i3);
Declare_label(mercury__browse__write_int_debugger_4_0_i5);
Declare_label(mercury__browse__write_int_debugger_4_0_i6);
Declare_static(mercury__browse__print_format_debugger_4_0);
Declare_label(mercury__browse__print_format_debugger_4_0_i3);
Declare_label(mercury__browse__print_format_debugger_4_0_i6);
Declare_label(mercury__browse__print_format_debugger_4_0_i10);
Declare_label(mercury__browse__print_format_debugger_4_0_i14);
Declare_label(mercury__browse__print_format_debugger_4_0_i15);
Declare_static(mercury__browse__send_term_to_socket_3_0);
Declare_label(mercury__browse__send_term_to_socket_3_0_i2);
Declare_label(mercury__browse__send_term_to_socket_3_0_i3);
Define_extern_entry(mercury____Unify___browse__browser_state_0_0);
Declare_label(mercury____Unify___browse__browser_state_0_0_i2);
Declare_label(mercury____Unify___browse__browser_state_0_0_i4);
Declare_label(mercury____Unify___browse__browser_state_0_0_i1);
Define_extern_entry(mercury____Index___browse__browser_state_0_0);
Define_extern_entry(mercury____Compare___browse__browser_state_0_0);
Declare_label(mercury____Compare___browse__browser_state_0_0_i3);
Declare_label(mercury____Compare___browse__browser_state_0_0_i7);
Declare_label(mercury____Compare___browse__browser_state_0_0_i11);
Declare_label(mercury____Compare___browse__browser_state_0_0_i15);
Declare_label(mercury____Compare___browse__browser_state_0_0_i19);
Declare_label(mercury____Compare___browse__browser_state_0_0_i23);
Declare_label(mercury____Compare___browse__browser_state_0_0_i32);
Declare_static(mercury____Unify___browse__term_browser_response_0_0);
Declare_label(mercury____Unify___browse__term_browser_response_0_0_i8);
Declare_label(mercury____Unify___browse__term_browser_response_0_0_i10);
Declare_label(mercury____Unify___browse__term_browser_response_0_0_i6);
Declare_label(mercury____Unify___browse__term_browser_response_0_0_i4);
Declare_label(mercury____Unify___browse__term_browser_response_0_0_i1);
Declare_static(mercury____Index___browse__term_browser_response_0_0);
Declare_label(mercury____Index___browse__term_browser_response_0_0_i6);
Declare_label(mercury____Index___browse__term_browser_response_0_0_i7);
Declare_label(mercury____Index___browse__term_browser_response_0_0_i5);
Declare_label(mercury____Index___browse__term_browser_response_0_0_i4);
Declare_static(mercury____Compare___browse__term_browser_response_0_0);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i6);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i7);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i5);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i4);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i2);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i12);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i13);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i11);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i10);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i8);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i14);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i15);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i26);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i28);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i23);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i20);
Declare_label(mercury____Compare___browse__term_browser_response_0_0_i1029);
Declare_static(mercury____Unify___browse__debugger_0_0);
Declare_label(mercury____Unify___browse__debugger_0_0_i1);
Declare_static(mercury____Index___browse__debugger_0_0);
Declare_static(mercury____Compare___browse__debugger_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_browser_state_0;

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_debugger_0;

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_term_browser_response_0;

static const struct mercury_data_browse__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_browse__common_0;

static const struct mercury_data_browse__common_1_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_browse__common_1;

static const struct mercury_data_browse__common_2_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_browse__common_2;

static const struct mercury_data_browse__common_3_struct {
	String f1;
}  mercury_data_browse__common_3;

static const struct mercury_data_browse__common_4_struct {
	Word * f1;
}  mercury_data_browse__common_4;

static const struct mercury_data_browse__common_5_struct {
	Word * f1;
}  mercury_data_browse__common_5;

static const struct mercury_data_browse__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_browse__common_6;

static const struct mercury_data_browse__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_browse__common_7;

static const struct mercury_data_browse__common_8_struct {
	String f1;
	Word * f2;
}  mercury_data_browse__common_8;

static const struct mercury_data_browse__common_9_struct {
	String f1;
	Word * f2;
}  mercury_data_browse__common_9;

static const struct mercury_data_browse__common_10_struct {
	Word * f1;
}  mercury_data_browse__common_10;

static const struct mercury_data_browse__common_11_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_browse__common_11;

static const struct mercury_data_browse__common_12_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_browse__common_12;

static const struct mercury_data_browse__common_13_struct {
	String f1;
	Word * f2;
}  mercury_data_browse__common_13;

static const struct mercury_data_browse__common_14_struct {
	String f1;
}  mercury_data_browse__common_14;

static const struct mercury_data_browse__common_15_struct {
	String f1;
}  mercury_data_browse__common_15;

static const struct mercury_data_browse__common_16_struct {
	String f1;
}  mercury_data_browse__common_16;

static const struct mercury_data_browse__common_17_struct {
	String f1;
}  mercury_data_browse__common_17;

static const struct mercury_data_browse__common_18_struct {
	String f1;
}  mercury_data_browse__common_18;

static const struct mercury_data_browse__common_19_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_browse__common_19;

static const struct mercury_data_browse__common_20_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_browse__common_20;

static const struct mercury_data_browse__common_21_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_browse__common_21;

static const struct mercury_data_browse__common_22_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_browse__common_22;

static const struct mercury_data_browse__common_23_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_browse__common_23;

static const struct mercury_data_browse__common_24_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_browse__common_24;

static const struct mercury_data_browse__common_25_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_browse__common_25;

static const struct mercury_data_browse__common_26_struct {
	Word * f1;
}  mercury_data_browse__common_26;

static const struct mercury_data_browse__common_27_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	String f9;
	Word * f10;
	Integer f11;
	Integer f12;
}  mercury_data_browse__common_27;

static const struct mercury_data_browse__type_ctor_functors_term_browser_response_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_browse__type_ctor_functors_term_browser_response_0;

static const struct mercury_data_browse__type_ctor_layout_term_browser_response_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_browse__type_ctor_layout_term_browser_response_0;

static const struct mercury_data_browse__type_ctor_functors_debugger_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_browse__type_ctor_functors_debugger_0;

static const struct mercury_data_browse__type_ctor_layout_debugger_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_browse__type_ctor_layout_debugger_0;

static const struct mercury_data_browse__type_ctor_functors_browser_state_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_browse__type_ctor_functors_browser_state_0;

static const struct mercury_data_browse__type_ctor_layout_browser_state_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_browse__type_ctor_layout_browser_state_0;

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_browser_state_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___browse__browser_state_0_0),
	ENTRY(mercury____Index___browse__browser_state_0_0),
	ENTRY(mercury____Compare___browse__browser_state_0_0),
	(Integer) 2,
	(Word *) &mercury_data_browse__type_ctor_functors_browser_state_0,
	(Word *) &mercury_data_browse__type_ctor_layout_browser_state_0,
	MR_string_const("browse", 6),
	MR_string_const("browser_state", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_debugger_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___browse__debugger_0_0),
	STATIC(mercury____Index___browse__debugger_0_0),
	STATIC(mercury____Compare___browse__debugger_0_0),
	(Integer) 0,
	(Word *) &mercury_data_browse__type_ctor_functors_debugger_0,
	(Word *) &mercury_data_browse__type_ctor_layout_debugger_0,
	MR_string_const("browse", 6),
	MR_string_const("debugger", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_browse__type_ctor_info_term_browser_response_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___browse__term_browser_response_0_0),
	STATIC(mercury____Index___browse__term_browser_response_0_0),
	STATIC(mercury____Compare___browse__term_browser_response_0_0),
	(Integer) 2,
	(Word *) &mercury_data_browse__type_ctor_functors_term_browser_response_0,
	(Word *) &mercury_data_browse__type_ctor_layout_term_browser_response_0,
	MR_string_const("browse", 6),
	MR_string_const("term_browser_response", 21),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_parse__type_ctor_info_dir_0;
static const struct mercury_data_browse__common_0_struct mercury_data_browse__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_parse__type_ctor_info_dir_0
};

static const struct mercury_data_browse__common_1_struct mercury_data_browse__common_1 = {
	(Integer) 0,
	MR_string_const("browse", 6),
	MR_string_const("browse", 6),
	MR_string_const("simplify", 8),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_0)
};

static const struct mercury_data_browse__common_2_struct mercury_data_browse__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_1),
	STATIC(mercury__browse__simplify_2_0),
	(Integer) 0
};

static const struct mercury_data_browse__common_3_struct mercury_data_browse__common_3 = {
	MR_string_const("error: no such subterm", 22)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_univ_0;
static const struct mercury_data_browse__common_4_struct mercury_data_browse__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_univ_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_browse__common_5_struct mercury_data_browse__common_5 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_browse__common_6_struct mercury_data_browse__common_6 = {
	(Integer) 0,
	MR_string_const("browse", 6),
	MR_string_const("browse", 6),
	MR_string_const("term_size_left_from_max", 23),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5)
};

static const struct mercury_data_browse__common_7_struct mercury_data_browse__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_6),
	STATIC(mercury__browse__term_size_left_from_max_3_0),
	(Integer) 0
};

static const struct mercury_data_browse__common_8_struct mercury_data_browse__common_8 = {
	MR_string_const("", 0),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_browse__common_9_struct mercury_data_browse__common_9 = {
	MR_string_const(")", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_browse__common_10_struct mercury_data_browse__common_10 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_browse__common_11_struct mercury_data_browse__common_11 = {
	(Integer) 0,
	MR_string_const("browse", 6),
	MR_string_const("browse", 6),
	MR_string_const("indent", 6),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_10)
};

static const struct mercury_data_browse__common_12_struct mercury_data_browse__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_11),
	STATIC(mercury__browse__indent_2_0),
	(Integer) 0
};

static const struct mercury_data_browse__common_13_struct mercury_data_browse__common_13 = {
	MR_string_const("-", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_browse__common_14_struct mercury_data_browse__common_14 = {
	MR_string_const("Max size is: ", 13)
};

static const struct mercury_data_browse__common_15_struct mercury_data_browse__common_15 = {
	MR_string_const("X clip is: ", 11)
};

static const struct mercury_data_browse__common_16_struct mercury_data_browse__common_16 = {
	MR_string_const("flat", 4)
};

static const struct mercury_data_browse__common_17_struct mercury_data_browse__common_17 = {
	MR_string_const("pretty", 6)
};

static const struct mercury_data_browse__common_18_struct mercury_data_browse__common_18 = {
	MR_string_const("verbose", 7)
};

static const struct mercury_data_browse__common_19_struct mercury_data_browse__common_19 = {
	(Integer) 0,
	MR_string_const("browser_end_command", 19),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__common_20_struct mercury_data_browse__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	MR_string_const("browser_int", 11),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__common_21_struct mercury_data_browse__common_21 = {
	(Integer) 0,
	MR_string_const("browser_nl", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__common_22_struct mercury_data_browse__common_22 = {
	(Integer) 0,
	MR_string_const("browser_quit", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__common_23_struct mercury_data_browse__common_23 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_10),
	MR_string_const("browser_str", 11),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__common_24_struct mercury_data_browse__common_24 = {
	(Integer) 0,
	(Integer) 3,
	MR_string_const("browser_nl", 10),
	MR_string_const("browser_end_command", 19),
	MR_string_const("browser_quit", 12)
};

static const struct mercury_data_browse__common_25_struct mercury_data_browse__common_25 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("internal", 8),
	MR_string_const("external", 8)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_parse__type_ctor_info_portray_format_0;
static const struct mercury_data_browse__common_26_struct mercury_data_browse__common_26 = {
	(Word *) &mercury_data_parse__type_ctor_info_portray_format_0
};

static const struct mercury_data_browse__common_27_struct mercury_data_browse__common_27 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_5),
	MR_string_const("browser_state", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_browse__type_ctor_functors_term_browser_response_0_struct mercury_data_browse__type_ctor_functors_term_browser_response_0 = {
	(Integer) 0,
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_23)
};

static const struct mercury_data_browse__type_ctor_layout_term_browser_response_0_struct mercury_data_browse__type_ctor_layout_term_browser_response_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_24),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_23),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_browse__type_ctor_functors_debugger_0_struct mercury_data_browse__type_ctor_functors_debugger_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_25)
};

static const struct mercury_data_browse__type_ctor_layout_debugger_0_struct mercury_data_browse__type_ctor_layout_debugger_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_25)
};

static const struct mercury_data_browse__type_ctor_functors_browser_state_0_struct mercury_data_browse__type_ctor_functors_browser_state_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_27)
};

static const struct mercury_data_browse__type_ctor_layout_browser_state_0_struct mercury_data_browse__type_ctor_layout_browser_state_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_27),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(browse_module0)
	init_entry(mercury____Index___browse__browser_state_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___browse__browser_state_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___browse__browser_state_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__std_util__type_to_univ_2_0);
Declare_entry(mercury__parse__default_depth_1_0);

BEGIN_MODULE(browse_module1)
	init_entry(mercury__browse__init_state_3_0);
	init_label(mercury__browse__init_state_3_0_i2);
	init_label(mercury__browse__init_state_3_0_i3);
BEGIN_CODE

/* code for predicate 'init_state'/3 in mode 0 */
Define_entry(mercury__browse__init_state_3_0);
	MR_incr_sp_push_msg(3, "browse:init_state/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__browse__init_state_3_0_i2,
		ENTRY(mercury__browse__init_state_3_0));
Define_label(mercury__browse__init_state_3_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__init_state_3_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__parse__default_depth_1_0),
		mercury__browse__init_state_3_0_i3,
		ENTRY(mercury__browse__init_state_3_0));
Define_label(mercury__browse__init_state_3_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__init_state_3_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__browse__init_state_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = r1;
	r1 = r3;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 6) = (Integer) 25;
	MR_field(MR_mktag(0), r3, (Integer) 5) = (Integer) 79;
	MR_field(MR_mktag(0), r3, (Integer) 4) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__std_util__type_to_univ_2_1);
Declare_entry(mercury__util__limit_3_0);
Declare_entry(mercury__io__set_input_stream_4_0);
Declare_entry(mercury__io__set_output_stream_4_0);

BEGIN_MODULE(browse_module2)
	init_entry(mercury__browse__browse_7_0);
	init_label(mercury__browse__browse_7_0_i2);
	init_label(mercury__browse__browse_7_0_i3);
	init_label(mercury__browse__browse_7_0_i4);
	init_label(mercury__browse__browse_7_0_i5);
	init_label(mercury__browse__browse_7_0_i6);
	init_label(mercury__browse__browse_7_0_i7);
	init_label(mercury__browse__browse_7_0_i8);
	init_label(mercury__browse__browse_7_0_i9);
BEGIN_CODE

/* code for predicate 'browse'/7 in mode 0 */
Define_entry(mercury__browse__browse_7_0);
	MR_incr_sp_push_msg(10, "browse:browse/7");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__browse__browse_7_0_i2,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__browse__browse_7_0_i3,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__browse_7_0_i4,
		ENTRY(mercury__browse__browse_7_0));
	}
Define_label(mercury__browse__browse_7_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__browse__browse_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__browse__browse_7_0_i5,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__browse_7_0_i6,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	r3 = r2;
	MR_stackvar(3) = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__browse_main_loop_5_0),
		mercury__browse__browse_7_0_i7,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__browse__browse_7_0_i8,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__browse_7_0_i9,
		ENTRY(mercury__browse__browse_7_0));
Define_label(mercury__browse__browse_7_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__browse_7_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module3)
	init_entry(mercury__browse__browse_external_7_0);
	init_label(mercury__browse__browse_external_7_0_i2);
	init_label(mercury__browse__browse_external_7_0_i3);
	init_label(mercury__browse__browse_external_7_0_i4);
	init_label(mercury__browse__browse_external_7_0_i5);
	init_label(mercury__browse__browse_external_7_0_i6);
	init_label(mercury__browse__browse_external_7_0_i7);
	init_label(mercury__browse__browse_external_7_0_i8);
	init_label(mercury__browse__browse_external_7_0_i9);
BEGIN_CODE

/* code for predicate 'browse_external'/7 in mode 0 */
Define_entry(mercury__browse__browse_external_7_0);
	MR_incr_sp_push_msg(10, "browse:browse_external/7");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__browse__browse_external_7_0_i2,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__browse__browse_external_7_0_i3,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__browse_external_7_0_i4,
		ENTRY(mercury__browse__browse_external_7_0));
	}
Define_label(mercury__browse__browse_external_7_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__browse__browse_external_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__browse__browse_external_7_0_i5,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__browse_external_7_0_i6,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	r3 = r2;
	MR_stackvar(3) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__browse_main_loop_5_0),
		mercury__browse__browse_external_7_0_i7,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__browse__browse_external_7_0_i8,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__browse_external_7_0_i9,
		ENTRY(mercury__browse__browse_external_7_0));
Define_label(mercury__browse__browse_external_7_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__browse_external_7_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module4)
	init_entry(mercury__browse__print_5_0);
	init_label(mercury__browse__print_5_0_i2);
	init_label(mercury__browse__print_5_0_i3);
	init_label(mercury__browse__print_5_0_i4);
	init_label(mercury__browse__print_5_0_i5);
	init_label(mercury__browse__print_5_0_i6);
BEGIN_CODE

/* code for predicate 'print'/5 in mode 0 */
Define_entry(mercury__browse__print_5_0);
	MR_incr_sp_push_msg(9, "browse:print/5");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_1),
		mercury__browse__print_5_0_i2,
		ENTRY(mercury__browse__print_5_0));
Define_label(mercury__browse__print_5_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__print_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__print_5_0_i3,
		ENTRY(mercury__browse__print_5_0));
	}
Define_label(mercury__browse__print_5_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__print_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__browse__print_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__print_5_0_i4,
		ENTRY(mercury__browse__print_5_0));
Define_label(mercury__browse__print_5_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__print_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__browse__print_3_0),
		mercury__browse__print_5_0_i5,
		ENTRY(mercury__browse__print_5_0));
Define_label(mercury__browse__print_5_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__print_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__browse__print_5_0_i6,
		ENTRY(mercury__browse__print_5_0));
Define_label(mercury__browse__print_5_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__print_5_0));
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__fn__std_util__type_of_1_0);

BEGIN_MODULE(browse_module5)
	init_entry(mercury__browse__browser_state_type_1_0);
	init_label(mercury__browse__browser_state_type_1_0_i2);
	init_label(mercury__browse__browser_state_type_1_0_i3);
	init_label(mercury__browse__browser_state_type_1_0_i4);
BEGIN_CODE

/* code for predicate 'browser_state_type'/1 in mode 0 */
Define_static(mercury__browse__browser_state_type_1_0);
	MR_incr_sp_push_msg(1, "browse:browser_state_type/1");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__browse__browser_state_type_1_0_i2,
		STATIC(mercury__browse__browser_state_type_1_0));
Define_label(mercury__browse__browser_state_type_1_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__browser_state_type_1_0));
	call_localret(ENTRY(mercury__parse__default_depth_1_0),
		mercury__browse__browser_state_type_1_0_i3,
		STATIC(mercury__browse__browser_state_type_1_0));
Define_label(mercury__browse__browser_state_type_1_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__browser_state_type_1_0));
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_browser_state_0;
	call_localret(ENTRY(mercury__fn__std_util__type_of_1_0),
		mercury__browse__browser_state_type_1_0_i4,
		STATIC(mercury__browse__browser_state_type_1_0));
Define_label(mercury__browse__browser_state_type_1_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__browser_state_type_1_0));
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_univ_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(browse_module6)
	init_entry(mercury__browse__print_3_0);
	init_label(mercury__browse__print_3_0_i2);
	init_label(mercury__browse__print_3_0_i3);
	init_label(mercury__browse__print_3_0_i7);
	init_label(mercury__browse__print_3_0_i8);
	init_label(mercury__browse__print_3_0_i10);
	init_label(mercury__browse__print_3_0_i12);
	init_label(mercury__browse__print_3_0_i6);
	init_label(mercury__browse__print_3_0_i15);
BEGIN_CODE

/* code for predicate 'print'/3 in mode 0 */
Define_static(mercury__browse__print_3_0);
	MR_incr_sp_push_msg(5, "browse:print/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	r2 = (Integer) 60;
	call_localret(STATIC(mercury__browse__term_size_left_from_max_3_0),
		mercury__browse__print_3_0_i2,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	if (((Integer) r1 < (Integer) 0))
		GOTO_LABEL(mercury__browse__print_3_0_i3);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_univ_3_0),
		mercury__browse__print_3_0_i15,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__print_3_0_i7,
		STATIC(mercury__browse__print_3_0));
	}
Define_label(mercury__browse__print_3_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__print_3_0_i8,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__print_3_0_i6);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__deref_subterm_2_3_0),
		mercury__browse__print_3_0_i10,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__print_3_0_i6);
	r1 = r2;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__term_to_string_4_0),
		mercury__browse__print_3_0_i12,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__browse__print_3_0_i15,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i6);
	r1 = (Word) MR_string_const("error: no such subterm", 22);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__browse__print_3_0_i15,
		STATIC(mercury__browse__print_3_0));
Define_label(mercury__browse__print_3_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__print_3_0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__browse__print_3_0));
END_MODULE

Declare_entry(mercury__io__write_3_0);
Declare_entry(mercury__io__print_3_0);
Declare_entry(mercury__io__flush_output_2_0);

BEGIN_MODULE(browse_module7)
	init_entry(mercury__browse__print_external_3_0);
	init_label(mercury__browse__print_external_3_0_i3);
	init_label(mercury__browse__print_external_3_0_i4);
	init_label(mercury__browse__print_external_3_0_i6);
	init_label(mercury__browse__print_external_3_0_i8);
	init_label(mercury__browse__print_external_3_0_i2);
	init_label(mercury__browse__print_external_3_0_i12);
	init_label(mercury__browse__print_external_3_0_i13);
	init_label(mercury__browse__print_external_3_0_i14);
	init_label(mercury__browse__print_external_3_0_i16);
	init_label(mercury__browse__print_external_3_0_i17);
BEGIN_CODE

/* code for predicate 'print_external'/3 in mode 0 */
Define_static(mercury__browse__print_external_3_0);
	MR_incr_sp_push_msg(5, "browse:print_external/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__print_external_3_0_i3,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__print_external_3_0_i4,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__print_external_3_0_i2);
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__deref_subterm_2_3_0),
		mercury__browse__print_external_3_0_i6,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__print_external_3_0_i2);
	r1 = r2;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__term_to_string_4_0),
		mercury__browse__print_external_3_0_i8,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__browse__print_external_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_external_3_0_i12,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i2);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_3);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_external_3_0_i12,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__print_external_3_0_i13,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__print_external_3_0_i14,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_external_3_0_i16,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__print_external_3_0_i17,
		STATIC(mercury__browse__print_external_3_0));
Define_label(mercury__browse__print_external_3_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__print_external_3_0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__print_external_3_0));
END_MODULE

Declare_entry(mercury__std_util__deconstruct_4_0);
Declare_entry(mercury__string__length_2_0);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(browse_module8)
	init_entry(mercury__browse__term_size_left_from_max_3_0);
	init_label(mercury__browse__term_size_left_from_max_3_0_i2);
	init_label(mercury__browse__term_size_left_from_max_3_0_i3);
	init_label(mercury__browse__term_size_left_from_max_3_0_i4);
BEGIN_CODE

/* code for predicate 'term_size_left_from_max'/3 in mode 0 */
Define_static(mercury__browse__term_size_left_from_max_3_0);
	MR_incr_sp_push_msg(4, "browse:term_size_left_from_max/3");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r2 >= (Integer) 0))
		GOTO_LABEL(mercury__browse__term_size_left_from_max_3_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__browse__term_size_left_from_max_3_0_i2);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_size_left_from_max_3_0_i3,
		STATIC(mercury__browse__term_size_left_from_max_3_0));
Define_label(mercury__browse__term_size_left_from_max_3_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__term_size_left_from_max_3_0));
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__browse__term_size_left_from_max_3_0_i4,
		STATIC(mercury__browse__term_size_left_from_max_3_0));
Define_label(mercury__browse__term_size_left_from_max_3_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__term_size_left_from_max_3_0));
	r5 = ((Integer) MR_stackvar(1) - ((Integer) r1 + ((Integer) MR_stackvar(2) * (Integer) 2)));
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_7);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__browse__term_size_left_from_max_3_0));
END_MODULE

Declare_entry(mercury__parse__read_command_4_0);
Declare_entry(mercury__parse__read_command_external_3_0);

BEGIN_MODULE(browse_module9)
	init_entry(mercury__browse__browse_main_loop_5_0);
	init_label(mercury__browse__browse_main_loop_5_0_i1003);
	init_label(mercury__browse__browse_main_loop_5_0_i3);
	init_label(mercury__browse__browse_main_loop_5_0_i5);
	init_label(mercury__browse__browse_main_loop_5_0_i9);
	init_label(mercury__browse__browse_main_loop_5_0_i10);
	init_label(mercury__browse__browse_main_loop_5_0_i11);
	init_label(mercury__browse__browse_main_loop_5_0_i12);
	init_label(mercury__browse__browse_main_loop_5_0_i6);
	init_label(mercury__browse__browse_main_loop_5_0_i13);
BEGIN_CODE

/* code for predicate 'browse_main_loop'/5 in mode 0 */
Define_static(mercury__browse__browse_main_loop_5_0);
	MR_incr_sp_push_msg(3, "browse:browse_main_loop/5");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__browse__browse_main_loop_5_0_i1003);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__browse_main_loop_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("browser> ", 9);
	r2 = r3;
	call_localret(ENTRY(mercury__parse__read_command_4_0),
		mercury__browse__browse_main_loop_5_0_i5,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i3);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__parse__read_command_external_3_0),
		mercury__browse__browse_main_loop_5_0_i5,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__browse_main_loop_5_0));
	r3 = r2;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury__browse__browse_main_loop_5_0_i6);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__browse_main_loop_5_0_i9);
	r1 = MR_stackvar(2);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__browse_main_loop_5_0_i9);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__browse_main_loop_5_0_i10,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__browse_main_loop_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__browse_main_loop_5_0_i11,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__browse_main_loop_5_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__browse_main_loop_5_0_i12,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__browse_main_loop_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__browse_main_loop_5_0_i6);
	r2 = r1;
	r1 = MR_stackvar(1);
	r4 = r3;
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__run_command_6_0),
		mercury__browse__browse_main_loop_5_0_i13,
		STATIC(mercury__browse__browse_main_loop_5_0));
Define_label(mercury__browse__browse_main_loop_5_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__browse_main_loop_5_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__browse__browse_main_loop_5_0_i1003);
END_MODULE


BEGIN_MODULE(browse_module10)
	init_entry(mercury__browse__run_command_6_0);
	init_label(mercury__browse__run_command_6_0_i4);
	init_label(mercury__browse__run_command_6_0_i2);
	init_label(mercury__browse__run_command_6_0_i6);
	init_label(mercury__browse__run_command_6_0_i9);
	init_label(mercury__browse__run_command_6_0_i14);
	init_label(mercury__browse__run_command_6_0_i16);
	init_label(mercury__browse__run_command_6_0_i18);
	init_label(mercury__browse__run_command_6_0_i20);
	init_label(mercury__browse__run_command_6_0_i22);
	init_label(mercury__browse__run_command_6_0_i12);
	init_label(mercury__browse__run_command_6_0_i31);
	init_label(mercury__browse__run_command_6_0_i34);
	init_label(mercury__browse__run_command_6_0_i39);
	init_label(mercury__browse__run_command_6_0_i37);
	init_label(mercury__browse__run_command_6_0_i42);
	init_label(mercury__browse__run_command_6_0_i43);
	init_label(mercury__browse__run_command_6_0_i44);
	init_label(mercury__browse__run_command_6_0_i47);
	init_label(mercury__browse__run_command_6_0_i49);
	init_label(mercury__browse__run_command_6_0_i46);
	init_label(mercury__browse__run_command_6_0_i40);
	init_label(mercury__browse__run_command_6_0_i54);
	init_label(mercury__browse__run_command_6_0_i52);
	init_label(mercury__browse__run_command_6_0_i61);
	init_label(mercury__browse__run_command_6_0_i62);
	init_label(mercury__browse__run_command_6_0_i59);
	init_label(mercury__browse__run_command_6_0_i64);
	init_label(mercury__browse__run_command_6_0_i1026);
	init_label(mercury__browse__run_command_6_0_i74);
	init_label(mercury__browse__run_command_6_0_i77);
	init_label(mercury__browse__run_command_6_0_i75);
BEGIN_CODE

/* code for predicate 'run_command'/6 in mode 0 */
Define_static(mercury__browse__run_command_6_0);
	MR_incr_sp_push_msg(9, "browse:run_command/6");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i2);
	MR_stackvar(2) = r3;
	r2 = (Word) MR_string_const("Error: unknown command or syntax error.\n", 40);
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i4,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("Type \"help\" for help.\n", 22);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i6);
	MR_stackvar(2) = r3;
	r2 = (Word) MR_string_const("Commands are:\n\tls [path]      -- list subterm (expanded)\n\tcd [path]      -- cd current subterm (default is root)\n\thelp           -- show this help message\n\tset var value  -- set a setting\n\tset            -- show settings\n\tprint          -- show single line representation of current term\n\tquit           -- quit browser\nSICStus Prolog style commands are:\n\tp              -- print\n\t< [n]          -- set depth (default is 10)\n\t^ [path]       -- cd [path]\n\t?              -- help\n\th              -- help\n\n-- settings:\n--    size; depth; path; format (flat pretty verbose); clipx; clipy\n--    Paths can be Unix-style or SICStus-style: /2/3/1 or ^2^3^1\n\n", 650);
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i6);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i9);
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__show_settings_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i9);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i12);
	r5 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i14);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 7, mercury__browse__run_command_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r2 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_tempr1;
	GOTO_LABEL(mercury__browse__run_command_6_0_i1026);
	}
Define_label(mercury__browse__run_command_6_0_i14);
	if ((MR_tag(r5) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i16);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__browse__run_command_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r2 = r4;
	MR_stackvar(3) = r1;
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i16);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i18);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__browse__run_command_6_0_i18);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__browse__run_command_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r2 = r4;
	MR_stackvar(3) = r1;
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i18);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i20);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__browse__run_command_6_0_i20);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__browse__run_command_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r2 = r4;
	MR_stackvar(3) = r1;
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i20);
	if ((MR_tag(r5) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i22);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	r2 = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__browse__set_fmt_3_0),
		mercury__browse__run_command_6_0_i49,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i22);
	MR_stackvar(2) = r3;
	r2 = (Word) MR_string_const("error: unknown setting.\n", 24);
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i31);
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__portray_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i31);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i34);
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__portray_path_5_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
	}
Define_label(mercury__browse__run_command_6_0_i34);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i37);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__run_command_6_0_i39,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i39);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__browse__run_command_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i37);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__browse__run_command_6_0_i40);
	MR_stackvar(1) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r1 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__browse__get_dirs_2_0),
		mercury__browse__run_command_6_0_i42,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i42);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__get_term_2_0),
		mercury__browse__run_command_6_0_i43,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i43);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__browse__change_dir_3_0),
		mercury__browse__run_command_6_0_i44,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i44);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__deref_subterm_3_0),
		mercury__browse__run_command_6_0_i47,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i47);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__run_command_6_0_i46);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__set_path_3_0),
		mercury__browse__run_command_6_0_i49,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i49);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	MR_stackvar(3) = r1;
	r2 = MR_stackvar(4);
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i46);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("error: cannot change to subterm\n", 32);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i40);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i52);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__run_command_6_0_i54);
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__browse__print_3_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i54);
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__browse__print_external_3_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i52);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__browse__run_command_6_0_i59);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__browse__get_dirs_2_0),
		mercury__browse__run_command_6_0_i61,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i61);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__write_path_4_0),
		mercury__browse__run_command_6_0_i62,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i62);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__nl_debugger_3_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i59);
	MR_stackvar(2) = r3;
	r2 = (Word) MR_string_const("command not yet implemented\n", 28);
	r3 = r4;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__run_command_6_0_i64,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i64);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	MR_stackvar(3) = MR_stackvar(2);
	r2 = r1;
	GOTO_LABEL(mercury__browse__run_command_6_0_i74);
Define_label(mercury__browse__run_command_6_0_i1026);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__browse__run_command_6_0_i75);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__browse__send_term_to_socket_3_0),
		mercury__browse__run_command_6_0_i77,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i74);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__browse__run_command_6_0_i75);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__browse__send_term_to_socket_3_0),
		mercury__browse__run_command_6_0_i77,
		STATIC(mercury__browse__run_command_6_0));
Define_label(mercury__browse__run_command_6_0_i77);
	update_prof_current_proc(LABEL(mercury__browse__run_command_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__browse__run_command_6_0_i75);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module11)
	init_entry(mercury__browse__portray_4_0);
	init_label(mercury__browse__portray_4_0_i5);
	init_label(mercury__browse__portray_4_0_i6);
	init_label(mercury__browse__portray_4_0_i8);
	init_label(mercury__browse__portray_4_0_i10);
	init_label(mercury__browse__portray_4_0_i4);
	init_label(mercury__browse__portray_4_0_i12);
	init_label(mercury__browse__portray_4_0_i15);
	init_label(mercury__browse__portray_4_0_i17);
	init_label(mercury__browse__portray_4_0_i18);
	init_label(mercury__browse__portray_4_0_i3);
	init_label(mercury__browse__portray_4_0_i1008);
BEGIN_CODE

/* code for predicate 'portray'/4 in mode 0 */
Define_static(mercury__browse__portray_4_0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__browse__portray_4_0_i3);
	MR_incr_sp_push_msg(6, "browse:portray/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__portray_4_0_i5,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__portray_4_0_i6,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_4_0_i4);
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__deref_subterm_2_3_0),
		mercury__browse__portray_4_0_i8,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_4_0_i4);
	r1 = r2;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__term_to_string_4_0),
		mercury__browse__portray_4_0_i10,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_4_0_i12,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i4);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("error: no such subterm", 22);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_4_0_i12,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	r3 = r1;
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__portray_4_0_i15);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i15);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__portray_4_0_i17,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__portray_4_0_i18,
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i18);
	update_prof_current_proc(LABEL(mercury__browse__portray_4_0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i3);
	if (((Integer) r4 != (Integer) 1))
		GOTO_LABEL(mercury__browse__portray_4_0_i1008);
	tailcall(STATIC(mercury__browse__portray_pretty_4_0),
		STATIC(mercury__browse__portray_4_0));
Define_label(mercury__browse__portray_4_0_i1008);
	tailcall(STATIC(mercury__browse__portray_verbose_4_0),
		STATIC(mercury__browse__portray_4_0));
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(browse_module12)
	init_entry(mercury__browse__portray_path_5_0);
	init_label(mercury__browse__portray_path_5_0_i3);
	init_label(mercury__browse__portray_path_5_0_i4);
	init_label(mercury__browse__portray_path_5_0_i5);
BEGIN_CODE

/* code for predicate 'portray_path'/5 in mode 0 */
Define_static(mercury__browse__portray_path_5_0);
	MR_incr_sp_push_msg(9, "browse:portray_path/5");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__browse__portray_path_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__portray_path_5_0_i5,
		STATIC(mercury__browse__portray_path_5_0));
Define_label(mercury__browse__portray_path_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__browse__portray_path_5_0_i4,
		STATIC(mercury__browse__portray_path_5_0));
Define_label(mercury__browse__portray_path_5_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__portray_path_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__portray_path_5_0_i5,
		STATIC(mercury__browse__portray_path_5_0));
Define_label(mercury__browse__portray_path_5_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__portray_path_5_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__browse__portray_path_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__browse__portray_4_0),
		STATIC(mercury__browse__portray_path_5_0));
END_MODULE


BEGIN_MODULE(browse_module13)
	init_entry(mercury__browse__portray_verbose_4_0);
	init_label(mercury__browse__portray_verbose_4_0_i3);
	init_label(mercury__browse__portray_verbose_4_0_i4);
	init_label(mercury__browse__portray_verbose_4_0_i6);
	init_label(mercury__browse__portray_verbose_4_0_i8);
	init_label(mercury__browse__portray_verbose_4_0_i2);
	init_label(mercury__browse__portray_verbose_4_0_i10);
	init_label(mercury__browse__portray_verbose_4_0_i13);
	init_label(mercury__browse__portray_verbose_4_0_i15);
	init_label(mercury__browse__portray_verbose_4_0_i16);
BEGIN_CODE

/* code for predicate 'portray_verbose'/4 in mode 0 */
Define_static(mercury__browse__portray_verbose_4_0);
	MR_incr_sp_push_msg(8, "browse:portray_verbose/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__portray_verbose_4_0_i3,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__portray_verbose_4_0_i4,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_verbose_4_0_i2);
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__deref_subterm_2_3_0),
		mercury__browse__portray_verbose_4_0_i6,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_verbose_4_0_i2);
	r1 = r2;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(7);
	call_localret(STATIC(mercury__browse__term_to_string_verbose_6_0),
		mercury__browse__portray_verbose_4_0_i8,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_verbose_4_0_i10,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i2);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("error: no such subterm", 22);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_verbose_4_0_i10,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	r3 = r1;
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__portray_verbose_4_0_i13);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i13);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__portray_verbose_4_0_i15,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__portray_verbose_4_0_i16,
		STATIC(mercury__browse__portray_verbose_4_0));
Define_label(mercury__browse__portray_verbose_4_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__portray_verbose_4_0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__portray_verbose_4_0));
END_MODULE


BEGIN_MODULE(browse_module14)
	init_entry(mercury__browse__portray_pretty_4_0);
	init_label(mercury__browse__portray_pretty_4_0_i3);
	init_label(mercury__browse__portray_pretty_4_0_i4);
	init_label(mercury__browse__portray_pretty_4_0_i6);
	init_label(mercury__browse__portray_pretty_4_0_i8);
	init_label(mercury__browse__portray_pretty_4_0_i9);
	init_label(mercury__browse__portray_pretty_4_0_i2);
	init_label(mercury__browse__portray_pretty_4_0_i11);
	init_label(mercury__browse__portray_pretty_4_0_i14);
	init_label(mercury__browse__portray_pretty_4_0_i16);
	init_label(mercury__browse__portray_pretty_4_0_i17);
BEGIN_CODE

/* code for predicate 'portray_pretty'/4 in mode 0 */
Define_static(mercury__browse__portray_pretty_4_0);
	MR_incr_sp_push_msg(6, "browse:portray_pretty/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__portray_pretty_4_0_i3,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__portray_pretty_4_0_i4,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_pretty_4_0_i2);
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__deref_subterm_2_3_0),
		mercury__browse__portray_pretty_4_0_i6,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__portray_pretty_4_0_i2);
	r1 = r2;
	r2 = MR_stackvar(3);
	r3 = (Integer) 0;
	r4 = MR_stackvar(5);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__browse__term_to_string_pretty_2_7_0),
		mercury__browse__portray_pretty_4_0_i8,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	r1 = r2;
	call_localret(STATIC(mercury__browse__unlines_2_0),
		mercury__browse__portray_pretty_4_0_i9,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_pretty_4_0_i11,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i2);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("error: no such subterm", 22);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__portray_pretty_4_0_i11,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	r3 = r1;
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__portray_pretty_4_0_i14);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i14);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__portray_pretty_4_0_i16,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__portray_pretty_4_0_i17,
		STATIC(mercury__browse__portray_pretty_4_0));
Define_label(mercury__browse__portray_pretty_4_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__portray_pretty_4_0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__portray_pretty_4_0));
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(browse_module15)
	init_entry(mercury__browse__term_to_string_4_0);
	init_label(mercury__browse__term_to_string_4_0_i5);
	init_label(mercury__browse__term_to_string_4_0_i4);
	init_label(mercury__browse__term_to_string_4_0_i6);
	init_label(mercury__browse__term_to_string_4_0_i9);
	init_label(mercury__browse__term_to_string_4_0_i3);
	init_label(mercury__browse__term_to_string_4_0_i12);
	init_label(mercury__browse__term_to_string_4_0_i13);
	init_label(mercury__browse__term_to_string_4_0_i14);
	init_label(mercury__browse__term_to_string_4_0_i16);
	init_label(mercury__browse__term_to_string_4_0_i17);
	init_label(mercury__browse__term_to_string_4_0_i20);
BEGIN_CODE

/* code for predicate 'term_to_string'/4 in mode 0 */
Define_static(mercury__browse__term_to_string_4_0);
	MR_incr_sp_push_msg(5, "browse:term_to_string/4");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) 0 < (Integer) r2))
		GOTO_LABEL(mercury__browse__term_to_string_4_0_i5);
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__browse__term_to_string_4_0_i4);
Define_label(mercury__browse__term_to_string_4_0_i5);
	if (((Integer) 0 < (Integer) r3))
		GOTO_LABEL(mercury__browse__term_to_string_4_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(3) = r3;
Define_label(mercury__browse__term_to_string_4_0_i4);
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_4_0_i6,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__browse__term_to_string_4_0_i20);
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_4_0_i9,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__browse__term_to_string_4_0));
	}
Define_label(mercury__browse__term_to_string_4_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_4_0_i12,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = MR_stackvar(2);
	r3 = (Integer) 1;
	r4 = MR_stackvar(3);
	r5 = (Integer) 1;
	call_localret(STATIC(mercury__browse__term_to_string_list_7_0),
		mercury__browse__term_to_string_4_0_i13,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_4_0_i14);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_8);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i14);
	r1 = r2;
	call_localret(STATIC(mercury__browse__comma_args_2_0),
		mercury__browse__term_to_string_4_0_i16,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_9);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_4_0_i17,
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__browse__term_to_string_4_0));
Define_label(mercury__browse__term_to_string_4_0_i20);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module16)
	init_entry(mercury__browse__term_to_string_list_7_0);
	init_label(mercury__browse__term_to_string_list_7_0_i7);
	init_label(mercury__browse__term_to_string_list_7_0_i6);
	init_label(mercury__browse__term_to_string_list_7_0_i8);
	init_label(mercury__browse__term_to_string_list_7_0_i1003);
	init_label(mercury__browse__term_to_string_list_7_0_i9);
	init_label(mercury__browse__term_to_string_list_7_0_i11);
	init_label(mercury__browse__term_to_string_list_7_0_i5);
	init_label(mercury__browse__term_to_string_list_7_0_i14);
	init_label(mercury__browse__term_to_string_list_7_0_i15);
	init_label(mercury__browse__term_to_string_list_7_0_i16);
	init_label(mercury__browse__term_to_string_list_7_0_i18);
	init_label(mercury__browse__term_to_string_list_7_0_i19);
	init_label(mercury__browse__term_to_string_list_7_0_i23);
	init_label(mercury__browse__term_to_string_list_7_0_i3);
BEGIN_CODE

/* code for predicate 'term_to_string_list'/7 in mode 0 */
Define_static(mercury__browse__term_to_string_list_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i3);
	MR_incr_sp_push_msg(8, "browse:term_to_string_list/7");
	MR_stackvar(8) = (Word) MR_succip;
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 < (Integer) r2))
		GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i7);
	MR_stackvar(1) = r2;
	r2 = r7;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r6;
	GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i6);
Define_label(mercury__browse__term_to_string_list_7_0_i7);
	if (((Integer) r5 < (Integer) r4))
		GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i5);
	MR_stackvar(1) = r2;
	r2 = r7;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r6;
Define_label(mercury__browse__term_to_string_list_7_0_i6);
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_list_7_0_i8,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i9);
Define_label(mercury__browse__term_to_string_list_7_0_i1003);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	localcall(mercury__browse__term_to_string_list_7_0,
		LABEL(mercury__browse__term_to_string_list_7_0_i23),
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i9);
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_list_7_0_i11,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_list_7_0_i1003,
		STATIC(mercury__browse__term_to_string_list_7_0));
	}
Define_label(mercury__browse__term_to_string_list_7_0_i5);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	r2 = r7;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_list_7_0_i14,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	MR_stackvar(5) = r1;
	r1 = r3;
	r2 = MR_stackvar(1);
	r3 = ((Integer) MR_stackvar(2) + (Integer) 1);
	r4 = MR_stackvar(3);
	r5 = ((Integer) MR_stackvar(4) + (Integer) 1);
	localcall(mercury__browse__term_to_string_list_7_0,
		LABEL(mercury__browse__term_to_string_list_7_0_i15),
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_list_7_0_i16);
	MR_stackvar(2) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_8);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_list_7_0_i1003,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i16);
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__browse__comma_args_2_0),
		mercury__browse__term_to_string_list_7_0_i18,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i18);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_9);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_list_7_0_i19,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i19);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_list_7_0_i1003,
		STATIC(mercury__browse__term_to_string_list_7_0));
Define_label(mercury__browse__term_to_string_list_7_0_i23);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_list_7_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__browse__term_to_string_list_7_0_i3);
	r1 = r3;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(browse_module17)
	init_entry(mercury__browse__comma_args_2_0);
	init_label(mercury__browse__comma_args_2_0_i3);
	init_label(mercury__browse__comma_args_2_0_i5);
	init_label(mercury__browse__comma_args_2_0_i8);
	init_label(mercury__browse__comma_args_2_0_i9);
	init_label(mercury__browse__comma_args_2_0_i7);
BEGIN_CODE

/* code for predicate 'comma_args'/2 in mode 0 */
Define_static(mercury__browse__comma_args_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_args_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
Define_label(mercury__browse__comma_args_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_args_2_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	proceed();
Define_label(mercury__browse__comma_args_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_args_2_0_i7);
	MR_incr_sp_push_msg(3, "browse:comma_args/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	localcall(mercury__browse__comma_args_2_0,
		LABEL(mercury__browse__comma_args_2_0_i8),
		STATIC(mercury__browse__comma_args_2_0));
Define_label(mercury__browse__comma_args_2_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__comma_args_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__comma_args_2_0_i9,
		STATIC(mercury__browse__comma_args_2_0));
	}
Define_label(mercury__browse__comma_args_2_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__comma_args_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__browse__comma_args_2_0));
	}
Define_label(mercury__browse__comma_args_2_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__comma_args_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__browse__comma_args_2_0));
	}
END_MODULE

Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(browse_module18)
	init_entry(mercury__browse__term_to_string_pretty_2_7_0);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i5);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i4);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i6);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i7);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i9);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i10);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i3);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i12);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i14);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i13);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i16);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i17);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i18);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i19);
	init_label(mercury__browse__term_to_string_pretty_2_7_0_i20);
BEGIN_CODE

/* code for predicate 'term_to_string_pretty_2'/7 in mode 0 */
Define_static(mercury__browse__term_to_string_pretty_2_7_0);
	MR_incr_sp_push_msg(7, "browse:term_to_string_pretty_2/7");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r3 < (Integer) r2))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i5);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i4);
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i5);
	if (((Integer) r5 < (Integer) r4))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i3);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i4);
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_pretty_2_7_0_i6,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i7);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i7);
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_pretty_2_7_0_i9,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_pretty_2_7_0_i10,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
	}
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_pretty_2_7_0_i12,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r4 = ((Integer) MR_stackvar(5) + (Integer) 1);
	r5 = ((Integer) MR_stackvar(3) + (Integer) 1);
	if (((Integer) r2 < (Integer) 1))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i13);
	MR_stackvar(3) = r2;
	r2 = (Word) MR_string_const("(", 1);
	MR_stackvar(1) = r3;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__browse__term_to_string_pretty_2_7_0_i14,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	call_localret(STATIC(mercury__browse__term_to_string_pretty_list_7_0),
		mercury__browse__term_to_string_pretty_2_7_0_i16,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i13);
	MR_stackvar(3) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r3;
	r3 = r5;
	r5 = r4;
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__term_to_string_pretty_list_7_0),
		mercury__browse__term_to_string_pretty_2_7_0_i16,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__browse__term_to_string_pretty_2_7_0_i17,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_12);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__browse__term_to_string_pretty_2_7_0_i18,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i18);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__browse__term_to_string_pretty_2_7_0_i19,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i19);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	if (((Integer) MR_stackvar(3) < (Integer) 1))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_2_7_0_i20);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_9);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__browse__term_to_string_pretty_2_7_0_i20,
		STATIC(mercury__browse__term_to_string_pretty_2_7_0));
Define_label(mercury__browse__term_to_string_pretty_2_7_0_i20);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_2_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module19)
	init_entry(mercury__browse__term_to_string_pretty_list_7_0);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i3);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i6);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i5);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i7);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i8);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i11);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i12);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i13);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i10);
	init_label(mercury__browse__term_to_string_pretty_list_7_0_i14);
BEGIN_CODE

/* code for predicate 'term_to_string_pretty_list'/7 in mode 0 */
Define_static(mercury__browse__term_to_string_pretty_list_7_0);
	MR_incr_sp_push_msg(7, "browse:term_to_string_pretty_list/7");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_list_7_0_i3);
	r1 = r3;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_list_7_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__browse__term_to_string_pretty_2_7_0),
		mercury__browse__term_to_string_pretty_list_7_0_i6,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i5);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(STATIC(mercury__browse__term_to_string_pretty_2_7_0),
		mercury__browse__term_to_string_pretty_list_7_0_i7,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__browse__comma_last_2_0),
		mercury__browse__term_to_string_pretty_list_7_0_i8,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	if (((Integer) MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_pretty_list_7_0_i10);
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__term_to_string_pretty_2_7_0),
		mercury__browse__term_to_string_pretty_list_7_0_i11,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
	}
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__browse__comma_last_2_0),
		mercury__browse__term_to_string_pretty_list_7_0_i12,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	localcall(mercury__browse__term_to_string_pretty_list_7_0,
		LABEL(mercury__browse__term_to_string_pretty_list_7_0_i13),
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_list_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i10);
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__browse__term_to_string_pretty_2_7_0),
		mercury__browse__term_to_string_pretty_list_7_0_i14,
		STATIC(mercury__browse__term_to_string_pretty_list_7_0));
Define_label(mercury__browse__term_to_string_pretty_list_7_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_pretty_list_7_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_list_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_pretty_list_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE


BEGIN_MODULE(browse_module20)
	init_entry(mercury__browse__comma_last_2_0);
	init_label(mercury__browse__comma_last_2_0_i3);
	init_label(mercury__browse__comma_last_2_0_i6);
	init_label(mercury__browse__comma_last_2_0_i5);
	init_label(mercury__browse__comma_last_2_0_i9);
	init_label(mercury__browse__comma_last_2_0_i8);
	init_label(mercury__browse__comma_last_2_0_i10);
BEGIN_CODE

/* code for predicate 'comma_last'/2 in mode 0 */
Define_static(mercury__browse__comma_last_2_0);
	MR_incr_sp_push_msg(3, "browse:comma_last/2");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_last_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__comma_last_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_last_2_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const(",", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__browse__comma_last_2_0_i6,
		STATIC(mercury__browse__comma_last_2_0));
Define_label(mercury__browse__comma_last_2_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__comma_last_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_last_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__comma_last_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__comma_last_2_0_i8);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	localcall(mercury__browse__comma_last_2_0,
		LABEL(mercury__browse__comma_last_2_0_i9),
		STATIC(mercury__browse__comma_last_2_0));
Define_label(mercury__browse__comma_last_2_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__comma_last_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_last_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__comma_last_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__comma_last_2_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	r2 = (Word) MR_string_const(",", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__browse__comma_last_2_0_i10,
		STATIC(mercury__browse__comma_last_2_0));
Define_label(mercury__browse__comma_last_2_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__comma_last_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__comma_last_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__comma_last_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module21)
	init_entry(mercury__browse__indent_2_0);
BEGIN_CODE

/* code for predicate 'indent'/2 in mode 0 */
Define_static(mercury__browse__indent_2_0);
	r2 = r1;
	r1 = (Word) MR_string_const("  ", 2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__browse__indent_2_0));
END_MODULE


BEGIN_MODULE(browse_module22)
	init_entry(mercury__browse__unlines_2_0);
	init_label(mercury__browse__unlines_2_0_i4);
	init_label(mercury__browse__unlines_2_0_i5);
	init_label(mercury__browse__unlines_2_0_i3);
BEGIN_CODE

/* code for predicate 'unlines'/2 in mode 0 */
Define_static(mercury__browse__unlines_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__unlines_2_0_i3);
	MR_incr_sp_push_msg(2, "browse:unlines/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__browse__unlines_2_0_i4,
		STATIC(mercury__browse__unlines_2_0));
Define_label(mercury__browse__unlines_2_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__unlines_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__browse__unlines_2_0,
		LABEL(mercury__browse__unlines_2_0_i5),
		STATIC(mercury__browse__unlines_2_0));
Define_label(mercury__browse__unlines_2_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__unlines_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__browse__unlines_2_0));
Define_label(mercury__browse__unlines_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury__frame__clip_3_0);
Declare_entry(mercury__frame__vglue_3_0);

BEGIN_MODULE(browse_module23)
	init_entry(mercury__browse__term_to_string_verbose_6_0);
	init_label(mercury__browse__term_to_string_verbose_6_0_i5);
	init_label(mercury__browse__term_to_string_verbose_6_0_i4);
	init_label(mercury__browse__term_to_string_verbose_6_0_i6);
	init_label(mercury__browse__term_to_string_verbose_6_0_i1012);
	init_label(mercury__browse__term_to_string_verbose_6_0_i7);
	init_label(mercury__browse__term_to_string_verbose_6_0_i9);
	init_label(mercury__browse__term_to_string_verbose_6_0_i3);
	init_label(mercury__browse__term_to_string_verbose_6_0_i12);
	init_label(mercury__browse__term_to_string_verbose_6_0_i1017);
	init_label(mercury__browse__term_to_string_verbose_6_0_i14);
	init_label(mercury__browse__term_to_string_verbose_6_0_i16);
BEGIN_CODE

/* code for predicate 'term_to_string_verbose'/6 in mode 0 */
Define_static(mercury__browse__term_to_string_verbose_6_0);
	MR_incr_sp_push_msg(7, "browse:term_to_string_verbose/6");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) 0 < (Integer) r2))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_6_0_i5);
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__browse__term_to_string_verbose_6_0_i4);
Define_label(mercury__browse__term_to_string_verbose_6_0_i5);
	if (((Integer) 0 < (Integer) r3))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_6_0_i3);
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(3) = r3;
Define_label(mercury__browse__term_to_string_verbose_6_0_i4);
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_verbose_6_0_i6,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_6_0_i7);
Define_label(mercury__browse__term_to_string_verbose_6_0_i1012);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	call_localret(ENTRY(mercury__frame__clip_3_0),
		mercury__browse__term_to_string_verbose_6_0_i16,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i7);
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_verbose_6_0_i9,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_verbose_6_0_i1012,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
	}
Define_label(mercury__browse__term_to_string_verbose_6_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_verbose_6_0_i12,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = (Integer) 1;
	r3 = MR_stackvar(2);
	r4 = (Integer) 1;
	r5 = MR_stackvar(3);
	r6 = (Integer) 1;
	call_localret(STATIC(mercury__browse__term_to_string_verbose_list_8_0),
		mercury__browse__term_to_string_verbose_6_0_i1017,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i1017);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__frame__vglue_3_0),
		mercury__browse__term_to_string_verbose_6_0_i14,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__browse__term_to_string_verbose_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	call_localret(ENTRY(mercury__frame__clip_3_0),
		mercury__browse__term_to_string_verbose_6_0_i16,
		STATIC(mercury__browse__term_to_string_verbose_6_0));
Define_label(mercury__browse__term_to_string_verbose_6_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_6_0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__browse__unlines_2_0),
		STATIC(mercury__browse__term_to_string_verbose_6_0));
END_MODULE


BEGIN_MODULE(browse_module24)
	init_entry(mercury__browse__term_to_string_verbose_2_7_0);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i5);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i4);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i6);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i7);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i9);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i10);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i3);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i12);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i13);
	init_label(mercury__browse__term_to_string_verbose_2_7_0_i14);
BEGIN_CODE

/* code for predicate 'term_to_string_verbose_2'/7 in mode 0 */
Define_static(mercury__browse__term_to_string_verbose_2_7_0);
	MR_incr_sp_push_msg(7, "browse:term_to_string_verbose_2/7");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r3 < (Integer) r2))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_2_7_0_i5);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	GOTO_LABEL(mercury__browse__term_to_string_verbose_2_7_0_i4);
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i5);
	if (((Integer) r5 < (Integer) r4))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_2_7_0_i3);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i4);
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_verbose_2_7_0_i6,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_2_7_0_i7);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i7);
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_verbose_2_7_0_i9,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_verbose_2_7_0_i10,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
	}
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__term_to_string_verbose_2_7_0_i12,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = (Integer) 1;
	r3 = MR_stackvar(2);
	r4 = ((Integer) MR_stackvar(3) + (Integer) 1);
	r5 = MR_stackvar(4);
	r6 = ((Integer) MR_stackvar(5) + (Integer) 1);
	call_localret(STATIC(mercury__browse__term_to_string_verbose_list_8_0),
		mercury__browse__term_to_string_verbose_2_7_0_i13,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__frame__vglue_3_0),
		mercury__browse__term_to_string_verbose_2_7_0_i14,
		STATIC(mercury__browse__term_to_string_verbose_2_7_0));
Define_label(mercury__browse__term_to_string_verbose_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_2_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__frame__vsize_2_0);
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__frame__hglue_3_0);

BEGIN_MODULE(browse_module25)
	init_entry(mercury__browse__term_to_string_verbose_list_8_0);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i3);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i6);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i7);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i8);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i9);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i10);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i11);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i12);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i13);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i5);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i15);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i16);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i17);
	init_label(mercury__browse__term_to_string_verbose_list_8_0_i18);
BEGIN_CODE

/* code for predicate 'term_to_string_verbose_list'/8 in mode 0 */
Define_static(mercury__browse__term_to_string_verbose_list_8_0);
	MR_incr_sp_push_msg(6, "browse:term_to_string_verbose_list/8");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_list_8_0_i3);
	r1 = r4;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__term_to_string_verbose_list_8_0_i5);
	MR_stackvar(1) = r2;
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	r4 = r5;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r6;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__browse__term_to_string_verbose_2_7_0),
		mercury__browse__term_to_string_verbose_list_8_0_i6,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r3 = MR_stackvar(2);
	r4 = r1;
	MR_stackvar(2) = r2;
	r1 = MR_stackvar(5);
	r2 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	localcall(mercury__browse__term_to_string_verbose_list_8_0,
		LABEL(mercury__browse__term_to_string_verbose_list_8_0_i7),
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_verbose_list_8_0_i8,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_list_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_13);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_verbose_list_8_0_i9,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__frame__vsize_2_0),
		mercury__browse__term_to_string_verbose_list_8_0_i10,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = ((Integer) r1 + (Integer) -1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_string_const("|", 1);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__browse__term_to_string_verbose_list_8_0_i11,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_list_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__frame__vglue_3_0),
		mercury__browse__term_to_string_verbose_list_8_0_i12,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i12);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__frame__hglue_3_0),
		mercury__browse__term_to_string_verbose_list_8_0_i13,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__frame__vglue_3_0),
		mercury__browse__term_to_string_verbose_list_8_0_i18,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i5);
	MR_stackvar(1) = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r6;
	call_localret(STATIC(mercury__browse__term_to_string_verbose_2_7_0),
		mercury__browse__term_to_string_verbose_list_8_0_i15,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__browse__term_to_string_verbose_list_8_0_i16,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_list_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_13);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__browse__term_to_string_verbose_list_8_0_i17,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__term_to_string_verbose_list_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__frame__hglue_3_0),
		mercury__browse__term_to_string_verbose_list_8_0_i18,
		STATIC(mercury__browse__term_to_string_verbose_list_8_0));
Define_label(mercury__browse__term_to_string_verbose_list_8_0_i18);
	update_prof_current_proc(LABEL(mercury__browse__term_to_string_verbose_list_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_int_3_0);

BEGIN_MODULE(browse_module26)
	init_entry(mercury__browse__write_path_4_0);
	init_label(mercury__browse__write_path_4_0_i3);
	init_label(mercury__browse__write_path_4_0_i8);
	init_label(mercury__browse__write_path_4_0_i10);
	init_label(mercury__browse__write_path_4_0_i12);
	init_label(mercury__browse__write_path_4_0_i14);
	init_label(mercury__browse__write_path_4_0_i15);
	init_label(mercury__browse__write_path_4_0_i1009);
BEGIN_CODE

/* code for predicate 'write_path'/4 in mode 0 */
Define_static(mercury__browse__write_path_4_0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_4_0_i3);
	r2 = (Word) MR_string_const("/", 1);
	tailcall(STATIC(mercury__browse__write_string_debugger_4_0),
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_4_0_i1009);
	MR_incr_sp_push_msg(3, "browse:write_path/4");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_4_0_i8);
	r2 = (Word) MR_string_const("/", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__browse__write_string_debugger_4_0),
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i8);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r2 = (Word) MR_string_const("/", 1);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__write_path_4_0_i10,
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__write_path_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__write_path_4_0_i12);
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i12);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__write_path_4_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__write_path_4_0_i14,
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__write_path_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__write_path_4_0_i15,
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__write_path_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__write_path_4_0));
Define_label(mercury__browse__write_path_4_0_i1009);
	tailcall(STATIC(mercury__browse__write_path_2_4_0),
		STATIC(mercury__browse__write_path_4_0));
END_MODULE


BEGIN_MODULE(browse_module27)
	init_entry(mercury__browse__write_path_2_4_0);
	init_label(mercury__browse__write_path_2_4_0_i1006);
	init_label(mercury__browse__write_path_2_4_0_i3);
	init_label(mercury__browse__write_path_2_4_0_i8);
	init_label(mercury__browse__write_path_2_4_0_i11);
	init_label(mercury__browse__write_path_2_4_0_i13);
	init_label(mercury__browse__write_path_2_4_0_i15);
	init_label(mercury__browse__write_path_2_4_0_i16);
	init_label(mercury__browse__write_path_2_4_0_i17);
	init_label(mercury__browse__write_path_2_4_0_i6);
	init_label(mercury__browse__write_path_2_4_0_i20);
	init_label(mercury__browse__write_path_2_4_0_i22);
	init_label(mercury__browse__write_path_2_4_0_i24);
	init_label(mercury__browse__write_path_2_4_0_i26);
	init_label(mercury__browse__write_path_2_4_0_i27);
BEGIN_CODE

/* code for predicate 'write_path_2'/4 in mode 0 */
Define_static(mercury__browse__write_path_2_4_0);
	MR_incr_sp_push_msg(4, "browse:write_path_2/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__browse__write_path_2_4_0_i1006);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i3);
	r2 = (Word) MR_string_const("/", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__browse__write_string_debugger_4_0),
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i8);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = (Word) MR_string_const("/..", 3);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__write_path_2_4_0_i17,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i8);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = (Word) MR_string_const("/", 1);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__write_path_2_4_0_i11,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i13);
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__browse__write_path_2_4_0_i17,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i13);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__write_path_2_4_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__write_path_2_4_0_i15,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__write_path_2_4_0_i16,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__write_path_2_4_0_i17,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__browse__write_path_2_4_0_i1006);
Define_label(mercury__browse__write_path_2_4_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i20);
	r2 = (Word) MR_string_const("/..", 3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__browse__write_string_debugger_4_0),
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i20);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r2 = (Word) MR_string_const("/", 1);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__write_path_2_4_0_i22,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i22);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__write_path_2_4_0_i24);
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i24);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__write_path_2_4_0, "browse:term_browser_response/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__write_path_2_4_0_i26,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i26);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__write_path_2_4_0_i27,
		STATIC(mercury__browse__write_path_2_4_0));
Define_label(mercury__browse__write_path_2_4_0_i27);
	update_prof_current_proc(LABEL(mercury__browse__write_path_2_4_0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__write_path_2_4_0));
END_MODULE


BEGIN_MODULE(browse_module28)
	init_entry(mercury__browse__deref_subterm_3_0);
	init_label(mercury__browse__deref_subterm_3_0_i2);
	init_label(mercury__browse__deref_subterm_3_0_i3);
	init_label(mercury__browse__deref_subterm_3_0_i1);
BEGIN_CODE

/* code for predicate 'deref_subterm'/3 in mode 0 */
Define_static(mercury__browse__deref_subterm_3_0);
	MR_incr_sp_push_msg(2, "browse:deref_subterm/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__deref_subterm_3_0_i2,
		STATIC(mercury__browse__deref_subterm_3_0));
Define_label(mercury__browse__deref_subterm_3_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__deref_subterm_3_0));
	call_localret(STATIC(mercury__browse__dirs_to_ints_2_0),
		mercury__browse__deref_subterm_3_0_i3,
		STATIC(mercury__browse__deref_subterm_3_0));
Define_label(mercury__browse__deref_subterm_3_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__deref_subterm_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__deref_subterm_3_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__browse__deref_subterm_2_3_0),
		STATIC(mercury__browse__deref_subterm_3_0));
Define_label(mercury__browse__deref_subterm_3_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(browse_module29)
	init_entry(mercury__browse__dirs_to_ints_2_0);
	init_label(mercury__browse__dirs_to_ints_2_0_i3);
	init_label(mercury__browse__dirs_to_ints_2_0_i6);
	init_label(mercury__browse__dirs_to_ints_2_0_i5);
	init_label(mercury__browse__dirs_to_ints_2_0_i7);
	init_label(mercury__browse__dirs_to_ints_2_0_i1);
BEGIN_CODE

/* code for predicate 'dirs_to_ints'/2 in mode 0 */
Define_static(mercury__browse__dirs_to_ints_2_0);
	MR_incr_sp_push_msg(2, "browse:dirs_to_ints/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__dirs_to_ints_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__browse__dirs_to_ints_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__dirs_to_ints_2_0_i5);
	r1 = (Word) MR_string_const("dirs_to_ints: software error", 28);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__browse__dirs_to_ints_2_0_i6,
		STATIC(mercury__browse__dirs_to_ints_2_0));
Define_label(mercury__browse__dirs_to_ints_2_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__dirs_to_ints_2_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__browse__dirs_to_ints_2_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__browse__dirs_to_ints_2_0,
		LABEL(mercury__browse__dirs_to_ints_2_0_i7),
		STATIC(mercury__browse__dirs_to_ints_2_0));
Define_label(mercury__browse__dirs_to_ints_2_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__dirs_to_ints_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__dirs_to_ints_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__browse__dirs_to_ints_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__browse__dirs_to_ints_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__index1_3_0);

BEGIN_MODULE(browse_module30)
	init_entry(mercury__browse__deref_subterm_2_3_0);
	init_label(mercury__browse__deref_subterm_2_3_0_i1003);
	init_label(mercury__browse__deref_subterm_2_3_0_i2);
	init_label(mercury__browse__deref_subterm_2_3_0_i5);
	init_label(mercury__browse__deref_subterm_2_3_0_i6);
	init_label(mercury__browse__deref_subterm_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'deref_subterm_2'/3 in mode 0 */
Define_static(mercury__browse__deref_subterm_2_3_0);
	MR_incr_sp_push_msg(3, "browse:deref_subterm_2/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__browse__deref_subterm_2_3_0_i1003);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__deref_subterm_2_3_0_i2);
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__deref_subterm_2_3_0_i2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__deref_subterm_2_3_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	call_localret(ENTRY(mercury__std_util__deconstruct_4_0),
		mercury__browse__deref_subterm_2_3_0_i5,
		STATIC(mercury__browse__deref_subterm_2_3_0));
Define_label(mercury__browse__deref_subterm_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__deref_subterm_2_3_0));
	r2 = r3;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__index1_3_0),
		mercury__browse__deref_subterm_2_3_0_i6,
		STATIC(mercury__browse__deref_subterm_2_3_0));
Define_label(mercury__browse__deref_subterm_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__deref_subterm_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__browse__deref_subterm_2_3_0_i1);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__browse__deref_subterm_2_3_0_i1003);
Define_label(mercury__browse__deref_subterm_2_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module31)
	init_entry(mercury__browse__get_term_2_0);
BEGIN_CODE

/* code for predicate 'get_term'/2 in mode 0 */
Define_static(mercury__browse__get_term_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module32)
	init_entry(mercury__browse__get_dirs_2_0);
BEGIN_CODE

/* code for predicate 'get_dirs'/2 in mode 0 */
Define_static(mercury__browse__get_dirs_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module33)
	init_entry(mercury__browse__set_path_3_0);
	init_label(mercury__browse__set_path_3_0_i3);
	init_label(mercury__browse__set_path_3_0_i4);
	init_label(mercury__browse__set_path_3_0_i5);
BEGIN_CODE

/* code for predicate 'set_path'/3 in mode 0 */
Define_static(mercury__browse__set_path_3_0);
	MR_incr_sp_push_msg(7, "browse:set_path/3");
	MR_stackvar(7) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__browse__set_path_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__set_path_3_0_i5,
		STATIC(mercury__browse__set_path_3_0));
Define_label(mercury__browse__set_path_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__browse__set_path_3_0_i4,
		STATIC(mercury__browse__set_path_3_0));
Define_label(mercury__browse__set_path_3_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__set_path_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	call_localret(ENTRY(mercury__util__limit_3_0),
		mercury__browse__set_path_3_0_i5,
		STATIC(mercury__browse__set_path_3_0));
Define_label(mercury__browse__set_path_3_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__set_path_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__browse__set_path_3_0, "browse:browser_state/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module34)
	init_entry(mercury__browse__change_dir_3_0);
	init_label(mercury__browse__change_dir_3_0_i3);
	init_label(mercury__browse__change_dir_3_0_i4);
BEGIN_CODE

/* code for predicate 'change_dir'/3 in mode 0 */
Define_static(mercury__browse__change_dir_3_0);
	MR_incr_sp_push_msg(1, "browse:change_dir/3");
	MR_stackvar(1) = (Word) MR_succip;
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__browse__change_dir_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__util__limit_3_0),
		STATIC(mercury__browse__change_dir_3_0));
Define_label(mercury__browse__change_dir_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__browse__change_dir_3_0_i4,
		STATIC(mercury__browse__change_dir_3_0));
Define_label(mercury__browse__change_dir_3_0_i4);
	update_prof_current_proc(LABEL(mercury__browse__change_dir_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_browse__common_2);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__util__limit_3_0),
		STATIC(mercury__browse__change_dir_3_0));
END_MODULE


BEGIN_MODULE(browse_module35)
	init_entry(mercury__browse__set_fmt_3_0);
BEGIN_CODE

/* code for predicate 'set_fmt'/3 in mode 0 */
Define_static(mercury__browse__set_fmt_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__browse__set_fmt_3_0, "browse:browser_state/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module36)
	init_entry(mercury__browse__show_settings_4_0);
	init_label(mercury__browse__show_settings_4_0_i2);
	init_label(mercury__browse__show_settings_4_0_i5);
	init_label(mercury__browse__show_settings_4_0_i6);
	init_label(mercury__browse__show_settings_4_0_i7);
	init_label(mercury__browse__show_settings_4_0_i8);
	init_label(mercury__browse__show_settings_4_0_i9);
	init_label(mercury__browse__show_settings_4_0_i10);
	init_label(mercury__browse__show_settings_4_0_i11);
	init_label(mercury__browse__show_settings_4_0_i4);
	init_label(mercury__browse__show_settings_4_0_i13);
	init_label(mercury__browse__show_settings_4_0_i14);
	init_label(mercury__browse__show_settings_4_0_i15);
	init_label(mercury__browse__show_settings_4_0_i16);
	init_label(mercury__browse__show_settings_4_0_i17);
	init_label(mercury__browse__show_settings_4_0_i18);
	init_label(mercury__browse__show_settings_4_0_i19);
	init_label(mercury__browse__show_settings_4_0_i20);
	init_label(mercury__browse__show_settings_4_0_i21);
	init_label(mercury__browse__show_settings_4_0_i22);
	init_label(mercury__browse__show_settings_4_0_i23);
	init_label(mercury__browse__show_settings_4_0_i24);
	init_label(mercury__browse__show_settings_4_0_i25);
	init_label(mercury__browse__show_settings_4_0_i26);
	init_label(mercury__browse__show_settings_4_0_i27);
	init_label(mercury__browse__show_settings_4_0_i28);
	init_label(mercury__browse__show_settings_4_0_i29);
	init_label(mercury__browse__show_settings_4_0_i30);
	init_label(mercury__browse__show_settings_4_0_i31);
	init_label(mercury__browse__show_settings_4_0_i32);
	init_label(mercury__browse__show_settings_4_0_i33);
	init_label(mercury__browse__show_settings_4_0_i34);
	init_label(mercury__browse__show_settings_4_0_i35);
	init_label(mercury__browse__show_settings_4_0_i36);
	init_label(mercury__browse__show_settings_4_0_i37);
	init_label(mercury__browse__show_settings_4_0_i38);
	init_label(mercury__browse__show_settings_4_0_i39);
	init_label(mercury__browse__show_settings_4_0_i40);
	init_label(mercury__browse__show_settings_4_0_i41);
	init_label(mercury__browse__show_settings_4_0_i42);
	init_label(mercury__browse__show_settings_4_0_i43);
	init_label(mercury__browse__show_settings_4_0_i44);
BEGIN_CODE

/* code for predicate 'show_settings'/4 in mode 0 */
Define_static(mercury__browse__show_settings_4_0);
	MR_incr_sp_push_msg(8, "browse:show_settings/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = (Word) MR_string_const("Max depth is: ", 14);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__show_settings_4_0_i2,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__browse__show_settings_4_0_i4);
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__browse__show_settings_4_0_i5,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__browse__show_settings_4_0_i6,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Max size is: ", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__browse__show_settings_4_0_i7,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i7);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__browse__show_settings_4_0_i8,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i8);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__browse__show_settings_4_0_i9,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i9);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("X clip is: ", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__browse__show_settings_4_0_i10,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i10);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__browse__show_settings_4_0_i11,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i11);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__browse__show_settings_4_0_i36,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__show_settings_4_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i13,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i13);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i14,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i15,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i16,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i17,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i17);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i18,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i18);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_14);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i19,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i19);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i20,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i20);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i21,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i21);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__show_settings_4_0, "browse:term_browser_response/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i22,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i22);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i23,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i23);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i24,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i24);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i25,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i25);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i26,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i26);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i27,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i27);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_15);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i28,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i28);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i29,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i29);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i30,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i30);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__browse__show_settings_4_0, "browse:term_browser_response/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i31,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i31);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i32,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i32);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i33,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i33);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__show_settings_4_0_i34,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i34);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__show_settings_4_0_i35,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i35);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__browse__show_settings_4_0_i36,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i36);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("Y clip is: ", 11);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__show_settings_4_0_i37,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i37);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__browse__write_int_debugger_4_0),
		mercury__browse__show_settings_4_0_i38,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i38);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__nl_debugger_3_0),
		mercury__browse__show_settings_4_0_i39,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i39);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("Current path is: ", 17);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__show_settings_4_0_i40,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i40);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__browse__write_path_4_0),
		mercury__browse__show_settings_4_0_i41,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i41);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__browse__nl_debugger_3_0),
		mercury__browse__show_settings_4_0_i42,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i42);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("Print format is ", 16);
	call_localret(STATIC(mercury__browse__write_string_debugger_4_0),
		mercury__browse__show_settings_4_0_i43,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i43);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__browse__print_format_debugger_4_0),
		mercury__browse__show_settings_4_0_i44,
		STATIC(mercury__browse__show_settings_4_0));
Define_label(mercury__browse__show_settings_4_0_i44);
	update_prof_current_proc(LABEL(mercury__browse__show_settings_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__browse__nl_debugger_3_0),
		STATIC(mercury__browse__show_settings_4_0));
END_MODULE


BEGIN_MODULE(browse_module37)
	init_entry(mercury__browse__simplify_2_0);
	init_label(mercury__browse__simplify_2_0_i3);
	init_label(mercury__browse__simplify_2_0_i5);
	init_label(mercury__browse__simplify_2_0_i7);
	init_label(mercury__browse__simplify_2_0_i9);
	init_label(mercury__browse__simplify_2_0_i11);
	init_label(mercury__browse__simplify_2_0_i13);
	init_label(mercury__browse__simplify_2_0_i16);
	init_label(mercury__browse__simplify_2_0_i15);
BEGIN_CODE

/* code for predicate 'simplify'/2 in mode 0 */
Define_static(mercury__browse__simplify_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__browse__simplify_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	proceed();
Define_label(mercury__browse__simplify_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__browse__simplify_2_0_i7);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i9);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1);
	proceed();
Define_label(mercury__browse__simplify_2_0_i9);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1);
	proceed();
Define_label(mercury__browse__simplify_2_0_i11);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i13);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	proceed();
Define_label(mercury__browse__simplify_2_0_i13);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1), (Integer) 0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__browse__simplify_2_0_i15);
	MR_incr_sp_push_msg(3, "browse:simplify/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	localcall(mercury__browse__simplify_2_0,
		LABEL(mercury__browse__simplify_2_0_i16),
		STATIC(mercury__browse__simplify_2_0));
Define_label(mercury__browse__simplify_2_0_i16);
	update_prof_current_proc(LABEL(mercury__browse__simplify_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__browse__simplify_2_0_i15);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__browse__simplify_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1), (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module38)
	init_entry(mercury__browse__write_string_debugger_4_0);
	init_label(mercury__browse__write_string_debugger_4_0_i3);
	init_label(mercury__browse__write_string_debugger_4_0_i5);
	init_label(mercury__browse__write_string_debugger_4_0_i6);
BEGIN_CODE

/* code for predicate 'write_string_debugger'/4 in mode 0 */
Define_static(mercury__browse__write_string_debugger_4_0);
	MR_incr_sp_push_msg(1, "browse:write_string_debugger/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__write_string_debugger_4_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__browse__write_string_debugger_4_0));
Define_label(mercury__browse__write_string_debugger_4_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__browse__write_string_debugger_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__write_string_debugger_4_0_i5,
		STATIC(mercury__browse__write_string_debugger_4_0));
	}
Define_label(mercury__browse__write_string_debugger_4_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__write_string_debugger_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__write_string_debugger_4_0_i6,
		STATIC(mercury__browse__write_string_debugger_4_0));
Define_label(mercury__browse__write_string_debugger_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__write_string_debugger_4_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__write_string_debugger_4_0));
END_MODULE


BEGIN_MODULE(browse_module39)
	init_entry(mercury__browse__nl_debugger_3_0);
	init_label(mercury__browse__nl_debugger_3_0_i3);
	init_label(mercury__browse__nl_debugger_3_0_i5);
	init_label(mercury__browse__nl_debugger_3_0_i6);
BEGIN_CODE

/* code for predicate 'nl_debugger'/3 in mode 0 */
Define_static(mercury__browse__nl_debugger_3_0);
	MR_incr_sp_push_msg(1, "browse:nl_debugger/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__nl_debugger_3_0_i3);
	r1 = r2;
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__browse__nl_debugger_3_0));
Define_label(mercury__browse__nl_debugger_3_0_i3);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__nl_debugger_3_0_i5,
		STATIC(mercury__browse__nl_debugger_3_0));
Define_label(mercury__browse__nl_debugger_3_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__nl_debugger_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__nl_debugger_3_0_i6,
		STATIC(mercury__browse__nl_debugger_3_0));
Define_label(mercury__browse__nl_debugger_3_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__nl_debugger_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__nl_debugger_3_0));
END_MODULE


BEGIN_MODULE(browse_module40)
	init_entry(mercury__browse__write_int_debugger_4_0);
	init_label(mercury__browse__write_int_debugger_4_0_i3);
	init_label(mercury__browse__write_int_debugger_4_0_i5);
	init_label(mercury__browse__write_int_debugger_4_0_i6);
BEGIN_CODE

/* code for predicate 'write_int_debugger'/4 in mode 0 */
Define_static(mercury__browse__write_int_debugger_4_0);
	MR_incr_sp_push_msg(1, "browse:write_int_debugger/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__write_int_debugger_4_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__browse__write_int_debugger_4_0));
Define_label(mercury__browse__write_int_debugger_4_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__browse__write_int_debugger_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__write_int_debugger_4_0_i5,
		STATIC(mercury__browse__write_int_debugger_4_0));
	}
Define_label(mercury__browse__write_int_debugger_4_0_i5);
	update_prof_current_proc(LABEL(mercury__browse__write_int_debugger_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__write_int_debugger_4_0_i6,
		STATIC(mercury__browse__write_int_debugger_4_0));
Define_label(mercury__browse__write_int_debugger_4_0_i6);
	update_prof_current_proc(LABEL(mercury__browse__write_int_debugger_4_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__write_int_debugger_4_0));
END_MODULE


BEGIN_MODULE(browse_module41)
	init_entry(mercury__browse__print_format_debugger_4_0);
	init_label(mercury__browse__print_format_debugger_4_0_i3);
	init_label(mercury__browse__print_format_debugger_4_0_i6);
	init_label(mercury__browse__print_format_debugger_4_0_i10);
	init_label(mercury__browse__print_format_debugger_4_0_i14);
	init_label(mercury__browse__print_format_debugger_4_0_i15);
BEGIN_CODE

/* code for predicate 'print_format_debugger'/4 in mode 0 */
Define_static(mercury__browse__print_format_debugger_4_0);
	MR_incr_sp_push_msg(1, "browse:print_format_debugger/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__browse__print_format_debugger_4_0_i3);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_portray_format_0;
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__print_3_0),
		STATIC(mercury__browse__print_format_debugger_4_0));
Define_label(mercury__browse__print_format_debugger_4_0_i3);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__browse__print_format_debugger_4_0_i6);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_16);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_format_debugger_4_0_i14,
		STATIC(mercury__browse__print_format_debugger_4_0));
Define_label(mercury__browse__print_format_debugger_4_0_i6);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__browse__print_format_debugger_4_0_i10);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_17);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_format_debugger_4_0_i14,
		STATIC(mercury__browse__print_format_debugger_4_0));
Define_label(mercury__browse__print_format_debugger_4_0_i10);
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_browse__common_18);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__print_format_debugger_4_0_i14,
		STATIC(mercury__browse__print_format_debugger_4_0));
Define_label(mercury__browse__print_format_debugger_4_0_i14);
	update_prof_current_proc(LABEL(mercury__browse__print_format_debugger_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__print_format_debugger_4_0_i15,
		STATIC(mercury__browse__print_format_debugger_4_0));
Define_label(mercury__browse__print_format_debugger_4_0_i15);
	update_prof_current_proc(LABEL(mercury__browse__print_format_debugger_4_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__print_format_debugger_4_0));
END_MODULE


BEGIN_MODULE(browse_module42)
	init_entry(mercury__browse__send_term_to_socket_3_0);
	init_label(mercury__browse__send_term_to_socket_3_0_i2);
	init_label(mercury__browse__send_term_to_socket_3_0_i3);
BEGIN_CODE

/* code for predicate 'send_term_to_socket'/3 in mode 0 */
Define_static(mercury__browse__send_term_to_socket_3_0);
	MR_incr_sp_push_msg(1, "browse:send_term_to_socket/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_browse__type_ctor_info_term_browser_response_0;
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__browse__send_term_to_socket_3_0_i2,
		STATIC(mercury__browse__send_term_to_socket_3_0));
Define_label(mercury__browse__send_term_to_socket_3_0_i2);
	update_prof_current_proc(LABEL(mercury__browse__send_term_to_socket_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__browse__send_term_to_socket_3_0_i3,
		STATIC(mercury__browse__send_term_to_socket_3_0));
Define_label(mercury__browse__send_term_to_socket_3_0_i3);
	update_prof_current_proc(LABEL(mercury__browse__send_term_to_socket_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		STATIC(mercury__browse__send_term_to_socket_3_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__univ_0_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(browse_module43)
	init_entry(mercury____Unify___browse__browser_state_0_0);
	init_label(mercury____Unify___browse__browser_state_0_0_i2);
	init_label(mercury____Unify___browse__browser_state_0_0_i4);
	init_label(mercury____Unify___browse__browser_state_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___browse__browser_state_0_0);
	MR_incr_sp_push_msg(13, "browse:__Unify__/2");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___std_util__univ_0_0),
		mercury____Unify___browse__browser_state_0_0_i2,
		ENTRY(mercury____Unify___browse__browser_state_0_0));
Define_label(mercury____Unify___browse__browser_state_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___browse__browser_state_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(7)))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(8)))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___browse__browser_state_0_0_i4,
		ENTRY(mercury____Unify___browse__browser_state_0_0));
Define_label(mercury____Unify___browse__browser_state_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___browse__browser_state_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	if ((MR_stackvar(4) != MR_stackvar(10)))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(11)))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	if ((MR_stackvar(6) != MR_stackvar(12)))
		GOTO_LABEL(mercury____Unify___browse__browser_state_0_0_i1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__browser_state_0_0_i1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(browse_module44)
	init_entry(mercury____Index___browse__browser_state_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___browse__browser_state_0_0);
	tailcall(STATIC(mercury____Index___browse__browser_state_0__ua0_2_0),
		ENTRY(mercury____Index___browse__browser_state_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__univ_0_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(browse_module45)
	init_entry(mercury____Compare___browse__browser_state_0_0);
	init_label(mercury____Compare___browse__browser_state_0_0_i3);
	init_label(mercury____Compare___browse__browser_state_0_0_i7);
	init_label(mercury____Compare___browse__browser_state_0_0_i11);
	init_label(mercury____Compare___browse__browser_state_0_0_i15);
	init_label(mercury____Compare___browse__browser_state_0_0_i19);
	init_label(mercury____Compare___browse__browser_state_0_0_i23);
	init_label(mercury____Compare___browse__browser_state_0_0_i32);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___browse__browser_state_0_0);
	MR_incr_sp_push_msg(13, "browse:__Compare__/3");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___std_util__univ_0_0),
		mercury____Compare___browse__browser_state_0_0_i3,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___browse__browser_state_0_0_i7,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___browse__browser_state_0_0_i11,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___browse__browser_state_0_0_i15,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___browse__browser_state_0_0_i19,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___browse__browser_state_0_0_i23,
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___browse__browser_state_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__browser_state_0_0_i32);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___browse__browser_state_0_0));
Define_label(mercury____Compare___browse__browser_state_0_0_i32);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module46)
	init_entry(mercury____Unify___browse__term_browser_response_0_0);
	init_label(mercury____Unify___browse__term_browser_response_0_0_i8);
	init_label(mercury____Unify___browse__term_browser_response_0_0_i10);
	init_label(mercury____Unify___browse__term_browser_response_0_0_i6);
	init_label(mercury____Unify___browse__term_browser_response_0_0_i4);
	init_label(mercury____Unify___browse__term_browser_response_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___browse__term_browser_response_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i6);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i8);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__term_browser_response_0_0_i8);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i10);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__term_browser_response_0_0_i10);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__term_browser_response_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	if ((MR_const_field(MR_mktag(2), r1, (Integer) 0) != MR_const_field(MR_mktag(2), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__term_browser_response_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(1), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__term_browser_response_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(browse_module47)
	init_entry(mercury____Index___browse__term_browser_response_0_0);
	init_label(mercury____Index___browse__term_browser_response_0_0_i6);
	init_label(mercury____Index___browse__term_browser_response_0_0_i7);
	init_label(mercury____Index___browse__term_browser_response_0_0_i5);
	init_label(mercury____Index___browse__term_browser_response_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___browse__term_browser_response_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___browse__term_browser_response_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___browse__term_browser_response_0_0_i5);
	r2 = MR_unmkbody(r1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury____Index___browse__term_browser_response_0_0_i6);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___browse__term_browser_response_0_0_i6);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury____Index___browse__term_browser_response_0_0_i7);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___browse__term_browser_response_0_0_i7);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___browse__term_browser_response_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___browse__term_browser_response_0_0_i4);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(browse_module48)
	init_entry(mercury____Compare___browse__term_browser_response_0_0);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i6);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i7);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i5);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i4);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i2);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i12);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i13);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i11);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i10);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i8);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i14);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i15);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i26);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i28);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i23);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i20);
	init_label(mercury____Compare___browse__term_browser_response_0_0_i1029);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___browse__term_browser_response_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i5);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i6);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i2);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i6);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i7);
	r3 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i2);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i7);
	r3 = (Integer) 4;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i2);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i5);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i2);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i4);
	r3 = (Integer) 0;
Define_label(mercury____Compare___browse__term_browser_response_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i10);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i11);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i12);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i8);
	}
Define_label(mercury____Compare___browse__term_browser_response_0_0_i12);
	if (((Integer) MR_unmkbody(r2) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i13);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i8);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i13);
	r4 = (Integer) 4;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i8);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i11);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i8);
Define_label(mercury____Compare___browse__term_browser_response_0_0_i10);
	r4 = (Integer) 0;
Define_label(mercury____Compare___browse__term_browser_response_0_0_i8);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i14);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___browse__term_browser_response_0_0_i14);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i15);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___browse__term_browser_response_0_0_i15);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i20);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i23);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i26);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___browse__term_browser_response_0_0_i26);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i28);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___browse__term_browser_response_0_0_i28);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___browse__term_browser_response_0_0_i23);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i1029);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___browse__term_browser_response_0_0));
Define_label(mercury____Compare___browse__term_browser_response_0_0_i20);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___browse__term_browser_response_0_0_i1029);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		STATIC(mercury____Compare___browse__term_browser_response_0_0));
Define_label(mercury____Compare___browse__term_browser_response_0_0_i1029);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___browse__term_browser_response_0_0));
END_MODULE


BEGIN_MODULE(browse_module49)
	init_entry(mercury____Unify___browse__debugger_0_0);
	init_label(mercury____Unify___browse__debugger_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___browse__debugger_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___browse__debugger_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___browse__debugger_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(browse_module50)
	init_entry(mercury____Index___browse__debugger_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___browse__debugger_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(browse_module51)
	init_entry(mercury____Compare___browse__debugger_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___browse__debugger_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___browse__debugger_0_0));
END_MODULE

Declare_entry(mercury__browse__browse_external_7_0);

void
ML_BROWSE_browse_external(Word Mercury__argument1, Word Mercury__argument2, Word Mercury__argument3, Word Mercury__argument4, Word Mercury__argument5, Word * Mercury__argument6)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = Mercury__argument3;
	r4 = Mercury__argument4;
	r5 = Mercury__argument5;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__browse__browse_external_7_0), FALSE);
	restore_transient_registers();
	*Mercury__argument6 = r1;
	restore_regs_from_mem(c_regs);
}


Declare_static(mercury__browse__browser_state_type_1_0);

void
ML_BROWSE_browser_state_type(Word * Mercury__argument1)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__browse__browser_state_type_1_0), FALSE);
	restore_transient_registers();
	*Mercury__argument1 = r1;
	restore_regs_from_mem(c_regs);
}


Declare_entry(mercury__browse__print_5_0);

void
ML_BROWSE_print(Word Mercury__argument1, Word Mercury__argument2, Word Mercury__argument3, Word Mercury__argument4)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = Mercury__argument3;
	r4 = Mercury__argument4;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__browse__print_5_0), FALSE);
	restore_transient_registers();
	restore_regs_from_mem(c_regs);
}


Declare_entry(mercury__browse__browse_7_0);

void
ML_BROWSE_browse(Word Mercury__argument1, Word Mercury__argument2, Word Mercury__argument3, Word Mercury__argument4, Word Mercury__argument5, Word * Mercury__argument6)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = Mercury__argument3;
	r4 = Mercury__argument4;
	r5 = Mercury__argument5;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__browse__browse_7_0), FALSE);
	restore_transient_registers();
	*Mercury__argument6 = r1;
	restore_regs_from_mem(c_regs);
}


Declare_entry(mercury__browse__init_state_3_0);

void
ML_BROWSE_init_state(Word * Mercury__argument1)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__browse__init_state_3_0), FALSE);
	restore_transient_registers();
	*Mercury__argument1 = r1;
	restore_regs_from_mem(c_regs);
}


#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__browse_maybe_bunch_0(void)
{
	browse_module0();
	browse_module1();
	browse_module2();
	browse_module3();
	browse_module4();
	browse_module5();
	browse_module6();
	browse_module7();
	browse_module8();
	browse_module9();
	browse_module10();
	browse_module11();
	browse_module12();
	browse_module13();
	browse_module14();
	browse_module15();
	browse_module16();
	browse_module17();
	browse_module18();
	browse_module19();
	browse_module20();
	browse_module21();
	browse_module22();
	browse_module23();
	browse_module24();
	browse_module25();
	browse_module26();
	browse_module27();
	browse_module28();
	browse_module29();
	browse_module30();
	browse_module31();
	browse_module32();
	browse_module33();
	browse_module34();
	browse_module35();
	browse_module36();
	browse_module37();
	browse_module38();
	browse_module39();
}

static void mercury__browse_maybe_bunch_1(void)
{
	browse_module40();
	browse_module41();
	browse_module42();
	browse_module43();
	browse_module44();
	browse_module45();
	browse_module46();
	browse_module47();
	browse_module48();
	browse_module49();
	browse_module50();
	browse_module51();
}

#endif

void mercury__browse__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__browse__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__browse_maybe_bunch_0();
		mercury__browse_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_browse__type_ctor_info_browser_state_0,
			browse__browser_state_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_browse__type_ctor_info_debugger_0,
			browse__debugger_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_browse__type_ctor_info_term_browser_response_0,
			browse__term_browser_response_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
