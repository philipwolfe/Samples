/*
** Automatically generated from `browse.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef BROWSE_H
#define BROWSE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void ML_BROWSE_browse_external(Word, Word, Word, Word, Word, Word *);
void ML_BROWSE_browser_state_type(Word *);
void ML_BROWSE_print(Word, Word, Word, Word);
void ML_BROWSE_browse(Word, Word, Word, Word, Word, Word *);
void ML_BROWSE_init_state(Word *);

#ifdef __cplusplus
}
#endif

#endif /* BROWSE_H */
