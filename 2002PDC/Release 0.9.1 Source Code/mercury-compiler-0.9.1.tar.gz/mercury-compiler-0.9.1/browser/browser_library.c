/*
** Automatically generated from `browser_library.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__browser_library__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__browser_library__version_1_0);


BEGIN_MODULE(browser_library_module0)
	init_entry(mercury__browser_library__version_1_0);
BEGIN_CODE

/* code for predicate 'version'/1 in mode 0 */
Define_entry(mercury__browser_library__version_1_0);
	{
	String	Version;
#define MR_PROC_LABEL mercury__browser_library__version_1_0
	MR_OBTAIN_GLOBAL_LOCK("version");
{
#line 25 "browser_library.m"

	ConstString version_string = 
		MR_VERSION ", configured for " MR_FULLARCH;
	/*
	** Cast away const needed here, because Mercury declares Version
	** with type String rather than ConstString.
	*/
	Version = (String) (Word) version_string;
;}
#line 46 "browser_library.c"
	MR_RELEASE_GLOBAL_LOCK("version");
	r1 = (Word) Version;
#undef MR_PROC_LABEL

	}
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__browser_library_maybe_bunch_0(void)
{
	browser_library_module0();
}

#endif

void mercury__browser_library__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__browser_library__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__browser_library_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
