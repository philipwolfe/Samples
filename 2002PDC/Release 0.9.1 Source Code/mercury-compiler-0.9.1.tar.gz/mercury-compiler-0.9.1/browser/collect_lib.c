/*
** Automatically generated from `collect_lib.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__collect_lib__init
ENDINIT
*/

#include "mercury_imp.h"
#include "collect_lib.h"

#line 23 "collect_lib.c"

Define_extern_entry(mercury__collect_lib__dummy_pred_to_avoid_warning_about_nothing_exported_0_0);
Declare_static(mercury__collect_lib__link_collect_9_0);
Declare_label(mercury__collect_lib__link_collect_9_0_i2);
Declare_label(mercury__collect_lib__link_collect_9_0_i5);
Declare_label(mercury__collect_lib__link_collect_9_0_i6);
Declare_label(mercury__collect_lib__link_collect_9_0_i7);
Declare_label(mercury__collect_lib__link_collect_9_0_i8);
Declare_label(mercury__collect_lib__link_collect_9_0_i9);
Declare_label(mercury__collect_lib__link_collect_9_0_i4);
Declare_label(mercury__collect_lib__link_collect_9_0_i15);
Declare_label(mercury__collect_lib__link_collect_9_0_i16);
Declare_label(mercury__collect_lib__link_collect_9_0_i17);
Declare_static(mercury__collect_lib__set_to_null_pointer_1_0);
Declare_static(mercury__collect_lib__unlink_collect_3_0);
Declare_label(mercury__collect_lib__unlink_collect_3_0_i4);
Declare_label(mercury__collect_lib__unlink_collect_3_0_i1004);
Declare_label(mercury__collect_lib__unlink_collect_3_0_i1001);
Declare_label(mercury__collect_lib__unlink_collect_3_0_i6);
Declare_label(mercury__collect_lib__unlink_collect_3_0_i7);


BEGIN_MODULE(collect_lib_module0)
	init_entry(mercury__collect_lib__dummy_pred_to_avoid_warning_about_nothing_exported_0_0);
BEGIN_CODE

/* code for predicate 'dummy_pred_to_avoid_warning_about_nothing_exported'/0 in mode 0 */
Define_entry(mercury__collect_lib__dummy_pred_to_avoid_warning_about_nothing_exported_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__dl__open_6_0);
Declare_entry(mercury__dl__sym_5_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
Declare_entry(mercury__io__print_3_0);
Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(collect_lib_module1)
	init_entry(mercury__collect_lib__link_collect_9_0);
	init_label(mercury__collect_lib__link_collect_9_0_i2);
	init_label(mercury__collect_lib__link_collect_9_0_i5);
	init_label(mercury__collect_lib__link_collect_9_0_i6);
	init_label(mercury__collect_lib__link_collect_9_0_i7);
	init_label(mercury__collect_lib__link_collect_9_0_i8);
	init_label(mercury__collect_lib__link_collect_9_0_i9);
	init_label(mercury__collect_lib__link_collect_9_0_i4);
	init_label(mercury__collect_lib__link_collect_9_0_i15);
	init_label(mercury__collect_lib__link_collect_9_0_i16);
	init_label(mercury__collect_lib__link_collect_9_0_i17);
BEGIN_CODE

/* code for predicate 'link_collect'/9 in mode 0 */
Define_static(mercury__collect_lib__link_collect_9_0);
	MR_incr_sp_push_msg(5, "collect_lib:link_collect/9");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = r2;
	r2 = (Integer) 0;
	r4 = r3;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__dl__open_6_0),
		mercury__collect_lib__link_collect_9_0_i2,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i2);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__link_collect_9_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = (Word) MR_string_const("ML_COLLECT_initialize", 21);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__dl__sym_5_0),
		mercury__collect_lib__link_collect_9_0_i5,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i5);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	MR_stackvar(3) = r1;
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = (Word) MR_string_const("ML_COLLECT_filter", 17);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__dl__sym_5_0),
		mercury__collect_lib__link_collect_9_0_i6,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i6);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	MR_stackvar(4) = r1;
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = (Word) MR_string_const("ML_COLLECT_send_collect_result", 30);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__dl__sym_5_0),
		mercury__collect_lib__link_collect_9_0_i7,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i7);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r4 = r1;
	r1 = r3;
	r3 = r2;
	r2 = (Word) MR_string_const("ML_COLLECT_collecting_variable_type", 35);
	call_localret(ENTRY(mercury__dl__sym_5_0),
		mercury__collect_lib__link_collect_9_0_i8,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i8);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__link_collect_9_0_i9);
	if ((MR_tag(MR_stackvar(4)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__link_collect_9_0_i9);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__link_collect_9_0_i9);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__link_collect_9_0_i9);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	r5 = r3;
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	r6 = r4;
	r4 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r7 = r5;
	r5 = MR_stackvar(1);
	r8 = r6;
	r6 = (Integer) 121;
	r9 = r7;
	r7 = r8;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__collect_lib__link_collect_9_0_i9);
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 171 "collect_lib.c"
	r1 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 182 "collect_lib.c"
	r3 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 193 "collect_lib.c"
	r4 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 204 "collect_lib.c"
	r5 = Pointer;
#undef MR_PROC_LABEL

	}
	r6 = r1;
	r1 = r3;
	r7 = r2;
	r2 = r6;
	r8 = r3;
	r3 = r4;
	r9 = r4;
	r4 = r5;
	r10 = r5;
	r5 = MR_stackvar(1);
	r11 = r6;
	r6 = (Integer) 110;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__collect_lib__link_collect_9_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r4 = r2;
	r2 = (Word) MR_string_const("dlopen failed: ", 15);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__collect_lib__link_collect_9_0_i15,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i15);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__collect_lib__link_collect_9_0_i16,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i16);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__collect_lib__link_collect_9_0_i17,
		STATIC(mercury__collect_lib__link_collect_9_0));
Define_label(mercury__collect_lib__link_collect_9_0_i17);
	update_prof_current_proc(LABEL(mercury__collect_lib__link_collect_9_0));
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 258 "collect_lib.c"
	r2 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 269 "collect_lib.c"
	r3 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 280 "collect_lib.c"
	r4 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__link_collect_9_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 291 "collect_lib.c"
	r5 = Pointer;
#undef MR_PROC_LABEL

	}
	r6 = r1;
	r1 = r3;
	r7 = r3;
	r3 = r4;
	r8 = r4;
	r4 = r5;
	r9 = r5;
	r5 = MR_stackvar(1);
	r10 = r6;
	r6 = (Integer) 110;
	r11 = r7;
	r7 = r10;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(collect_lib_module2)
	init_entry(mercury__collect_lib__set_to_null_pointer_1_0);
BEGIN_CODE

/* code for predicate 'set_to_null_pointer'/1 in mode 0 */
Define_static(mercury__collect_lib__set_to_null_pointer_1_0);
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__collect_lib__set_to_null_pointer_1_0
{
#line 123 "collect_lib.m"
(Pointer = (Word) NULL);}
#line 326 "collect_lib.c"
	r1 = Pointer;
#undef MR_PROC_LABEL

	}
	proceed();
END_MODULE

Declare_entry(mercury__dl__close_4_0);

BEGIN_MODULE(collect_lib_module3)
	init_entry(mercury__collect_lib__unlink_collect_3_0);
	init_label(mercury__collect_lib__unlink_collect_3_0_i4);
	init_label(mercury__collect_lib__unlink_collect_3_0_i1004);
	init_label(mercury__collect_lib__unlink_collect_3_0_i1001);
	init_label(mercury__collect_lib__unlink_collect_3_0_i6);
	init_label(mercury__collect_lib__unlink_collect_3_0_i7);
BEGIN_CODE

/* code for predicate 'unlink_collect'/3 in mode 0 */
Define_static(mercury__collect_lib__unlink_collect_3_0);
	MR_incr_sp_push_msg(1, "collect_lib:unlink_collect/3");
	MR_stackvar(1) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__collect_lib__unlink_collect_3_0_i1004);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__dl__close_4_0),
		mercury__collect_lib__unlink_collect_3_0_i4,
		STATIC(mercury__collect_lib__unlink_collect_3_0));
Define_label(mercury__collect_lib__unlink_collect_3_0_i4);
	update_prof_current_proc(LABEL(mercury__collect_lib__unlink_collect_3_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__collect_lib__unlink_collect_3_0_i6);
	GOTO_LABEL(mercury__collect_lib__unlink_collect_3_0_i1001);
Define_label(mercury__collect_lib__unlink_collect_3_0_i1004);
	r1 = r2;
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__collect_lib__unlink_collect_3_0_i1001);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__collect_lib__unlink_collect_3_0_i6);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__collect_lib__unlink_collect_3_0_i7,
		STATIC(mercury__collect_lib__unlink_collect_3_0));
Define_label(mercury__collect_lib__unlink_collect_3_0_i7);
	update_prof_current_proc(LABEL(mercury__collect_lib__unlink_collect_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__collect_lib__unlink_collect_3_0));
END_MODULE

Declare_static(mercury__collect_lib__unlink_collect_3_0);

void
ML_CL_unlink_collect(Word Mercury__argument1)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__collect_lib__unlink_collect_3_0), FALSE);
	restore_transient_registers();
	restore_regs_from_mem(c_regs);
}


Declare_static(mercury__collect_lib__link_collect_9_0);

void
ML_CL_link_collect(String Mercury__argument1, Word * Mercury__argument2, Word * Mercury__argument3, Word * Mercury__argument4, Word * Mercury__argument5, Word * Mercury__argument6, Char * Mercury__argument7)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = (Word) Mercury__argument1;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__collect_lib__link_collect_9_0), FALSE);
	restore_transient_registers();
	*Mercury__argument2 = r1;
	*Mercury__argument3 = r2;
	*Mercury__argument4 = r3;
	*Mercury__argument5 = r4;
	*Mercury__argument6 = r5;
	*Mercury__argument7 = r6;
	restore_regs_from_mem(c_regs);
}


#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__collect_lib_maybe_bunch_0(void)
{
	collect_lib_module0();
	collect_lib_module1();
	collect_lib_module2();
	collect_lib_module3();
}

#endif

void mercury__collect_lib__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__collect_lib__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__collect_lib_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
