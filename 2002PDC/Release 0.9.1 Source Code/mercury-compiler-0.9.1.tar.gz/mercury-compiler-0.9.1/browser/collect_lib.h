/*
** Automatically generated from `collect_lib.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef COLLECT_LIB_H
#define COLLECT_LIB_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void ML_CL_unlink_collect(Word);
void ML_CL_link_collect(String, Word *, Word *, Word *, Word *, Word *, Char *);

#ifdef __cplusplus
}
#endif

#endif /* COLLECT_LIB_H */
