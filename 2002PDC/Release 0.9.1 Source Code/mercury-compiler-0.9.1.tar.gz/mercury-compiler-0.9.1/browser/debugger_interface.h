/*
** Automatically generated from `debugger_interface.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef DEBUGGER_INTERFACE_H
#define DEBUGGER_INTERFACE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void ML_DI_get_variable_name(Word, String *);
void ML_DI_init_mercury_string(String *);
void ML_DI_get_object_file_name(Word, String *);
void ML_DI_get_mmc_options(Word, String *);
void ML_DI_get_list_modules_to_import(Word, Integer *, Word *);
void ML_DI_read_request_from_socket(Word, Word *, Integer *);
bool ML_DI_found_match_comp(Integer, Integer, Integer, Word, String, String, String, String, Integer, Integer, Integer, Word, String, Word);
bool ML_DI_found_match_user(Integer, Integer, Integer, Word, Word, String, String, String, Integer, Integer, Integer, Word, String, Word);
Integer ML_DI_get_var_number(Word);
void ML_DI_output_current_live_var_names(Word, Word, Word);
void ML_DI_output_current_nth_var(Word, Word);
void ML_DI_output_current_vars(Word, Word, Word);
void ML_DI_output_current_slots_comp(Integer, Integer, Integer, Word, String, String, String, String, Integer, Integer, Integer, String, Word);
void ML_DI_output_current_slots_user(Integer, Integer, Integer, Word, Word, String, String, String, Integer, Integer, Integer, String, Word);

#ifdef __cplusplus
}
#endif

#endif /* DEBUGGER_INTERFACE_H */
