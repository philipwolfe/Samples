/*
** Automatically generated from `declarative_debugger.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__declarative_debugger__init
ENDINIT
*/

#include "mercury_imp.h"
#include "declarative_debugger.h"

#line 23 "declarative_debugger.c"

Declare_static(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0);
Declare_label(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0_i3);
Declare_static(mercury____Index___declarative_debugger__wrap_1__ua0_2_0);
Declare_static(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i2);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i5);
Declare_static(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i4);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i5);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i2);
Declare_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i6);
Define_extern_entry(mercury__declarative_debugger__edt_root_3_0);
Define_extern_entry(mercury__declarative_debugger__edt_children_3_0);
Define_extern_entry(mercury__declarative_debugger__diagnoser_state_init_1_0);
Define_extern_entry(mercury__declarative_debugger__diagnosis_9_0);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i2);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i3);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i4);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i5);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i6);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i7);
Declare_label(mercury__declarative_debugger__diagnosis_9_0_i8);
Declare_static(mercury__declarative_debugger__diagnosis_store_9_0);
Declare_static(mercury__declarative_debugger__get_answers_4_0);
Declare_label(mercury__declarative_debugger__get_answers_4_0_i1001);
Declare_label(mercury__declarative_debugger__get_answers_4_0_i3);
Declare_label(mercury__declarative_debugger__get_answers_4_0_i5);
Declare_label(mercury__declarative_debugger__get_answers_4_0_i2);
Declare_static(mercury__declarative_debugger__wrong_answer_children_4_0);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i2);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i6);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i9);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i11);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i12);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i13);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i17);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i19);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1000);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i26);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i27);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i30);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i31);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i32);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i35);
Declare_label(mercury__declarative_debugger__wrong_answer_children_4_0_i36);
Declare_static(mercury__declarative_debugger__missing_answer_children_4_0);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i2);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i6);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i8);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i7);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i10);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i13);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i14);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i16);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i17);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i18);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i20);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i19);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i28);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i1002);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i35);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i36);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i39);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i40);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i43);
Declare_label(mercury__declarative_debugger__missing_answer_children_4_0_i44);
Declare_static(mercury__declarative_debugger__analyse_edt_7_0);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i2);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i3);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i8);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i9);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i1002);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i11);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i13);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i14);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i15);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i16);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i19);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i20);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i21);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i22);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i23);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i24);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i25);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i17);
Declare_label(mercury__declarative_debugger__analyse_edt_7_0_i29);
Declare_static(mercury__declarative_debugger__analyse_children_8_0);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i1003);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i4);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i5);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i10);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i9);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i7);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i13);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i14);
Declare_label(mercury__declarative_debugger__analyse_children_8_0_i3);
Declare_static(mercury__declarative_debugger__write_children_4_0);
Declare_label(mercury__declarative_debugger__write_children_4_0_i1001);
Declare_label(mercury__declarative_debugger__write_children_4_0_i4);
Declare_label(mercury__declarative_debugger__write_children_4_0_i5);
Declare_label(mercury__declarative_debugger__write_children_4_0_i6);
Declare_label(mercury__declarative_debugger__write_children_4_0_i7);
Declare_label(mercury__declarative_debugger__write_children_4_0_i3);
Define_extern_entry(mercury____Unify___declarative_debugger__edt_truth_0_0);
Declare_label(mercury____Unify___declarative_debugger__edt_truth_0_0_i1);
Define_extern_entry(mercury____Index___declarative_debugger__edt_truth_0_0);
Define_extern_entry(mercury____Compare___declarative_debugger__edt_truth_0_0);
Define_extern_entry(mercury____Unify___declarative_debugger__edt_node_0_0);
Declare_label(mercury____Unify___declarative_debugger__edt_node_0_0_i3);
Declare_label(mercury____Unify___declarative_debugger__edt_node_0_0_i8);
Declare_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1006);
Declare_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1);
Define_extern_entry(mercury____Index___declarative_debugger__edt_node_0_0);
Declare_label(mercury____Index___declarative_debugger__edt_node_0_0_i3);
Define_extern_entry(mercury____Compare___declarative_debugger__edt_node_0_0);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i3);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i2);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i5);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i4);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i6);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i7);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i11);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i16);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i1015);
Declare_label(mercury____Compare___declarative_debugger__edt_node_0_0_i24);
Define_extern_entry(mercury____Unify___declarative_debugger__edt_atom_0_0);
Define_extern_entry(mercury____Index___declarative_debugger__edt_atom_0_0);
Define_extern_entry(mercury____Compare___declarative_debugger__edt_atom_0_0);
Define_extern_entry(mercury____Unify___declarative_debugger__diagnoser_response_0_0);
Declare_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i3);
Declare_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i1);
Define_extern_entry(mercury____Index___declarative_debugger__diagnoser_response_0_0);
Declare_label(mercury____Index___declarative_debugger__diagnoser_response_0_0_i3);
Define_extern_entry(mercury____Compare___declarative_debugger__diagnoser_response_0_0);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i3);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i2);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i5);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i4);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i6);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i7);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i11);
Declare_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i1014);
Define_extern_entry(mercury____Unify___declarative_debugger__diagnoser_state_0_0);
Define_extern_entry(mercury____Index___declarative_debugger__diagnoser_state_0_0);
Define_extern_entry(mercury____Compare___declarative_debugger__diagnoser_state_0_0);
Declare_static(mercury____Unify___declarative_debugger__wrap_1_0);
Declare_static(mercury____Index___declarative_debugger__wrap_1_0);
Declare_static(mercury____Compare___declarative_debugger__wrap_1_0);
Declare_static(mercury____Unify___declarative_debugger__declarative_bug_1_0);
Declare_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i3);
Declare_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i1);
Declare_static(mercury____Index___declarative_debugger__declarative_bug_1_0);
Declare_static(mercury____Compare___declarative_debugger__declarative_bug_1_0);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i3);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i2);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i5);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i4);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i6);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i7);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i11);
Declare_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i1014);

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_declarative_bug_1;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_diagnoser_response_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_diagnoser_state_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_atom_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_node_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_truth_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_wrap_1;

const struct mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1___struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Code * f4;
	Code * f5;
}  mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__;

static const struct mercury_data_declarative_debugger__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_declarative_debugger__common_0;

static const struct mercury_data_declarative_debugger__common_1_struct {
	Integer f1;
	Integer f2;
	String f3;
	Word * f4;
}  mercury_data_declarative_debugger__common_1;

static const struct mercury_data_declarative_debugger__common_2_struct {
	Word * f1;
}  mercury_data_declarative_debugger__common_2;

static const struct mercury_data_declarative_debugger__common_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__common_3;

static const struct mercury_data_declarative_debugger__common_4_struct {
	Word * f1;
}  mercury_data_declarative_debugger__common_4;

static const struct mercury_data_declarative_debugger__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_declarative_debugger__common_5;

static const struct mercury_data_declarative_debugger__common_6_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_declarative_debugger__common_6;

static const struct mercury_data_declarative_debugger__common_7_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_declarative_debugger__common_7;

static const struct mercury_data_declarative_debugger__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__common_8;

static const struct mercury_data_declarative_debugger__common_9_struct {
	Word * f1;
}  mercury_data_declarative_debugger__common_9;

static const struct mercury_data_declarative_debugger__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__common_10;

static const struct mercury_data_declarative_debugger__common_11_struct {
	Word * f1;
}  mercury_data_declarative_debugger__common_11;

static const struct mercury_data_declarative_debugger__common_12_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_declarative_debugger__common_12;

static const struct mercury_data_declarative_debugger__common_13_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_declarative_debugger__common_13;

static const struct mercury_data_declarative_debugger__common_14_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_declarative_debugger__common_14;

static const struct mercury_data_declarative_debugger__common_15_struct {
	Integer f1;
	Integer f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_declarative_debugger__common_15;

static const struct mercury_data_declarative_debugger__common_16_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_declarative_debugger__common_16;

static const struct mercury_data_declarative_debugger__common_17_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_declarative_debugger__common_17;

static const struct mercury_data_declarative_debugger__type_ctor_functors_wrap_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__type_ctor_functors_wrap_1;

static const struct mercury_data_declarative_debugger__type_ctor_layout_wrap_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_wrap_1;

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_truth_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__type_ctor_functors_edt_truth_0;

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_truth_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_edt_truth_0;

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_node_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_functors_edt_node_0;

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_node_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_edt_node_0;

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_atom_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__type_ctor_functors_edt_atom_0;

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_atom_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_edt_atom_0;

static const struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_state_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_debugger__type_ctor_functors_diagnoser_state_0;

static const struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_state_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_diagnoser_state_0;

static const struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_response_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_functors_diagnoser_response_0;

static const struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_response_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_diagnoser_response_0;

static const struct mercury_data_declarative_debugger__type_ctor_functors_declarative_bug_1_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_functors_declarative_bug_1;

static const struct mercury_data_declarative_debugger__type_ctor_layout_declarative_bug_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_debugger__type_ctor_layout_declarative_bug_1;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_declarative_bug_1 = {
	(Integer) 1,
	STATIC(mercury____Unify___declarative_debugger__declarative_bug_1_0),
	STATIC(mercury____Index___declarative_debugger__declarative_bug_1_0),
	STATIC(mercury____Compare___declarative_debugger__declarative_bug_1_0),
	(Integer) 2,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_declarative_bug_1,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_declarative_bug_1,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("declarative_bug", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_diagnoser_response_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_debugger__diagnoser_response_0_0),
	ENTRY(mercury____Index___declarative_debugger__diagnoser_response_0_0),
	ENTRY(mercury____Compare___declarative_debugger__diagnoser_response_0_0),
	(Integer) 2,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_diagnoser_response_0,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_diagnoser_response_0,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("diagnoser_response", 18),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_diagnoser_state_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_debugger__diagnoser_state_0_0),
	ENTRY(mercury____Index___declarative_debugger__diagnoser_state_0_0),
	ENTRY(mercury____Compare___declarative_debugger__diagnoser_state_0_0),
	(Integer) 6,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_diagnoser_state_0,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_diagnoser_state_0,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("diagnoser_state", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_atom_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_debugger__edt_atom_0_0),
	ENTRY(mercury____Index___declarative_debugger__edt_atom_0_0),
	ENTRY(mercury____Compare___declarative_debugger__edt_atom_0_0),
	(Integer) 6,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_edt_atom_0,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_edt_atom_0,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("edt_atom", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_node_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_debugger__edt_node_0_0),
	ENTRY(mercury____Index___declarative_debugger__edt_node_0_0),
	ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0),
	(Integer) 2,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_edt_node_0,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_edt_node_0,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("edt_node", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_edt_truth_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_debugger__edt_truth_0_0),
	ENTRY(mercury____Index___declarative_debugger__edt_truth_0_0),
	ENTRY(mercury____Compare___declarative_debugger__edt_truth_0_0),
	(Integer) 6,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_edt_truth_0,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_edt_truth_0,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("edt_truth", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_debugger__type_ctor_info_wrap_1 = {
	(Integer) 1,
	STATIC(mercury____Unify___declarative_debugger__wrap_1_0),
	STATIC(mercury____Index___declarative_debugger__wrap_1_0),
	STATIC(mercury____Compare___declarative_debugger__wrap_1_0),
	(Integer) 4,
	(Word *) &mercury_data_declarative_debugger__type_ctor_functors_wrap_1,
	(Word *) &mercury_data_declarative_debugger__type_ctor_layout_wrap_1,
	MR_string_const("declarative_debugger", 20),
	MR_string_const("wrap", 4),
	(Integer) 3
};

const struct mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1___struct mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__ = {
	(Integer) 1,
	(Integer) 0,
	(Integer) 2,
	STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0),
	STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0)
};

extern const struct mercury_data___base_typeclass_info_declarative_execution__execution_tree__arity2__declarative_execution__trace_node_store__arity0__declarative_execution__trace_node_id__arity0___struct
	mercury_data___base_typeclass_info_declarative_execution__execution_tree__arity2__declarative_execution__trace_node_store__arity0__declarative_execution__trace_node_id__arity0__;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_execution__type_ctor_info_trace_node_store_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_execution__type_ctor_info_trace_node_id_0;
static const struct mercury_data_declarative_debugger__common_0_struct mercury_data_declarative_debugger__common_0 = {
	(Word *) &mercury_data___base_typeclass_info_declarative_execution__execution_tree__arity2__declarative_execution__trace_node_store__arity0__declarative_execution__trace_node_id__arity0__,
	(Word *) &mercury_data_declarative_execution__type_ctor_info_trace_node_store_0,
	(Word *) &mercury_data_declarative_execution__type_ctor_info_trace_node_id_0
};

static const struct mercury_data_declarative_debugger__common_1_struct mercury_data_declarative_debugger__common_1 = {
	(Integer) 1,
	(Integer) 1,
	MR_string_const("wrap", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_declarative_debugger__common_2_struct mercury_data_declarative_debugger__common_2 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_declarative_debugger__common_3_struct mercury_data_declarative_debugger__common_3 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_execution__type_ctor_info_trace_atom_0;
static const struct mercury_data_declarative_debugger__common_4_struct mercury_data_declarative_debugger__common_4 = {
	(Word *) &mercury_data_declarative_execution__type_ctor_info_trace_atom_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_declarative_debugger__common_5_struct mercury_data_declarative_debugger__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_declarative_execution__type_ctor_info_trace_atom_0
};

static const struct mercury_data_declarative_debugger__common_6_struct mercury_data_declarative_debugger__common_6 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_5),
	MR_string_const("missing_answer", 14),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_7_struct mercury_data_declarative_debugger__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_4),
	MR_string_const("wrong_answer", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_8_struct mercury_data_declarative_debugger__common_8 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_oracle__type_ctor_info_oracle_state_0;
static const struct mercury_data_declarative_debugger__common_9_struct mercury_data_declarative_debugger__common_9 = {
	(Word *) &mercury_data_declarative_oracle__type_ctor_info_oracle_state_0
};

static const struct mercury_data_declarative_debugger__common_10_struct mercury_data_declarative_debugger__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_9)
};

static const struct mercury_data_declarative_debugger__common_11_struct mercury_data_declarative_debugger__common_11 = {
	(Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0
};

static const struct mercury_data_declarative_debugger__common_12_struct mercury_data_declarative_debugger__common_12 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_11),
	MR_string_const("bug_found", 9),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_13_struct mercury_data_declarative_debugger__common_13 = {
	(Integer) 0,
	MR_string_const("no_bug_found", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_14_struct mercury_data_declarative_debugger__common_14 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("no_bug_found", 12)
};

static const struct mercury_data_declarative_debugger__common_15_struct mercury_data_declarative_debugger__common_15 = {
	(Integer) 1,
	(Integer) 1,
	MR_string_const("e_bug", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_16_struct mercury_data_declarative_debugger__common_16 = {
	(Integer) 0,
	MR_string_const("not_found", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_debugger__common_17_struct mercury_data_declarative_debugger__common_17 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("not_found", 9)
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_wrap_1_struct mercury_data_declarative_debugger__type_ctor_functors_wrap_1 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_1)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_wrap_1_struct mercury_data_declarative_debugger__type_ctor_layout_wrap_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_1)
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_truth_0_struct mercury_data_declarative_debugger__type_ctor_functors_edt_truth_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_2)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_truth_0_struct mercury_data_declarative_debugger__type_ctor_layout_edt_truth_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_3)
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_node_0_struct mercury_data_declarative_debugger__type_ctor_functors_edt_node_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_7)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_node_0_struct mercury_data_declarative_debugger__type_ctor_layout_edt_node_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_debugger__common_7),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_debugger__common_6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_edt_atom_0_struct mercury_data_declarative_debugger__type_ctor_functors_edt_atom_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_4)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_edt_atom_0_struct mercury_data_declarative_debugger__type_ctor_layout_edt_atom_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_8)
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_state_0_struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_state_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_9)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_state_0_struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_state_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_debugger__common_10)
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_response_0_struct mercury_data_declarative_debugger__type_ctor_functors_diagnoser_response_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_13)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_response_0_struct mercury_data_declarative_debugger__type_ctor_layout_diagnoser_response_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_debugger__common_12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_declarative_debugger__type_ctor_functors_declarative_bug_1_struct mercury_data_declarative_debugger__type_ctor_functors_declarative_bug_1 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_16)
};

static const struct mercury_data_declarative_debugger__type_ctor_layout_declarative_bug_1_struct mercury_data_declarative_debugger__type_ctor_layout_declarative_bug_1 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_17),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_debugger__common_15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(declarative_debugger_module0)
	init_entry(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0);
	init_label(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index___declarative_debugger__declarative_bug_1__ua0'/2 in mode 0 */
Define_static(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module1)
	init_entry(mercury____Index___declarative_debugger__wrap_1__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___declarative_debugger__wrap_1__ua0'/2 in mode 0 */
Define_static(mercury____Index___declarative_debugger__wrap_1__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(declarative_debugger_module2)
	init_entry(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i2);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i5);
BEGIN_CODE

/* code for predicate 'Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3'/3 in mode 0 */
Define_static(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i2);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__declarative_debugger__missing_answer_children_4_0),
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0));
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__declarative_debugger__wrong_answer_children_4_0),
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0));
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0_i5);
	r1 = (Word) MR_string_const("trace_children: not an EXIT or FAIL node", 40);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0));
END_MODULE

Declare_entry(mercury__declarative_execution__call_node_from_id_3_0);

BEGIN_MODULE(declarative_debugger_module3)
	init_entry(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i4);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i5);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i2);
	init_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i6);
BEGIN_CODE

/* code for predicate 'Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3'/3 in mode 0 */
Define_static(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i2);
	MR_incr_sp_push_msg(3, "declarative_debugger:Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__declarative_execution__call_node_from_id_3_0),
		mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i4,
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0));
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r2 = MR_stackvar(2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__declarative_debugger__get_answers_4_0),
		mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i5,
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0));
	}
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0, "declarative_debugger:edt_node/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i6);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0, "declarative_debugger:edt_node/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 3);
	proceed();
Define_label(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0_i6);
	r1 = (Word) MR_string_const("trace_root: not an EXIT or FAIL node", 36);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0));
END_MODULE

Declare_entry(mercury__do_call_class_method);

BEGIN_MODULE(declarative_debugger_module4)
	init_entry(mercury__declarative_debugger__edt_root_3_0);
BEGIN_CODE

/* code for predicate 'edt_root'/3 in mode 0 */
Define_entry(mercury__declarative_debugger__edt_root_3_0);
	r5 = r2;
	r6 = r3;
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	tailcall(ENTRY(mercury__do_call_class_method),
		ENTRY(mercury__declarative_debugger__edt_root_3_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module5)
	init_entry(mercury__declarative_debugger__edt_children_3_0);
BEGIN_CODE

/* code for predicate 'edt_children'/3 in mode 0 */
Define_entry(mercury__declarative_debugger__edt_children_3_0);
	r5 = r2;
	r6 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	tailcall(ENTRY(mercury__do_call_class_method),
		ENTRY(mercury__declarative_debugger__edt_children_3_0));
END_MODULE

Declare_entry(mercury__declarative_oracle__oracle_state_init_1_0);

BEGIN_MODULE(declarative_debugger_module6)
	init_entry(mercury__declarative_debugger__diagnoser_state_init_1_0);
BEGIN_CODE

/* code for predicate 'diagnoser_state_init'/1 in mode 0 */
Define_entry(mercury__declarative_debugger__diagnoser_state_init_1_0);
	tailcall(ENTRY(mercury__declarative_oracle__oracle_state_init_1_0),
		ENTRY(mercury__declarative_debugger__diagnoser_state_init_1_0));
END_MODULE

Declare_entry(mercury__io__set_input_stream_4_0);
Declare_entry(mercury__io__set_output_stream_4_0);
Declare_entry(mercury__type_info_from_typeclass_info_3_0);
extern const struct mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1___struct
	mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_execution__type_ctor_info_trace_node_1;

BEGIN_MODULE(declarative_debugger_module7)
	init_entry(mercury__declarative_debugger__diagnosis_9_0);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i2);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i3);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i4);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i5);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i6);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i7);
	init_label(mercury__declarative_debugger__diagnosis_9_0_i8);
BEGIN_CODE

/* code for predicate 'diagnosis'/9 in mode 0 */
Define_entry(mercury__declarative_debugger__diagnosis_9_0);
	MR_incr_sp_push_msg(9, "declarative_debugger:diagnosis/9");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(7) = r1;
	r1 = r2;
	r2 = r7;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__declarative_debugger__diagnosis_9_0_i2,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__declarative_debugger__diagnosis_9_0_i3,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i3);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	MR_stackvar(6) = MR_stackvar(2);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(7);
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__type_info_from_typeclass_info_3_0),
		mercury__declarative_debugger__diagnosis_9_0_i4,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__declarative_debugger__diagnosis_9_0, "origin_lost_in_value_number");
	MR_stackvar(8) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(7);
	r2 = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_wrap_1;
	call_localret(ENTRY(mercury__type_info_from_typeclass_info_3_0),
		mercury__declarative_debugger__diagnosis_9_0_i5,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 4, mercury__declarative_debugger__diagnosis_9_0, "private_builtin:typeclass_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__declarative_debugger__diagnosis_9_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) (Word *) &mercury_data_declarative_execution__type_ctor_info_trace_node_1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r3;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__declarative_debugger__analyse_edt_7_0),
		mercury__declarative_debugger__diagnosis_9_0_i6,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i6);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__declarative_debugger__diagnosis_9_0_i7,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
	}
Define_label(mercury__declarative_debugger__diagnosis_9_0_i7);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__declarative_debugger__diagnosis_9_0_i8,
		ENTRY(mercury__declarative_debugger__diagnosis_9_0));
Define_label(mercury__declarative_debugger__diagnosis_9_0_i8);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__diagnosis_9_0));
	r3 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module8)
	init_entry(mercury__declarative_debugger__diagnosis_store_9_0);
BEGIN_CODE

/* code for predicate 'diagnosis_store'/9 in mode 0 */
Define_static(mercury__declarative_debugger__diagnosis_store_9_0);
	r7 = r6;
	r6 = r5;
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_debugger__common_0);
	tailcall(STATIC(mercury__declarative_debugger__diagnosis_9_0),
		STATIC(mercury__declarative_debugger__diagnosis_store_9_0));
END_MODULE

Declare_entry(mercury__declarative_execution__maybe_redo_node_from_id_3_0);
Declare_entry(mercury__declarative_execution__exit_node_from_id_3_0);

BEGIN_MODULE(declarative_debugger_module9)
	init_entry(mercury__declarative_debugger__get_answers_4_0);
	init_label(mercury__declarative_debugger__get_answers_4_0_i1001);
	init_label(mercury__declarative_debugger__get_answers_4_0_i3);
	init_label(mercury__declarative_debugger__get_answers_4_0_i5);
	init_label(mercury__declarative_debugger__get_answers_4_0_i2);
BEGIN_CODE

/* code for predicate 'get_answers'/4 in mode 0 */
Define_static(mercury__declarative_debugger__get_answers_4_0);
	MR_incr_sp_push_msg(4, "declarative_debugger:get_answers/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__declarative_debugger__get_answers_4_0_i1001);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__declarative_execution__maybe_redo_node_from_id_3_0),
		mercury__declarative_debugger__get_answers_4_0_i3,
		STATIC(mercury__declarative_debugger__get_answers_4_0));
Define_label(mercury__declarative_debugger__get_answers_4_0_i3);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__get_answers_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__declarative_debugger__get_answers_4_0_i2);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__exit_node_from_id_3_0),
		mercury__declarative_debugger__get_answers_4_0_i5,
		STATIC(mercury__declarative_debugger__get_answers_4_0));
Define_label(mercury__declarative_debugger__get_answers_4_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__get_answers_4_0));
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__get_answers_4_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__declarative_debugger__get_answers_4_0_i1001);
Define_label(mercury__declarative_debugger__get_answers_4_0_i2);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__declarative_execution__det_trace_node_from_id_3_0);
Declare_entry(mercury__declarative_execution__cond_node_from_id_3_0);
Declare_entry(mercury__declarative_execution__neg_node_from_id_3_0);

BEGIN_MODULE(declarative_debugger_module10)
	init_entry(mercury__declarative_debugger__wrong_answer_children_4_0);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i2);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i6);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i9);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i11);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i12);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i13);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i17);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i19);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1000);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i26);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i27);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i30);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i31);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i32);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i35);
	init_label(mercury__declarative_debugger__wrong_answer_children_4_0_i36);
BEGIN_CODE

/* code for predicate 'wrong_answer_children'/4 in mode 0 */
Define_static(mercury__declarative_debugger__wrong_answer_children_4_0);
	MR_incr_sp_push_msg(5, "declarative_debugger:wrong_answer_children/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__declarative_execution__det_trace_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i2,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i30) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i6) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i9) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i11));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__call_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i13,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i9);
	r1 = (Word) MR_string_const("wrong_answer_children: unexpected REDO node", 43);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i11);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i12) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i1000) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i17) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i19) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i1000) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i26) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i30) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i31) AND
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i35));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i12);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__call_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i13,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i13);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__wrong_answer_children_4_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i17);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i19);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i30);
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i1000);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i1001);
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i26);
	r4 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__declarative_debugger__missing_answer_children_4_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i27,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i27);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__cond_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i1000,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i30);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i31);
	r4 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__declarative_debugger__missing_answer_children_4_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i32,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i32);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__neg_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i1000,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i35);
	r4 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	localcall(mercury__declarative_debugger__wrong_answer_children_4_0,
		LABEL(mercury__declarative_debugger__wrong_answer_children_4_0_i36),
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
Define_label(mercury__declarative_debugger__wrong_answer_children_4_0_i36);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__wrong_answer_children_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__neg_node_from_id_3_0),
		mercury__declarative_debugger__wrong_answer_children_4_0_i1000,
		STATIC(mercury__declarative_debugger__wrong_answer_children_4_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module11)
	init_entry(mercury__declarative_debugger__missing_answer_children_4_0);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i2);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i6);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i8);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i7);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i10);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i13);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i14);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i16);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i17);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i18);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i20);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i19);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i28);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i1002);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i35);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i36);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i39);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i40);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i43);
	init_label(mercury__declarative_debugger__missing_answer_children_4_0_i44);
BEGIN_CODE

/* code for predicate 'missing_answer_children'/4 in mode 0 */
Define_static(mercury__declarative_debugger__missing_answer_children_4_0);
	MR_incr_sp_push_msg(6, "declarative_debugger:missing_answer_children/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__declarative_execution__det_trace_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i2,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i39) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i6) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i13) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i16));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(3) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__maybe_redo_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i8,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i8);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i7);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__missing_answer_children_4_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__declarative_debugger__wrong_answer_children_4_0),
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i7);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__declarative_execution__call_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i10,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i10);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__missing_answer_children_4_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(5);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__declarative_debugger__wrong_answer_children_4_0),
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i13);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__exit_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i14,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i14);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__declarative_debugger__wrong_answer_children_4_0),
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i17) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1002) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1002) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i28) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1002) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i35) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i39) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i40) AND
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i43));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i17);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__call_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i18,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i18);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__maybe_redo_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i20,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i20);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i19);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__missing_answer_children_4_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(5);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i19);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__missing_answer_children_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i28);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i39);
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i1002);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i1005);
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i35);
	r4 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	localcall(mercury__declarative_debugger__missing_answer_children_4_0,
		LABEL(mercury__declarative_debugger__missing_answer_children_4_0_i36),
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i36);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__cond_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i1002,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i39);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i40);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__neg_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i1002,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i43);
	r4 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__declarative_debugger__wrong_answer_children_4_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i44,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
Define_label(mercury__declarative_debugger__missing_answer_children_4_0_i44);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__missing_answer_children_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_execution__neg_node_from_id_3_0),
		mercury__declarative_debugger__missing_answer_children_4_0_i1002,
		STATIC(mercury__declarative_debugger__missing_answer_children_4_0));
END_MODULE

Declare_entry(mercury__declarative_oracle__query_oracle_6_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__declarative_user__write_edt_node_3_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__io__write_char_3_0);

BEGIN_MODULE(declarative_debugger_module12)
	init_entry(mercury__declarative_debugger__analyse_edt_7_0);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i2);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i3);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i8);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i9);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i1002);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i11);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i13);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i14);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i15);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i16);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i19);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i20);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i21);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i22);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i23);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i24);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i25);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i17);
	init_label(mercury__declarative_debugger__analyse_edt_7_0_i29);
BEGIN_CODE

/* code for predicate 'analyse_edt'/7 in mode 0 */
Define_static(mercury__declarative_debugger__analyse_edt_7_0);
	MR_incr_sp_push_msg(7, "declarative_debugger:analyse_edt/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(4) = r5;
	r5 = r2;
	r6 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_edt_7_0_i2,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__declarative_oracle__query_oracle_6_0),
		mercury__declarative_debugger__analyse_edt_7_0_i3,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i3);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__declarative_debugger__analyse_edt_7_0_i1002);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__analyse_edt_7_0_i1002);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(2);
	r1 = MR_stackvar(5);
	r2 = (Integer) 2;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_edt_7_0_i8,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i8);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__declarative_debugger__analyse_edt_7_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	call_localret(STATIC(mercury__declarative_debugger__analyse_children_8_0),
		mercury__declarative_debugger__analyse_edt_7_0_i9,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i9);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_debugger__analyse_edt_7_0_i11);
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i1002);
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("Bug not found.\n", 15);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i29,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i11);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("Incorrect instance found:\n\n", 27);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i13,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i13);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	MR_stackvar(4) = r1;
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_edt_7_0_i14,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i14);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__declarative_user__write_edt_node_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i15,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i15);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r5 = MR_stackvar(1);
	r6 = r2;
	r1 = MR_stackvar(5);
	r2 = (Integer) 2;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_edt_7_0_i16,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i16);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_debugger__analyse_edt_7_0_i17);
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const(" :-\n", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i19,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i19);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	r2 = (Integer) 2;
	call_localret(ENTRY(mercury__type_info_from_typeclass_info_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i20,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i20);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__declarative_debugger__analyse_edt_7_0_i21,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i21);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__declarative_debugger__write_children_4_0),
		mercury__declarative_debugger__analyse_edt_7_0_i22,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i22);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = r1;
	r1 = (Integer) 9;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i23,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i23);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r5 = r2;
	r6 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_edt_7_0_i24,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i24);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__declarative_user__write_edt_node_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i25,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i25);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i29,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i17);
	r2 = MR_stackvar(3);
	r1 = (Word) MR_string_const(".\n\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__analyse_edt_7_0_i29,
		STATIC(mercury__declarative_debugger__analyse_edt_7_0));
Define_label(mercury__declarative_debugger__analyse_edt_7_0_i29);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_edt_7_0));
	r2 = MR_stackvar(2);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(declarative_debugger_module13)
	init_entry(mercury__declarative_debugger__analyse_children_8_0);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i1003);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i4);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i5);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i10);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i9);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i7);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i13);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i14);
	init_label(mercury__declarative_debugger__analyse_children_8_0_i3);
BEGIN_CODE

/* code for predicate 'analyse_children'/8 in mode 0 */
Define_static(mercury__declarative_debugger__analyse_children_8_0);
	MR_incr_sp_push_msg(8, "declarative_debugger:analyse_children/8");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__declarative_debugger__analyse_children_8_0_i1003);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i3);
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	r6 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(5) = r6;
	r5 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_children_8_0_i4,
		STATIC(mercury__declarative_debugger__analyse_children_8_0));
Define_label(mercury__declarative_debugger__analyse_children_8_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_children_8_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__declarative_oracle__query_oracle_6_0),
		mercury__declarative_debugger__analyse_children_8_0_i5,
		STATIC(mercury__declarative_debugger__analyse_children_8_0));
Define_label(mercury__declarative_debugger__analyse_children_8_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_children_8_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i7);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i9);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(5);
	r1 = MR_stackvar(7);
	r2 = (Integer) 2;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__analyse_children_8_0_i10,
		STATIC(mercury__declarative_debugger__analyse_children_8_0));
Define_label(mercury__declarative_debugger__analyse_children_8_0_i10);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_children_8_0));
	r3 = r1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__declarative_debugger__analyse_children_8_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i1003);
Define_label(mercury__declarative_debugger__analyse_children_8_0_i9);
	r5 = r2;
	r6 = r3;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i1003);
Define_label(mercury__declarative_debugger__analyse_children_8_0_i7);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__declarative_debugger__analyse_children_8_0, "origin_lost_in_value_number");
	MR_stackvar(5) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(7);
	r2 = (Integer) 2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__type_info_from_typeclass_info_3_0),
		mercury__declarative_debugger__analyse_children_8_0_i13,
		STATIC(mercury__declarative_debugger__analyse_children_8_0));
Define_label(mercury__declarative_debugger__analyse_children_8_0_i13);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_children_8_0));
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__declarative_debugger__analyse_children_8_0_i14,
		STATIC(mercury__declarative_debugger__analyse_children_8_0));
Define_label(mercury__declarative_debugger__analyse_children_8_0_i14);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__analyse_children_8_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__declarative_debugger__analyse_children_8_0_i1003);
Define_label(mercury__declarative_debugger__analyse_children_8_0_i3);
	r1 = r4;
	r2 = r5;
	r3 = r6;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module14)
	init_entry(mercury__declarative_debugger__write_children_4_0);
	init_label(mercury__declarative_debugger__write_children_4_0_i1001);
	init_label(mercury__declarative_debugger__write_children_4_0_i4);
	init_label(mercury__declarative_debugger__write_children_4_0_i5);
	init_label(mercury__declarative_debugger__write_children_4_0_i6);
	init_label(mercury__declarative_debugger__write_children_4_0_i7);
	init_label(mercury__declarative_debugger__write_children_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_children'/4 in mode 0 */
Define_static(mercury__declarative_debugger__write_children_4_0);
	MR_incr_sp_push_msg(5, "declarative_debugger:write_children/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__declarative_debugger__write_children_4_0_i1001);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_debugger__write_children_4_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Integer) 9;
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__declarative_debugger__write_children_4_0_i4,
		STATIC(mercury__declarative_debugger__write_children_4_0));
Define_label(mercury__declarative_debugger__write_children_4_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__write_children_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r5 = MR_stackvar(1);
	r6 = r2;
	r1 = MR_stackvar(4);
	r2 = (Integer) 1;
	r3 = (Integer) 2;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_class_method),
		mercury__declarative_debugger__write_children_4_0_i5,
		STATIC(mercury__declarative_debugger__write_children_4_0));
Define_label(mercury__declarative_debugger__write_children_4_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__write_children_4_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__declarative_user__write_edt_node_3_0),
		mercury__declarative_debugger__write_children_4_0_i6,
		STATIC(mercury__declarative_debugger__write_children_4_0));
Define_label(mercury__declarative_debugger__write_children_4_0_i6);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__write_children_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_debugger__write_children_4_0_i7,
		STATIC(mercury__declarative_debugger__write_children_4_0));
Define_label(mercury__declarative_debugger__write_children_4_0_i7);
	update_prof_current_proc(LABEL(mercury__declarative_debugger__write_children_4_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__declarative_debugger__write_children_4_0_i1001);
Define_label(mercury__declarative_debugger__write_children_4_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module15)
	init_entry(mercury____Unify___declarative_debugger__edt_truth_0_0);
	init_label(mercury____Unify___declarative_debugger__edt_truth_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_debugger__edt_truth_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___declarative_debugger__edt_truth_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_debugger__edt_truth_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_int_2_0);

BEGIN_MODULE(declarative_debugger_module16)
	init_entry(mercury____Index___declarative_debugger__edt_truth_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_debugger__edt_truth_0_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___declarative_debugger__edt_truth_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(declarative_debugger_module17)
	init_entry(mercury____Compare___declarative_debugger__edt_truth_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_debugger__edt_truth_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___declarative_debugger__edt_truth_0_0));
END_MODULE

Declare_entry(mercury____Unify___declarative_execution__trace_atom_0_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(declarative_debugger_module18)
	init_entry(mercury____Unify___declarative_debugger__edt_node_0_0);
	init_label(mercury____Unify___declarative_debugger__edt_node_0_0_i3);
	init_label(mercury____Unify___declarative_debugger__edt_node_0_0_i8);
	init_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1006);
	init_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_debugger__edt_node_0_0);
	MR_incr_sp_push_msg(3, "declarative_debugger:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_debugger__edt_node_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_debugger__edt_node_0_0_i1006);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___declarative_execution__trace_atom_0_0),
		ENTRY(mercury____Unify___declarative_debugger__edt_node_0_0));
Define_label(mercury____Unify___declarative_debugger__edt_node_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___declarative_debugger__edt_node_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___declarative_execution__trace_atom_0_0),
		mercury____Unify___declarative_debugger__edt_node_0_0_i8,
		ENTRY(mercury____Unify___declarative_debugger__edt_node_0_0));
Define_label(mercury____Unify___declarative_debugger__edt_node_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___declarative_debugger__edt_node_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___declarative_debugger__edt_node_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_declarative_execution__type_ctor_info_trace_atom_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___declarative_debugger__edt_node_0_0));
Define_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1006);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___declarative_debugger__edt_node_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module19)
	init_entry(mercury____Index___declarative_debugger__edt_node_0_0);
	init_label(mercury____Index___declarative_debugger__edt_node_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_debugger__edt_node_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___declarative_debugger__edt_node_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___declarative_debugger__edt_node_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___declarative_execution__trace_atom_0_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(declarative_debugger_module20)
	init_entry(mercury____Compare___declarative_debugger__edt_node_0_0);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i3);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i2);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i5);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i4);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i6);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i7);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i11);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i16);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i1015);
	init_label(mercury____Compare___declarative_debugger__edt_node_0_0_i24);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_debugger__edt_node_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i2);
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i4);
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i1015);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___declarative_execution__trace_atom_0_0),
		ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0));
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i1015);
	MR_incr_sp_push_msg(3, "declarative_debugger:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___declarative_execution__trace_atom_0_0),
		mercury____Compare___declarative_debugger__edt_node_0_0_i16,
		ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0));
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Compare___declarative_debugger__edt_node_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___declarative_debugger__edt_node_0_0_i24);
	r1 = (Word) (Word *) &mercury_data_declarative_execution__type_ctor_info_trace_atom_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0));
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i1015);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0));
Define_label(mercury____Compare___declarative_debugger__edt_node_0_0_i24);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module21)
	init_entry(mercury____Unify___declarative_debugger__edt_atom_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_debugger__edt_atom_0_0);
	tailcall(ENTRY(mercury____Unify___declarative_execution__trace_atom_0_0),
		ENTRY(mercury____Unify___declarative_debugger__edt_atom_0_0));
END_MODULE

Declare_entry(mercury____Index___declarative_execution__trace_atom_0_0);

BEGIN_MODULE(declarative_debugger_module22)
	init_entry(mercury____Index___declarative_debugger__edt_atom_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_debugger__edt_atom_0_0);
	tailcall(ENTRY(mercury____Index___declarative_execution__trace_atom_0_0),
		ENTRY(mercury____Index___declarative_debugger__edt_atom_0_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module23)
	init_entry(mercury____Compare___declarative_debugger__edt_atom_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_debugger__edt_atom_0_0);
	tailcall(ENTRY(mercury____Compare___declarative_execution__trace_atom_0_0),
		ENTRY(mercury____Compare___declarative_debugger__edt_atom_0_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module24)
	init_entry(mercury____Unify___declarative_debugger__diagnoser_response_0_0);
	init_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i3);
	init_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_debugger__diagnoser_response_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(STATIC(mercury____Unify___declarative_debugger__edt_node_0_0),
		ENTRY(mercury____Unify___declarative_debugger__diagnoser_response_0_0));
Define_label(mercury____Unify___declarative_debugger__diagnoser_response_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module25)
	init_entry(mercury____Index___declarative_debugger__diagnoser_response_0_0);
	init_label(mercury____Index___declarative_debugger__diagnoser_response_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_debugger__diagnoser_response_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___declarative_debugger__diagnoser_response_0_0_i3);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___declarative_debugger__diagnoser_response_0_0_i3);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module26)
	init_entry(mercury____Compare___declarative_debugger__diagnoser_response_0_0);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i3);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i2);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i5);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i4);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i6);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i7);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i11);
	init_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_debugger__diagnoser_response_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i3);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i2);
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i3);
	r3 = (Integer) 0;
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i5);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i4);
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i5);
	r4 = (Integer) 0;
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(STATIC(mercury____Compare___declarative_debugger__edt_node_0_0),
		ENTRY(mercury____Compare___declarative_debugger__diagnoser_response_0_0));
Define_label(mercury____Compare___declarative_debugger__diagnoser_response_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___declarative_debugger__diagnoser_response_0_0));
END_MODULE

Declare_entry(mercury____Unify___declarative_oracle__oracle_state_0_0);

BEGIN_MODULE(declarative_debugger_module27)
	init_entry(mercury____Unify___declarative_debugger__diagnoser_state_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_debugger__diagnoser_state_0_0);
	tailcall(ENTRY(mercury____Unify___declarative_oracle__oracle_state_0_0),
		ENTRY(mercury____Unify___declarative_debugger__diagnoser_state_0_0));
END_MODULE

Declare_entry(mercury____Index___declarative_oracle__oracle_state_0_0);

BEGIN_MODULE(declarative_debugger_module28)
	init_entry(mercury____Index___declarative_debugger__diagnoser_state_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_debugger__diagnoser_state_0_0);
	tailcall(ENTRY(mercury____Index___declarative_oracle__oracle_state_0_0),
		ENTRY(mercury____Index___declarative_debugger__diagnoser_state_0_0));
END_MODULE

Declare_entry(mercury____Compare___declarative_oracle__oracle_state_0_0);

BEGIN_MODULE(declarative_debugger_module29)
	init_entry(mercury____Compare___declarative_debugger__diagnoser_state_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_debugger__diagnoser_state_0_0);
	tailcall(ENTRY(mercury____Compare___declarative_oracle__oracle_state_0_0),
		ENTRY(mercury____Compare___declarative_debugger__diagnoser_state_0_0));
END_MODULE

Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(declarative_debugger_module30)
	init_entry(mercury____Unify___declarative_debugger__wrap_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___declarative_debugger__wrap_1_0);
	tailcall(ENTRY(mercury__unify_2_0),
		STATIC(mercury____Unify___declarative_debugger__wrap_1_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module31)
	init_entry(mercury____Index___declarative_debugger__wrap_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___declarative_debugger__wrap_1_0);
	tailcall(STATIC(mercury____Index___declarative_debugger__wrap_1__ua0_2_0),
		STATIC(mercury____Index___declarative_debugger__wrap_1_0));
END_MODULE

Declare_entry(mercury__compare_3_3);

BEGIN_MODULE(declarative_debugger_module32)
	init_entry(mercury____Compare___declarative_debugger__wrap_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___declarative_debugger__wrap_1_0);
	tailcall(ENTRY(mercury__compare_3_3),
		STATIC(mercury____Compare___declarative_debugger__wrap_1_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module33)
	init_entry(mercury____Unify___declarative_debugger__declarative_bug_1_0);
	init_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i3);
	init_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___declarative_debugger__declarative_bug_1_0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__declarative_bug_1_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__declarative_bug_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___declarative_debugger__declarative_bug_1_0_i1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	tailcall(ENTRY(mercury__unify_2_0),
		STATIC(mercury____Unify___declarative_debugger__declarative_bug_1_0));
Define_label(mercury____Unify___declarative_debugger__declarative_bug_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_debugger_module34)
	init_entry(mercury____Index___declarative_debugger__declarative_bug_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___declarative_debugger__declarative_bug_1_0);
	r1 = r2;
	tailcall(STATIC(mercury____Index___declarative_debugger__declarative_bug_1__ua0_2_0),
		STATIC(mercury____Index___declarative_debugger__declarative_bug_1_0));
END_MODULE


BEGIN_MODULE(declarative_debugger_module35)
	init_entry(mercury____Compare___declarative_debugger__declarative_bug_1_0);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i3);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i2);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i5);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i4);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i6);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i7);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i11);
	init_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___declarative_debugger__declarative_bug_1_0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i3);
	r4 = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i2);
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i3);
	r4 = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 1;
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i5);
	r5 = r4;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i4);
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i5);
	r5 = r4;
	r4 = (Integer) 1;
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___declarative_debugger__declarative_bug_1_0_i1014);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r5;
	tailcall(ENTRY(mercury__compare_3_3),
		STATIC(mercury____Compare___declarative_debugger__declarative_bug_1_0));
Define_label(mercury____Compare___declarative_debugger__declarative_bug_1_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___declarative_debugger__declarative_bug_1_0));
END_MODULE

Declare_static(mercury__declarative_debugger__diagnosis_store_9_0);

void
MR_DD_decl_diagnosis(Word Mercury__argument1, Word Mercury__argument2, Word Mercury__argument3, Word Mercury__argument4, Word * Mercury__argument5, Word Mercury__argument6, Word * Mercury__argument7)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = Mercury__argument3;
	r4 = Mercury__argument4;
	r5 = Mercury__argument6;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__declarative_debugger__diagnosis_store_9_0), FALSE);
	restore_transient_registers();
	*Mercury__argument5 = r1;
	*Mercury__argument7 = r2;
	restore_regs_from_mem(c_regs);
}


Declare_entry(mercury__declarative_debugger__diagnoser_state_init_1_0);

void
MR_DD_diagnoser_state_init(Word * Mercury__argument1)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__declarative_debugger__diagnoser_state_init_1_0), FALSE);
	restore_transient_registers();
	*Mercury__argument1 = r1;
	restore_regs_from_mem(c_regs);
}


#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__declarative_debugger_maybe_bunch_0(void)
{
	declarative_debugger_module0();
	declarative_debugger_module1();
	declarative_debugger_module2();
	declarative_debugger_module3();
	declarative_debugger_module4();
	declarative_debugger_module5();
	declarative_debugger_module6();
	declarative_debugger_module7();
	declarative_debugger_module8();
	declarative_debugger_module9();
	declarative_debugger_module10();
	declarative_debugger_module11();
	declarative_debugger_module12();
	declarative_debugger_module13();
	declarative_debugger_module14();
	declarative_debugger_module15();
	declarative_debugger_module16();
	declarative_debugger_module17();
	declarative_debugger_module18();
	declarative_debugger_module19();
	declarative_debugger_module20();
	declarative_debugger_module21();
	declarative_debugger_module22();
	declarative_debugger_module23();
	declarative_debugger_module24();
	declarative_debugger_module25();
	declarative_debugger_module26();
	declarative_debugger_module27();
	declarative_debugger_module28();
	declarative_debugger_module29();
	declarative_debugger_module30();
	declarative_debugger_module31();
	declarative_debugger_module32();
	declarative_debugger_module33();
	declarative_debugger_module34();
	declarative_debugger_module35();
}

#endif

void mercury__declarative_debugger__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__declarative_debugger__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__declarative_debugger_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_declarative_bug_1,
			declarative_debugger__declarative_bug_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_diagnoser_response_0,
			declarative_debugger__diagnoser_response_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_diagnoser_state_0,
			declarative_debugger__diagnoser_state_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_edt_atom_0,
			declarative_debugger__edt_atom_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_edt_node_0,
			declarative_debugger__edt_node_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_edt_truth_0,
			declarative_debugger__edt_truth_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_debugger__type_ctor_info_wrap_1,
			declarative_debugger__wrap_1_0);
#ifndef MR_STATIC_CODE_ADDRESSES
		mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__.f4 =
			STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_root_3_3_0);
		mercury_data___base_typeclass_info_declarative_debugger__mercury_edt__arity2__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1__.f5 =
			STATIC(mercury__declarative_debugger__Introduced_pred_for_declarative_debugger__mercury_edt__declarative_debugger__wrap__arity1__declarative_execution__trace_node__arity1______declarative_debugger__edt_children_3_3_0);
#endif /* MR_STATIC_CODE_ADDRESSES */
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
