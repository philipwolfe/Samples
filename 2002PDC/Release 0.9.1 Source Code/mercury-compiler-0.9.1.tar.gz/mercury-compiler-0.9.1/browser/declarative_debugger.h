/*
** Automatically generated from `declarative_debugger.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef DECLARATIVE_DEBUGGER_H
#define DECLARATIVE_DEBUGGER_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void MR_DD_decl_diagnosis(Word, Word, Word, Word, Word *, Word, Word *);
void MR_DD_diagnoser_state_init(Word *);

#ifdef __cplusplus
}
#endif

#endif /* DECLARATIVE_DEBUGGER_H */
