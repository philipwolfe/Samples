/*
** Automatically generated from `declarative_execution.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef DECLARATIVE_EXECUTION_H
#define DECLARATIVE_EXECUTION_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void MR_DD_save_trace(Word, Word, Word);
Word MR_DD_construct_neg_fail_node(Word, Word);
Word MR_DD_construct_neg_succ_node(Word, Word);
Word MR_DD_construct_neg_node(Word, String);
Word MR_DD_construct_else_node(Word, Word);
Word MR_DD_construct_then_node(Word, Word);
Word MR_DD_construct_cond_node(Word, String);
Word MR_DD_construct_later_disj_node(Word, Word, String);
Word MR_DD_construct_first_disj_node(Word, String, Word);
Word MR_DD_construct_fail_node(Word, Word);
Word MR_DD_construct_redo_node(Word, Word);
Word MR_DD_construct_exit_node(Word, Word, Word, Word);
Word MR_DD_construct_call_node(Word, Word);
Word MR_DD_scan_backwards(Word, Word);
String MR_DD_trace_node_path(Word, Word);
Word MR_DD_trace_node_port(Word);

#ifdef __cplusplus
}
#endif

#endif /* DECLARATIVE_EXECUTION_H */
