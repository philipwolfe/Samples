/*
** Automatically generated from `declarative_oracle.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__declarative_oracle__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___declarative_oracle__oracle_assumption_0__ua0_2_0);
Declare_static(mercury____Index___declarative_oracle__oracle_kb_0__ua0_2_0);
Declare_static(mercury____Index___declarative_oracle__oracle_state_0__ua0_2_0);
Define_extern_entry(mercury__declarative_oracle__query_oracle_6_0);
Declare_label(mercury__declarative_oracle__query_oracle_6_0_i3);
Declare_label(mercury__declarative_oracle__query_oracle_6_0_i2);
Declare_label(mercury__declarative_oracle__query_oracle_6_0_i5);
Declare_label(mercury__declarative_oracle__query_oracle_6_0_i8);
Declare_label(mercury__declarative_oracle__query_oracle_6_0_i7);
Define_extern_entry(mercury__declarative_oracle__oracle_state_init_1_0);
Define_extern_entry(mercury____Unify___declarative_oracle__oracle_state_0_0);
Define_extern_entry(mercury____Index___declarative_oracle__oracle_state_0_0);
Define_extern_entry(mercury____Compare___declarative_oracle__oracle_state_0_0);
Define_extern_entry(mercury____Unify___declarative_oracle__oracle_answer_0_0);
Declare_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i3);
Declare_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
Define_extern_entry(mercury____Index___declarative_oracle__oracle_answer_0_0);
Declare_label(mercury____Index___declarative_oracle__oracle_answer_0_0_i3);
Define_extern_entry(mercury____Compare___declarative_oracle__oracle_answer_0_0);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i3);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i2);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i5);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i4);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i6);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i7);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i11);
Declare_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i1014);
Declare_static(mercury____Unify___declarative_oracle__oracle_kb_0_0);
Declare_static(mercury____Index___declarative_oracle__oracle_kb_0_0);
Declare_static(mercury____Compare___declarative_oracle__oracle_kb_0_0);
Declare_static(mercury____Unify___declarative_oracle__oracle_assumption_0_0);
Declare_static(mercury____Index___declarative_oracle__oracle_assumption_0_0);
Declare_static(mercury____Compare___declarative_oracle__oracle_assumption_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_answer_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_assumption_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_kb_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_state_0;

static const struct mercury_data_declarative_oracle__common_0_struct {
	Word * f1;
}  mercury_data_declarative_oracle__common_0;

static const struct mercury_data_declarative_oracle__common_1_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
}  mercury_data_declarative_oracle__common_1;

static const struct mercury_data_declarative_oracle__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_declarative_oracle__common_2;

static const struct mercury_data_declarative_oracle__common_3_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
}  mercury_data_declarative_oracle__common_3;

static const struct mercury_data_declarative_oracle__common_4_struct {
	Word * f1;
}  mercury_data_declarative_oracle__common_4;

static const struct mercury_data_declarative_oracle__common_5_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
}  mercury_data_declarative_oracle__common_5;

static const struct mercury_data_declarative_oracle__common_6_struct {
	Word * f1;
}  mercury_data_declarative_oracle__common_6;

static const struct mercury_data_declarative_oracle__common_7_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_declarative_oracle__common_7;

static const struct mercury_data_declarative_oracle__common_8_struct {
	Word * f1;
}  mercury_data_declarative_oracle__common_8;

static const struct mercury_data_declarative_oracle__common_9_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_declarative_oracle__common_9;

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_state_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_oracle__type_ctor_functors_oracle_state_0;

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_state_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_oracle__type_ctor_layout_oracle_state_0;

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_kb_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_oracle__type_ctor_functors_oracle_kb_0;

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_kb_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_oracle__type_ctor_layout_oracle_kb_0;

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_assumption_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_oracle__type_ctor_functors_oracle_assumption_0;

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_assumption_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_oracle__type_ctor_layout_oracle_assumption_0;

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_answer_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_oracle__type_ctor_functors_oracle_answer_0;

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_answer_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_oracle__type_ctor_layout_oracle_answer_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_answer_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_oracle__oracle_answer_0_0),
	ENTRY(mercury____Index___declarative_oracle__oracle_answer_0_0),
	ENTRY(mercury____Compare___declarative_oracle__oracle_answer_0_0),
	(Integer) 2,
	(Word *) &mercury_data_declarative_oracle__type_ctor_functors_oracle_answer_0,
	(Word *) &mercury_data_declarative_oracle__type_ctor_layout_oracle_answer_0,
	MR_string_const("declarative_oracle", 18),
	MR_string_const("oracle_answer", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_assumption_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___declarative_oracle__oracle_assumption_0_0),
	STATIC(mercury____Index___declarative_oracle__oracle_assumption_0_0),
	STATIC(mercury____Compare___declarative_oracle__oracle_assumption_0_0),
	(Integer) 4,
	(Word *) &mercury_data_declarative_oracle__type_ctor_functors_oracle_assumption_0,
	(Word *) &mercury_data_declarative_oracle__type_ctor_layout_oracle_assumption_0,
	MR_string_const("declarative_oracle", 18),
	MR_string_const("oracle_assumption", 17),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_kb_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___declarative_oracle__oracle_kb_0_0),
	STATIC(mercury____Index___declarative_oracle__oracle_kb_0_0),
	STATIC(mercury____Compare___declarative_oracle__oracle_kb_0_0),
	(Integer) 4,
	(Word *) &mercury_data_declarative_oracle__type_ctor_functors_oracle_kb_0,
	(Word *) &mercury_data_declarative_oracle__type_ctor_layout_oracle_kb_0,
	MR_string_const("declarative_oracle", 18),
	MR_string_const("oracle_kb", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_declarative_oracle__type_ctor_info_oracle_state_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_oracle__oracle_state_0_0),
	ENTRY(mercury____Index___declarative_oracle__oracle_state_0_0),
	ENTRY(mercury____Compare___declarative_oracle__oracle_state_0_0),
	(Integer) 4,
	(Word *) &mercury_data_declarative_oracle__type_ctor_functors_oracle_state_0,
	(Word *) &mercury_data_declarative_oracle__type_ctor_layout_oracle_state_0,
	MR_string_const("declarative_oracle", 18),
	MR_string_const("oracle_state", 12),
	(Integer) 3
};

static const struct mercury_data_declarative_oracle__common_0_struct mercury_data_declarative_oracle__common_0 = {
	(Word *) &mercury_data_declarative_oracle__type_ctor_info_oracle_kb_0
};

static const struct mercury_data_declarative_oracle__common_1_struct mercury_data_declarative_oracle__common_1 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_0),
	MR_string_const("oracle", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_declarative_oracle__common_2_struct mercury_data_declarative_oracle__common_2 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0,
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_declarative_oracle__common_3_struct mercury_data_declarative_oracle__common_3 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_2),
	MR_string_const("oracle_kb", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_declarative_oracle__common_4_struct mercury_data_declarative_oracle__common_4 = {
	(Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0
};

static const struct mercury_data_declarative_oracle__common_5_struct mercury_data_declarative_oracle__common_5 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_4),
	MR_string_const("ground", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_declarative_user__type_ctor_info_user_response_0;
static const struct mercury_data_declarative_oracle__common_6_struct mercury_data_declarative_oracle__common_6 = {
	(Word *) &mercury_data_declarative_user__type_ctor_info_user_response_0
};

static const struct mercury_data_declarative_oracle__common_7_struct mercury_data_declarative_oracle__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_6),
	MR_string_const("deferred", 8),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_oracle__common_8_struct mercury_data_declarative_oracle__common_8 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_declarative_oracle__common_9_struct mercury_data_declarative_oracle__common_9 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_8),
	MR_string_const("truth_value", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_state_0_struct mercury_data_declarative_oracle__type_ctor_functors_oracle_state_0 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_1)
};

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_state_0_struct mercury_data_declarative_oracle__type_ctor_layout_oracle_state_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_1),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_1)
};

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_kb_0_struct mercury_data_declarative_oracle__type_ctor_functors_oracle_kb_0 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_3)
};

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_kb_0_struct mercury_data_declarative_oracle__type_ctor_layout_oracle_kb_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_3)
};

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_assumption_0_struct mercury_data_declarative_oracle__type_ctor_functors_oracle_assumption_0 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_5)
};

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_assumption_0_struct mercury_data_declarative_oracle__type_ctor_layout_oracle_assumption_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_declarative_oracle__common_5)
};

static const struct mercury_data_declarative_oracle__type_ctor_functors_oracle_answer_0_struct mercury_data_declarative_oracle__type_ctor_functors_oracle_answer_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_oracle__common_9)
};

static const struct mercury_data_declarative_oracle__type_ctor_layout_oracle_answer_0_struct mercury_data_declarative_oracle__type_ctor_layout_oracle_answer_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_oracle__common_9),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_oracle__common_7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(declarative_oracle_module0)
	init_entry(mercury____Index___declarative_oracle__oracle_assumption_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___declarative_oracle__oracle_assumption_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___declarative_oracle__oracle_assumption_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_oracle_module1)
	init_entry(mercury____Index___declarative_oracle__oracle_kb_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___declarative_oracle__oracle_kb_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___declarative_oracle__oracle_kb_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_oracle_module2)
	init_entry(mercury____Index___declarative_oracle__oracle_state_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___declarative_oracle__oracle_state_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___declarative_oracle__oracle_state_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__declarative_user__query_user_4_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(declarative_oracle_module3)
	init_entry(mercury__declarative_oracle__query_oracle_6_0);
	init_label(mercury__declarative_oracle__query_oracle_6_0_i3);
	init_label(mercury__declarative_oracle__query_oracle_6_0_i2);
	init_label(mercury__declarative_oracle__query_oracle_6_0_i5);
	init_label(mercury__declarative_oracle__query_oracle_6_0_i8);
	init_label(mercury__declarative_oracle__query_oracle_6_0_i7);
BEGIN_CODE

/* code for predicate 'query_oracle'/6 in mode 0 */
Define_entry(mercury__declarative_oracle__query_oracle_6_0);
	MR_incr_sp_push_msg(4, "declarative_oracle:query_oracle/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = r2;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__declarative_oracle__query_oracle_6_0_i3,
		ENTRY(mercury__declarative_oracle__query_oracle_6_0));
Define_label(mercury__declarative_oracle__query_oracle_6_0_i3);
	update_prof_current_proc(LABEL(mercury__declarative_oracle__query_oracle_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__declarative_oracle__query_oracle_6_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__declarative_oracle__query_oracle_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__declarative_oracle__query_oracle_6_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__declarative_user__query_user_4_0),
		mercury__declarative_oracle__query_oracle_6_0_i5,
		ENTRY(mercury__declarative_oracle__query_oracle_6_0));
Define_label(mercury__declarative_oracle__query_oracle_6_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_oracle__query_oracle_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__declarative_oracle__query_oracle_6_0_i7);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__declarative_oracle__query_oracle_6_0_i8,
		ENTRY(mercury__declarative_oracle__query_oracle_6_0));
Define_label(mercury__declarative_oracle__query_oracle_6_0_i8);
	update_prof_current_proc(LABEL(mercury__declarative_oracle__query_oracle_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__declarative_oracle__query_oracle_6_0_i7);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(declarative_oracle_module4)
	init_entry(mercury__declarative_oracle__oracle_state_init_1_0);
BEGIN_CODE

/* code for predicate 'oracle_state_init'/1 in mode 0 */
Define_entry(mercury__declarative_oracle__oracle_state_init_1_0);
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury__map__init_1_0),
		ENTRY(mercury__declarative_oracle__oracle_state_init_1_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(declarative_oracle_module5)
	init_entry(mercury____Unify___declarative_oracle__oracle_state_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_oracle__oracle_state_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___declarative_oracle__oracle_state_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module6)
	init_entry(mercury____Index___declarative_oracle__oracle_state_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_oracle__oracle_state_0_0);
	tailcall(STATIC(mercury____Index___declarative_oracle__oracle_state_0__ua0_2_0),
		ENTRY(mercury____Index___declarative_oracle__oracle_state_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(declarative_oracle_module7)
	init_entry(mercury____Compare___declarative_oracle__oracle_state_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_oracle__oracle_state_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___declarative_oracle__oracle_state_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module8)
	init_entry(mercury____Unify___declarative_oracle__oracle_answer_0_0);
	init_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i3);
	init_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_oracle__oracle_answer_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_oracle__oracle_answer_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_oracle__oracle_answer_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_oracle_module9)
	init_entry(mercury____Index___declarative_oracle__oracle_answer_0_0);
	init_label(mercury____Index___declarative_oracle__oracle_answer_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_oracle__oracle_answer_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___declarative_oracle__oracle_answer_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___declarative_oracle__oracle_answer_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(declarative_oracle_module10)
	init_entry(mercury____Compare___declarative_oracle__oracle_answer_0_0);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i3);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i2);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i5);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i4);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i6);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i7);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i11);
	init_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_oracle__oracle_answer_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i2);
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i4);
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i1014);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___declarative_oracle__oracle_answer_0_0));
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___declarative_oracle__oracle_answer_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___declarative_oracle__oracle_answer_0_0));
Define_label(mercury____Compare___declarative_oracle__oracle_answer_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___declarative_oracle__oracle_answer_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module11)
	init_entry(mercury____Unify___declarative_oracle__oracle_kb_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___declarative_oracle__oracle_kb_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___declarative_oracle__oracle_kb_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module12)
	init_entry(mercury____Index___declarative_oracle__oracle_kb_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___declarative_oracle__oracle_kb_0_0);
	tailcall(STATIC(mercury____Index___declarative_oracle__oracle_kb_0__ua0_2_0),
		STATIC(mercury____Index___declarative_oracle__oracle_kb_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module13)
	init_entry(mercury____Compare___declarative_oracle__oracle_kb_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___declarative_oracle__oracle_kb_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_declarative_debugger__type_ctor_info_edt_node_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___declarative_oracle__oracle_kb_0_0));
END_MODULE

Declare_entry(mercury____Unify___declarative_debugger__edt_node_0_0);

BEGIN_MODULE(declarative_oracle_module14)
	init_entry(mercury____Unify___declarative_oracle__oracle_assumption_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___declarative_oracle__oracle_assumption_0_0);
	tailcall(ENTRY(mercury____Unify___declarative_debugger__edt_node_0_0),
		STATIC(mercury____Unify___declarative_oracle__oracle_assumption_0_0));
END_MODULE


BEGIN_MODULE(declarative_oracle_module15)
	init_entry(mercury____Index___declarative_oracle__oracle_assumption_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___declarative_oracle__oracle_assumption_0_0);
	tailcall(STATIC(mercury____Index___declarative_oracle__oracle_assumption_0__ua0_2_0),
		STATIC(mercury____Index___declarative_oracle__oracle_assumption_0_0));
END_MODULE

Declare_entry(mercury____Compare___declarative_debugger__edt_node_0_0);

BEGIN_MODULE(declarative_oracle_module16)
	init_entry(mercury____Compare___declarative_oracle__oracle_assumption_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___declarative_oracle__oracle_assumption_0_0);
	tailcall(ENTRY(mercury____Compare___declarative_debugger__edt_node_0_0),
		STATIC(mercury____Compare___declarative_oracle__oracle_assumption_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__declarative_oracle_maybe_bunch_0(void)
{
	declarative_oracle_module0();
	declarative_oracle_module1();
	declarative_oracle_module2();
	declarative_oracle_module3();
	declarative_oracle_module4();
	declarative_oracle_module5();
	declarative_oracle_module6();
	declarative_oracle_module7();
	declarative_oracle_module8();
	declarative_oracle_module9();
	declarative_oracle_module10();
	declarative_oracle_module11();
	declarative_oracle_module12();
	declarative_oracle_module13();
	declarative_oracle_module14();
	declarative_oracle_module15();
	declarative_oracle_module16();
}

#endif

void mercury__declarative_oracle__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__declarative_oracle__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__declarative_oracle_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_oracle__type_ctor_info_oracle_answer_0,
			declarative_oracle__oracle_answer_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_oracle__type_ctor_info_oracle_assumption_0,
			declarative_oracle__oracle_assumption_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_oracle__type_ctor_info_oracle_kb_0,
			declarative_oracle__oracle_kb_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_oracle__type_ctor_info_oracle_state_0,
			declarative_oracle__oracle_state_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
