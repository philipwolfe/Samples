/*
** Automatically generated from `declarative_user.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__declarative_user__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__declarative_user__query_user_4_0);
Declare_label(mercury__declarative_user__query_user_4_0_i1000);
Declare_label(mercury__declarative_user__query_user_4_0_i2);
Declare_label(mercury__declarative_user__query_user_4_0_i3);
Declare_label(mercury__declarative_user__query_user_4_0_i4);
Declare_label(mercury__declarative_user__query_user_4_0_i6);
Declare_label(mercury__declarative_user__query_user_4_0_i7);
Declare_label(mercury__declarative_user__query_user_4_0_i8);
Declare_label(mercury__declarative_user__query_user_4_0_i11);
Declare_label(mercury__declarative_user__query_user_4_0_i12);
Declare_label(mercury__declarative_user__query_user_4_0_i15);
Declare_label(mercury__declarative_user__query_user_4_0_i18);
Declare_label(mercury__declarative_user__query_user_4_0_i21);
Declare_label(mercury__declarative_user__query_user_4_0_i22);
Define_extern_entry(mercury__declarative_user__write_edt_node_3_0);
Declare_label(mercury__declarative_user__write_edt_node_3_0_i4);
Declare_label(mercury__declarative_user__write_edt_node_3_0_i7);
Declare_label(mercury__declarative_user__write_edt_node_3_0_i8);
Declare_label(mercury__declarative_user__write_edt_node_3_0_i9);
Declare_label(mercury__declarative_user__write_edt_node_3_0_i11);
Declare_static(mercury__declarative_user__get_command_4_0);
Declare_label(mercury__declarative_user__get_command_4_0_i1011);
Declare_label(mercury__declarative_user__get_command_4_0_i2);
Declare_label(mercury__declarative_user__get_command_4_0_i19);
Declare_label(mercury__declarative_user__get_command_4_0_i20);
Declare_label(mercury__declarative_user__get_command_4_0_i21);
Declare_label(mercury__declarative_user__get_command_4_0_i22);
Declare_label(mercury__declarative_user__get_command_4_0_i5);
Declare_label(mercury__declarative_user__get_command_4_0_i6);
Declare_label(mercury__declarative_user__get_command_4_0_i10);
Declare_label(mercury__declarative_user__get_command_4_0_i11);
Declare_label(mercury__declarative_user__get_command_4_0_i12);
Declare_label(mercury__declarative_user__get_command_4_0_i13);
Declare_label(mercury__declarative_user__get_command_4_0_i14);
Declare_label(mercury__declarative_user__get_command_4_0_i15);
Declare_label(mercury__declarative_user__get_command_4_0_i16);
Declare_label(mercury__declarative_user__get_command_4_0_i7);
Declare_static(mercury__declarative_user__write_args_rest_3_0);
Declare_label(mercury__declarative_user__write_args_rest_3_0_i1001);
Declare_label(mercury__declarative_user__write_args_rest_3_0_i4);
Declare_label(mercury__declarative_user__write_args_rest_3_0_i5);
Declare_label(mercury__declarative_user__write_args_rest_3_0_i3);
Define_extern_entry(mercury____Unify___declarative_user__user_response_0_0);
Declare_label(mercury____Unify___declarative_user__user_response_0_0_i1);
Define_extern_entry(mercury____Index___declarative_user__user_response_0_0);
Define_extern_entry(mercury____Compare___declarative_user__user_response_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_declarative_user__type_ctor_info_user_response_0;

static const struct mercury_data_declarative_user__common_0_struct {
	Integer f1;
}  mercury_data_declarative_user__common_0;

static const struct mercury_data_declarative_user__common_1_struct {
	Integer f1;
}  mercury_data_declarative_user__common_1;

static const struct mercury_data_declarative_user__common_2_struct {
	Integer f1;
}  mercury_data_declarative_user__common_2;

static const struct mercury_data_declarative_user__common_3_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_3;

static const struct mercury_data_declarative_user__common_4_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_4;

static const struct mercury_data_declarative_user__common_5_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_5;

static const struct mercury_data_declarative_user__common_6_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_6;

static const struct mercury_data_declarative_user__common_7_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_7;

static const struct mercury_data_declarative_user__common_8_struct {
	String f1;
	Word * f2;
}  mercury_data_declarative_user__common_8;

static const struct mercury_data_declarative_user__common_9_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
}  mercury_data_declarative_user__common_9;

static const struct mercury_data_declarative_user__type_ctor_functors_user_response_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_declarative_user__type_ctor_functors_user_response_0;

static const struct mercury_data_declarative_user__type_ctor_layout_user_response_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_declarative_user__type_ctor_layout_user_response_0;

const struct MR_TypeCtorInfo_struct mercury_data_declarative_user__type_ctor_info_user_response_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___declarative_user__user_response_0_0),
	ENTRY(mercury____Index___declarative_user__user_response_0_0),
	ENTRY(mercury____Compare___declarative_user__user_response_0_0),
	(Integer) 0,
	(Word *) &mercury_data_declarative_user__type_ctor_functors_user_response_0,
	(Word *) &mercury_data_declarative_user__type_ctor_layout_user_response_0,
	MR_string_const("declarative_user", 16),
	MR_string_const("user_response", 13),
	(Integer) 3
};

static const struct mercury_data_declarative_user__common_0_struct mercury_data_declarative_user__common_0 = {
	(Integer) 1
};

static const struct mercury_data_declarative_user__common_1_struct mercury_data_declarative_user__common_1 = {
	(Integer) 0
};

static const struct mercury_data_declarative_user__common_2_struct mercury_data_declarative_user__common_2 = {
	(Integer) 3
};

static const struct mercury_data_declarative_user__common_3_struct mercury_data_declarative_user__common_3 = {
	MR_string_const("\th, ?\tthis help message\n", 24),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_declarative_user__common_4_struct mercury_data_declarative_user__common_4 = {
	MR_string_const("\td\tdon't know\n", 14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_3)
};

static const struct mercury_data_declarative_user__common_5_struct mercury_data_declarative_user__common_5 = {
	MR_string_const("\tn\tno\n", 6),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_4)
};

static const struct mercury_data_declarative_user__common_6_struct mercury_data_declarative_user__common_6 = {
	MR_string_const("\ty\tyes\n", 7),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_5)
};

static const struct mercury_data_declarative_user__common_7_struct mercury_data_declarative_user__common_7 = {
	MR_string_const(" of the program, answer one of:\n", 32),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_6)
};

static const struct mercury_data_declarative_user__common_8_struct mercury_data_declarative_user__common_8 = {
	MR_string_const("According to the intended interpretation", 40),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_7)
};

static const struct mercury_data_declarative_user__common_9_struct mercury_data_declarative_user__common_9 = {
	(Integer) 1,
	(Integer) 8,
	MR_string_const("yes", 3),
	MR_string_const("no", 2),
	MR_string_const("inadmissible", 12),
	MR_string_const("do_not_know", 11),
	MR_string_const("browse", 6),
	MR_string_const("tree", 4),
	MR_string_const("help", 4),
	MR_string_const("illegal_command", 15)
};

static const struct mercury_data_declarative_user__type_ctor_functors_user_response_0_struct mercury_data_declarative_user__type_ctor_functors_user_response_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_9)
};

static const struct mercury_data_declarative_user__type_ctor_layout_user_response_0_struct mercury_data_declarative_user__type_ctor_layout_user_response_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_9)
};

Declare_entry(mercury__io__nl_2_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_strings_3_0);

BEGIN_MODULE(declarative_user_module0)
	init_entry(mercury__declarative_user__query_user_4_0);
	init_label(mercury__declarative_user__query_user_4_0_i1000);
	init_label(mercury__declarative_user__query_user_4_0_i2);
	init_label(mercury__declarative_user__query_user_4_0_i3);
	init_label(mercury__declarative_user__query_user_4_0_i4);
	init_label(mercury__declarative_user__query_user_4_0_i6);
	init_label(mercury__declarative_user__query_user_4_0_i7);
	init_label(mercury__declarative_user__query_user_4_0_i8);
	init_label(mercury__declarative_user__query_user_4_0_i11);
	init_label(mercury__declarative_user__query_user_4_0_i12);
	init_label(mercury__declarative_user__query_user_4_0_i15);
	init_label(mercury__declarative_user__query_user_4_0_i18);
	init_label(mercury__declarative_user__query_user_4_0_i21);
	init_label(mercury__declarative_user__query_user_4_0_i22);
BEGIN_CODE

/* code for predicate 'query_user'/4 in mode 0 */
Define_entry(mercury__declarative_user__query_user_4_0);
	MR_incr_sp_push_msg(2, "declarative_user:query_user/4");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__declarative_user__query_user_4_0_i1000);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__declarative_user__write_edt_node_3_0),
		mercury__declarative_user__query_user_4_0_i2,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_user__query_user_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__declarative_user__query_user_4_0_i3,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i3);
	update_prof_current_proc(LABEL(mercury__declarative_user__query_user_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Valid? ", 7);
	call_localret(STATIC(mercury__declarative_user__get_command_4_0),
		mercury__declarative_user__query_user_4_0_i4,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_user__query_user_4_0));
	COMPUTED_GOTO((Unsigned) r1,
		LABEL(mercury__declarative_user__query_user_4_0_i6) AND
		LABEL(mercury__declarative_user__query_user_4_0_i7) AND
		LABEL(mercury__declarative_user__query_user_4_0_i8) AND
		LABEL(mercury__declarative_user__query_user_4_0_i11) AND
		LABEL(mercury__declarative_user__query_user_4_0_i12) AND
		LABEL(mercury__declarative_user__query_user_4_0_i15) AND
		LABEL(mercury__declarative_user__query_user_4_0_i18) AND
		LABEL(mercury__declarative_user__query_user_4_0_i21));
Define_label(mercury__declarative_user__query_user_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__declarative_user__query_user_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_declarative_user__common_1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__declarative_user__query_user_4_0_i8);
	r1 = (Word) MR_string_const("Sorry, not implemented.\n", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__query_user_4_0_i22,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__declarative_user__query_user_4_0_i12);
	r1 = (Word) MR_string_const("Sorry, not implemented.\n", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__query_user_4_0_i22,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i15);
	r1 = (Word) MR_string_const("Sorry, not implemented.\n", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__query_user_4_0_i22,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i18);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_declarative_user__common_8);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__declarative_user__query_user_4_0_i22,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i21);
	r1 = (Word) MR_string_const("Unknown command, 'h' for help.\n", 31);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__query_user_4_0_i22,
		ENTRY(mercury__declarative_user__query_user_4_0));
Define_label(mercury__declarative_user__query_user_4_0_i22);
	update_prof_current_proc(LABEL(mercury__declarative_user__query_user_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__declarative_user__query_user_4_0_i1000);
END_MODULE

Declare_entry(mercury__io__write_char_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_univ_0;
Declare_entry(mercury__io__print_3_0);

BEGIN_MODULE(declarative_user_module1)
	init_entry(mercury__declarative_user__write_edt_node_3_0);
	init_label(mercury__declarative_user__write_edt_node_3_0_i4);
	init_label(mercury__declarative_user__write_edt_node_3_0_i7);
	init_label(mercury__declarative_user__write_edt_node_3_0_i8);
	init_label(mercury__declarative_user__write_edt_node_3_0_i9);
	init_label(mercury__declarative_user__write_edt_node_3_0_i11);
BEGIN_CODE

/* code for predicate 'write_edt_node'/3 in mode 0 */
Define_entry(mercury__declarative_user__write_edt_node_3_0);
	MR_incr_sp_push_msg(3, "declarative_user:write_edt_node/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_mask_field(r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__write_edt_node_3_0_i4,
		ENTRY(mercury__declarative_user__write_edt_node_3_0));
Define_label(mercury__declarative_user__write_edt_node_3_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_edt_node_3_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_user__write_edt_node_3_0_i11);
	r3 = MR_stackvar(1);
	r2 = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Integer) 40;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__declarative_user__write_edt_node_3_0_i7,
		ENTRY(mercury__declarative_user__write_edt_node_3_0));
Define_label(mercury__declarative_user__write_edt_node_3_0_i7);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_edt_node_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__declarative_user__write_edt_node_3_0_i8,
		ENTRY(mercury__declarative_user__write_edt_node_3_0));
Define_label(mercury__declarative_user__write_edt_node_3_0_i8);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_edt_node_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__declarative_user__write_args_rest_3_0),
		mercury__declarative_user__write_edt_node_3_0_i9,
		ENTRY(mercury__declarative_user__write_edt_node_3_0));
Define_label(mercury__declarative_user__write_edt_node_3_0_i9);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_edt_node_3_0));
	r2 = r1;
	r1 = (Integer) 41;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_char_3_0),
		ENTRY(mercury__declarative_user__write_edt_node_3_0));
Define_label(mercury__declarative_user__write_edt_node_3_0_i11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__util__trace_getline_4_0);
Declare_entry(mercury__io__error_message_2_0);
Declare_entry(mercury__string__to_char_list_2_0);

BEGIN_MODULE(declarative_user_module2)
	init_entry(mercury__declarative_user__get_command_4_0);
	init_label(mercury__declarative_user__get_command_4_0_i1011);
	init_label(mercury__declarative_user__get_command_4_0_i2);
	init_label(mercury__declarative_user__get_command_4_0_i19);
	init_label(mercury__declarative_user__get_command_4_0_i20);
	init_label(mercury__declarative_user__get_command_4_0_i21);
	init_label(mercury__declarative_user__get_command_4_0_i22);
	init_label(mercury__declarative_user__get_command_4_0_i5);
	init_label(mercury__declarative_user__get_command_4_0_i6);
	init_label(mercury__declarative_user__get_command_4_0_i10);
	init_label(mercury__declarative_user__get_command_4_0_i11);
	init_label(mercury__declarative_user__get_command_4_0_i12);
	init_label(mercury__declarative_user__get_command_4_0_i13);
	init_label(mercury__declarative_user__get_command_4_0_i14);
	init_label(mercury__declarative_user__get_command_4_0_i15);
	init_label(mercury__declarative_user__get_command_4_0_i16);
	init_label(mercury__declarative_user__get_command_4_0_i7);
BEGIN_CODE

/* code for predicate 'get_command'/4 in mode 0 */
Define_static(mercury__declarative_user__get_command_4_0);
	MR_incr_sp_push_msg(3, "declarative_user:get_command/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__declarative_user__get_command_4_0_i1011);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__util__trace_getline_4_0),
		mercury__declarative_user__get_command_4_0_i2,
		STATIC(mercury__declarative_user__get_command_4_0));
Define_label(mercury__declarative_user__get_command_4_0_i2);
	update_prof_current_proc(LABEL(mercury__declarative_user__get_command_4_0));
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i5);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i19);
	r1 = (Integer) 7;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i19);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__declarative_user__get_command_4_0_i20,
		STATIC(mercury__declarative_user__get_command_4_0));
Define_label(mercury__declarative_user__get_command_4_0_i20);
	update_prof_current_proc(LABEL(mercury__declarative_user__get_command_4_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__get_command_4_0_i21,
		STATIC(mercury__declarative_user__get_command_4_0));
Define_label(mercury__declarative_user__get_command_4_0_i21);
	update_prof_current_proc(LABEL(mercury__declarative_user__get_command_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__declarative_user__get_command_4_0_i22,
		STATIC(mercury__declarative_user__get_command_4_0));
Define_label(mercury__declarative_user__get_command_4_0_i22);
	update_prof_current_proc(LABEL(mercury__declarative_user__get_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__declarative_user__get_command_4_0_i1011);
Define_label(mercury__declarative_user__get_command_4_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__declarative_user__get_command_4_0_i6,
		STATIC(mercury__declarative_user__get_command_4_0));
Define_label(mercury__declarative_user__get_command_4_0_i6);
	update_prof_current_proc(LABEL(mercury__declarative_user__get_command_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 63))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i10);
	r1 = (Integer) 6;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i10);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 98))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i11);
	r1 = (Integer) 4;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i11);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 100))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i12);
	r1 = (Integer) 3;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i12);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 104))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i13);
	r1 = (Integer) 6;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 105))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i14);
	r1 = (Integer) 2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i14);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 110))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i15);
	r1 = (Integer) 1;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i15);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 116))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i16);
	r1 = (Integer) 5;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i16);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 121))
		GOTO_LABEL(mercury__declarative_user__get_command_4_0_i7);
	r1 = (Integer) 0;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__declarative_user__get_command_4_0_i7);
	r1 = (Integer) 7;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_user_module3)
	init_entry(mercury__declarative_user__write_args_rest_3_0);
	init_label(mercury__declarative_user__write_args_rest_3_0_i1001);
	init_label(mercury__declarative_user__write_args_rest_3_0_i4);
	init_label(mercury__declarative_user__write_args_rest_3_0_i5);
	init_label(mercury__declarative_user__write_args_rest_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_args_rest'/3 in mode 0 */
Define_static(mercury__declarative_user__write_args_rest_3_0);
	MR_incr_sp_push_msg(3, "declarative_user:write_args_rest/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__declarative_user__write_args_rest_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__declarative_user__write_args_rest_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__declarative_user__write_args_rest_3_0_i4,
		STATIC(mercury__declarative_user__write_args_rest_3_0));
Define_label(mercury__declarative_user__write_args_rest_3_0_i4);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_args_rest_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_univ_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__declarative_user__write_args_rest_3_0_i5,
		STATIC(mercury__declarative_user__write_args_rest_3_0));
Define_label(mercury__declarative_user__write_args_rest_3_0_i5);
	update_prof_current_proc(LABEL(mercury__declarative_user__write_args_rest_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__declarative_user__write_args_rest_3_0_i1001);
Define_label(mercury__declarative_user__write_args_rest_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(declarative_user_module4)
	init_entry(mercury____Unify___declarative_user__user_response_0_0);
	init_label(mercury____Unify___declarative_user__user_response_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___declarative_user__user_response_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___declarative_user__user_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___declarative_user__user_response_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(declarative_user_module5)
	init_entry(mercury____Index___declarative_user__user_response_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___declarative_user__user_response_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(declarative_user_module6)
	init_entry(mercury____Compare___declarative_user__user_response_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___declarative_user__user_response_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___declarative_user__user_response_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__declarative_user_maybe_bunch_0(void)
{
	declarative_user_module0();
	declarative_user_module1();
	declarative_user_module2();
	declarative_user_module3();
	declarative_user_module4();
	declarative_user_module5();
	declarative_user_module6();
}

#endif

void mercury__declarative_user__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__declarative_user__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__declarative_user_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_declarative_user__type_ctor_info_user_response_0,
			declarative_user__user_response_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
