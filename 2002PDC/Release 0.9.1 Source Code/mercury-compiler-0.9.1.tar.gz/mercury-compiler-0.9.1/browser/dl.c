/*
** Automatically generated from `dl.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__dl__init
ENDINIT
*/

#include "mercury_imp.h"
#line 58 "dl.m"

	#include <stdio.h>
	#include "mercury_conf.h"
#ifdef HAVE_DLFCN_H
	#include <dlfcn.h>
#endif

#line 29 "dl.c"

Declare_static(mercury____Index___dl__closure_0__ua0_2_0);
Declare_static(mercury____Index___dl__closure_layout_0__ua0_2_0);
Declare_static(mercury____Index___dl__handle_0__ua0_2_0);
Define_extern_entry(mercury__dl__open_6_0);
Declare_label(mercury__dl__open_6_0_i4);
Declare_label(mercury__dl__open_6_0_i5);
Declare_label(mercury__dl__open_6_0_i2);
Define_extern_entry(mercury__dl__sym_5_0);
Declare_label(mercury__dl__sym_5_0_i4);
Declare_label(mercury__dl__sym_5_0_i5);
Declare_label(mercury__dl__sym_5_0_i3);
Define_extern_entry(mercury__dl__mercury_sym_5_0);
Declare_label(mercury__dl__mercury_sym_5_0_i2);
Declare_label(mercury__dl__mercury_sym_5_0_i3);
Declare_label(mercury__dl__mercury_sym_5_0_i4);
Declare_label(mercury__dl__mercury_sym_5_0_i9);
Declare_label(mercury__dl__mercury_sym_5_0_i7);
Declare_label(mercury__dl__mercury_sym_5_0_i6);
Declare_label(mercury__dl__mercury_sym_5_0_i22);
Declare_label(mercury__dl__mercury_sym_5_0_i18);
Declare_label(mercury__dl__mercury_sym_5_0_i29);
Declare_label(mercury__dl__mercury_sym_5_0_i25);
Declare_label(mercury__dl__mercury_sym_5_0_i33);
Declare_label(mercury__dl__mercury_sym_5_0_i34);
Declare_label(mercury__dl__mercury_sym_5_0_i35);
Declare_label(mercury__dl__mercury_sym_5_0_i32);
Declare_label(mercury__dl__mercury_sym_5_0_i40);
Declare_label(mercury__dl__mercury_sym_5_0_i41);
Declare_label(mercury__dl__mercury_sym_5_0_i42);
Declare_label(mercury__dl__mercury_sym_5_0_i43);
Define_extern_entry(mercury__dl__close_4_0);
Declare_label(mercury__dl__close_4_0_i2);
Declare_static(mercury__dl__is_null_1_0);
Declare_label(mercury__dl__is_null_1_0_i2);
Declare_static(mercury__dl__dlopen_6_0);
Declare_static(mercury__dl__dlsym_5_0);
Declare_static(mercury__dl__dlerror_3_0);
Declare_static(mercury__dl__dlclose_3_0);
Define_extern_entry(mercury____Unify___dl__mode_0_0);
Declare_label(mercury____Unify___dl__mode_0_0_i1);
Define_extern_entry(mercury____Index___dl__mode_0_0);
Define_extern_entry(mercury____Compare___dl__mode_0_0);
Define_extern_entry(mercury____Unify___dl__scope_0_0);
Declare_label(mercury____Unify___dl__scope_0_0_i1);
Define_extern_entry(mercury____Index___dl__scope_0_0);
Define_extern_entry(mercury____Compare___dl__scope_0_0);
Define_extern_entry(mercury____Unify___dl__handle_0_0);
Define_extern_entry(mercury____Index___dl__handle_0_0);
Define_extern_entry(mercury____Compare___dl__handle_0_0);
Define_extern_entry(mercury____Unify___dl__result_1_0);
Declare_label(mercury____Unify___dl__result_1_0_i3);
Declare_label(mercury____Unify___dl__result_1_0_i1);
Define_extern_entry(mercury____Index___dl__result_1_0);
Declare_label(mercury____Index___dl__result_1_0_i3);
Define_extern_entry(mercury____Compare___dl__result_1_0);
Declare_label(mercury____Compare___dl__result_1_0_i3);
Declare_label(mercury____Compare___dl__result_1_0_i2);
Declare_label(mercury____Compare___dl__result_1_0_i5);
Declare_label(mercury____Compare___dl__result_1_0_i4);
Declare_label(mercury____Compare___dl__result_1_0_i6);
Declare_label(mercury____Compare___dl__result_1_0_i7);
Declare_label(mercury____Compare___dl__result_1_0_i11);
Declare_label(mercury____Compare___dl__result_1_0_i1014);
Define_extern_entry(mercury____Unify___dl__result_0_0);
Declare_label(mercury____Unify___dl__result_0_0_i3);
Declare_label(mercury____Unify___dl__result_0_0_i1);
Define_extern_entry(mercury____Index___dl__result_0_0);
Declare_label(mercury____Index___dl__result_0_0_i3);
Define_extern_entry(mercury____Compare___dl__result_0_0);
Declare_label(mercury____Compare___dl__result_0_0_i3);
Declare_label(mercury____Compare___dl__result_0_0_i2);
Declare_label(mercury____Compare___dl__result_0_0_i5);
Declare_label(mercury____Compare___dl__result_0_0_i4);
Declare_label(mercury____Compare___dl__result_0_0_i6);
Declare_label(mercury____Compare___dl__result_0_0_i7);
Declare_label(mercury____Compare___dl__result_0_0_i11);
Declare_label(mercury____Compare___dl__result_0_0_i1014);
Declare_static(mercury____Unify___dl__closure_layout_0_0);
Declare_label(mercury____Unify___dl__closure_layout_0_0_i1);
Declare_static(mercury____Index___dl__closure_layout_0_0);
Declare_static(mercury____Compare___dl__closure_layout_0_0);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i3);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i7);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i11);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i15);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i19);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i23);
Declare_label(mercury____Compare___dl__closure_layout_0_0_i32);
Declare_static(mercury____Unify___dl__closure_0_0);
Declare_label(mercury____Unify___dl__closure_0_0_i2);
Declare_label(mercury____Unify___dl__closure_0_0_i1016);
Declare_label(mercury____Unify___dl__closure_0_0_i1);
Declare_static(mercury____Index___dl__closure_0_0);
Declare_static(mercury____Compare___dl__closure_0_0);
Declare_label(mercury____Compare___dl__closure_0_0_i3);
Declare_label(mercury____Compare___dl__closure_0_0_i7);
Declare_label(mercury____Compare___dl__closure_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_closure_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_closure_layout_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_handle_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_mode_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_result_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_result_1;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_scope_0;

static const struct mercury_data_dl__common_0_struct {
	String f1;
	Word * f2;
}  mercury_data_dl__common_0;

static const struct mercury_data_dl__common_1_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	Integer f5;
	Integer f6;
	Integer f7;
}  mercury_data_dl__common_1;

static const struct mercury_data_dl__common_2_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_dl__common_2;

static const struct mercury_data_dl__common_3_struct {
	Word * f1;
}  mercury_data_dl__common_3;

static const struct mercury_data_dl__common_4_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_dl__common_4;

static const struct mercury_data_dl__common_5_struct {
	Integer f1;
	Integer f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_dl__common_5;

static const struct mercury_data_dl__common_6_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_dl__common_6;

static const struct mercury_data_dl__common_7_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_dl__common_7;

static const struct mercury_data_dl__common_8_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_dl__common_8;

static const struct mercury_data_dl__common_9_struct {
	Word * f1;
}  mercury_data_dl__common_9;

static const struct mercury_data_dl__common_10_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
}  mercury_data_dl__common_10;

static const struct mercury_data_dl__common_11_struct {
	Word * f1;
}  mercury_data_dl__common_11;

static const struct mercury_data_dl__common_12_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	String f9;
	Word * f10;
	Integer f11;
	Integer f12;
}  mercury_data_dl__common_12;

static const struct mercury_data_dl__common_13_struct {
	Word * f1;
}  mercury_data_dl__common_13;

static const struct mercury_data_dl__common_14_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_dl__common_14;

static const struct mercury_data_dl__type_ctor_functors_scope_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dl__type_ctor_functors_scope_0;

static const struct mercury_data_dl__type_ctor_layout_scope_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_scope_0;

static const struct mercury_data_dl__type_ctor_functors_result_1_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_functors_result_1;

static const struct mercury_data_dl__type_ctor_layout_result_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_result_1;

static const struct mercury_data_dl__type_ctor_functors_result_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_functors_result_0;

static const struct mercury_data_dl__type_ctor_layout_result_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_result_0;

static const struct mercury_data_dl__type_ctor_functors_mode_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dl__type_ctor_functors_mode_0;

static const struct mercury_data_dl__type_ctor_layout_mode_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_mode_0;

static const struct mercury_data_dl__type_ctor_functors_handle_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dl__type_ctor_functors_handle_0;

static const struct mercury_data_dl__type_ctor_layout_handle_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_handle_0;

static const struct mercury_data_dl__type_ctor_functors_closure_layout_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_dl__type_ctor_functors_closure_layout_0;

static const struct mercury_data_dl__type_ctor_layout_closure_layout_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_closure_layout_0;

static const struct mercury_data_dl__type_ctor_functors_closure_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_dl__type_ctor_functors_closure_0;

static const struct mercury_data_dl__type_ctor_layout_closure_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dl__type_ctor_layout_closure_0;

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_closure_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dl__closure_0_0),
	STATIC(mercury____Index___dl__closure_0_0),
	STATIC(mercury____Compare___dl__closure_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dl__type_ctor_functors_closure_0,
	(Word *) &mercury_data_dl__type_ctor_layout_closure_0,
	MR_string_const("dl", 2),
	MR_string_const("closure", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_closure_layout_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dl__closure_layout_0_0),
	STATIC(mercury____Index___dl__closure_layout_0_0),
	STATIC(mercury____Compare___dl__closure_layout_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dl__type_ctor_functors_closure_layout_0,
	(Word *) &mercury_data_dl__type_ctor_layout_closure_layout_0,
	MR_string_const("dl", 2),
	MR_string_const("closure_layout", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_handle_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dl__handle_0_0),
	ENTRY(mercury____Index___dl__handle_0_0),
	ENTRY(mercury____Compare___dl__handle_0_0),
	(Integer) 4,
	(Word *) &mercury_data_dl__type_ctor_functors_handle_0,
	(Word *) &mercury_data_dl__type_ctor_layout_handle_0,
	MR_string_const("dl", 2),
	MR_string_const("handle", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_mode_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dl__mode_0_0),
	ENTRY(mercury____Index___dl__mode_0_0),
	ENTRY(mercury____Compare___dl__mode_0_0),
	(Integer) 0,
	(Word *) &mercury_data_dl__type_ctor_functors_mode_0,
	(Word *) &mercury_data_dl__type_ctor_layout_mode_0,
	MR_string_const("dl", 2),
	MR_string_const("mode", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_result_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dl__result_0_0),
	ENTRY(mercury____Index___dl__result_0_0),
	ENTRY(mercury____Compare___dl__result_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dl__type_ctor_functors_result_0,
	(Word *) &mercury_data_dl__type_ctor_layout_result_0,
	MR_string_const("dl", 2),
	MR_string_const("result", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_result_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___dl__result_1_0),
	ENTRY(mercury____Index___dl__result_1_0),
	ENTRY(mercury____Compare___dl__result_1_0),
	(Integer) 2,
	(Word *) &mercury_data_dl__type_ctor_functors_result_1,
	(Word *) &mercury_data_dl__type_ctor_layout_result_1,
	MR_string_const("dl", 2),
	MR_string_const("result", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dl__type_ctor_info_scope_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dl__scope_0_0),
	ENTRY(mercury____Index___dl__scope_0_0),
	ENTRY(mercury____Compare___dl__scope_0_0),
	(Integer) 0,
	(Word *) &mercury_data_dl__type_ctor_functors_scope_0,
	(Word *) &mercury_data_dl__type_ctor_layout_scope_0,
	MR_string_const("dl", 2),
	MR_string_const("scope", 5),
	(Integer) 3
};

static const struct mercury_data_dl__common_0_struct mercury_data_dl__common_0 = {
	MR_string_const(" arguments(s)", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_dl__common_1_struct mercury_data_dl__common_1 = {
	(Integer) 0,
	MR_string_const("unknown", 7),
	MR_string_const("unknown", 7),
	MR_string_const("unknown", 7),
	(Integer) -1,
	(Integer) -1,
	(Integer) -1
};

static const struct mercury_data_dl__common_2_struct mercury_data_dl__common_2 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("local", 5),
	MR_string_const("global", 6)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_dl__common_3_struct mercury_data_dl__common_3 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_dl__common_4_struct mercury_data_dl__common_4 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_3),
	MR_string_const("error", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dl__common_5_struct mercury_data_dl__common_5 = {
	(Integer) 1,
	(Integer) 1,
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dl__common_6_struct mercury_data_dl__common_6 = {
	(Integer) 0,
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dl__common_7_struct mercury_data_dl__common_7 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("ok", 2)
};

static const struct mercury_data_dl__common_8_struct mercury_data_dl__common_8 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("lazy", 4),
	MR_string_const("now", 3)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_builtin__type_ctor_info_c_pointer_0;
static const struct mercury_data_dl__common_9_struct mercury_data_dl__common_9 = {
	(Word *) &mercury_data_builtin__type_ctor_info_c_pointer_0
};

static const struct mercury_data_dl__common_10_struct mercury_data_dl__common_10 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_9),
	MR_string_const("handle", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_dl__common_11_struct mercury_data_dl__common_11 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_dl__common_12_struct mercury_data_dl__common_12 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_11),
	MR_string_const("closure_layout", 14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dl__common_13_struct mercury_data_dl__common_13 = {
	(Word *) &mercury_data_dl__type_ctor_info_closure_layout_0
};

static const struct mercury_data_dl__common_14_struct mercury_data_dl__common_14 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_11),
	MR_string_const("closure", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dl__type_ctor_functors_scope_0_struct mercury_data_dl__type_ctor_functors_scope_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_2)
};

static const struct mercury_data_dl__type_ctor_layout_scope_0_struct mercury_data_dl__type_ctor_layout_scope_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_2)
};

static const struct mercury_data_dl__type_ctor_functors_result_1_struct mercury_data_dl__type_ctor_functors_result_1 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_5)
};

static const struct mercury_data_dl__type_ctor_layout_result_1_struct mercury_data_dl__type_ctor_layout_result_1 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_5),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_dl__type_ctor_functors_result_0_struct mercury_data_dl__type_ctor_functors_result_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_6)
};

static const struct mercury_data_dl__type_ctor_layout_result_0_struct mercury_data_dl__type_ctor_layout_result_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_7),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_dl__type_ctor_functors_mode_0_struct mercury_data_dl__type_ctor_functors_mode_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_8)
};

static const struct mercury_data_dl__type_ctor_layout_mode_0_struct mercury_data_dl__type_ctor_layout_mode_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_8)
};

static const struct mercury_data_dl__type_ctor_functors_handle_0_struct mercury_data_dl__type_ctor_functors_handle_0 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_10)
};

static const struct mercury_data_dl__type_ctor_layout_handle_0_struct mercury_data_dl__type_ctor_layout_handle_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dl__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dl__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dl__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dl__common_10)
};

static const struct mercury_data_dl__type_ctor_functors_closure_layout_0_struct mercury_data_dl__type_ctor_functors_closure_layout_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_12)
};

static const struct mercury_data_dl__type_ctor_layout_closure_layout_0_struct mercury_data_dl__type_ctor_layout_closure_layout_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_dl__type_ctor_functors_closure_0_struct mercury_data_dl__type_ctor_functors_closure_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_14)
};

static const struct mercury_data_dl__type_ctor_layout_closure_0_struct mercury_data_dl__type_ctor_layout_closure_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(dl_module0)
	init_entry(mercury____Index___dl__closure_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dl__closure_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dl__closure_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module1)
	init_entry(mercury____Index___dl__closure_layout_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dl__closure_layout_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dl__closure_layout_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module2)
	init_entry(mercury____Index___dl__handle_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dl__handle_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dl__handle_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module3)
	init_entry(mercury__dl__open_6_0);
	init_label(mercury__dl__open_6_0_i4);
	init_label(mercury__dl__open_6_0_i5);
	init_label(mercury__dl__open_6_0_i2);
BEGIN_CODE

/* code for predicate 'open'/6 in mode 0 */
Define_entry(mercury__dl__open_6_0);
	MR_incr_sp_push_msg(3, "dl:open/6");
	MR_stackvar(3) = (Word) MR_succip;
	{
	String	FileName;
	Word	Mode;
	Word	Scope;
	Word	Result;
#define MR_PROC_LABEL mercury__dl__open_6_0
	FileName = (String) r1;
	Mode = r2;
	Scope = r3;
	save_registers();
	MR_OBTAIN_GLOBAL_LOCK("dlopen");
{
#line 91 "dl.m"

{
#if defined(HAVE_DLFCN_H) && defined(HAVE_DLOPEN)  && defined(RTLD_NOW) && defined(RTLD_LAZY)
	int mode = (Mode ? RTLD_NOW : RTLD_LAZY);
	/* not all systems have RTLD_GLOBAL */
	#ifdef RTLD_GLOBAL
	  if (Scope) mode |= RTLD_GLOBAL;
	#endif
	Result = (Word) dlopen(FileName, mode);
#else
	Result = (Word) NULL;
#endif
};}
#line 711 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlopen");
#ifndef CONSERVATIVE_GC
	restore_registers();
#endif
	r1 = Result;
#undef MR_PROC_LABEL

	}
	r3 = r1;
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__dl__open_6_0
	Pointer = r1;
{
#line 71 "dl.m"
SUCCESS_INDICATOR = ((void *)Pointer == NULL);}
#line 728 "dl.c"
if (!r1) GOTO_LABEL(mercury__dl__open_6_0_i4);
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__dl__open_6_0_i5);
Define_label(mercury__dl__open_6_0_i4);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	GOTO_LABEL(mercury__dl__open_6_0_i2);
Define_label(mercury__dl__open_6_0_i5);
	{
	String	ErrorMsg;
#define MR_PROC_LABEL mercury__dl__open_6_0
	MR_OBTAIN_GLOBAL_LOCK("dlerror");
{
#line 216 "dl.m"

{
	const char *msg;

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLERROR)
	msg = dlerror();
	if (msg == NULL) msg = "";
#else
	MR_make_aligned_string(msg, "sorry, not implemented: "
		"dynamic linking not supported on this platform");
#endif

	MR_make_aligned_string_copy(ErrorMsg, msg);
};}
#line 759 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlerror");
	r1 = (Word) ErrorMsg;
#undef MR_PROC_LABEL

	}
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__dl__open_6_0, "dl:result/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r4 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dl__open_6_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__dl__open_6_0, "dl:result/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module4)
	init_entry(mercury__dl__sym_5_0);
	init_label(mercury__dl__sym_5_0_i4);
	init_label(mercury__dl__sym_5_0_i5);
	init_label(mercury__dl__sym_5_0_i3);
BEGIN_CODE

/* code for predicate 'sym'/5 in mode 0 */
Define_entry(mercury__dl__sym_5_0);
	MR_incr_sp_push_msg(2, "dl:sym/5");
	{
	Word	Handle;
	String	Name;
	Word	Pointer;
#define MR_PROC_LABEL mercury__dl__sym_5_0
	Handle = r1;
	Name = (String) r2;
	MR_OBTAIN_GLOBAL_LOCK("dlsym");
{
#line 205 "dl.m"

{
#if defined(HAVE_DLFCN_H) && defined(HAVE_DLSYM)
	Pointer = (Word) dlsym((void *) Handle, Name);
#else
	Pointer = (Word) NULL;
#endif
};}
#line 813 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlsym");
	r4 = Pointer;
#undef MR_PROC_LABEL

	}
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__dl__sym_5_0
	Pointer = r4;
{
#line 71 "dl.m"
SUCCESS_INDICATOR = ((void *)Pointer == NULL);}
#line 826 "dl.c"
if (!r1) GOTO_LABEL(mercury__dl__sym_5_0_i4);
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__dl__sym_5_0_i5);
Define_label(mercury__dl__sym_5_0_i4);
	GOTO_LABEL(mercury__dl__sym_5_0_i3);
Define_label(mercury__dl__sym_5_0_i5);
	{
	String	ErrorMsg;
#define MR_PROC_LABEL mercury__dl__sym_5_0
	MR_OBTAIN_GLOBAL_LOCK("dlerror");
{
#line 216 "dl.m"

{
	const char *msg;

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLERROR)
	msg = dlerror();
	if (msg == NULL) msg = "";
#else
	MR_make_aligned_string(msg, "sorry, not implemented: "
		"dynamic linking not supported on this platform");
#endif

	MR_make_aligned_string_copy(ErrorMsg, msg);
};}
#line 855 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlerror");
	r1 = (Word) ErrorMsg;
#undef MR_PROC_LABEL

	}
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__dl__sym_5_0, "dl:result/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__dl__sym_5_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__dl__sym_5_0, "dl:result/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	r2 = r5;
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__fn__std_util__type_of_1_0);
Declare_entry(mercury__fn__std_util__type_ctor_1_0);
Declare_entry(mercury__std_util__type_ctor_name_and_arity_4_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__fn__name_mangle__proc_name_mangle_1_0);

BEGIN_MODULE(dl_module5)
	init_entry(mercury__dl__mercury_sym_5_0);
	init_label(mercury__dl__mercury_sym_5_0_i2);
	init_label(mercury__dl__mercury_sym_5_0_i3);
	init_label(mercury__dl__mercury_sym_5_0_i4);
	init_label(mercury__dl__mercury_sym_5_0_i9);
	init_label(mercury__dl__mercury_sym_5_0_i7);
	init_label(mercury__dl__mercury_sym_5_0_i6);
	init_label(mercury__dl__mercury_sym_5_0_i22);
	init_label(mercury__dl__mercury_sym_5_0_i18);
	init_label(mercury__dl__mercury_sym_5_0_i29);
	init_label(mercury__dl__mercury_sym_5_0_i25);
	init_label(mercury__dl__mercury_sym_5_0_i33);
	init_label(mercury__dl__mercury_sym_5_0_i34);
	init_label(mercury__dl__mercury_sym_5_0_i35);
	init_label(mercury__dl__mercury_sym_5_0_i32);
	init_label(mercury__dl__mercury_sym_5_0_i40);
	init_label(mercury__dl__mercury_sym_5_0_i41);
	init_label(mercury__dl__mercury_sym_5_0_i42);
	init_label(mercury__dl__mercury_sym_5_0_i43);
BEGIN_CODE

/* code for predicate 'mercury_sym'/5 in mode 0 */
Define_entry(mercury__dl__mercury_sym_5_0);
	MR_incr_sp_push_msg(8, "dl:mercury_sym/5");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	call_localret(ENTRY(mercury__fn__std_util__type_of_1_0),
		mercury__dl__mercury_sym_5_0_i2,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	r1 = r2;
	call_localret(ENTRY(mercury__fn__std_util__type_ctor_1_0),
		mercury__dl__mercury_sym_5_0_i3,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	call_localret(ENTRY(mercury__std_util__type_ctor_name_and_arity_4_0),
		mercury__dl__mercury_sym_5_0_i4,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("builtin", 7)) == 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i9);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = r3;
	GOTO_LABEL(mercury__dl__mercury_sym_5_0_i7);
Define_label(mercury__dl__mercury_sym_5_0_i9);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("pred", 4)) == 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i6);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("func", 4)) == 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i6);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = r3;
Define_label(mercury__dl__mercury_sym_5_0_i7);
	r1 = (Word) MR_string_const("dl__mercury_sym: result type is not a higher-order type", 55);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dl__mercury_sym_5_0_i40,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i6);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i18);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("pred", 4)) == 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i18);
	r1 = (Word) MR_string_const("dl__mercury_sym: predicate/function mismatch: ", 46);
	r2 = (Word) MR_string_const("argument is a predicate, result type is a function", 50);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__dl__mercury_sym_5_0_i22,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i22);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dl__mercury_sym_5_0_i40,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i18);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i25);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("func", 4)) == 0))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i25);
	r1 = (Word) MR_string_const("dl__mercury_sym: predicate/function mismatch: ", 46);
	r2 = (Word) MR_string_const("argument is a function, result type is a predicate", 50);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__dl__mercury_sym_5_0_i29,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i29);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dl__mercury_sym_5_0_i40,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i25);
	if ((MR_stackvar(5) == r3))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i32);
	MR_stackvar(7) = r3;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__dl__mercury_sym_5_0_i33,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i33);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__dl__mercury_sym_5_0_i34,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i34);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("dl__mercury_sym: arity mismatch: ", 33);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("argument has ", 13);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" argument(s), ", 14);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("result type has ", 16);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__dl__mercury_sym_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_dl__common_0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__dl__mercury_sym_5_0_i35,
		ENTRY(mercury__dl__mercury_sym_5_0));
	}
Define_label(mercury__dl__mercury_sym_5_0_i35);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dl__mercury_sym_5_0_i40,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i32);
	r1 = MR_stackvar(2);
Define_label(mercury__dl__mercury_sym_5_0_i40);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	call_localret(ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0),
		mercury__dl__mercury_sym_5_0_i41,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i41);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__dl__sym_5_0),
		mercury__dl__mercury_sym_5_0_i42,
		ENTRY(mercury__dl__mercury_sym_5_0));
Define_label(mercury__dl__mercury_sym_5_0_i42);
	update_prof_current_proc(LABEL(mercury__dl__mercury_sym_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dl__mercury_sym_5_0_i43);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__dl__mercury_sym_5_0, "dl:result/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__dl__mercury_sym_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dl__common_1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	}
Define_label(mercury__dl__mercury_sym_5_0_i43);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module6)
	init_entry(mercury__dl__close_4_0);
	init_label(mercury__dl__close_4_0_i2);
BEGIN_CODE

/* code for predicate 'close'/4 in mode 0 */
Define_entry(mercury__dl__close_4_0);
	MR_incr_sp_push_msg(1, "dl:close/4");
	MR_stackvar(1) = (Word) MR_succip;
	{
	Word	Handle;
#define MR_PROC_LABEL mercury__dl__close_4_0
	Handle = r1;
	save_registers();
	MR_OBTAIN_GLOBAL_LOCK("dlclose");
{
#line 242 "dl.m"

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLCLOSE)
	dlclose((void *)Handle)
#endif
;}
#line 1082 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlclose");
#ifndef CONSERVATIVE_GC
	restore_registers();
#endif
#undef MR_PROC_LABEL

	}
	{
	String	ErrorMsg;
#define MR_PROC_LABEL mercury__dl__close_4_0
	MR_OBTAIN_GLOBAL_LOCK("dlerror");
{
#line 216 "dl.m"

{
	const char *msg;

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLERROR)
	msg = dlerror();
	if (msg == NULL) msg = "";
#else
	MR_make_aligned_string(msg, "sorry, not implemented: "
		"dynamic linking not supported on this platform");
#endif

	MR_make_aligned_string_copy(ErrorMsg, msg);
};}
#line 1110 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlerror");
	r2 = (Word) ErrorMsg;
#undef MR_PROC_LABEL

	}
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__dl__close_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__dl__close_4_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__dl__close_4_0, "dl:result/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r4 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module7)
	init_entry(mercury__dl__is_null_1_0);
	init_label(mercury__dl__is_null_1_0_i2);
BEGIN_CODE

/* code for predicate 'is_null'/1 in mode 0 */
Define_static(mercury__dl__is_null_1_0);
	r2 = r1;
	{
	Word	Pointer;
#define MR_PROC_LABEL mercury__dl__is_null_1_0
	Pointer = r1;
{
#line 71 "dl.m"
SUCCESS_INDICATOR = ((void *)Pointer == NULL);}
#line 1149 "dl.c"
if (!r1) GOTO_LABEL(mercury__dl__is_null_1_0_i2);
#undef MR_PROC_LABEL

	}
	r1 = TRUE;
	proceed();
Define_label(mercury__dl__is_null_1_0_i2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module8)
	init_entry(mercury__dl__dlopen_6_0);
BEGIN_CODE

/* code for predicate 'dlopen'/6 in mode 0 */
Define_static(mercury__dl__dlopen_6_0);
	MR_incr_sp_push_msg(1, "dl:dlopen/6");
	MR_stackvar(1) = (Word) MR_succip;
	{
	String	FileName;
	Word	Mode;
	Word	Scope;
	Word	Result;
#define MR_PROC_LABEL mercury__dl__dlopen_6_0
	FileName = (String) r1;
	Mode = r2;
	Scope = r3;
	save_registers();
	MR_OBTAIN_GLOBAL_LOCK("dlopen");
{
#line 91 "dl.m"

{
#if defined(HAVE_DLFCN_H) && defined(HAVE_DLOPEN)  && defined(RTLD_NOW) && defined(RTLD_LAZY)
	int mode = (Mode ? RTLD_NOW : RTLD_LAZY);
	/* not all systems have RTLD_GLOBAL */
	#ifdef RTLD_GLOBAL
	  if (Scope) mode |= RTLD_GLOBAL;
	#endif
	Result = (Word) dlopen(FileName, mode);
#else
	Result = (Word) NULL;
#endif
};}
#line 1196 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlopen");
#ifndef CONSERVATIVE_GC
	restore_registers();
#endif
	r1 = Result;
#undef MR_PROC_LABEL

	}
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module9)
	init_entry(mercury__dl__dlsym_5_0);
BEGIN_CODE

/* code for predicate 'dlsym'/5 in mode 0 */
Define_static(mercury__dl__dlsym_5_0);
	{
	Word	Handle;
	String	Name;
	Word	Pointer;
#define MR_PROC_LABEL mercury__dl__dlsym_5_0
	Handle = r1;
	Name = (String) r2;
	MR_OBTAIN_GLOBAL_LOCK("dlsym");
{
#line 205 "dl.m"

{
#if defined(HAVE_DLFCN_H) && defined(HAVE_DLSYM)
	Pointer = (Word) dlsym((void *) Handle, Name);
#else
	Pointer = (Word) NULL;
#endif
};}
#line 1235 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlsym");
	r4 = Pointer;
#undef MR_PROC_LABEL

	}
	r1 = r4;
	r2 = r5;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module10)
	init_entry(mercury__dl__dlerror_3_0);
BEGIN_CODE

/* code for predicate 'dlerror'/3 in mode 0 */
Define_static(mercury__dl__dlerror_3_0);
	{
	String	ErrorMsg;
#define MR_PROC_LABEL mercury__dl__dlerror_3_0
	MR_OBTAIN_GLOBAL_LOCK("dlerror");
{
#line 216 "dl.m"

{
	const char *msg;

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLERROR)
	msg = dlerror();
	if (msg == NULL) msg = "";
#else
	MR_make_aligned_string(msg, "sorry, not implemented: "
		"dynamic linking not supported on this platform");
#endif

	MR_make_aligned_string_copy(ErrorMsg, msg);
};}
#line 1273 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlerror");
	r2 = (Word) ErrorMsg;
#undef MR_PROC_LABEL

	}
	r1 = r2;
	r4 = r2;
	r2 = r3;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module11)
	init_entry(mercury__dl__dlclose_3_0);
BEGIN_CODE

/* code for predicate 'dlclose'/3 in mode 0 */
Define_static(mercury__dl__dlclose_3_0);
	MR_incr_sp_push_msg(1, "dl:dlclose/3");
	MR_stackvar(1) = (Word) MR_succip;
	{
	Word	Handle;
#define MR_PROC_LABEL mercury__dl__dlclose_3_0
	Handle = r1;
	save_registers();
	MR_OBTAIN_GLOBAL_LOCK("dlclose");
{
#line 242 "dl.m"

#if defined(HAVE_DLFCN_H) && defined(HAVE_DLCLOSE)
	dlclose((void *)Handle)
#endif
;}
#line 1307 "dl.c"
	MR_RELEASE_GLOBAL_LOCK("dlclose");
#ifndef CONSERVATIVE_GC
	restore_registers();
#endif
#undef MR_PROC_LABEL

	}
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module12)
	init_entry(mercury____Unify___dl__mode_0_0);
	init_label(mercury____Unify___dl__mode_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dl__mode_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___dl__mode_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__mode_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module13)
	init_entry(mercury____Index___dl__mode_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dl__mode_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(dl_module14)
	init_entry(mercury____Compare___dl__mode_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dl__mode_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___dl__mode_0_0));
END_MODULE


BEGIN_MODULE(dl_module15)
	init_entry(mercury____Unify___dl__scope_0_0);
	init_label(mercury____Unify___dl__scope_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dl__scope_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___dl__scope_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__scope_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module16)
	init_entry(mercury____Index___dl__scope_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dl__scope_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module17)
	init_entry(mercury____Compare___dl__scope_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dl__scope_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___dl__scope_0_0));
END_MODULE

Declare_entry(mercury____Unify___builtin__c_pointer_0_0);

BEGIN_MODULE(dl_module18)
	init_entry(mercury____Unify___dl__handle_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dl__handle_0_0);
	tailcall(ENTRY(mercury____Unify___builtin__c_pointer_0_0),
		ENTRY(mercury____Unify___dl__handle_0_0));
END_MODULE


BEGIN_MODULE(dl_module19)
	init_entry(mercury____Index___dl__handle_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dl__handle_0_0);
	tailcall(STATIC(mercury____Index___dl__handle_0__ua0_2_0),
		ENTRY(mercury____Index___dl__handle_0_0));
END_MODULE

Declare_entry(mercury____Compare___builtin__c_pointer_0_0);

BEGIN_MODULE(dl_module20)
	init_entry(mercury____Compare___dl__handle_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dl__handle_0_0);
	tailcall(ENTRY(mercury____Compare___builtin__c_pointer_0_0),
		ENTRY(mercury____Compare___dl__handle_0_0));
END_MODULE

Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(dl_module21)
	init_entry(mercury____Unify___dl__result_1_0);
	init_label(mercury____Unify___dl__result_1_0_i3);
	init_label(mercury____Unify___dl__result_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dl__result_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___dl__result_1_0_i3);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___dl__result_1_0_i1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___dl__result_1_0));
Define_label(mercury____Unify___dl__result_1_0_i3);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___dl__result_1_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r2, (Integer) 0), (char *)MR_const_field(MR_mktag(1), r3, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___dl__result_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__result_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module22)
	init_entry(mercury____Index___dl__result_1_0);
	init_label(mercury____Index___dl__result_1_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dl__result_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___dl__result_1_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___dl__result_1_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__compare_3_3);
Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(dl_module23)
	init_entry(mercury____Compare___dl__result_1_0);
	init_label(mercury____Compare___dl__result_1_0_i3);
	init_label(mercury____Compare___dl__result_1_0_i2);
	init_label(mercury____Compare___dl__result_1_0_i5);
	init_label(mercury____Compare___dl__result_1_0_i4);
	init_label(mercury____Compare___dl__result_1_0_i6);
	init_label(mercury____Compare___dl__result_1_0_i7);
	init_label(mercury____Compare___dl__result_1_0_i11);
	init_label(mercury____Compare___dl__result_1_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dl__result_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i3);
	r4 = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dl__result_1_0_i2);
Define_label(mercury____Compare___dl__result_1_0_i3);
	r4 = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 1;
Define_label(mercury____Compare___dl__result_1_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i5);
	r5 = r4;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dl__result_1_0_i4);
Define_label(mercury____Compare___dl__result_1_0_i5);
	r5 = r4;
	r4 = (Integer) 1;
Define_label(mercury____Compare___dl__result_1_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___dl__result_1_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___dl__result_1_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i1014);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = r5;
	tailcall(ENTRY(mercury__compare_3_3),
		ENTRY(mercury____Compare___dl__result_1_0));
Define_label(mercury____Compare___dl__result_1_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___dl__result_1_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___dl__result_1_0));
Define_label(mercury____Compare___dl__result_1_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___dl__result_1_0));
END_MODULE


BEGIN_MODULE(dl_module24)
	init_entry(mercury____Unify___dl__result_0_0);
	init_label(mercury____Unify___dl__result_0_0_i3);
	init_label(mercury____Unify___dl__result_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dl__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___dl__result_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___dl__result_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__result_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___dl__result_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(1), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___dl__result_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__result_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module25)
	init_entry(mercury____Index___dl__result_0_0);
	init_label(mercury____Index___dl__result_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dl__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___dl__result_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___dl__result_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module26)
	init_entry(mercury____Compare___dl__result_0_0);
	init_label(mercury____Compare___dl__result_0_0_i3);
	init_label(mercury____Compare___dl__result_0_0_i2);
	init_label(mercury____Compare___dl__result_0_0_i5);
	init_label(mercury____Compare___dl__result_0_0_i4);
	init_label(mercury____Compare___dl__result_0_0_i6);
	init_label(mercury____Compare___dl__result_0_0_i7);
	init_label(mercury____Compare___dl__result_0_0_i11);
	init_label(mercury____Compare___dl__result_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dl__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dl__result_0_0_i2);
Define_label(mercury____Compare___dl__result_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___dl__result_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dl__result_0_0_i4);
Define_label(mercury____Compare___dl__result_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___dl__result_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___dl__result_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___dl__result_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___dl__result_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___dl__result_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___dl__result_0_0));
Define_label(mercury____Compare___dl__result_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___dl__result_0_0));
END_MODULE


BEGIN_MODULE(dl_module27)
	init_entry(mercury____Unify___dl__closure_layout_0_0);
	init_label(mercury____Unify___dl__closure_layout_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dl__closure_layout_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 1), (char *)MR_const_field(MR_mktag(0), r2, (Integer) 1)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 2), (char *)MR_const_field(MR_mktag(0), r2, (Integer) 2)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 3), (char *)MR_const_field(MR_mktag(0), r2, (Integer) 3)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 4) != MR_const_field(MR_mktag(0), r2, (Integer) 4)))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 5) != MR_const_field(MR_mktag(0), r2, (Integer) 5)))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 6) != MR_const_field(MR_mktag(0), r2, (Integer) 6)))
		GOTO_LABEL(mercury____Unify___dl__closure_layout_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dl__closure_layout_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dl_module28)
	init_entry(mercury____Index___dl__closure_layout_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dl__closure_layout_0_0);
	tailcall(STATIC(mercury____Index___dl__closure_layout_0__ua0_2_0),
		STATIC(mercury____Index___dl__closure_layout_0_0));
END_MODULE


BEGIN_MODULE(dl_module29)
	init_entry(mercury____Compare___dl__closure_layout_0_0);
	init_label(mercury____Compare___dl__closure_layout_0_0_i3);
	init_label(mercury____Compare___dl__closure_layout_0_0_i7);
	init_label(mercury____Compare___dl__closure_layout_0_0_i11);
	init_label(mercury____Compare___dl__closure_layout_0_0_i15);
	init_label(mercury____Compare___dl__closure_layout_0_0_i19);
	init_label(mercury____Compare___dl__closure_layout_0_0_i23);
	init_label(mercury____Compare___dl__closure_layout_0_0_i32);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dl__closure_layout_0_0);
	MR_incr_sp_push_msg(13, "dl:__Compare__/3");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___dl__closure_layout_0_0_i3,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___dl__closure_layout_0_0_i7,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___dl__closure_layout_0_0_i11,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___dl__closure_layout_0_0_i15,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___dl__closure_layout_0_0_i19,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___dl__closure_layout_0_0_i23,
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_layout_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_layout_0_0_i32);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___dl__closure_layout_0_0));
Define_label(mercury____Compare___dl__closure_layout_0_0_i32);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module30)
	init_entry(mercury____Unify___dl__closure_0_0);
	init_label(mercury____Unify___dl__closure_0_0_i2);
	init_label(mercury____Unify___dl__closure_0_0_i1016);
	init_label(mercury____Unify___dl__closure_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dl__closure_0_0);
	MR_incr_sp_push_msg(3, "dl:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0) != MR_const_field(MR_mktag(0), r3, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1), (char *)MR_const_field(MR_mktag(0), r3, (Integer) 1)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2), (char *)MR_const_field(MR_mktag(0), r3, (Integer) 2)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3), (char *)MR_const_field(MR_mktag(0), r3, (Integer) 3)) != 0))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4) != MR_const_field(MR_mktag(0), r3, (Integer) 4)))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5) != MR_const_field(MR_mktag(0), r3, (Integer) 5)))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	if ((MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6) != MR_const_field(MR_mktag(0), r3, (Integer) 6)))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1016);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___builtin__c_pointer_0_0),
		mercury____Unify___dl__closure_0_0_i2,
		STATIC(mercury____Unify___dl__closure_0_0));
	}
Define_label(mercury____Unify___dl__closure_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___dl__closure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___dl__closure_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___dl__closure_0_0_i1016);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___dl__closure_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(dl_module31)
	init_entry(mercury____Index___dl__closure_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dl__closure_0_0);
	tailcall(STATIC(mercury____Index___dl__closure_0__ua0_2_0),
		STATIC(mercury____Index___dl__closure_0_0));
END_MODULE


BEGIN_MODULE(dl_module32)
	init_entry(mercury____Compare___dl__closure_0_0);
	init_label(mercury____Compare___dl__closure_0_0_i3);
	init_label(mercury____Compare___dl__closure_0_0_i7);
	init_label(mercury____Compare___dl__closure_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dl__closure_0_0);
	MR_incr_sp_push_msg(5, "dl:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury____Compare___dl__closure_layout_0_0),
		mercury____Compare___dl__closure_0_0_i3,
		STATIC(mercury____Compare___dl__closure_0_0));
Define_label(mercury____Compare___dl__closure_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_0_0_i12);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___builtin__c_pointer_0_0),
		mercury____Compare___dl__closure_0_0_i7,
		STATIC(mercury____Compare___dl__closure_0_0));
Define_label(mercury____Compare___dl__closure_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___dl__closure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dl__closure_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___dl__closure_0_0));
Define_label(mercury____Compare___dl__closure_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__dl_maybe_bunch_0(void)
{
	dl_module0();
	dl_module1();
	dl_module2();
	dl_module3();
	dl_module4();
	dl_module5();
	dl_module6();
	dl_module7();
	dl_module8();
	dl_module9();
	dl_module10();
	dl_module11();
	dl_module12();
	dl_module13();
	dl_module14();
	dl_module15();
	dl_module16();
	dl_module17();
	dl_module18();
	dl_module19();
	dl_module20();
	dl_module21();
	dl_module22();
	dl_module23();
	dl_module24();
	dl_module25();
	dl_module26();
	dl_module27();
	dl_module28();
	dl_module29();
	dl_module30();
	dl_module31();
	dl_module32();
}

#endif

void mercury__dl__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__dl__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__dl_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_closure_0,
			dl__closure_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_closure_layout_0,
			dl__closure_layout_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_handle_0,
			dl__handle_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_mode_0,
			dl__mode_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_result_0,
			dl__result_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_result_1,
			dl__result_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dl__type_ctor_info_scope_0,
			dl__scope_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
