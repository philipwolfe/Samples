/*
** Automatically generated from `frame.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__frame__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__frame__hsize_2_0);
Declare_label(mercury__frame__hsize_2_0_i2);
Define_extern_entry(mercury__frame__vsize_2_0);
Define_extern_entry(mercury__frame__from_string_2_0);
Define_extern_entry(mercury__frame__vglue_3_0);
Define_extern_entry(mercury__frame__hglue_3_0);
Declare_label(mercury__frame__hglue_3_0_i2);
Declare_label(mercury__frame__hglue_3_0_i3);
Declare_label(mercury__frame__hglue_3_0_i5);
Declare_label(mercury__frame__hglue_3_0_i6);
Declare_label(mercury__frame__hglue_3_0_i4);
Declare_label(mercury__frame__hglue_3_0_i8);
Declare_label(mercury__frame__hglue_3_0_i9);
Declare_label(mercury__frame__hglue_3_0_i7);
Declare_label(mercury__frame__hglue_3_0_i11);
Declare_label(mercury__frame__hglue_3_0_i12);
Declare_label(mercury__frame__hglue_3_0_i13);
Declare_label(mercury__frame__hglue_3_0_i14);
Declare_label(mercury__frame__hglue_3_0_i15);
Define_extern_entry(mercury__frame__clip_3_0);
Declare_label(mercury__frame__clip_3_0_i2);
Declare_static(mercury__frame__add_right_padding_3_0);
Declare_label(mercury__frame__add_right_padding_3_0_i2);
Declare_label(mercury__frame__add_right_padding_3_0_i8);
Declare_label(mercury__frame__add_right_padding_3_0_i9);
Declare_label(mercury__frame__add_right_padding_3_0_i10);
Declare_label(mercury__frame__add_right_padding_3_0_i11);
Declare_label(mercury__frame__add_right_padding_3_0_i5);
Declare_static(mercury__frame__subtract_3_0);
Declare_static(mercury__frame__left_3_0);
Define_extern_entry(mercury____Unify___frame__frame_0_0);
Define_extern_entry(mercury____Index___frame__frame_0_0);
Define_extern_entry(mercury____Compare___frame__frame_0_0);
Define_extern_entry(mercury____Unify___frame__clip_rect_0_0);
Define_extern_entry(mercury____Index___frame__clip_rect_0_0);
Define_extern_entry(mercury____Compare___frame__clip_rect_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_frame__type_ctor_info_clip_rect_0;

const struct MR_TypeCtorInfo_struct mercury_data_frame__type_ctor_info_frame_0;

static const struct mercury_data_frame__common_0_struct {
	Word * f1;
}  mercury_data_frame__common_0;

static const struct mercury_data_frame__common_1_struct {
	Word * f1;
}  mercury_data_frame__common_1;

static const struct mercury_data_frame__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_frame__common_2;

static const struct mercury_data_frame__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_frame__common_3;

static const struct mercury_data_frame__common_4_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_frame__common_4;

static const struct mercury_data_frame__common_5_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_frame__common_5;

static const struct mercury_data_frame__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_frame__common_6;

static const struct mercury_data_frame__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_frame__common_7;

static const struct mercury_data_frame__common_8_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_frame__common_8;

static const struct mercury_data_frame__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_frame__common_9;

static const struct mercury_data_frame__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frame__common_10;

static const struct mercury_data_frame__common_11_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frame__common_11;

static const struct mercury_data_frame__common_12_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_frame__common_12;

static const struct mercury_data_frame__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frame__common_13;

static const struct mercury_data_frame__type_ctor_functors_frame_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frame__type_ctor_functors_frame_0;

static const struct mercury_data_frame__type_ctor_layout_frame_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frame__type_ctor_layout_frame_0;

static const struct mercury_data_frame__type_ctor_functors_clip_rect_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frame__type_ctor_functors_clip_rect_0;

static const struct mercury_data_frame__type_ctor_layout_clip_rect_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frame__type_ctor_layout_clip_rect_0;

const struct MR_TypeCtorInfo_struct mercury_data_frame__type_ctor_info_clip_rect_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___frame__clip_rect_0_0),
	ENTRY(mercury____Index___frame__clip_rect_0_0),
	ENTRY(mercury____Compare___frame__clip_rect_0_0),
	(Integer) 6,
	(Word *) &mercury_data_frame__type_ctor_functors_clip_rect_0,
	(Word *) &mercury_data_frame__type_ctor_layout_clip_rect_0,
	MR_string_const("frame", 5),
	MR_string_const("clip_rect", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_frame__type_ctor_info_frame_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___frame__frame_0_0),
	ENTRY(mercury____Index___frame__frame_0_0),
	ENTRY(mercury____Compare___frame__frame_0_0),
	(Integer) 6,
	(Word *) &mercury_data_frame__type_ctor_functors_frame_0,
	(Word *) &mercury_data_frame__type_ctor_layout_frame_0,
	MR_string_const("frame", 5),
	MR_string_const("frame", 5),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_frame__common_0_struct mercury_data_frame__common_0 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_frame__common_1_struct mercury_data_frame__common_1 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_frame__common_2_struct mercury_data_frame__common_2 = {
	(Integer) 0,
	MR_string_const("string", 6),
	MR_string_const("string", 6),
	MR_string_const("length", 6),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1)
};

Declare_entry(mercury__string__length_2_0);
static const struct mercury_data_frame__common_3_struct mercury_data_frame__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_2),
	ENTRY(mercury__string__length_2_0),
	(Integer) 0
};

static const struct mercury_data_frame__common_4_struct mercury_data_frame__common_4 = {
	(Integer) 0,
	MR_string_const("int", 3),
	MR_string_const("int", 3),
	MR_string_const("max", 3),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1)
};

Declare_entry(mercury__int__max_3_0);
static const struct mercury_data_frame__common_5_struct mercury_data_frame__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_4),
	ENTRY(mercury__int__max_3_0),
	(Integer) 0
};

static const struct mercury_data_frame__common_6_struct mercury_data_frame__common_6 = {
	(Integer) 0,
	MR_string_const("frame", 5),
	MR_string_const("frame", 5),
	MR_string_const("subtract", 8),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1)
};

static const struct mercury_data_frame__common_7_struct mercury_data_frame__common_7 = {
	(Integer) 0,
	MR_string_const("string", 6),
	MR_string_const("string", 6),
	MR_string_const("append", 6),
	3,
	2,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0)
};

Declare_entry(mercury__string__append_3_2);
static const struct mercury_data_frame__common_8_struct mercury_data_frame__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_7),
	ENTRY(mercury__string__append_3_2),
	(Integer) 0
};

static const struct mercury_data_frame__common_9_struct mercury_data_frame__common_9 = {
	(Integer) 0,
	MR_string_const("frame", 5),
	MR_string_const("frame", 5),
	MR_string_const("left", 4),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_frame__common_10_struct mercury_data_frame__common_10 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_frame__common_11_struct mercury_data_frame__common_11 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_10)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_frame__common_12_struct mercury_data_frame__common_12 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_frame__common_13_struct mercury_data_frame__common_13 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_12)
};

static const struct mercury_data_frame__type_ctor_functors_frame_0_struct mercury_data_frame__type_ctor_functors_frame_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_10)
};

static const struct mercury_data_frame__type_ctor_layout_frame_0_struct mercury_data_frame__type_ctor_layout_frame_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_11)
};

static const struct mercury_data_frame__type_ctor_functors_clip_rect_0_struct mercury_data_frame__type_ctor_functors_clip_rect_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_12)
};

static const struct mercury_data_frame__type_ctor_layout_clip_rect_0_struct mercury_data_frame__type_ctor_layout_clip_rect_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frame__common_13)
};

Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(frame_module0)
	init_entry(mercury__frame__hsize_2_0);
	init_label(mercury__frame__hsize_2_0_i2);
BEGIN_CODE

/* code for predicate 'hsize'/2 in mode 0 */
Define_entry(mercury__frame__hsize_2_0);
	MR_incr_sp_push_msg(1, "frame:hsize/2");
	MR_stackvar(1) = (Word) MR_succip;
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__frame__hsize_2_0_i2,
		ENTRY(mercury__frame__hsize_2_0));
Define_label(mercury__frame__hsize_2_0_i2);
	update_prof_current_proc(LABEL(mercury__frame__hsize_2_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_5);
	r5 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		ENTRY(mercury__frame__hsize_2_0));
END_MODULE

Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(frame_module1)
	init_entry(mercury__frame__vsize_2_0);
BEGIN_CODE

/* code for predicate 'vsize'/2 in mode 0 */
Define_entry(mercury__frame__vsize_2_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury__list__length_2_0),
		ENTRY(mercury__frame__vsize_2_0));
END_MODULE


BEGIN_MODULE(frame_module2)
	init_entry(mercury__frame__from_string_2_0);
BEGIN_CODE

/* code for predicate 'from_string'/2 in mode 0 */
Define_entry(mercury__frame__from_string_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frame__from_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(frame_module3)
	init_entry(mercury__frame__vglue_3_0);
BEGIN_CODE

/* code for predicate 'vglue'/3 in mode 0 */
Define_entry(mercury__frame__vglue_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__frame__vglue_3_0));
END_MODULE

Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__util__zip_with_4_0);

BEGIN_MODULE(frame_module4)
	init_entry(mercury__frame__hglue_3_0);
	init_label(mercury__frame__hglue_3_0_i2);
	init_label(mercury__frame__hglue_3_0_i3);
	init_label(mercury__frame__hglue_3_0_i5);
	init_label(mercury__frame__hglue_3_0_i6);
	init_label(mercury__frame__hglue_3_0_i4);
	init_label(mercury__frame__hglue_3_0_i8);
	init_label(mercury__frame__hglue_3_0_i9);
	init_label(mercury__frame__hglue_3_0_i7);
	init_label(mercury__frame__hglue_3_0_i11);
	init_label(mercury__frame__hglue_3_0_i12);
	init_label(mercury__frame__hglue_3_0_i13);
	init_label(mercury__frame__hglue_3_0_i14);
	init_label(mercury__frame__hglue_3_0_i15);
BEGIN_CODE

/* code for predicate 'hglue'/3 in mode 0 */
Define_entry(mercury__frame__hglue_3_0);
	MR_incr_sp_push_msg(4, "frame:hglue/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__frame__hglue_3_0_i2,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i2);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__frame__hglue_3_0_i3,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i3);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury__frame__hglue_3_0_i4);
	r2 = ((Integer) r1 - (Integer) MR_stackvar(3));
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__frame__hglue_3_0_i5,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i5);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frame__hglue_3_0_i6,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i6);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_3);
	GOTO_LABEL(mercury__frame__hglue_3_0_i11);
Define_label(mercury__frame__hglue_3_0_i4);
	if (((Integer) r1 >= (Integer) MR_stackvar(3)))
		GOTO_LABEL(mercury__frame__hglue_3_0_i7);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = ((Integer) MR_stackvar(3) - (Integer) MR_tempr2);
	r3 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__frame__hglue_3_0_i8,
		ENTRY(mercury__frame__hglue_3_0));
	}
Define_label(mercury__frame__hglue_3_0_i8);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frame__hglue_3_0_i9,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i9);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_3);
	MR_stackvar(1) = MR_stackvar(2);
	GOTO_LABEL(mercury__frame__hglue_3_0_i11);
Define_label(mercury__frame__hglue_3_0_i7);
	r4 = MR_stackvar(1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_3);
	MR_stackvar(1) = MR_stackvar(2);
Define_label(mercury__frame__hglue_3_0_i11);
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__frame__hglue_3_0_i12,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i12);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r4 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_5);
	r5 = (Integer) 0;
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__frame__hglue_3_0_i13,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i13);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__frame__hglue_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__frame__subtract_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_6);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__frame__hglue_3_0_i14,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i14);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__frame__add_right_padding_3_0),
		mercury__frame__hglue_3_0_i15,
		ENTRY(mercury__frame__hglue_3_0));
Define_label(mercury__frame__hglue_3_0_i15);
	update_prof_current_proc(LABEL(mercury__frame__hglue_3_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_8);
	r6 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__util__zip_with_4_0),
		ENTRY(mercury__frame__hglue_3_0));
END_MODULE

Declare_entry(mercury__list__take_upto_3_0);

BEGIN_MODULE(frame_module5)
	init_entry(mercury__frame__clip_3_0);
	init_label(mercury__frame__clip_3_0_i2);
BEGIN_CODE

/* code for predicate 'clip'/3 in mode 0 */
Define_entry(mercury__frame__clip_3_0);
	MR_incr_sp_push_msg(2, "frame:clip/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__list__take_upto_3_0),
		mercury__frame__clip_3_0_i2,
		ENTRY(mercury__frame__clip_3_0));
Define_label(mercury__frame__clip_3_0_i2);
	update_prof_current_proc(LABEL(mercury__frame__clip_3_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__frame__clip_3_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__frame__left_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frame__common_9);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__map_3_0),
		ENTRY(mercury__frame__clip_3_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
Declare_entry(mercury__string__from_char_list_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(frame_module6)
	init_entry(mercury__frame__add_right_padding_3_0);
	init_label(mercury__frame__add_right_padding_3_0_i2);
	init_label(mercury__frame__add_right_padding_3_0_i8);
	init_label(mercury__frame__add_right_padding_3_0_i9);
	init_label(mercury__frame__add_right_padding_3_0_i10);
	init_label(mercury__frame__add_right_padding_3_0_i11);
	init_label(mercury__frame__add_right_padding_3_0_i5);
BEGIN_CODE

/* code for predicate 'add_right_padding'/3 in mode 0 */
Define_static(mercury__frame__add_right_padding_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frame__add_right_padding_3_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frame__add_right_padding_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__frame__add_right_padding_3_0_i2);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frame__add_right_padding_3_0_i5);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frame__add_right_padding_3_0_i5);
	MR_incr_sp_push_msg(4, "frame:add_right_padding/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_character_0;
	r3 = (Integer) 32;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__frame__add_right_padding_3_0_i8,
		STATIC(mercury__frame__add_right_padding_3_0));
Define_label(mercury__frame__add_right_padding_3_0_i8);
	update_prof_current_proc(LABEL(mercury__frame__add_right_padding_3_0));
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__frame__add_right_padding_3_0_i9,
		STATIC(mercury__frame__add_right_padding_3_0));
Define_label(mercury__frame__add_right_padding_3_0_i9);
	update_prof_current_proc(LABEL(mercury__frame__add_right_padding_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__frame__add_right_padding_3_0_i10,
		STATIC(mercury__frame__add_right_padding_3_0));
Define_label(mercury__frame__add_right_padding_3_0_i10);
	update_prof_current_proc(LABEL(mercury__frame__add_right_padding_3_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	localcall(mercury__frame__add_right_padding_3_0,
		LABEL(mercury__frame__add_right_padding_3_0_i11),
		STATIC(mercury__frame__add_right_padding_3_0));
Define_label(mercury__frame__add_right_padding_3_0_i11);
	update_prof_current_proc(LABEL(mercury__frame__add_right_padding_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frame__add_right_padding_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frame__add_right_padding_3_0_i5);
	r1 = (Word) MR_string_const("add_right_padding: list arguments are of unequal length", 55);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frame__add_right_padding_3_0));
END_MODULE


BEGIN_MODULE(frame_module7)
	init_entry(mercury__frame__subtract_3_0);
BEGIN_CODE

/* code for predicate 'subtract'/3 in mode 0 */
Define_static(mercury__frame__subtract_3_0);
	r1 = ((Integer) r1 - (Integer) r2);
	proceed();
END_MODULE

Declare_entry(mercury__string__left_3_0);

BEGIN_MODULE(frame_module8)
	init_entry(mercury__frame__left_3_0);
BEGIN_CODE

/* code for predicate 'left'/3 in mode 0 */
Define_static(mercury__frame__left_3_0);
	r3 = r1;
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury__string__left_3_0),
		STATIC(mercury__frame__left_3_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(frame_module9)
	init_entry(mercury____Unify___frame__frame_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___frame__frame_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___frame__frame_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(frame_module10)
	init_entry(mercury____Index___frame__frame_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___frame__frame_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___frame__frame_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(frame_module11)
	init_entry(mercury____Compare___frame__frame_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___frame__frame_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___frame__frame_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(frame_module12)
	init_entry(mercury____Unify___frame__clip_rect_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___frame__clip_rect_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___frame__clip_rect_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(frame_module13)
	init_entry(mercury____Index___frame__clip_rect_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___frame__clip_rect_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___frame__clip_rect_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(frame_module14)
	init_entry(mercury____Compare___frame__clip_rect_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___frame__clip_rect_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___frame__clip_rect_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__frame_maybe_bunch_0(void)
{
	frame_module0();
	frame_module1();
	frame_module2();
	frame_module3();
	frame_module4();
	frame_module5();
	frame_module6();
	frame_module7();
	frame_module8();
	frame_module9();
	frame_module10();
	frame_module11();
	frame_module12();
	frame_module13();
	frame_module14();
}

#endif

void mercury__frame__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__frame__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__frame_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frame__type_ctor_info_clip_rect_0,
			frame__clip_rect_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frame__type_ctor_info_frame_0,
			frame__frame_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
