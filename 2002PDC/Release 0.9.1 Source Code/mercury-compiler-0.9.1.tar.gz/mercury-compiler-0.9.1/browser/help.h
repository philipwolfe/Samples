/*
** Automatically generated from `help.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef HELP_H
#define HELP_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

bool ML_HELP_result_is_error(Word, String *);
void ML_HELP_help_system_type(Word *);
void ML_HELP_name(Word, String, Word);
void ML_HELP_path(Word, Word, Word, Word *);
void ML_HELP_help(Word, Word);
void ML_HELP_add_help_node(Word, Word, Integer, String, String, Word *, Word *);
void ML_HELP_init(Word *);

#ifdef __cplusplus
}
#endif

#endif /* HELP_H */
