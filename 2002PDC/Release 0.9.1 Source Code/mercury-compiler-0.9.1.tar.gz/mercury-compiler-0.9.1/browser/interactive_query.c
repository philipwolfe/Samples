/*
** Automatically generated from `interactive_query.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__interactive_query__init
ENDINIT
*/

#include "mercury_imp.h"
#include "interactive_query.h"

#line 23 "interactive_query.c"
#line 445 "interactive_query.m"
#include "mercury_grade.h"
#line 26 "interactive_query.c"

Declare_static(mercury____Index___interactive_query__prog_0__ua0_2_0);
Define_extern_entry(mercury__interactive_query__query_7_0);
Declare_label(mercury__interactive_query__query_7_0_i1004);
Declare_label(mercury__interactive_query__query_7_0_i3);
Declare_label(mercury__interactive_query__query_7_0_i4);
Declare_label(mercury__interactive_query__query_7_0_i2);
Declare_label(mercury__interactive_query__query_7_0_i5);
Declare_label(mercury__interactive_query__query_7_0_i11);
Declare_label(mercury__interactive_query__query_7_0_i12);
Declare_label(mercury__interactive_query__query_7_0_i13);
Declare_label(mercury__interactive_query__query_7_0_i14);
Declare_label(mercury__interactive_query__query_7_0_i8);
Declare_label(mercury__interactive_query__query_7_0_i9);
Define_extern_entry(mercury__interactive_query__query_external_7_0);
Declare_label(mercury__interactive_query__query_external_7_0_i1015);
Declare_label(mercury__interactive_query__query_external_7_0_i2);
Declare_label(mercury__interactive_query__query_external_7_0_i3);
Declare_label(mercury__interactive_query__query_external_7_0_i4);
Declare_label(mercury__interactive_query__query_external_7_0_i12);
Declare_label(mercury__interactive_query__query_external_7_0_i18);
Declare_label(mercury__interactive_query__query_external_7_0_i19);
Declare_label(mercury__interactive_query__query_external_7_0_i13);
Declare_label(mercury__interactive_query__query_external_7_0_i30);
Declare_label(mercury__interactive_query__query_external_7_0_i31);
Declare_label(mercury__interactive_query__query_external_7_0_i21);
Declare_label(mercury__interactive_query__query_external_7_0_i36);
Declare_label(mercury__interactive_query__query_external_7_0_i38);
Declare_label(mercury__interactive_query__query_external_7_0_i39);
Declare_label(mercury__interactive_query__query_external_7_0_i34);
Declare_label(mercury__interactive_query__query_external_7_0_i41);
Declare_label(mercury__interactive_query__query_external_7_0_i7);
Declare_label(mercury__interactive_query__query_external_7_0_i8);
Declare_label(mercury__interactive_query__query_external_7_0_i9);
Declare_label(mercury__interactive_query__query_external_7_0_i10);
Declare_static(mercury__interactive_query__query_2_8_0);
Declare_label(mercury__interactive_query__query_2_8_0_i8);
Declare_label(mercury__interactive_query__query_2_8_0_i9);
Declare_label(mercury__interactive_query__query_2_8_0_i24);
Declare_label(mercury__interactive_query__query_2_8_0_i25);
Declare_label(mercury__interactive_query__query_2_8_0_i15);
Declare_label(mercury__interactive_query__query_2_8_0_i30);
Declare_label(mercury__interactive_query__query_2_8_0_i32);
Declare_label(mercury__interactive_query__query_2_8_0_i33);
Declare_label(mercury__interactive_query__query_2_8_0_i34);
Declare_label(mercury__interactive_query__query_2_8_0_i35);
Declare_label(mercury__interactive_query__query_2_8_0_i28);
Declare_label(mercury__interactive_query__query_2_8_0_i4);
Declare_label(mercury__interactive_query__query_2_8_0_i5);
Declare_label(mercury__interactive_query__query_2_8_0_i6);
Declare_static(mercury__interactive_query__send_term_to_socket_4_0);
Declare_label(mercury__interactive_query__send_term_to_socket_4_0_i2);
Declare_label(mercury__interactive_query__send_term_to_socket_4_0_i3);
Declare_static(mercury__interactive_query__term_to_list_2_0);
Declare_label(mercury__interactive_query__term_to_list_2_0_i5);
Declare_label(mercury__interactive_query__term_to_list_2_0_i13);
Declare_label(mercury__interactive_query__term_to_list_2_0_i1015);
Declare_label(mercury__interactive_query__term_to_list_2_0_i1);
Declare_static(mercury__interactive_query__run_query_4_0);
Declare_label(mercury__interactive_query__run_query_4_0_i2);
Declare_label(mercury__interactive_query__run_query_4_0_i5);
Declare_label(mercury__interactive_query__run_query_4_0_i6);
Declare_label(mercury__interactive_query__run_query_4_0_i8);
Declare_label(mercury__interactive_query__run_query_4_0_i9);
Declare_label(mercury__interactive_query__run_query_4_0_i10);
Declare_label(mercury__interactive_query__run_query_4_0_i11);
Declare_label(mercury__interactive_query__run_query_4_0_i12);
Declare_label(mercury__interactive_query__run_query_4_0_i7);
Declare_label(mercury__interactive_query__run_query_4_0_i14);
Declare_label(mercury__interactive_query__run_query_4_0_i15);
Declare_label(mercury__interactive_query__run_query_4_0_i16);
Declare_label(mercury__interactive_query__run_query_4_0_i17);
Declare_label(mercury__interactive_query__run_query_4_0_i18);
Declare_label(mercury__interactive_query__run_query_4_0_i21);
Declare_label(mercury__interactive_query__run_query_4_0_i19);
Declare_label(mercury__interactive_query__run_query_4_0_i3);
Declare_static(mercury__interactive_query__write_prog_to_stream_3_0);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i2);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i3);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i4);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i5);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i8);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i9);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i10);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i11);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i12);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i13);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i14);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i15);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i16);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i17);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i18);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i19);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i20);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i21);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i22);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i23);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i24);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i25);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i26);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i27);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i7);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i31);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i32);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i33);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i34);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i35);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i36);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i37);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i38);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i39);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i40);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i41);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i30);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i44);
Declare_label(mercury__interactive_query__write_prog_to_stream_3_0_i45);
Declare_static(mercury__interactive_query__write_line_directive_2_0);
Declare_label(mercury__interactive_query__write_line_directive_2_0_i2);
Declare_label(mercury__interactive_query__write_line_directive_2_0_i3);
Declare_label(mercury__interactive_query__write_line_directive_2_0_i4);
Declare_static(mercury__interactive_query__write_code_to_print_one_var_4_0);
Declare_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i2);
Declare_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i3);
Declare_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i4);
Declare_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i5);
Declare_static(mercury__interactive_query__write_args_4_0);
Declare_label(mercury__interactive_query__write_args_4_0_i6);
Declare_label(mercury__interactive_query__write_args_4_0_i7);
Declare_label(mercury__interactive_query__write_args_4_0_i3);
Declare_static(mercury__interactive_query__write_one_var_4_0);
Declare_static(mercury__interactive_query__write_import_list_4_0);
Declare_label(mercury__interactive_query__write_import_list_4_0_i2);
Declare_label(mercury__interactive_query__write_import_list_4_0_i3);
Declare_static(mercury__interactive_query__compile_file_4_0);
Declare_label(mercury__interactive_query__compile_file_4_0_i2);
Declare_label(mercury__interactive_query__compile_file_4_0_i5);
Declare_label(mercury__interactive_query__compile_file_4_0_i6);
Declare_label(mercury__interactive_query__compile_file_4_0_i7);
Declare_label(mercury__interactive_query__compile_file_4_0_i8);
Declare_label(mercury__interactive_query__compile_file_4_0_i3);
Declare_label(mercury__interactive_query__compile_file_4_0_i10);
Declare_label(mercury__interactive_query__compile_file_4_0_i16);
Declare_label(mercury__interactive_query__compile_file_4_0_i14);
Declare_label(mercury__interactive_query__compile_file_4_0_i11);
Declare_label(mercury__interactive_query__compile_file_4_0_i18);
Declare_label(mercury__interactive_query__compile_file_4_0_i21);
Declare_label(mercury__interactive_query__compile_file_4_0_i23);
Declare_label(mercury__interactive_query__compile_file_4_0_i26);
Declare_label(mercury__interactive_query__compile_file_4_0_i24);
Declare_static(mercury__fn__interactive_query__grade_option_0_0);
Declare_static(mercury__interactive_query__invoke_system_command_4_0);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i4);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i5);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i6);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i7);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i8);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i9);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i15);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i13);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i10);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i17);
Declare_label(mercury__interactive_query__invoke_system_command_4_0_i20);
Declare_static(mercury__interactive_query__dynamically_load_and_run_2_0);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i2);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i5);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i7);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i9);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i10);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i11);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i12);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i14);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i15);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i4);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i18);
Declare_label(mercury__interactive_query__dynamically_load_and_run_2_0_i19);
Declare_static(mercury__fn__interactive_query__inst_cast_1_0);
Define_extern_entry(mercury____Unify___interactive_query__query_type_0_0);
Declare_label(mercury____Unify___interactive_query__query_type_0_0_i1);
Define_extern_entry(mercury____Index___interactive_query__query_type_0_0);
Define_extern_entry(mercury____Compare___interactive_query__query_type_0_0);
Define_extern_entry(mercury____Unify___interactive_query__imports_0_0);
Define_extern_entry(mercury____Index___interactive_query__imports_0_0);
Define_extern_entry(mercury____Compare___interactive_query__imports_0_0);
Define_extern_entry(mercury____Unify___interactive_query__options_0_0);
Declare_label(mercury____Unify___interactive_query__options_0_0_i1);
Define_extern_entry(mercury____Index___interactive_query__options_0_0);
Define_extern_entry(mercury____Compare___interactive_query__options_0_0);
Declare_static(mercury____Unify___interactive_query__prog_0_0);
Declare_label(mercury____Unify___interactive_query__prog_0_0_i2);
Declare_label(mercury____Unify___interactive_query__prog_0_0_i4);
Declare_label(mercury____Unify___interactive_query__prog_0_0_i1004);
Declare_label(mercury____Unify___interactive_query__prog_0_0_i1);
Declare_static(mercury____Index___interactive_query__prog_0_0);
Declare_static(mercury____Compare___interactive_query__prog_0_0);
Declare_label(mercury____Compare___interactive_query__prog_0_0_i3);
Declare_label(mercury____Compare___interactive_query__prog_0_0_i7);
Declare_label(mercury____Compare___interactive_query__prog_0_0_i11);
Declare_label(mercury____Compare___interactive_query__prog_0_0_i17);
Declare_static(mercury____Unify___interactive_query__interactive_query_response_0_0);
Declare_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i10);
Declare_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i12);
Declare_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i8);
Declare_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i4);
Declare_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
Declare_static(mercury____Index___interactive_query__interactive_query_response_0_0);
Declare_label(mercury____Index___interactive_query__interactive_query_response_0_0_i6);
Declare_label(mercury____Index___interactive_query__interactive_query_response_0_0_i7);
Declare_label(mercury____Index___interactive_query__interactive_query_response_0_0_i5);
Declare_label(mercury____Index___interactive_query__interactive_query_response_0_0_i4);
Declare_static(mercury____Compare___interactive_query__interactive_query_response_0_0);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i6);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i7);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i5);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i4);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i12);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i13);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i11);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i10);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i14);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i15);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i26);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i28);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i23);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i20);
Declare_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
Declare_static(mercury____Unify___interactive_query__io_pred_0_0);
Declare_static(mercury____Index___interactive_query__io_pred_0_0);
Declare_static(mercury____Compare___interactive_query__io_pred_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_imports_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_io_pred_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_options_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_prog_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_query_type_0;

static const struct mercury_data_interactive_query__common_0_struct {
	Word * f1;
}  mercury_data_interactive_query__common_0;

static const struct mercury_data_interactive_query__common_1_struct {
	Word * f1;
}  mercury_data_interactive_query__common_1;

static const struct mercury_data_interactive_query__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_interactive_query__common_2;

static const struct mercury_data_interactive_query__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_interactive_query__common_3;

static const struct mercury_data_interactive_query__common_4_struct {
	String f1;
	Word * f2;
}  mercury_data_interactive_query__common_4;

static const struct mercury_data_interactive_query__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_interactive_query__common_5;

static const struct mercury_data_interactive_query__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_interactive_query__common_6;

static const struct mercury_data_interactive_query__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_interactive_query__common_7;

static const struct mercury_data_interactive_query__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_interactive_query__common_8;

static const struct mercury_data_interactive_query__common_9_struct {
	String f1;
	Word * f2;
}  mercury_data_interactive_query__common_9;

static const struct mercury_data_interactive_query__common_10_struct {
	String f1;
	Word * f2;
}  mercury_data_interactive_query__common_10;

static const struct mercury_data_interactive_query__common_11_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__common_11;

static const struct mercury_data_interactive_query__common_12_struct {
	String f1;
}  mercury_data_interactive_query__common_12;

static const struct mercury_data_interactive_query__common_13_struct {
	Integer f1;
	Word * f2;
	String f3;
	Integer f4;
	Integer f5;
}  mercury_data_interactive_query__common_13;

static const struct mercury_data_interactive_query__common_14_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_interactive_query__common_14;

static const struct mercury_data_interactive_query__common_15_struct {
	Word * f1;
}  mercury_data_interactive_query__common_15;

static const struct mercury_data_interactive_query__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_interactive_query__common_16;

static const struct mercury_data_interactive_query__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_interactive_query__common_17;

static const struct mercury_data_interactive_query__common_18_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_interactive_query__common_18;

static const struct mercury_data_interactive_query__common_19_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__common_19;

static const struct mercury_data_interactive_query__common_20_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__common_20;

static const struct mercury_data_interactive_query__common_21_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_interactive_query__common_21;

static const struct mercury_data_interactive_query__common_22_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_interactive_query__common_22;

static const struct mercury_data_interactive_query__common_23_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_interactive_query__common_23;

static const struct mercury_data_interactive_query__common_24_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_interactive_query__common_24;

static const struct mercury_data_interactive_query__common_25_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_interactive_query__common_25;

static const struct mercury_data_interactive_query__common_26_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_interactive_query__common_26;

static const struct mercury_data_interactive_query__common_27_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__common_27;

static const struct mercury_data_interactive_query__type_ctor_functors_query_type_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__type_ctor_functors_query_type_0;

static const struct mercury_data_interactive_query__type_ctor_layout_query_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_query_type_0;

static const struct mercury_data_interactive_query__type_ctor_functors_prog_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_interactive_query__type_ctor_functors_prog_0;

static const struct mercury_data_interactive_query__type_ctor_layout_prog_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_prog_0;

static const struct mercury_data_interactive_query__type_ctor_functors_options_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__type_ctor_functors_options_0;

static const struct mercury_data_interactive_query__type_ctor_layout_options_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_options_0;

static const struct mercury_data_interactive_query__type_ctor_functors_io_pred_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__type_ctor_functors_io_pred_0;

static const struct mercury_data_interactive_query__type_ctor_layout_io_pred_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_io_pred_0;

static const struct mercury_data_interactive_query__type_ctor_functors_interactive_query_response_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_interactive_query__type_ctor_functors_interactive_query_response_0;

static const struct mercury_data_interactive_query__type_ctor_layout_interactive_query_response_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_interactive_query_response_0;

static const struct mercury_data_interactive_query__type_ctor_functors_imports_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_interactive_query__type_ctor_functors_imports_0;

static const struct mercury_data_interactive_query__type_ctor_layout_imports_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_interactive_query__type_ctor_layout_imports_0;

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_imports_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___interactive_query__imports_0_0),
	ENTRY(mercury____Index___interactive_query__imports_0_0),
	ENTRY(mercury____Compare___interactive_query__imports_0_0),
	(Integer) 6,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_imports_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_imports_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("imports", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_interactive_query_response_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___interactive_query__interactive_query_response_0_0),
	STATIC(mercury____Index___interactive_query__interactive_query_response_0_0),
	STATIC(mercury____Compare___interactive_query__interactive_query_response_0_0),
	(Integer) 2,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_interactive_query_response_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_interactive_query_response_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("interactive_query_response", 26),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_io_pred_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___interactive_query__io_pred_0_0),
	STATIC(mercury____Index___interactive_query__io_pred_0_0),
	STATIC(mercury____Compare___interactive_query__io_pred_0_0),
	(Integer) 6,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_io_pred_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_io_pred_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("io_pred", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_options_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___interactive_query__options_0_0),
	ENTRY(mercury____Index___interactive_query__options_0_0),
	ENTRY(mercury____Compare___interactive_query__options_0_0),
	(Integer) 6,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_options_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_options_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("options", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_prog_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___interactive_query__prog_0_0),
	STATIC(mercury____Index___interactive_query__prog_0_0),
	STATIC(mercury____Compare___interactive_query__prog_0_0),
	(Integer) 2,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_prog_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_prog_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("prog", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_interactive_query__type_ctor_info_query_type_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___interactive_query__query_type_0_0),
	ENTRY(mercury____Index___interactive_query__query_type_0_0),
	ENTRY(mercury____Compare___interactive_query__query_type_0_0),
	(Integer) 0,
	(Word *) &mercury_data_interactive_query__type_ctor_functors_query_type_0,
	(Word *) &mercury_data_interactive_query__type_ctor_layout_query_type_0,
	MR_string_const("interactive_query", 17),
	MR_string_const("query_type", 10),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_interactive_query__common_0_struct mercury_data_interactive_query__common_0 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_interactive_query__common_1_struct mercury_data_interactive_query__common_1 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_interactive_query__common_2_struct mercury_data_interactive_query__common_2 = {
	(Integer) 0,
	MR_string_const("term_io", 7),
	MR_string_const("term_io", 7),
	MR_string_const("quote_atom", 10),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1)
};

Declare_entry(mercury__term_io__quote_atom_3_0);
static const struct mercury_data_interactive_query__common_3_struct mercury_data_interactive_query__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_2),
	ENTRY(mercury__term_io__quote_atom_3_0),
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_4_struct mercury_data_interactive_query__common_4 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_interactive_query__common_5_struct mercury_data_interactive_query__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_interactive_query__common_6_struct mercury_data_interactive_query__common_6 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

static const struct mercury_data_interactive_query__common_7_struct mercury_data_interactive_query__common_7 = {
	(Integer) 0,
	MR_string_const("interactive_query", 17),
	MR_string_const("interactive_query", 17),
	MR_string_const("write_code_to_print_one_var", 27),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1)
};

static const struct mercury_data_interactive_query__common_8_struct mercury_data_interactive_query__common_8 = {
	(Integer) 0,
	MR_string_const("interactive_query", 17),
	MR_string_const("interactive_query", 17),
	MR_string_const("write_one_var", 13),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_1)
};

static const struct mercury_data_interactive_query__common_9_struct mercury_data_interactive_query__common_9 = {
	MR_string_const(" query.m", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_interactive_query__common_10_struct mercury_data_interactive_query__common_10 = {
	MR_string_const(" -o libquery.so query.o", 23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_pred_0;
static const struct mercury_data_interactive_query__common_11_struct mercury_data_interactive_query__common_11 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 2,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_interactive_query__common_12_struct mercury_data_interactive_query__common_12 = {
	MR_string_const("query", 5)
};

static const struct mercury_data_interactive_query__common_13_struct mercury_data_interactive_query__common_13 = {
	(Integer) 0,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_12),
	MR_string_const("run", 3),
	(Integer) 2,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_14_struct mercury_data_interactive_query__common_14 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("normal_query", 12),
	MR_string_const("cc_query", 8),
	MR_string_const("io_query", 8)
};

static const struct mercury_data_interactive_query__common_15_struct mercury_data_interactive_query__common_15 = {
	(Word *) &mercury_data_interactive_query__type_ctor_info_query_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_interactive_query__common_16_struct mercury_data_interactive_query__common_16 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
static const struct mercury_data_interactive_query__common_17_struct mercury_data_interactive_query__common_17 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

static const struct mercury_data_interactive_query__common_18_struct mercury_data_interactive_query__common_18 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_6),
	MR_string_const("prog", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_19_struct mercury_data_interactive_query__common_19 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_0)
};

static const struct mercury_data_interactive_query__common_20_struct mercury_data_interactive_query__common_20 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_11)
};

static const struct mercury_data_interactive_query__common_21_struct mercury_data_interactive_query__common_21 = {
	(Integer) 0,
	MR_string_const("iq_eof", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_22_struct mercury_data_interactive_query__common_22 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_0),
	MR_string_const("iq_error", 8),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_23_struct mercury_data_interactive_query__common_23 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_16),
	MR_string_const("iq_imported", 11),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_24_struct mercury_data_interactive_query__common_24 = {
	(Integer) 0,
	MR_string_const("iq_ok", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_25_struct mercury_data_interactive_query__common_25 = {
	(Integer) 0,
	MR_string_const("iq_quit", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_interactive_query__common_26_struct mercury_data_interactive_query__common_26 = {
	(Integer) 0,
	(Integer) 3,
	MR_string_const("iq_ok", 5),
	MR_string_const("iq_quit", 7),
	MR_string_const("iq_eof", 6)
};

static const struct mercury_data_interactive_query__common_27_struct mercury_data_interactive_query__common_27 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_16)
};

static const struct mercury_data_interactive_query__type_ctor_functors_query_type_0_struct mercury_data_interactive_query__type_ctor_functors_query_type_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_14)
};

static const struct mercury_data_interactive_query__type_ctor_layout_query_type_0_struct mercury_data_interactive_query__type_ctor_layout_query_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_14)
};

static const struct mercury_data_interactive_query__type_ctor_functors_prog_0_struct mercury_data_interactive_query__type_ctor_functors_prog_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_18)
};

static const struct mercury_data_interactive_query__type_ctor_layout_prog_0_struct mercury_data_interactive_query__type_ctor_layout_prog_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_18),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_interactive_query__type_ctor_functors_options_0_struct mercury_data_interactive_query__type_ctor_functors_options_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_0)
};

static const struct mercury_data_interactive_query__type_ctor_layout_options_0_struct mercury_data_interactive_query__type_ctor_layout_options_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_19)
};

static const struct mercury_data_interactive_query__type_ctor_functors_io_pred_0_struct mercury_data_interactive_query__type_ctor_functors_io_pred_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_11)
};

static const struct mercury_data_interactive_query__type_ctor_layout_io_pred_0_struct mercury_data_interactive_query__type_ctor_layout_io_pred_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_20),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_20),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_20),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_20)
};

static const struct mercury_data_interactive_query__type_ctor_functors_interactive_query_response_0_struct mercury_data_interactive_query__type_ctor_functors_interactive_query_response_0 = {
	(Integer) 0,
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_25)
};

static const struct mercury_data_interactive_query__type_ctor_layout_interactive_query_response_0_struct mercury_data_interactive_query__type_ctor_layout_interactive_query_response_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_26),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_23),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_22),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_interactive_query__type_ctor_functors_imports_0_struct mercury_data_interactive_query__type_ctor_functors_imports_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_16)
};

static const struct mercury_data_interactive_query__type_ctor_layout_imports_0_struct mercury_data_interactive_query__type_ctor_layout_imports_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_27),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_27),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_27),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_interactive_query__common_27)
};


BEGIN_MODULE(interactive_query_module0)
	init_entry(mercury____Index___interactive_query__prog_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___interactive_query__prog_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___interactive_query__prog_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__util__trace_getline_6_0);
Declare_entry(mercury__io__nl_3_0);
Declare_entry(mercury__io__error_message_2_0);
Declare_entry(mercury__io__write_string_4_0);
Declare_entry(mercury__parser__read_term_from_string_4_0);

BEGIN_MODULE(interactive_query_module1)
	init_entry(mercury__interactive_query__query_7_0);
	init_label(mercury__interactive_query__query_7_0_i1004);
	init_label(mercury__interactive_query__query_7_0_i3);
	init_label(mercury__interactive_query__query_7_0_i4);
	init_label(mercury__interactive_query__query_7_0_i2);
	init_label(mercury__interactive_query__query_7_0_i5);
	init_label(mercury__interactive_query__query_7_0_i11);
	init_label(mercury__interactive_query__query_7_0_i12);
	init_label(mercury__interactive_query__query_7_0_i13);
	init_label(mercury__interactive_query__query_7_0_i14);
	init_label(mercury__interactive_query__query_7_0_i8);
	init_label(mercury__interactive_query__query_7_0_i9);
BEGIN_CODE

/* code for predicate 'query'/7 in mode 0 */
Define_entry(mercury__interactive_query__query_7_0);
	MR_incr_sp_push_msg(7, "interactive_query:query/7");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__interactive_query__query_7_0_i1004);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__interactive_query__query_7_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = r4;
	r1 = (Word) MR_string_const("?- ", 3);
	r3 = r5;
	r4 = r6;
	GOTO_LABEL(mercury__interactive_query__query_7_0_i2);
Define_label(mercury__interactive_query__query_7_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__query_7_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = r4;
	r1 = (Word) MR_string_const("?- ", 3);
	r3 = r5;
	r4 = r6;
	GOTO_LABEL(mercury__interactive_query__query_7_0_i2);
Define_label(mercury__interactive_query__query_7_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = r4;
	r1 = (Word) MR_string_const("run <-- ", 8);
	r3 = r5;
	r4 = r6;
Define_label(mercury__interactive_query__query_7_0_i2);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = r3;
	call_localret(ENTRY(mercury__util__trace_getline_6_0),
		mercury__interactive_query__query_7_0_i5,
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_7_0));
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__interactive_query__query_7_0_i8);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__interactive_query__query_7_0_i11);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__io__nl_3_0),
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i11);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__interactive_query__query_7_0_i12,
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i12);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__interactive_query__query_7_0_i13,
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i13);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__nl_3_0),
		mercury__interactive_query__query_7_0_i14,
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i14);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_7_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__interactive_query__query_7_0_i1004);
Define_label(mercury__interactive_query__query_7_0_i8);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__parser__read_term_from_string_4_0),
		mercury__interactive_query__query_7_0_i9,
		ENTRY(mercury__interactive_query__query_7_0));
Define_label(mercury__interactive_query__query_7_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_7_0));
	r6 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__interactive_query__query_2_8_0),
		ENTRY(mercury__interactive_query__query_7_0));
END_MODULE

Declare_entry(mercury__io__set_input_stream_4_0);
Declare_entry(mercury__term_io__read_term_3_0);
Declare_entry(mercury__io__write_4_0);
Declare_entry(mercury__io__print_4_0);
Declare_entry(mercury__io__flush_output_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(interactive_query_module2)
	init_entry(mercury__interactive_query__query_external_7_0);
	init_label(mercury__interactive_query__query_external_7_0_i1015);
	init_label(mercury__interactive_query__query_external_7_0_i2);
	init_label(mercury__interactive_query__query_external_7_0_i3);
	init_label(mercury__interactive_query__query_external_7_0_i4);
	init_label(mercury__interactive_query__query_external_7_0_i12);
	init_label(mercury__interactive_query__query_external_7_0_i18);
	init_label(mercury__interactive_query__query_external_7_0_i19);
	init_label(mercury__interactive_query__query_external_7_0_i13);
	init_label(mercury__interactive_query__query_external_7_0_i30);
	init_label(mercury__interactive_query__query_external_7_0_i31);
	init_label(mercury__interactive_query__query_external_7_0_i21);
	init_label(mercury__interactive_query__query_external_7_0_i36);
	init_label(mercury__interactive_query__query_external_7_0_i38);
	init_label(mercury__interactive_query__query_external_7_0_i39);
	init_label(mercury__interactive_query__query_external_7_0_i34);
	init_label(mercury__interactive_query__query_external_7_0_i41);
	init_label(mercury__interactive_query__query_external_7_0_i7);
	init_label(mercury__interactive_query__query_external_7_0_i8);
	init_label(mercury__interactive_query__query_external_7_0_i9);
	init_label(mercury__interactive_query__query_external_7_0_i10);
BEGIN_CODE

/* code for predicate 'query_external'/7 in mode 0 */
Define_entry(mercury__interactive_query__query_external_7_0);
	MR_incr_sp_push_msg(10, "interactive_query:query_external/7");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__interactive_query__query_external_7_0_i1015);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r4;
	r2 = r6;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__interactive_query__query_external_7_0_i2,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__term_io__read_term_3_0),
		mercury__interactive_query__query_external_7_0_i3,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r3;
	call_localret(ENTRY(mercury__io__set_input_stream_4_0),
		mercury__interactive_query__query_external_7_0_i4,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i4);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r3 = MR_stackvar(6);
	if ((MR_tag(r3) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i7);
	if ((MR_tag(r3) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i12);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	call_localret(ENTRY(mercury__io__write_4_0),
		mercury__interactive_query__query_external_7_0_i18,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i12);
	r4 = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r5 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i13);
	r6 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i13);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r6, (Integer) 0), (char *)(Word) MR_string_const("quit", 4)) != 0))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i13);
	r6 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i13);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(ENTRY(mercury__io__write_4_0),
		mercury__interactive_query__query_external_7_0_i18,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i18);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__query_external_7_0_i19,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i19);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__io__flush_output_3_0),
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i13);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("options", 7)) != 0))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i21);
	r4 = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__write_4_0),
		mercury__interactive_query__query_external_7_0_i30,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i30);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__query_external_7_0_i31,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i31);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__flush_output_3_0),
		mercury__interactive_query__query_external_7_0_i10,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i21);
	MR_stackvar(6) = r5;
	MR_stackvar(7) = r4;
	MR_stackvar(9) = r2;
	r1 = r4;
	call_localret(STATIC(mercury__interactive_query__term_to_list_2_0),
		mercury__interactive_query__query_external_7_0_i36,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i36);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__interactive_query__query_external_7_0_i34);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__interactive_query__query_external_7_0_i38,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i38);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	MR_stackvar(8) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__interactive_query__query_external_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(9);
	call_localret(STATIC(mercury__interactive_query__send_term_to_socket_4_0),
		mercury__interactive_query__query_external_7_0_i39,
		ENTRY(mercury__interactive_query__query_external_7_0));
	}
Define_label(mercury__interactive_query__query_external_7_0_i39);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__interactive_query__query_external_7_0_i1015);
Define_label(mercury__interactive_query__query_external_7_0_i34);
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(6);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__interactive_query__query_external_7_0, "interactive_query:prog/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r5;
	call_localret(STATIC(mercury__interactive_query__run_query_4_0),
		mercury__interactive_query__query_external_7_0_i41,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i41);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__interactive_query__send_term_to_socket_4_0),
		mercury__interactive_query__query_external_7_0_i10,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i7);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;
	r2 = MR_stackvar(5);
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__interactive_query__query_external_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	r4 = r5;
	call_localret(ENTRY(mercury__io__write_4_0),
		mercury__interactive_query__query_external_7_0_i8,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i8);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__query_external_7_0_i9,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__flush_output_3_0),
		mercury__interactive_query__query_external_7_0_i10,
		ENTRY(mercury__interactive_query__query_external_7_0));
Define_label(mercury__interactive_query__query_external_7_0_i10);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_external_7_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__interactive_query__query_external_7_0_i1015);
END_MODULE

Declare_entry(mercury__io__write_list_6_0);

BEGIN_MODULE(interactive_query_module3)
	init_entry(mercury__interactive_query__query_2_8_0);
	init_label(mercury__interactive_query__query_2_8_0_i8);
	init_label(mercury__interactive_query__query_2_8_0_i9);
	init_label(mercury__interactive_query__query_2_8_0_i24);
	init_label(mercury__interactive_query__query_2_8_0_i25);
	init_label(mercury__interactive_query__query_2_8_0_i15);
	init_label(mercury__interactive_query__query_2_8_0_i30);
	init_label(mercury__interactive_query__query_2_8_0_i32);
	init_label(mercury__interactive_query__query_2_8_0_i33);
	init_label(mercury__interactive_query__query_2_8_0_i34);
	init_label(mercury__interactive_query__query_2_8_0_i35);
	init_label(mercury__interactive_query__query_2_8_0_i28);
	init_label(mercury__interactive_query__query_2_8_0_i4);
	init_label(mercury__interactive_query__query_2_8_0_i5);
	init_label(mercury__interactive_query__query_2_8_0_i6);
BEGIN_CODE

/* code for predicate 'query_2'/8 in mode 0 */
Define_static(mercury__interactive_query__query_2_8_0);
	MR_incr_sp_push_msg(10, "interactive_query:query_2/8");
	MR_stackvar(10) = (Word) MR_succip;
	if ((MR_tag(r6) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i4);
	if ((MR_tag(r6) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i8);
	r1 = r5;
	r2 = r7;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__io__nl_3_0),
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i8);
	r8 = MR_const_field(MR_mktag(2), r6, (Integer) 1);
	r9 = MR_const_field(MR_mktag(2), r6, (Integer) 0);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i9);
	r10 = MR_const_field(MR_mktag(0), r8, (Integer) 0);
	if ((MR_tag(r10) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i9);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r10, (Integer) 0), (char *)(Word) MR_string_const("quit", 4)) != 0))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i9);
	r10 = MR_const_field(MR_mktag(0), r8, (Integer) 1);
	if (((Integer) r10 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i9);
	r1 = r5;
	r2 = r7;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__io__nl_3_0),
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i9);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	r6 = MR_const_field(MR_mktag(0), r8, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r6, (Integer) 0), (char *)(Word) MR_string_const("options", 7)) != 0))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	r6 = MR_const_field(MR_mktag(0), r8, (Integer) 1);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	if ((MR_tag(MR_const_field(MR_mktag(1), r6, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r6, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r6, (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	if (((Integer) MR_const_field(MR_mktag(1), r6, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i15);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r6, (Integer) 0), (Integer) 0), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = r5;
	r3 = (Word) MR_string_const("Compilation options: ", 21);
	r4 = r7;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__query_2_8_0_i24,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i24);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__query_2_8_0_i25,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i25);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__nl_3_0),
		mercury__interactive_query__query_2_8_0_i6,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i15);
	MR_stackvar(1) = r1;
	r1 = r8;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	call_localret(STATIC(mercury__interactive_query__term_to_list_2_0),
		mercury__interactive_query__query_2_8_0_i30,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i30);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__interactive_query__query_2_8_0_i28);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__interactive_query__query_2_8_0_i32,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i32);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_string_const(":- import_module ", 17);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__interactive_query__query_2_8_0_i33,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i33);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(9);
	r4 = (Word) MR_string_const(", ", 2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_3);
	call_localret(ENTRY(mercury__io__write_list_6_0),
		mercury__interactive_query__query_2_8_0_i34,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i34);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__interactive_query__query_2_8_0_i35,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i35);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__interactive_query__query_7_0),
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i28);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__interactive_query__query_2_8_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(STATIC(mercury__interactive_query__run_query_4_0),
		mercury__interactive_query__query_2_8_0_i6,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	r1 = r5;
	r3 = r7;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__interactive_query__query_2_8_0_i5,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__nl_3_0),
		mercury__interactive_query__query_2_8_0_i6,
		STATIC(mercury__interactive_query__query_2_8_0));
Define_label(mercury__interactive_query__query_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__interactive_query__query_2_8_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__interactive_query__query_7_0),
		STATIC(mercury__interactive_query__query_2_8_0));
END_MODULE


BEGIN_MODULE(interactive_query_module4)
	init_entry(mercury__interactive_query__send_term_to_socket_4_0);
	init_label(mercury__interactive_query__send_term_to_socket_4_0_i2);
	init_label(mercury__interactive_query__send_term_to_socket_4_0_i3);
BEGIN_CODE

/* code for predicate 'send_term_to_socket'/4 in mode 0 */
Define_static(mercury__interactive_query__send_term_to_socket_4_0);
	MR_incr_sp_push_msg(2, "interactive_query:send_term_to_socket/4");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = r3;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_interactive_query__type_ctor_info_interactive_query_response_0;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__io__write_4_0),
		mercury__interactive_query__send_term_to_socket_4_0_i2,
		STATIC(mercury__interactive_query__send_term_to_socket_4_0));
Define_label(mercury__interactive_query__send_term_to_socket_4_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__send_term_to_socket_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__print_4_0),
		mercury__interactive_query__send_term_to_socket_4_0_i3,
		STATIC(mercury__interactive_query__send_term_to_socket_4_0));
Define_label(mercury__interactive_query__send_term_to_socket_4_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__send_term_to_socket_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__flush_output_3_0),
		STATIC(mercury__interactive_query__send_term_to_socket_4_0));
END_MODULE


BEGIN_MODULE(interactive_query_module5)
	init_entry(mercury__interactive_query__term_to_list_2_0);
	init_label(mercury__interactive_query__term_to_list_2_0_i5);
	init_label(mercury__interactive_query__term_to_list_2_0_i13);
	init_label(mercury__interactive_query__term_to_list_2_0_i1015);
	init_label(mercury__interactive_query__term_to_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'term_to_list'/2 in mode 0 */
Define_static(mercury__interactive_query__term_to_list_2_0);
	MR_incr_sp_push_msg(2, "interactive_query:term_to_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1015);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1015);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("[]", 2)) != 0))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1015);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__interactive_query__term_to_list_2_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const(".", 1)) != 0))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1), (Integer) 0);
	localcall(mercury__interactive_query__term_to_list_2_0,
		LABEL(mercury__interactive_query__term_to_list_2_0_i13),
		STATIC(mercury__interactive_query__term_to_list_2_0));
Define_label(mercury__interactive_query__term_to_list_2_0_i13);
	update_prof_current_proc(LABEL(mercury__interactive_query__term_to_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__interactive_query__term_to_list_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__interactive_query__term_to_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__interactive_query__term_to_list_2_0_i1015);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__interactive_query__term_to_list_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__io__get_environment_var_4_0);
Declare_entry(mercury__io__set_environment_var_4_0);
Declare_entry(mercury__io__open_output_4_0);
Declare_entry(mercury__io__progname_4_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__stdout_stream_3_0);
Declare_entry(mercury__io__set_output_stream_4_0);
Declare_entry(mercury__io__close_output_3_0);
Declare_entry(mercury__io__print_3_0);

BEGIN_MODULE(interactive_query_module6)
	init_entry(mercury__interactive_query__run_query_4_0);
	init_label(mercury__interactive_query__run_query_4_0_i2);
	init_label(mercury__interactive_query__run_query_4_0_i5);
	init_label(mercury__interactive_query__run_query_4_0_i6);
	init_label(mercury__interactive_query__run_query_4_0_i8);
	init_label(mercury__interactive_query__run_query_4_0_i9);
	init_label(mercury__interactive_query__run_query_4_0_i10);
	init_label(mercury__interactive_query__run_query_4_0_i11);
	init_label(mercury__interactive_query__run_query_4_0_i12);
	init_label(mercury__interactive_query__run_query_4_0_i7);
	init_label(mercury__interactive_query__run_query_4_0_i14);
	init_label(mercury__interactive_query__run_query_4_0_i15);
	init_label(mercury__interactive_query__run_query_4_0_i16);
	init_label(mercury__interactive_query__run_query_4_0_i17);
	init_label(mercury__interactive_query__run_query_4_0_i18);
	init_label(mercury__interactive_query__run_query_4_0_i21);
	init_label(mercury__interactive_query__run_query_4_0_i19);
	init_label(mercury__interactive_query__run_query_4_0_i3);
BEGIN_CODE

/* code for predicate 'run_query'/4 in mode 0 */
Define_static(mercury__interactive_query__run_query_4_0);
	MR_incr_sp_push_msg(6, "interactive_query:run_query/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("MERCURY_OPTIONS", 15);
	r2 = r3;
	call_localret(ENTRY(mercury__io__get_environment_var_4_0),
		mercury__interactive_query__run_query_4_0_i2,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__run_query_4_0_i3);
	r3 = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("MERCURY_OPTIONS", 15);
	r2 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__io__set_environment_var_4_0),
		mercury__interactive_query__run_query_4_0_i5,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("query.m", 7);
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__interactive_query__run_query_4_0_i6,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i6);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__run_query_4_0_i8);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	GOTO_LABEL(mercury__interactive_query__run_query_4_0_i7);
Define_label(mercury__interactive_query__run_query_4_0_i8);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("interactive", 11);
	call_localret(ENTRY(mercury__io__progname_4_0),
		mercury__interactive_query__run_query_4_0_i9,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__interactive_query__run_query_4_0_i10,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i10);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": ", 2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("error opening file `", 20);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("query.m", 7);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("' for output:\n\t", 15);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__interactive_query__run_query_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__interactive_query__run_query_4_0_i11,
		STATIC(mercury__interactive_query__run_query_4_0));
	}
Define_label(mercury__interactive_query__run_query_4_0_i11);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__run_query_4_0_i12,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i12);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	call_localret(ENTRY(mercury__io__stdout_stream_3_0),
		mercury__interactive_query__run_query_4_0_i7,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i7);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__interactive_query__run_query_4_0_i14,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i14);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__interactive_query__write_prog_to_stream_3_0),
		mercury__interactive_query__run_query_4_0_i15,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i15);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__interactive_query__run_query_4_0_i16,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i16);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__interactive_query__run_query_4_0_i17,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i17);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__interactive_query__compile_file_4_0),
		mercury__interactive_query__run_query_4_0_i18,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i18);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__run_query_4_0_i19);
	r1 = r2;
	call_localret(STATIC(mercury__interactive_query__dynamically_load_and_run_2_0),
		mercury__interactive_query__run_query_4_0_i21,
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i21);
	update_prof_current_proc(LABEL(mercury__interactive_query__run_query_4_0));
	r3 = r1;
	r1 = (Word) MR_string_const("MERCURY_OPTIONS", 15);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__set_environment_var_4_0),
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i19);
	r3 = r2;
	r1 = (Word) MR_string_const("MERCURY_OPTIONS", 15);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__set_environment_var_4_0),
		STATIC(mercury__interactive_query__run_query_4_0));
Define_label(mercury__interactive_query__run_query_4_0_i3);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("Unable to unset MERCURY_OPTIONS environment variable", 52);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__print_3_0),
		STATIC(mercury__interactive_query__run_query_4_0));
END_MODULE

Declare_entry(mercury__io__output_stream_3_0);
Declare_entry(mercury__term__vars_2_0);
Declare_entry(mercury__list__remove_dups_2_0);
Declare_entry(mercury__list__foldl_4_0);
Declare_entry(mercury__term_io__write_term_4_0);

BEGIN_MODULE(interactive_query_module7)
	init_entry(mercury__interactive_query__write_prog_to_stream_3_0);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i2);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i3);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i4);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i5);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i8);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i9);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i10);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i11);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i12);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i13);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i14);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i15);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i16);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i17);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i18);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i19);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i20);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i21);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i22);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i23);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i24);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i25);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i26);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i27);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i7);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i31);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i32);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i33);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i34);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i35);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i36);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i37);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i38);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i39);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i40);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i41);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i30);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i44);
	init_label(mercury__interactive_query__write_prog_to_stream_3_0_i45);
BEGIN_CODE

/* code for predicate 'write_prog_to_stream'/3 in mode 0 */
Define_static(mercury__interactive_query__write_prog_to_stream_3_0);
	MR_incr_sp_push_msg(5, "interactive_query:write_prog_to_stream/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) MR_string_const("\n\t\t\t:- module query.\n\t\t\t:- interface.\n\t\t\t:- import_module io.\n\t\t\t:- pred run(io__state::di, io__state::uo) is cc_multi.\n\t\t\t:- implementation.\n\t\t\t", 145);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i2,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	call_localret(ENTRY(mercury__io__output_stream_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i3,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__interactive_query__write_prog_to_stream_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_string_const("std_util", 8);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	call_localret(STATIC(mercury__interactive_query__write_import_list_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i4,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i4);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t\t\t:- pragma source_file(\"<stdin>\").\n\t\t\trun -->\n\t", 50);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i5,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__interactive_query__write_prog_to_stream_3_0_i7);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i8,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i8);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5);
	call_localret(ENTRY(mercury__list__remove_dups_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i9,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("\n\t\t\t\tunsorted_aggregate(\n\t\t\t\t\t(pred(res", 39);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i10,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i10);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i11,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i11);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("::out) is nondet :-\n\t\t\t\t\t\tquery", 31);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i12,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i12);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i13,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i13);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("),", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i14,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i14);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(pred(res", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i15,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i15);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i16,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i16);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("::in, di, uo) is det -->\n\t\t\t\t\t\t", 31);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i17,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i17);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5);
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__interactive_query__write_prog_to_stream_3_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_7);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(4);
	r5 = r4;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i18,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i18);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t\t\t\t\tio__write_string(\"true ;\n\"))\n\t\t\t\t),\n\t\t\t\tio__write_string(\"fail.\n\"),\n\t\t\t\tio__write_string(\"No (more) solutions.\n\").\n\n\t\t\t:- type res", 136);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i19,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i19);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i20,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i20);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ---> res", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i21,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i21);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i22,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i22);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i23,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i23);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t\t\tquery", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i24,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i24);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i25,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i25);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" :- ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i26,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i26);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	call_localret(STATIC(mercury__interactive_query__write_line_directive_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i27,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i27);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term_io__write_term_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i45,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i7);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__write_prog_to_stream_3_0_i30);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i31,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i31);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5);
	call_localret(ENTRY(mercury__list__remove_dups_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i32,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i32);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("(if { query", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i33,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i33);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i34,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i34);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" } then\n", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i35,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i35);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5);
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__interactive_query__write_prog_to_stream_3_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_7);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(4);
	r5 = r4;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i36,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i36);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t\t\t\t\tio__write_string(\"true.\\n\")\n\t\t\t\telse\n\t\t\t\t\tio__write_string(\"No solution.\\n\")\n\t\t\t\t).\n\t\t", 92);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i37,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i37);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("query", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i38,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i38);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__interactive_query__write_args_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i39,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i39);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" :-\n", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i40,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i40);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	call_localret(STATIC(mercury__interactive_query__write_line_directive_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i41,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i41);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term_io__write_term_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i45,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i30);
	call_localret(STATIC(mercury__interactive_query__write_line_directive_2_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i44,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i44);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term_io__write_term_4_0),
		mercury__interactive_query__write_prog_to_stream_3_0_i45,
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
Define_label(mercury__interactive_query__write_prog_to_stream_3_0_i45);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_prog_to_stream_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" .\n", 3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__interactive_query__write_prog_to_stream_3_0));
END_MODULE

Declare_entry(mercury__io__get_line_number_3_0);
Declare_entry(mercury__io__write_int_3_0);
Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(interactive_query_module8)
	init_entry(mercury__interactive_query__write_line_directive_2_0);
	init_label(mercury__interactive_query__write_line_directive_2_0_i2);
	init_label(mercury__interactive_query__write_line_directive_2_0_i3);
	init_label(mercury__interactive_query__write_line_directive_2_0_i4);
BEGIN_CODE

/* code for predicate 'write_line_directive'/2 in mode 0 */
Define_static(mercury__interactive_query__write_line_directive_2_0);
	MR_incr_sp_push_msg(1, "interactive_query:write_line_directive/2");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) MR_string_const("\n#", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_line_directive_2_0_i2,
		STATIC(mercury__interactive_query__write_line_directive_2_0));
Define_label(mercury__interactive_query__write_line_directive_2_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_line_directive_2_0));
	call_localret(ENTRY(mercury__io__get_line_number_3_0),
		mercury__interactive_query__write_line_directive_2_0_i3,
		STATIC(mercury__interactive_query__write_line_directive_2_0));
Define_label(mercury__interactive_query__write_line_directive_2_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_line_directive_2_0));
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__interactive_query__write_line_directive_2_0_i4,
		STATIC(mercury__interactive_query__write_line_directive_2_0));
Define_label(mercury__interactive_query__write_line_directive_2_0_i4);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_line_directive_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__interactive_query__write_line_directive_2_0));
END_MODULE

Declare_entry(mercury__term_io__write_variable_4_0);

BEGIN_MODULE(interactive_query_module9)
	init_entry(mercury__interactive_query__write_code_to_print_one_var_4_0);
	init_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i2);
	init_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i3);
	init_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i4);
	init_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i5);
BEGIN_CODE

/* code for predicate 'write_code_to_print_one_var'/4 in mode 0 */
Define_static(mercury__interactive_query__write_code_to_print_one_var_4_0);
	MR_incr_sp_push_msg(3, "interactive_query:write_code_to_print_one_var/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("io__write_string(\"", 18);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_code_to_print_one_var_4_0_i2,
		STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0));
Define_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_code_to_print_one_var_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term_io__write_variable_4_0),
		mercury__interactive_query__write_code_to_print_one_var_4_0_i3,
		STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0));
Define_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_code_to_print_one_var_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = \"), write(", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_code_to_print_one_var_4_0_i4,
		STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0));
Define_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i4);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_code_to_print_one_var_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term_io__write_variable_4_0),
		mercury__interactive_query__write_code_to_print_one_var_4_0_i5,
		STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0));
Define_label(mercury__interactive_query__write_code_to_print_one_var_4_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_code_to_print_one_var_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_string_const("), io__write_string(\", \"), ", 27);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__print_3_0),
		STATIC(mercury__interactive_query__write_code_to_print_one_var_4_0));
END_MODULE

Declare_entry(mercury__io__write_list_5_0);

BEGIN_MODULE(interactive_query_module10)
	init_entry(mercury__interactive_query__write_args_4_0);
	init_label(mercury__interactive_query__write_args_4_0_i6);
	init_label(mercury__interactive_query__write_args_4_0_i7);
	init_label(mercury__interactive_query__write_args_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_args'/4 in mode 0 */
Define_static(mercury__interactive_query__write_args_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__write_args_4_0_i3);
	MR_incr_sp_push_msg(4, "interactive_query:write_args/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("(", 1);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__write_args_4_0_i6,
		STATIC(mercury__interactive_query__write_args_4_0));
Define_label(mercury__interactive_query__write_args_4_0_i6);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_args_4_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__interactive_query__write_args_4_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_5);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__interactive_query__write_one_var_4_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_8);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__interactive_query__write_args_4_0_i7,
		STATIC(mercury__interactive_query__write_args_4_0));
Define_label(mercury__interactive_query__write_args_4_0_i7);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_args_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__interactive_query__write_args_4_0));
Define_label(mercury__interactive_query__write_args_4_0_i3);
	r1 = r3;
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module11)
	init_entry(mercury__interactive_query__write_one_var_4_0);
BEGIN_CODE

/* code for predicate 'write_one_var'/4 in mode 0 */
Define_static(mercury__interactive_query__write_one_var_4_0);
	r4 = r3;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	tailcall(ENTRY(mercury__term_io__write_variable_4_0),
		STATIC(mercury__interactive_query__write_one_var_4_0));
END_MODULE


BEGIN_MODULE(interactive_query_module12)
	init_entry(mercury__interactive_query__write_import_list_4_0);
	init_label(mercury__interactive_query__write_import_list_4_0_i2);
	init_label(mercury__interactive_query__write_import_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_import_list'/4 in mode 0 */
Define_static(mercury__interactive_query__write_import_list_4_0);
	MR_incr_sp_push_msg(3, "interactive_query:write_import_list/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const(":- import_module ", 17);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__interactive_query__write_import_list_4_0_i2,
		STATIC(mercury__interactive_query__write_import_list_4_0));
Define_label(mercury__interactive_query__write_import_list_4_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_import_list_4_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = (Word) MR_string_const(", ", 2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_3);
	call_localret(ENTRY(mercury__io__write_list_6_0),
		mercury__interactive_query__write_import_list_4_0_i3,
		STATIC(mercury__interactive_query__write_import_list_4_0));
Define_label(mercury__interactive_query__write_import_list_4_0_i3);
	update_prof_current_proc(LABEL(mercury__interactive_query__write_import_list_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const(".\n", 2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		STATIC(mercury__interactive_query__write_import_list_4_0));
END_MODULE

Declare_entry(mercury__io__flush_output_2_0);
Declare_entry(mercury__io__call_system_4_0);

BEGIN_MODULE(interactive_query_module13)
	init_entry(mercury__interactive_query__compile_file_4_0);
	init_label(mercury__interactive_query__compile_file_4_0_i2);
	init_label(mercury__interactive_query__compile_file_4_0_i5);
	init_label(mercury__interactive_query__compile_file_4_0_i6);
	init_label(mercury__interactive_query__compile_file_4_0_i7);
	init_label(mercury__interactive_query__compile_file_4_0_i8);
	init_label(mercury__interactive_query__compile_file_4_0_i3);
	init_label(mercury__interactive_query__compile_file_4_0_i10);
	init_label(mercury__interactive_query__compile_file_4_0_i16);
	init_label(mercury__interactive_query__compile_file_4_0_i14);
	init_label(mercury__interactive_query__compile_file_4_0_i11);
	init_label(mercury__interactive_query__compile_file_4_0_i18);
	init_label(mercury__interactive_query__compile_file_4_0_i21);
	init_label(mercury__interactive_query__compile_file_4_0_i23);
	init_label(mercury__interactive_query__compile_file_4_0_i26);
	init_label(mercury__interactive_query__compile_file_4_0_i24);
BEGIN_CODE

/* code for predicate 'compile_file'/4 in mode 0 */
Define_static(mercury__interactive_query__compile_file_4_0);
	{
	String	GradeOpt;
#define MR_PROC_LABEL mercury__interactive_query__compile_file_4_0
{
#line 448 "interactive_query.m"
MR_make_aligned_string(GradeOpt, (String) MR_GRADE_OPT);;}
#line 2413 "interactive_query.c"
	r3 = (Word) GradeOpt;
#undef MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(3, "interactive_query:compile_file/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mmc --grade ", 12);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("--infer-all ", 12);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const("--pic-reg ", 10);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("-O0 --no-c-optimize ", 20);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = (Word) MR_string_const("--no-warn-simple-code --no-warn-det-decls-too-lax ", 50);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("-c ", 3);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r12, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_9);
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__interactive_query__compile_file_4_0_i2,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	if (((Integer) 0 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i3);
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r3 = r1;
	r1 = (Word) MR_string_const("% Invoking system command `", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__compile_file_4_0_i5,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__compile_file_4_0_i6,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i6);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'...\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__compile_file_4_0_i7,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i7);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__interactive_query__compile_file_4_0_i8,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i8);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__interactive_query__compile_file_4_0_i10,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__interactive_query__compile_file_4_0_i10,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i10);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i11);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i11);
	if (((Integer) 0 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i14);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("% done.\n", 8);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__compile_file_4_0_i16,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i16);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = r1;
	r1 = (Integer) 1;
	GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i23);
Define_label(mercury__interactive_query__compile_file_4_0_i14);
	r1 = (Integer) 1;
	GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i23);
Define_label(mercury__interactive_query__compile_file_4_0_i11);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i18);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("Compilation error(s) occurred.\n", 31);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__compile_file_4_0_i21,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i18);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("Error: unable to invoke the compiler.\n", 38);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__compile_file_4_0_i21,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i21);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = r1;
	r1 = (Integer) 0;
Define_label(mercury__interactive_query__compile_file_4_0_i23);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__compile_file_4_0_i24);
	{
	String	GradeOpt;
#define MR_PROC_LABEL mercury__interactive_query__compile_file_4_0
{
#line 448 "interactive_query.m"
MR_make_aligned_string(GradeOpt, (String) MR_GRADE_OPT);;}
#line 2547 "interactive_query.c"
	r1 = (Word) GradeOpt;
#undef MR_PROC_LABEL

	}
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("ml --grade ", 11);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(" --trace", 8);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const(" --make-shared-lib ", 19);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__interactive_query__compile_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_interactive_query__common_10);
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__interactive_query__compile_file_4_0_i26,
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i26);
	update_prof_current_proc(LABEL(mercury__interactive_query__compile_file_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__interactive_query__invoke_system_command_4_0),
		STATIC(mercury__interactive_query__compile_file_4_0));
Define_label(mercury__interactive_query__compile_file_4_0_i24);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module14)
	init_entry(mercury__fn__interactive_query__grade_option_0_0);
BEGIN_CODE

/* code for predicate 'grade_option'/1 in mode 0 */
Define_static(mercury__fn__interactive_query__grade_option_0_0);
	{
	String	GradeOpt;
#define MR_PROC_LABEL mercury__fn__interactive_query__grade_option_0_0
{
#line 448 "interactive_query.m"
MR_make_aligned_string(GradeOpt, (String) MR_GRADE_OPT);;}
#line 2600 "interactive_query.c"
	r1 = (Word) GradeOpt;
#undef MR_PROC_LABEL

	}
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module15)
	init_entry(mercury__interactive_query__invoke_system_command_4_0);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i4);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i5);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i6);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i7);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i8);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i9);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i15);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i13);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i10);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i17);
	init_label(mercury__interactive_query__invoke_system_command_4_0_i20);
BEGIN_CODE

/* code for predicate 'invoke_system_command'/4 in mode 0 */
Define_static(mercury__interactive_query__invoke_system_command_4_0);
	MR_incr_sp_push_msg(2, "interactive_query:invoke_system_command/4");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) 0 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__invoke_system_command_4_0_i8);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("% Invoking system command `", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i4,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i4);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i5,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'...\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i6,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i6);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__interactive_query__invoke_system_command_4_0_i7,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i7);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
Define_label(mercury__interactive_query__invoke_system_command_4_0_i8);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__interactive_query__invoke_system_command_4_0_i9,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__invoke_system_command_4_0_i10);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__interactive_query__invoke_system_command_4_0_i10);
	if (((Integer) 0 != (Integer) 1))
		GOTO_LABEL(mercury__interactive_query__invoke_system_command_4_0_i13);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("% done.\n", 8);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i15,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i15);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__interactive_query__invoke_system_command_4_0_i13);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__interactive_query__invoke_system_command_4_0_i10);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__invoke_system_command_4_0_i17);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("Compilation error(s) occurred.\n", 31);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i20,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i17);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = (Word) MR_string_const("Error: unable to invoke the compiler.\n", 38);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__invoke_system_command_4_0_i20,
		STATIC(mercury__interactive_query__invoke_system_command_4_0));
Define_label(mercury__interactive_query__invoke_system_command_4_0_i20);
	update_prof_current_proc(LABEL(mercury__interactive_query__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__dl__open_6_0);
Declare_entry(mercury__dl__mercury_sym_5_0);
Declare_entry(mercury__do_call_closure);
Declare_entry(mercury__dl__close_4_0);

BEGIN_MODULE(interactive_query_module16)
	init_entry(mercury__interactive_query__dynamically_load_and_run_2_0);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i2);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i5);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i7);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i9);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i10);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i11);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i12);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i14);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i15);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i4);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i18);
	init_label(mercury__interactive_query__dynamically_load_and_run_2_0_i19);
BEGIN_CODE

/* code for predicate 'dynamically_load_and_run'/2 in mode 0 */
Define_static(mercury__interactive_query__dynamically_load_and_run_2_0);
	MR_incr_sp_push_msg(3, "interactive_query:dynamically_load_and_run/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) MR_string_const("./libquery.so", 13);
	r3 = r2;
	r2 = (Integer) 0;
	r4 = r3;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__dl__open_6_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i2,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i2);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__dynamically_load_and_run_2_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_11);
	r4 = r2;
	r2 = MR_stackvar(1);
	r5 = r3;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_interactive_query__common_13);
	call_localret(ENTRY(mercury__dl__mercury_sym_5_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i5,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i5);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__interactive_query__dynamically_load_and_run_2_0_i7);
	{
	Word	X;
	Word	Y;
#define MR_PROC_LABEL mercury__interactive_query__dynamically_load_and_run_2_0
	X = MR_const_field(MR_mktag(0), r1, (Integer) 0);
{
#line 544 "interactive_query.m"
Y = X;}
#line 2774 "interactive_query.c"
	r3 = Y;
#undef MR_PROC_LABEL

	}
	r4 = r2;
	r1 = r3;
	r2 = (Integer) 1;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__interactive_query__dynamically_load_and_run_2_0_i11,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i7);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r4 = r2;
	r2 = (Word) MR_string_const("dlsym failed: ", 14);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i9,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i9);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i10,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i10);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i11,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i11);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__dl__close_4_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i12,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i12);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__interactive_query__dynamically_load_and_run_2_0_i14);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i14);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r4 = r2;
	r2 = (Word) MR_string_const("dlclose failed: ", 16);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i15,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i15);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i19,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r4 = r2;
	r2 = (Word) MR_string_const("dlopen failed: ", 15);
	r5 = r3;
	r3 = r4;
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i18,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i18);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__print_3_0),
		mercury__interactive_query__dynamically_load_and_run_2_0_i19,
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
Define_label(mercury__interactive_query__dynamically_load_and_run_2_0_i19);
	update_prof_current_proc(LABEL(mercury__interactive_query__dynamically_load_and_run_2_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__interactive_query__dynamically_load_and_run_2_0));
END_MODULE


BEGIN_MODULE(interactive_query_module17)
	init_entry(mercury__fn__interactive_query__inst_cast_1_0);
BEGIN_CODE

/* code for predicate 'inst_cast'/2 in mode 0 */
Define_static(mercury__fn__interactive_query__inst_cast_1_0);
	{
	Word	X;
	Word	Y;
#define MR_PROC_LABEL mercury__fn__interactive_query__inst_cast_1_0
	X = r1;
{
#line 544 "interactive_query.m"
Y = X;}
#line 2889 "interactive_query.c"
	r2 = Y;
#undef MR_PROC_LABEL

	}
	r1 = r2;
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module18)
	init_entry(mercury____Unify___interactive_query__query_type_0_0);
	init_label(mercury____Unify___interactive_query__query_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___interactive_query__query_type_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___interactive_query__query_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__query_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module19)
	init_entry(mercury____Index___interactive_query__query_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___interactive_query__query_type_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(interactive_query_module20)
	init_entry(mercury____Compare___interactive_query__query_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___interactive_query__query_type_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___interactive_query__query_type_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(interactive_query_module21)
	init_entry(mercury____Unify___interactive_query__imports_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___interactive_query__imports_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___interactive_query__imports_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(interactive_query_module22)
	init_entry(mercury____Index___interactive_query__imports_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___interactive_query__imports_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___interactive_query__imports_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(interactive_query_module23)
	init_entry(mercury____Compare___interactive_query__imports_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___interactive_query__imports_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___interactive_query__imports_0_0));
END_MODULE


BEGIN_MODULE(interactive_query_module24)
	init_entry(mercury____Unify___interactive_query__options_0_0);
	init_label(mercury____Unify___interactive_query__options_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___interactive_query__options_0_0);
	if ((strcmp((char *)r1, (char *)r2) != 0))
		GOTO_LABEL(mercury____Unify___interactive_query__options_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__options_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_string_2_0);

BEGIN_MODULE(interactive_query_module25)
	init_entry(mercury____Index___interactive_query__options_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___interactive_query__options_0_0);
	tailcall(ENTRY(mercury__builtin_index_string_2_0),
		ENTRY(mercury____Index___interactive_query__options_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(interactive_query_module26)
	init_entry(mercury____Compare___interactive_query__options_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___interactive_query__options_0_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___interactive_query__options_0_0));
END_MODULE

Declare_entry(mercury____Unify___term__term_1_0);
Declare_entry(mercury____Unify___varset__varset_1_0);

BEGIN_MODULE(interactive_query_module27)
	init_entry(mercury____Unify___interactive_query__prog_0_0);
	init_label(mercury____Unify___interactive_query__prog_0_0_i2);
	init_label(mercury____Unify___interactive_query__prog_0_0_i4);
	init_label(mercury____Unify___interactive_query__prog_0_0_i1004);
	init_label(mercury____Unify___interactive_query__prog_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___interactive_query__prog_0_0);
	MR_incr_sp_push_msg(5, "interactive_query:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___interactive_query__prog_0_0_i1004);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___interactive_query__prog_0_0_i2,
		STATIC(mercury____Unify___interactive_query__prog_0_0));
Define_label(mercury____Unify___interactive_query__prog_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___interactive_query__prog_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___interactive_query__prog_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___term__term_1_0),
		mercury____Unify___interactive_query__prog_0_0_i4,
		STATIC(mercury____Unify___interactive_query__prog_0_0));
Define_label(mercury____Unify___interactive_query__prog_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___interactive_query__prog_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___interactive_query__prog_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___varset__varset_1_0),
		STATIC(mercury____Unify___interactive_query__prog_0_0));
Define_label(mercury____Unify___interactive_query__prog_0_0_i1004);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___interactive_query__prog_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module28)
	init_entry(mercury____Index___interactive_query__prog_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___interactive_query__prog_0_0);
	tailcall(STATIC(mercury____Index___interactive_query__prog_0__ua0_2_0),
		STATIC(mercury____Index___interactive_query__prog_0_0));
END_MODULE

Declare_entry(mercury____Compare___term__term_1_0);
Declare_entry(mercury____Compare___varset__varset_1_0);

BEGIN_MODULE(interactive_query_module29)
	init_entry(mercury____Compare___interactive_query__prog_0_0);
	init_label(mercury____Compare___interactive_query__prog_0_0_i3);
	init_label(mercury____Compare___interactive_query__prog_0_0_i7);
	init_label(mercury____Compare___interactive_query__prog_0_0_i11);
	init_label(mercury____Compare___interactive_query__prog_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___interactive_query__prog_0_0);
	MR_incr_sp_push_msg(7, "interactive_query:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___interactive_query__prog_0_0_i3,
		STATIC(mercury____Compare___interactive_query__prog_0_0));
Define_label(mercury____Compare___interactive_query__prog_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___interactive_query__prog_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__prog_0_0_i17);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___interactive_query__prog_0_0_i7,
		STATIC(mercury____Compare___interactive_query__prog_0_0));
Define_label(mercury____Compare___interactive_query__prog_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___interactive_query__prog_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__prog_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___term__term_1_0),
		mercury____Compare___interactive_query__prog_0_0_i11,
		STATIC(mercury____Compare___interactive_query__prog_0_0));
Define_label(mercury____Compare___interactive_query__prog_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___interactive_query__prog_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__prog_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___varset__varset_1_0),
		STATIC(mercury____Compare___interactive_query__prog_0_0));
Define_label(mercury____Compare___interactive_query__prog_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module30)
	init_entry(mercury____Unify___interactive_query__interactive_query_response_0_0);
	init_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i10);
	init_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i12);
	init_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i8);
	init_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i4);
	init_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___interactive_query__interactive_query_response_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i8);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i10);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i10);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i8);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(2), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___interactive_query__interactive_query_response_0_0));
Define_label(mercury____Unify___interactive_query__interactive_query_response_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(interactive_query_module31)
	init_entry(mercury____Index___interactive_query__interactive_query_response_0_0);
	init_label(mercury____Index___interactive_query__interactive_query_response_0_0_i6);
	init_label(mercury____Index___interactive_query__interactive_query_response_0_0_i7);
	init_label(mercury____Index___interactive_query__interactive_query_response_0_0_i5);
	init_label(mercury____Index___interactive_query__interactive_query_response_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___interactive_query__interactive_query_response_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___interactive_query__interactive_query_response_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___interactive_query__interactive_query_response_0_0_i5);
	r2 = MR_unmkbody(r1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury____Index___interactive_query__interactive_query_response_0_0_i6);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___interactive_query__interactive_query_response_0_0_i6);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury____Index___interactive_query__interactive_query_response_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___interactive_query__interactive_query_response_0_0_i7);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___interactive_query__interactive_query_response_0_0_i5);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___interactive_query__interactive_query_response_0_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(interactive_query_module32)
	init_entry(mercury____Compare___interactive_query__interactive_query_response_0_0);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i6);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i7);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i5);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i4);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i12);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i13);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i11);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i10);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i14);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i15);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i26);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i28);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i23);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i20);
	init_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___interactive_query__interactive_query_response_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i5);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i6);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i6);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i7);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i7);
	r3 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i5);
	r3 = (Integer) 4;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i4);
	r3 = (Integer) 1;
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i10);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i11);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i12);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
	}
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i12);
	if (((Integer) MR_unmkbody(r2) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i13);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i13);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i11);
	r4 = (Integer) 4;
	GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i10);
	r4 = (Integer) 1;
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i8);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i14);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i14);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i15);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i15);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i20);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i23);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i26);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i26);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i28);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i28);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i23);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		STATIC(mercury____Compare___interactive_query__interactive_query_response_0_0));
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i20);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___interactive_query__interactive_query_response_0_0));
Define_label(mercury____Compare___interactive_query__interactive_query_response_0_0_i1029);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___interactive_query__interactive_query_response_0_0));
END_MODULE

Declare_entry(mercury__builtin_unify_pred_2_0);

BEGIN_MODULE(interactive_query_module33)
	init_entry(mercury____Unify___interactive_query__io_pred_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___interactive_query__io_pred_0_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		STATIC(mercury____Unify___interactive_query__io_pred_0_0));
END_MODULE

Declare_entry(mercury__builtin_index_pred_2_0);

BEGIN_MODULE(interactive_query_module34)
	init_entry(mercury____Index___interactive_query__io_pred_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___interactive_query__io_pred_0_0);
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		STATIC(mercury____Index___interactive_query__io_pred_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_pred_3_0);

BEGIN_MODULE(interactive_query_module35)
	init_entry(mercury____Compare___interactive_query__io_pred_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___interactive_query__io_pred_0_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		STATIC(mercury____Compare___interactive_query__io_pred_0_0));
END_MODULE

Declare_entry(mercury__interactive_query__query_external_7_0);

void
ML_query_external(Word Mercury__argument1, Word Mercury__argument2, String Mercury__argument3, Word Mercury__argument4, Word Mercury__argument5)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = (Word) Mercury__argument3;
	r4 = Mercury__argument4;
	r5 = Mercury__argument5;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__interactive_query__query_external_7_0), FALSE);
	restore_transient_registers();
	restore_regs_from_mem(c_regs);
}


Declare_entry(mercury__interactive_query__query_7_0);

void
ML_query(Word Mercury__argument1, Word Mercury__argument2, String Mercury__argument3, Word Mercury__argument4, Word Mercury__argument5)
{
#if NUM_REAL_REGS > 0
	Word c_regs[NUM_REAL_REGS];
#endif

	save_regs_to_mem(c_regs);
	restore_registers();
	r1 = Mercury__argument1;
	r2 = Mercury__argument2;
	r3 = (Word) Mercury__argument3;
	r4 = Mercury__argument4;
	r5 = Mercury__argument5;
	save_transient_registers();
	(void) MR_call_engine(ENTRY(mercury__interactive_query__query_7_0), FALSE);
	restore_transient_registers();
	restore_regs_from_mem(c_regs);
}


#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__interactive_query_maybe_bunch_0(void)
{
	interactive_query_module0();
	interactive_query_module1();
	interactive_query_module2();
	interactive_query_module3();
	interactive_query_module4();
	interactive_query_module5();
	interactive_query_module6();
	interactive_query_module7();
	interactive_query_module8();
	interactive_query_module9();
	interactive_query_module10();
	interactive_query_module11();
	interactive_query_module12();
	interactive_query_module13();
	interactive_query_module14();
	interactive_query_module15();
	interactive_query_module16();
	interactive_query_module17();
	interactive_query_module18();
	interactive_query_module19();
	interactive_query_module20();
	interactive_query_module21();
	interactive_query_module22();
	interactive_query_module23();
	interactive_query_module24();
	interactive_query_module25();
	interactive_query_module26();
	interactive_query_module27();
	interactive_query_module28();
	interactive_query_module29();
	interactive_query_module30();
	interactive_query_module31();
	interactive_query_module32();
	interactive_query_module33();
	interactive_query_module34();
	interactive_query_module35();
}

#endif

void mercury__interactive_query__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__interactive_query__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__interactive_query_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_imports_0,
			interactive_query__imports_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_interactive_query_response_0,
			interactive_query__interactive_query_response_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_io_pred_0,
			interactive_query__io_pred_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_options_0,
			interactive_query__options_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_prog_0,
			interactive_query__prog_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_interactive_query__type_ctor_info_query_type_0,
			interactive_query__query_type_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
