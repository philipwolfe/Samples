/*
** Automatically generated from `interactive_query.m.m' by the
** Mercury compiler, version 0.9.1, configured for alpha-dec-osf3.2.  Do not edit.
*/
#ifndef INTERACTIVE_QUERY_H
#define INTERACTIVE_QUERY_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MERCURY_HDR_EXCLUDE_IMP_H
#include "mercury_imp.h"
#endif

void ML_query_external(Word, Word, String, Word, Word);
void ML_query(Word, Word, String, Word, Word);

#ifdef __cplusplus
}
#endif

#endif /* INTERACTIVE_QUERY_H */
