/*
** Automatically generated from `name_mangle.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__name_mangle__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___name_mangle__mercury_proc_0__ua0_2_0);
Define_extern_entry(mercury__fn__name_mangle__proc_name_mangle_1_0);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i2);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i6);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i4);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i12);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i15);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i18);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i17);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i13);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i24);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i26);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i27);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i28);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i29);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i30);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i31);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i32);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i33);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i34);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i35);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i36);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i37);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i38);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i39);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i40);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i43);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i44);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i47);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i48);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i49);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1009);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i51);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i53);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i56);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i57);
Declare_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i54);
Declare_static(mercury__name_mangle__sym_name_mangle_2_0);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i4);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i7);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i10);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i9);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i5);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i16);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i1005);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i18);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i19);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i20);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i21);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i22);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i23);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i24);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i25);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i26);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i27);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i28);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i29);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i30);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i31);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i15);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i14);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i32);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i3);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i39);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i42);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i41);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i37);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i48);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i1013);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i50);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i51);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i52);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i53);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i54);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i55);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i56);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i57);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i58);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i59);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i60);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i61);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i62);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i63);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i46);
Declare_label(mercury__name_mangle__sym_name_mangle_2_0_i64);
Declare_static(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i4);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i6);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i7);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i8);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i9);
Declare_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i2);
Declare_static(mercury__name_mangle__use_asm_labels_0_0);
Declare_label(mercury__name_mangle__use_asm_labels_0_0_i2);
Define_extern_entry(mercury____Unify___name_mangle__mercury_proc_0_0);
Declare_label(mercury____Unify___name_mangle__mercury_proc_0_0_i2);
Declare_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1006);
Declare_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__mercury_proc_0_0);
Define_extern_entry(mercury____Compare___name_mangle__mercury_proc_0_0);
Declare_label(mercury____Compare___name_mangle__mercury_proc_0_0_i3);
Declare_label(mercury____Compare___name_mangle__mercury_proc_0_0_i7);
Declare_label(mercury____Compare___name_mangle__mercury_proc_0_0_i11);
Declare_label(mercury____Compare___name_mangle__mercury_proc_0_0_i15);
Declare_label(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
Define_extern_entry(mercury____Unify___name_mangle__is_pred_or_func_0_0);
Declare_label(mercury____Unify___name_mangle__is_pred_or_func_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__is_pred_or_func_0_0);
Define_extern_entry(mercury____Compare___name_mangle__is_pred_or_func_0_0);
Define_extern_entry(mercury____Unify___name_mangle__module_name_0_0);
Define_extern_entry(mercury____Index___name_mangle__module_name_0_0);
Declare_label(mercury____Index___name_mangle__module_name_0_0_i3);
Define_extern_entry(mercury____Compare___name_mangle__module_name_0_0);
Define_extern_entry(mercury____Unify___name_mangle__sym_name_0_0);
Declare_label(mercury____Unify___name_mangle__sym_name_0_0_i5);
Declare_label(mercury____Unify___name_mangle__sym_name_0_0_i1007);
Declare_label(mercury____Unify___name_mangle__sym_name_0_0_i1008);
Declare_label(mercury____Unify___name_mangle__sym_name_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__sym_name_0_0);
Declare_label(mercury____Index___name_mangle__sym_name_0_0_i3);
Define_extern_entry(mercury____Compare___name_mangle__sym_name_0_0);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i3);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i2);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i5);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i4);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i6);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i7);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i14);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i11);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i1015);
Declare_label(mercury____Compare___name_mangle__sym_name_0_0_i24);
Define_extern_entry(mercury____Unify___name_mangle__pred_name_0_0);
Declare_label(mercury____Unify___name_mangle__pred_name_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__pred_name_0_0);
Define_extern_entry(mercury____Compare___name_mangle__pred_name_0_0);
Define_extern_entry(mercury____Unify___name_mangle__arity_0_0);
Declare_label(mercury____Unify___name_mangle__arity_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__arity_0_0);
Define_extern_entry(mercury____Compare___name_mangle__arity_0_0);
Define_extern_entry(mercury____Unify___name_mangle__mode_num_0_0);
Declare_label(mercury____Unify___name_mangle__mode_num_0_0_i1);
Define_extern_entry(mercury____Index___name_mangle__mode_num_0_0);
Define_extern_entry(mercury____Compare___name_mangle__mode_num_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_arity_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_is_pred_or_func_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_mercury_proc_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_mode_num_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_module_name_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_pred_name_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_sym_name_0;

static const struct mercury_data_name_mangle__common_0_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	String f11;
	String f12;
	String f13;
	String f14;
	String f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	String f27;
	Integer f28;
	String f29;
	String f30;
	Integer f31;
	String f32;
}  mercury_data_name_mangle__common_0;

static const struct mercury_data_name_mangle__common_1_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_name_mangle__common_1;

static const struct mercury_data_name_mangle__common_2_struct {
	Word * f1;
}  mercury_data_name_mangle__common_2;

static const struct mercury_data_name_mangle__common_3_struct {
	Word * f1;
}  mercury_data_name_mangle__common_3;

static const struct mercury_data_name_mangle__common_4_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_name_mangle__common_4;

static const struct mercury_data_name_mangle__common_5_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_name_mangle__common_5;

static const struct mercury_data_name_mangle__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__common_6;

static const struct mercury_data_name_mangle__common_7_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__common_7;

static const struct mercury_data_name_mangle__common_8_struct {
	Word * f1;
}  mercury_data_name_mangle__common_8;

static const struct mercury_data_name_mangle__common_9_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__common_9;

static const struct mercury_data_name_mangle__common_10_struct {
	Word * f1;
}  mercury_data_name_mangle__common_10;

static const struct mercury_data_name_mangle__common_11_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_name_mangle__common_11;

static const struct mercury_data_name_mangle__common_12_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_name_mangle__common_12;

static const struct mercury_data_name_mangle__type_ctor_functors_sym_name_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_functors_sym_name_0;

static const struct mercury_data_name_mangle__type_ctor_layout_sym_name_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_sym_name_0;

static const struct mercury_data_name_mangle__type_ctor_functors_pred_name_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__type_ctor_functors_pred_name_0;

static const struct mercury_data_name_mangle__type_ctor_layout_pred_name_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_pred_name_0;

static const struct mercury_data_name_mangle__type_ctor_functors_module_name_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__type_ctor_functors_module_name_0;

static const struct mercury_data_name_mangle__type_ctor_layout_module_name_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_module_name_0;

static const struct mercury_data_name_mangle__type_ctor_functors_mode_num_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__type_ctor_functors_mode_num_0;

static const struct mercury_data_name_mangle__type_ctor_layout_mode_num_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_mode_num_0;

static const struct mercury_data_name_mangle__type_ctor_functors_mercury_proc_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_name_mangle__type_ctor_functors_mercury_proc_0;

static const struct mercury_data_name_mangle__type_ctor_layout_mercury_proc_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_mercury_proc_0;

static const struct mercury_data_name_mangle__type_ctor_functors_is_pred_or_func_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__type_ctor_functors_is_pred_or_func_0;

static const struct mercury_data_name_mangle__type_ctor_layout_is_pred_or_func_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_is_pred_or_func_0;

static const struct mercury_data_name_mangle__type_ctor_functors_arity_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_name_mangle__type_ctor_functors_arity_0;

static const struct mercury_data_name_mangle__type_ctor_layout_arity_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_name_mangle__type_ctor_layout_arity_0;

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_arity_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__arity_0_0),
	ENTRY(mercury____Index___name_mangle__arity_0_0),
	ENTRY(mercury____Compare___name_mangle__arity_0_0),
	(Integer) 6,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_arity_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_arity_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("arity", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_is_pred_or_func_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__is_pred_or_func_0_0),
	ENTRY(mercury____Index___name_mangle__is_pred_or_func_0_0),
	ENTRY(mercury____Compare___name_mangle__is_pred_or_func_0_0),
	(Integer) 0,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_is_pred_or_func_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_is_pred_or_func_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("is_pred_or_func", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_mercury_proc_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__mercury_proc_0_0),
	ENTRY(mercury____Index___name_mangle__mercury_proc_0_0),
	ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0),
	(Integer) 2,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_mercury_proc_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_mercury_proc_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("mercury_proc", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_mode_num_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__mode_num_0_0),
	ENTRY(mercury____Index___name_mangle__mode_num_0_0),
	ENTRY(mercury____Compare___name_mangle__mode_num_0_0),
	(Integer) 6,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_mode_num_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_mode_num_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("mode_num", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_module_name_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__module_name_0_0),
	ENTRY(mercury____Index___name_mangle__module_name_0_0),
	ENTRY(mercury____Compare___name_mangle__module_name_0_0),
	(Integer) 6,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_module_name_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_module_name_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("module_name", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_pred_name_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__pred_name_0_0),
	ENTRY(mercury____Index___name_mangle__pred_name_0_0),
	ENTRY(mercury____Compare___name_mangle__pred_name_0_0),
	(Integer) 6,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_pred_name_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_pred_name_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("pred_name", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_name_mangle__type_ctor_info_sym_name_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___name_mangle__sym_name_0_0),
	ENTRY(mercury____Index___name_mangle__sym_name_0_0),
	ENTRY(mercury____Compare___name_mangle__sym_name_0_0),
	(Integer) 2,
	(Word *) &mercury_data_name_mangle__type_ctor_functors_sym_name_0,
	(Word *) &mercury_data_name_mangle__type_ctor_layout_sym_name_0,
	MR_string_const("name_mangle", 11),
	MR_string_const("sym_name", 8),
	(Integer) 3
};

static const struct mercury_data_name_mangle__common_0_struct mercury_data_name_mangle__common_0 = {
	MR_string_const("!", 1),
	MR_string_const(">=", 2),
	MR_string_const("=<", 2),
	MR_string_const("\\=", 2),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("+", 1),
	MR_string_const("*", 1),
	MR_string_const("-", 1),
	MR_string_const(",", 1),
	MR_string_const("/", 1),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const(";", 1),
	(Integer) 0,
	MR_string_const("=", 1),
	MR_string_const("<", 1),
	(Integer) 0,
	MR_string_const(">", 1)
};

static const struct mercury_data_name_mangle__common_1_struct mercury_data_name_mangle__common_1 = {
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) 2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1
};

static const struct mercury_data_name_mangle__common_2_struct mercury_data_name_mangle__common_2 = {
	(Word *) &mercury_data_name_mangle__type_ctor_info_sym_name_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_name_mangle__common_3_struct mercury_data_name_mangle__common_3 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_name_mangle__common_4_struct mercury_data_name_mangle__common_4 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_3),
	MR_string_const("qualified", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_name_mangle__common_5_struct mercury_data_name_mangle__common_5 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_3),
	MR_string_const("unqualified", 11),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_name_mangle__common_6_struct mercury_data_name_mangle__common_6 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_3)
};

static const struct mercury_data_name_mangle__common_7_struct mercury_data_name_mangle__common_7 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_name_mangle__common_8_struct mercury_data_name_mangle__common_8 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_name_mangle__common_9_struct mercury_data_name_mangle__common_9 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_8)
};

static const struct mercury_data_name_mangle__common_10_struct mercury_data_name_mangle__common_10 = {
	(Word *) &mercury_data_name_mangle__type_ctor_info_is_pred_or_func_0
};

static const struct mercury_data_name_mangle__common_11_struct mercury_data_name_mangle__common_11 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_8),
	MR_string_const("mercury_proc", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_name_mangle__common_12_struct mercury_data_name_mangle__common_12 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("predicate", 9),
	MR_string_const("function", 8)
};

static const struct mercury_data_name_mangle__type_ctor_functors_sym_name_0_struct mercury_data_name_mangle__type_ctor_functors_sym_name_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_5)
};

static const struct mercury_data_name_mangle__type_ctor_layout_sym_name_0_struct mercury_data_name_mangle__type_ctor_layout_sym_name_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_name_mangle__common_4),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_name_mangle__common_5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_name_mangle__type_ctor_functors_pred_name_0_struct mercury_data_name_mangle__type_ctor_functors_pred_name_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_3)
};

static const struct mercury_data_name_mangle__type_ctor_layout_pred_name_0_struct mercury_data_name_mangle__type_ctor_layout_pred_name_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_6)
};

static const struct mercury_data_name_mangle__type_ctor_functors_module_name_0_struct mercury_data_name_mangle__type_ctor_functors_module_name_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_2)
};

static const struct mercury_data_name_mangle__type_ctor_layout_module_name_0_struct mercury_data_name_mangle__type_ctor_layout_module_name_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_7)
};

static const struct mercury_data_name_mangle__type_ctor_functors_mode_num_0_struct mercury_data_name_mangle__type_ctor_functors_mode_num_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_8)
};

static const struct mercury_data_name_mangle__type_ctor_layout_mode_num_0_struct mercury_data_name_mangle__type_ctor_layout_mode_num_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9)
};

static const struct mercury_data_name_mangle__type_ctor_functors_mercury_proc_0_struct mercury_data_name_mangle__type_ctor_functors_mercury_proc_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_11)
};

static const struct mercury_data_name_mangle__type_ctor_layout_mercury_proc_0_struct mercury_data_name_mangle__type_ctor_layout_mercury_proc_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_name_mangle__common_11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_name_mangle__type_ctor_functors_is_pred_or_func_0_struct mercury_data_name_mangle__type_ctor_functors_is_pred_or_func_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_12)
};

static const struct mercury_data_name_mangle__type_ctor_layout_is_pred_or_func_0_struct mercury_data_name_mangle__type_ctor_layout_is_pred_or_func_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_12)
};

static const struct mercury_data_name_mangle__type_ctor_functors_arity_0_struct mercury_data_name_mangle__type_ctor_functors_arity_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_8)
};

static const struct mercury_data_name_mangle__type_ctor_layout_arity_0_struct mercury_data_name_mangle__type_ctor_layout_arity_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_name_mangle__common_9)
};


BEGIN_MODULE(name_mangle_module0)
	init_entry(mercury____Index___name_mangle__mercury_proc_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___name_mangle__mercury_proc_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___name_mangle__mercury_proc_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__string__is_alnum_or_underscore_1_0);
Declare_entry(mercury__string__append_3_1);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(name_mangle_module1)
	init_entry(mercury__fn__name_mangle__proc_name_mangle_1_0);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i2);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i6);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i4);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i12);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i15);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i18);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i17);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i13);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i24);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i26);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i27);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i28);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i29);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i30);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i31);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i32);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i33);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i34);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i35);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i36);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i37);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i38);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i39);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i40);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i43);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i44);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i47);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i48);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i49);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1009);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i51);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i53);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i56);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i57);
	init_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i54);
BEGIN_CODE

/* code for predicate 'proc_name_mangle'/2 in mode 0 */
Define_entry(mercury__fn__name_mangle__proc_name_mangle_1_0);
	MR_incr_sp_push_msg(9, "name_mangle:proc_name_mangle/2");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__name_mangle__sym_name_mangle_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i2,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i6);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0), (char *)(Word) MR_string_const("builtin", 7)) != 0))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i6);
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(2) = r2;
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i12);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i6);
	if ((strcmp((char *)MR_stackvar(3), (char *)(Word) MR_string_const("main", 4)) != 0))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i4);
	if (((Integer) MR_stackvar(4) != (Integer) 2))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i4);
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(2) = r2;
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i12);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i4);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("__", 2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i12,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i12);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__string__is_alnum_or_underscore_1_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i15,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i15);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i13);
	r1 = (Word) MR_string_const("f_", 2);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i18,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i18);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i17);
	r1 = (Word) MR_string_const("f__", 3);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i23,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i17);
	MR_stackvar(7) = MR_stackvar(6);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i43);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i13);
	r1 = MR_stackvar(6);
	r2 = (hash_string(r1) & (Integer) 31);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i24);
	while (1) {
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_0))[(Integer) r2];
	if (((Integer) r3 && (strcmp((char *)r3, (char *)r1) == 0)))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i26);
	r2 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_1))[(Integer) r2];
	if (((Integer) r2 >= (Integer) 0))
		continue;
	break; } /* end while */
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007);
	call_localret(STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i40,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i26);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i27) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i28) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i29) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i30) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i31) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i32) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i33) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i34) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i35) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i36) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i37) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i38) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i1007) AND
		LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i39));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i27);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_cut", 5);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i28);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_greater_or_equal", 18);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i29);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_less_or_equal", 15);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i30);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_not_equal", 11);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i31);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_plus", 6);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i32);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_times", 7);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i33);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_minus", 7);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i34);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_comma", 7);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i35);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_slash", 7);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i36);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_semicolon", 11);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i37);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_equal", 7);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i38);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_less_than", 11);
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i39);
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) MR_string_const("f_greater_than", 14);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i23);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	MR_stackvar(7) = r1;
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i43);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i40);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	r2 = r1;
	r1 = (Word) MR_string_const("f", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i23,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i43);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i44);
	r1 = ((Integer) MR_stackvar(4) - (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i47,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i44);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i47,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i47);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	MR_stackvar(8) = r1;
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i48,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i48);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__fn__name_mangle__proc_name_mangle_1_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i49,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i49);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i51);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i1009);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	r2 = r1;
	r3 = r1;
	r1 = (Word) MR_string_const("mercury__", 9);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i53,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i51);
	r2 = r1;
	r1 = (Word) MR_string_const("fn__", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__fn__name_mangle__proc_name_mangle_1_0_i1009,
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i53);
	update_prof_current_proc(LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0));
	r2 = r1;
	{
#define MR_PROC_LABEL mercury__fn__name_mangle__proc_name_mangle_1_0
{
#line 215 "name_mangle.m"

#ifdef USE_ASM_LABELS
	SUCCESS_INDICATOR = TRUE;
#else
	SUCCESS_INDICATOR = FALSE;
#endif
;}
#line 1060 "name_mangle.c"
if (!r1) GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i56);
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i57);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i56);
	MR_stackvar(7) = r2;
	GOTO_LABEL(mercury__fn__name_mangle__proc_name_mangle_1_0_i54);
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i57);
	r1 = (Word) MR_string_const("_entry_", 7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__fn__name_mangle__proc_name_mangle_1_0));
Define_label(mercury__fn__name_mangle__proc_name_mangle_1_0_i54);
	r1 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module2)
	init_entry(mercury__name_mangle__sym_name_mangle_2_0);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i4);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i7);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i10);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i9);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i5);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i16);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i1005);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i18);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i19);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i20);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i21);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i22);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i23);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i24);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i25);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i26);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i27);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i28);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i29);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i30);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i31);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i15);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i14);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i32);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i3);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i39);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i42);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i41);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i37);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i48);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i1013);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i50);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i51);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i52);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i53);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i54);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i55);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i56);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i57);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i58);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i59);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i60);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i61);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i62);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i63);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i46);
	init_label(mercury__name_mangle__sym_name_mangle_2_0_i64);
BEGIN_CODE

/* code for predicate 'sym_name_mangle'/2 in mode 0 */
Define_static(mercury__name_mangle__sym_name_mangle_2_0);
	MR_incr_sp_push_msg(3, "name_mangle:sym_name_mangle/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	localcall(mercury__name_mangle__sym_name_mangle_2_0,
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i4),
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i4);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__is_alnum_or_underscore_1_0),
		mercury__name_mangle__sym_name_mangle_2_0_i7,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i7);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i5);
	r1 = (Word) MR_string_const("f_", 2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__name_mangle__sym_name_mangle_2_0_i10,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i10);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i9);
	r1 = (Word) MR_string_const("f__", 3);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__name_mangle__sym_name_mangle_2_0_i15,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i9);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_string_const("__", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i5);
	r1 = MR_stackvar(2);
	r2 = (hash_string(MR_stackvar(1)) & (Integer) 31);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i16);
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_0))[(Integer) r2];
	if (!(r3))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i1005);
	if ((strcmp((char *)r3, (char *)MR_stackvar(1)) == 0))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i18);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i1005);
	r2 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_1))[(Integer) r2];
	if (((Integer) r2 >= (Integer) 0))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i16);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i18);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i19) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i20) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i21) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i22) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i23) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i24) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i25) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i26) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i27) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i28) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i29) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i30) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i14) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i31));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i19);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_cut", 5);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i20);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_greater_or_equal", 18);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i21);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_less_or_equal", 15);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i22);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_not_equal", 11);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i23);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_plus", 6);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i24);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_times", 7);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i25);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_minus", 7);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i26);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_comma", 7);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i27);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_slash", 7);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i28);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_semicolon", 11);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i29);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_equal", 7);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i30);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_less_than", 11);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i15);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i31);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("f_greater_than", 14);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i15);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("__", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__name_mangle__sym_name_mangle_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
	}
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i14);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0),
		mercury__name_mangle__sym_name_mangle_2_0_i32,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i32);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("f", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__name_mangle__sym_name_mangle_2_0_i15,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__string__is_alnum_or_underscore_1_0),
		mercury__name_mangle__sym_name_mangle_2_0_i39,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i39);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i37);
	r1 = (Word) MR_string_const("f_", 2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__name_mangle__sym_name_mangle_2_0_i42,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i42);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i41);
	r1 = (Word) MR_string_const("f__", 3);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i41);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i37);
	r2 = MR_stackvar(1);
	r1 = (hash_string(r2) & (Integer) 31);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i48);
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_0))[(Integer) r1];
	if (!(r3))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i1013);
	if ((strcmp((char *)r3, (char *)r2) == 0))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i50);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i1013);
	r1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_name_mangle__common_1))[(Integer) r1];
	if (((Integer) r1 >= (Integer) 0))
		GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i48);
	GOTO_LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46);
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i50);
	COMPUTED_GOTO((Unsigned) r1,
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i51) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i52) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i53) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i54) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i55) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i56) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i57) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i58) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i59) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i60) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i61) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i62) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i46) AND
		LABEL(mercury__name_mangle__sym_name_mangle_2_0_i63));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i51);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_cut", 5);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i52);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_greater_or_equal", 18);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i53);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_less_or_equal", 15);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i54);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_not_equal", 11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i55);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_plus", 6);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i56);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_times", 7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i57);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_minus", 7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i58);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_comma", 7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i59);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_slash", 7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i60);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_semicolon", 11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i61);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_equal", 7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i62);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_less_than", 11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i63);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("f_greater_than", 14);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i46);
	r1 = r2;
	call_localret(STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0),
		mercury__name_mangle__sym_name_mangle_2_0_i64,
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
Define_label(mercury__name_mangle__sym_name_mangle_2_0_i64);
	update_prof_current_proc(LABEL(mercury__name_mangle__sym_name_mangle_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("f", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__name_mangle__sym_name_mangle_2_0));
END_MODULE

Declare_entry(mercury__string__first_char_3_3);
Declare_entry(mercury__char__to_int_2_0);

BEGIN_MODULE(name_mangle_module3)
	init_entry(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i4);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i6);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i7);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i8);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i9);
	init_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i2);
BEGIN_CODE

/* code for predicate 'convert_to_valid_c_identifier_2'/2 in mode 0 */
Define_static(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0);
	MR_incr_sp_push_msg(3, "name_mangle:convert_to_valid_c_identifier_2/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i4,
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i4);
	update_prof_current_proc(LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i2);
	MR_stackvar(2) = r3;
	r1 = r2;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i6,
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i6);
	update_prof_current_proc(LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i7,
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i7);
	update_prof_current_proc(LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("_", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i8,
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i8);
	update_prof_current_proc(LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0,
		LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i9),
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i9);
	update_prof_current_proc(LABEL(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0));
Define_label(mercury__name_mangle__convert_to_valid_c_identifier_2_2_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module4)
	init_entry(mercury__name_mangle__use_asm_labels_0_0);
	init_label(mercury__name_mangle__use_asm_labels_0_0_i2);
BEGIN_CODE

/* code for predicate 'use_asm_labels'/0 in mode 0 */
Define_static(mercury__name_mangle__use_asm_labels_0_0);
	{
#define MR_PROC_LABEL mercury__name_mangle__use_asm_labels_0_0
{
#line 215 "name_mangle.m"

#ifdef USE_ASM_LABELS
	SUCCESS_INDICATOR = TRUE;
#else
	SUCCESS_INDICATOR = FALSE;
#endif
;}
#line 1568 "name_mangle.c"
if (!r1) GOTO_LABEL(mercury__name_mangle__use_asm_labels_0_0_i2);
#undef MR_PROC_LABEL

	}
	r1 = TRUE;
	proceed();
Define_label(mercury__name_mangle__use_asm_labels_0_0_i2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module5)
	init_entry(mercury____Unify___name_mangle__mercury_proc_0_0);
	init_label(mercury____Unify___name_mangle__mercury_proc_0_0_i2);
	init_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1006);
	init_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__mercury_proc_0_0);
	MR_incr_sp_push_msg(7, "name_mangle:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != r3))
		GOTO_LABEL(mercury____Unify___name_mangle__mercury_proc_0_0_i1006);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(STATIC(mercury____Unify___name_mangle__sym_name_0_0),
		mercury____Unify___name_mangle__mercury_proc_0_0_i2,
		ENTRY(mercury____Unify___name_mangle__mercury_proc_0_0));
Define_label(mercury____Unify___name_mangle__mercury_proc_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___name_mangle__mercury_proc_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
	if ((strcmp((char *)MR_stackvar(1), (char *)MR_stackvar(4)) != 0))
		GOTO_LABEL(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(5)))
		GOTO_LABEL(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(6)))
		GOTO_LABEL(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1006);
	r1 = FALSE;
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___name_mangle__mercury_proc_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module6)
	init_entry(mercury____Index___name_mangle__mercury_proc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__mercury_proc_0_0);
	tailcall(STATIC(mercury____Index___name_mangle__mercury_proc_0__ua0_2_0),
		ENTRY(mercury____Index___name_mangle__mercury_proc_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(name_mangle_module7)
	init_entry(mercury____Compare___name_mangle__mercury_proc_0_0);
	init_label(mercury____Compare___name_mangle__mercury_proc_0_0_i3);
	init_label(mercury____Compare___name_mangle__mercury_proc_0_0_i7);
	init_label(mercury____Compare___name_mangle__mercury_proc_0_0_i11);
	init_label(mercury____Compare___name_mangle__mercury_proc_0_0_i15);
	init_label(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__mercury_proc_0_0);
	MR_incr_sp_push_msg(9, "name_mangle:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___name_mangle__mercury_proc_0_0_i3,
		ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0));
Define_label(mercury____Compare___name_mangle__mercury_proc_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___name_mangle__mercury_proc_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury____Compare___name_mangle__sym_name_0_0),
		mercury____Compare___name_mangle__mercury_proc_0_0_i7,
		ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0));
Define_label(mercury____Compare___name_mangle__mercury_proc_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___name_mangle__mercury_proc_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___name_mangle__mercury_proc_0_0_i11,
		ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0));
Define_label(mercury____Compare___name_mangle__mercury_proc_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___name_mangle__mercury_proc_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___name_mangle__mercury_proc_0_0_i15,
		ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0));
Define_label(mercury____Compare___name_mangle__mercury_proc_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___name_mangle__mercury_proc_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___name_mangle__mercury_proc_0_0));
Define_label(mercury____Compare___name_mangle__mercury_proc_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module8)
	init_entry(mercury____Unify___name_mangle__is_pred_or_func_0_0);
	init_label(mercury____Unify___name_mangle__is_pred_or_func_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__is_pred_or_func_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___name_mangle__is_pred_or_func_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___name_mangle__is_pred_or_func_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module9)
	init_entry(mercury____Index___name_mangle__is_pred_or_func_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__is_pred_or_func_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module10)
	init_entry(mercury____Compare___name_mangle__is_pred_or_func_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__is_pred_or_func_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___name_mangle__is_pred_or_func_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module11)
	init_entry(mercury____Unify___name_mangle__module_name_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__module_name_0_0);
	tailcall(STATIC(mercury____Unify___name_mangle__sym_name_0_0),
		ENTRY(mercury____Unify___name_mangle__module_name_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module12)
	init_entry(mercury____Index___name_mangle__module_name_0_0);
	init_label(mercury____Index___name_mangle__module_name_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__module_name_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___name_mangle__module_name_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___name_mangle__module_name_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module13)
	init_entry(mercury____Compare___name_mangle__module_name_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__module_name_0_0);
	tailcall(STATIC(mercury____Compare___name_mangle__sym_name_0_0),
		ENTRY(mercury____Compare___name_mangle__module_name_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module14)
	init_entry(mercury____Unify___name_mangle__sym_name_0_0);
	init_label(mercury____Unify___name_mangle__sym_name_0_0_i5);
	init_label(mercury____Unify___name_mangle__sym_name_0_0_i1007);
	init_label(mercury____Unify___name_mangle__sym_name_0_0_i1008);
	init_label(mercury____Unify___name_mangle__sym_name_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__sym_name_0_0);
	MR_incr_sp_push_msg(3, "name_mangle:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1007);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1008);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury____Unify___name_mangle__sym_name_0_0,
		LABEL(mercury____Unify___name_mangle__sym_name_0_0_i5),
		ENTRY(mercury____Unify___name_mangle__sym_name_0_0));
Define_label(mercury____Unify___name_mangle__sym_name_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___name_mangle__sym_name_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1);
	if ((strcmp((char *)MR_stackvar(1), (char *)MR_stackvar(2)) != 0))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___name_mangle__sym_name_0_0_i1007);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((strcmp((char *)r3, (char *)MR_const_field(MR_mktag(1), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___name_mangle__sym_name_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___name_mangle__sym_name_0_0_i1008);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___name_mangle__sym_name_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module15)
	init_entry(mercury____Index___name_mangle__sym_name_0_0);
	init_label(mercury____Index___name_mangle__sym_name_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__sym_name_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___name_mangle__sym_name_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___name_mangle__sym_name_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(name_mangle_module16)
	init_entry(mercury____Compare___name_mangle__sym_name_0_0);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i3);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i2);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i5);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i4);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i6);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i7);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i14);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i11);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i1015);
	init_label(mercury____Compare___name_mangle__sym_name_0_0_i24);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__sym_name_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i2);
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i4);
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i1015);
	MR_incr_sp_push_msg(3, "name_mangle:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury____Compare___name_mangle__sym_name_0_0,
		LABEL(mercury____Compare___name_mangle__sym_name_0_0_i14),
		ENTRY(mercury____Compare___name_mangle__sym_name_0_0));
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___name_mangle__sym_name_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i24);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___name_mangle__sym_name_0_0));
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___name_mangle__sym_name_0_0_i1015);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___name_mangle__sym_name_0_0));
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i1015);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___name_mangle__sym_name_0_0));
Define_label(mercury____Compare___name_mangle__sym_name_0_0_i24);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module17)
	init_entry(mercury____Unify___name_mangle__pred_name_0_0);
	init_label(mercury____Unify___name_mangle__pred_name_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__pred_name_0_0);
	if ((strcmp((char *)r1, (char *)r2) != 0))
		GOTO_LABEL(mercury____Unify___name_mangle__pred_name_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___name_mangle__pred_name_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_string_2_0);

BEGIN_MODULE(name_mangle_module18)
	init_entry(mercury____Index___name_mangle__pred_name_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__pred_name_0_0);
	tailcall(ENTRY(mercury__builtin_index_string_2_0),
		ENTRY(mercury____Index___name_mangle__pred_name_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module19)
	init_entry(mercury____Compare___name_mangle__pred_name_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__pred_name_0_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___name_mangle__pred_name_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module20)
	init_entry(mercury____Unify___name_mangle__arity_0_0);
	init_label(mercury____Unify___name_mangle__arity_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__arity_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___name_mangle__arity_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___name_mangle__arity_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_int_2_0);

BEGIN_MODULE(name_mangle_module21)
	init_entry(mercury____Index___name_mangle__arity_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__arity_0_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___name_mangle__arity_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module22)
	init_entry(mercury____Compare___name_mangle__arity_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__arity_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___name_mangle__arity_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module23)
	init_entry(mercury____Unify___name_mangle__mode_num_0_0);
	init_label(mercury____Unify___name_mangle__mode_num_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___name_mangle__mode_num_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___name_mangle__mode_num_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___name_mangle__mode_num_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(name_mangle_module24)
	init_entry(mercury____Index___name_mangle__mode_num_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___name_mangle__mode_num_0_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		ENTRY(mercury____Index___name_mangle__mode_num_0_0));
END_MODULE


BEGIN_MODULE(name_mangle_module25)
	init_entry(mercury____Compare___name_mangle__mode_num_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___name_mangle__mode_num_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___name_mangle__mode_num_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__name_mangle_maybe_bunch_0(void)
{
	name_mangle_module0();
	name_mangle_module1();
	name_mangle_module2();
	name_mangle_module3();
	name_mangle_module4();
	name_mangle_module5();
	name_mangle_module6();
	name_mangle_module7();
	name_mangle_module8();
	name_mangle_module9();
	name_mangle_module10();
	name_mangle_module11();
	name_mangle_module12();
	name_mangle_module13();
	name_mangle_module14();
	name_mangle_module15();
	name_mangle_module16();
	name_mangle_module17();
	name_mangle_module18();
	name_mangle_module19();
	name_mangle_module20();
	name_mangle_module21();
	name_mangle_module22();
	name_mangle_module23();
	name_mangle_module24();
	name_mangle_module25();
}

#endif

void mercury__name_mangle__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__name_mangle__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__name_mangle_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_arity_0,
			name_mangle__arity_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_is_pred_or_func_0,
			name_mangle__is_pred_or_func_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_mercury_proc_0,
			name_mangle__mercury_proc_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_mode_num_0,
			name_mangle__mode_num_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_module_name_0,
			name_mangle__module_name_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_pred_name_0,
			name_mangle__pred_name_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_name_mangle__type_ctor_info_sym_name_0,
			name_mangle__sym_name_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
