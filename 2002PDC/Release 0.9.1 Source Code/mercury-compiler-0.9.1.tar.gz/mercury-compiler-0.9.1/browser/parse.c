/*
** Automatically generated from `parse.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__parse__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___parse__external_request_0__ua0_2_0);
Define_extern_entry(mercury__parse__read_command_4_0);
Declare_label(mercury__parse__read_command_4_0_i1003);
Declare_label(mercury__parse__read_command_4_0_i2);
Declare_label(mercury__parse__read_command_4_0_i13);
Declare_label(mercury__parse__read_command_4_0_i14);
Declare_label(mercury__parse__read_command_4_0_i15);
Declare_label(mercury__parse__read_command_4_0_i16);
Declare_label(mercury__parse__read_command_4_0_i5);
Declare_label(mercury__parse__read_command_4_0_i6);
Declare_label(mercury__parse__read_command_4_0_i7);
Declare_label(mercury__parse__read_command_4_0_i10);
Declare_label(mercury__parse__read_command_4_0_i9);
Define_extern_entry(mercury__parse__read_command_external_3_0);
Declare_label(mercury__parse__read_command_external_3_0_i2);
Declare_label(mercury__parse__read_command_external_3_0_i5);
Declare_label(mercury__parse__read_command_external_3_0_i6);
Declare_label(mercury__parse__read_command_external_3_0_i9);
Declare_label(mercury__parse__read_command_external_3_0_i8);
Declare_label(mercury__parse__read_command_external_3_0_i3);
Declare_label(mercury__parse__read_command_external_3_0_i12);
Define_extern_entry(mercury__parse__default_depth_1_0);
Declare_static(mercury__parse__lexer_2_0);
Declare_label(mercury__parse__lexer_2_0_i1009);
Declare_label(mercury__parse__lexer_2_0_i3);
Declare_label(mercury__parse__lexer_2_0_i4);
Declare_label(mercury__parse__lexer_2_0_i9);
Declare_label(mercury__parse__lexer_2_0_i7);
Declare_label(mercury__parse__lexer_2_0_i12);
Declare_label(mercury__parse__lexer_2_0_i10);
Declare_label(mercury__parse__lexer_2_0_i15);
Declare_label(mercury__parse__lexer_2_0_i13);
Declare_label(mercury__parse__lexer_2_0_i18);
Declare_label(mercury__parse__lexer_2_0_i16);
Declare_label(mercury__parse__lexer_2_0_i21);
Declare_label(mercury__parse__lexer_2_0_i23);
Declare_label(mercury__parse__lexer_2_0_i24);
Declare_label(mercury__parse__lexer_2_0_i19);
Declare_label(mercury__parse__lexer_2_0_i28);
Declare_label(mercury__parse__lexer_2_0_i26);
Declare_label(mercury__parse__lexer_2_0_i33);
Declare_label(mercury__parse__lexer_2_0_i31);
Declare_label(mercury__parse__lexer_2_0_i36);
Declare_static(mercury__parse__lexer_dots_2_0);
Declare_label(mercury__parse__lexer_dots_2_0_i3);
Declare_label(mercury__parse__lexer_dots_2_0_i6);
Declare_label(mercury__parse__lexer_dots_2_0_i4);
Declare_label(mercury__parse__lexer_dots_2_0_i7);
Declare_static(mercury__parse__lexer_num_3_0);
Declare_label(mercury__parse__lexer_num_3_0_i2);
Declare_label(mercury__parse__lexer_num_3_0_i3);
Declare_label(mercury__parse__lexer_num_3_0_i4);
Declare_static(mercury__parse__digits_to_int_acc_3_0);
Declare_label(mercury__parse__digits_to_int_acc_3_0_i1001);
Declare_label(mercury__parse__digits_to_int_acc_3_0_i4);
Declare_label(mercury__parse__digits_to_int_acc_3_0_i5);
Declare_label(mercury__parse__digits_to_int_acc_3_0_i2);
Declare_static(mercury__parse__lexer_name_3_0);
Declare_label(mercury__parse__lexer_name_3_0_i2);
Declare_label(mercury__parse__lexer_name_3_0_i3);
Declare_label(mercury__parse__lexer_name_3_0_i4);
Declare_static(mercury__parse__parse_2_0);
Declare_label(mercury__parse__parse_2_0_i1126);
Declare_label(mercury__parse__parse_2_0_i1250);
Declare_label(mercury__parse__parse_2_0_i1252);
Declare_label(mercury__parse__parse_2_0_i3);
Declare_label(mercury__parse__parse_2_0_i12);
Declare_label(mercury__parse__parse_2_0_i16);
Declare_label(mercury__parse__parse_2_0_i21);
Declare_label(mercury__parse__parse_2_0_i19);
Declare_label(mercury__parse__parse_2_0_i26);
Declare_label(mercury__parse__parse_2_0_i27);
Declare_label(mercury__parse__parse_2_0_i29);
Declare_label(mercury__parse__parse_2_0_i30);
Declare_label(mercury__parse__parse_2_0_i32);
Declare_label(mercury__parse__parse_2_0_i33);
Declare_label(mercury__parse__parse_2_0_i25);
Declare_label(mercury__parse__parse_2_0_i36);
Declare_label(mercury__parse__parse_2_0_i11);
Declare_label(mercury__parse__parse_2_0_i40);
Declare_label(mercury__parse__parse_2_0_i47);
Declare_label(mercury__parse__parse_2_0_i52);
Declare_label(mercury__parse__parse_2_0_i50);
Declare_label(mercury__parse__parse_2_0_i57);
Declare_label(mercury__parse__parse_2_0_i58);
Declare_label(mercury__parse__parse_2_0_i60);
Declare_label(mercury__parse__parse_2_0_i61);
Declare_label(mercury__parse__parse_2_0_i63);
Declare_label(mercury__parse__parse_2_0_i64);
Declare_label(mercury__parse__parse_2_0_i56);
Declare_label(mercury__parse__parse_2_0_i67);
Declare_label(mercury__parse__parse_2_0_i44);
Declare_label(mercury__parse__parse_2_0_i74);
Declare_label(mercury__parse__parse_2_0_i77);
Declare_label(mercury__parse__parse_2_0_i83);
Declare_label(mercury__parse__parse_2_0_i89);
Declare_label(mercury__parse__parse_2_0_i95);
Declare_label(mercury__parse__parse_2_0_i105);
Declare_label(mercury__parse__parse_2_0_i108);
Declare_label(mercury__parse__parse_2_0_i71);
Declare_label(mercury__parse__parse_2_0_i120);
Declare_label(mercury__parse__parse_2_0_i126);
Declare_label(mercury__parse__parse_2_0_i124);
Declare_label(mercury__parse__parse_2_0_i132);
Declare_label(mercury__parse__parse_2_0_i130);
Declare_label(mercury__parse__parse_2_0_i138);
Declare_label(mercury__parse__parse_2_0_i136);
Declare_label(mercury__parse__parse_2_0_i143);
Declare_label(mercury__parse__parse_2_0_i1124);
Declare_label(mercury__parse__parse_2_0_i1);
Declare_static(mercury__parse__parse_dirs_2_0);
Declare_label(mercury__parse__parse_dirs_2_0_i1005);
Declare_label(mercury__parse__parse_dirs_2_0_i3);
Declare_label(mercury__parse__parse_dirs_2_0_i7);
Declare_label(mercury__parse__parse_dirs_2_0_i8);
Declare_label(mercury__parse__parse_dirs_2_0_i13);
Declare_label(mercury__parse__parse_dirs_2_0_i6);
Declare_label(mercury__parse__parse_dirs_2_0_i17);
Declare_label(mercury__parse__parse_dirs_2_0_i1);
Define_extern_entry(mercury____Unify___parse__command_0_0);
Declare_label(mercury____Unify___parse__command_0_0_i4);
Declare_label(mercury____Unify___parse__command_0_0_i5);
Declare_label(mercury____Unify___parse__command_0_0_i7);
Declare_label(mercury____Unify___parse__command_0_0_i9);
Declare_label(mercury____Unify___parse__command_0_0_i11);
Declare_label(mercury____Unify___parse__command_0_0_i13);
Declare_label(mercury____Unify___parse__command_0_0_i15);
Declare_label(mercury____Unify___parse__command_0_0_i17);
Declare_label(mercury____Unify___parse__command_0_0_i19);
Declare_label(mercury____Unify___parse__command_0_0_i21);
Declare_label(mercury____Unify___parse__command_0_0_i23);
Declare_label(mercury____Unify___parse__command_0_0_i25);
Declare_label(mercury____Unify___parse__command_0_0_i29);
Declare_label(mercury____Unify___parse__command_0_0_i33);
Declare_label(mercury____Unify___parse__command_0_0_i1);
Define_extern_entry(mercury____Index___parse__command_0_0);
Declare_label(mercury____Index___parse__command_0_0_i4);
Declare_label(mercury____Index___parse__command_0_0_i5);
Declare_label(mercury____Index___parse__command_0_0_i6);
Declare_label(mercury____Index___parse__command_0_0_i7);
Declare_label(mercury____Index___parse__command_0_0_i8);
Declare_label(mercury____Index___parse__command_0_0_i9);
Declare_label(mercury____Index___parse__command_0_0_i10);
Declare_label(mercury____Index___parse__command_0_0_i11);
Declare_label(mercury____Index___parse__command_0_0_i12);
Declare_label(mercury____Index___parse__command_0_0_i13);
Declare_label(mercury____Index___parse__command_0_0_i14);
Declare_label(mercury____Index___parse__command_0_0_i15);
Declare_label(mercury____Index___parse__command_0_0_i16);
Declare_label(mercury____Index___parse__command_0_0_i17);
Define_extern_entry(mercury____Compare___parse__command_0_0);
Declare_label(mercury____Compare___parse__command_0_0_i2);
Declare_label(mercury____Compare___parse__command_0_0_i3);
Declare_label(mercury____Compare___parse__command_0_0_i4);
Declare_label(mercury____Compare___parse__command_0_0_i5);
Declare_label(mercury____Compare___parse__command_0_0_i10);
Declare_label(mercury____Compare___parse__command_0_0_i11);
Declare_label(mercury____Compare___parse__command_0_0_i13);
Declare_label(mercury____Compare___parse__command_0_0_i15);
Declare_label(mercury____Compare___parse__command_0_0_i17);
Declare_label(mercury____Compare___parse__command_0_0_i19);
Declare_label(mercury____Compare___parse__command_0_0_i21);
Declare_label(mercury____Compare___parse__command_0_0_i23);
Declare_label(mercury____Compare___parse__command_0_0_i25);
Declare_label(mercury____Compare___parse__command_0_0_i27);
Declare_label(mercury____Compare___parse__command_0_0_i29);
Declare_label(mercury____Compare___parse__command_0_0_i31);
Declare_label(mercury____Compare___parse__command_0_0_i34);
Declare_label(mercury____Compare___parse__command_0_0_i37);
Declare_label(mercury____Compare___parse__command_0_0_i7);
Define_extern_entry(mercury____Unify___parse__path_0_0);
Declare_label(mercury____Unify___parse__path_0_0_i3);
Declare_label(mercury____Unify___parse__path_0_0_i1);
Define_extern_entry(mercury____Index___parse__path_0_0);
Declare_label(mercury____Index___parse__path_0_0_i3);
Define_extern_entry(mercury____Compare___parse__path_0_0);
Declare_label(mercury____Compare___parse__path_0_0_i3);
Declare_label(mercury____Compare___parse__path_0_0_i2);
Declare_label(mercury____Compare___parse__path_0_0_i5);
Declare_label(mercury____Compare___parse__path_0_0_i4);
Declare_label(mercury____Compare___parse__path_0_0_i6);
Declare_label(mercury____Compare___parse__path_0_0_i7);
Declare_label(mercury____Compare___parse__path_0_0_i11);
Declare_label(mercury____Compare___parse__path_0_0_i1014);
Define_extern_entry(mercury____Unify___parse__dir_0_0);
Declare_label(mercury____Unify___parse__dir_0_0_i3);
Declare_label(mercury____Unify___parse__dir_0_0_i1);
Define_extern_entry(mercury____Index___parse__dir_0_0);
Declare_label(mercury____Index___parse__dir_0_0_i3);
Define_extern_entry(mercury____Compare___parse__dir_0_0);
Declare_label(mercury____Compare___parse__dir_0_0_i3);
Declare_label(mercury____Compare___parse__dir_0_0_i2);
Declare_label(mercury____Compare___parse__dir_0_0_i5);
Declare_label(mercury____Compare___parse__dir_0_0_i4);
Declare_label(mercury____Compare___parse__dir_0_0_i6);
Declare_label(mercury____Compare___parse__dir_0_0_i7);
Declare_label(mercury____Compare___parse__dir_0_0_i11);
Declare_label(mercury____Compare___parse__dir_0_0_i1014);
Define_extern_entry(mercury____Unify___parse__setting_0_0);
Declare_label(mercury____Unify___parse__setting_0_0_i4);
Declare_label(mercury____Unify___parse__setting_0_0_i6);
Declare_label(mercury____Unify___parse__setting_0_0_i8);
Declare_label(mercury____Unify___parse__setting_0_0_i10);
Declare_label(mercury____Unify___parse__setting_0_0_i11);
Declare_label(mercury____Unify___parse__setting_0_0_i1);
Define_extern_entry(mercury____Index___parse__setting_0_0);
Declare_label(mercury____Index___parse__setting_0_0_i4);
Declare_label(mercury____Index___parse__setting_0_0_i5);
Declare_label(mercury____Index___parse__setting_0_0_i6);
Declare_label(mercury____Index___parse__setting_0_0_i7);
Declare_label(mercury____Index___parse__setting_0_0_i8);
Define_extern_entry(mercury____Compare___parse__setting_0_0);
Declare_label(mercury____Compare___parse__setting_0_0_i4);
Declare_label(mercury____Compare___parse__setting_0_0_i5);
Declare_label(mercury____Compare___parse__setting_0_0_i6);
Declare_label(mercury____Compare___parse__setting_0_0_i7);
Declare_label(mercury____Compare___parse__setting_0_0_i8);
Declare_label(mercury____Compare___parse__setting_0_0_i11);
Declare_label(mercury____Compare___parse__setting_0_0_i12);
Declare_label(mercury____Compare___parse__setting_0_0_i13);
Declare_label(mercury____Compare___parse__setting_0_0_i14);
Declare_label(mercury____Compare___parse__setting_0_0_i15);
Declare_label(mercury____Compare___parse__setting_0_0_i9);
Declare_label(mercury____Compare___parse__setting_0_0_i16);
Declare_label(mercury____Compare___parse__setting_0_0_i17);
Declare_label(mercury____Compare___parse__setting_0_0_i22);
Declare_label(mercury____Compare___parse__setting_0_0_i25);
Declare_label(mercury____Compare___parse__setting_0_0_i28);
Declare_label(mercury____Compare___parse__setting_0_0_i31);
Declare_label(mercury____Compare___parse__setting_0_0_i32);
Declare_label(mercury____Compare___parse__setting_0_0_i1020);
Define_extern_entry(mercury____Unify___parse__portray_format_0_0);
Declare_label(mercury____Unify___parse__portray_format_0_0_i1);
Define_extern_entry(mercury____Index___parse__portray_format_0_0);
Define_extern_entry(mercury____Compare___parse__portray_format_0_0);
Define_extern_entry(mercury____Unify___parse__external_request_0_0);
Declare_label(mercury____Unify___parse__external_request_0_0_i1);
Define_extern_entry(mercury____Index___parse__external_request_0_0);
Define_extern_entry(mercury____Compare___parse__external_request_0_0);
Declare_static(mercury____Unify___parse__token_0_0);
Declare_label(mercury____Unify___parse__token_0_0_i4);
Declare_label(mercury____Unify___parse__token_0_0_i5);
Declare_label(mercury____Unify___parse__token_0_0_i7);
Declare_label(mercury____Unify___parse__token_0_0_i9);
Declare_label(mercury____Unify___parse__token_0_0_i11);
Declare_label(mercury____Unify___parse__token_0_0_i13);
Declare_label(mercury____Unify___parse__token_0_0_i15);
Declare_label(mercury____Unify___parse__token_0_0_i17);
Declare_label(mercury____Unify___parse__token_0_0_i19);
Declare_label(mercury____Unify___parse__token_0_0_i21);
Declare_label(mercury____Unify___parse__token_0_0_i1);
Declare_static(mercury____Index___parse__token_0_0);
Declare_label(mercury____Index___parse__token_0_0_i4);
Declare_label(mercury____Index___parse__token_0_0_i5);
Declare_label(mercury____Index___parse__token_0_0_i6);
Declare_label(mercury____Index___parse__token_0_0_i7);
Declare_label(mercury____Index___parse__token_0_0_i8);
Declare_label(mercury____Index___parse__token_0_0_i9);
Declare_label(mercury____Index___parse__token_0_0_i10);
Declare_label(mercury____Index___parse__token_0_0_i11);
Declare_label(mercury____Index___parse__token_0_0_i12);
Declare_label(mercury____Index___parse__token_0_0_i13);
Declare_static(mercury____Compare___parse__token_0_0);
Declare_label(mercury____Compare___parse__token_0_0_i2);
Declare_label(mercury____Compare___parse__token_0_0_i3);
Declare_label(mercury____Compare___parse__token_0_0_i4);
Declare_label(mercury____Compare___parse__token_0_0_i5);
Declare_label(mercury____Compare___parse__token_0_0_i10);
Declare_label(mercury____Compare___parse__token_0_0_i11);
Declare_label(mercury____Compare___parse__token_0_0_i13);
Declare_label(mercury____Compare___parse__token_0_0_i15);
Declare_label(mercury____Compare___parse__token_0_0_i17);
Declare_label(mercury____Compare___parse__token_0_0_i19);
Declare_label(mercury____Compare___parse__token_0_0_i21);
Declare_label(mercury____Compare___parse__token_0_0_i23);
Declare_label(mercury____Compare___parse__token_0_0_i26);
Declare_label(mercury____Compare___parse__token_0_0_i29);
Declare_label(mercury____Compare___parse__token_0_0_i7);

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_command_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_dir_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_external_request_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_path_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_portray_format_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_setting_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_token_0;

static const struct mercury_data_parse__common_0_struct {
	Word * f1;
}  mercury_data_parse__common_0;

static const struct mercury_data_parse__common_1_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_parse__common_1;

static const struct mercury_data_parse__common_2_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_parse__common_2;

static const struct mercury_data_parse__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_parse__common_3;

static const struct mercury_data_parse__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_parse__common_4;

static const struct mercury_data_parse__common_5_struct {
	Integer f1;
}  mercury_data_parse__common_5;

static const struct mercury_data_parse__common_6_struct {
	Word * f1;
}  mercury_data_parse__common_6;

static const struct mercury_data_parse__common_7_struct {
	Integer f1;
}  mercury_data_parse__common_7;

static const struct mercury_data_parse__common_8_struct {
	Word * f1;
}  mercury_data_parse__common_8;

static const struct mercury_data_parse__common_9_struct {
	Integer f1;
}  mercury_data_parse__common_9;

static const struct mercury_data_parse__common_10_struct {
	Word * f1;
}  mercury_data_parse__common_10;

static const struct mercury_data_parse__common_11_struct {
	Integer f1;
}  mercury_data_parse__common_11;

static const struct mercury_data_parse__common_12_struct {
	Word * f1;
}  mercury_data_parse__common_12;

static const struct mercury_data_parse__common_13_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_13;

static const struct mercury_data_parse__common_14_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_14;

static const struct mercury_data_parse__common_15_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_15;

static const struct mercury_data_parse__common_16_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_16;

static const struct mercury_data_parse__common_17_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_17;

static const struct mercury_data_parse__common_18_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_18;

static const struct mercury_data_parse__common_19_struct {
	Word * f1;
}  mercury_data_parse__common_19;

static const struct mercury_data_parse__common_20_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_20;

static const struct mercury_data_parse__common_21_struct {
	Word * f1;
}  mercury_data_parse__common_21;

static const struct mercury_data_parse__common_22_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_22;

static const struct mercury_data_parse__common_23_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_23;

static const struct mercury_data_parse__common_24_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
}  mercury_data_parse__common_24;

static const struct mercury_data_parse__common_25_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_25;

static const struct mercury_data_parse__common_26_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_26;

static const struct mercury_data_parse__common_27_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_27;

static const struct mercury_data_parse__common_28_struct {
	Word * f1;
}  mercury_data_parse__common_28;

static const struct mercury_data_parse__common_29_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_29;

static const struct mercury_data_parse__common_30_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_30;

static const struct mercury_data_parse__common_31_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_parse__common_31;

static const struct mercury_data_parse__common_32_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_parse__common_32;

static const struct mercury_data_parse__common_33_struct {
	Word * f1;
	Word * f2;
}  mercury_data_parse__common_33;

static const struct mercury_data_parse__common_34_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_34;

static const struct mercury_data_parse__common_35_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_35;

static const struct mercury_data_parse__common_36_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
}  mercury_data_parse__common_36;

static const struct mercury_data_parse__common_37_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_37;

static const struct mercury_data_parse__common_38_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_38;

static const struct mercury_data_parse__common_39_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_parse__common_39;

static const struct mercury_data_parse__common_40_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_40;

static const struct mercury_data_parse__common_41_struct {
	Word * f1;
}  mercury_data_parse__common_41;

static const struct mercury_data_parse__common_42_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_42;

static const struct mercury_data_parse__common_43_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_43;

static const struct mercury_data_parse__common_44_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_44;

static const struct mercury_data_parse__common_45_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_45;

static const struct mercury_data_parse__common_46_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_46;

static const struct mercury_data_parse__common_47_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_47;

static const struct mercury_data_parse__common_48_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_48;

static const struct mercury_data_parse__common_49_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_49;

static const struct mercury_data_parse__common_50_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_50;

static const struct mercury_data_parse__common_51_struct {
	Word * f1;
}  mercury_data_parse__common_51;

static const struct mercury_data_parse__common_52_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_parse__common_52;

static const struct mercury_data_parse__common_53_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_53;

static const struct mercury_data_parse__common_54_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_parse__common_54;

static const struct mercury_data_parse__common_55_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
}  mercury_data_parse__common_55;

static const struct mercury_data_parse__type_ctor_functors_token_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_parse__type_ctor_functors_token_0;

static const struct mercury_data_parse__type_ctor_layout_token_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_token_0;

static const struct mercury_data_parse__type_ctor_functors_setting_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_parse__type_ctor_functors_setting_0;

static const struct mercury_data_parse__type_ctor_layout_setting_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_setting_0;

static const struct mercury_data_parse__type_ctor_functors_portray_format_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_parse__type_ctor_functors_portray_format_0;

static const struct mercury_data_parse__type_ctor_layout_portray_format_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_portray_format_0;

static const struct mercury_data_parse__type_ctor_functors_path_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_functors_path_0;

static const struct mercury_data_parse__type_ctor_layout_path_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_path_0;

static const struct mercury_data_parse__type_ctor_functors_external_request_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_parse__type_ctor_functors_external_request_0;

static const struct mercury_data_parse__type_ctor_layout_external_request_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_external_request_0;

static const struct mercury_data_parse__type_ctor_functors_dir_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_functors_dir_0;

static const struct mercury_data_parse__type_ctor_layout_dir_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_dir_0;

static const struct mercury_data_parse__type_ctor_functors_command_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_parse__type_ctor_functors_command_0;

static const struct mercury_data_parse__type_ctor_layout_command_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_parse__type_ctor_layout_command_0;

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_command_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__command_0_0),
	ENTRY(mercury____Index___parse__command_0_0),
	ENTRY(mercury____Compare___parse__command_0_0),
	(Integer) 2,
	(Word *) &mercury_data_parse__type_ctor_functors_command_0,
	(Word *) &mercury_data_parse__type_ctor_layout_command_0,
	MR_string_const("parse", 5),
	MR_string_const("command", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_dir_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__dir_0_0),
	ENTRY(mercury____Index___parse__dir_0_0),
	ENTRY(mercury____Compare___parse__dir_0_0),
	(Integer) 2,
	(Word *) &mercury_data_parse__type_ctor_functors_dir_0,
	(Word *) &mercury_data_parse__type_ctor_layout_dir_0,
	MR_string_const("parse", 5),
	MR_string_const("dir", 3),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_external_request_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__external_request_0_0),
	ENTRY(mercury____Index___parse__external_request_0_0),
	ENTRY(mercury____Compare___parse__external_request_0_0),
	(Integer) 4,
	(Word *) &mercury_data_parse__type_ctor_functors_external_request_0,
	(Word *) &mercury_data_parse__type_ctor_layout_external_request_0,
	MR_string_const("parse", 5),
	MR_string_const("external_request", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_path_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__path_0_0),
	ENTRY(mercury____Index___parse__path_0_0),
	ENTRY(mercury____Compare___parse__path_0_0),
	(Integer) 2,
	(Word *) &mercury_data_parse__type_ctor_functors_path_0,
	(Word *) &mercury_data_parse__type_ctor_layout_path_0,
	MR_string_const("parse", 5),
	MR_string_const("path", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_portray_format_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__portray_format_0_0),
	ENTRY(mercury____Index___parse__portray_format_0_0),
	ENTRY(mercury____Compare___parse__portray_format_0_0),
	(Integer) 0,
	(Word *) &mercury_data_parse__type_ctor_functors_portray_format_0,
	(Word *) &mercury_data_parse__type_ctor_layout_portray_format_0,
	MR_string_const("parse", 5),
	MR_string_const("portray_format", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_setting_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___parse__setting_0_0),
	ENTRY(mercury____Index___parse__setting_0_0),
	ENTRY(mercury____Compare___parse__setting_0_0),
	(Integer) 2,
	(Word *) &mercury_data_parse__type_ctor_functors_setting_0,
	(Word *) &mercury_data_parse__type_ctor_layout_setting_0,
	MR_string_const("parse", 5),
	MR_string_const("setting", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_parse__type_ctor_info_token_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___parse__token_0_0),
	STATIC(mercury____Index___parse__token_0_0),
	STATIC(mercury____Compare___parse__token_0_0),
	(Integer) 2,
	(Word *) &mercury_data_parse__type_ctor_functors_token_0,
	(Word *) &mercury_data_parse__type_ctor_layout_token_0,
	MR_string_const("parse", 5),
	MR_string_const("token", 5),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_parse__common_0_struct mercury_data_parse__common_0 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

static const struct mercury_data_parse__common_1_struct mercury_data_parse__common_1 = {
	(Integer) 0,
	MR_string_const("char", 4),
	MR_string_const("char", 4),
	MR_string_const("is_digit", 8),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_0)
};

Declare_entry(mercury__char__is_digit_1_0);
static const struct mercury_data_parse__common_2_struct mercury_data_parse__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_1),
	ENTRY(mercury__char__is_digit_1_0),
	(Integer) 0
};

static const struct mercury_data_parse__common_3_struct mercury_data_parse__common_3 = {
	(Integer) 0,
	MR_string_const("char", 4),
	MR_string_const("char", 4),
	MR_string_const("is_alpha", 8),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_0)
};

Declare_entry(mercury__char__is_alpha_1_0);
static const struct mercury_data_parse__common_4_struct mercury_data_parse__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_3),
	ENTRY(mercury__char__is_alpha_1_0),
	(Integer) 0
};

static const struct mercury_data_parse__common_5_struct mercury_data_parse__common_5 = {
	(Integer) 0
};

static const struct mercury_data_parse__common_6_struct mercury_data_parse__common_6 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_parse__common_5)
};

static const struct mercury_data_parse__common_7_struct mercury_data_parse__common_7 = {
	(Integer) 1
};

static const struct mercury_data_parse__common_8_struct mercury_data_parse__common_8 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_parse__common_7)
};

static const struct mercury_data_parse__common_9_struct mercury_data_parse__common_9 = {
	(Integer) 2
};

static const struct mercury_data_parse__common_10_struct mercury_data_parse__common_10 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_parse__common_9)
};

static const struct mercury_data_parse__common_11_struct mercury_data_parse__common_11 = {
	(Integer) 10
};

static const struct mercury_data_parse__common_12_struct mercury_data_parse__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_11)
};

static const struct mercury_data_parse__common_13_struct mercury_data_parse__common_13 = {
	(Integer) 0,
	MR_string_const(".", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_14_struct mercury_data_parse__common_14 = {
	(Integer) 0,
	MR_string_const("..", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_15_struct mercury_data_parse__common_15 = {
	(Integer) 0,
	MR_string_const("/", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_16_struct mercury_data_parse__common_16 = {
	(Integer) 0,
	MR_string_const("<", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_17_struct mercury_data_parse__common_17 = {
	(Integer) 0,
	MR_string_const("?", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_18_struct mercury_data_parse__common_18 = {
	(Integer) 0,
	MR_string_const("^", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_parse__common_19_struct mercury_data_parse__common_19 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_parse__common_20_struct mercury_data_parse__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_19),
	MR_string_const("name", 4),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_parse__common_21_struct mercury_data_parse__common_21 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_parse__common_22_struct mercury_data_parse__common_22 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("num", 3),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_23_struct mercury_data_parse__common_23 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_0),
	MR_string_const("unknown", 7),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_24_struct mercury_data_parse__common_24 = {
	(Integer) 0,
	(Integer) 6,
	MR_string_const(".", 1),
	MR_string_const("..", 2),
	MR_string_const("/", 1),
	MR_string_const("?", 1),
	MR_string_const("^", 1),
	MR_string_const("<", 1)
};

static const struct mercury_data_parse__common_25_struct mercury_data_parse__common_25 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("clipx", 5),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_26_struct mercury_data_parse__common_26 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("clipy", 5),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_27_struct mercury_data_parse__common_27 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("depth", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_28_struct mercury_data_parse__common_28 = {
	(Word *) &mercury_data_parse__type_ctor_info_portray_format_0
};

static const struct mercury_data_parse__common_29_struct mercury_data_parse__common_29 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_28),
	MR_string_const("format", 6),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_30_struct mercury_data_parse__common_30 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("size", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_31_struct mercury_data_parse__common_31 = {
	(Integer) 2,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_25),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_26)
};

static const struct mercury_data_parse__common_32_struct mercury_data_parse__common_32 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("flat", 4),
	MR_string_const("pretty", 6),
	MR_string_const("verbose", 7)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_parse__common_33_struct mercury_data_parse__common_33 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_parse__type_ctor_info_dir_0
};

static const struct mercury_data_parse__common_34_struct mercury_data_parse__common_34 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_33),
	MR_string_const("dot_rel", 7),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_35_struct mercury_data_parse__common_35 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_33),
	MR_string_const("root_rel", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_36_struct mercury_data_parse__common_36 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_19),
	MR_string_const("external_request", 16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_parse__common_37_struct mercury_data_parse__common_37 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_21),
	MR_string_const("child", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_38_struct mercury_data_parse__common_38 = {
	(Integer) 0,
	MR_string_const("parent", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_39_struct mercury_data_parse__common_39 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("parent", 6)
};

static const struct mercury_data_parse__common_40_struct mercury_data_parse__common_40 = {
	(Integer) 0,
	MR_string_const("cd", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_41_struct mercury_data_parse__common_41 = {
	(Word *) &mercury_data_parse__type_ctor_info_path_0
};

static const struct mercury_data_parse__common_42_struct mercury_data_parse__common_42 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_41),
	MR_string_const("cd", 2),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_43_struct mercury_data_parse__common_43 = {
	(Integer) 0,
	MR_string_const("display", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_44_struct mercury_data_parse__common_44 = {
	(Integer) 0,
	MR_string_const("help", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_45_struct mercury_data_parse__common_45 = {
	(Integer) 0,
	MR_string_const("ls", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_46_struct mercury_data_parse__common_46 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_41),
	MR_string_const("ls", 2),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_47_struct mercury_data_parse__common_47 = {
	(Integer) 0,
	MR_string_const("print", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_48_struct mercury_data_parse__common_48 = {
	(Integer) 0,
	MR_string_const("pwd", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_49_struct mercury_data_parse__common_49 = {
	(Integer) 0,
	MR_string_const("quit", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_50_struct mercury_data_parse__common_50 = {
	(Integer) 0,
	MR_string_const("set", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_51_struct mercury_data_parse__common_51 = {
	(Word *) &mercury_data_parse__type_ctor_info_setting_0
};

static const struct mercury_data_parse__common_52_struct mercury_data_parse__common_52 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_51),
	MR_string_const("set", 3),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_53_struct mercury_data_parse__common_53 = {
	(Integer) 0,
	MR_string_const("unknown", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_54_struct mercury_data_parse__common_54 = {
	(Integer) 0,
	MR_string_const("write", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 8)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_parse__common_55_struct mercury_data_parse__common_55 = {
	(Integer) 0,
	(Integer) 10,
	MR_string_const("ls", 2),
	MR_string_const("cd", 2),
	MR_string_const("pwd", 3),
	MR_string_const("help", 4),
	MR_string_const("set", 3),
	MR_string_const("quit", 4),
	MR_string_const("print", 5),
	MR_string_const("display", 7),
	MR_string_const("write", 5),
	MR_string_const("unknown", 7)
};

static const struct mercury_data_parse__type_ctor_functors_token_0_struct mercury_data_parse__type_ctor_functors_token_0 = {
	(Integer) 0,
	(Integer) 9,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_23)
};

static const struct mercury_data_parse__type_ctor_layout_token_0_struct mercury_data_parse__type_ctor_layout_token_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_24),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_22),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_20),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_23)
};

static const struct mercury_data_parse__type_ctor_functors_setting_0_struct mercury_data_parse__type_ctor_functors_setting_0 = {
	(Integer) 0,
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_29),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_30)
};

static const struct mercury_data_parse__type_ctor_layout_setting_0_struct mercury_data_parse__type_ctor_layout_setting_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_27),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_30),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_29),
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_parse__common_31)
};

static const struct mercury_data_parse__type_ctor_functors_portray_format_0_struct mercury_data_parse__type_ctor_functors_portray_format_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_32)
};

static const struct mercury_data_parse__type_ctor_layout_portray_format_0_struct mercury_data_parse__type_ctor_layout_portray_format_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_32),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_32),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_32),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_32)
};

static const struct mercury_data_parse__type_ctor_functors_path_0_struct mercury_data_parse__type_ctor_functors_path_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_35)
};

static const struct mercury_data_parse__type_ctor_layout_path_0_struct mercury_data_parse__type_ctor_layout_path_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_35),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_34),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_parse__type_ctor_functors_external_request_0_struct mercury_data_parse__type_ctor_functors_external_request_0 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_36)
};

static const struct mercury_data_parse__type_ctor_layout_external_request_0_struct mercury_data_parse__type_ctor_layout_external_request_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_36)
};

static const struct mercury_data_parse__type_ctor_functors_dir_0_struct mercury_data_parse__type_ctor_functors_dir_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_37),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_38)
};

static const struct mercury_data_parse__type_ctor_layout_dir_0_struct mercury_data_parse__type_ctor_layout_dir_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_39),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_37),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_parse__type_ctor_functors_command_0_struct mercury_data_parse__type_ctor_functors_command_0 = {
	(Integer) 0,
	(Integer) 13,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_42),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_43),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_44),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_45),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_46),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_47),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_48),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_49),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_50),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_53),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_54)
};

static const struct mercury_data_parse__type_ctor_layout_command_0_struct mercury_data_parse__type_ctor_layout_command_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_55),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_46),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_42),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_parse__common_52)
};


BEGIN_MODULE(parse_module0)
	init_entry(mercury____Index___parse__external_request_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___parse__external_request_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___parse__external_request_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__util__trace_getline_4_0);
Declare_entry(mercury__io__error_message_2_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__nl_2_0);
Declare_entry(mercury__string__to_char_list_2_0);

BEGIN_MODULE(parse_module1)
	init_entry(mercury__parse__read_command_4_0);
	init_label(mercury__parse__read_command_4_0_i1003);
	init_label(mercury__parse__read_command_4_0_i2);
	init_label(mercury__parse__read_command_4_0_i13);
	init_label(mercury__parse__read_command_4_0_i14);
	init_label(mercury__parse__read_command_4_0_i15);
	init_label(mercury__parse__read_command_4_0_i16);
	init_label(mercury__parse__read_command_4_0_i5);
	init_label(mercury__parse__read_command_4_0_i6);
	init_label(mercury__parse__read_command_4_0_i7);
	init_label(mercury__parse__read_command_4_0_i10);
	init_label(mercury__parse__read_command_4_0_i9);
BEGIN_CODE

/* code for predicate 'read_command'/4 in mode 0 */
Define_entry(mercury__parse__read_command_4_0);
	MR_incr_sp_push_msg(3, "parse:read_command/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__parse__read_command_4_0_i1003);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__util__trace_getline_4_0),
		mercury__parse__read_command_4_0_i2,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i2);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__read_command_4_0_i5);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__read_command_4_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__parse__read_command_4_0_i13);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__parse__read_command_4_0_i14,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i14);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__parse__read_command_4_0_i15,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i15);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__parse__read_command_4_0_i16,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i16);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__parse__read_command_4_0_i1003);
Define_label(mercury__parse__read_command_4_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__parse__read_command_4_0_i6,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i6);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__read_command_4_0_i7,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i7);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	call_localret(STATIC(mercury__parse__parse_2_0),
		mercury__parse__read_command_4_0_i10,
		ENTRY(mercury__parse__read_command_4_0));
Define_label(mercury__parse__read_command_4_0_i10);
	update_prof_current_proc(LABEL(mercury__parse__read_command_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__read_command_4_0_i9);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__parse__read_command_4_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__io__read_3_0);

BEGIN_MODULE(parse_module2)
	init_entry(mercury__parse__read_command_external_3_0);
	init_label(mercury__parse__read_command_external_3_0_i2);
	init_label(mercury__parse__read_command_external_3_0_i5);
	init_label(mercury__parse__read_command_external_3_0_i6);
	init_label(mercury__parse__read_command_external_3_0_i9);
	init_label(mercury__parse__read_command_external_3_0_i8);
	init_label(mercury__parse__read_command_external_3_0_i3);
	init_label(mercury__parse__read_command_external_3_0_i12);
BEGIN_CODE

/* code for predicate 'read_command_external'/3 in mode 0 */
Define_entry(mercury__parse__read_command_external_3_0);
	MR_incr_sp_push_msg(2, "parse:read_command_external/3");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_external_request_0;
	call_localret(ENTRY(mercury__io__read_3_0),
		mercury__parse__read_command_external_3_0_i2,
		ENTRY(mercury__parse__read_command_external_3_0));
Define_label(mercury__parse__read_command_external_3_0_i2);
	update_prof_current_proc(LABEL(mercury__parse__read_command_external_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__read_command_external_3_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__parse__read_command_external_3_0_i5,
		ENTRY(mercury__parse__read_command_external_3_0));
Define_label(mercury__parse__read_command_external_3_0_i5);
	update_prof_current_proc(LABEL(mercury__parse__read_command_external_3_0));
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__read_command_external_3_0_i6,
		ENTRY(mercury__parse__read_command_external_3_0));
Define_label(mercury__parse__read_command_external_3_0_i6);
	update_prof_current_proc(LABEL(mercury__parse__read_command_external_3_0));
	call_localret(STATIC(mercury__parse__parse_2_0),
		mercury__parse__read_command_external_3_0_i9,
		ENTRY(mercury__parse__read_command_external_3_0));
Define_label(mercury__parse__read_command_external_3_0_i9);
	update_prof_current_proc(LABEL(mercury__parse__read_command_external_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__read_command_external_3_0_i8);
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__read_command_external_3_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__read_command_external_3_0_i3);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__read_command_external_3_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__read_command_external_3_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module3)
	init_entry(mercury__parse__default_depth_1_0);
BEGIN_CODE

/* code for predicate 'default_depth'/1 in mode 0 */
Define_entry(mercury__parse__default_depth_1_0);
	r1 = (Integer) 10;
	proceed();
END_MODULE

Declare_entry(mercury__char__to_int_2_0);
Declare_entry(mercury__char__is_whitespace_1_0);

BEGIN_MODULE(parse_module4)
	init_entry(mercury__parse__lexer_2_0);
	init_label(mercury__parse__lexer_2_0_i1009);
	init_label(mercury__parse__lexer_2_0_i3);
	init_label(mercury__parse__lexer_2_0_i4);
	init_label(mercury__parse__lexer_2_0_i9);
	init_label(mercury__parse__lexer_2_0_i7);
	init_label(mercury__parse__lexer_2_0_i12);
	init_label(mercury__parse__lexer_2_0_i10);
	init_label(mercury__parse__lexer_2_0_i15);
	init_label(mercury__parse__lexer_2_0_i13);
	init_label(mercury__parse__lexer_2_0_i18);
	init_label(mercury__parse__lexer_2_0_i16);
	init_label(mercury__parse__lexer_2_0_i21);
	init_label(mercury__parse__lexer_2_0_i23);
	init_label(mercury__parse__lexer_2_0_i24);
	init_label(mercury__parse__lexer_2_0_i19);
	init_label(mercury__parse__lexer_2_0_i28);
	init_label(mercury__parse__lexer_2_0_i26);
	init_label(mercury__parse__lexer_2_0_i33);
	init_label(mercury__parse__lexer_2_0_i31);
	init_label(mercury__parse__lexer_2_0_i36);
BEGIN_CODE

/* code for predicate 'lexer'/2 in mode 0 */
Define_static(mercury__parse__lexer_2_0);
	MR_incr_sp_push_msg(4, "parse:lexer/2");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__parse__lexer_2_0_i1009);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__lexer_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__parse__lexer_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 46))
		GOTO_LABEL(mercury__parse__lexer_2_0_i4);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__parse__lexer_dots_2_0),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i4);
	if (((Integer) r3 != (Integer) 47))
		GOTO_LABEL(mercury__parse__lexer_2_0_i7);
	r1 = r2;
	localcall(mercury__parse__lexer_2_0,
		LABEL(mercury__parse__lexer_2_0_i9),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i9);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__parse__lexer_2_0_i7);
	if (((Integer) r3 != (Integer) 63))
		GOTO_LABEL(mercury__parse__lexer_2_0_i10);
	r1 = r2;
	localcall(mercury__parse__lexer_2_0,
		LABEL(mercury__parse__lexer_2_0_i12),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i12);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__parse__lexer_2_0_i10);
	if (((Integer) r3 != (Integer) 94))
		GOTO_LABEL(mercury__parse__lexer_2_0_i13);
	r1 = r2;
	localcall(mercury__parse__lexer_2_0,
		LABEL(mercury__parse__lexer_2_0_i15),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i15);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__parse__lexer_2_0_i13);
	if (((Integer) r3 != (Integer) 60))
		GOTO_LABEL(mercury__parse__lexer_2_0_i16);
	r1 = r2;
	localcall(mercury__parse__lexer_2_0,
		LABEL(mercury__parse__lexer_2_0_i18),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i18);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__parse__lexer_2_0_i16);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = r3;
	call_localret(ENTRY(mercury__char__is_digit_1_0),
		mercury__parse__lexer_2_0_i21,
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i21);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__lexer_2_0_i19);
	r1 = (Integer) 48;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__parse__lexer_2_0_i23,
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i23);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__parse__lexer_2_0_i24,
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i24);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r1 = ((Integer) r1 - (Integer) MR_stackvar(3));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__parse__lexer_num_3_0),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i19);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__char__is_alpha_1_0),
		mercury__parse__lexer_2_0_i28,
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i28);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__lexer_2_0_i26);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__parse__lexer_name_3_0),
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i26);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__char__is_whitespace_1_0),
		mercury__parse__lexer_2_0_i33,
		STATIC(mercury__parse__lexer_2_0));
Define_label(mercury__parse__lexer_2_0_i33);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__lexer_2_0_i31);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__parse__lexer_2_0_i1009);
Define_label(mercury__parse__lexer_2_0_i31);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__parse__lexer_2_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = r3;
	localcall(mercury__parse__lexer_2_0,
		LABEL(mercury__parse__lexer_2_0_i36),
		STATIC(mercury__parse__lexer_2_0));
	}
Define_label(mercury__parse__lexer_2_0_i36);
	update_prof_current_proc(LABEL(mercury__parse__lexer_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module5)
	init_entry(mercury__parse__lexer_dots_2_0);
	init_label(mercury__parse__lexer_dots_2_0_i3);
	init_label(mercury__parse__lexer_dots_2_0_i6);
	init_label(mercury__parse__lexer_dots_2_0_i4);
	init_label(mercury__parse__lexer_dots_2_0_i7);
BEGIN_CODE

/* code for predicate 'lexer_dots'/2 in mode 0 */
Define_static(mercury__parse__lexer_dots_2_0);
	MR_incr_sp_push_msg(1, "parse:lexer_dots/2");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__lexer_dots_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__parse__lexer_dots_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 46))
		GOTO_LABEL(mercury__parse__lexer_dots_2_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__lexer_dots_2_0_i6,
		STATIC(mercury__parse__lexer_dots_2_0));
Define_label(mercury__parse__lexer_dots_2_0_i6);
	update_prof_current_proc(LABEL(mercury__parse__lexer_dots_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_dots_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__parse__lexer_dots_2_0_i4);
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__lexer_dots_2_0_i7,
		STATIC(mercury__parse__lexer_dots_2_0));
Define_label(mercury__parse__lexer_dots_2_0_i7);
	update_prof_current_proc(LABEL(mercury__parse__lexer_dots_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_dots_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__list__takewhile_4_0);

BEGIN_MODULE(parse_module6)
	init_entry(mercury__parse__lexer_num_3_0);
	init_label(mercury__parse__lexer_num_3_0_i2);
	init_label(mercury__parse__lexer_num_3_0_i3);
	init_label(mercury__parse__lexer_num_3_0_i4);
BEGIN_CODE

/* code for predicate 'lexer_num'/3 in mode 0 */
Define_static(mercury__parse__lexer_num_3_0);
	MR_incr_sp_push_msg(2, "parse:lexer_num/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_character_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_2);
	call_localret(ENTRY(mercury__list__takewhile_4_0),
		mercury__parse__lexer_num_3_0_i2,
		STATIC(mercury__parse__lexer_num_3_0));
Define_label(mercury__parse__lexer_num_3_0_i2);
	update_prof_current_proc(LABEL(mercury__parse__lexer_num_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__parse__digits_to_int_acc_3_0),
		mercury__parse__lexer_num_3_0_i3,
		STATIC(mercury__parse__lexer_num_3_0));
Define_label(mercury__parse__lexer_num_3_0_i3);
	update_prof_current_proc(LABEL(mercury__parse__lexer_num_3_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__lexer_num_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__lexer_num_3_0_i4,
		STATIC(mercury__parse__lexer_num_3_0));
Define_label(mercury__parse__lexer_num_3_0_i4);
	update_prof_current_proc(LABEL(mercury__parse__lexer_num_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_num_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module7)
	init_entry(mercury__parse__digits_to_int_acc_3_0);
	init_label(mercury__parse__digits_to_int_acc_3_0_i1001);
	init_label(mercury__parse__digits_to_int_acc_3_0_i4);
	init_label(mercury__parse__digits_to_int_acc_3_0_i5);
	init_label(mercury__parse__digits_to_int_acc_3_0_i2);
BEGIN_CODE

/* code for predicate 'digits_to_int_acc'/3 in mode 0 */
Define_static(mercury__parse__digits_to_int_acc_3_0);
	MR_incr_sp_push_msg(4, "parse:digits_to_int_acc/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__parse__digits_to_int_acc_3_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__digits_to_int_acc_3_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Integer) 48;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__parse__digits_to_int_acc_3_0_i4,
		STATIC(mercury__parse__digits_to_int_acc_3_0));
Define_label(mercury__parse__digits_to_int_acc_3_0_i4);
	update_prof_current_proc(LABEL(mercury__parse__digits_to_int_acc_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__parse__digits_to_int_acc_3_0_i5,
		STATIC(mercury__parse__digits_to_int_acc_3_0));
Define_label(mercury__parse__digits_to_int_acc_3_0_i5);
	update_prof_current_proc(LABEL(mercury__parse__digits_to_int_acc_3_0));
	r1 = (((Integer) 10 * (Integer) MR_stackvar(1)) + ((Integer) r1 - (Integer) MR_stackvar(2)));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__parse__digits_to_int_acc_3_0_i1001);
Define_label(mercury__parse__digits_to_int_acc_3_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__string__from_char_list_2_0);

BEGIN_MODULE(parse_module8)
	init_entry(mercury__parse__lexer_name_3_0);
	init_label(mercury__parse__lexer_name_3_0_i2);
	init_label(mercury__parse__lexer_name_3_0_i3);
	init_label(mercury__parse__lexer_name_3_0_i4);
BEGIN_CODE

/* code for predicate 'lexer_name'/3 in mode 0 */
Define_static(mercury__parse__lexer_name_3_0);
	MR_incr_sp_push_msg(2, "parse:lexer_name/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_character_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_parse__common_4);
	call_localret(ENTRY(mercury__list__takewhile_4_0),
		mercury__parse__lexer_name_3_0_i2,
		STATIC(mercury__parse__lexer_name_3_0));
Define_label(mercury__parse__lexer_name_3_0_i2);
	update_prof_current_proc(LABEL(mercury__parse__lexer_name_3_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__parse__lexer_name_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__parse__lexer_name_3_0_i3,
		STATIC(mercury__parse__lexer_name_3_0));
Define_label(mercury__parse__lexer_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__parse__lexer_name_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__parse__lexer_2_0),
		mercury__parse__lexer_name_3_0_i4,
		STATIC(mercury__parse__lexer_name_3_0));
Define_label(mercury__parse__lexer_name_3_0_i4);
	update_prof_current_proc(LABEL(mercury__parse__lexer_name_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__parse__lexer_name_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__parse__lexer_name_3_0, "parse:token/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module9)
	init_entry(mercury__parse__parse_2_0);
	init_label(mercury__parse__parse_2_0_i1126);
	init_label(mercury__parse__parse_2_0_i1250);
	init_label(mercury__parse__parse_2_0_i1252);
	init_label(mercury__parse__parse_2_0_i3);
	init_label(mercury__parse__parse_2_0_i12);
	init_label(mercury__parse__parse_2_0_i16);
	init_label(mercury__parse__parse_2_0_i21);
	init_label(mercury__parse__parse_2_0_i19);
	init_label(mercury__parse__parse_2_0_i26);
	init_label(mercury__parse__parse_2_0_i27);
	init_label(mercury__parse__parse_2_0_i29);
	init_label(mercury__parse__parse_2_0_i30);
	init_label(mercury__parse__parse_2_0_i32);
	init_label(mercury__parse__parse_2_0_i33);
	init_label(mercury__parse__parse_2_0_i25);
	init_label(mercury__parse__parse_2_0_i36);
	init_label(mercury__parse__parse_2_0_i11);
	init_label(mercury__parse__parse_2_0_i40);
	init_label(mercury__parse__parse_2_0_i47);
	init_label(mercury__parse__parse_2_0_i52);
	init_label(mercury__parse__parse_2_0_i50);
	init_label(mercury__parse__parse_2_0_i57);
	init_label(mercury__parse__parse_2_0_i58);
	init_label(mercury__parse__parse_2_0_i60);
	init_label(mercury__parse__parse_2_0_i61);
	init_label(mercury__parse__parse_2_0_i63);
	init_label(mercury__parse__parse_2_0_i64);
	init_label(mercury__parse__parse_2_0_i56);
	init_label(mercury__parse__parse_2_0_i67);
	init_label(mercury__parse__parse_2_0_i44);
	init_label(mercury__parse__parse_2_0_i74);
	init_label(mercury__parse__parse_2_0_i77);
	init_label(mercury__parse__parse_2_0_i83);
	init_label(mercury__parse__parse_2_0_i89);
	init_label(mercury__parse__parse_2_0_i95);
	init_label(mercury__parse__parse_2_0_i105);
	init_label(mercury__parse__parse_2_0_i108);
	init_label(mercury__parse__parse_2_0_i71);
	init_label(mercury__parse__parse_2_0_i120);
	init_label(mercury__parse__parse_2_0_i126);
	init_label(mercury__parse__parse_2_0_i124);
	init_label(mercury__parse__parse_2_0_i132);
	init_label(mercury__parse__parse_2_0_i130);
	init_label(mercury__parse__parse_2_0_i138);
	init_label(mercury__parse__parse_2_0_i136);
	init_label(mercury__parse__parse_2_0_i143);
	init_label(mercury__parse__parse_2_0_i1124);
	init_label(mercury__parse__parse_2_0_i1);
BEGIN_CODE

/* code for predicate 'parse'/2 in mode 0 */
Define_static(mercury__parse__parse_2_0);
	MR_incr_sp_push_msg(2, "parse:parse/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1124);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1126);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i3);
	r4 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("h", 1)) == 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i1250);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("help", 4)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i3);
	GOTO_LABEL(mercury__parse__parse_2_0_i1252);
Define_label(mercury__parse__parse_2_0_i1126);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = TRUE;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i1250);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = TRUE;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i1252);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = TRUE;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury__parse__parse_2_0_i12);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i11);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("cd", 2)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i11);
Define_label(mercury__parse__parse_2_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i16);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i16);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__parse__parse_2_0_i19);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i21,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i21);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i19);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__parse__parse_2_0_i25);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__parse__parse_2_0_i1) AND
		LABEL(mercury__parse__parse_2_0_i26) AND
		LABEL(mercury__parse__parse_2_0_i29) AND
		LABEL(mercury__parse__parse_2_0_i1) AND
		LABEL(mercury__parse__parse_2_0_i32) AND
		LABEL(mercury__parse__parse_2_0_i1));
Define_label(mercury__parse__parse_2_0_i26);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i27,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i27);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__parse__parse_2_0_i29);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i30,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i30);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i32);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i33,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i33);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i25);
	if ((r3 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i36,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i36);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__parse__parse_2_0_i11);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i40);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("pwd", 3)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i40);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i40);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i44);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("ls", 2)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i44);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i47);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i47);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__parse__parse_2_0_i50);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i52,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i52);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i50);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__parse__parse_2_0_i56);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__parse__parse_2_0_i1) AND
		LABEL(mercury__parse__parse_2_0_i57) AND
		LABEL(mercury__parse__parse_2_0_i60) AND
		LABEL(mercury__parse__parse_2_0_i1) AND
		LABEL(mercury__parse__parse_2_0_i63) AND
		LABEL(mercury__parse__parse_2_0_i1));
Define_label(mercury__parse__parse_2_0_i57);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i58,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i58);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__parse__parse_2_0_i60);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i61,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i61);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i63);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i64,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i64);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i56);
	if ((r3 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(STATIC(mercury__parse__parse_dirs_2_0),
		mercury__parse__parse_2_0_i67,
		STATIC(mercury__parse__parse_2_0));
Define_label(mercury__parse__parse_2_0_i67);
	update_prof_current_proc(LABEL(mercury__parse__parse_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:path/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__parse__parse_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__parse__parse_2_0_i44);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i71);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("set", 3)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i71);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i74);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i74);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i77);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r3, (Integer) 0), (char *)(Word) MR_string_const("depth", 5)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i77);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__parse__parse_2_0, "parse:setting/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i77);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i83);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("size", 4)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i83);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_2_0, "parse:setting/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i83);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i89);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("clipx", 5)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i89);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__parse__parse_2_0, "parse:setting/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i89);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i95);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("clipy", 5)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i95);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__parse__parse_2_0, "parse:setting/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i95);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r3, (Integer) 0), (char *)(Word) MR_string_const("format", 6)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i105);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	if ((strcmp((char *)r3, (char *)(Word) MR_string_const("flat", 4)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i105);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i105);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i108);
	r1 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("pretty", 6)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i108);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_8);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i108);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r2, (Integer) 0), (char *)(Word) MR_string_const("verbose", 7)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_10);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i71);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i120);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("quit", 4)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i120);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i120);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i124);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("d", 1)) == 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i126);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("display", 7)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i124);
Define_label(mercury__parse__parse_2_0_i126);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i124);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i130);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("w", 1)) == 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i132);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("write", 5)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i130);
Define_label(mercury__parse__parse_2_0_i132);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 8));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i130);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__parse__parse_2_0_i136);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("p", 1)) == 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i138);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("print", 5)) != 0))
		GOTO_LABEL(mercury__parse__parse_2_0_i136);
Define_label(mercury__parse__parse_2_0_i138);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i136);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i143);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_parse__common_12);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i143);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__parse__parse_2_0, "parse:command/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__parse__parse_2_0, "parse:setting/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 0) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i1124);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module10)
	init_entry(mercury__parse__parse_dirs_2_0);
	init_label(mercury__parse__parse_dirs_2_0_i1005);
	init_label(mercury__parse__parse_dirs_2_0_i3);
	init_label(mercury__parse__parse_dirs_2_0_i7);
	init_label(mercury__parse__parse_dirs_2_0_i8);
	init_label(mercury__parse__parse_dirs_2_0_i13);
	init_label(mercury__parse__parse_dirs_2_0_i6);
	init_label(mercury__parse__parse_dirs_2_0_i17);
	init_label(mercury__parse__parse_dirs_2_0_i1);
BEGIN_CODE

/* code for predicate 'parse_dirs'/2 in mode 0 */
Define_static(mercury__parse__parse_dirs_2_0);
	MR_incr_sp_push_msg(2, "parse:parse_dirs/2");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__parse__parse_dirs_2_0_i1005);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__parse__parse_dirs_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_dirs_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_tag(r2);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__parse__parse_dirs_2_0_i6);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__parse__parse_dirs_2_0_i1) AND
		LABEL(mercury__parse__parse_dirs_2_0_i7) AND
		LABEL(mercury__parse__parse_dirs_2_0_i13) AND
		LABEL(mercury__parse__parse_dirs_2_0_i1) AND
		LABEL(mercury__parse__parse_dirs_2_0_i13) AND
		LABEL(mercury__parse__parse_dirs_2_0_i1));
Define_label(mercury__parse__parse_dirs_2_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__parse__parse_dirs_2_0,
		LABEL(mercury__parse__parse_dirs_2_0_i8),
		STATIC(mercury__parse__parse_dirs_2_0));
Define_label(mercury__parse__parse_dirs_2_0_i8);
	update_prof_current_proc(LABEL(mercury__parse__parse_dirs_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_dirs_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__parse__parse_dirs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_dirs_2_0_i13);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__parse__parse_dirs_2_0_i1005);
Define_label(mercury__parse__parse_dirs_2_0_i6);
	if ((r3 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__parse__parse_dirs_2_0_i1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__parse__parse_dirs_2_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	localcall(mercury__parse__parse_dirs_2_0,
		LABEL(mercury__parse__parse_dirs_2_0_i17),
		STATIC(mercury__parse__parse_dirs_2_0));
Define_label(mercury__parse__parse_dirs_2_0_i17);
	update_prof_current_proc(LABEL(mercury__parse__parse_dirs_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__parse__parse_dirs_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__parse__parse_dirs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__parse__parse_dirs_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module11)
	init_entry(mercury____Unify___parse__command_0_0);
	init_label(mercury____Unify___parse__command_0_0_i4);
	init_label(mercury____Unify___parse__command_0_0_i5);
	init_label(mercury____Unify___parse__command_0_0_i7);
	init_label(mercury____Unify___parse__command_0_0_i9);
	init_label(mercury____Unify___parse__command_0_0_i11);
	init_label(mercury____Unify___parse__command_0_0_i13);
	init_label(mercury____Unify___parse__command_0_0_i15);
	init_label(mercury____Unify___parse__command_0_0_i17);
	init_label(mercury____Unify___parse__command_0_0_i19);
	init_label(mercury____Unify___parse__command_0_0_i21);
	init_label(mercury____Unify___parse__command_0_0_i23);
	init_label(mercury____Unify___parse__command_0_0_i25);
	init_label(mercury____Unify___parse__command_0_0_i29);
	init_label(mercury____Unify___parse__command_0_0_i33);
	init_label(mercury____Unify___parse__command_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__command_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___parse__command_0_0_i4) AND
		LABEL(mercury____Unify___parse__command_0_0_i25) AND
		LABEL(mercury____Unify___parse__command_0_0_i29) AND
		LABEL(mercury____Unify___parse__command_0_0_i33));
Define_label(mercury____Unify___parse__command_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Unify___parse__command_0_0_i5) AND
		LABEL(mercury____Unify___parse__command_0_0_i7) AND
		LABEL(mercury____Unify___parse__command_0_0_i9) AND
		LABEL(mercury____Unify___parse__command_0_0_i11) AND
		LABEL(mercury____Unify___parse__command_0_0_i13) AND
		LABEL(mercury____Unify___parse__command_0_0_i15) AND
		LABEL(mercury____Unify___parse__command_0_0_i17) AND
		LABEL(mercury____Unify___parse__command_0_0_i19) AND
		LABEL(mercury____Unify___parse__command_0_0_i21) AND
		LABEL(mercury____Unify___parse__command_0_0_i23));
Define_label(mercury____Unify___parse__command_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i7);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i9);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i13);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i15);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i17);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i19);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i21);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 8))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i23);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9))))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__command_0_0_i25);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(STATIC(mercury____Unify___parse__path_0_0),
		ENTRY(mercury____Unify___parse__command_0_0));
Define_label(mercury____Unify___parse__command_0_0_i29);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(STATIC(mercury____Unify___parse__path_0_0),
		ENTRY(mercury____Unify___parse__command_0_0));
Define_label(mercury____Unify___parse__command_0_0_i33);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___parse__command_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	tailcall(STATIC(mercury____Unify___parse__setting_0_0),
		ENTRY(mercury____Unify___parse__command_0_0));
Define_label(mercury____Unify___parse__command_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module12)
	init_entry(mercury____Index___parse__command_0_0);
	init_label(mercury____Index___parse__command_0_0_i4);
	init_label(mercury____Index___parse__command_0_0_i5);
	init_label(mercury____Index___parse__command_0_0_i6);
	init_label(mercury____Index___parse__command_0_0_i7);
	init_label(mercury____Index___parse__command_0_0_i8);
	init_label(mercury____Index___parse__command_0_0_i9);
	init_label(mercury____Index___parse__command_0_0_i10);
	init_label(mercury____Index___parse__command_0_0_i11);
	init_label(mercury____Index___parse__command_0_0_i12);
	init_label(mercury____Index___parse__command_0_0_i13);
	init_label(mercury____Index___parse__command_0_0_i14);
	init_label(mercury____Index___parse__command_0_0_i15);
	init_label(mercury____Index___parse__command_0_0_i16);
	init_label(mercury____Index___parse__command_0_0_i17);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__command_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___parse__command_0_0_i4) AND
		LABEL(mercury____Index___parse__command_0_0_i15) AND
		LABEL(mercury____Index___parse__command_0_0_i16) AND
		LABEL(mercury____Index___parse__command_0_0_i17));
Define_label(mercury____Index___parse__command_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Index___parse__command_0_0_i5) AND
		LABEL(mercury____Index___parse__command_0_0_i6) AND
		LABEL(mercury____Index___parse__command_0_0_i7) AND
		LABEL(mercury____Index___parse__command_0_0_i8) AND
		LABEL(mercury____Index___parse__command_0_0_i9) AND
		LABEL(mercury____Index___parse__command_0_0_i10) AND
		LABEL(mercury____Index___parse__command_0_0_i11) AND
		LABEL(mercury____Index___parse__command_0_0_i12) AND
		LABEL(mercury____Index___parse__command_0_0_i13) AND
		LABEL(mercury____Index___parse__command_0_0_i14));
Define_label(mercury____Index___parse__command_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i6);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i7);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i8);
	r1 = (Integer) 5;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i9);
	r1 = (Integer) 7;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i10);
	r1 = (Integer) 8;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i11);
	r1 = (Integer) 9;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i12);
	r1 = (Integer) 10;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i13);
	r1 = (Integer) 11;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i14);
	r1 = (Integer) 12;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i15);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i16);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___parse__command_0_0_i17);
	r1 = (Integer) 6;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(parse_module13)
	init_entry(mercury____Compare___parse__command_0_0);
	init_label(mercury____Compare___parse__command_0_0_i2);
	init_label(mercury____Compare___parse__command_0_0_i3);
	init_label(mercury____Compare___parse__command_0_0_i4);
	init_label(mercury____Compare___parse__command_0_0_i5);
	init_label(mercury____Compare___parse__command_0_0_i10);
	init_label(mercury____Compare___parse__command_0_0_i11);
	init_label(mercury____Compare___parse__command_0_0_i13);
	init_label(mercury____Compare___parse__command_0_0_i15);
	init_label(mercury____Compare___parse__command_0_0_i17);
	init_label(mercury____Compare___parse__command_0_0_i19);
	init_label(mercury____Compare___parse__command_0_0_i21);
	init_label(mercury____Compare___parse__command_0_0_i23);
	init_label(mercury____Compare___parse__command_0_0_i25);
	init_label(mercury____Compare___parse__command_0_0_i27);
	init_label(mercury____Compare___parse__command_0_0_i29);
	init_label(mercury____Compare___parse__command_0_0_i31);
	init_label(mercury____Compare___parse__command_0_0_i34);
	init_label(mercury____Compare___parse__command_0_0_i37);
	init_label(mercury____Compare___parse__command_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__command_0_0);
	MR_incr_sp_push_msg(4, "parse:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury____Index___parse__command_0_0),
		mercury____Compare___parse__command_0_0_i2,
		ENTRY(mercury____Compare___parse__command_0_0));
Define_label(mercury____Compare___parse__command_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___parse__command_0_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury____Index___parse__command_0_0),
		mercury____Compare___parse__command_0_0_i3,
		ENTRY(mercury____Compare___parse__command_0_0));
Define_label(mercury____Compare___parse__command_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___parse__command_0_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i4);
	if (((Integer) MR_stackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i5);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i5);
	r1 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___parse__command_0_0_i10) AND
		LABEL(mercury____Compare___parse__command_0_0_i31) AND
		LABEL(mercury____Compare___parse__command_0_0_i34) AND
		LABEL(mercury____Compare___parse__command_0_0_i37));
Define_label(mercury____Compare___parse__command_0_0_i10);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Compare___parse__command_0_0_i11) AND
		LABEL(mercury____Compare___parse__command_0_0_i13) AND
		LABEL(mercury____Compare___parse__command_0_0_i15) AND
		LABEL(mercury____Compare___parse__command_0_0_i17) AND
		LABEL(mercury____Compare___parse__command_0_0_i19) AND
		LABEL(mercury____Compare___parse__command_0_0_i21) AND
		LABEL(mercury____Compare___parse__command_0_0_i23) AND
		LABEL(mercury____Compare___parse__command_0_0_i25) AND
		LABEL(mercury____Compare___parse__command_0_0_i27) AND
		LABEL(mercury____Compare___parse__command_0_0_i29));
Define_label(mercury____Compare___parse__command_0_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i13);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i15);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i17);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i19);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i21);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i23);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i25);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i27);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 8))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i29);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9))))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__command_0_0_i31);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury____Compare___parse__path_0_0),
		ENTRY(mercury____Compare___parse__command_0_0));
Define_label(mercury____Compare___parse__command_0_0_i34);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury____Compare___parse__path_0_0),
		ENTRY(mercury____Compare___parse__command_0_0));
Define_label(mercury____Compare___parse__command_0_0_i37);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___parse__command_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury____Compare___parse__setting_0_0),
		ENTRY(mercury____Compare___parse__command_0_0));
Define_label(mercury____Compare___parse__command_0_0_i7);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___parse__command_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(parse_module14)
	init_entry(mercury____Unify___parse__path_0_0);
	init_label(mercury____Unify___parse__path_0_0_i3);
	init_label(mercury____Unify___parse__path_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__path_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__path_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__path_0_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___parse__path_0_0));
Define_label(mercury____Unify___parse__path_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__path_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___parse__path_0_0));
Define_label(mercury____Unify___parse__path_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module15)
	init_entry(mercury____Index___parse__path_0_0);
	init_label(mercury____Index___parse__path_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__path_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___parse__path_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___parse__path_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(parse_module16)
	init_entry(mercury____Compare___parse__path_0_0);
	init_label(mercury____Compare___parse__path_0_0_i3);
	init_label(mercury____Compare___parse__path_0_0_i2);
	init_label(mercury____Compare___parse__path_0_0_i5);
	init_label(mercury____Compare___parse__path_0_0_i4);
	init_label(mercury____Compare___parse__path_0_0_i6);
	init_label(mercury____Compare___parse__path_0_0_i7);
	init_label(mercury____Compare___parse__path_0_0_i11);
	init_label(mercury____Compare___parse__path_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__path_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___parse__path_0_0_i2);
Define_label(mercury____Compare___parse__path_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___parse__path_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___parse__path_0_0_i4);
Define_label(mercury____Compare___parse__path_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___parse__path_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___parse__path_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___parse__path_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i1014);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___parse__path_0_0));
Define_label(mercury____Compare___parse__path_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___parse__path_0_0_i1014);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_parse__type_ctor_info_dir_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___parse__path_0_0));
Define_label(mercury____Compare___parse__path_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___parse__path_0_0));
END_MODULE


BEGIN_MODULE(parse_module17)
	init_entry(mercury____Unify___parse__dir_0_0);
	init_label(mercury____Unify___parse__dir_0_0_i3);
	init_label(mercury____Unify___parse__dir_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__dir_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___parse__dir_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___parse__dir_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__dir_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___parse__dir_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__dir_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__dir_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module18)
	init_entry(mercury____Index___parse__dir_0_0);
	init_label(mercury____Index___parse__dir_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__dir_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___parse__dir_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___parse__dir_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(parse_module19)
	init_entry(mercury____Compare___parse__dir_0_0);
	init_label(mercury____Compare___parse__dir_0_0_i3);
	init_label(mercury____Compare___parse__dir_0_0_i2);
	init_label(mercury____Compare___parse__dir_0_0_i5);
	init_label(mercury____Compare___parse__dir_0_0_i4);
	init_label(mercury____Compare___parse__dir_0_0_i6);
	init_label(mercury____Compare___parse__dir_0_0_i7);
	init_label(mercury____Compare___parse__dir_0_0_i11);
	init_label(mercury____Compare___parse__dir_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__dir_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___parse__dir_0_0_i2);
Define_label(mercury____Compare___parse__dir_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___parse__dir_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___parse__dir_0_0_i4);
Define_label(mercury____Compare___parse__dir_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___parse__dir_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___parse__dir_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___parse__dir_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___parse__dir_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__dir_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__dir_0_0));
Define_label(mercury____Compare___parse__dir_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___parse__dir_0_0));
END_MODULE


BEGIN_MODULE(parse_module20)
	init_entry(mercury____Unify___parse__setting_0_0);
	init_label(mercury____Unify___parse__setting_0_0_i4);
	init_label(mercury____Unify___parse__setting_0_0_i6);
	init_label(mercury____Unify___parse__setting_0_0_i8);
	init_label(mercury____Unify___parse__setting_0_0_i10);
	init_label(mercury____Unify___parse__setting_0_0_i11);
	init_label(mercury____Unify___parse__setting_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__setting_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___parse__setting_0_0_i4) AND
		LABEL(mercury____Unify___parse__setting_0_0_i6) AND
		LABEL(mercury____Unify___parse__setting_0_0_i8) AND
		LABEL(mercury____Unify___parse__setting_0_0_i10));
Define_label(mercury____Unify___parse__setting_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__setting_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__setting_0_0_i8);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if ((MR_const_field(MR_mktag(2), r1, (Integer) 0) != MR_const_field(MR_mktag(2), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__setting_0_0_i10);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if ((MR_const_field(MR_mktag(3), r1, (Integer) 1) != MR_const_field(MR_mktag(3), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__setting_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	if ((MR_const_field(MR_mktag(3), r1, (Integer) 1) != MR_const_field(MR_mktag(3), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__setting_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__setting_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module21)
	init_entry(mercury____Index___parse__setting_0_0);
	init_label(mercury____Index___parse__setting_0_0_i4);
	init_label(mercury____Index___parse__setting_0_0_i5);
	init_label(mercury____Index___parse__setting_0_0_i6);
	init_label(mercury____Index___parse__setting_0_0_i7);
	init_label(mercury____Index___parse__setting_0_0_i8);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__setting_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___parse__setting_0_0_i4) AND
		LABEL(mercury____Index___parse__setting_0_0_i5) AND
		LABEL(mercury____Index___parse__setting_0_0_i6) AND
		LABEL(mercury____Index___parse__setting_0_0_i7));
Define_label(mercury____Index___parse__setting_0_0_i4);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___parse__setting_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___parse__setting_0_0_i6);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___parse__setting_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Index___parse__setting_0_0_i8);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___parse__setting_0_0_i8);
	r1 = (Integer) 4;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module22)
	init_entry(mercury____Compare___parse__setting_0_0);
	init_label(mercury____Compare___parse__setting_0_0_i4);
	init_label(mercury____Compare___parse__setting_0_0_i5);
	init_label(mercury____Compare___parse__setting_0_0_i6);
	init_label(mercury____Compare___parse__setting_0_0_i7);
	init_label(mercury____Compare___parse__setting_0_0_i8);
	init_label(mercury____Compare___parse__setting_0_0_i11);
	init_label(mercury____Compare___parse__setting_0_0_i12);
	init_label(mercury____Compare___parse__setting_0_0_i13);
	init_label(mercury____Compare___parse__setting_0_0_i14);
	init_label(mercury____Compare___parse__setting_0_0_i15);
	init_label(mercury____Compare___parse__setting_0_0_i9);
	init_label(mercury____Compare___parse__setting_0_0_i16);
	init_label(mercury____Compare___parse__setting_0_0_i17);
	init_label(mercury____Compare___parse__setting_0_0_i22);
	init_label(mercury____Compare___parse__setting_0_0_i25);
	init_label(mercury____Compare___parse__setting_0_0_i28);
	init_label(mercury____Compare___parse__setting_0_0_i31);
	init_label(mercury____Compare___parse__setting_0_0_i32);
	init_label(mercury____Compare___parse__setting_0_0_i1020);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__setting_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___parse__setting_0_0_i4) AND
		LABEL(mercury____Compare___parse__setting_0_0_i5) AND
		LABEL(mercury____Compare___parse__setting_0_0_i6) AND
		LABEL(mercury____Compare___parse__setting_0_0_i7));
Define_label(mercury____Compare___parse__setting_0_0_i4);
	r3 = (Integer) 0;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury____Compare___parse__setting_0_0_i11) AND
		LABEL(mercury____Compare___parse__setting_0_0_i12) AND
		LABEL(mercury____Compare___parse__setting_0_0_i13) AND
		LABEL(mercury____Compare___parse__setting_0_0_i14));
Define_label(mercury____Compare___parse__setting_0_0_i5);
	r3 = (Integer) 1;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury____Compare___parse__setting_0_0_i11) AND
		LABEL(mercury____Compare___parse__setting_0_0_i12) AND
		LABEL(mercury____Compare___parse__setting_0_0_i13) AND
		LABEL(mercury____Compare___parse__setting_0_0_i14));
Define_label(mercury____Compare___parse__setting_0_0_i6);
	r3 = (Integer) 2;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury____Compare___parse__setting_0_0_i11) AND
		LABEL(mercury____Compare___parse__setting_0_0_i12) AND
		LABEL(mercury____Compare___parse__setting_0_0_i13) AND
		LABEL(mercury____Compare___parse__setting_0_0_i14));
Define_label(mercury____Compare___parse__setting_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i8);
	r3 = (Integer) 3;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury____Compare___parse__setting_0_0_i11) AND
		LABEL(mercury____Compare___parse__setting_0_0_i12) AND
		LABEL(mercury____Compare___parse__setting_0_0_i13) AND
		LABEL(mercury____Compare___parse__setting_0_0_i14));
Define_label(mercury____Compare___parse__setting_0_0_i8);
	r3 = (Integer) 4;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury____Compare___parse__setting_0_0_i11) AND
		LABEL(mercury____Compare___parse__setting_0_0_i12) AND
		LABEL(mercury____Compare___parse__setting_0_0_i13) AND
		LABEL(mercury____Compare___parse__setting_0_0_i14));
Define_label(mercury____Compare___parse__setting_0_0_i11);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___parse__setting_0_0_i9);
Define_label(mercury____Compare___parse__setting_0_0_i12);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___parse__setting_0_0_i9);
Define_label(mercury____Compare___parse__setting_0_0_i13);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___parse__setting_0_0_i9);
Define_label(mercury____Compare___parse__setting_0_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i15);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___parse__setting_0_0_i9);
Define_label(mercury____Compare___parse__setting_0_0_i15);
	r4 = (Integer) 4;
Define_label(mercury____Compare___parse__setting_0_0_i9);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i16);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___parse__setting_0_0_i16);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i17);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___parse__setting_0_0_i17);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___parse__setting_0_0_i22) AND
		LABEL(mercury____Compare___parse__setting_0_0_i25) AND
		LABEL(mercury____Compare___parse__setting_0_0_i28) AND
		LABEL(mercury____Compare___parse__setting_0_0_i31));
Define_label(mercury____Compare___parse__setting_0_0_i22);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
Define_label(mercury____Compare___parse__setting_0_0_i25);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
Define_label(mercury____Compare___parse__setting_0_0_i28);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
Define_label(mercury____Compare___parse__setting_0_0_i31);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i32);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
Define_label(mercury____Compare___parse__setting_0_0_i32);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___parse__setting_0_0_i1020);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
Define_label(mercury____Compare___parse__setting_0_0_i1020);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___parse__setting_0_0));
END_MODULE


BEGIN_MODULE(parse_module23)
	init_entry(mercury____Unify___parse__portray_format_0_0);
	init_label(mercury____Unify___parse__portray_format_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__portray_format_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___parse__portray_format_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__portray_format_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module24)
	init_entry(mercury____Index___parse__portray_format_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__portray_format_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(parse_module25)
	init_entry(mercury____Compare___parse__portray_format_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__portray_format_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___parse__portray_format_0_0));
END_MODULE


BEGIN_MODULE(parse_module26)
	init_entry(mercury____Unify___parse__external_request_0_0);
	init_label(mercury____Unify___parse__external_request_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___parse__external_request_0_0);
	if ((strcmp((char *)r1, (char *)r2) != 0))
		GOTO_LABEL(mercury____Unify___parse__external_request_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__external_request_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module27)
	init_entry(mercury____Index___parse__external_request_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___parse__external_request_0_0);
	tailcall(STATIC(mercury____Index___parse__external_request_0__ua0_2_0),
		ENTRY(mercury____Index___parse__external_request_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(parse_module28)
	init_entry(mercury____Compare___parse__external_request_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___parse__external_request_0_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___parse__external_request_0_0));
END_MODULE


BEGIN_MODULE(parse_module29)
	init_entry(mercury____Unify___parse__token_0_0);
	init_label(mercury____Unify___parse__token_0_0_i4);
	init_label(mercury____Unify___parse__token_0_0_i5);
	init_label(mercury____Unify___parse__token_0_0_i7);
	init_label(mercury____Unify___parse__token_0_0_i9);
	init_label(mercury____Unify___parse__token_0_0_i11);
	init_label(mercury____Unify___parse__token_0_0_i13);
	init_label(mercury____Unify___parse__token_0_0_i15);
	init_label(mercury____Unify___parse__token_0_0_i17);
	init_label(mercury____Unify___parse__token_0_0_i19);
	init_label(mercury____Unify___parse__token_0_0_i21);
	init_label(mercury____Unify___parse__token_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___parse__token_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___parse__token_0_0_i4) AND
		LABEL(mercury____Unify___parse__token_0_0_i17) AND
		LABEL(mercury____Unify___parse__token_0_0_i19) AND
		LABEL(mercury____Unify___parse__token_0_0_i21));
Define_label(mercury____Unify___parse__token_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Unify___parse__token_0_0_i5) AND
		LABEL(mercury____Unify___parse__token_0_0_i7) AND
		LABEL(mercury____Unify___parse__token_0_0_i9) AND
		LABEL(mercury____Unify___parse__token_0_0_i11) AND
		LABEL(mercury____Unify___parse__token_0_0_i13) AND
		LABEL(mercury____Unify___parse__token_0_0_i15));
Define_label(mercury____Unify___parse__token_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i7);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i9);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i13);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i15);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i17);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(2), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i21);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	if ((MR_const_field(MR_mktag(3), r1, (Integer) 0) != MR_const_field(MR_mktag(3), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___parse__token_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___parse__token_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module30)
	init_entry(mercury____Index___parse__token_0_0);
	init_label(mercury____Index___parse__token_0_0_i4);
	init_label(mercury____Index___parse__token_0_0_i5);
	init_label(mercury____Index___parse__token_0_0_i6);
	init_label(mercury____Index___parse__token_0_0_i7);
	init_label(mercury____Index___parse__token_0_0_i8);
	init_label(mercury____Index___parse__token_0_0_i9);
	init_label(mercury____Index___parse__token_0_0_i10);
	init_label(mercury____Index___parse__token_0_0_i11);
	init_label(mercury____Index___parse__token_0_0_i12);
	init_label(mercury____Index___parse__token_0_0_i13);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___parse__token_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___parse__token_0_0_i4) AND
		LABEL(mercury____Index___parse__token_0_0_i11) AND
		LABEL(mercury____Index___parse__token_0_0_i12) AND
		LABEL(mercury____Index___parse__token_0_0_i13));
Define_label(mercury____Index___parse__token_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Index___parse__token_0_0_i5) AND
		LABEL(mercury____Index___parse__token_0_0_i6) AND
		LABEL(mercury____Index___parse__token_0_0_i7) AND
		LABEL(mercury____Index___parse__token_0_0_i8) AND
		LABEL(mercury____Index___parse__token_0_0_i9) AND
		LABEL(mercury____Index___parse__token_0_0_i10));
Define_label(mercury____Index___parse__token_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i8);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i9);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i10);
	r1 = (Integer) 5;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i11);
	r1 = (Integer) 6;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i12);
	r1 = (Integer) 7;
	proceed();
Define_label(mercury____Index___parse__token_0_0_i13);
	r1 = (Integer) 8;
	proceed();
END_MODULE


BEGIN_MODULE(parse_module31)
	init_entry(mercury____Compare___parse__token_0_0);
	init_label(mercury____Compare___parse__token_0_0_i2);
	init_label(mercury____Compare___parse__token_0_0_i3);
	init_label(mercury____Compare___parse__token_0_0_i4);
	init_label(mercury____Compare___parse__token_0_0_i5);
	init_label(mercury____Compare___parse__token_0_0_i10);
	init_label(mercury____Compare___parse__token_0_0_i11);
	init_label(mercury____Compare___parse__token_0_0_i13);
	init_label(mercury____Compare___parse__token_0_0_i15);
	init_label(mercury____Compare___parse__token_0_0_i17);
	init_label(mercury____Compare___parse__token_0_0_i19);
	init_label(mercury____Compare___parse__token_0_0_i21);
	init_label(mercury____Compare___parse__token_0_0_i23);
	init_label(mercury____Compare___parse__token_0_0_i26);
	init_label(mercury____Compare___parse__token_0_0_i29);
	init_label(mercury____Compare___parse__token_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___parse__token_0_0);
	MR_incr_sp_push_msg(4, "parse:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury____Index___parse__token_0_0),
		mercury____Compare___parse__token_0_0_i2,
		STATIC(mercury____Compare___parse__token_0_0));
Define_label(mercury____Compare___parse__token_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___parse__token_0_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury____Index___parse__token_0_0),
		mercury____Compare___parse__token_0_0_i3,
		STATIC(mercury____Compare___parse__token_0_0));
Define_label(mercury____Compare___parse__token_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___parse__token_0_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i4);
	if (((Integer) MR_stackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i5);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i5);
	r1 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___parse__token_0_0_i10) AND
		LABEL(mercury____Compare___parse__token_0_0_i23) AND
		LABEL(mercury____Compare___parse__token_0_0_i26) AND
		LABEL(mercury____Compare___parse__token_0_0_i29));
Define_label(mercury____Compare___parse__token_0_0_i10);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Compare___parse__token_0_0_i11) AND
		LABEL(mercury____Compare___parse__token_0_0_i13) AND
		LABEL(mercury____Compare___parse__token_0_0_i15) AND
		LABEL(mercury____Compare___parse__token_0_0_i17) AND
		LABEL(mercury____Compare___parse__token_0_0_i19) AND
		LABEL(mercury____Compare___parse__token_0_0_i21));
Define_label(mercury____Compare___parse__token_0_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i13);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i15);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i17);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i19);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i21);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___parse__token_0_0_i23);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___parse__token_0_0));
Define_label(mercury____Compare___parse__token_0_0_i26);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		STATIC(mercury____Compare___parse__token_0_0));
Define_label(mercury____Compare___parse__token_0_0_i29);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___parse__token_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___parse__token_0_0));
Define_label(mercury____Compare___parse__token_0_0_i7);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___parse__token_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__parse_maybe_bunch_0(void)
{
	parse_module0();
	parse_module1();
	parse_module2();
	parse_module3();
	parse_module4();
	parse_module5();
	parse_module6();
	parse_module7();
	parse_module8();
	parse_module9();
	parse_module10();
	parse_module11();
	parse_module12();
	parse_module13();
	parse_module14();
	parse_module15();
	parse_module16();
	parse_module17();
	parse_module18();
	parse_module19();
	parse_module20();
	parse_module21();
	parse_module22();
	parse_module23();
	parse_module24();
	parse_module25();
	parse_module26();
	parse_module27();
	parse_module28();
	parse_module29();
	parse_module30();
	parse_module31();
}

#endif

void mercury__parse__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__parse__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__parse_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_command_0,
			parse__command_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_dir_0,
			parse__dir_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_external_request_0,
			parse__external_request_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_path_0,
			parse__path_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_portray_format_0,
			parse__portray_format_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_setting_0,
			parse__setting_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_parse__type_ctor_info_token_0,
			parse__token_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
