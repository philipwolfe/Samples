/*
** Automatically generated from `util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__util__init
ENDINIT
*/

#include "mercury_imp.h"
#line 81 "util.m"

	#include "mercury_wrapper.h"
	#include "mercury_string.h"
	#include "mercury_trace_base.h"
	#include "mercury_trace_internal.h"

#line 28 "util.c"

Define_extern_entry(mercury__util__trace_getline_4_0);
Declare_label(mercury__util__trace_getline_4_0_i2);
Declare_label(mercury__util__trace_getline_4_0_i3);
Declare_label(mercury__util__trace_getline_4_0_i6);
Declare_label(mercury__util__trace_getline_4_0_i7);
Declare_label(mercury__util__trace_getline_4_0_i5);
Define_extern_entry(mercury__util__trace_getline_6_0);
Declare_label(mercury__util__trace_getline_6_0_i4);
Declare_label(mercury__util__trace_getline_6_0_i5);
Declare_label(mercury__util__trace_getline_6_0_i3);
Define_extern_entry(mercury__util__zip_with_4_0);
Declare_label(mercury__util__zip_with_4_0_i2);
Declare_label(mercury__util__zip_with_4_0_i8);
Declare_label(mercury__util__zip_with_4_0_i9);
Declare_label(mercury__util__zip_with_4_0_i5);
Define_extern_entry(mercury__util__limit_3_0);
Declare_label(mercury__util__limit_3_0_i1001);
Declare_label(mercury__util__limit_3_0_i2);
Declare_label(mercury__util__limit_3_0_i5);
Declare_label(mercury__util__limit_3_0_i3);
Declare_static(mercury__util__call_trace_getline_4_0);
Declare_label(mercury__util__call_trace_getline_4_0_i2);
Declare_label(mercury__util__call_trace_getline_4_0_i3);
Define_extern_entry(mercury____Unify___util__trace_port_type_0_0);
Declare_label(mercury____Unify___util__trace_port_type_0_0_i1);
Define_extern_entry(mercury____Index___util__trace_port_type_0_0);
Define_extern_entry(mercury____Compare___util__trace_port_type_0_0);
Define_extern_entry(mercury____Unify___util__goal_path_string_0_0);
Declare_label(mercury____Unify___util__goal_path_string_0_0_i1);
Define_extern_entry(mercury____Index___util__goal_path_string_0_0);
Define_extern_entry(mercury____Compare___util__goal_path_string_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_util__type_ctor_info_goal_path_string_0;

const struct MR_TypeCtorInfo_struct mercury_data_util__type_ctor_info_trace_port_type_0;

static const struct mercury_data_util__common_0_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
	String f13;
	String f14;
	String f15;
	String f16;
	String f17;
}  mercury_data_util__common_0;

static const struct mercury_data_util__common_1_struct {
	Word * f1;
}  mercury_data_util__common_1;

static const struct mercury_data_util__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_util__common_2;

static const struct mercury_data_util__type_ctor_functors_trace_port_type_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_util__type_ctor_functors_trace_port_type_0;

static const struct mercury_data_util__type_ctor_layout_trace_port_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_util__type_ctor_layout_trace_port_type_0;

static const struct mercury_data_util__type_ctor_functors_goal_path_string_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_util__type_ctor_functors_goal_path_string_0;

static const struct mercury_data_util__type_ctor_layout_goal_path_string_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_util__type_ctor_layout_goal_path_string_0;

const struct MR_TypeCtorInfo_struct mercury_data_util__type_ctor_info_goal_path_string_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___util__goal_path_string_0_0),
	ENTRY(mercury____Index___util__goal_path_string_0_0),
	ENTRY(mercury____Compare___util__goal_path_string_0_0),
	(Integer) 6,
	(Word *) &mercury_data_util__type_ctor_functors_goal_path_string_0,
	(Word *) &mercury_data_util__type_ctor_layout_goal_path_string_0,
	MR_string_const("util", 4),
	MR_string_const("goal_path_string", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_util__type_ctor_info_trace_port_type_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___util__trace_port_type_0_0),
	ENTRY(mercury____Index___util__trace_port_type_0_0),
	ENTRY(mercury____Compare___util__trace_port_type_0_0),
	(Integer) 0,
	(Word *) &mercury_data_util__type_ctor_functors_trace_port_type_0,
	(Word *) &mercury_data_util__type_ctor_layout_trace_port_type_0,
	MR_string_const("util", 4),
	MR_string_const("trace_port_type", 15),
	(Integer) 3
};

static const struct mercury_data_util__common_0_struct mercury_data_util__common_0 = {
	(Integer) 1,
	(Integer) 15,
	MR_string_const("call", 4),
	MR_string_const("exit", 4),
	MR_string_const("redo", 4),
	MR_string_const("fail", 4),
	MR_string_const("exception", 9),
	MR_string_const("ite_cond", 8),
	MR_string_const("ite_then", 8),
	MR_string_const("ite_else", 8),
	MR_string_const("neg_enter", 9),
	MR_string_const("neg_success", 11),
	MR_string_const("neg_failure", 11),
	MR_string_const("disj", 4),
	MR_string_const("switch", 6),
	MR_string_const("nondet_pragma_first", 19),
	MR_string_const("nondet_pragma_later", 19)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_util__common_1_struct mercury_data_util__common_1 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_util__common_2_struct mercury_data_util__common_2 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_1)
};

static const struct mercury_data_util__type_ctor_functors_trace_port_type_0_struct mercury_data_util__type_ctor_functors_trace_port_type_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_0)
};

static const struct mercury_data_util__type_ctor_layout_trace_port_type_0_struct mercury_data_util__type_ctor_layout_trace_port_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_0)
};

static const struct mercury_data_util__type_ctor_functors_goal_path_string_0_struct mercury_data_util__type_ctor_functors_goal_path_string_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_util__common_1)
};

static const struct mercury_data_util__type_ctor_layout_goal_path_string_0_struct mercury_data_util__type_ctor_layout_goal_path_string_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_util__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_util__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_util__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_util__common_2)
};

Declare_entry(mercury__io__input_stream_3_0);
Declare_entry(mercury__io__output_stream_3_0);

BEGIN_MODULE(util_module0)
	init_entry(mercury__util__trace_getline_4_0);
	init_label(mercury__util__trace_getline_4_0_i2);
	init_label(mercury__util__trace_getline_4_0_i3);
	init_label(mercury__util__trace_getline_4_0_i6);
	init_label(mercury__util__trace_getline_4_0_i7);
	init_label(mercury__util__trace_getline_4_0_i5);
BEGIN_CODE

/* code for predicate 'trace_getline'/4 in mode 0 */
Define_entry(mercury__util__trace_getline_4_0);
	MR_incr_sp_push_msg(3, "util:trace_getline/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__input_stream_3_0),
		mercury__util__trace_getline_4_0_i2,
		ENTRY(mercury__util__trace_getline_4_0));
Define_label(mercury__util__trace_getline_4_0_i2);
	update_prof_current_proc(LABEL(mercury__util__trace_getline_4_0));
	MR_stackvar(2) = r1;
	r3 = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__output_stream_3_0),
		mercury__util__trace_getline_4_0_i3,
		ENTRY(mercury__util__trace_getline_4_0));
Define_label(mercury__util__trace_getline_4_0_i3);
	update_prof_current_proc(LABEL(mercury__util__trace_getline_4_0));
	r3 = r1;
	{
	Word	MdbIn;
	Word	MdbOut;
	String	Prompt;
	String	Line;
#define MR_PROC_LABEL mercury__util__trace_getline_4_0
	MdbIn = MR_stackvar(2);
	MdbOut = r1;
	Prompt = (String) MR_stackvar(1);
	MR_OBTAIN_GLOBAL_LOCK("call_trace_getline");
{
#line 91 "util.m"

		char		*line;
		char		*mercury_string;
		MercuryFile	*mdb_in = (MercuryFile *) MdbIn;
		MercuryFile	*mdb_out = (MercuryFile *) MdbOut;

		if (MR_address_of_trace_getline != NULL) {
			line = (*MR_address_of_trace_getline)((char *) Prompt,
					mdb_in->file, mdb_out->file);
		} else {
			MR_tracing_not_enabled();
			/* not reached */
		}

		if (line == NULL) {
			SUCCESS_INDICATOR = FALSE;
		} else {
			MR_make_aligned_string_copy(mercury_string, line);
			free(line);
			Line = (String) mercury_string;
			SUCCESS_INDICATOR = TRUE;
		}
	;}
#line 268 "util.c"
	MR_RELEASE_GLOBAL_LOCK("call_trace_getline");
if (!r1) GOTO_LABEL(mercury__util__trace_getline_4_0_i6);
	r1 = (Word) Line;
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__util__trace_getline_4_0_i7);
Define_label(mercury__util__trace_getline_4_0_i6);
	GOTO_LABEL(mercury__util__trace_getline_4_0_i5);
Define_label(mercury__util__trace_getline_4_0_i7);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__util__trace_getline_4_0, "io:result/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__util__trace_getline_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(util_module1)
	init_entry(mercury__util__trace_getline_6_0);
	init_label(mercury__util__trace_getline_6_0_i4);
	init_label(mercury__util__trace_getline_6_0_i5);
	init_label(mercury__util__trace_getline_6_0_i3);
BEGIN_CODE

/* code for predicate 'trace_getline'/6 in mode 0 */
Define_entry(mercury__util__trace_getline_6_0);
	MR_incr_sp_push_msg(1, "util:trace_getline/6");
	r5 = r1;
	{
	Word	MdbIn;
	Word	MdbOut;
	String	Prompt;
	String	Line;
#define MR_PROC_LABEL mercury__util__trace_getline_6_0
	MdbIn = r2;
	MdbOut = r3;
	Prompt = (String) r1;
	MR_OBTAIN_GLOBAL_LOCK("call_trace_getline");
{
#line 91 "util.m"

		char		*line;
		char		*mercury_string;
		MercuryFile	*mdb_in = (MercuryFile *) MdbIn;
		MercuryFile	*mdb_out = (MercuryFile *) MdbOut;

		if (MR_address_of_trace_getline != NULL) {
			line = (*MR_address_of_trace_getline)((char *) Prompt,
					mdb_in->file, mdb_out->file);
		} else {
			MR_tracing_not_enabled();
			/* not reached */
		}

		if (line == NULL) {
			SUCCESS_INDICATOR = FALSE;
		} else {
			MR_make_aligned_string_copy(mercury_string, line);
			free(line);
			Line = (String) mercury_string;
			SUCCESS_INDICATOR = TRUE;
		}
	;}
#line 339 "util.c"
	MR_RELEASE_GLOBAL_LOCK("call_trace_getline");
if (!r1) GOTO_LABEL(mercury__util__trace_getline_6_0_i4);
	r1 = (Word) Line;
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__util__trace_getline_6_0_i5);
Define_label(mercury__util__trace_getline_6_0_i4);
	GOTO_LABEL(mercury__util__trace_getline_6_0_i3);
Define_label(mercury__util__trace_getline_6_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__util__trace_getline_6_0, "io:result/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r3 = r2;
	r2 = r4;
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__util__trace_getline_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r4;
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__do_call_closure);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(util_module2)
	init_entry(mercury__util__zip_with_4_0);
	init_label(mercury__util__zip_with_4_0_i2);
	init_label(mercury__util__zip_with_4_0_i8);
	init_label(mercury__util__zip_with_4_0_i9);
	init_label(mercury__util__zip_with_4_0_i5);
BEGIN_CODE

/* code for predicate 'zip_with'/4 in mode 0 */
Define_entry(mercury__util__zip_with_4_0);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__util__zip_with_4_0_i2);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__util__zip_with_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__util__zip_with_4_0_i2);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__util__zip_with_4_0_i5);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__util__zip_with_4_0_i5);
	MR_incr_sp_push_msg(7, "util:zip_with/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(4) = r1;
	r1 = r4;
	MR_stackvar(1) = r4;
	r4 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(5) = r2;
	MR_stackvar(6) = r3;
	r5 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r6, (Integer) 1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__util__zip_with_4_0_i8,
		ENTRY(mercury__util__zip_with_4_0));
Define_label(mercury__util__zip_with_4_0_i8);
	update_prof_current_proc(LABEL(mercury__util__zip_with_4_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	localcall(mercury__util__zip_with_4_0,
		LABEL(mercury__util__zip_with_4_0_i9),
		ENTRY(mercury__util__zip_with_4_0));
Define_label(mercury__util__zip_with_4_0_i9);
	update_prof_current_proc(LABEL(mercury__util__zip_with_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__util__zip_with_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__util__zip_with_4_0_i5);
	r1 = (Word) MR_string_const("zip_with: list arguments are of unequal length", 46);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__util__zip_with_4_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(util_module3)
	init_entry(mercury__util__limit_3_0);
	init_label(mercury__util__limit_3_0_i1001);
	init_label(mercury__util__limit_3_0_i2);
	init_label(mercury__util__limit_3_0_i5);
	init_label(mercury__util__limit_3_0_i3);
BEGIN_CODE

/* code for predicate 'limit'/3 in mode 0 */
Define_entry(mercury__util__limit_3_0);
	MR_incr_sp_push_msg(4, "util:limit/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__util__limit_3_0_i1001);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r1;
	r4 = r3;
	r1 = r2;
	r2 = (Integer) 1;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__util__limit_3_0_i2,
		ENTRY(mercury__util__limit_3_0));
Define_label(mercury__util__limit_3_0_i2);
	update_prof_current_proc(LABEL(mercury__util__limit_3_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r3 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__util__limit_3_0_i5,
		ENTRY(mercury__util__limit_3_0));
Define_label(mercury__util__limit_3_0_i5);
	update_prof_current_proc(LABEL(mercury__util__limit_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__util__limit_3_0_i3);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__util__limit_3_0_i3);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__util__limit_3_0_i1001);
END_MODULE


BEGIN_MODULE(util_module4)
	init_entry(mercury__util__call_trace_getline_4_0);
	init_label(mercury__util__call_trace_getline_4_0_i2);
	init_label(mercury__util__call_trace_getline_4_0_i3);
BEGIN_CODE

/* code for predicate 'call_trace_getline'/4 in mode 0 */
Define_static(mercury__util__call_trace_getline_4_0);
	r4 = r1;
	{
	Word	MdbIn;
	Word	MdbOut;
	String	Prompt;
	String	Line;
#define MR_PROC_LABEL mercury__util__call_trace_getline_4_0
	MdbIn = r1;
	MdbOut = r2;
	Prompt = (String) r3;
	MR_OBTAIN_GLOBAL_LOCK("call_trace_getline");
{
#line 91 "util.m"

		char		*line;
		char		*mercury_string;
		MercuryFile	*mdb_in = (MercuryFile *) MdbIn;
		MercuryFile	*mdb_out = (MercuryFile *) MdbOut;

		if (MR_address_of_trace_getline != NULL) {
			line = (*MR_address_of_trace_getline)((char *) Prompt,
					mdb_in->file, mdb_out->file);
		} else {
			MR_tracing_not_enabled();
			/* not reached */
		}

		if (line == NULL) {
			SUCCESS_INDICATOR = FALSE;
		} else {
			MR_make_aligned_string_copy(mercury_string, line);
			free(line);
			Line = (String) mercury_string;
			SUCCESS_INDICATOR = TRUE;
		}
	;}
#line 526 "util.c"
	MR_RELEASE_GLOBAL_LOCK("call_trace_getline");
if (!r1) GOTO_LABEL(mercury__util__call_trace_getline_4_0_i2);
	r1 = (Word) Line;
#undef MR_PROC_LABEL

	}
	GOTO_LABEL(mercury__util__call_trace_getline_4_0_i3);
Define_label(mercury__util__call_trace_getline_4_0_i2);
	r1 = FALSE;
	proceed();
Define_label(mercury__util__call_trace_getline_4_0_i3);
	r2 = r1;
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(util_module5)
	init_entry(mercury____Unify___util__trace_port_type_0_0);
	init_label(mercury____Unify___util__trace_port_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___util__trace_port_type_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___util__trace_port_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___util__trace_port_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(util_module6)
	init_entry(mercury____Index___util__trace_port_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___util__trace_port_type_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(util_module7)
	init_entry(mercury____Compare___util__trace_port_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___util__trace_port_type_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___util__trace_port_type_0_0));
END_MODULE


BEGIN_MODULE(util_module8)
	init_entry(mercury____Unify___util__goal_path_string_0_0);
	init_label(mercury____Unify___util__goal_path_string_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___util__goal_path_string_0_0);
	if ((strcmp((char *)r1, (char *)r2) != 0))
		GOTO_LABEL(mercury____Unify___util__goal_path_string_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___util__goal_path_string_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_string_2_0);

BEGIN_MODULE(util_module9)
	init_entry(mercury____Index___util__goal_path_string_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___util__goal_path_string_0_0);
	tailcall(ENTRY(mercury__builtin_index_string_2_0),
		ENTRY(mercury____Index___util__goal_path_string_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(util_module10)
	init_entry(mercury____Compare___util__goal_path_string_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___util__goal_path_string_0_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___util__goal_path_string_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__util_maybe_bunch_0(void)
{
	util_module0();
	util_module1();
	util_module2();
	util_module3();
	util_module4();
	util_module5();
	util_module6();
	util_module7();
	util_module8();
	util_module9();
	util_module10();
}

#endif

void mercury__util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__util_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_util__type_ctor_info_goal_path_string_0,
			util__goal_path_string_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_util__type_ctor_info_trace_port_type_0,
			util__trace_port_type_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
