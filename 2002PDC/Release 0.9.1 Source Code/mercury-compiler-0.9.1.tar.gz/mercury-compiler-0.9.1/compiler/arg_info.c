/*
** Automatically generated from `arg_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__arg_info__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__arg_info__generate_arg_info_2_0);
Declare_label(mercury__arg_info__generate_arg_info_2_0_i2);
Declare_label(mercury__arg_info__generate_arg_info_2_0_i3);
Define_extern_entry(mercury__arg_info__unify_arg_info_2_0);
Declare_label(mercury__arg_info__unify_arg_info_2_0_i3);
Declare_label(mercury__arg_info__unify_arg_info_2_0_i4);
Define_extern_entry(mercury__arg_info__make_arg_infos_5_0);
Declare_label(mercury__arg_info__make_arg_infos_5_0_i2);
Define_extern_entry(mercury__arg_info__build_input_arg_list_2_0);
Declare_label(mercury__arg_info__build_input_arg_list_2_0_i4);
Declare_label(mercury__arg_info__build_input_arg_list_2_0_i7);
Declare_label(mercury__arg_info__build_input_arg_list_2_0_i3);
Declare_label(mercury__arg_info__build_input_arg_list_2_0_i2);
Declare_static(mercury__arg_info__generate_pred_arg_info_3_0);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i1001);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i4);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i5);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i6);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i7);
Declare_label(mercury__arg_info__generate_pred_arg_info_3_0_i3);
Declare_static(mercury__arg_info__generate_proc_list_arg_info_4_0);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i1003);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i4);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i5);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i8);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i6);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i10);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i11);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i12);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i13);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i14);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i15);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i17);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i18);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i19);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i20);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i21);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i22);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i23);
Declare_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i3);
Declare_static(mercury__arg_info__make_arg_infos_list_6_0);
Declare_label(mercury__arg_info__make_arg_infos_list_6_0_i3);
Declare_label(mercury__arg_info__make_arg_infos_list_6_0_i9);
Declare_label(mercury__arg_info__make_arg_infos_list_6_0_i11);
Declare_label(mercury__arg_info__make_arg_infos_list_6_0_i13);
Declare_label(mercury__arg_info__make_arg_infos_list_6_0_i8);

static const struct mercury_data_arg_info__common_0_struct {
	Integer f1;
	Integer f2;
}  mercury_data_arg_info__common_0;

static const struct mercury_data_arg_info__common_1_struct {
	Integer f1;
	Integer f2;
}  mercury_data_arg_info__common_1;

static const struct mercury_data_arg_info__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_arg_info__common_2;

static const struct mercury_data_arg_info__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_arg_info__common_3;

static const struct mercury_data_arg_info__common_0_struct mercury_data_arg_info__common_0 = {
	(Integer) 1,
	(Integer) 0
};

static const struct mercury_data_arg_info__common_1_struct mercury_data_arg_info__common_1 = {
	(Integer) 2,
	(Integer) 0
};

static const struct mercury_data_arg_info__common_2_struct mercury_data_arg_info__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_arg_info__common_1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_arg_info__common_3_struct mercury_data_arg_info__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_arg_info__common_0),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_arg_info__common_2)
};

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__keys_2_0);

BEGIN_MODULE(arg_info_module0)
	init_entry(mercury__arg_info__generate_arg_info_2_0);
	init_label(mercury__arg_info__generate_arg_info_2_0_i2);
	init_label(mercury__arg_info__generate_arg_info_2_0_i3);
BEGIN_CODE

/* code for predicate 'generate_arg_info'/2 in mode 0 */
Define_entry(mercury__arg_info__generate_arg_info_2_0);
	MR_incr_sp_push_msg(2, "arg_info:generate_arg_info/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__arg_info__generate_arg_info_2_0_i2,
		ENTRY(mercury__arg_info__generate_arg_info_2_0));
Define_label(mercury__arg_info__generate_arg_info_2_0_i2);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_arg_info_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__arg_info__generate_arg_info_2_0_i3,
		ENTRY(mercury__arg_info__generate_arg_info_2_0));
Define_label(mercury__arg_info__generate_arg_info_2_0_i3);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_arg_info_2_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__arg_info__generate_pred_arg_info_3_0),
		ENTRY(mercury__arg_info__generate_arg_info_2_0));
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(arg_info_module1)
	init_entry(mercury__arg_info__unify_arg_info_2_0);
	init_label(mercury__arg_info__unify_arg_info_2_0_i3);
	init_label(mercury__arg_info__unify_arg_info_2_0_i4);
BEGIN_CODE

/* code for predicate 'unify_arg_info'/2 in mode 0 */
Define_entry(mercury__arg_info__unify_arg_info_2_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__arg_info__unify_arg_info_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_arg_info__common_3);
	proceed();
Define_label(mercury__arg_info__unify_arg_info_2_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__arg_info__unify_arg_info_2_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_arg_info__common_3);
	proceed();
Define_label(mercury__arg_info__unify_arg_info_2_0_i4);
	r1 = (Word) MR_string_const("arg_info: nondet unify!", 23);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__arg_info__unify_arg_info_2_0));
END_MODULE


BEGIN_MODULE(arg_info_module2)
	init_entry(mercury__arg_info__make_arg_infos_5_0);
	init_label(mercury__arg_info__make_arg_infos_5_0_i2);
BEGIN_CODE

/* code for predicate 'make_arg_infos'/5 in mode 0 */
Define_entry(mercury__arg_info__make_arg_infos_5_0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__arg_info__make_arg_infos_5_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r5 = r4;
	r3 = (Integer) 1;
	r4 = (Integer) 2;
	tailcall(STATIC(mercury__arg_info__make_arg_infos_list_6_0),
		ENTRY(mercury__arg_info__make_arg_infos_5_0));
	}
Define_label(mercury__arg_info__make_arg_infos_5_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r5 = r4;
	r3 = (Integer) 1;
	r4 = (Integer) 1;
	tailcall(STATIC(mercury__arg_info__make_arg_infos_list_6_0),
		ENTRY(mercury__arg_info__make_arg_infos_5_0));
	}
END_MODULE

Declare_entry(mercury__code_util__arg_loc_to_register_2_0);

BEGIN_MODULE(arg_info_module3)
	init_entry(mercury__arg_info__build_input_arg_list_2_0);
	init_label(mercury__arg_info__build_input_arg_list_2_0_i4);
	init_label(mercury__arg_info__build_input_arg_list_2_0_i7);
	init_label(mercury__arg_info__build_input_arg_list_2_0_i3);
	init_label(mercury__arg_info__build_input_arg_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'build_input_arg_list'/2 in mode 0 */
Define_entry(mercury__arg_info__build_input_arg_list_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__build_input_arg_list_2_0_i3);
	MR_incr_sp_push_msg(4, "arg_info:build_input_arg_list/2");
	MR_stackvar(4) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__arg_info__build_input_arg_list_2_0,
		LABEL(mercury__arg_info__build_input_arg_list_2_0_i4),
		ENTRY(mercury__arg_info__build_input_arg_list_2_0));
Define_label(mercury__arg_info__build_input_arg_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__arg_info__build_input_arg_list_2_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__arg_info__build_input_arg_list_2_0_i2);
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__arg_info__build_input_arg_list_2_0_i7,
		ENTRY(mercury__arg_info__build_input_arg_list_2_0));
Define_label(mercury__arg_info__build_input_arg_list_2_0_i7);
	update_prof_current_proc(LABEL(mercury__arg_info__build_input_arg_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__arg_info__build_input_arg_list_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__arg_info__build_input_arg_list_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__arg_info__build_input_arg_list_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__arg_info__build_input_arg_list_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__arg_info__build_input_arg_list_2_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);

BEGIN_MODULE(arg_info_module4)
	init_entry(mercury__arg_info__generate_pred_arg_info_3_0);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i1001);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i4);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i5);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i6);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i7);
	init_label(mercury__arg_info__generate_pred_arg_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'generate_pred_arg_info'/3 in mode 0 */
Define_static(mercury__arg_info__generate_pred_arg_info_3_0);
	MR_incr_sp_push_msg(4, "arg_info:generate_pred_arg_info/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__generate_pred_arg_info_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__arg_info__generate_pred_arg_info_3_0_i4,
		STATIC(mercury__arg_info__generate_pred_arg_info_3_0));
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_pred_arg_info_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__arg_info__generate_pred_arg_info_3_0_i5,
		STATIC(mercury__arg_info__generate_pred_arg_info_3_0));
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i5);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_pred_arg_info_3_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__arg_info__generate_pred_arg_info_3_0_i6,
		STATIC(mercury__arg_info__generate_pred_arg_info_3_0));
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i6);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_pred_arg_info_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0),
		mercury__arg_info__generate_pred_arg_info_3_0_i7,
		STATIC(mercury__arg_info__generate_pred_arg_info_3_0));
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i7);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_pred_arg_info_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__arg_info__generate_pred_arg_info_3_0_i1001);
Define_label(mercury__arg_info__generate_pred_arg_info_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_is_aditi_relation_1_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arg_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_set_arg_info_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(arg_info_module5)
	init_entry(mercury__arg_info__generate_proc_list_arg_info_4_0);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i1003);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i4);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i5);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i8);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i6);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i10);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i11);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i12);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i13);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i14);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i15);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i17);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i18);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i19);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i20);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i21);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i22);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i23);
	init_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i3);
BEGIN_CODE

/* code for predicate 'generate_proc_list_arg_info'/4 in mode 0 */
Define_static(mercury__arg_info__generate_proc_list_arg_info_4_0);
	MR_incr_sp_push_msg(11, "arg_info:generate_proc_list_arg_info/4");
	MR_stackvar(11) = (Word) MR_succip;
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i1003);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = r3;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i4,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i4);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r3 = r1;
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i5,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i5);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_aditi_relation_1_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i8,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i8);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i6);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i1003);
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i6);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i10,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i10);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i11,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i11);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i12,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i12);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i13,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i13);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i14,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i14);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i15);
	r5 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	r1 = MR_stackvar(10);
	r4 = (Integer) 2;
	r3 = (Integer) 1;
	GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i17);
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i15);
	r5 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	r1 = MR_stackvar(10);
	r4 = (Integer) 1;
	r3 = (Integer) 1;
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i17);
	MR_stackvar(2) = r5;
	call_localret(STATIC(mercury__arg_info__make_arg_infos_list_6_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i18,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i18);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_arg_info_3_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i19,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i19);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i20,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i20);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i21,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i21);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i22,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i22);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__arg_info__generate_proc_list_arg_info_4_0_i23,
		STATIC(mercury__arg_info__generate_proc_list_arg_info_4_0));
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i23);
	update_prof_current_proc(LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__arg_info__generate_proc_list_arg_info_4_0_i1003);
Define_label(mercury__arg_info__generate_proc_list_arg_info_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE

Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);

BEGIN_MODULE(arg_info_module6)
	init_entry(mercury__arg_info__make_arg_infos_list_6_0);
	init_label(mercury__arg_info__make_arg_infos_list_6_0_i3);
	init_label(mercury__arg_info__make_arg_infos_list_6_0_i9);
	init_label(mercury__arg_info__make_arg_infos_list_6_0_i11);
	init_label(mercury__arg_info__make_arg_infos_list_6_0_i13);
	init_label(mercury__arg_info__make_arg_infos_list_6_0_i8);
BEGIN_CODE

/* code for predicate 'make_arg_infos_list'/6 in mode 0 */
Define_static(mercury__arg_info__make_arg_infos_list_6_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__make_arg_infos_list_6_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__make_arg_infos_list_6_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__arg_info__make_arg_infos_list_6_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__arg_info__make_arg_infos_list_6_0_i8);
	MR_incr_sp_push_msg(6, "arg_info:make_arg_infos_list/6");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r5;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__arg_info__make_arg_infos_list_6_0_i9,
		STATIC(mercury__arg_info__make_arg_infos_list_6_0));
Define_label(mercury__arg_info__make_arg_infos_list_6_0_i9);
	update_prof_current_proc(LABEL(mercury__arg_info__make_arg_infos_list_6_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__arg_info__make_arg_infos_list_6_0_i11);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(1);
	tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (Integer) 2, mercury__arg_info__make_arg_infos_list_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 0) = MR_tempr1;
	MR_stackvar(1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 1) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = ((Integer) MR_tempr1 + (Integer) 1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	localcall(mercury__arg_info__make_arg_infos_list_6_0,
		LABEL(mercury__arg_info__make_arg_infos_list_6_0_i13),
		STATIC(mercury__arg_info__make_arg_infos_list_6_0));
	}
Define_label(mercury__arg_info__make_arg_infos_list_6_0_i11);
	r5 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__arg_info__make_arg_infos_list_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_tempr2 = MR_stackvar(2);
	r1 = MR_stackvar(5);
	r4 = ((Integer) MR_tempr2 + (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_tempr2;
	localcall(mercury__arg_info__make_arg_infos_list_6_0,
		LABEL(mercury__arg_info__make_arg_infos_list_6_0_i13),
		STATIC(mercury__arg_info__make_arg_infos_list_6_0));
	}
Define_label(mercury__arg_info__make_arg_infos_list_6_0_i13);
	update_prof_current_proc(LABEL(mercury__arg_info__make_arg_infos_list_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__arg_info__make_arg_infos_list_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__arg_info__make_arg_infos_list_6_0_i8);
	r1 = (Word) MR_string_const("make_arg_infos_list: length mis-match", 37);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__arg_info__make_arg_infos_list_6_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__arg_info_maybe_bunch_0(void)
{
	arg_info_module0();
	arg_info_module1();
	arg_info_module2();
	arg_info_module3();
	arg_info_module4();
	arg_info_module5();
	arg_info_module6();
}

#endif

void mercury__arg_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__arg_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__arg_info_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
