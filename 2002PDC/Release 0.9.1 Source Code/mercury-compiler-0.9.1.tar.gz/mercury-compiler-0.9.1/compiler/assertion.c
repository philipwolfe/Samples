/*
** Automatically generated from `assertion.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__assertion__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__assertion__goal_3_0);
Declare_label(mercury__assertion__goal_3_0_i2);
Declare_label(mercury__assertion__goal_3_0_i3);
Declare_label(mercury__assertion__goal_3_0_i4);
Declare_label(mercury__assertion__goal_3_0_i5);
Declare_label(mercury__assertion__goal_3_0_i6);
Declare_label(mercury__assertion__goal_3_0_i7);
Define_extern_entry(mercury__assertion__record_preds_used_in_4_0);
Declare_label(mercury__assertion__record_preds_used_in_4_0_i2);
Define_extern_entry(mercury__assertion__is_commutativity_assertion_4_0);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i2);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i7);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i20);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i22);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i26);
Declare_label(mercury__assertion__is_commutativity_assertion_4_0_i1);
Define_extern_entry(mercury__assertion__in_interface_check_6_0);
Declare_label(mercury__assertion__in_interface_check_6_0_i1002);
Declare_label(mercury__assertion__in_interface_check_6_0_i4);
Declare_label(mercury__assertion__in_interface_check_6_0_i6);
Declare_label(mercury__assertion__in_interface_check_6_0_i7);
Declare_label(mercury__assertion__in_interface_check_6_0_i8);
Declare_label(mercury__assertion__in_interface_check_6_0_i10);
Declare_label(mercury__assertion__in_interface_check_6_0_i11);
Declare_label(mercury__assertion__in_interface_check_6_0_i12);
Declare_label(mercury__assertion__in_interface_check_6_0_i13);
Declare_label(mercury__assertion__in_interface_check_6_0_i16);
Declare_label(mercury__assertion__in_interface_check_6_0_i17);
Declare_label(mercury__assertion__in_interface_check_6_0_i18);
Declare_label(mercury__assertion__in_interface_check_6_0_i19);
Declare_label(mercury__assertion__in_interface_check_6_0_i20);
Declare_label(mercury__assertion__in_interface_check_6_0_i21);
Declare_label(mercury__assertion__in_interface_check_6_0_i25);
Declare_label(mercury__assertion__in_interface_check_6_0_i27);
Declare_label(mercury__assertion__in_interface_check_6_0_i29);
Declare_label(mercury__assertion__in_interface_check_6_0_i30);
Declare_label(mercury__assertion__in_interface_check_6_0_i31);
Declare_label(mercury__assertion__in_interface_check_6_0_i33);
Declare_label(mercury__assertion__in_interface_check_6_0_i34);
Declare_label(mercury__assertion__in_interface_check_6_0_i35);
Declare_label(mercury__assertion__in_interface_check_6_0_i37);
Declare_label(mercury__assertion__in_interface_check_6_0_i38);
Declare_label(mercury__assertion__in_interface_check_6_0_i39);
Declare_label(mercury__assertion__in_interface_check_6_0_i40);
Declare_label(mercury__assertion__in_interface_check_6_0_i41);
Declare_label(mercury__assertion__in_interface_check_6_0_i36);
Declare_label(mercury__assertion__in_interface_check_6_0_i44);
Declare_label(mercury__assertion__in_interface_check_6_0_i46);
Declare_label(mercury__assertion__in_interface_check_6_0_i47);
Declare_static(mercury__assertion__commutative_var_ordering_4_0);
Declare_label(mercury__assertion__commutative_var_ordering_4_0_i1005);
Declare_label(mercury__assertion__commutative_var_ordering_4_0_i6);
Declare_label(mercury__assertion__commutative_var_ordering_4_0_i5);
Declare_label(mercury__assertion__commutative_var_ordering_4_0_i10);
Declare_label(mercury__assertion__commutative_var_ordering_4_0_i1);
Declare_static(mercury__assertion__commutative_var_ordering_2_6_0);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i1007);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i6);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i5);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i10);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i12);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i14);
Declare_label(mercury__assertion__commutative_var_ordering_2_6_0_i1);
Declare_static(mercury__assertion__equal_goals_4_0);
Declare_label(mercury__assertion__equal_goals_4_0_i1024);
Declare_label(mercury__assertion__equal_goals_4_0_i4);
Declare_label(mercury__assertion__equal_goals_4_0_i8);
Declare_label(mercury__assertion__equal_goals_4_0_i10);
Declare_label(mercury__assertion__equal_goals_4_0_i14);
Declare_label(mercury__assertion__equal_goals_4_0_i16);
Declare_label(mercury__assertion__equal_goals_4_0_i20);
Declare_label(mercury__assertion__equal_goals_4_0_i21);
Declare_label(mercury__assertion__equal_goals_4_0_i23);
Declare_label(mercury__assertion__equal_goals_4_0_i27);
Declare_label(mercury__assertion__equal_goals_4_0_i29);
Declare_label(mercury__assertion__equal_goals_4_0_i33);
Declare_label(mercury__assertion__equal_goals_4_0_i37);
Declare_label(mercury__assertion__equal_goals_4_0_i41);
Declare_label(mercury__assertion__equal_goals_4_0_i43);
Declare_label(mercury__assertion__equal_goals_4_0_i47);
Declare_label(mercury__assertion__equal_goals_4_0_i49);
Declare_label(mercury__assertion__equal_goals_4_0_i51);
Declare_label(mercury__assertion__equal_goals_4_0_i53);
Declare_label(mercury__assertion__equal_goals_4_0_i57);
Declare_label(mercury__assertion__equal_goals_4_0_i59);
Declare_label(mercury__assertion__equal_goals_4_0_i61);
Declare_label(mercury__assertion__equal_goals_4_0_i65);
Declare_label(mercury__assertion__equal_goals_4_0_i69);
Declare_label(mercury__assertion__equal_goals_4_0_i71);
Declare_label(mercury__assertion__equal_goals_4_0_i1);
Declare_static(mercury__assertion__equal_vars_4_0);
Declare_label(mercury__assertion__equal_vars_4_0_i1006);
Declare_label(mercury__assertion__equal_vars_4_0_i3);
Declare_label(mercury__assertion__equal_vars_4_0_i7);
Declare_label(mercury__assertion__equal_vars_4_0_i9);
Declare_label(mercury__assertion__equal_vars_4_0_i6);
Declare_label(mercury__assertion__equal_vars_4_0_i13);
Declare_label(mercury__assertion__equal_vars_4_0_i1);
Declare_static(mercury__assertion__equal_unification_4_0);
Declare_label(mercury__assertion__equal_unification_4_0_i10);
Declare_label(mercury__assertion__equal_unification_4_0_i12);
Declare_label(mercury__assertion__equal_unification_4_0_i14);
Declare_label(mercury__assertion__equal_unification_4_0_i16);
Declare_label(mercury__assertion__equal_unification_4_0_i4);
Declare_label(mercury__assertion__equal_unification_4_0_i6);
Declare_label(mercury__assertion__equal_unification_4_0_i1017);
Declare_label(mercury__assertion__equal_unification_4_0_i1);
Declare_static(mercury__assertion__equal_goals_list_4_0);
Declare_label(mercury__assertion__equal_goals_list_4_0_i1004);
Declare_label(mercury__assertion__equal_goals_list_4_0_i3);
Declare_label(mercury__assertion__equal_goals_list_4_0_i6);
Declare_label(mercury__assertion__equal_goals_list_4_0_i1);
Declare_static(mercury__assertion__equal_goals_cases_4_0);
Declare_label(mercury__assertion__equal_goals_cases_4_0_i1005);
Declare_label(mercury__assertion__equal_goals_cases_4_0_i3);
Declare_label(mercury__assertion__equal_goals_cases_4_0_i6);
Declare_label(mercury__assertion__equal_goals_cases_4_0_i8);
Declare_label(mercury__assertion__equal_goals_cases_4_0_i1);
Declare_static(mercury__assertion__update_pred_info_4_0);
Declare_label(mercury__assertion__update_pred_info_4_0_i2);
Declare_label(mercury__assertion__update_pred_info_4_0_i3);
Declare_label(mercury__assertion__update_pred_info_4_0_i4);
Declare_label(mercury__assertion__update_pred_info_4_0_i5);
Declare_static(mercury__assertion__normalise_goal_2_0);
Declare_label(mercury__assertion__normalise_goal_2_0_i4);
Declare_label(mercury__assertion__normalise_goal_2_0_i5);
Declare_label(mercury__assertion__normalise_goal_2_0_i8);
Declare_label(mercury__assertion__normalise_goal_2_0_i9);
Declare_label(mercury__assertion__normalise_goal_2_0_i10);
Declare_label(mercury__assertion__normalise_goal_2_0_i12);
Declare_label(mercury__assertion__normalise_goal_2_0_i13);
Declare_label(mercury__assertion__normalise_goal_2_0_i14);
Declare_label(mercury__assertion__normalise_goal_2_0_i15);
Declare_label(mercury__assertion__normalise_goal_2_0_i16);
Declare_label(mercury__assertion__normalise_goal_2_0_i17);
Declare_label(mercury__assertion__normalise_goal_2_0_i18);
Declare_label(mercury__assertion__normalise_goal_2_0_i19);
Declare_label(mercury__assertion__normalise_goal_2_0_i20);
Declare_label(mercury__assertion__normalise_goal_2_0_i21);
Declare_label(mercury__assertion__normalise_goal_2_0_i23);
Declare_label(mercury__assertion__normalise_goal_2_0_i24);
Declare_label(mercury__assertion__normalise_goal_2_0_i25);
Declare_label(mercury__assertion__normalise_goal_2_0_i26);
Declare_label(mercury__assertion__normalise_goal_2_0_i27);
Declare_label(mercury__assertion__normalise_goal_2_0_i1018);
Declare_label(mercury__assertion__normalise_goal_2_0_i2);
Declare_static(mercury__assertion__normalise_conj_2_0);
Declare_label(mercury__assertion__normalise_conj_2_0_i4);
Declare_label(mercury__assertion__normalise_conj_2_0_i5);
Declare_label(mercury__assertion__normalise_conj_2_0_i3);
Declare_static(mercury__assertion__normalise_cases_2_0);
Declare_label(mercury__assertion__normalise_cases_2_0_i4);
Declare_label(mercury__assertion__normalise_cases_2_0_i5);
Declare_label(mercury__assertion__normalise_cases_2_0_i3);
Declare_static(mercury__assertion__normalise_goals_2_0);
Declare_label(mercury__assertion__normalise_goals_2_0_i4);
Declare_label(mercury__assertion__normalise_goals_2_0_i5);
Declare_label(mercury__assertion__normalise_goals_2_0_i3);
Declare_static(mercury__assertion__in_interface_check_unify_rhs_8_0);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1012);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i4);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i5);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i6);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i7);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i10);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i12);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i13);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i14);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i18);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i28);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i16);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i29);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1013);
Declare_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i9);
Declare_static(mercury__assertion__in_interface_check_list_6_0);
Declare_label(mercury__assertion__in_interface_check_list_6_0_i1001);
Declare_label(mercury__assertion__in_interface_check_list_6_0_i4);
Declare_label(mercury__assertion__in_interface_check_list_6_0_i3);
Declare_static(mercury__assertion__is_defined_in_implementation_section_2_0);
Declare_label(mercury__assertion__is_defined_in_implementation_section_2_0_i4);
Declare_label(mercury__assertion__is_defined_in_implementation_section_2_0_i1001);
Declare_label(mercury__assertion__is_defined_in_implementation_section_2_0_i14);
Declare_static(mercury__assertion__write_assertion_interface_error_6_0);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i2);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i3);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i4);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i5);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i6);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i7);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i8);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i9);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i12);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i11);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i14);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i15);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i16);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i17);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i18);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i19);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i20);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i21);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i22);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i25);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i26);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i27);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i28);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i29);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i30);
Declare_label(mercury__assertion__write_assertion_interface_error_6_0_i23);
Declare_static(mercury____Unify___assertion__subst_0_0);
Declare_static(mercury____Index___assertion__subst_0_0);
Declare_static(mercury____Compare___assertion__subst_0_0);
Declare_static(mercury____Unify___assertion__call_or_consid_0_0);
Declare_label(mercury____Unify___assertion__call_or_consid_0_0_i5);
Declare_label(mercury____Unify___assertion__call_or_consid_0_0_i1007);
Declare_label(mercury____Unify___assertion__call_or_consid_0_0_i1009);
Declare_label(mercury____Unify___assertion__call_or_consid_0_0_i1);
Declare_static(mercury____Index___assertion__call_or_consid_0_0);
Declare_label(mercury____Index___assertion__call_or_consid_0_0_i3);
Declare_static(mercury____Compare___assertion__call_or_consid_0_0);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i3);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i2);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i5);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i4);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i6);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i7);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i14);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i18);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i11);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i1016);
Declare_label(mercury____Compare___assertion__call_or_consid_0_0_i29);

const struct MR_TypeCtorInfo_struct mercury_data_assertion__type_ctor_info_call_or_consid_0;

const struct MR_TypeCtorInfo_struct mercury_data_assertion__type_ctor_info_subst_0;

static const struct mercury_data_assertion__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_assertion__common_0;

static const struct mercury_data_assertion__common_1_struct {
	Word * f1;
}  mercury_data_assertion__common_1;

static const struct mercury_data_assertion__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_assertion__common_2;

static const struct mercury_data_assertion__common_3_struct {
	Word * f1;
}  mercury_data_assertion__common_3;

static const struct mercury_data_assertion__common_4_struct {
	Word * f1;
}  mercury_data_assertion__common_4;

static const struct mercury_data_assertion__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_assertion__common_5;

static const struct mercury_data_assertion__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_assertion__common_6;

static const struct mercury_data_assertion__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_assertion__common_7;

static const struct mercury_data_assertion__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_assertion__common_8;

static const struct mercury_data_assertion__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_assertion__common_9;

static const struct mercury_data_assertion__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_assertion__common_10;

static const struct mercury_data_assertion__common_11_struct {
	Word * f1;
}  mercury_data_assertion__common_11;

static const struct mercury_data_assertion__common_12_struct {
	Word * f1;
}  mercury_data_assertion__common_12;

static const struct mercury_data_assertion__common_13_struct {
	Word * f1;
}  mercury_data_assertion__common_13;

static const struct mercury_data_assertion__common_14_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_assertion__common_14;

static const struct mercury_data_assertion__common_15_struct {
	Word * f1;
}  mercury_data_assertion__common_15;

static const struct mercury_data_assertion__common_16_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_assertion__common_16;

static const struct mercury_data_assertion__type_ctor_functors_subst_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_assertion__type_ctor_functors_subst_0;

static const struct mercury_data_assertion__type_ctor_layout_subst_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_assertion__type_ctor_layout_subst_0;

static const struct mercury_data_assertion__type_ctor_functors_call_or_consid_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_assertion__type_ctor_functors_call_or_consid_0;

static const struct mercury_data_assertion__type_ctor_layout_call_or_consid_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_assertion__type_ctor_layout_call_or_consid_0;

const struct MR_TypeCtorInfo_struct mercury_data_assertion__type_ctor_info_call_or_consid_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___assertion__call_or_consid_0_0),
	STATIC(mercury____Index___assertion__call_or_consid_0_0),
	STATIC(mercury____Compare___assertion__call_or_consid_0_0),
	(Integer) 2,
	(Word *) &mercury_data_assertion__type_ctor_functors_call_or_consid_0,
	(Word *) &mercury_data_assertion__type_ctor_layout_call_or_consid_0,
	MR_string_const("assertion", 9),
	MR_string_const("call_or_consid", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_assertion__type_ctor_info_subst_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___assertion__subst_0_0),
	STATIC(mercury____Index___assertion__subst_0_0),
	STATIC(mercury____Compare___assertion__subst_0_0),
	(Integer) 6,
	(Word *) &mercury_data_assertion__type_ctor_functors_subst_0,
	(Word *) &mercury_data_assertion__type_ctor_layout_subst_0,
	MR_string_const("assertion", 9),
	MR_string_const("subst", 5),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_assertion__common_0_struct mercury_data_assertion__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_assertion__common_1_struct mercury_data_assertion__common_1 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_assertion__common_2_struct mercury_data_assertion__common_2 = {
	(Integer) 0,
	MR_string_const("goal_util", 9),
	MR_string_const("goal_util", 9),
	MR_string_const("goal_calls_pred_id", 18),
	2,
	1,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_assert_id_0;
static const struct mercury_data_assertion__common_3_struct mercury_data_assertion__common_3 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_assert_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_assertion__common_4_struct mercury_data_assertion__common_4 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_assertion__common_5_struct mercury_data_assertion__common_5 = {
	(Integer) 0,
	MR_string_const("assertion", 9),
	MR_string_const("assertion", 9),
	MR_string_const("update_pred_info", 16),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_assertion__common_6_struct mercury_data_assertion__common_6 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_assertion__common_7_struct mercury_data_assertion__common_7 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_assertion__common_8_struct mercury_data_assertion__common_8 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_assertion__common_9_struct mercury_data_assertion__common_9 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6)
};

static const struct mercury_data_assertion__common_10_struct mercury_data_assertion__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_9)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_pred_or_func_0;
static const struct mercury_data_assertion__common_11_struct mercury_data_assertion__common_11 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_pred_or_func_0
};

static const struct mercury_data_assertion__common_12_struct mercury_data_assertion__common_12 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0
};

static const struct mercury_data_assertion__common_13_struct mercury_data_assertion__common_13 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_assertion__common_14_struct mercury_data_assertion__common_14 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_13),
	MR_string_const("call", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_assertion__common_15_struct mercury_data_assertion__common_15 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

static const struct mercury_data_assertion__common_16_struct mercury_data_assertion__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_15),
	MR_string_const("cons", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_assertion__type_ctor_functors_subst_0_struct mercury_data_assertion__type_ctor_functors_subst_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_9)
};

static const struct mercury_data_assertion__type_ctor_layout_subst_0_struct mercury_data_assertion__type_ctor_layout_subst_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_assertion__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_assertion__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_assertion__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_assertion__common_10)
};

static const struct mercury_data_assertion__type_ctor_functors_call_or_consid_0_struct mercury_data_assertion__type_ctor_functors_call_or_consid_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_16)
};

static const struct mercury_data_assertion__type_ctor_layout_call_or_consid_0_struct mercury_data_assertion__type_ctor_layout_call_or_consid_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_assertion__common_14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_assertion__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

Declare_entry(mercury__hlds_module__module_info_assertion_table_2_0);
Declare_entry(mercury__hlds_data__assertion_table_lookup_3_0);
Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
Declare_entry(mercury__hlds_pred__clauses_info_clauses_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(assertion_module0)
	init_entry(mercury__assertion__goal_3_0);
	init_label(mercury__assertion__goal_3_0_i2);
	init_label(mercury__assertion__goal_3_0_i3);
	init_label(mercury__assertion__goal_3_0_i4);
	init_label(mercury__assertion__goal_3_0_i5);
	init_label(mercury__assertion__goal_3_0_i6);
	init_label(mercury__assertion__goal_3_0_i7);
BEGIN_CODE

/* code for predicate 'goal'/3 in mode 0 */
Define_entry(mercury__assertion__goal_3_0);
	MR_incr_sp_push_msg(3, "assertion:goal/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_assertion_table_2_0),
		mercury__assertion__goal_3_0_i2,
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i2);
	update_prof_current_proc(LABEL(mercury__assertion__goal_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_data__assertion_table_lookup_3_0),
		mercury__assertion__goal_3_0_i3,
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i3);
	update_prof_current_proc(LABEL(mercury__assertion__goal_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__assertion__goal_3_0_i4,
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__goal_3_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__assertion__goal_3_0_i5,
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__goal_3_0));
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_clauses_2_0),
		mercury__assertion__goal_3_0_i6,
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__goal_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__goal_3_0_i7);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__goal_3_0_i7);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__assertion__normalise_goal_2_0),
		ENTRY(mercury__assertion__goal_3_0));
Define_label(mercury__assertion__goal_3_0_i7);
	r1 = (Word) MR_string_const("assertion__goal: not an assertion", 33);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__assertion__goal_3_0));
END_MODULE

Declare_entry(mercury__goal_util__goal_calls_pred_id_2_1);
Declare_entry(mercury__std_util__solutions_2_1);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(assertion_module1)
	init_entry(mercury__assertion__record_preds_used_in_4_0);
	init_label(mercury__assertion__record_preds_used_in_4_0_i2);
BEGIN_CODE

/* code for predicate 'record_preds_used_in'/4 in mode 0 */
Define_entry(mercury__assertion__record_preds_used_in_4_0);
	MR_incr_sp_push_msg(3, "assertion:record_preds_used_in/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__assertion__record_preds_used_in_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) ENTRY(mercury__goal_util__goal_calls_pred_id_2_1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_2);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__assertion__record_preds_used_in_4_0_i2,
		ENTRY(mercury__assertion__record_preds_used_in_4_0));
Define_label(mercury__assertion__record_preds_used_in_4_0_i2);
	update_prof_current_proc(LABEL(mercury__assertion__record_preds_used_in_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__assertion__record_preds_used_in_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__assertion__update_pred_info_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		ENTRY(mercury__assertion__record_preds_used_in_4_0));
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);

BEGIN_MODULE(assertion_module2)
	init_entry(mercury__assertion__is_commutativity_assertion_4_0);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i2);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i7);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i20);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i22);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i26);
	init_label(mercury__assertion__is_commutativity_assertion_4_0_i1);
BEGIN_CODE

/* code for predicate 'is_commutativity_assertion'/4 in mode 0 */
Define_entry(mercury__assertion__is_commutativity_assertion_4_0);
	MR_incr_sp_push_msg(6, "assertion:is_commutativity_assertion/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__assertion__goal_3_0),
		mercury__assertion__is_commutativity_assertion_4_0_i2,
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i2);
	update_prof_current_proc(LABEL(mercury__assertion__is_commutativity_assertion_4_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__assertion__is_commutativity_assertion_4_0_i7,
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
	}
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i7);
	update_prof_current_proc(LABEL(mercury__assertion__is_commutativity_assertion_4_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	r3 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1);
	MR_stackvar(4) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	r4 = r1;
	r1 = MR_stackvar(2);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1);
	r6 = r3;
	r3 = r4;
	call_localret(STATIC(mercury__assertion__equal_goals_4_0),
		mercury__assertion__is_commutativity_assertion_4_0_i20,
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i20);
	update_prof_current_proc(LABEL(mercury__assertion__is_commutativity_assertion_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__assertion__equal_goals_4_0),
		mercury__assertion__is_commutativity_assertion_4_0_i22,
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i22);
	update_prof_current_proc(LABEL(mercury__assertion__is_commutativity_assertion_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__assertion__is_commutativity_assertion_4_0_i26,
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
	}
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i26);
	update_prof_current_proc(LABEL(mercury__assertion__is_commutativity_assertion_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__is_commutativity_assertion_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__commutative_var_ordering_4_0),
		ENTRY(mercury__assertion__is_commutativity_assertion_4_0));
Define_label(mercury__assertion__is_commutativity_assertion_4_0_i1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_import_status_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);

BEGIN_MODULE(assertion_module3)
	init_entry(mercury__assertion__in_interface_check_6_0);
	init_label(mercury__assertion__in_interface_check_6_0_i1002);
	init_label(mercury__assertion__in_interface_check_6_0_i4);
	init_label(mercury__assertion__in_interface_check_6_0_i6);
	init_label(mercury__assertion__in_interface_check_6_0_i7);
	init_label(mercury__assertion__in_interface_check_6_0_i8);
	init_label(mercury__assertion__in_interface_check_6_0_i10);
	init_label(mercury__assertion__in_interface_check_6_0_i11);
	init_label(mercury__assertion__in_interface_check_6_0_i12);
	init_label(mercury__assertion__in_interface_check_6_0_i13);
	init_label(mercury__assertion__in_interface_check_6_0_i16);
	init_label(mercury__assertion__in_interface_check_6_0_i17);
	init_label(mercury__assertion__in_interface_check_6_0_i18);
	init_label(mercury__assertion__in_interface_check_6_0_i19);
	init_label(mercury__assertion__in_interface_check_6_0_i20);
	init_label(mercury__assertion__in_interface_check_6_0_i21);
	init_label(mercury__assertion__in_interface_check_6_0_i25);
	init_label(mercury__assertion__in_interface_check_6_0_i27);
	init_label(mercury__assertion__in_interface_check_6_0_i29);
	init_label(mercury__assertion__in_interface_check_6_0_i30);
	init_label(mercury__assertion__in_interface_check_6_0_i31);
	init_label(mercury__assertion__in_interface_check_6_0_i33);
	init_label(mercury__assertion__in_interface_check_6_0_i34);
	init_label(mercury__assertion__in_interface_check_6_0_i35);
	init_label(mercury__assertion__in_interface_check_6_0_i37);
	init_label(mercury__assertion__in_interface_check_6_0_i38);
	init_label(mercury__assertion__in_interface_check_6_0_i39);
	init_label(mercury__assertion__in_interface_check_6_0_i40);
	init_label(mercury__assertion__in_interface_check_6_0_i41);
	init_label(mercury__assertion__in_interface_check_6_0_i36);
	init_label(mercury__assertion__in_interface_check_6_0_i44);
	init_label(mercury__assertion__in_interface_check_6_0_i46);
	init_label(mercury__assertion__in_interface_check_6_0_i47);
BEGIN_CODE

/* code for predicate 'in_interface_check'/6 in mode 0 */
Define_entry(mercury__assertion__in_interface_check_6_0);
	MR_incr_sp_push_msg(6, "assertion:in_interface_check/6");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__assertion__in_interface_check_6_0_i1002);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r5),
		LABEL(mercury__assertion__in_interface_check_6_0_i4) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i6) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i16) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i17));
Define_label(mercury__assertion__in_interface_check_6_0_i4);
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__in_interface_check_list_6_0),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r5, (Integer) 5);
	r1 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__assertion__in_interface_check_6_0_i7,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i7);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__assertion__in_interface_check_6_0_i8,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i8);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	call_localret(STATIC(mercury__assertion__is_defined_in_implementation_section_2_0),
		mercury__assertion__in_interface_check_6_0_i10,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i36);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__assertion__in_interface_check_6_0_i11,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i11);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__assertion__in_interface_check_6_0_i12,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i12);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__assertion__in_interface_check_6_0_i13,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i13);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__assertion__in_interface_check_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 2) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__write_assertion_interface_error_6_0),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i16);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__in_interface_check_6_0_i17);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r5, (Integer) 0),
		LABEL(mercury__assertion__in_interface_check_6_0_i18) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i20) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i44) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i25) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i27) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i29) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i33) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i44) AND
		LABEL(mercury__assertion__in_interface_check_6_0_i46));
Define_label(mercury__assertion__in_interface_check_6_0_i18);
	MR_stackvar(1) = r4;
	r1 = (Word) MR_string_const("assertion__in_interface_check: assertion contains switch.", 57);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__assertion__in_interface_check_6_0_i19,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i19);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__in_interface_check_6_0_i20);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__assertion__in_interface_check_6_0_i21,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i21);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i25);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i1002);
Define_label(mercury__assertion__in_interface_check_6_0_i27);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i1002);
Define_label(mercury__assertion__in_interface_check_6_0_i29);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	localcall(mercury__assertion__in_interface_check_6_0,
		LABEL(mercury__assertion__in_interface_check_6_0_i30),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i30);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	localcall(mercury__assertion__in_interface_check_6_0,
		LABEL(mercury__assertion__in_interface_check_6_0_i31),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i31);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i1002);
Define_label(mercury__assertion__in_interface_check_6_0_i33);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	r1 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__assertion__in_interface_check_6_0_i34,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i34);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__assertion__in_interface_check_6_0_i35,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i35);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	call_localret(STATIC(mercury__assertion__is_defined_in_implementation_section_2_0),
		mercury__assertion__in_interface_check_6_0_i37,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i37);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i36);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__assertion__in_interface_check_6_0_i38,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i38);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__assertion__in_interface_check_6_0_i39,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i39);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__assertion__in_interface_check_6_0_i40,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i40);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__assertion__in_interface_check_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__assertion__in_interface_check_6_0_i41,
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i41);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__assertion__in_interface_check_6_0, "assertion:call_or_consid/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__write_assertion_interface_error_6_0),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i36);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__in_interface_check_6_0_i44);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__in_interface_check_list_6_0),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i46);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	localcall(mercury__assertion__in_interface_check_6_0,
		LABEL(mercury__assertion__in_interface_check_6_0_i47),
		ENTRY(mercury__assertion__in_interface_check_6_0));
Define_label(mercury__assertion__in_interface_check_6_0_i47);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__in_interface_check_6_0_i1002);
END_MODULE

Declare_entry(mercury____Unify___term__var_1_0);

BEGIN_MODULE(assertion_module4)
	init_entry(mercury__assertion__commutative_var_ordering_4_0);
	init_label(mercury__assertion__commutative_var_ordering_4_0_i1005);
	init_label(mercury__assertion__commutative_var_ordering_4_0_i6);
	init_label(mercury__assertion__commutative_var_ordering_4_0_i5);
	init_label(mercury__assertion__commutative_var_ordering_4_0_i10);
	init_label(mercury__assertion__commutative_var_ordering_4_0_i1);
BEGIN_CODE

/* code for predicate 'commutative_var_ordering'/4 in mode 0 */
Define_static(mercury__assertion__commutative_var_ordering_4_0);
	MR_incr_sp_push_msg(7, "assertion:commutative_var_ordering/4");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__assertion__commutative_var_ordering_4_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__commutative_var_ordering_4_0_i6,
		STATIC(mercury__assertion__commutative_var_ordering_4_0));
Define_label(mercury__assertion__commutative_var_ordering_4_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i5);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i1005);
Define_label(mercury__assertion__commutative_var_ordering_4_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	call_localret(STATIC(mercury__assertion__commutative_var_ordering_2_6_0),
		mercury__assertion__commutative_var_ordering_4_0_i10,
		STATIC(mercury__assertion__commutative_var_ordering_4_0));
Define_label(mercury__assertion__commutative_var_ordering_4_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_4_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__assertion__commutative_var_ordering_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__assertion__commutative_var_ordering_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(assertion_module5)
	init_entry(mercury__assertion__commutative_var_ordering_2_6_0);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i1007);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i6);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i5);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i10);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i12);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i14);
	init_label(mercury__assertion__commutative_var_ordering_2_6_0_i1);
BEGIN_CODE

/* code for predicate 'commutative_var_ordering_2'/6 in mode 0 */
Define_static(mercury__assertion__commutative_var_ordering_2_6_0);
	MR_incr_sp_push_msg(9, "assertion:commutative_var_ordering_2/6");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i1007);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	r3 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(5) = r3;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__commutative_var_ordering_2_6_0_i6,
		STATIC(mercury__assertion__commutative_var_ordering_2_6_0));
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1007);
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i5);
	r3 = MR_stackvar(2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(3);
	MR_stackvar(2) = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__commutative_var_ordering_2_6_0_i10,
		STATIC(mercury__assertion__commutative_var_ordering_2_6_0));
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__commutative_var_ordering_2_6_0_i12,
		STATIC(mercury__assertion__commutative_var_ordering_2_6_0));
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__assertion__commutative_var_ordering_2_6_0_i14,
		STATIC(mercury__assertion__commutative_var_ordering_2_6_0));
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__assertion__commutative_var_ordering_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	r2 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__assertion__commutative_var_ordering_2_6_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_goal__generic_call_0_0);
Declare_entry(mercury____Unify___prog_data__pragma_c_code_attributes_0_0);

BEGIN_MODULE(assertion_module6)
	init_entry(mercury__assertion__equal_goals_4_0);
	init_label(mercury__assertion__equal_goals_4_0_i1024);
	init_label(mercury__assertion__equal_goals_4_0_i4);
	init_label(mercury__assertion__equal_goals_4_0_i8);
	init_label(mercury__assertion__equal_goals_4_0_i10);
	init_label(mercury__assertion__equal_goals_4_0_i14);
	init_label(mercury__assertion__equal_goals_4_0_i16);
	init_label(mercury__assertion__equal_goals_4_0_i20);
	init_label(mercury__assertion__equal_goals_4_0_i21);
	init_label(mercury__assertion__equal_goals_4_0_i23);
	init_label(mercury__assertion__equal_goals_4_0_i27);
	init_label(mercury__assertion__equal_goals_4_0_i29);
	init_label(mercury__assertion__equal_goals_4_0_i33);
	init_label(mercury__assertion__equal_goals_4_0_i37);
	init_label(mercury__assertion__equal_goals_4_0_i41);
	init_label(mercury__assertion__equal_goals_4_0_i43);
	init_label(mercury__assertion__equal_goals_4_0_i47);
	init_label(mercury__assertion__equal_goals_4_0_i49);
	init_label(mercury__assertion__equal_goals_4_0_i51);
	init_label(mercury__assertion__equal_goals_4_0_i53);
	init_label(mercury__assertion__equal_goals_4_0_i57);
	init_label(mercury__assertion__equal_goals_4_0_i59);
	init_label(mercury__assertion__equal_goals_4_0_i61);
	init_label(mercury__assertion__equal_goals_4_0_i65);
	init_label(mercury__assertion__equal_goals_4_0_i69);
	init_label(mercury__assertion__equal_goals_4_0_i71);
	init_label(mercury__assertion__equal_goals_4_0_i1);
BEGIN_CODE

/* code for predicate 'equal_goals'/4 in mode 0 */
Define_static(mercury__assertion__equal_goals_4_0);
	MR_incr_sp_push_msg(7, "assertion:equal_goals/4");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__assertion__equal_goals_4_0_i1024);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__assertion__equal_goals_4_0_i4) AND
		LABEL(mercury__assertion__equal_goals_4_0_i8) AND
		LABEL(mercury__assertion__equal_goals_4_0_i14) AND
		LABEL(mercury__assertion__equal_goals_4_0_i20));
Define_label(mercury__assertion__equal_goals_4_0_i4);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_goals_list_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__assertion__equal_goals_4_0_i10,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_vars_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i14);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r4, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_goal__generic_call_0_0),
		mercury__assertion__equal_goals_4_0_i16,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i16);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_vars_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i20);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r4, (Integer) 0),
		LABEL(mercury__assertion__equal_goals_4_0_i21) AND
		LABEL(mercury__assertion__equal_goals_4_0_i27) AND
		LABEL(mercury__assertion__equal_goals_4_0_i33) AND
		LABEL(mercury__assertion__equal_goals_4_0_i37) AND
		LABEL(mercury__assertion__equal_goals_4_0_i41) AND
		LABEL(mercury__assertion__equal_goals_4_0_i47) AND
		LABEL(mercury__assertion__equal_goals_4_0_i57) AND
		LABEL(mercury__assertion__equal_goals_4_0_i65) AND
		LABEL(mercury__assertion__equal_goals_4_0_i69));
Define_label(mercury__assertion__equal_goals_4_0_i21);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	MR_stackvar(1) = r3;
	r2 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__equal_goals_4_0_i23,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i23);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(5)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_goals_cases_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i27);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__assertion__equal_goals_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r5 = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__assertion__equal_goals_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__assertion__equal_vars_4_0),
		mercury__assertion__equal_goals_4_0_i29,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i29);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_unification_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i33);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_goals_list_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i37);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1024);
	}
Define_label(mercury__assertion__equal_goals_4_0_i41);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	call_localret(STATIC(mercury__assertion__equal_vars_4_0),
		mercury__assertion__equal_goals_4_0_i43,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i43);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1024);
Define_label(mercury__assertion__equal_goals_4_0_i47);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r4, (Integer) 4);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	call_localret(STATIC(mercury__assertion__equal_vars_4_0),
		mercury__assertion__equal_goals_4_0_i49,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i49);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(4);
	localcall(mercury__assertion__equal_goals_4_0,
		LABEL(mercury__assertion__equal_goals_4_0_i51),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i51);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(2);
	r3 = r2;
	r2 = MR_stackvar(5);
	localcall(mercury__assertion__equal_goals_4_0,
		LABEL(mercury__assertion__equal_goals_4_0_i53),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i53);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(3);
	r3 = r2;
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1024);
Define_label(mercury__assertion__equal_goals_4_0_i57);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r4, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___prog_data__pragma_c_code_attributes_0_0),
		mercury__assertion__equal_goals_4_0_i59,
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i59);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__assertion__equal_goals_4_0_i61,
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i61);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_vars_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
Define_label(mercury__assertion__equal_goals_4_0_i65);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__assertion__equal_goals_list_4_0),
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i69);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	localcall(mercury__assertion__equal_goals_4_0,
		LABEL(mercury__assertion__equal_goals_4_0_i71),
		STATIC(mercury__assertion__equal_goals_4_0));
	}
Define_label(mercury__assertion__equal_goals_4_0_i71);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__assertion__equal_goals_4_0_i1024);
Define_label(mercury__assertion__equal_goals_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__map__insert_4_0);

BEGIN_MODULE(assertion_module7)
	init_entry(mercury__assertion__equal_vars_4_0);
	init_label(mercury__assertion__equal_vars_4_0_i1006);
	init_label(mercury__assertion__equal_vars_4_0_i3);
	init_label(mercury__assertion__equal_vars_4_0_i7);
	init_label(mercury__assertion__equal_vars_4_0_i9);
	init_label(mercury__assertion__equal_vars_4_0_i6);
	init_label(mercury__assertion__equal_vars_4_0_i13);
	init_label(mercury__assertion__equal_vars_4_0_i1);
BEGIN_CODE

/* code for predicate 'equal_vars'/4 in mode 0 */
Define_static(mercury__assertion__equal_vars_4_0);
	MR_incr_sp_push_msg(6, "assertion:equal_vars/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__assertion__equal_vars_4_0_i1006);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1);
	r2 = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__equal_vars_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__assertion__equal_vars_4_0_i7,
		STATIC(mercury__assertion__equal_vars_4_0));
Define_label(mercury__assertion__equal_vars_4_0_i7);
	update_prof_current_proc(LABEL(mercury__assertion__equal_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i6);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__assertion__equal_vars_4_0_i9,
		STATIC(mercury__assertion__equal_vars_4_0));
Define_label(mercury__assertion__equal_vars_4_0_i9);
	update_prof_current_proc(LABEL(mercury__assertion__equal_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1006);
Define_label(mercury__assertion__equal_vars_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__assertion__equal_vars_4_0_i13,
		STATIC(mercury__assertion__equal_vars_4_0));
Define_label(mercury__assertion__equal_vars_4_0_i13);
	update_prof_current_proc(LABEL(mercury__assertion__equal_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1);
	r1 = MR_stackvar(3);
	r3 = r2;
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__equal_vars_4_0_i1006);
Define_label(mercury__assertion__equal_vars_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);

BEGIN_MODULE(assertion_module8)
	init_entry(mercury__assertion__equal_unification_4_0);
	init_label(mercury__assertion__equal_unification_4_0_i10);
	init_label(mercury__assertion__equal_unification_4_0_i12);
	init_label(mercury__assertion__equal_unification_4_0_i14);
	init_label(mercury__assertion__equal_unification_4_0_i16);
	init_label(mercury__assertion__equal_unification_4_0_i4);
	init_label(mercury__assertion__equal_unification_4_0_i6);
	init_label(mercury__assertion__equal_unification_4_0_i1017);
	init_label(mercury__assertion__equal_unification_4_0_i1);
BEGIN_CODE

/* code for predicate 'equal_unification'/4 in mode 0 */
Define_static(mercury__assertion__equal_unification_4_0);
	MR_incr_sp_push_msg(10, "assertion:equal_unification/4");
	MR_stackvar(10) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i10);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1017);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__assertion__equal_unification_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__assertion__equal_unification_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__assertion__equal_vars_4_0),
		STATIC(mercury__assertion__equal_unification_4_0));
	}
Define_label(mercury__assertion__equal_unification_4_0_i10);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	if ((MR_const_field(MR_mktag(2), r1, (Integer) 0) != MR_const_field(MR_mktag(2), r2, (Integer) 0)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	if ((MR_const_field(MR_mktag(2), r1, (Integer) 1) != MR_const_field(MR_mktag(2), r2, (Integer) 1)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	if ((MR_const_field(MR_mktag(2), r1, (Integer) 2) != MR_const_field(MR_mktag(2), r2, (Integer) 2)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r2, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r2, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r2, (Integer) 7);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 5);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r1, (Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 7);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__assertion__equal_unification_4_0_i12,
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i12);
	update_prof_current_proc(LABEL(mercury__assertion__equal_unification_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	if ((MR_stackvar(4) != MR_stackvar(9)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__assertion__equal_vars_4_0),
		mercury__assertion__equal_unification_4_0_i14,
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i14);
	update_prof_current_proc(LABEL(mercury__assertion__equal_unification_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	r1 = MR_stackvar(3);
	r3 = r2;
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__assertion__equal_vars_4_0),
		mercury__assertion__equal_unification_4_0_i16,
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i16);
	update_prof_current_proc(LABEL(mercury__assertion__equal_unification_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	r1 = MR_stackvar(5);
	r3 = r2;
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__assertion__equal_goals_4_0),
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__assertion__equal_unification_4_0_i6,
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__equal_unification_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_unification_4_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(STATIC(mercury__assertion__equal_vars_4_0),
		STATIC(mercury__assertion__equal_unification_4_0));
Define_label(mercury__assertion__equal_unification_4_0_i1017);
	r1 = FALSE;
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__assertion__equal_unification_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module9)
	init_entry(mercury__assertion__equal_goals_list_4_0);
	init_label(mercury__assertion__equal_goals_list_4_0_i1004);
	init_label(mercury__assertion__equal_goals_list_4_0_i3);
	init_label(mercury__assertion__equal_goals_list_4_0_i6);
	init_label(mercury__assertion__equal_goals_list_4_0_i1);
BEGIN_CODE

/* code for predicate 'equal_goals_list'/4 in mode 0 */
Define_static(mercury__assertion__equal_goals_list_4_0);
	MR_incr_sp_push_msg(3, "assertion:equal_goals_list/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__assertion__equal_goals_list_4_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_list_4_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_list_4_0_i1);
	r2 = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__assertion__equal_goals_list_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_list_4_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(STATIC(mercury__assertion__equal_goals_4_0),
		mercury__assertion__equal_goals_list_4_0_i6,
		STATIC(mercury__assertion__equal_goals_list_4_0));
Define_label(mercury__assertion__equal_goals_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_list_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_list_4_0_i1);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__assertion__equal_goals_list_4_0_i1004);
Define_label(mercury__assertion__equal_goals_list_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module10)
	init_entry(mercury__assertion__equal_goals_cases_4_0);
	init_label(mercury__assertion__equal_goals_cases_4_0_i1005);
	init_label(mercury__assertion__equal_goals_cases_4_0_i3);
	init_label(mercury__assertion__equal_goals_cases_4_0_i6);
	init_label(mercury__assertion__equal_goals_cases_4_0_i8);
	init_label(mercury__assertion__equal_goals_cases_4_0_i1);
BEGIN_CODE

/* code for predicate 'equal_goals_cases'/4 in mode 0 */
Define_static(mercury__assertion__equal_goals_cases_4_0);
	MR_incr_sp_push_msg(6, "assertion:equal_goals_cases/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__assertion__equal_goals_cases_4_0_i1005);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i1);
	r2 = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__equal_goals_cases_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__assertion__equal_goals_cases_4_0_i6,
		STATIC(mercury__assertion__equal_goals_cases_4_0));
	}
Define_label(mercury__assertion__equal_goals_cases_4_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_cases_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__assertion__equal_goals_4_0),
		mercury__assertion__equal_goals_cases_4_0_i8,
		STATIC(mercury__assertion__equal_goals_cases_4_0));
Define_label(mercury__assertion__equal_goals_cases_4_0_i8);
	update_prof_current_proc(LABEL(mercury__assertion__equal_goals_cases_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i1);
	r1 = MR_stackvar(2);
	r3 = r2;
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__assertion__equal_goals_cases_4_0_i1005);
Define_label(mercury__assertion__equal_goals_cases_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_get_assertions_2_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__hlds_pred__pred_info_set_assertions_3_0);
Declare_entry(mercury__hlds_module__module_info_set_pred_info_4_0);

BEGIN_MODULE(assertion_module11)
	init_entry(mercury__assertion__update_pred_info_4_0);
	init_label(mercury__assertion__update_pred_info_4_0_i2);
	init_label(mercury__assertion__update_pred_info_4_0_i3);
	init_label(mercury__assertion__update_pred_info_4_0_i4);
	init_label(mercury__assertion__update_pred_info_4_0_i5);
BEGIN_CODE

/* code for predicate 'update_pred_info'/4 in mode 0 */
Define_static(mercury__assertion__update_pred_info_4_0);
	MR_incr_sp_push_msg(5, "assertion:update_pred_info/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__assertion__update_pred_info_4_0_i2,
		STATIC(mercury__assertion__update_pred_info_4_0));
Define_label(mercury__assertion__update_pred_info_4_0_i2);
	update_prof_current_proc(LABEL(mercury__assertion__update_pred_info_4_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_assertions_2_0),
		mercury__assertion__update_pred_info_4_0_i3,
		STATIC(mercury__assertion__update_pred_info_4_0));
Define_label(mercury__assertion__update_pred_info_4_0_i3);
	update_prof_current_proc(LABEL(mercury__assertion__update_pred_info_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_assert_id_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__assertion__update_pred_info_4_0_i4,
		STATIC(mercury__assertion__update_pred_info_4_0));
Define_label(mercury__assertion__update_pred_info_4_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__update_pred_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_assertions_3_0),
		mercury__assertion__update_pred_info_4_0_i5,
		STATIC(mercury__assertion__update_pred_info_4_0));
Define_label(mercury__assertion__update_pred_info_4_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__update_pred_info_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_pred_info_4_0),
		STATIC(mercury__assertion__update_pred_info_4_0));
END_MODULE


BEGIN_MODULE(assertion_module12)
	init_entry(mercury__assertion__normalise_goal_2_0);
	init_label(mercury__assertion__normalise_goal_2_0_i4);
	init_label(mercury__assertion__normalise_goal_2_0_i5);
	init_label(mercury__assertion__normalise_goal_2_0_i8);
	init_label(mercury__assertion__normalise_goal_2_0_i9);
	init_label(mercury__assertion__normalise_goal_2_0_i10);
	init_label(mercury__assertion__normalise_goal_2_0_i12);
	init_label(mercury__assertion__normalise_goal_2_0_i13);
	init_label(mercury__assertion__normalise_goal_2_0_i14);
	init_label(mercury__assertion__normalise_goal_2_0_i15);
	init_label(mercury__assertion__normalise_goal_2_0_i16);
	init_label(mercury__assertion__normalise_goal_2_0_i17);
	init_label(mercury__assertion__normalise_goal_2_0_i18);
	init_label(mercury__assertion__normalise_goal_2_0_i19);
	init_label(mercury__assertion__normalise_goal_2_0_i20);
	init_label(mercury__assertion__normalise_goal_2_0_i21);
	init_label(mercury__assertion__normalise_goal_2_0_i23);
	init_label(mercury__assertion__normalise_goal_2_0_i24);
	init_label(mercury__assertion__normalise_goal_2_0_i25);
	init_label(mercury__assertion__normalise_goal_2_0_i26);
	init_label(mercury__assertion__normalise_goal_2_0_i27);
	init_label(mercury__assertion__normalise_goal_2_0_i1018);
	init_label(mercury__assertion__normalise_goal_2_0_i2);
BEGIN_CODE

/* code for predicate 'normalise_goal'/2 in mode 0 */
Define_static(mercury__assertion__normalise_goal_2_0);
	MR_incr_sp_push_msg(6, "assertion:normalise_goal/2");
	MR_stackvar(6) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__assertion__normalise_goal_2_0_i4) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i1018) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i1018) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i8));
Define_label(mercury__assertion__normalise_goal_2_0_i4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__assertion__normalise_conj_2_0),
		mercury__assertion__normalise_goal_2_0_i5,
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__assertion__normalise_goal_2_0_i9) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i2) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i12) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i14) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i16) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i18) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i2) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i23) AND
		LABEL(mercury__assertion__normalise_goal_2_0_i25));
Define_label(mercury__assertion__normalise_goal_2_0_i9);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(STATIC(mercury__assertion__normalise_cases_2_0),
		mercury__assertion__normalise_goal_2_0_i10,
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 5, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 3) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 4) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i12);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	call_localret(STATIC(mercury__assertion__normalise_goals_2_0),
		mercury__assertion__normalise_goal_2_0_i13,
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i13);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i14);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i15),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i15);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i16);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i17),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i17);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i18);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r2, (Integer) 5);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i19),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i19);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i20),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i20);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i21),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i21);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 6, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r3, (Integer) 4) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i23);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	call_localret(STATIC(mercury__assertion__normalise_goals_2_0),
		mercury__assertion__normalise_goal_2_0_i24,
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i24);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i25);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i26),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i26);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__assertion__normalise_goal_2_0,
		LABEL(mercury__assertion__normalise_goal_2_0_i27),
		STATIC(mercury__assertion__normalise_goal_2_0));
Define_label(mercury__assertion__normalise_goal_2_0_i27);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goal_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_goal_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__assertion__normalise_goal_2_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i1018);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__normalise_goal_2_0_i2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(assertion_module13)
	init_entry(mercury__assertion__normalise_conj_2_0);
	init_label(mercury__assertion__normalise_conj_2_0_i4);
	init_label(mercury__assertion__normalise_conj_2_0_i5);
	init_label(mercury__assertion__normalise_conj_2_0_i3);
BEGIN_CODE

/* code for predicate 'normalise_conj'/2 in mode 0 */
Define_static(mercury__assertion__normalise_conj_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__normalise_conj_2_0_i3);
	MR_incr_sp_push_msg(2, "assertion:normalise_conj/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__assertion__normalise_conj_2_0_i4,
		STATIC(mercury__assertion__normalise_conj_2_0));
Define_label(mercury__assertion__normalise_conj_2_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_conj_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__assertion__normalise_conj_2_0,
		LABEL(mercury__assertion__normalise_conj_2_0_i5),
		STATIC(mercury__assertion__normalise_conj_2_0));
Define_label(mercury__assertion__normalise_conj_2_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_conj_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_0);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__assertion__normalise_conj_2_0));
Define_label(mercury__assertion__normalise_conj_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module14)
	init_entry(mercury__assertion__normalise_cases_2_0);
	init_label(mercury__assertion__normalise_cases_2_0_i4);
	init_label(mercury__assertion__normalise_cases_2_0_i5);
	init_label(mercury__assertion__normalise_cases_2_0_i3);
BEGIN_CODE

/* code for predicate 'normalise_cases'/2 in mode 0 */
Define_static(mercury__assertion__normalise_cases_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__normalise_cases_2_0_i3);
	MR_incr_sp_push_msg(3, "assertion:normalise_cases/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__assertion__normalise_goal_2_0),
		mercury__assertion__normalise_cases_2_0_i4,
		STATIC(mercury__assertion__normalise_cases_2_0));
Define_label(mercury__assertion__normalise_cases_2_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_cases_2_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__assertion__normalise_cases_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__assertion__normalise_cases_2_0,
		LABEL(mercury__assertion__normalise_cases_2_0_i5),
		STATIC(mercury__assertion__normalise_cases_2_0));
Define_label(mercury__assertion__normalise_cases_2_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_cases_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__assertion__normalise_cases_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__assertion__normalise_cases_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module15)
	init_entry(mercury__assertion__normalise_goals_2_0);
	init_label(mercury__assertion__normalise_goals_2_0_i4);
	init_label(mercury__assertion__normalise_goals_2_0_i5);
	init_label(mercury__assertion__normalise_goals_2_0_i3);
BEGIN_CODE

/* code for predicate 'normalise_goals'/2 in mode 0 */
Define_static(mercury__assertion__normalise_goals_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__normalise_goals_2_0_i3);
	MR_incr_sp_push_msg(2, "assertion:normalise_goals/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__assertion__normalise_goal_2_0),
		mercury__assertion__normalise_goals_2_0_i4,
		STATIC(mercury__assertion__normalise_goals_2_0));
Define_label(mercury__assertion__normalise_goals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goals_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__assertion__normalise_goals_2_0,
		LABEL(mercury__assertion__normalise_goals_2_0_i5),
		STATIC(mercury__assertion__normalise_goals_2_0));
Define_label(mercury__assertion__normalise_goals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__normalise_goals_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__assertion__normalise_goals_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__assertion__normalise_goals_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__clauses_info_vartypes_2_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__hlds_data__get_type_defn_status_2_0);

BEGIN_MODULE(assertion_module16)
	init_entry(mercury__assertion__in_interface_check_unify_rhs_8_0);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1012);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i4);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i5);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i6);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i7);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i10);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i12);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i13);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i14);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i18);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i28);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i16);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i29);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1013);
	init_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i9);
BEGIN_CODE

/* code for predicate 'in_interface_check_unify_rhs'/8 in mode 0 */
Define_static(mercury__assertion__in_interface_check_unify_rhs_8_0);
	MR_incr_sp_push_msg(6, "assertion:in_interface_check_unify_rhs/8");
	MR_stackvar(6) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i1012);
	r1 = r5;
	r2 = r6;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1012);
	r2 = r4;
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 7);
	r3 = r5;
	r4 = r6;
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__in_interface_check_6_0),
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i4);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i5,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_vartypes_2_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i6,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i7,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i7);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i10,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i10);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i9);
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i12,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i12);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_8);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i13,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i13);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_status_2_0),
		mercury__assertion__in_interface_check_unify_rhs_8_0_i14,
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i14);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0));
	r2 = MR_tag(r1);
	if ((r2 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i18);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004) AND
		LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i18);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i28);
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1004);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r2 = (Integer) 1;
	GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i16);
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i28);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r2 = (Integer) 0;
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i16);
	if (((Integer) 1 == (Integer) r2))
		GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i29);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	GOTO_LABEL(mercury__assertion__in_interface_check_unify_rhs_8_0_i1013);
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i29);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__assertion__in_interface_check_unify_rhs_8_0, "assertion:call_or_consid/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__assertion__write_assertion_interface_error_6_0),
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i1013);
	r1 = r3;
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__assertion__in_interface_check_unify_rhs_8_0_i9);
	r1 = (Word) MR_string_const("assertion__in_interface_check_unify_rhs: type_to_type_id failed.", 64);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__assertion__in_interface_check_unify_rhs_8_0));
END_MODULE


BEGIN_MODULE(assertion_module17)
	init_entry(mercury__assertion__in_interface_check_list_6_0);
	init_label(mercury__assertion__in_interface_check_list_6_0_i1001);
	init_label(mercury__assertion__in_interface_check_list_6_0_i4);
	init_label(mercury__assertion__in_interface_check_list_6_0_i3);
BEGIN_CODE

/* code for predicate 'in_interface_check_list'/6 in mode 0 */
Define_static(mercury__assertion__in_interface_check_list_6_0);
	MR_incr_sp_push_msg(3, "assertion:in_interface_check_list/6");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__assertion__in_interface_check_list_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__assertion__in_interface_check_list_6_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__assertion__in_interface_check_6_0),
		mercury__assertion__in_interface_check_list_6_0_i4,
		STATIC(mercury__assertion__in_interface_check_list_6_0));
Define_label(mercury__assertion__in_interface_check_list_6_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__in_interface_check_list_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__assertion__in_interface_check_list_6_0_i1001);
Define_label(mercury__assertion__in_interface_check_list_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module18)
	init_entry(mercury__assertion__is_defined_in_implementation_section_2_0);
	init_label(mercury__assertion__is_defined_in_implementation_section_2_0_i4);
	init_label(mercury__assertion__is_defined_in_implementation_section_2_0_i1001);
	init_label(mercury__assertion__is_defined_in_implementation_section_2_0_i14);
BEGIN_CODE

/* code for predicate 'is_defined_in_implementation_section'/2 in mode 0 */
Define_static(mercury__assertion__is_defined_in_implementation_section_2_0);
	r2 = MR_tag(r1);
	if ((r2 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i1001) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i1001) AND
		LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i1001));
Define_label(mercury__assertion__is_defined_in_implementation_section_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__assertion__is_defined_in_implementation_section_2_0_i14);
Define_label(mercury__assertion__is_defined_in_implementation_section_2_0_i1001);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury__assertion__is_defined_in_implementation_section_2_0_i14);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_incr_errors_2_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__prog_out__write_context_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__prog_out__write_sym_name_3_0);
Declare_entry(mercury__hlds_out__write_simple_call_id_5_0);
Declare_entry(mercury__io__nl_2_0);
Declare_entry(mercury__hlds_out__write_cons_id_3_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);

BEGIN_MODULE(assertion_module19)
	init_entry(mercury__assertion__write_assertion_interface_error_6_0);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i2);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i3);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i4);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i5);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i6);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i7);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i8);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i9);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i12);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i11);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i14);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i15);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i16);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i17);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i18);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i19);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i20);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i21);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i22);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i25);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i26);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i27);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i28);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i29);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i30);
	init_label(mercury__assertion__write_assertion_interface_error_6_0_i23);
BEGIN_CODE

/* code for predicate 'write_assertion_interface_error'/6 in mode 0 */
Define_static(mercury__assertion__write_assertion_interface_error_6_0);
	MR_incr_sp_push_msg(5, "assertion:write_assertion_interface_error/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_incr_errors_2_0),
		mercury__assertion__write_assertion_interface_error_6_0_i2,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i2);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__assertion__write_assertion_interface_error_6_0_i3,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i3);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i4,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i4);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In interface for module `", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i5,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i5);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__prog_out__write_sym_name_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i6,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i6);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("':\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i7,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i7);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i8,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i8);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  error: exported promise refers to ", 36);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i9,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i9);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__assertion__write_assertion_interface_error_6_0_i11);
	r4 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_out__write_simple_call_id_5_0),
		mercury__assertion__write_assertion_interface_error_6_0_i12,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
	}
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i12);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__assertion__write_assertion_interface_error_6_0_i16,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i11);
	r2 = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r1 = (Word) MR_string_const("constructor `", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i14,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i14);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_cons_id_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i15,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i15);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i16,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i16);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i17,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i17);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  which is defined in the implementation ", 41);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i18,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i18);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("of module `", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i19,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i19);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__prog_out__write_sym_name_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i20,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i20);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'.\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i21,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i21);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Integer) 19;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__assertion__write_assertion_interface_error_6_0_i22,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i22);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__assertion__write_assertion_interface_error_6_0_i23);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i25,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i25);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  Either move the promise into the ", 35);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i26,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i26);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("implementation section\n", 23);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i27,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i27);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i28,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i28);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  or move the definition ", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i29,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i29);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("into the interface.\n", 20);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__assertion__write_assertion_interface_error_6_0_i30,
		STATIC(mercury__assertion__write_assertion_interface_error_6_0));
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i30);
	update_prof_current_proc(LABEL(mercury__assertion__write_assertion_interface_error_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__assertion__write_assertion_interface_error_6_0_i23);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(assertion_module20)
	init_entry(mercury____Unify___assertion__subst_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___assertion__subst_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___assertion__subst_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(assertion_module21)
	init_entry(mercury____Index___assertion__subst_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___assertion__subst_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___assertion__subst_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(assertion_module22)
	init_entry(mercury____Compare___assertion__subst_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___assertion__subst_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_assertion__common_6);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___assertion__subst_0_0));
END_MODULE

Declare_entry(mercury____Unify___prog_data__sym_name_0_0);

BEGIN_MODULE(assertion_module23)
	init_entry(mercury____Unify___assertion__call_or_consid_0_0);
	init_label(mercury____Unify___assertion__call_or_consid_0_0_i5);
	init_label(mercury____Unify___assertion__call_or_consid_0_0_i1007);
	init_label(mercury____Unify___assertion__call_or_consid_0_0_i1009);
	init_label(mercury____Unify___assertion__call_or_consid_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___assertion__call_or_consid_0_0);
	MR_incr_sp_push_msg(3, "assertion:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1007);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1009);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != r3))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1009);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___assertion__call_or_consid_0_0_i5,
		STATIC(mercury____Unify___assertion__call_or_consid_0_0));
Define_label(mercury____Unify___assertion__call_or_consid_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___assertion__call_or_consid_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___assertion__call_or_consid_0_0_i1007);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___assertion__call_or_consid_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		STATIC(mercury____Unify___assertion__call_or_consid_0_0));
Define_label(mercury____Unify___assertion__call_or_consid_0_0_i1009);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___assertion__call_or_consid_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(assertion_module24)
	init_entry(mercury____Index___assertion__call_or_consid_0_0);
	init_label(mercury____Index___assertion__call_or_consid_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___assertion__call_or_consid_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___assertion__call_or_consid_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___assertion__call_or_consid_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(assertion_module25)
	init_entry(mercury____Compare___assertion__call_or_consid_0_0);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i3);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i2);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i5);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i4);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i6);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i7);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i14);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i18);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i11);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i1016);
	init_label(mercury____Compare___assertion__call_or_consid_0_0_i29);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___assertion__call_or_consid_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i2);
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i4);
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i1016);
	MR_incr_sp_push_msg(5, "assertion:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___assertion__call_or_consid_0_0_i14,
		STATIC(mercury____Compare___assertion__call_or_consid_0_0));
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___assertion__call_or_consid_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i29);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___assertion__call_or_consid_0_0_i18,
		STATIC(mercury____Compare___assertion__call_or_consid_0_0));
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Compare___assertion__call_or_consid_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i29);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___assertion__call_or_consid_0_0));
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___assertion__call_or_consid_0_0_i1016);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		STATIC(mercury____Compare___assertion__call_or_consid_0_0));
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i1016);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___assertion__call_or_consid_0_0));
Define_label(mercury____Compare___assertion__call_or_consid_0_0_i29);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__assertion_maybe_bunch_0(void)
{
	assertion_module0();
	assertion_module1();
	assertion_module2();
	assertion_module3();
	assertion_module4();
	assertion_module5();
	assertion_module6();
	assertion_module7();
	assertion_module8();
	assertion_module9();
	assertion_module10();
	assertion_module11();
	assertion_module12();
	assertion_module13();
	assertion_module14();
	assertion_module15();
	assertion_module16();
	assertion_module17();
	assertion_module18();
	assertion_module19();
	assertion_module20();
	assertion_module21();
	assertion_module22();
	assertion_module23();
	assertion_module24();
	assertion_module25();
}

#endif

void mercury__assertion__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__assertion__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__assertion_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_assertion__type_ctor_info_call_or_consid_0,
			assertion__call_or_consid_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_assertion__type_ctor_info_subst_0,
			assertion__subst_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
