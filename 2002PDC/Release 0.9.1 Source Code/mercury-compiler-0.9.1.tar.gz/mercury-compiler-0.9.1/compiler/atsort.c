/*
** Automatically generated from `atsort.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__atsort__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__atsort__main__ua0_7_0);
Declare_label(mercury__atsort__main__ua0_7_0_i2);
Declare_label(mercury__atsort__main__ua0_7_0_i5);
Declare_label(mercury__atsort__main__ua0_7_0_i3);
Declare_label(mercury__atsort__main__ua0_7_0_i7);
Declare_label(mercury__atsort__main__ua0_7_0_i8);
Declare_label(mercury__atsort__main__ua0_7_0_i9);
Declare_label(mercury__atsort__main__ua0_7_0_i10);
Declare_label(mercury__atsort__main__ua0_7_0_i11);
Declare_label(mercury__atsort__main__ua0_7_0_i12);
Declare_label(mercury__atsort__main__ua0_7_0_i13);
Declare_label(mercury__atsort__main__ua0_7_0_i14);
Declare_label(mercury__atsort__main__ua0_7_0_i15);
Declare_label(mercury__atsort__main__ua0_7_0_i16);
Declare_label(mercury__atsort__main__ua0_7_0_i17);
Declare_static(mercury__atsort__atsort__ua0_6_0);
Declare_label(mercury__atsort__atsort__ua0_6_0_i2);
Declare_label(mercury__atsort__atsort__ua0_6_0_i3);
Declare_label(mercury__atsort__atsort__ua0_6_0_i6);
Declare_label(mercury__atsort__atsort__ua0_6_0_i5);
Declare_label(mercury__atsort__atsort__ua0_6_0_i8);
Declare_static(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i1001);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i4);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i5);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i3);
Declare_static(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i1001);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i4);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i5);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i6);
Declare_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i3);
Define_extern_entry(mercury__atsort__atsort_6_0);
Define_extern_entry(mercury__atsort__closure_3_0);
Declare_static(mercury__atsort__can_choose_5_0);
Declare_label(mercury__atsort__can_choose_5_0_i1005);
Declare_label(mercury__atsort__can_choose_5_0_i5);
Declare_label(mercury__atsort__can_choose_5_0_i9);
Declare_label(mercury__atsort__can_choose_5_0_i1002);
Declare_label(mercury__atsort__can_choose_5_0_i8);
Declare_label(mercury__atsort__can_choose_5_0_i3);
Declare_static(mercury__atsort__must_avoid_2_0);
Declare_label(mercury__atsort__must_avoid_2_0_i1002);
Declare_label(mercury__atsort__must_avoid_2_0_i6);
Declare_label(mercury__atsort__must_avoid_2_0_i2);
Declare_label(mercury__atsort__must_avoid_2_0_i1);
Declare_static(mercury__atsort__choose_pref_3_0);
Declare_label(mercury__atsort__choose_pref_3_0_i1002);
Declare_label(mercury__atsort__choose_pref_3_0_i3);
Declare_label(mercury__atsort__choose_pref_3_0_i7);
Declare_label(mercury__atsort__choose_pref_3_0_i5);
Declare_static(mercury__atsort__repeat_source_sink_10_0);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i1004);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i2);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i3);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i6);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i7);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i8);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i9);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i10);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i11);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i12);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i14);
Declare_label(mercury__atsort__repeat_source_sink_10_0_i17);
Declare_static(mercury__atsort__source_sink_9_0);
Declare_label(mercury__atsort__source_sink_9_0_i1005);
Declare_label(mercury__atsort__source_sink_9_0_i5);
Declare_label(mercury__atsort__source_sink_9_0_i4);
Declare_label(mercury__atsort__source_sink_9_0_i9);
Declare_label(mercury__atsort__source_sink_9_0_i8);
Declare_label(mercury__atsort__source_sink_9_0_i3);
Declare_static(mercury__atsort__map_delete_all_sink_links_4_0);
Declare_label(mercury__atsort__map_delete_all_sink_links_4_0_i1001);
Declare_label(mercury__atsort__map_delete_all_sink_links_4_0_i4);
Declare_label(mercury__atsort__map_delete_all_sink_links_4_0_i5);
Declare_label(mercury__atsort__map_delete_all_sink_links_4_0_i3);
Declare_static(mercury__atsort__map_delete_this_element_4_0);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i1002);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i5);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i7);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i8);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i4);
Declare_label(mercury__atsort__map_delete_this_element_4_0_i3);
Declare_static(mercury__atsort__map_delete_all_nodes_3_0);
Declare_label(mercury__atsort__map_delete_all_nodes_3_0_i1001);
Declare_label(mercury__atsort__map_delete_all_nodes_3_0_i4);
Declare_label(mercury__atsort__map_delete_all_nodes_3_0_i3);
Declare_static(mercury__atsort__closure_2_4_0);
Declare_label(mercury__atsort__closure_2_4_0_i1002);
Declare_label(mercury__atsort__closure_2_4_0_i6);
Declare_label(mercury__atsort__closure_2_4_0_i4);
Declare_label(mercury__atsort__closure_2_4_0_i8);
Declare_label(mercury__atsort__closure_2_4_0_i9);
Declare_label(mercury__atsort__closure_2_4_0_i3);
Declare_static(mercury__atsort__maybe_insert_3_0);
Declare_label(mercury__atsort__maybe_insert_3_0_i1002);
Declare_label(mercury__atsort__maybe_insert_3_0_i6);
Declare_label(mercury__atsort__maybe_insert_3_0_i4);
Declare_label(mercury__atsort__maybe_insert_3_0_i3);
Define_extern_entry(mercury____Unify___atsort__relmap_1_0);
Define_extern_entry(mercury____Index___atsort__relmap_1_0);
Define_extern_entry(mercury____Compare___atsort__relmap_1_0);

const struct MR_TypeCtorInfo_struct mercury_data_atsort__type_ctor_info_relmap_1;

static const struct mercury_data_atsort__common_0_struct {
	Word * f1;
	Integer f2;
}  mercury_data_atsort__common_0;

static const struct mercury_data_atsort__common_1_struct {
	Word * f1;
	Integer f2;
	Word * f3;
}  mercury_data_atsort__common_1;

static const struct mercury_data_atsort__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_atsort__common_2;

static const struct mercury_data_atsort__type_ctor_functors_relmap_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_atsort__type_ctor_functors_relmap_1;

static const struct mercury_data_atsort__type_ctor_layout_relmap_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_atsort__type_ctor_layout_relmap_1;

const struct MR_TypeCtorInfo_struct mercury_data_atsort__type_ctor_info_relmap_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___atsort__relmap_1_0),
	ENTRY(mercury____Index___atsort__relmap_1_0),
	ENTRY(mercury____Compare___atsort__relmap_1_0),
	(Integer) 6,
	(Word *) &mercury_data_atsort__type_ctor_functors_relmap_1,
	(Word *) &mercury_data_atsort__type_ctor_layout_relmap_1,
	MR_string_const("atsort", 6),
	MR_string_const("relmap", 6),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_atsort__common_0_struct mercury_data_atsort__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Integer) 1
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_atsort__common_1_struct mercury_data_atsort__common_1 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_atsort__common_0)
};

static const struct mercury_data_atsort__common_2_struct mercury_data_atsort__common_2 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_atsort__common_1)
};

static const struct mercury_data_atsort__type_ctor_functors_relmap_1_struct mercury_data_atsort__type_ctor_functors_relmap_1 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_atsort__common_1)
};

static const struct mercury_data_atsort__type_ctor_layout_relmap_1_struct mercury_data_atsort__type_ctor_layout_relmap_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_atsort__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_atsort__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_atsort__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_atsort__common_2)
};

Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__list__delete_all_3_1);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__map__delete_3_1);
Declare_entry(mercury__list__condense_2_0);

BEGIN_MODULE(atsort_module0)
	init_entry(mercury__atsort__main__ua0_7_0);
	init_label(mercury__atsort__main__ua0_7_0_i2);
	init_label(mercury__atsort__main__ua0_7_0_i5);
	init_label(mercury__atsort__main__ua0_7_0_i3);
	init_label(mercury__atsort__main__ua0_7_0_i7);
	init_label(mercury__atsort__main__ua0_7_0_i8);
	init_label(mercury__atsort__main__ua0_7_0_i9);
	init_label(mercury__atsort__main__ua0_7_0_i10);
	init_label(mercury__atsort__main__ua0_7_0_i11);
	init_label(mercury__atsort__main__ua0_7_0_i12);
	init_label(mercury__atsort__main__ua0_7_0_i13);
	init_label(mercury__atsort__main__ua0_7_0_i14);
	init_label(mercury__atsort__main__ua0_7_0_i15);
	init_label(mercury__atsort__main__ua0_7_0_i16);
	init_label(mercury__atsort__main__ua0_7_0_i17);
BEGIN_CODE

/* code for predicate 'main__ua0'/7 in mode 0 */
Define_static(mercury__atsort__main__ua0_7_0);
	MR_incr_sp_push_msg(10, "atsort:main__ua0/7");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r5;
	MR_stackvar(2) = r6;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(9) = r1;
	call_localret(STATIC(mercury__atsort__repeat_source_sink_10_0),
		mercury__atsort__main__ua0_7_0_i2,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i2);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__main__ua0_7_0_i3);
	MR_stackvar(7) = r5;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(9);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__atsort__main__ua0_7_0_i5,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(9);
	r3 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i3);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = r3;
	r2 = r4;
	r3 = r4;
	MR_stackvar(3) = r1;
	MR_stackvar(6) = r4;
	MR_stackvar(7) = r5;
	r1 = MR_stackvar(9);
	r4 = MR_stackvar(1);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__atsort__can_choose_5_0),
		mercury__atsort__main__ua0_7_0_i7,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i7);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r3 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__atsort__choose_pref_3_0),
		mercury__atsort__main__ua0_7_0_i8,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i8);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r3 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__atsort__main__ua0_7_0_i9,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i9);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__atsort__main__ua0_7_0_i10,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i10);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__atsort__map_delete_this_element_4_0),
		mercury__atsort__main__ua0_7_0_i11,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i11);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	r3 = r4;
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__atsort__main__ua0_7_0_i12,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i12);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__atsort__map_delete_this_element_4_0),
		mercury__atsort__main__ua0_7_0_i13,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i13);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r3 = r1;
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__main__ua0_7_0_i14,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i14);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__main__ua0_7_0_i15,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i15);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r4 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(2);
	localcall(mercury__atsort__main__ua0_7_0,
		LABEL(mercury__atsort__main__ua0_7_0_i16),
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i16);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	r2 = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__atsort__main__ua0_7_0_i17,
		STATIC(mercury__atsort__main__ua0_7_0));
Define_label(mercury__atsort__main__ua0_7_0_i17);
	update_prof_current_proc(LABEL(mercury__atsort__main__ua0_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__atsort__main__ua0_7_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(9);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__atsort__main__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__list__condense_2_0),
		STATIC(mercury__atsort__main__ua0_7_0));
END_MODULE

Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(atsort_module1)
	init_entry(mercury__atsort__atsort__ua0_6_0);
	init_label(mercury__atsort__atsort__ua0_6_0_i2);
	init_label(mercury__atsort__atsort__ua0_6_0_i3);
	init_label(mercury__atsort__atsort__ua0_6_0_i6);
	init_label(mercury__atsort__atsort__ua0_6_0_i5);
	init_label(mercury__atsort__atsort__ua0_6_0_i8);
BEGIN_CODE

/* code for predicate 'atsort__ua0'/6 in mode 0 */
Define_static(mercury__atsort__atsort__ua0_6_0);
	MR_incr_sp_push_msg(7, "atsort:atsort__ua0/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__atsort__ua0_6_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__atsort__atsort__ua0_6_0_i2,
		STATIC(mercury__atsort__atsort__ua0_6_0));
Define_label(mercury__atsort__atsort__ua0_6_0_i2);
	update_prof_current_proc(LABEL(mercury__atsort__atsort__ua0_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(6);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__atsort__ua0_6_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__atsort__atsort__ua0_6_0_i3,
		STATIC(mercury__atsort__atsort__ua0_6_0));
Define_label(mercury__atsort__atsort__ua0_6_0_i3);
	update_prof_current_proc(LABEL(mercury__atsort__atsort__ua0_6_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__atsort__atsort__ua0_6_0_i6,
		STATIC(mercury__atsort__atsort__ua0_6_0));
Define_label(mercury__atsort__atsort__ua0_6_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__atsort__ua0_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__atsort__ua0_6_0_i5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r1 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__atsort__main__ua0_7_0),
		STATIC(mercury__atsort__atsort__ua0_6_0));
Define_label(mercury__atsort__atsort__ua0_6_0_i5);
	r1 = (Word) MR_string_const("succ and pred nodelists differ in atsort", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__atsort__atsort__ua0_6_0_i8,
		STATIC(mercury__atsort__atsort__ua0_6_0));
Define_label(mercury__atsort__atsort__ua0_6_0_i8);
	update_prof_current_proc(LABEL(mercury__atsort__atsort__ua0_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__atsort__main__ua0_7_0),
		STATIC(mercury__atsort__atsort__ua0_6_0));
END_MODULE


BEGIN_MODULE(atsort_module2)
	init_entry(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i1001);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i4);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i5);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i3);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__repeat_source_sink__279__1'/6 in mode 0 */
Define_static(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0);
	MR_incr_sp_push_msg(5, "atsort:DeforestationIn__pred__repeat_source_sink__279__1/6");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = r4;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r4;
	MR_stackvar(3) = MR_tempr1;
	r1 = r4;
	r4 = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i4,
		STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0));
	}
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i4);
	update_prof_current_proc(LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0, "origin_lost_in_value_number");
	r3 = r4;
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i5,
		STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0));
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i1001);
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module3)
	init_entry(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i1001);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i4);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i5);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i6);
	init_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i3);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__repeat_source_sink__241__0'/7 in mode 0 */
Define_static(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0);
	MR_incr_sp_push_msg(7, "atsort:DeforestationIn__pred__repeat_source_sink__241__0/7");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i1001);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r4 = MR_tempr1;
	MR_stackvar(5) = MR_tempr1;
	r3 = r1;
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0, "origin_lost_in_value_number");
	r1 = r5;
	MR_stackvar(4) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i4,
		STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
	}
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i4);
	update_prof_current_proc(LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__atsort__map_delete_this_element_4_0),
		mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i5,
		STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i6,
		STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i1001);
Define_label(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0_i3);
	r1 = r2;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module4)
	init_entry(mercury__atsort__atsort_6_0);
BEGIN_CODE

/* code for predicate 'atsort'/6 in mode 0 */
Define_entry(mercury__atsort__atsort_6_0);
	r4 = r5;
	r5 = r6;
	tailcall(STATIC(mercury__atsort__atsort__ua0_6_0),
		ENTRY(mercury__atsort__atsort_6_0));
END_MODULE


BEGIN_MODULE(atsort_module5)
	init_entry(mercury__atsort__closure_3_0);
BEGIN_CODE

/* code for predicate 'closure'/3 in mode 0 */
Define_entry(mercury__atsort__closure_3_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__atsort__closure_2_4_0),
		ENTRY(mercury__atsort__closure_3_0));
END_MODULE

Declare_entry(mercury__map__search_3_1);

BEGIN_MODULE(atsort_module6)
	init_entry(mercury__atsort__can_choose_5_0);
	init_label(mercury__atsort__can_choose_5_0_i1005);
	init_label(mercury__atsort__can_choose_5_0_i5);
	init_label(mercury__atsort__can_choose_5_0_i9);
	init_label(mercury__atsort__can_choose_5_0_i1002);
	init_label(mercury__atsort__can_choose_5_0_i8);
	init_label(mercury__atsort__can_choose_5_0_i3);
BEGIN_CODE

/* code for predicate 'can_choose'/5 in mode 0 */
Define_static(mercury__atsort__can_choose_5_0);
	MR_incr_sp_push_msg(7, "atsort:can_choose/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__atsort__can_choose_5_0_i1005);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__can_choose_5_0_i3);
	MR_stackvar(1) = r3;
	r3 = r4;
	MR_stackvar(2) = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__can_choose_5_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r5;
	MR_stackvar(6) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__atsort__can_choose_5_0_i5,
		STATIC(mercury__atsort__can_choose_5_0));
Define_label(mercury__atsort__can_choose_5_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__can_choose_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__can_choose_5_0_i1002);
	r1 = MR_stackvar(6);
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__atsort__must_avoid_2_0),
		mercury__atsort__can_choose_5_0_i9,
		STATIC(mercury__atsort__can_choose_5_0));
Define_label(mercury__atsort__can_choose_5_0_i9);
	update_prof_current_proc(LABEL(mercury__atsort__can_choose_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__can_choose_5_0_i8);
Define_label(mercury__atsort__can_choose_5_0_i1002);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__atsort__can_choose_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(3);
	r1 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__atsort__can_choose_5_0_i1005);
Define_label(mercury__atsort__can_choose_5_0_i8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r5 = MR_stackvar(3);
	r1 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__atsort__can_choose_5_0_i1005);
Define_label(mercury__atsort__can_choose_5_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_0);

BEGIN_MODULE(atsort_module7)
	init_entry(mercury__atsort__must_avoid_2_0);
	init_label(mercury__atsort__must_avoid_2_0_i1002);
	init_label(mercury__atsort__must_avoid_2_0_i6);
	init_label(mercury__atsort__must_avoid_2_0_i2);
	init_label(mercury__atsort__must_avoid_2_0_i1);
BEGIN_CODE

/* code for predicate 'must_avoid'/2 in mode 0 */
Define_static(mercury__atsort__must_avoid_2_0);
	MR_incr_sp_push_msg(4, "atsort:must_avoid/2");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__atsort__must_avoid_2_0_i1002);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__must_avoid_2_0_i2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__atsort__must_avoid_2_0_i6,
		STATIC(mercury__atsort__must_avoid_2_0));
Define_label(mercury__atsort__must_avoid_2_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__must_avoid_2_0));
	if (r1)
		GOTO_LABEL(mercury__atsort__must_avoid_2_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__atsort__must_avoid_2_0_i1002);
Define_label(mercury__atsort__must_avoid_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__atsort__must_avoid_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module8)
	init_entry(mercury__atsort__choose_pref_3_0);
	init_label(mercury__atsort__choose_pref_3_0_i1002);
	init_label(mercury__atsort__choose_pref_3_0_i3);
	init_label(mercury__atsort__choose_pref_3_0_i7);
	init_label(mercury__atsort__choose_pref_3_0_i5);
BEGIN_CODE

/* code for predicate 'choose_pref'/3 in mode 0 */
Define_static(mercury__atsort__choose_pref_3_0);
	MR_incr_sp_push_msg(5, "atsort:choose_pref/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__atsort__choose_pref_3_0_i1002);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__choose_pref_3_0_i3);
	r1 = (Word) MR_string_const("cannot choose any node in atsort", 32);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__atsort__choose_pref_3_0));
Define_label(mercury__atsort__choose_pref_3_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__atsort__choose_pref_3_0_i7,
		STATIC(mercury__atsort__choose_pref_3_0));
Define_label(mercury__atsort__choose_pref_3_0_i7);
	update_prof_current_proc(LABEL(mercury__atsort__choose_pref_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__choose_pref_3_0_i5);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__atsort__choose_pref_3_0_i5);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__atsort__choose_pref_3_0_i1002);
END_MODULE

Declare_entry(mercury__list__delete_elems_3_0);

BEGIN_MODULE(atsort_module9)
	init_entry(mercury__atsort__repeat_source_sink_10_0);
	init_label(mercury__atsort__repeat_source_sink_10_0_i1004);
	init_label(mercury__atsort__repeat_source_sink_10_0_i2);
	init_label(mercury__atsort__repeat_source_sink_10_0_i3);
	init_label(mercury__atsort__repeat_source_sink_10_0_i6);
	init_label(mercury__atsort__repeat_source_sink_10_0_i7);
	init_label(mercury__atsort__repeat_source_sink_10_0_i8);
	init_label(mercury__atsort__repeat_source_sink_10_0_i9);
	init_label(mercury__atsort__repeat_source_sink_10_0_i10);
	init_label(mercury__atsort__repeat_source_sink_10_0_i11);
	init_label(mercury__atsort__repeat_source_sink_10_0_i12);
	init_label(mercury__atsort__repeat_source_sink_10_0_i14);
	init_label(mercury__atsort__repeat_source_sink_10_0_i17);
BEGIN_CODE

/* code for predicate 'repeat_source_sink'/10 in mode 0 */
Define_static(mercury__atsort__repeat_source_sink_10_0);
	MR_incr_sp_push_msg(9, "atsort:repeat_source_sink/10");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__atsort__repeat_source_sink_10_0_i1004);
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(8) = r1;
	call_localret(STATIC(mercury__atsort__source_sink_9_0),
		mercury__atsort__repeat_source_sink_10_0_i2,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i2);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i3);
	r4 = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__atsort__repeat_source_sink_10_0_i3);
	r2 = MR_stackvar(1);
	MR_stackvar(6) = r3;
	r3 = r1;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__atsort__repeat_source_sink_10_0_i6,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__atsort__repeat_source_sink_10_0_i7,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i7);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__atsort__map_delete_all_sink_links_4_0),
		mercury__atsort__repeat_source_sink_10_0_i8,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i8);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(8);
	call_localret(STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__241__0_7_0),
		mercury__atsort__repeat_source_sink_10_0_i9,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i9);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	r3 = r1;
	MR_stackvar(2) = r2;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__atsort__map_delete_all_nodes_3_0),
		mercury__atsort__repeat_source_sink_10_0_i10,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i10);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__atsort__DeforestationIn__pred__repeat_source_sink__279__1_6_0),
		mercury__atsort__repeat_source_sink_10_0_i11,
		STATIC(mercury__atsort__repeat_source_sink_10_0));
Define_label(mercury__atsort__repeat_source_sink_10_0_i11);
	update_prof_current_proc(LABEL(mercury__atsort__repeat_source_sink_10_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i12);
	r3 = r1;
	r4 = r2;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(7);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i14);
Define_label(mercury__atsort__repeat_source_sink_10_0_i12);
	r3 = r1;
	r4 = r2;
	r6 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__atsort__repeat_source_sink_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(7);
Define_label(mercury__atsort__repeat_source_sink_10_0_i14);
	if (((Integer) MR_stackvar(6) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i17);
	r7 = r6;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__atsort__repeat_source_sink_10_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
Define_label(mercury__atsort__repeat_source_sink_10_0_i17);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__atsort__repeat_source_sink_10_0_i1004);
END_MODULE


BEGIN_MODULE(atsort_module10)
	init_entry(mercury__atsort__source_sink_9_0);
	init_label(mercury__atsort__source_sink_9_0_i1005);
	init_label(mercury__atsort__source_sink_9_0_i5);
	init_label(mercury__atsort__source_sink_9_0_i4);
	init_label(mercury__atsort__source_sink_9_0_i9);
	init_label(mercury__atsort__source_sink_9_0_i8);
	init_label(mercury__atsort__source_sink_9_0_i3);
BEGIN_CODE

/* code for predicate 'source_sink'/9 in mode 0 */
Define_static(mercury__atsort__source_sink_9_0);
	MR_incr_sp_push_msg(9, "atsort:source_sink/9");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__atsort__source_sink_9_0_i1005);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__source_sink_9_0_i3);
	MR_stackvar(2) = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(6) = r4;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__source_sink_9_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(8) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__atsort__source_sink_9_0_i5,
		STATIC(mercury__atsort__source_sink_9_0));
Define_label(mercury__atsort__source_sink_9_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__source_sink_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__source_sink_9_0_i4);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__source_sink_9_0_i4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__atsort__source_sink_9_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_stackvar(5);
	r1 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__atsort__source_sink_9_0_i1005);
Define_label(mercury__atsort__source_sink_9_0_i4);
	r1 = MR_stackvar(8);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__source_sink_9_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__atsort__source_sink_9_0_i9,
		STATIC(mercury__atsort__source_sink_9_0));
Define_label(mercury__atsort__source_sink_9_0_i9);
	update_prof_current_proc(LABEL(mercury__atsort__source_sink_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__source_sink_9_0_i8);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__source_sink_9_0_i8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__atsort__source_sink_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r1 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__atsort__source_sink_9_0_i1005);
Define_label(mercury__atsort__source_sink_9_0_i8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	r5 = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__atsort__source_sink_9_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r1 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__atsort__source_sink_9_0_i1005);
Define_label(mercury__atsort__source_sink_9_0_i3);
	r1 = r5;
	r2 = r6;
	r3 = r7;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module11)
	init_entry(mercury__atsort__map_delete_all_sink_links_4_0);
	init_label(mercury__atsort__map_delete_all_sink_links_4_0_i1001);
	init_label(mercury__atsort__map_delete_all_sink_links_4_0_i4);
	init_label(mercury__atsort__map_delete_all_sink_links_4_0_i5);
	init_label(mercury__atsort__map_delete_all_sink_links_4_0_i3);
BEGIN_CODE

/* code for predicate 'map_delete_all_sink_links'/4 in mode 0 */
Define_static(mercury__atsort__map_delete_all_sink_links_4_0);
	MR_incr_sp_push_msg(6, "atsort:map_delete_all_sink_links/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__atsort__map_delete_all_sink_links_4_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__map_delete_all_sink_links_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r4 = MR_tempr1;
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__map_delete_all_sink_links_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_stackvar(5) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__atsort__map_delete_all_sink_links_4_0_i4,
		STATIC(mercury__atsort__map_delete_all_sink_links_4_0));
	}
Define_label(mercury__atsort__map_delete_all_sink_links_4_0_i4);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_all_sink_links_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__atsort__map_delete_this_element_4_0),
		mercury__atsort__map_delete_all_sink_links_4_0_i5,
		STATIC(mercury__atsort__map_delete_all_sink_links_4_0));
Define_label(mercury__atsort__map_delete_all_sink_links_4_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_all_sink_links_4_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__atsort__map_delete_all_sink_links_4_0_i1001);
Define_label(mercury__atsort__map_delete_all_sink_links_4_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(atsort_module12)
	init_entry(mercury__atsort__map_delete_this_element_4_0);
	init_label(mercury__atsort__map_delete_this_element_4_0_i1002);
	init_label(mercury__atsort__map_delete_this_element_4_0_i5);
	init_label(mercury__atsort__map_delete_this_element_4_0_i7);
	init_label(mercury__atsort__map_delete_this_element_4_0_i8);
	init_label(mercury__atsort__map_delete_this_element_4_0_i4);
	init_label(mercury__atsort__map_delete_this_element_4_0_i3);
BEGIN_CODE

/* code for predicate 'map_delete_this_element'/4 in mode 0 */
Define_static(mercury__atsort__map_delete_this_element_4_0);
	MR_incr_sp_push_msg(6, "atsort:map_delete_this_element/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__atsort__map_delete_this_element_4_0_i1002);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__map_delete_this_element_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = r4;
	MR_stackvar(2) = r4;
	r4 = MR_tempr1;
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__map_delete_this_element_4_0, "origin_lost_in_value_number");
	MR_stackvar(5) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__atsort__map_delete_this_element_4_0_i5,
		STATIC(mercury__atsort__map_delete_this_element_4_0));
	}
Define_label(mercury__atsort__map_delete_this_element_4_0_i5);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_this_element_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__map_delete_this_element_4_0_i4);
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__atsort__map_delete_this_element_4_0_i7,
		STATIC(mercury__atsort__map_delete_this_element_4_0));
Define_label(mercury__atsort__map_delete_this_element_4_0_i7);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_this_element_4_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__map_delete_this_element_4_0, "origin_lost_in_value_number");
	r5 = r3;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__atsort__map_delete_this_element_4_0_i8,
		STATIC(mercury__atsort__map_delete_this_element_4_0));
Define_label(mercury__atsort__map_delete_this_element_4_0_i8);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_this_element_4_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__atsort__map_delete_this_element_4_0_i1002);
Define_label(mercury__atsort__map_delete_this_element_4_0_i4);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__atsort__map_delete_this_element_4_0_i1002);
Define_label(mercury__atsort__map_delete_this_element_4_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module13)
	init_entry(mercury__atsort__map_delete_all_nodes_3_0);
	init_label(mercury__atsort__map_delete_all_nodes_3_0_i1001);
	init_label(mercury__atsort__map_delete_all_nodes_3_0_i4);
	init_label(mercury__atsort__map_delete_all_nodes_3_0_i3);
BEGIN_CODE

/* code for predicate 'map_delete_all_nodes'/3 in mode 0 */
Define_static(mercury__atsort__map_delete_all_nodes_3_0);
	MR_incr_sp_push_msg(3, "atsort:map_delete_all_nodes/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__atsort__map_delete_all_nodes_3_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__map_delete_all_nodes_3_0_i3);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__map_delete_all_nodes_3_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__atsort__map_delete_all_nodes_3_0_i4,
		STATIC(mercury__atsort__map_delete_all_nodes_3_0));
Define_label(mercury__atsort__map_delete_all_nodes_3_0_i4);
	update_prof_current_proc(LABEL(mercury__atsort__map_delete_all_nodes_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__atsort__map_delete_all_nodes_3_0_i1001);
Define_label(mercury__atsort__map_delete_all_nodes_3_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module14)
	init_entry(mercury__atsort__closure_2_4_0);
	init_label(mercury__atsort__closure_2_4_0_i1002);
	init_label(mercury__atsort__closure_2_4_0_i6);
	init_label(mercury__atsort__closure_2_4_0_i4);
	init_label(mercury__atsort__closure_2_4_0_i8);
	init_label(mercury__atsort__closure_2_4_0_i9);
	init_label(mercury__atsort__closure_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'closure_2'/4 in mode 0 */
Define_static(mercury__atsort__closure_2_4_0);
	MR_incr_sp_push_msg(6, "atsort:closure_2/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__atsort__closure_2_4_0_i1002);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__closure_2_4_0_i3);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(3) = r2;
	r3 = r4;
	MR_stackvar(2) = r4;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__atsort__closure_2_4_0_i6,
		STATIC(mercury__atsort__closure_2_4_0));
Define_label(mercury__atsort__closure_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__closure_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__closure_2_4_0_i4);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__atsort__closure_2_4_0_i1002);
Define_label(mercury__atsort__closure_2_4_0_i4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__atsort__closure_2_4_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__atsort__closure_2_4_0_i8,
		STATIC(mercury__atsort__closure_2_4_0));
Define_label(mercury__atsort__closure_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__atsort__closure_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__atsort__maybe_insert_3_0),
		mercury__atsort__closure_2_4_0_i9,
		STATIC(mercury__atsort__closure_2_4_0));
Define_label(mercury__atsort__closure_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__atsort__closure_2_4_0));
	r3 = MR_stackvar(1);
	r2 = r1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__atsort__closure_2_4_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(5);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__atsort__closure_2_4_0_i1002);
Define_label(mercury__atsort__closure_2_4_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(atsort_module15)
	init_entry(mercury__atsort__maybe_insert_3_0);
	init_label(mercury__atsort__maybe_insert_3_0_i1002);
	init_label(mercury__atsort__maybe_insert_3_0_i6);
	init_label(mercury__atsort__maybe_insert_3_0_i4);
	init_label(mercury__atsort__maybe_insert_3_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_insert'/3 in mode 0 */
Define_static(mercury__atsort__maybe_insert_3_0);
	MR_incr_sp_push_msg(5, "atsort:maybe_insert/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__atsort__maybe_insert_3_0_i1002);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__atsort__maybe_insert_3_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__atsort__maybe_insert_3_0_i6,
		STATIC(mercury__atsort__maybe_insert_3_0));
Define_label(mercury__atsort__maybe_insert_3_0_i6);
	update_prof_current_proc(LABEL(mercury__atsort__maybe_insert_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__atsort__maybe_insert_3_0_i4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__atsort__maybe_insert_3_0_i1002);
Define_label(mercury__atsort__maybe_insert_3_0_i4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__atsort__maybe_insert_3_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__atsort__maybe_insert_3_0_i1002);
Define_label(mercury__atsort__maybe_insert_3_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(atsort_module16)
	init_entry(mercury____Unify___atsort__relmap_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___atsort__relmap_1_0);
	r4 = r3;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury____Unify___atsort__relmap_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___atsort__relmap_1_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(atsort_module17)
	init_entry(mercury____Index___atsort__relmap_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___atsort__relmap_1_0);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury____Index___atsort__relmap_1_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___atsort__relmap_1_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(atsort_module18)
	init_entry(mercury____Compare___atsort__relmap_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___atsort__relmap_1_0);
	r4 = r3;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury____Compare___atsort__relmap_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___atsort__relmap_1_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__atsort_maybe_bunch_0(void)
{
	atsort_module0();
	atsort_module1();
	atsort_module2();
	atsort_module3();
	atsort_module4();
	atsort_module5();
	atsort_module6();
	atsort_module7();
	atsort_module8();
	atsort_module9();
	atsort_module10();
	atsort_module11();
	atsort_module12();
	atsort_module13();
	atsort_module14();
	atsort_module15();
	atsort_module16();
	atsort_module17();
	atsort_module18();
}

#endif

void mercury__atsort__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__atsort__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__atsort_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_atsort__type_ctor_info_relmap_1,
			atsort__relmap_1_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
