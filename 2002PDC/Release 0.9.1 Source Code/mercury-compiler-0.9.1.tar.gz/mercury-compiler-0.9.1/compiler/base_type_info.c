/*
** Automatically generated from `base_type_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__base_type_info__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__base_type_info__generate_hlds_2_0);
Declare_label(mercury__base_type_info__generate_hlds_2_0_i2);
Declare_label(mercury__base_type_info__generate_hlds_2_0_i3);
Declare_label(mercury__base_type_info__generate_hlds_2_0_i4);
Declare_label(mercury__base_type_info__generate_hlds_2_0_i5);
Define_extern_entry(mercury__base_type_info__generate_llds_2_0);
Declare_label(mercury__base_type_info__generate_llds_2_0_i2);
Declare_label(mercury__base_type_info__generate_llds_2_0_i3);
Declare_label(mercury__base_type_info__generate_llds_2_0_i4);
Declare_static(mercury__base_type_info__gen_base_gen_infos_5_0);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i4);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i7);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i6);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i10);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i14);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i16);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i17);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i18);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i19);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i20);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i21);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i22);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i23);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i25);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i9);
Declare_label(mercury__base_type_info__gen_base_gen_infos_5_0_i3);
Declare_static(mercury__base_type_info__gen_proc_list_4_0);
Declare_label(mercury__base_type_info__gen_proc_list_4_0_i4);
Declare_label(mercury__base_type_info__gen_proc_list_4_0_i5);
Declare_label(mercury__base_type_info__gen_proc_list_4_0_i6);
Declare_label(mercury__base_type_info__gen_proc_list_4_0_i7);
Declare_label(mercury__base_type_info__gen_proc_list_4_0_i3);
Declare_static(mercury__base_type_info__construct_type_ctor_infos_3_0);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i6);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i8);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i9);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i10);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i7);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i4);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i13);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i15);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i16);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i1023);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i20);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i21);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i22);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i23);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i17);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i25);
Declare_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i3);
Declare_static(mercury__base_type_info__construct_functors_4_0);
Declare_label(mercury__base_type_info__construct_functors_4_0_i2);
Declare_static(mercury__base_type_info__construct_pred_addrs2_3_0);
Declare_label(mercury__base_type_info__construct_pred_addrs2_3_0_i4);
Declare_label(mercury__base_type_info__construct_pred_addrs2_3_0_i5);
Declare_label(mercury__base_type_info__construct_pred_addrs2_3_0_i3);
Declare_static(mercury__base_type_info__construct_type_ctor_representation_2_0);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i2);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i5);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i6);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i11);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i14);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i9);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i16);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i8);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i19);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i20);
Declare_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i22);
Declare_static(mercury____Unify___base_type_info__type_ctor_representation_0_0);
Declare_label(mercury____Unify___base_type_info__type_ctor_representation_0_0_i1);
Declare_static(mercury____Index___base_type_info__type_ctor_representation_0_0);
Declare_static(mercury____Compare___base_type_info__type_ctor_representation_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_base_type_info__type_ctor_info_type_ctor_representation_0;

static const struct mercury_data_base_type_info__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_base_type_info__common_0;

static const struct mercury_data_base_type_info__common_1_struct {
	String f1;
	Word * f2;
}  mercury_data_base_type_info__common_1;

static const struct mercury_data_base_type_info__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_base_type_info__common_2;

static const struct mercury_data_base_type_info__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_base_type_info__common_3;

static const struct mercury_data_base_type_info__common_4_struct {
	Integer f1;
}  mercury_data_base_type_info__common_4;

static const struct mercury_data_base_type_info__common_5_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_5;

static const struct mercury_data_base_type_info__common_6_struct {
	Word * f1;
}  mercury_data_base_type_info__common_6;

static const struct mercury_data_base_type_info__common_7_struct {
	Integer f1;
}  mercury_data_base_type_info__common_7;

static const struct mercury_data_base_type_info__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_8;

static const struct mercury_data_base_type_info__common_9_struct {
	Word * f1;
}  mercury_data_base_type_info__common_9;

static const struct mercury_data_base_type_info__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_base_type_info__common_10;

static const struct mercury_data_base_type_info__common_11_struct {
	Word * f1;
}  mercury_data_base_type_info__common_11;

static const struct mercury_data_base_type_info__common_12_struct {
	Integer f1;
}  mercury_data_base_type_info__common_12;

static const struct mercury_data_base_type_info__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_13;

static const struct mercury_data_base_type_info__common_14_struct {
	Word * f1;
}  mercury_data_base_type_info__common_14;

static const struct mercury_data_base_type_info__common_15_struct {
	Integer f1;
}  mercury_data_base_type_info__common_15;

static const struct mercury_data_base_type_info__common_16_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_16;

static const struct mercury_data_base_type_info__common_17_struct {
	Word * f1;
}  mercury_data_base_type_info__common_17;

static const struct mercury_data_base_type_info__common_18_struct {
	Integer f1;
}  mercury_data_base_type_info__common_18;

static const struct mercury_data_base_type_info__common_19_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_19;

static const struct mercury_data_base_type_info__common_20_struct {
	Word * f1;
}  mercury_data_base_type_info__common_20;

static const struct mercury_data_base_type_info__common_21_struct {
	Integer f1;
}  mercury_data_base_type_info__common_21;

static const struct mercury_data_base_type_info__common_22_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_22;

static const struct mercury_data_base_type_info__common_23_struct {
	Word * f1;
}  mercury_data_base_type_info__common_23;

static const struct mercury_data_base_type_info__common_24_struct {
	Integer f1;
}  mercury_data_base_type_info__common_24;

static const struct mercury_data_base_type_info__common_25_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_25;

static const struct mercury_data_base_type_info__common_26_struct {
	Word * f1;
}  mercury_data_base_type_info__common_26;

static const struct mercury_data_base_type_info__common_27_struct {
	Integer f1;
}  mercury_data_base_type_info__common_27;

static const struct mercury_data_base_type_info__common_28_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__common_28;

static const struct mercury_data_base_type_info__common_29_struct {
	Word * f1;
}  mercury_data_base_type_info__common_29;

static const struct mercury_data_base_type_info__common_30_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
	String f13;
	String f14;
	String f15;
	String f16;
	String f17;
	String f18;
	String f19;
	String f20;
	String f21;
	String f22;
}  mercury_data_base_type_info__common_30;

static const struct mercury_data_base_type_info__type_ctor_functors_type_ctor_representation_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_base_type_info__type_ctor_functors_type_ctor_representation_0;

static const struct mercury_data_base_type_info__type_ctor_layout_type_ctor_representation_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_base_type_info__type_ctor_layout_type_ctor_representation_0;

const struct MR_TypeCtorInfo_struct mercury_data_base_type_info__type_ctor_info_type_ctor_representation_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___base_type_info__type_ctor_representation_0_0),
	STATIC(mercury____Index___base_type_info__type_ctor_representation_0_0),
	STATIC(mercury____Compare___base_type_info__type_ctor_representation_0_0),
	(Integer) 0,
	(Word *) &mercury_data_base_type_info__type_ctor_functors_type_ctor_representation_0,
	(Word *) &mercury_data_base_type_info__type_ctor_layout_type_ctor_representation_0,
	MR_string_const("base_type_info", 14),
	MR_string_const("type_ctor_representation", 24),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_base_type_info__common_0_struct mercury_data_base_type_info__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_base_type_info__common_1_struct mercury_data_base_type_info__common_1 = {
	MR_string_const("found in type_ctor_info", 23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_special_pred__type_ctor_info_special_pred_id_0;
static const struct mercury_data_base_type_info__common_2_struct mercury_data_base_type_info__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_rval_0;
static const struct mercury_data_base_type_info__common_3_struct mercury_data_base_type_info__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_llds__type_ctor_info_rval_0
};

static const struct mercury_data_base_type_info__common_4_struct mercury_data_base_type_info__common_4 = {
	(Integer) 0
};

static const struct mercury_data_base_type_info__common_5_struct mercury_data_base_type_info__common_5 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_4)
};

static const struct mercury_data_base_type_info__common_6_struct mercury_data_base_type_info__common_6 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_5)
};

static const struct mercury_data_base_type_info__common_7_struct mercury_data_base_type_info__common_7 = {
	(Integer) 3
};

static const struct mercury_data_base_type_info__common_8_struct mercury_data_base_type_info__common_8 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_7)
};

static const struct mercury_data_base_type_info__common_9_struct mercury_data_base_type_info__common_9 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_8)
};

static const struct mercury_data_base_type_info__common_10_struct mercury_data_base_type_info__common_10 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_base_type_info__common_11_struct mercury_data_base_type_info__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_base_type_info__common_12_struct mercury_data_base_type_info__common_12 = {
	(Integer) 19
};

static const struct mercury_data_base_type_info__common_13_struct mercury_data_base_type_info__common_13 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_12)
};

static const struct mercury_data_base_type_info__common_14_struct mercury_data_base_type_info__common_14 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_13)
};

static const struct mercury_data_base_type_info__common_15_struct mercury_data_base_type_info__common_15 = {
	(Integer) 4
};

static const struct mercury_data_base_type_info__common_16_struct mercury_data_base_type_info__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_15)
};

static const struct mercury_data_base_type_info__common_17_struct mercury_data_base_type_info__common_17 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_16)
};

static const struct mercury_data_base_type_info__common_18_struct mercury_data_base_type_info__common_18 = {
	(Integer) 5
};

static const struct mercury_data_base_type_info__common_19_struct mercury_data_base_type_info__common_19 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_18)
};

static const struct mercury_data_base_type_info__common_20_struct mercury_data_base_type_info__common_20 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_19)
};

static const struct mercury_data_base_type_info__common_21_struct mercury_data_base_type_info__common_21 = {
	(Integer) 2
};

static const struct mercury_data_base_type_info__common_22_struct mercury_data_base_type_info__common_22 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_21)
};

static const struct mercury_data_base_type_info__common_23_struct mercury_data_base_type_info__common_23 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_22)
};

static const struct mercury_data_base_type_info__common_24_struct mercury_data_base_type_info__common_24 = {
	(Integer) 1
};

static const struct mercury_data_base_type_info__common_25_struct mercury_data_base_type_info__common_25 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_24)
};

static const struct mercury_data_base_type_info__common_26_struct mercury_data_base_type_info__common_26 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_25)
};

static const struct mercury_data_base_type_info__common_27_struct mercury_data_base_type_info__common_27 = {
	(Integer) 6
};

static const struct mercury_data_base_type_info__common_28_struct mercury_data_base_type_info__common_28 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_27)
};

static const struct mercury_data_base_type_info__common_29_struct mercury_data_base_type_info__common_29 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_base_type_info__common_28)
};

static const struct mercury_data_base_type_info__common_30_struct mercury_data_base_type_info__common_30 = {
	(Integer) 1,
	(Integer) 20,
	MR_string_const("enum", 4),
	MR_string_const("enum_usereq", 11),
	MR_string_const("du", 2),
	MR_string_const("du_usereq", 9),
	MR_string_const("notag", 5),
	MR_string_const("notag_usereq", 12),
	MR_string_const("equiv", 5),
	MR_string_const("equiv_var", 9),
	MR_string_const("int", 3),
	MR_string_const("char", 4),
	MR_string_const("float", 5),
	MR_string_const("string", 6),
	MR_string_const("pred", 4),
	MR_string_const("univ", 4),
	MR_string_const("void", 4),
	MR_string_const("c_pointer", 9),
	MR_string_const("typeinfo", 8),
	MR_string_const("typeclassinfo", 13),
	MR_string_const("array", 5),
	MR_string_const("unknown", 7)
};

static const struct mercury_data_base_type_info__type_ctor_functors_type_ctor_representation_0_struct mercury_data_base_type_info__type_ctor_functors_type_ctor_representation_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_30)
};

static const struct mercury_data_base_type_info__type_ctor_layout_type_ctor_representation_0_struct mercury_data_base_type_info__type_ctor_layout_type_ctor_representation_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_30)
};

Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__hlds_module__module_info_set_base_gen_infos_3_0);

BEGIN_MODULE(base_type_info_module0)
	init_entry(mercury__base_type_info__generate_hlds_2_0);
	init_label(mercury__base_type_info__generate_hlds_2_0_i2);
	init_label(mercury__base_type_info__generate_hlds_2_0_i3);
	init_label(mercury__base_type_info__generate_hlds_2_0_i4);
	init_label(mercury__base_type_info__generate_hlds_2_0_i5);
BEGIN_CODE

/* code for predicate 'generate_hlds'/2 in mode 0 */
Define_entry(mercury__base_type_info__generate_hlds_2_0);
	MR_incr_sp_push_msg(4, "base_type_info:generate_hlds/2");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_type_info__generate_hlds_2_0_i2,
		ENTRY(mercury__base_type_info__generate_hlds_2_0));
Define_label(mercury__base_type_info__generate_hlds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_hlds_2_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__base_type_info__generate_hlds_2_0_i3,
		ENTRY(mercury__base_type_info__generate_hlds_2_0));
Define_label(mercury__base_type_info__generate_hlds_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_hlds_2_0));
	r3 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__base_type_info__generate_hlds_2_0_i4,
		ENTRY(mercury__base_type_info__generate_hlds_2_0));
Define_label(mercury__base_type_info__generate_hlds_2_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_hlds_2_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__base_type_info__gen_base_gen_infos_5_0),
		mercury__base_type_info__generate_hlds_2_0_i5,
		ENTRY(mercury__base_type_info__generate_hlds_2_0));
Define_label(mercury__base_type_info__generate_hlds_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_hlds_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_base_gen_infos_3_0),
		ENTRY(mercury__base_type_info__generate_hlds_2_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_base_gen_infos_2_0);
Declare_entry(mercury__base_typeclass_info__generate_llds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_comp_gen_c_data_0;
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(base_type_info_module1)
	init_entry(mercury__base_type_info__generate_llds_2_0);
	init_label(mercury__base_type_info__generate_llds_2_0_i2);
	init_label(mercury__base_type_info__generate_llds_2_0_i3);
	init_label(mercury__base_type_info__generate_llds_2_0_i4);
BEGIN_CODE

/* code for predicate 'generate_llds'/2 in mode 0 */
Define_entry(mercury__base_type_info__generate_llds_2_0);
	MR_incr_sp_push_msg(2, "base_type_info:generate_llds/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_base_gen_infos_2_0),
		mercury__base_type_info__generate_llds_2_0_i2,
		ENTRY(mercury__base_type_info__generate_llds_2_0));
Define_label(mercury__base_type_info__generate_llds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_llds_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0),
		mercury__base_type_info__generate_llds_2_0_i3,
		ENTRY(mercury__base_type_info__generate_llds_2_0));
Define_label(mercury__base_type_info__generate_llds_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_llds_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__base_typeclass_info__generate_llds_2_0),
		mercury__base_type_info__generate_llds_2_0_i4,
		ENTRY(mercury__base_type_info__generate_llds_2_0));
Define_label(mercury__base_type_info__generate_llds_2_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_info__generate_llds_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_comp_gen_c_data_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__base_type_info__generate_llds_2_0));
END_MODULE

Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
Declare_entry(mercury__type_util__type_id_is_hand_defined_1_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_data__get_type_defn_status_2_0);
Declare_entry(mercury__special_pred__special_pred_list_1_0);
Declare_entry(mercury__hlds_module__module_info_globals_2_0);
Declare_entry(mercury__globals__have_static_code_addresses_2_0);
Declare_entry(mercury__hlds_module__module_info_get_special_pred_map_2_0);
Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(base_type_info_module2)
	init_entry(mercury__base_type_info__gen_base_gen_infos_5_0);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i4);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i7);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i6);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i10);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i14);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i16);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i17);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i18);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i19);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i20);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i21);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i22);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i23);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i25);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i9);
	init_label(mercury__base_type_info__gen_base_gen_infos_5_0_i3);
BEGIN_CODE

/* code for predicate 'gen_base_gen_infos'/5 in mode 0 */
Define_static(mercury__base_type_info__gen_base_gen_infos_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i3);
	MR_incr_sp_push_msg(10, "base_type_info:gen_base_gen_infos/5");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	localcall(mercury__base_type_info__gen_base_gen_infos_5_0,
		LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i4),
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i6);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__gen_base_gen_infos_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("unqualified type ", 17);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__base_type_info__gen_base_gen_infos_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i7,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i6);
	MR_stackvar(5) = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i10,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i9);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__type_util__type_id_is_hand_defined_1_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i14,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i14);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	if (r1)
		GOTO_LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i16,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i16);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_status_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i17,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i17);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__special_pred__special_pred_list_1_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i18,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i18);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i19,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i19);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	call_localret(ENTRY(mercury__globals__have_static_code_addresses_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i20,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i20);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_special_pred_map_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i21,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i21);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__base_type_info__gen_proc_list_4_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i22,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i22);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__base_type_info__gen_base_gen_infos_5_0_i23);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__gen_base_gen_infos_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__base_type_info__gen_base_gen_infos_5_0, "hlds_module:base_gen_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 6) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i23);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_type_info__gen_base_gen_infos_5_0_i25,
		STATIC(mercury__base_type_info__gen_base_gen_infos_5_0));
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i25);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_base_gen_infos_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__gen_base_gen_infos_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__base_type_info__gen_base_gen_infos_5_0, "hlds_module:base_gen_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__base_type_info__gen_base_gen_infos_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i9);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__base_type_info__gen_base_gen_infos_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
Declare_entry(mercury__special_pred__special_pred_mode_num_2_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_1);

BEGIN_MODULE(base_type_info_module3)
	init_entry(mercury__base_type_info__gen_proc_list_4_0);
	init_label(mercury__base_type_info__gen_proc_list_4_0_i4);
	init_label(mercury__base_type_info__gen_proc_list_4_0_i5);
	init_label(mercury__base_type_info__gen_proc_list_4_0_i6);
	init_label(mercury__base_type_info__gen_proc_list_4_0_i7);
	init_label(mercury__base_type_info__gen_proc_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'gen_proc_list'/4 in mode 0 */
Define_static(mercury__base_type_info__gen_proc_list_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__gen_proc_list_4_0_i3);
	MR_incr_sp_push_msg(5, "base_type_info:gen_proc_list/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__base_type_info__gen_proc_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__base_type_info__gen_proc_list_4_0_i4,
		STATIC(mercury__base_type_info__gen_proc_list_4_0));
	}
Define_label(mercury__base_type_info__gen_proc_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_proc_list_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__special_pred__special_pred_mode_num_2_0),
		mercury__base_type_info__gen_proc_list_4_0_i5,
		STATIC(mercury__base_type_info__gen_proc_list_4_0));
Define_label(mercury__base_type_info__gen_proc_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_proc_list_4_0));
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_1),
		mercury__base_type_info__gen_proc_list_4_0_i6,
		STATIC(mercury__base_type_info__gen_proc_list_4_0));
Define_label(mercury__base_type_info__gen_proc_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_proc_list_4_0));
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__base_type_info__gen_proc_list_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__base_type_info__gen_proc_list_4_0,
		LABEL(mercury__base_type_info__gen_proc_list_4_0_i7),
		STATIC(mercury__base_type_info__gen_proc_list_4_0));
	}
Define_label(mercury__base_type_info__gen_proc_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__base_type_info__gen_proc_list_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__gen_proc_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__base_type_info__gen_proc_list_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__initial_proc_id_1_0);
Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__globals__lookup_bool_option_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);

BEGIN_MODULE(base_type_info_module4)
	init_entry(mercury__base_type_info__construct_type_ctor_infos_3_0);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i6);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i8);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i9);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i10);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i7);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i4);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i13);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i15);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i16);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i1023);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i20);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i21);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i22);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i23);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i17);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i25);
	init_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i3);
BEGIN_CODE

/* code for predicate 'construct_type_ctor_infos'/3 in mode 0 */
Define_static(mercury__base_type_info__construct_type_ctor_infos_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i3);
	MR_incr_sp_push_msg(15, "base_type_info:construct_type_ctor_infos/3");
	MR_stackvar(15) = (Word) MR_succip;
	r8 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	r7 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r5 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 7);
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i4);
	MR_stackvar(2) = r8;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	MR_stackvar(7) = r4;
	MR_stackvar(8) = r3;
	MR_stackvar(14) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i6,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i6);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	call_localret(ENTRY(mercury__globals__have_static_code_addresses_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i8,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i8);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i7);
	call_localret(ENTRY(mercury__hlds_pred__initial_proc_id_1_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i9,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i9);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i10,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i10);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	r2 = MR_stackvar(14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:code_addr/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_3);
	MR_field(MR_mktag(3), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = (Word) MR_string_const("unused", 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Integer) 0;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i13,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i7);
	r2 = MR_stackvar(14);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_3);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i13,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r8;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	MR_stackvar(7) = r4;
	MR_stackvar(8) = r3;
	r1 = r4;
	call_localret(STATIC(mercury__base_type_info__construct_pred_addrs2_3_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i13,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i13);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(10) = (Integer) 1;
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i15,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i15);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	r2 = (Integer) 105;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i16,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i16);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i17);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i1023,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i1023);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	tag_incr_hp_msg(MR_stackvar(11), MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:data_addr/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_stackvar(11), (Integer) 0) = r2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r3 = MR_stackvar(6);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = r3;
	call_localret(STATIC(mercury__base_type_info__construct_functors_4_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i20,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i20);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(8);
	call_localret(STATIC(mercury__base_type_info__construct_type_ctor_representation_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i21,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i21);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i22,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i22);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_type_info__common_3);
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_type_ctor_infos_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_10);
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__base_type_info__construct_type_ctor_infos_3_0_i23,
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i23);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(2);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_11);
	localcall(mercury__base_type_info__construct_type_ctor_infos_3_0,
		LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i25),
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i17);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_11);
	localcall(mercury__base_type_info__construct_type_ctor_infos_3_0,
		LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0_i25),
		STATIC(mercury__base_type_info__construct_type_ctor_infos_3_0));
	}
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i25);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_infos_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_type_ctor_infos_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_infos_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(base_type_info_module5)
	init_entry(mercury__base_type_info__construct_functors_4_0);
	init_label(mercury__base_type_info__construct_functors_4_0_i2);
BEGIN_CODE

/* code for predicate 'construct_functors'/4 in mode 0 */
Define_static(mercury__base_type_info__construct_functors_4_0);
	MR_incr_sp_push_msg(3, "base_type_info:construct_functors/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_type_info__construct_functors_4_0_i2,
		STATIC(mercury__base_type_info__construct_functors_4_0));
Define_label(mercury__base_type_info__construct_functors_4_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_functors_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_functors_4_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_functors_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_functors_4_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__base_type_info__construct_functors_4_0, "llds:data_addr/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 3, mercury__base_type_info__construct_functors_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(2), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(2), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__code_util__make_entry_label_5_0);

BEGIN_MODULE(base_type_info_module6)
	init_entry(mercury__base_type_info__construct_pred_addrs2_3_0);
	init_label(mercury__base_type_info__construct_pred_addrs2_3_0_i4);
	init_label(mercury__base_type_info__construct_pred_addrs2_3_0_i5);
	init_label(mercury__base_type_info__construct_pred_addrs2_3_0_i3);
BEGIN_CODE

/* code for predicate 'construct_pred_addrs2'/3 in mode 0 */
Define_static(mercury__base_type_info__construct_pred_addrs2_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_pred_addrs2_3_0_i3);
	MR_incr_sp_push_msg(3, "base_type_info:construct_pred_addrs2/3");
	MR_stackvar(3) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_util__make_entry_label_5_0),
		mercury__base_type_info__construct_pred_addrs2_3_0_i4,
		STATIC(mercury__base_type_info__construct_pred_addrs2_3_0));
	}
Define_label(mercury__base_type_info__construct_pred_addrs2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_pred_addrs2_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__base_type_info__construct_pred_addrs2_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_pred_addrs2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__base_type_info__construct_pred_addrs2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r3;
	localcall(mercury__base_type_info__construct_pred_addrs2_3_0,
		LABEL(mercury__base_type_info__construct_pred_addrs2_3_0_i5),
		STATIC(mercury__base_type_info__construct_pred_addrs2_3_0));
	}
Define_label(mercury__base_type_info__construct_pred_addrs2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_pred_addrs2_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_type_info__construct_pred_addrs2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__base_type_info__construct_pred_addrs2_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
Declare_entry(mercury__type_util__type_is_no_tag_type_3_0);

BEGIN_MODULE(base_type_info_module7)
	init_entry(mercury__base_type_info__construct_type_ctor_representation_2_0);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i2);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i5);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i6);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i11);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i14);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i9);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i16);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i8);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i19);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i20);
	init_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i22);
BEGIN_CODE

/* code for predicate 'construct_type_ctor_representation'/2 in mode 0 */
Define_static(mercury__base_type_info__construct_type_ctor_representation_2_0);
	MR_incr_sp_push_msg(2, "base_type_info:construct_type_ctor_representation/2");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__base_type_info__construct_type_ctor_representation_2_0_i2,
		STATIC(mercury__base_type_info__construct_type_ctor_representation_2_0));
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i5) AND
		LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i6) AND
		LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i20) AND
		LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i22));
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_14);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 2) != (Integer) 0))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__type_util__type_is_no_tag_type_3_0),
		mercury__base_type_info__construct_type_ctor_representation_2_0_i11,
		STATIC(mercury__base_type_info__construct_type_ctor_representation_2_0));
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i11);
	update_prof_current_proc(LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i9);
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i14);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_17);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i14);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_20);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i9);
	r2 = MR_stackvar(1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i16);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_23);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i16);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_9);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i8);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_type_info__construct_type_ctor_representation_2_0_i19);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_6);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i19);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_26);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i20);
	r1 = (Word) MR_string_const("base_type_info__construct_type_ctor_representation: sorry, undiscriminated union unimplemented\n", 95);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_type_info__construct_type_ctor_representation_2_0));
Define_label(mercury__base_type_info__construct_type_ctor_representation_2_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_type_info__common_29);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(base_type_info_module8)
	init_entry(mercury____Unify___base_type_info__type_ctor_representation_0_0);
	init_label(mercury____Unify___base_type_info__type_ctor_representation_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___base_type_info__type_ctor_representation_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___base_type_info__type_ctor_representation_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___base_type_info__type_ctor_representation_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(base_type_info_module9)
	init_entry(mercury____Index___base_type_info__type_ctor_representation_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___base_type_info__type_ctor_representation_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(base_type_info_module10)
	init_entry(mercury____Compare___base_type_info__type_ctor_representation_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___base_type_info__type_ctor_representation_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___base_type_info__type_ctor_representation_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__base_type_info_maybe_bunch_0(void)
{
	base_type_info_module0();
	base_type_info_module1();
	base_type_info_module2();
	base_type_info_module3();
	base_type_info_module4();
	base_type_info_module5();
	base_type_info_module6();
	base_type_info_module7();
	base_type_info_module8();
	base_type_info_module9();
	base_type_info_module10();
}

#endif

void mercury__base_type_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__base_type_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__base_type_info_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_base_type_info__type_ctor_info_type_ctor_representation_0,
			base_type_info__type_ctor_representation_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
