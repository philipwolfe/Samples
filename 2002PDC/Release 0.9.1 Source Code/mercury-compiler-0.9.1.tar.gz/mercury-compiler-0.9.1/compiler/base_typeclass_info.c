/*
** Automatically generated from `base_typeclass_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__base_typeclass_info__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__base_typeclass_info__IntroducedFrom__pred__gen_rvals_and_procs__124__1_2_0);
Define_extern_entry(mercury__base_typeclass_info__generate_llds_2_0);
Declare_label(mercury__base_typeclass_info__generate_llds_2_0_i2);
Declare_label(mercury__base_typeclass_info__generate_llds_2_0_i3);
Declare_label(mercury__base_typeclass_info__generate_llds_2_0_i4);
Define_extern_entry(mercury__base_typeclass_info__make_instance_string_2_0);
Declare_label(mercury__base_typeclass_info__make_instance_string_2_0_i2);
Declare_static(mercury__base_typeclass_info__gen_infos_for_classes_4_0);
Declare_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i4);
Declare_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i5);
Declare_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i3);
Declare_static(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i4);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i8);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i9);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i10);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i11);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i5);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i3);
Declare_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i2);
Declare_static(mercury__base_typeclass_info__gen_rvals_and_procs_6_0);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i4);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i3);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i5);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i6);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i7);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i8);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i9);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i10);
Declare_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i11);
Declare_static(mercury__base_typeclass_info__construct_pred_addrs_3_0);
Declare_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i4);
Declare_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i5);
Declare_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i3);
Declare_static(mercury__base_typeclass_info__type_to_string_2_0);
Declare_label(mercury__base_typeclass_info__type_to_string_2_0_i3);
Declare_label(mercury__base_typeclass_info__type_to_string_2_0_i5);
Declare_label(mercury__base_typeclass_info__type_to_string_2_0_i6);
Declare_label(mercury__base_typeclass_info__type_to_string_2_0_i7);
Declare_label(mercury__base_typeclass_info__type_to_string_2_0_i2);

static const struct mercury_data_base_typeclass_info__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_base_typeclass_info__common_0;

static const struct mercury_data_base_typeclass_info__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_base_typeclass_info__common_1;

static const struct mercury_data_base_typeclass_info__common_2_struct {
	Word * f1;
}  mercury_data_base_typeclass_info__common_2;

static const struct mercury_data_base_typeclass_info__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_base_typeclass_info__common_3;

static const struct mercury_data_base_typeclass_info__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_base_typeclass_info__common_4;

static const struct mercury_data_base_typeclass_info__common_5_struct {
	Word * f1;
}  mercury_data_base_typeclass_info__common_5;

static const struct mercury_data_base_typeclass_info__common_6_struct {
	Word * f1;
}  mercury_data_base_typeclass_info__common_6;

static const struct mercury_data_base_typeclass_info__common_7_struct {
	Word * f1;
}  mercury_data_base_typeclass_info__common_7;

static const struct mercury_data_base_typeclass_info__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_base_typeclass_info__common_8;

static const struct mercury_data_base_typeclass_info__common_9_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_base_typeclass_info__common_9;

static const struct mercury_data_base_typeclass_info__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_base_typeclass_info__common_10;

static const struct mercury_data_base_typeclass_info__common_11_struct {
	String f1;
	Word * f2;
}  mercury_data_base_typeclass_info__common_11;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
static const struct mercury_data_base_typeclass_info__common_0_struct mercury_data_base_typeclass_info__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_base_typeclass_info__common_1_struct mercury_data_base_typeclass_info__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_base_typeclass_info__common_2_struct mercury_data_base_typeclass_info__common_2 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_base_typeclass_info__common_3_struct mercury_data_base_typeclass_info__common_3 = {
	(Integer) 0,
	MR_string_const("base_typeclass_info", 19),
	MR_string_const("base_typeclass_info", 19),
	MR_string_const("type_to_string", 14),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_2)
};

static const struct mercury_data_base_typeclass_info__common_4_struct mercury_data_base_typeclass_info__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_3),
	STATIC(mercury__base_typeclass_info__type_to_string_2_0),
	(Integer) 0
};

static const struct mercury_data_base_typeclass_info__common_5_struct mercury_data_base_typeclass_info__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
static const struct mercury_data_base_typeclass_info__common_6_struct mercury_data_base_typeclass_info__common_6 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_base_typeclass_info__common_7_struct mercury_data_base_typeclass_info__common_7 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_base_typeclass_info__common_8_struct mercury_data_base_typeclass_info__common_8 = {
	(Integer) 0,
	MR_string_const("base_typeclass_info", 19),
	MR_string_const("base_typeclass_info", 19),
	MR_string_const("IntroducedFrom__pred__gen_rvals_and_procs__124__1", 49),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_7)
};

static const struct mercury_data_base_typeclass_info__common_9_struct mercury_data_base_typeclass_info__common_9 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_8),
	STATIC(mercury__base_typeclass_info__IntroducedFrom__pred__gen_rvals_and_procs__124__1_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
static const struct mercury_data_base_typeclass_info__common_10_struct mercury_data_base_typeclass_info__common_10 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_base_typeclass_info__common_11_struct mercury_data_base_typeclass_info__common_11 = {
	MR_string_const("__", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};


BEGIN_MODULE(base_typeclass_info_module0)
	init_entry(mercury__base_typeclass_info__IntroducedFrom__pred__gen_rvals_and_procs__124__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__gen_rvals_and_procs__124__1'/2 in mode 0 */
Define_static(mercury__base_typeclass_info__IntroducedFrom__pred__gen_rvals_and_procs__124__1_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__base_typeclass_info__IntroducedFrom__pred__gen_rvals_and_procs__124__1_2_0, "hlds_pred:pred_proc_id/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__hlds_module__module_info_instances_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_class_id_0;
Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(base_typeclass_info_module1)
	init_entry(mercury__base_typeclass_info__generate_llds_2_0);
	init_label(mercury__base_typeclass_info__generate_llds_2_0_i2);
	init_label(mercury__base_typeclass_info__generate_llds_2_0_i3);
	init_label(mercury__base_typeclass_info__generate_llds_2_0_i4);
BEGIN_CODE

/* code for predicate 'generate_llds'/2 in mode 0 */
Define_entry(mercury__base_typeclass_info__generate_llds_2_0);
	MR_incr_sp_push_msg(3, "base_typeclass_info:generate_llds/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__base_typeclass_info__generate_llds_2_0_i2,
		ENTRY(mercury__base_typeclass_info__generate_llds_2_0));
Define_label(mercury__base_typeclass_info__generate_llds_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__generate_llds_2_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_instances_2_0),
		mercury__base_typeclass_info__generate_llds_2_0_i3,
		ENTRY(mercury__base_typeclass_info__generate_llds_2_0));
Define_label(mercury__base_typeclass_info__generate_llds_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__generate_llds_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__base_typeclass_info__generate_llds_2_0_i4,
		ENTRY(mercury__base_typeclass_info__generate_llds_2_0));
Define_label(mercury__base_typeclass_info__generate_llds_2_0_i4);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__generate_llds_2_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__base_typeclass_info__gen_infos_for_classes_4_0),
		ENTRY(mercury__base_typeclass_info__generate_llds_2_0));
END_MODULE

Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(base_typeclass_info_module2)
	init_entry(mercury__base_typeclass_info__make_instance_string_2_0);
	init_label(mercury__base_typeclass_info__make_instance_string_2_0_i2);
BEGIN_CODE

/* code for predicate 'make_instance_string'/2 in mode 0 */
Define_entry(mercury__base_typeclass_info__make_instance_string_2_0);
	MR_incr_sp_push_msg(1, "base_typeclass_info:make_instance_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_4);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__base_typeclass_info__make_instance_string_2_0_i2,
		ENTRY(mercury__base_typeclass_info__make_instance_string_2_0));
Define_label(mercury__base_typeclass_info__make_instance_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__make_instance_string_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__base_typeclass_info__make_instance_string_2_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_comp_gen_c_data_0;
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(base_typeclass_info_module3)
	init_entry(mercury__base_typeclass_info__gen_infos_for_classes_4_0);
	init_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i4);
	init_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i5);
	init_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i3);
BEGIN_CODE

/* code for predicate 'gen_infos_for_classes'/4 in mode 0 */
Define_static(mercury__base_typeclass_info__gen_infos_for_classes_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i3);
	MR_incr_sp_push_msg(4, "base_typeclass_info:gen_infos_for_classes/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0),
		mercury__base_typeclass_info__gen_infos_for_classes_4_0_i4,
		STATIC(mercury__base_typeclass_info__gen_infos_for_classes_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_classes_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	localcall(mercury__base_typeclass_info__gen_infos_for_classes_4_0,
		LABEL(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i5),
		STATIC(mercury__base_typeclass_info__gen_infos_for_classes_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i5);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_classes_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_comp_gen_c_data_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__base_typeclass_info__gen_infos_for_classes_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_classes_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__status_defined_in_this_module_2_0);

BEGIN_MODULE(base_typeclass_info_module4)
	init_entry(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i4);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i8);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i9);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i10);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i11);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i5);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i3);
	init_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i2);
BEGIN_CODE

/* code for predicate 'gen_infos_for_instance_list'/4 in mode 0 */
Define_static(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i3);
	MR_incr_sp_push_msg(8, "base_typeclass_info:gen_infos_for_instance_list/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_tempr2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(7) = MR_tempr2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__base_typeclass_info__gen_infos_for_instance_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0,
		LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i4),
		STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	}
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 4) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i2);
	r2 = MR_stackvar(3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(3) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_pred__status_defined_in_this_module_2_0),
		mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i8,
		STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i8);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_4);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i9,
		STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i9);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i10,
		STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i10);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__base_typeclass_info__gen_infos_for_instance_list_4_0, "origin_lost_in_value_number");
	r3 = r2;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r1;
	r4 = MR_stackvar(7);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0),
		mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i11,
		STATIC(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	}
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i11);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__gen_infos_for_instance_list_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__base_typeclass_info__gen_infos_for_instance_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_typeclass_info__common_5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i5);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__base_typeclass_info__gen_infos_for_instance_list_4_0_i2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__hlds_module__module_info_classes_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
Declare_entry(mercury__map__lookup_3_0);

BEGIN_MODULE(base_typeclass_info_module5)
	init_entry(mercury__base_typeclass_info__gen_rvals_and_procs_6_0);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i4);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i3);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i5);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i6);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i7);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i8);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i9);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i10);
	init_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i11);
BEGIN_CODE

/* code for predicate 'gen_rvals_and_procs'/6 in mode 0 */
Define_static(mercury__base_typeclass_info__gen_rvals_and_procs_6_0);
	MR_incr_sp_push_msg(5, "base_typeclass_info:gen_rvals_and_procs/6");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i3);
	r1 = (Word) MR_string_const("pred_proc_ids should have been filled in by check_typeclass.m", 61);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i4,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i4);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i5,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i5);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_9);
	r4 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(4), (Integer) 0) = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i6,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	}
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i6);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	MR_stackvar(3) = r1;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__base_typeclass_info__construct_pred_addrs_3_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i7,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i7);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_classes_2_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i8,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i8);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i9,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i9);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i10,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i10);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_10);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i11,
		STATIC(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
Define_label(mercury__base_typeclass_info__gen_rvals_and_procs_6_0_i11);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__gen_rvals_and_procs_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__gen_rvals_and_procs_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_util__make_entry_label_5_0);

BEGIN_MODULE(base_typeclass_info_module6)
	init_entry(mercury__base_typeclass_info__construct_pred_addrs_3_0);
	init_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i4);
	init_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i5);
	init_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i3);
BEGIN_CODE

/* code for predicate 'construct_pred_addrs'/3 in mode 0 */
Define_static(mercury__base_typeclass_info__construct_pred_addrs_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__base_typeclass_info__construct_pred_addrs_3_0_i3);
	MR_incr_sp_push_msg(3, "base_typeclass_info:construct_pred_addrs/3");
	MR_stackvar(3) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_util__make_entry_label_5_0),
		mercury__base_typeclass_info__construct_pred_addrs_3_0_i4,
		STATIC(mercury__base_typeclass_info__construct_pred_addrs_3_0));
	}
Define_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__construct_pred_addrs_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__base_typeclass_info__construct_pred_addrs_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__base_typeclass_info__construct_pred_addrs_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__base_typeclass_info__construct_pred_addrs_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r3;
	localcall(mercury__base_typeclass_info__construct_pred_addrs_3_0,
		LABEL(mercury__base_typeclass_info__construct_pred_addrs_3_0_i5),
		STATIC(mercury__base_typeclass_info__construct_pred_addrs_3_0));
	}
Define_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__construct_pred_addrs_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__construct_pred_addrs_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__base_typeclass_info__construct_pred_addrs_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__prog_io__sym_name_and_args_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_3_0);
Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(base_typeclass_info_module7)
	init_entry(mercury__base_typeclass_info__type_to_string_2_0);
	init_label(mercury__base_typeclass_info__type_to_string_2_0_i3);
	init_label(mercury__base_typeclass_info__type_to_string_2_0_i5);
	init_label(mercury__base_typeclass_info__type_to_string_2_0_i6);
	init_label(mercury__base_typeclass_info__type_to_string_2_0_i7);
	init_label(mercury__base_typeclass_info__type_to_string_2_0_i2);
BEGIN_CODE

/* code for predicate 'type_to_string'/2 in mode 0 */
Define_static(mercury__base_typeclass_info__type_to_string_2_0);
	MR_incr_sp_push_msg(2, "base_typeclass_info:type_to_string/2");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__prog_io__sym_name_and_args_3_0),
		mercury__base_typeclass_info__type_to_string_2_0_i3,
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
Define_label(mercury__base_typeclass_info__type_to_string_2_0_i3);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__type_to_string_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__base_typeclass_info__type_to_string_2_0_i2);
	MR_stackvar(1) = r3;
	r1 = r2;
	r2 = (Word) MR_string_const("__", 2);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_3_0),
		mercury__base_typeclass_info__type_to_string_2_0_i5,
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
Define_label(mercury__base_typeclass_info__type_to_string_2_0_i5);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__type_to_string_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_base_typeclass_info__common_1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__base_typeclass_info__type_to_string_2_0_i6,
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
Define_label(mercury__base_typeclass_info__type_to_string_2_0_i6);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__type_to_string_2_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__base_typeclass_info__type_to_string_2_0_i7,
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
Define_label(mercury__base_typeclass_info__type_to_string_2_0_i7);
	update_prof_current_proc(LABEL(mercury__base_typeclass_info__type_to_string_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__type_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__type_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("__arity", 7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__base_typeclass_info__type_to_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_base_typeclass_info__common_11);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
	}
Define_label(mercury__base_typeclass_info__type_to_string_2_0_i2);
	r1 = (Word) MR_string_const("base_typeclass_info__type_to_string: invalid type", 49);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__base_typeclass_info__type_to_string_2_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__base_typeclass_info_maybe_bunch_0(void)
{
	base_typeclass_info_module0();
	base_typeclass_info_module1();
	base_typeclass_info_module2();
	base_typeclass_info_module3();
	base_typeclass_info_module4();
	base_typeclass_info_module5();
	base_typeclass_info_module6();
	base_typeclass_info_module7();
}

#endif

void mercury__base_typeclass_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__base_typeclass_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__base_typeclass_info_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
