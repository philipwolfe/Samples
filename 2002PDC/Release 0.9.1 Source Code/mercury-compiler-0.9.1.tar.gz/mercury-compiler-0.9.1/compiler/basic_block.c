/*
** Automatically generated from `basic_block.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__basic_block__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___basic_block__block_info_0__ua0_2_0);
Define_extern_entry(mercury__basic_block__create_basic_blocks_6_0);
Declare_label(mercury__basic_block__create_basic_blocks_6_0_i2);
Declare_label(mercury__basic_block__create_basic_blocks_6_0_i3);
Declare_label(mercury__basic_block__create_basic_blocks_6_0_i4);
Declare_label(mercury__basic_block__create_basic_blocks_6_0_i5);
Define_extern_entry(mercury__basic_block__flatten_basic_blocks_3_0);
Declare_label(mercury__basic_block__flatten_basic_blocks_3_0_i4);
Declare_label(mercury__basic_block__flatten_basic_blocks_3_0_i5);
Declare_label(mercury__basic_block__flatten_basic_blocks_3_0_i3);
Declare_static(mercury__basic_block__build_block_map_7_0);
Declare_label(mercury__basic_block__build_block_map_7_0_i4);
Declare_label(mercury__basic_block__build_block_map_7_0_i7);
Declare_label(mercury__basic_block__build_block_map_7_0_i8);
Declare_label(mercury__basic_block__build_block_map_7_0_i10);
Declare_label(mercury__basic_block__build_block_map_7_0_i12);
Declare_label(mercury__basic_block__build_block_map_7_0_i13);
Declare_label(mercury__basic_block__build_block_map_7_0_i14);
Declare_label(mercury__basic_block__build_block_map_7_0_i9);
Declare_label(mercury__basic_block__build_block_map_7_0_i20);
Declare_label(mercury__basic_block__build_block_map_7_0_i23);
Declare_label(mercury__basic_block__build_block_map_7_0_i24);
Declare_label(mercury__basic_block__build_block_map_7_0_i3);
Declare_static(mercury__basic_block__take_until_end_of_block_3_0);
Declare_label(mercury__basic_block__take_until_end_of_block_3_0_i3);
Declare_label(mercury__basic_block__take_until_end_of_block_3_0_i4);
Declare_label(mercury__basic_block__take_until_end_of_block_3_0_i7);
Declare_label(mercury__basic_block__take_until_end_of_block_3_0_i6);
Declare_label(mercury__basic_block__take_until_end_of_block_3_0_i8);
Define_extern_entry(mercury____Unify___basic_block__block_map_0_0);
Define_extern_entry(mercury____Index___basic_block__block_map_0_0);
Define_extern_entry(mercury____Compare___basic_block__block_map_0_0);
Define_extern_entry(mercury____Unify___basic_block__block_info_0_0);
Declare_label(mercury____Unify___basic_block__block_info_0_0_i2);
Declare_label(mercury____Unify___basic_block__block_info_0_0_i4);
Declare_label(mercury____Unify___basic_block__block_info_0_0_i6);
Declare_label(mercury____Unify___basic_block__block_info_0_0_i8);
Declare_label(mercury____Unify___basic_block__block_info_0_0_i1);
Define_extern_entry(mercury____Index___basic_block__block_info_0_0);
Define_extern_entry(mercury____Compare___basic_block__block_info_0_0);
Declare_label(mercury____Compare___basic_block__block_info_0_0_i3);
Declare_label(mercury____Compare___basic_block__block_info_0_0_i7);
Declare_label(mercury____Compare___basic_block__block_info_0_0_i11);
Declare_label(mercury____Compare___basic_block__block_info_0_0_i15);
Declare_label(mercury____Compare___basic_block__block_info_0_0_i22);

const struct MR_TypeCtorInfo_struct mercury_data_basic_block__type_ctor_info_block_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_basic_block__type_ctor_info_block_map_0;

static const struct mercury_data_basic_block__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_basic_block__common_0;

static const struct mercury_data_basic_block__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_basic_block__common_1;

static const struct mercury_data_basic_block__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_basic_block__common_2;

static const struct mercury_data_basic_block__common_3_struct {
	Word * f1;
}  mercury_data_basic_block__common_3;

static const struct mercury_data_basic_block__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_basic_block__common_4;

static const struct mercury_data_basic_block__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_basic_block__common_5;

static const struct mercury_data_basic_block__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_basic_block__common_6;

static const struct mercury_data_basic_block__common_7_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_basic_block__common_7;

static const struct mercury_data_basic_block__type_ctor_functors_block_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_basic_block__type_ctor_functors_block_map_0;

static const struct mercury_data_basic_block__type_ctor_layout_block_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_basic_block__type_ctor_layout_block_map_0;

static const struct mercury_data_basic_block__type_ctor_functors_block_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_basic_block__type_ctor_functors_block_info_0;

static const struct mercury_data_basic_block__type_ctor_layout_block_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_basic_block__type_ctor_layout_block_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_basic_block__type_ctor_info_block_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___basic_block__block_info_0_0),
	ENTRY(mercury____Index___basic_block__block_info_0_0),
	ENTRY(mercury____Compare___basic_block__block_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_basic_block__type_ctor_functors_block_info_0,
	(Word *) &mercury_data_basic_block__type_ctor_layout_block_info_0,
	MR_string_const("basic_block", 11),
	MR_string_const("block_info", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_basic_block__type_ctor_info_block_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___basic_block__block_map_0_0),
	ENTRY(mercury____Index___basic_block__block_map_0_0),
	ENTRY(mercury____Compare___basic_block__block_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_basic_block__type_ctor_functors_block_map_0,
	(Word *) &mercury_data_basic_block__type_ctor_layout_block_map_0,
	MR_string_const("basic_block", 11),
	MR_string_const("block_map", 9),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_basic_block__common_0_struct mercury_data_basic_block__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;
static const struct mercury_data_basic_block__common_1_struct mercury_data_basic_block__common_1 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_llds__type_ctor_info_label_0,
	(Word *) &mercury_data_basic_block__type_ctor_info_block_info_0
};

static const struct mercury_data_basic_block__common_2_struct mercury_data_basic_block__common_2 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_1)
};

static const struct mercury_data_basic_block__common_3_struct mercury_data_basic_block__common_3 = {
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_basic_block__common_4_struct mercury_data_basic_block__common_4 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0)
};

static const struct mercury_data_basic_block__common_5_struct mercury_data_basic_block__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_basic_block__common_6_struct mercury_data_basic_block__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

static const struct mercury_data_basic_block__common_7_struct mercury_data_basic_block__common_7 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_6),
	MR_string_const("block_info", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_basic_block__type_ctor_functors_block_map_0_struct mercury_data_basic_block__type_ctor_functors_block_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_1)
};

static const struct mercury_data_basic_block__type_ctor_layout_block_map_0_struct mercury_data_basic_block__type_ctor_layout_block_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_basic_block__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_basic_block__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_basic_block__common_2),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_basic_block__common_2)
};

static const struct mercury_data_basic_block__type_ctor_functors_block_info_0_struct mercury_data_basic_block__type_ctor_functors_block_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_7)
};

static const struct mercury_data_basic_block__type_ctor_layout_block_info_0_struct mercury_data_basic_block__type_ctor_layout_block_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_basic_block__common_7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(basic_block_module0)
	init_entry(mercury____Index___basic_block__block_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___basic_block__block_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___basic_block__block_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__get_prologue_5_0);
Declare_entry(mercury__opt_util__new_label_no_3_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(basic_block_module1)
	init_entry(mercury__basic_block__create_basic_blocks_6_0);
	init_label(mercury__basic_block__create_basic_blocks_6_0_i2);
	init_label(mercury__basic_block__create_basic_blocks_6_0_i3);
	init_label(mercury__basic_block__create_basic_blocks_6_0_i4);
	init_label(mercury__basic_block__create_basic_blocks_6_0_i5);
BEGIN_CODE

/* code for predicate 'create_basic_blocks'/6 in mode 0 */
Define_entry(mercury__basic_block__create_basic_blocks_6_0);
	MR_incr_sp_push_msg(5, "basic_block:create_basic_blocks/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__opt_util__get_prologue_5_0),
		mercury__basic_block__create_basic_blocks_6_0_i2,
		ENTRY(mercury__basic_block__create_basic_blocks_6_0));
Define_label(mercury__basic_block__create_basic_blocks_6_0_i2);
	update_prof_current_proc(LABEL(mercury__basic_block__create_basic_blocks_6_0));
	MR_stackvar(2) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__basic_block__create_basic_blocks_6_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(1);
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = (Integer) 1000;
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	call_localret(ENTRY(mercury__opt_util__new_label_no_3_0),
		mercury__basic_block__create_basic_blocks_6_0_i3,
		ENTRY(mercury__basic_block__create_basic_blocks_6_0));
	}
Define_label(mercury__basic_block__create_basic_blocks_6_0_i3);
	update_prof_current_proc(LABEL(mercury__basic_block__create_basic_blocks_6_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__basic_block__create_basic_blocks_6_0_i4,
		ENTRY(mercury__basic_block__create_basic_blocks_6_0));
Define_label(mercury__basic_block__create_basic_blocks_6_0_i4);
	update_prof_current_proc(LABEL(mercury__basic_block__create_basic_blocks_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__basic_block__build_block_map_7_0),
		mercury__basic_block__create_basic_blocks_6_0_i5,
		ENTRY(mercury__basic_block__create_basic_blocks_6_0));
Define_label(mercury__basic_block__create_basic_blocks_6_0_i5);
	update_prof_current_proc(LABEL(mercury__basic_block__create_basic_blocks_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r5 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(basic_block_module2)
	init_entry(mercury__basic_block__flatten_basic_blocks_3_0);
	init_label(mercury__basic_block__flatten_basic_blocks_3_0_i4);
	init_label(mercury__basic_block__flatten_basic_blocks_3_0_i5);
	init_label(mercury__basic_block__flatten_basic_blocks_3_0_i3);
BEGIN_CODE

/* code for predicate 'flatten_basic_blocks'/3 in mode 0 */
Define_entry(mercury__basic_block__flatten_basic_blocks_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__basic_block__flatten_basic_blocks_3_0_i3);
	MR_incr_sp_push_msg(3, "basic_block:flatten_basic_blocks/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__basic_block__flatten_basic_blocks_3_0,
		LABEL(mercury__basic_block__flatten_basic_blocks_3_0_i4),
		ENTRY(mercury__basic_block__flatten_basic_blocks_3_0));
Define_label(mercury__basic_block__flatten_basic_blocks_3_0_i4);
	update_prof_current_proc(LABEL(mercury__basic_block__flatten_basic_blocks_3_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__basic_block__flatten_basic_blocks_3_0_i5,
		ENTRY(mercury__basic_block__flatten_basic_blocks_3_0));
Define_label(mercury__basic_block__flatten_basic_blocks_3_0_i5);
	update_prof_current_proc(LABEL(mercury__basic_block__flatten_basic_blocks_3_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__basic_block__flatten_basic_blocks_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__basic_block__flatten_basic_blocks_3_0));
Define_label(mercury__basic_block__flatten_basic_blocks_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__list__last_2_0);
Declare_entry(mercury__opt_util__possible_targets_2_0);
Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(basic_block_module3)
	init_entry(mercury__basic_block__build_block_map_7_0);
	init_label(mercury__basic_block__build_block_map_7_0_i4);
	init_label(mercury__basic_block__build_block_map_7_0_i7);
	init_label(mercury__basic_block__build_block_map_7_0_i8);
	init_label(mercury__basic_block__build_block_map_7_0_i10);
	init_label(mercury__basic_block__build_block_map_7_0_i12);
	init_label(mercury__basic_block__build_block_map_7_0_i13);
	init_label(mercury__basic_block__build_block_map_7_0_i14);
	init_label(mercury__basic_block__build_block_map_7_0_i9);
	init_label(mercury__basic_block__build_block_map_7_0_i20);
	init_label(mercury__basic_block__build_block_map_7_0_i23);
	init_label(mercury__basic_block__build_block_map_7_0_i24);
	init_label(mercury__basic_block__build_block_map_7_0_i3);
BEGIN_CODE

/* code for predicate 'build_block_map'/7 in mode 0 */
Define_static(mercury__basic_block__build_block_map_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i3);
	MR_incr_sp_push_msg(8, "basic_block:build_block_map/7");
	MR_stackvar(8) = (Word) MR_succip;
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i4);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r4;
	call_localret(STATIC(mercury__basic_block__take_until_end_of_block_3_0),
		mercury__basic_block__build_block_map_7_0_i7,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(MR_stackvar(3), MR_mktag(0), (Integer) 2, mercury__basic_block__build_block_map_7_0, "llds:label/0");
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 1) = r4;
	r5 = MR_stackvar(3);
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(0), (Integer) 2, mercury__basic_block__build_block_map_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__basic_block__build_block_map_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 0) = r2;
	MR_stackvar(5) = ((Integer) r4 + (Integer) 1);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(STATIC(mercury__basic_block__take_until_end_of_block_3_0),
		mercury__basic_block__build_block_map_7_0_i7,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i7);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	localcall(mercury__basic_block__build_block_map_7_0,
		LABEL(mercury__basic_block__build_block_map_7_0_i8),
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i8);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	MR_stackvar(5) = r1;
	MR_stackvar(6) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0);
	r2 = MR_stackvar(2);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__list__last_2_0),
		mercury__basic_block__build_block_map_7_0_i10,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i10);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i9);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__opt_util__possible_targets_2_0),
		mercury__basic_block__build_block_map_7_0_i12,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i12);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__basic_block__build_block_map_7_0_i13,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i13);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i14);
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i14);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__basic_block__build_block_map_7_0, "basic_block:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(7);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__basic_block__build_block_map_7_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	MR_field(MR_mktag(0), r5, (Integer) 4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i23);
Define_label(mercury__basic_block__build_block_map_7_0_i14);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__basic_block__build_block_map_7_0, "basic_block:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i23);
Define_label(mercury__basic_block__build_block_map_7_0_i9);
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i20);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__basic_block__build_block_map_7_0, "basic_block:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__basic_block__build_block_map_7_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	MR_field(MR_mktag(0), r5, (Integer) 4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	GOTO_LABEL(mercury__basic_block__build_block_map_7_0_i23);
Define_label(mercury__basic_block__build_block_map_7_0_i20);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__basic_block__build_block_map_7_0, "basic_block:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
Define_label(mercury__basic_block__build_block_map_7_0_i23);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__basic_block__build_block_map_7_0_i24,
		STATIC(mercury__basic_block__build_block_map_7_0));
Define_label(mercury__basic_block__build_block_map_7_0_i24);
	update_prof_current_proc(LABEL(mercury__basic_block__build_block_map_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__basic_block__build_block_map_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(5);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__basic_block__build_block_map_7_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r4;
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__can_instr_branch_away_2_0);

BEGIN_MODULE(basic_block_module4)
	init_entry(mercury__basic_block__take_until_end_of_block_3_0);
	init_label(mercury__basic_block__take_until_end_of_block_3_0_i3);
	init_label(mercury__basic_block__take_until_end_of_block_3_0_i4);
	init_label(mercury__basic_block__take_until_end_of_block_3_0_i7);
	init_label(mercury__basic_block__take_until_end_of_block_3_0_i6);
	init_label(mercury__basic_block__take_until_end_of_block_3_0_i8);
BEGIN_CODE

/* code for predicate 'take_until_end_of_block'/3 in mode 0 */
Define_static(mercury__basic_block__take_until_end_of_block_3_0);
	MR_incr_sp_push_msg(3, "basic_block:take_until_end_of_block/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__basic_block__take_until_end_of_block_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__basic_block__take_until_end_of_block_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__basic_block__take_until_end_of_block_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__basic_block__take_until_end_of_block_3_0_i4);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__basic_block__take_until_end_of_block_3_0_i4);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__can_instr_branch_away_2_0),
		mercury__basic_block__take_until_end_of_block_3_0_i7,
		STATIC(mercury__basic_block__take_until_end_of_block_3_0));
Define_label(mercury__basic_block__take_until_end_of_block_3_0_i7);
	update_prof_current_proc(LABEL(mercury__basic_block__take_until_end_of_block_3_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__basic_block__take_until_end_of_block_3_0_i6);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__basic_block__take_until_end_of_block_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__basic_block__take_until_end_of_block_3_0_i6);
	r1 = MR_stackvar(2);
	localcall(mercury__basic_block__take_until_end_of_block_3_0,
		LABEL(mercury__basic_block__take_until_end_of_block_3_0_i8),
		STATIC(mercury__basic_block__take_until_end_of_block_3_0));
Define_label(mercury__basic_block__take_until_end_of_block_3_0_i8);
	update_prof_current_proc(LABEL(mercury__basic_block__take_until_end_of_block_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__basic_block__take_until_end_of_block_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(basic_block_module5)
	init_entry(mercury____Unify___basic_block__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___basic_block__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___basic_block__block_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(basic_block_module6)
	init_entry(mercury____Index___basic_block__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___basic_block__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___basic_block__block_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(basic_block_module7)
	init_entry(mercury____Compare___basic_block__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___basic_block__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_basic_block__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___basic_block__block_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___llds__label_0_0);
Declare_entry(mercury____Unify___std_util__pair_2_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);

BEGIN_MODULE(basic_block_module8)
	init_entry(mercury____Unify___basic_block__block_info_0_0);
	init_label(mercury____Unify___basic_block__block_info_0_0_i2);
	init_label(mercury____Unify___basic_block__block_info_0_0_i4);
	init_label(mercury____Unify___basic_block__block_info_0_0_i6);
	init_label(mercury____Unify___basic_block__block_info_0_0_i8);
	init_label(mercury____Unify___basic_block__block_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___basic_block__block_info_0_0);
	MR_incr_sp_push_msg(9, "basic_block:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury____Unify___basic_block__block_info_0_0_i2,
		ENTRY(mercury____Unify___basic_block__block_info_0_0));
Define_label(mercury____Unify___basic_block__block_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___basic_block__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___basic_block__block_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_instr_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___basic_block__block_info_0_0_i4,
		ENTRY(mercury____Unify___basic_block__block_info_0_0));
Define_label(mercury____Unify___basic_block__block_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___basic_block__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___basic_block__block_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___basic_block__block_info_0_0_i6,
		ENTRY(mercury____Unify___basic_block__block_info_0_0));
Define_label(mercury____Unify___basic_block__block_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___basic_block__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___basic_block__block_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___basic_block__block_info_0_0_i8,
		ENTRY(mercury____Unify___basic_block__block_info_0_0));
Define_label(mercury____Unify___basic_block__block_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___basic_block__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___basic_block__block_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___basic_block__block_info_0_0));
Define_label(mercury____Unify___basic_block__block_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(basic_block_module9)
	init_entry(mercury____Index___basic_block__block_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___basic_block__block_info_0_0);
	tailcall(STATIC(mercury____Index___basic_block__block_info_0__ua0_2_0),
		ENTRY(mercury____Index___basic_block__block_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___llds__label_0_0);
Declare_entry(mercury____Compare___std_util__pair_2_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);

BEGIN_MODULE(basic_block_module10)
	init_entry(mercury____Compare___basic_block__block_info_0_0);
	init_label(mercury____Compare___basic_block__block_info_0_0_i3);
	init_label(mercury____Compare___basic_block__block_info_0_0_i7);
	init_label(mercury____Compare___basic_block__block_info_0_0_i11);
	init_label(mercury____Compare___basic_block__block_info_0_0_i15);
	init_label(mercury____Compare___basic_block__block_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___basic_block__block_info_0_0);
	MR_incr_sp_push_msg(9, "basic_block:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___llds__label_0_0),
		mercury____Compare___basic_block__block_info_0_0_i3,
		ENTRY(mercury____Compare___basic_block__block_info_0_0));
Define_label(mercury____Compare___basic_block__block_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___basic_block__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___basic_block__block_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_instr_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___basic_block__block_info_0_0_i7,
		ENTRY(mercury____Compare___basic_block__block_info_0_0));
Define_label(mercury____Compare___basic_block__block_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___basic_block__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___basic_block__block_info_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_basic_block__common_0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___basic_block__block_info_0_0_i11,
		ENTRY(mercury____Compare___basic_block__block_info_0_0));
Define_label(mercury____Compare___basic_block__block_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___basic_block__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___basic_block__block_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___basic_block__block_info_0_0_i15,
		ENTRY(mercury____Compare___basic_block__block_info_0_0));
Define_label(mercury____Compare___basic_block__block_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___basic_block__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___basic_block__block_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___basic_block__block_info_0_0));
Define_label(mercury____Compare___basic_block__block_info_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__basic_block_maybe_bunch_0(void)
{
	basic_block_module0();
	basic_block_module1();
	basic_block_module2();
	basic_block_module3();
	basic_block_module4();
	basic_block_module5();
	basic_block_module6();
	basic_block_module7();
	basic_block_module8();
	basic_block_module9();
	basic_block_module10();
}

#endif

void mercury__basic_block__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__basic_block__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__basic_block_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_basic_block__type_ctor_info_block_info_0,
			basic_block__block_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_basic_block__type_ctor_info_block_map_0,
			basic_block__block_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
