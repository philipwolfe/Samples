/*
** Automatically generated from `builtin_ops.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__builtin_ops__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury____Unify___builtin_ops__unary_op_0_0);
Declare_label(mercury____Unify___builtin_ops__unary_op_0_0_i1);
Define_extern_entry(mercury____Index___builtin_ops__unary_op_0_0);
Define_extern_entry(mercury____Compare___builtin_ops__unary_op_0_0);
Define_extern_entry(mercury____Unify___builtin_ops__binary_op_0_0);
Declare_label(mercury____Unify___builtin_ops__binary_op_0_0_i1);
Define_extern_entry(mercury____Index___builtin_ops__binary_op_0_0);
Define_extern_entry(mercury____Compare___builtin_ops__binary_op_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_builtin_ops__type_ctor_info_binary_op_0;

const struct MR_TypeCtorInfo_struct mercury_data_builtin_ops__type_ctor_info_unary_op_0;

static const struct mercury_data_builtin_ops__common_0_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
}  mercury_data_builtin_ops__common_0;

static const struct mercury_data_builtin_ops__common_1_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
	String f13;
	String f14;
	String f15;
	String f16;
	String f17;
	String f18;
	String f19;
	String f20;
	String f21;
	String f22;
	String f23;
	String f24;
	String f25;
	String f26;
	String f27;
	String f28;
	String f29;
	String f30;
	String f31;
	String f32;
	String f33;
	String f34;
	String f35;
	String f36;
	String f37;
}  mercury_data_builtin_ops__common_1;

static const struct mercury_data_builtin_ops__type_ctor_functors_unary_op_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_builtin_ops__type_ctor_functors_unary_op_0;

static const struct mercury_data_builtin_ops__type_ctor_layout_unary_op_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_builtin_ops__type_ctor_layout_unary_op_0;

static const struct mercury_data_builtin_ops__type_ctor_functors_binary_op_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_builtin_ops__type_ctor_functors_binary_op_0;

static const struct mercury_data_builtin_ops__type_ctor_layout_binary_op_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_builtin_ops__type_ctor_layout_binary_op_0;

const struct MR_TypeCtorInfo_struct mercury_data_builtin_ops__type_ctor_info_binary_op_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___builtin_ops__binary_op_0_0),
	ENTRY(mercury____Index___builtin_ops__binary_op_0_0),
	ENTRY(mercury____Compare___builtin_ops__binary_op_0_0),
	(Integer) 0,
	(Word *) &mercury_data_builtin_ops__type_ctor_functors_binary_op_0,
	(Word *) &mercury_data_builtin_ops__type_ctor_layout_binary_op_0,
	MR_string_const("builtin_ops", 11),
	MR_string_const("binary_op", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_builtin_ops__type_ctor_info_unary_op_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___builtin_ops__unary_op_0_0),
	ENTRY(mercury____Index___builtin_ops__unary_op_0_0),
	ENTRY(mercury____Compare___builtin_ops__unary_op_0_0),
	(Integer) 0,
	(Word *) &mercury_data_builtin_ops__type_ctor_functors_unary_op_0,
	(Word *) &mercury_data_builtin_ops__type_ctor_layout_unary_op_0,
	MR_string_const("builtin_ops", 11),
	MR_string_const("unary_op", 8),
	(Integer) 3
};

static const struct mercury_data_builtin_ops__common_0_struct mercury_data_builtin_ops__common_0 = {
	(Integer) 1,
	(Integer) 10,
	MR_string_const("mktag", 5),
	MR_string_const("tag", 3),
	MR_string_const("unmktag", 7),
	MR_string_const("mkbody", 6),
	MR_string_const("body", 4),
	MR_string_const("unmkbody", 8),
	MR_string_const("cast_to_unsigned", 16),
	MR_string_const("hash_string", 11),
	MR_string_const("bitwise_complement", 18),
	MR_string_const("not", 3)
};

static const struct mercury_data_builtin_ops__common_1_struct mercury_data_builtin_ops__common_1 = {
	(Integer) 1,
	(Integer) 35,
	MR_string_const("+", 1),
	MR_string_const("-", 1),
	MR_string_const("*", 1),
	MR_string_const("/", 1),
	MR_string_const("mod", 3),
	MR_string_const("<<", 2),
	MR_string_const(">>", 2),
	MR_string_const("&", 1),
	MR_string_const("|", 1),
	MR_string_const("^", 1),
	MR_string_const("and", 3),
	MR_string_const("or", 2),
	MR_string_const("eq", 2),
	MR_string_const("ne", 2),
	MR_string_const("array_index", 11),
	MR_string_const("str_eq", 6),
	MR_string_const("str_ne", 6),
	MR_string_const("str_lt", 6),
	MR_string_const("str_gt", 6),
	MR_string_const("str_le", 6),
	MR_string_const("str_ge", 6),
	MR_string_const("<", 1),
	MR_string_const(">", 1),
	MR_string_const("<=", 2),
	MR_string_const(">=", 2),
	MR_string_const("float_plus", 10),
	MR_string_const("float_minus", 11),
	MR_string_const("float_times", 11),
	MR_string_const("float_divide", 12),
	MR_string_const("float_eq", 8),
	MR_string_const("float_ne", 8),
	MR_string_const("float_lt", 8),
	MR_string_const("float_gt", 8),
	MR_string_const("float_le", 8),
	MR_string_const("float_ge", 8)
};

static const struct mercury_data_builtin_ops__type_ctor_functors_unary_op_0_struct mercury_data_builtin_ops__type_ctor_functors_unary_op_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_0)
};

static const struct mercury_data_builtin_ops__type_ctor_layout_unary_op_0_struct mercury_data_builtin_ops__type_ctor_layout_unary_op_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_0)
};

static const struct mercury_data_builtin_ops__type_ctor_functors_binary_op_0_struct mercury_data_builtin_ops__type_ctor_functors_binary_op_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_1)
};

static const struct mercury_data_builtin_ops__type_ctor_layout_binary_op_0_struct mercury_data_builtin_ops__type_ctor_layout_binary_op_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_builtin_ops__common_1)
};


BEGIN_MODULE(builtin_ops_module0)
	init_entry(mercury____Unify___builtin_ops__unary_op_0_0);
	init_label(mercury____Unify___builtin_ops__unary_op_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___builtin_ops__unary_op_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___builtin_ops__unary_op_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___builtin_ops__unary_op_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(builtin_ops_module1)
	init_entry(mercury____Index___builtin_ops__unary_op_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___builtin_ops__unary_op_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(builtin_ops_module2)
	init_entry(mercury____Compare___builtin_ops__unary_op_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___builtin_ops__unary_op_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___builtin_ops__unary_op_0_0));
END_MODULE


BEGIN_MODULE(builtin_ops_module3)
	init_entry(mercury____Unify___builtin_ops__binary_op_0_0);
	init_label(mercury____Unify___builtin_ops__binary_op_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___builtin_ops__binary_op_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___builtin_ops__binary_op_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___builtin_ops__binary_op_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(builtin_ops_module4)
	init_entry(mercury____Index___builtin_ops__binary_op_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___builtin_ops__binary_op_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(builtin_ops_module5)
	init_entry(mercury____Compare___builtin_ops__binary_op_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___builtin_ops__binary_op_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___builtin_ops__binary_op_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__builtin_ops_maybe_bunch_0(void)
{
	builtin_ops_module0();
	builtin_ops_module1();
	builtin_ops_module2();
	builtin_ops_module3();
	builtin_ops_module4();
	builtin_ops_module5();
}

#endif

void mercury__builtin_ops__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__builtin_ops__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__builtin_ops_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_builtin_ops__type_ctor_info_binary_op_0,
			builtin_ops__binary_op_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_builtin_ops__type_ctor_info_unary_op_0,
			builtin_ops__unary_op_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
