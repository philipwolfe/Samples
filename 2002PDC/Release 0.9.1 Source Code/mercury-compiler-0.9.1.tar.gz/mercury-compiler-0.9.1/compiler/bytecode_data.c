/*
** Automatically generated from `bytecode_data.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__bytecode_data__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__bytecode_data__output_int_bytes__ua1_5_0);
Declare_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i1001);
Declare_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i3);
Declare_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i4);
Declare_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i5);
Declare_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i2);
Declare_static(mercury__bytecode_data__output_int_bytes__ua0_5_0);
Declare_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i1001);
Declare_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i3);
Declare_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i4);
Declare_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i5);
Declare_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i2);
Declare_static(mercury__bytecode_data__output_padding_zeros__ua1_4_0);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i1001);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i3);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i2);
Declare_static(mercury__bytecode_data__output_padding_zeros__ua0_4_0);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i1001);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i3);
Declare_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i2);
Declare_static(mercury__bytecode_data__IntroducedFrom__pred__int_to_byte_list__138__1_3_0);
Define_extern_entry(mercury__bytecode_data__output_string_3_0);
Declare_label(mercury__bytecode_data__output_string_3_0_i2);
Define_extern_entry(mercury__bytecode_data__string_to_byte_list_2_0);
Declare_label(mercury__bytecode_data__string_to_byte_list_2_0_i2);
Declare_label(mercury__bytecode_data__string_to_byte_list_2_0_i3);
Define_extern_entry(mercury__bytecode_data__output_byte_3_0);
Declare_label(mercury__bytecode_data__output_byte_3_0_i2);
Define_extern_entry(mercury__bytecode_data__output_int_3_0);
Declare_label(mercury__bytecode_data__output_int_3_0_i2);
Declare_label(mercury__bytecode_data__output_int_3_0_i3);
Define_extern_entry(mercury__bytecode_data__int_to_byte_list_2_0);
Declare_label(mercury__bytecode_data__int_to_byte_list_2_0_i2);
Declare_label(mercury__bytecode_data__int_to_byte_list_2_0_i3);
Define_extern_entry(mercury__bytecode_data__output_int32_3_0);
Define_extern_entry(mercury__bytecode_data__int32_to_byte_list_2_0);
Define_extern_entry(mercury__bytecode_data__output_short_3_0);
Define_extern_entry(mercury__bytecode_data__short_to_byte_list_2_0);
Define_extern_entry(mercury__bytecode_data__output_float_3_0);
Declare_label(mercury__bytecode_data__output_float_3_0_i2);
Declare_label(mercury__bytecode_data__output_float_3_0_i4);
Declare_label(mercury__bytecode_data__output_float_3_0_i6);
Declare_label(mercury__bytecode_data__output_float_3_0_i8);
Declare_label(mercury__bytecode_data__output_float_3_0_i10);
Declare_label(mercury__bytecode_data__output_float_3_0_i12);
Declare_label(mercury__bytecode_data__output_float_3_0_i14);
Declare_label(mercury__bytecode_data__output_float_3_0_i16);
Declare_label(mercury__bytecode_data__output_float_3_0_i18);
Declare_label(mercury__bytecode_data__output_float_3_0_i20);
Declare_label(mercury__bytecode_data__output_float_3_0_i22);
Declare_label(mercury__bytecode_data__output_float_3_0_i24);
Declare_label(mercury__bytecode_data__output_float_3_0_i26);
Declare_label(mercury__bytecode_data__output_float_3_0_i28);
Declare_label(mercury__bytecode_data__output_float_3_0_i30);
Define_extern_entry(mercury__bytecode_data__float_to_byte_list_2_0);
Declare_static(mercury__bytecode_data__output_int_4_0);
Declare_label(mercury__bytecode_data__output_int_4_0_i2);
Declare_label(mercury__bytecode_data__output_int_4_0_i5);
Declare_label(mercury__bytecode_data__output_int_4_0_i6);
Declare_label(mercury__bytecode_data__output_int_4_0_i8);
Declare_label(mercury__bytecode_data__output_int_4_0_i9);
Declare_label(mercury__bytecode_data__output_int_4_0_i3);
Declare_label(mercury__bytecode_data__output_int_4_0_i4);
Declare_label(mercury__bytecode_data__output_int_4_0_i10);
Declare_label(mercury__bytecode_data__output_int_4_0_i11);
Declare_label(mercury__bytecode_data__output_int_4_0_i12);
Declare_label(mercury__bytecode_data__output_int_4_0_i13);
Declare_static(mercury__bytecode_data__int_to_byte_list_3_0);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i2);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i5);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i6);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i8);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i3);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i4);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i10);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i11);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i12);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i13);
Declare_label(mercury__bytecode_data__int_to_byte_list_3_0_i14);
Declare_static(mercury__bytecode_data__float_to_float64_bytes_9_0);

static const struct mercury_data_bytecode_data__common_0_struct {
	Word * f1;
}  mercury_data_bytecode_data__common_0;

static const struct mercury_data_bytecode_data__common_1_struct {
	Word * f1;
}  mercury_data_bytecode_data__common_1;

static const struct mercury_data_bytecode_data__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_bytecode_data__common_2;

static const struct mercury_data_bytecode_data__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_bytecode_data__common_3;

static const struct mercury_data_bytecode_data__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_bytecode_data__common_4;

static const struct mercury_data_bytecode_data__common_5_struct {
	Word * f1;
}  mercury_data_bytecode_data__common_5;

static const struct mercury_data_bytecode_data__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_bytecode_data__common_6;

static const struct mercury_data_bytecode_data__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_bytecode_data__common_7;

static const struct mercury_data_bytecode_data__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_bytecode_data__common_8;

static const struct mercury_data_bytecode_data__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_bytecode_data__common_9;

static const struct mercury_data_bytecode_data__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_bytecode_data__common_10;

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_bytecode_data__common_0_struct mercury_data_bytecode_data__common_0 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_bytecode_data__common_1_struct mercury_data_bytecode_data__common_1 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_bytecode_data__common_2_struct mercury_data_bytecode_data__common_2 = {
	(Integer) 0,
	MR_string_const("char", 4),
	MR_string_const("char", 4),
	MR_string_const("to_int", 6),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_1)
};

Declare_entry(mercury__char__to_int_2_0);
static const struct mercury_data_bytecode_data__common_3_struct mercury_data_bytecode_data__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_2),
	ENTRY(mercury__char__to_int_2_0),
	(Integer) 0
};

static const struct mercury_data_bytecode_data__common_4_struct mercury_data_bytecode_data__common_4 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_bytecode_data__common_5_struct mercury_data_bytecode_data__common_5 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_bytecode_data__common_6_struct mercury_data_bytecode_data__common_6 = {
	(Integer) 0,
	MR_string_const("io", 2),
	MR_string_const("io", 2),
	MR_string_const("write_byte", 10),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_5)
};

Declare_entry(mercury__io__write_byte_3_0);
static const struct mercury_data_bytecode_data__common_7_struct mercury_data_bytecode_data__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_6),
	ENTRY(mercury__io__write_byte_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_bytecode_data__common_8_struct mercury_data_bytecode_data__common_8 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_bytecode_data__common_9_struct mercury_data_bytecode_data__common_9 = {
	(Integer) 0,
	MR_string_const("bytecode_data", 13),
	MR_string_const("bytecode_data", 13),
	MR_string_const("IntroducedFrom__pred__int_to_byte_list__138__1", 46),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_8)
};

static const struct mercury_data_bytecode_data__common_10_struct mercury_data_bytecode_data__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_9),
	STATIC(mercury__bytecode_data__IntroducedFrom__pred__int_to_byte_list__138__1_3_0),
	(Integer) 0
};

Declare_entry(mercury__fn__f_105_110_116_95_95_62_62_2_0);
Declare_entry(mercury__fn__int__mod_2_0);
Declare_entry(mercury__do_call_closure);

BEGIN_MODULE(bytecode_data_module0)
	init_entry(mercury__bytecode_data__output_int_bytes__ua1_5_0);
	init_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i1001);
	init_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i3);
	init_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i4);
	init_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i5);
	init_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i2);
BEGIN_CODE

/* code for predicate 'output_int_bytes__ua1'/5 in mode 0 */
Define_static(mercury__bytecode_data__output_int_bytes__ua1_5_0);
	MR_incr_sp_push_msg(5, "bytecode_data:output_int_bytes__ua1/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i1001);
	if (((Integer) r2 < (Integer) 0))
		GOTO_LABEL(mercury__bytecode_data__output_int_bytes__ua1_5_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r3;
	r2 = ((Integer) r2 * (Integer) 8);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_62_62_2_0),
		mercury__bytecode_data__output_int_bytes__ua1_5_0_i3,
		STATIC(mercury__bytecode_data__output_int_bytes__ua1_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua1_5_0));
	r2 = (Integer) 256;
	call_localret(ENTRY(mercury__fn__int__mod_2_0),
		mercury__bytecode_data__output_int_bytes__ua1_5_0_i4,
		STATIC(mercury__bytecode_data__output_int_bytes__ua1_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua1_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = ((Integer) r2 - (Integer) 1);
	r4 = r1;
	r5 = MR_stackvar(4);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__bytecode_data__output_int_bytes__ua1_5_0_i5,
		STATIC(mercury__bytecode_data__output_int_bytes__ua1_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua1_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__bytecode_data__output_int_bytes__ua1_5_0_i1001);
Define_label(mercury__bytecode_data__output_int_bytes__ua1_5_0_i2);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(bytecode_data_module1)
	init_entry(mercury__bytecode_data__output_int_bytes__ua0_5_0);
	init_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i1001);
	init_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i3);
	init_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i4);
	init_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i5);
	init_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i2);
BEGIN_CODE

/* code for predicate 'output_int_bytes__ua0'/5 in mode 0 */
Define_static(mercury__bytecode_data__output_int_bytes__ua0_5_0);
	MR_incr_sp_push_msg(5, "bytecode_data:output_int_bytes__ua0/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i1001);
	if (((Integer) r2 < (Integer) 0))
		GOTO_LABEL(mercury__bytecode_data__output_int_bytes__ua0_5_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r3;
	r2 = ((Integer) r2 * (Integer) 8);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_62_62_2_0),
		mercury__bytecode_data__output_int_bytes__ua0_5_0_i3,
		STATIC(mercury__bytecode_data__output_int_bytes__ua0_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua0_5_0));
	r2 = (Integer) 256;
	call_localret(ENTRY(mercury__fn__int__mod_2_0),
		mercury__bytecode_data__output_int_bytes__ua0_5_0_i4,
		STATIC(mercury__bytecode_data__output_int_bytes__ua0_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua0_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = ((Integer) r2 - (Integer) 1);
	r4 = r1;
	r5 = MR_stackvar(4);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__bytecode_data__output_int_bytes__ua0_5_0_i5,
		STATIC(mercury__bytecode_data__output_int_bytes__ua0_5_0));
Define_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_bytes__ua0_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__bytecode_data__output_int_bytes__ua0_5_0_i1001);
Define_label(mercury__bytecode_data__output_int_bytes__ua0_5_0_i2);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(bytecode_data_module2)
	init_entry(mercury__bytecode_data__output_padding_zeros__ua1_4_0);
	init_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i1001);
	init_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i3);
	init_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i2);
BEGIN_CODE

/* code for predicate 'output_padding_zeros__ua1'/4 in mode 0 */
Define_static(mercury__bytecode_data__output_padding_zeros__ua1_4_0);
	MR_incr_sp_push_msg(3, "bytecode_data:output_padding_zeros__ua1/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i1001);
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r4 = (Integer) 0;
	r5 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__bytecode_data__output_padding_zeros__ua1_4_0_i3,
		STATIC(mercury__bytecode_data__output_padding_zeros__ua1_4_0));
Define_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_padding_zeros__ua1_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = ((Integer) MR_stackvar(2) + (Integer) -1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i1001);
Define_label(mercury__bytecode_data__output_padding_zeros__ua1_4_0_i2);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(bytecode_data_module3)
	init_entry(mercury__bytecode_data__output_padding_zeros__ua0_4_0);
	init_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i1001);
	init_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i3);
	init_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i2);
BEGIN_CODE

/* code for predicate 'output_padding_zeros__ua0'/4 in mode 0 */
Define_static(mercury__bytecode_data__output_padding_zeros__ua0_4_0);
	MR_incr_sp_push_msg(3, "bytecode_data:output_padding_zeros__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i1001);
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r4 = (Integer) 0;
	r5 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__bytecode_data__output_padding_zeros__ua0_4_0_i3,
		STATIC(mercury__bytecode_data__output_padding_zeros__ua0_4_0));
Define_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_padding_zeros__ua0_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = ((Integer) MR_stackvar(2) + (Integer) -1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i1001);
Define_label(mercury__bytecode_data__output_padding_zeros__ua0_4_0_i2);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(bytecode_data_module4)
	init_entry(mercury__bytecode_data__IntroducedFrom__pred__int_to_byte_list__138__1_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__int_to_byte_list__138__1'/3 in mode 0 */
Define_static(mercury__bytecode_data__IntroducedFrom__pred__int_to_byte_list__138__1_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__bytecode_data__IntroducedFrom__pred__int_to_byte_list__138__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	proceed();
END_MODULE

Declare_entry(mercury__io__write_bytes_3_0);

BEGIN_MODULE(bytecode_data_module5)
	init_entry(mercury__bytecode_data__output_string_3_0);
	init_label(mercury__bytecode_data__output_string_3_0_i2);
BEGIN_CODE

/* code for predicate 'output_string'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_string_3_0);
	MR_incr_sp_push_msg(1, "bytecode_data:output_string/3");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__write_bytes_3_0),
		mercury__bytecode_data__output_string_3_0_i2,
		ENTRY(mercury__bytecode_data__output_string_3_0));
Define_label(mercury__bytecode_data__output_string_3_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_string_3_0));
	r2 = r1;
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__write_byte_3_0),
		ENTRY(mercury__bytecode_data__output_string_3_0));
END_MODULE

Declare_entry(mercury__string__to_char_list_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(bytecode_data_module6)
	init_entry(mercury__bytecode_data__string_to_byte_list_2_0);
	init_label(mercury__bytecode_data__string_to_byte_list_2_0_i2);
	init_label(mercury__bytecode_data__string_to_byte_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'string_to_byte_list'/2 in mode 0 */
Define_entry(mercury__bytecode_data__string_to_byte_list_2_0);
	MR_incr_sp_push_msg(1, "bytecode_data:string_to_byte_list/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__bytecode_data__string_to_byte_list_2_0_i2,
		ENTRY(mercury__bytecode_data__string_to_byte_list_2_0));
Define_label(mercury__bytecode_data__string_to_byte_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__string_to_byte_list_2_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_character_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__bytecode_data__string_to_byte_list_2_0_i3,
		ENTRY(mercury__bytecode_data__string_to_byte_list_2_0));
Define_label(mercury__bytecode_data__string_to_byte_list_2_0_i3);
	update_prof_current_proc(LABEL(mercury__bytecode_data__string_to_byte_list_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_bytecode_data__common_4);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__bytecode_data__string_to_byte_list_2_0));
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(bytecode_data_module7)
	init_entry(mercury__bytecode_data__output_byte_3_0);
	init_label(mercury__bytecode_data__output_byte_3_0_i2);
BEGIN_CODE

/* code for predicate 'output_byte'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_byte_3_0);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_byte_3_0_i2);
	tailcall(ENTRY(mercury__io__write_byte_3_0),
		ENTRY(mercury__bytecode_data__output_byte_3_0));
Define_label(mercury__bytecode_data__output_byte_3_0_i2);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__bytecode_data__output_byte_3_0));
END_MODULE

Declare_entry(mercury__int__bits_per_int_1_0);

BEGIN_MODULE(bytecode_data_module8)
	init_entry(mercury__bytecode_data__output_int_3_0);
	init_label(mercury__bytecode_data__output_int_3_0_i2);
	init_label(mercury__bytecode_data__output_int_3_0_i3);
BEGIN_CODE

/* code for predicate 'output_int'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_int_3_0);
	MR_incr_sp_push_msg(3, "bytecode_data:output_int/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__int__bits_per_int_1_0),
		mercury__bytecode_data__output_int_3_0_i2,
		ENTRY(mercury__bytecode_data__output_int_3_0));
Define_label(mercury__bytecode_data__output_int_3_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_3_0));
	if (((Integer) r1 <= (Integer) 64))
		GOTO_LABEL(mercury__bytecode_data__output_int_3_0_i3);
	r1 = (Word) MR_string_const("size of int is larger than size of bytecode integer.", 52);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__bytecode_data__output_int_3_0));
Define_label(mercury__bytecode_data__output_int_3_0_i3);
	r1 = (Integer) 64;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__bytecode_data__output_int_4_0),
		ENTRY(mercury__bytecode_data__output_int_3_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module9)
	init_entry(mercury__bytecode_data__int_to_byte_list_2_0);
	init_label(mercury__bytecode_data__int_to_byte_list_2_0_i2);
	init_label(mercury__bytecode_data__int_to_byte_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'int_to_byte_list'/2 in mode 0 */
Define_entry(mercury__bytecode_data__int_to_byte_list_2_0);
	MR_incr_sp_push_msg(2, "bytecode_data:int_to_byte_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__int__bits_per_int_1_0),
		mercury__bytecode_data__int_to_byte_list_2_0_i2,
		ENTRY(mercury__bytecode_data__int_to_byte_list_2_0));
Define_label(mercury__bytecode_data__int_to_byte_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_2_0));
	if (((Integer) r1 <= (Integer) 64))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_2_0_i3);
	r1 = (Word) MR_string_const("size of int is larger than size of bytecode integer.", 52);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__bytecode_data__int_to_byte_list_2_0));
Define_label(mercury__bytecode_data__int_to_byte_list_2_0_i3);
	r1 = (Integer) 64;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__bytecode_data__int_to_byte_list_3_0),
		ENTRY(mercury__bytecode_data__int_to_byte_list_2_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module10)
	init_entry(mercury__bytecode_data__output_int32_3_0);
BEGIN_CODE

/* code for predicate 'output_int32'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_int32_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Integer) 32;
	tailcall(STATIC(mercury__bytecode_data__output_int_4_0),
		ENTRY(mercury__bytecode_data__output_int32_3_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module11)
	init_entry(mercury__bytecode_data__int32_to_byte_list_2_0);
BEGIN_CODE

/* code for predicate 'int32_to_byte_list'/2 in mode 0 */
Define_entry(mercury__bytecode_data__int32_to_byte_list_2_0);
	r2 = r1;
	r1 = (Integer) 32;
	tailcall(STATIC(mercury__bytecode_data__int_to_byte_list_3_0),
		ENTRY(mercury__bytecode_data__int32_to_byte_list_2_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module12)
	init_entry(mercury__bytecode_data__output_short_3_0);
BEGIN_CODE

/* code for predicate 'output_short'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_short_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Integer) 16;
	tailcall(STATIC(mercury__bytecode_data__output_int_4_0),
		ENTRY(mercury__bytecode_data__output_short_3_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module13)
	init_entry(mercury__bytecode_data__short_to_byte_list_2_0);
BEGIN_CODE

/* code for predicate 'short_to_byte_list'/2 in mode 0 */
Define_entry(mercury__bytecode_data__short_to_byte_list_2_0);
	r2 = r1;
	r1 = (Integer) 16;
	tailcall(STATIC(mercury__bytecode_data__int_to_byte_list_3_0),
		ENTRY(mercury__bytecode_data__short_to_byte_list_2_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module14)
	init_entry(mercury__bytecode_data__output_float_3_0);
	init_label(mercury__bytecode_data__output_float_3_0_i2);
	init_label(mercury__bytecode_data__output_float_3_0_i4);
	init_label(mercury__bytecode_data__output_float_3_0_i6);
	init_label(mercury__bytecode_data__output_float_3_0_i8);
	init_label(mercury__bytecode_data__output_float_3_0_i10);
	init_label(mercury__bytecode_data__output_float_3_0_i12);
	init_label(mercury__bytecode_data__output_float_3_0_i14);
	init_label(mercury__bytecode_data__output_float_3_0_i16);
	init_label(mercury__bytecode_data__output_float_3_0_i18);
	init_label(mercury__bytecode_data__output_float_3_0_i20);
	init_label(mercury__bytecode_data__output_float_3_0_i22);
	init_label(mercury__bytecode_data__output_float_3_0_i24);
	init_label(mercury__bytecode_data__output_float_3_0_i26);
	init_label(mercury__bytecode_data__output_float_3_0_i28);
	init_label(mercury__bytecode_data__output_float_3_0_i30);
BEGIN_CODE

/* code for predicate 'output_float'/3 in mode 0 */
Define_entry(mercury__bytecode_data__output_float_3_0);
	{
	Float	FloatVal;
	Integer	B0;
	Integer	B1;
	Integer	B2;
	Integer	B3;
	Integer	B4;
	Integer	B5;
	Integer	B6;
	Integer	B7;
#define MR_PROC_LABEL mercury__bytecode_data__output_float_3_0
	FloatVal = word_to_float(r1);
	MR_OBTAIN_GLOBAL_LOCK("float_to_float64_bytes");
{
#line 244 "bytecode_data.m"


	{
		Float64		float64;
		unsigned char	*raw_mem_p;

		float64 = (Float64) FloatVal;
		raw_mem_p = (unsigned char*) &float64;

		#if defined(MR_BIG_ENDIAN)
			B0 = raw_mem_p[0];
			B1 = raw_mem_p[1];
			B2 = raw_mem_p[2];
			B3 = raw_mem_p[3];
			B4 = raw_mem_p[4];
			B5 = raw_mem_p[5];
			B6 = raw_mem_p[6];
			B7 = raw_mem_p[7];
		#elif defined(MR_LITTLE_ENDIAN)
			B7 = raw_mem_p[0];
			B6 = raw_mem_p[1];
			B5 = raw_mem_p[2];
			B4 = raw_mem_p[3];
			B3 = raw_mem_p[4];
			B2 = raw_mem_p[5];
			B1 = raw_mem_p[6];
			B0 = raw_mem_p[7];
		#else
			#error	Weird-endian architecture
		#endif
	}
	
	;}
#line 759 "bytecode_data.c"
	MR_RELEASE_GLOBAL_LOCK("float_to_float64_bytes");
	r3 = B0;
	r4 = B1;
	r5 = B2;
	r6 = B3;
	r7 = B4;
	r8 = B5;
	r9 = B6;
	r10 = B7;
#undef MR_PROC_LABEL

	}
	MR_incr_sp_push_msg(8, "bytecode_data:output_float/3");
	MR_stackvar(8) = (Word) MR_succip;
	if (((Integer) r3 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i2);
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r8;
	MR_stackvar(6) = r9;
	MR_stackvar(7) = r10;
	r1 = r3;
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i4,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i2);
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r8;
	MR_stackvar(6) = r9;
	MR_stackvar(7) = r10;
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i4,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i4);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i6);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i8,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i6);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i8,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i10);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i12,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i10);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i12,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i12);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i14);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i16,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i14);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i16,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i16);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i18);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i20,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i18);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i20,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i20);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i22);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i24,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i22);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i24,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i24);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i26);
	call_localret(ENTRY(mercury__io__write_byte_3_0),
		mercury__bytecode_data__output_float_3_0_i28,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i26);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_float_3_0_i28,
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i28);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_float_3_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	if (((Integer) r1 >= (Integer) 256))
		GOTO_LABEL(mercury__bytecode_data__output_float_3_0_i30);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__write_byte_3_0),
		ENTRY(mercury__bytecode_data__output_float_3_0));
Define_label(mercury__bytecode_data__output_float_3_0_i30);
	r1 = (Word) MR_string_const("byte does not fit in eight bits", 31);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__bytecode_data__output_float_3_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module15)
	init_entry(mercury__bytecode_data__float_to_byte_list_2_0);
BEGIN_CODE

/* code for predicate 'float_to_byte_list'/2 in mode 0 */
Define_entry(mercury__bytecode_data__float_to_byte_list_2_0);
	{
	Float	FloatVal;
	Integer	B0;
	Integer	B1;
	Integer	B2;
	Integer	B3;
	Integer	B4;
	Integer	B5;
	Integer	B6;
	Integer	B7;
#define MR_PROC_LABEL mercury__bytecode_data__float_to_byte_list_2_0
	FloatVal = word_to_float(r1);
	MR_OBTAIN_GLOBAL_LOCK("float_to_float64_bytes");
{
#line 244 "bytecode_data.m"


	{
		Float64		float64;
		unsigned char	*raw_mem_p;

		float64 = (Float64) FloatVal;
		raw_mem_p = (unsigned char*) &float64;

		#if defined(MR_BIG_ENDIAN)
			B0 = raw_mem_p[0];
			B1 = raw_mem_p[1];
			B2 = raw_mem_p[2];
			B3 = raw_mem_p[3];
			B4 = raw_mem_p[4];
			B5 = raw_mem_p[5];
			B6 = raw_mem_p[6];
			B7 = raw_mem_p[7];
		#elif defined(MR_LITTLE_ENDIAN)
			B7 = raw_mem_p[0];
			B6 = raw_mem_p[1];
			B5 = raw_mem_p[2];
			B4 = raw_mem_p[3];
			B3 = raw_mem_p[4];
			B2 = raw_mem_p[5];
			B1 = raw_mem_p[6];
			B0 = raw_mem_p[7];
		#else
			#error	Weird-endian architecture
		#endif
	}
	
	;}
#line 956 "bytecode_data.c"
	MR_RELEASE_GLOBAL_LOCK("float_to_float64_bytes");
	r2 = B0;
	r3 = B1;
	r4 = B2;
	r5 = B3;
	r6 = B4;
	r7 = B5;
	r8 = B6;
	r9 = B7;
#undef MR_PROC_LABEL

	}
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = r3;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = r4;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = r5;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = r6;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = r7;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = r8;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__bytecode_data__float_to_byte_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r16, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r16, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r10;
	proceed();
END_MODULE

Declare_entry(mercury__int__pow_3_0);
Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(bytecode_data_module16)
	init_entry(mercury__bytecode_data__output_int_4_0);
	init_label(mercury__bytecode_data__output_int_4_0_i2);
	init_label(mercury__bytecode_data__output_int_4_0_i5);
	init_label(mercury__bytecode_data__output_int_4_0_i6);
	init_label(mercury__bytecode_data__output_int_4_0_i8);
	init_label(mercury__bytecode_data__output_int_4_0_i9);
	init_label(mercury__bytecode_data__output_int_4_0_i3);
	init_label(mercury__bytecode_data__output_int_4_0_i4);
	init_label(mercury__bytecode_data__output_int_4_0_i10);
	init_label(mercury__bytecode_data__output_int_4_0_i11);
	init_label(mercury__bytecode_data__output_int_4_0_i12);
	init_label(mercury__bytecode_data__output_int_4_0_i13);
BEGIN_CODE

/* code for predicate 'output_int'/4 in mode 0 */
Define_static(mercury__bytecode_data__output_int_4_0);
	MR_incr_sp_push_msg(6, "bytecode_data:output_int/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__int__bits_per_int_1_0),
		mercury__bytecode_data__output_int_4_0_i2,
		STATIC(mercury__bytecode_data__output_int_4_0));
Define_label(mercury__bytecode_data__output_int_4_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_4_0));
	if (((Integer) MR_stackvar(1) >= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i4);
	MR_stackvar(4) = r1;
	r1 = (Integer) 2;
	r2 = ((Integer) MR_stackvar(1) + (Integer) -1);
	call_localret(ENTRY(mercury__int__pow_3_0),
		mercury__bytecode_data__output_int_4_0_i5,
		STATIC(mercury__bytecode_data__output_int_4_0));
Define_label(mercury__bytecode_data__output_int_4_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_4_0));
	r2 = MR_stackvar(2);
	if (((Integer) r2 >= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i6);
	if (((Integer) r2 >= ((Integer) 0 - (Integer) r1)))
		GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i3);
Define_label(mercury__bytecode_data__output_int_4_0_i6);
	r1 = (Word) MR_string_const("error: bytecode_data__output_int: %d does not fit in %d bits", 60);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__bytecode_data__output_int_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__bytecode_data__output_int_4_0, "string:poly_type/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__bytecode_data__output_int_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__bytecode_data__output_int_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__bytecode_data__output_int_4_0_i8,
		STATIC(mercury__bytecode_data__output_int_4_0));
	}
Define_label(mercury__bytecode_data__output_int_4_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_4_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__output_int_4_0_i9,
		STATIC(mercury__bytecode_data__output_int_4_0));
Define_label(mercury__bytecode_data__output_int_4_0_i9);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_4_0));
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i10);
Define_label(mercury__bytecode_data__output_int_4_0_i3);
	r1 = MR_stackvar(4);
Define_label(mercury__bytecode_data__output_int_4_0_i4);
	r3 = MR_stackvar(3);
	if (((Integer) MR_stackvar(1) <= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i11);
	r2 = (((Integer) MR_stackvar(1) - (Integer) r1) / (Integer) 8);
	MR_stackvar(4) = r1;
	GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i12);
Define_label(mercury__bytecode_data__output_int_4_0_i10);
	if (((Integer) MR_stackvar(1) <= (Integer) MR_stackvar(4)))
		GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i11);
	r2 = (((Integer) MR_stackvar(1) - (Integer) MR_stackvar(4)) / (Integer) 8);
	GOTO_LABEL(mercury__bytecode_data__output_int_4_0_i12);
Define_label(mercury__bytecode_data__output_int_4_0_i11);
	r2 = (Integer) 0;
Define_label(mercury__bytecode_data__output_int_4_0_i12);
	MR_stackvar(5) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_7);
	call_localret(STATIC(mercury__bytecode_data__output_padding_zeros__ua1_4_0),
		mercury__bytecode_data__output_int_4_0_i13,
		STATIC(mercury__bytecode_data__output_int_4_0));
Define_label(mercury__bytecode_data__output_int_4_0_i13);
	update_prof_current_proc(LABEL(mercury__bytecode_data__output_int_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_7);
	r2 = ((((Integer) MR_stackvar(1) / (Integer) 8) - (Integer) MR_stackvar(5)) + (Integer) -1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__bytecode_data__output_int_bytes__ua1_5_0),
		STATIC(mercury__bytecode_data__output_int_4_0));
END_MODULE

Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(bytecode_data_module17)
	init_entry(mercury__bytecode_data__int_to_byte_list_3_0);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i2);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i5);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i6);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i8);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i3);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i4);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i10);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i11);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i12);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i13);
	init_label(mercury__bytecode_data__int_to_byte_list_3_0_i14);
BEGIN_CODE

/* code for predicate 'int_to_byte_list'/3 in mode 0 */
Define_static(mercury__bytecode_data__int_to_byte_list_3_0);
	MR_incr_sp_push_msg(5, "bytecode_data:int_to_byte_list/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__int__bits_per_int_1_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i2,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	if (((Integer) MR_stackvar(1) >= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i4);
	MR_stackvar(3) = r1;
	r1 = (Integer) 2;
	r2 = ((Integer) MR_stackvar(1) + (Integer) -1);
	call_localret(ENTRY(mercury__int__pow_3_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i5,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	r2 = MR_stackvar(2);
	if (((Integer) r2 >= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i6);
	if (((Integer) r2 >= ((Integer) 0 - (Integer) r1)))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i3);
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i6);
	r1 = (Word) MR_string_const("error: bytecode_data__output_int: %d does not fit in %d bits", 60);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__bytecode_data__int_to_byte_list_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__bytecode_data__int_to_byte_list_3_0, "string:poly_type/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__bytecode_data__int_to_byte_list_3_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__bytecode_data__int_to_byte_list_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i8,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
	}
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i8);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i10,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i3);
	r1 = MR_stackvar(3);
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i4);
	if (((Integer) MR_stackvar(1) <= (Integer) r1))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i11);
	r3 = MR_stackvar(1);
	r2 = (((Integer) r3 - (Integer) r1) / (Integer) 8);
	MR_stackvar(3) = r1;
	GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i12);
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i10);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	if (((Integer) MR_stackvar(1) <= (Integer) MR_stackvar(3)))
		GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i11);
	r2 = (((Integer) MR_stackvar(1) - (Integer) MR_stackvar(3)) / (Integer) 8);
	GOTO_LABEL(mercury__bytecode_data__int_to_byte_list_3_0_i12);
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i11);
	r2 = (Integer) 0;
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i12);
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_10);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__bytecode_data__output_padding_zeros__ua0_4_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i13,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i13);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_bytecode_data__common_10);
	r2 = ((((Integer) MR_stackvar(1) / (Integer) 8) - (Integer) MR_stackvar(4)) + (Integer) -1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__bytecode_data__output_int_bytes__ua0_5_0),
		mercury__bytecode_data__int_to_byte_list_3_0_i14,
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
Define_label(mercury__bytecode_data__int_to_byte_list_3_0_i14);
	update_prof_current_proc(LABEL(mercury__bytecode_data__int_to_byte_list_3_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__bytecode_data__int_to_byte_list_3_0));
END_MODULE


BEGIN_MODULE(bytecode_data_module18)
	init_entry(mercury__bytecode_data__float_to_float64_bytes_9_0);
BEGIN_CODE

/* code for predicate 'float_to_float64_bytes'/9 in mode 0 */
Define_static(mercury__bytecode_data__float_to_float64_bytes_9_0);
	{
	Float	FloatVal;
	Integer	B0;
	Integer	B1;
	Integer	B2;
	Integer	B3;
	Integer	B4;
	Integer	B5;
	Integer	B6;
	Integer	B7;
#define MR_PROC_LABEL mercury__bytecode_data__float_to_float64_bytes_9_0
	FloatVal = word_to_float(r1);
	MR_OBTAIN_GLOBAL_LOCK("float_to_float64_bytes");
{
#line 244 "bytecode_data.m"


	{
		Float64		float64;
		unsigned char	*raw_mem_p;

		float64 = (Float64) FloatVal;
		raw_mem_p = (unsigned char*) &float64;

		#if defined(MR_BIG_ENDIAN)
			B0 = raw_mem_p[0];
			B1 = raw_mem_p[1];
			B2 = raw_mem_p[2];
			B3 = raw_mem_p[3];
			B4 = raw_mem_p[4];
			B5 = raw_mem_p[5];
			B6 = raw_mem_p[6];
			B7 = raw_mem_p[7];
		#elif defined(MR_LITTLE_ENDIAN)
			B7 = raw_mem_p[0];
			B6 = raw_mem_p[1];
			B5 = raw_mem_p[2];
			B4 = raw_mem_p[3];
			B3 = raw_mem_p[4];
			B2 = raw_mem_p[5];
			B1 = raw_mem_p[6];
			B0 = raw_mem_p[7];
		#else
			#error	Weird-endian architecture
		#endif
	}
	
	;}
#line 1266 "bytecode_data.c"
	MR_RELEASE_GLOBAL_LOCK("float_to_float64_bytes");
	r2 = B0;
	r3 = B1;
	r4 = B2;
	r5 = B3;
	r6 = B4;
	r7 = B5;
	r8 = B6;
	r9 = B7;
#undef MR_PROC_LABEL

	}
	r1 = r2;
	r10 = r2;
	r2 = r3;
	r11 = r3;
	r3 = r4;
	r12 = r4;
	r4 = r5;
	r13 = r5;
	r5 = r6;
	r14 = r6;
	r6 = r7;
	r15 = r7;
	r7 = r8;
	r16 = r8;
	r8 = r9;
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__bytecode_data_maybe_bunch_0(void)
{
	bytecode_data_module0();
	bytecode_data_module1();
	bytecode_data_module2();
	bytecode_data_module3();
	bytecode_data_module4();
	bytecode_data_module5();
	bytecode_data_module6();
	bytecode_data_module7();
	bytecode_data_module8();
	bytecode_data_module9();
	bytecode_data_module10();
	bytecode_data_module11();
	bytecode_data_module12();
	bytecode_data_module13();
	bytecode_data_module14();
	bytecode_data_module15();
	bytecode_data_module16();
	bytecode_data_module17();
	bytecode_data_module18();
}

#endif

void mercury__bytecode_data__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__bytecode_data__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__bytecode_data_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
