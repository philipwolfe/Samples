/*
** Automatically generated from `c_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__c_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i4);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i5);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i6);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i7);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
Declare_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i2);
Define_extern_entry(mercury__c_util__set_line_num_4_0);
Declare_label(mercury__c_util__set_line_num_4_0_i2);
Declare_label(mercury__c_util__set_line_num_4_0_i8);
Declare_label(mercury__c_util__set_line_num_4_0_i9);
Declare_label(mercury__c_util__set_line_num_4_0_i10);
Declare_label(mercury__c_util__set_line_num_4_0_i11);
Declare_label(mercury__c_util__set_line_num_4_0_i4);
Define_extern_entry(mercury__c_util__reset_line_num_2_0);
Declare_label(mercury__c_util__reset_line_num_2_0_i2);
Declare_label(mercury__c_util__reset_line_num_2_0_i3);
Declare_label(mercury__c_util__reset_line_num_2_0_i4);
Declare_label(mercury__c_util__reset_line_num_2_0_i10);
Declare_label(mercury__c_util__reset_line_num_2_0_i11);
Declare_label(mercury__c_util__reset_line_num_2_0_i12);
Declare_label(mercury__c_util__reset_line_num_2_0_i13);
Declare_label(mercury__c_util__reset_line_num_2_0_i6);
Define_extern_entry(mercury__c_util__output_quoted_string_3_0);
Declare_label(mercury__c_util__output_quoted_string_3_0_i1006);
Declare_label(mercury__c_util__output_quoted_string_3_0_i4);
Declare_label(mercury__c_util__output_quoted_string_3_0_i8);
Declare_label(mercury__c_util__output_quoted_string_3_0_i9);
Declare_label(mercury__c_util__output_quoted_string_3_0_i10);
Declare_label(mercury__c_util__output_quoted_string_3_0_i11);
Declare_label(mercury__c_util__output_quoted_string_3_0_i7);
Declare_label(mercury__c_util__output_quoted_string_3_0_i13);
Declare_label(mercury__c_util__output_quoted_string_3_0_i6);
Declare_label(mercury__c_util__output_quoted_string_3_0_i15);
Declare_label(mercury__c_util__output_quoted_string_3_0_i2);
Define_extern_entry(mercury__c_util__output_quoted_multi_string_4_0);
Define_extern_entry(mercury__c_util__quote_string_2_0);
Declare_label(mercury__c_util__quote_string_2_0_i2);
Define_extern_entry(mercury__c_util__quote_char_2_0);
Declare_label(mercury__c_util__quote_char_2_0_i3);
Declare_label(mercury__c_util__quote_char_2_0_i4);
Declare_label(mercury__c_util__quote_char_2_0_i5);
Declare_label(mercury__c_util__quote_char_2_0_i6);
Declare_label(mercury__c_util__quote_char_2_0_i1);
Define_extern_entry(mercury__c_util__string_compare_op_2_0);
Declare_label(mercury__c_util__string_compare_op_2_0_i1);
Define_extern_entry(mercury__c_util__float_op_2_0);
Declare_label(mercury__c_util__float_op_2_0_i1);
Define_extern_entry(mercury__c_util__float_compare_op_2_0);
Declare_label(mercury__c_util__float_compare_op_2_0_i1);
Define_extern_entry(mercury__c_util__unary_prefix_op_2_0);
Define_extern_entry(mercury__c_util__binary_infix_op_2_0);
Declare_label(mercury__c_util__binary_infix_op_2_0_i1);
Declare_static(mercury__c_util__output_quoted_multi_string_2_5_0);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i1007);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i3);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i5);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i4);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i10);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i11);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i12);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i13);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i15);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i8);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i17);
Declare_label(mercury__c_util__output_quoted_multi_string_2_5_0_i2);
Define_extern_entry(mercury____Unify___c_util__multi_string_0_0);
Declare_label(mercury____Unify___c_util__multi_string_0_0_i1);
Define_extern_entry(mercury____Index___c_util__multi_string_0_0);
Define_extern_entry(mercury____Compare___c_util__multi_string_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_c_util__type_ctor_info_multi_string_0;

static const struct mercury_data_c_util__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_c_util__common_0;

static const struct mercury_data_c_util__common_1_struct {
	Word * f1;
}  mercury_data_c_util__common_1;

static const struct mercury_data_c_util__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_c_util__common_2;

static const struct mercury_data_c_util__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_c_util__common_3;

static const struct mercury_data_c_util__common_4_struct {
	Word * f1;
}  mercury_data_c_util__common_4;

static const struct mercury_data_c_util__common_5_struct {
	Integer f1;
	Word * f2;
}  mercury_data_c_util__common_5;

static const struct mercury_data_c_util__type_ctor_functors_multi_string_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_c_util__type_ctor_functors_multi_string_0;

static const struct mercury_data_c_util__type_ctor_layout_multi_string_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_c_util__type_ctor_layout_multi_string_0;

const struct MR_TypeCtorInfo_struct mercury_data_c_util__type_ctor_info_multi_string_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___c_util__multi_string_0_0),
	ENTRY(mercury____Index___c_util__multi_string_0_0),
	ENTRY(mercury____Compare___c_util__multi_string_0_0),
	(Integer) 6,
	(Word *) &mercury_data_c_util__type_ctor_functors_multi_string_0,
	(Word *) &mercury_data_c_util__type_ctor_layout_multi_string_0,
	MR_string_const("c_util", 6),
	MR_string_const("multi_string", 12),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_c_util__common_0_struct mercury_data_c_util__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_character_0
};

static const struct mercury_data_c_util__common_1_struct mercury_data_c_util__common_1 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

static const struct mercury_data_c_util__common_2_struct mercury_data_c_util__common_2 = {
	(Integer) 0,
	MR_string_const("c_util", 6),
	MR_string_const("c_util", 6),
	MR_string_const("IntroducedFrom__pred__quote_string__188__1", 42),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_0)
};

static const struct mercury_data_c_util__common_3_struct mercury_data_c_util__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_2),
	STATIC(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_c_util__common_4_struct mercury_data_c_util__common_4 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_c_util__common_5_struct mercury_data_c_util__common_5 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_4)
};

static const struct mercury_data_c_util__type_ctor_functors_multi_string_0_struct mercury_data_c_util__type_ctor_functors_multi_string_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_4)
};

static const struct mercury_data_c_util__type_ctor_layout_multi_string_0_struct mercury_data_c_util__type_ctor_layout_multi_string_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_c_util__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_c_util__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_c_util__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_c_util__common_5)
};


BEGIN_MODULE(c_util_module0)
	init_entry(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i4);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i5);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i6);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i7);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
	init_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__quote_string__188__1'/3 in mode 0 */
Define_static(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0);
	if (((Integer) r1 != (Integer) 8))
		GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i4);
	r1 = (Integer) 98;
	GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i4);
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i5);
	r1 = (Integer) 116;
	GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i5);
	if (((Integer) r1 != (Integer) 10))
		GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i6);
	r1 = (Integer) 110;
	GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i6);
	if (((Integer) r1 != (Integer) 34))
		GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i7);
	r1 = (Integer) 34;
	GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i7);
	if (((Integer) r1 != (Integer) 92))
		GOTO_LABEL(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i2);
	r1 = (Integer) 92;
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i3);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Integer) 92;
	proceed();
Define_label(mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0_i2);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__c_util__IntroducedFrom__pred__quote_string__188__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	proceed();
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_int_3_0);

BEGIN_MODULE(c_util_module1)
	init_entry(mercury__c_util__set_line_num_4_0);
	init_label(mercury__c_util__set_line_num_4_0_i2);
	init_label(mercury__c_util__set_line_num_4_0_i8);
	init_label(mercury__c_util__set_line_num_4_0_i9);
	init_label(mercury__c_util__set_line_num_4_0_i10);
	init_label(mercury__c_util__set_line_num_4_0_i11);
	init_label(mercury__c_util__set_line_num_4_0_i4);
BEGIN_CODE

/* code for predicate 'set_line_num'/4 in mode 0 */
Define_entry(mercury__c_util__set_line_num_4_0);
	MR_incr_sp_push_msg(4, "c_util:set_line_num/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 55;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__c_util__set_line_num_4_0_i2,
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i2);
	update_prof_current_proc(LABEL(mercury__c_util__set_line_num_4_0));
	if (((Integer) MR_stackvar(2) <= (Integer) 0))
		GOTO_LABEL(mercury__c_util__set_line_num_4_0_i4);
	if ((strcmp((char *)MR_stackvar(1), (char *)(Word) MR_string_const("", 0)) == 0))
		GOTO_LABEL(mercury__c_util__set_line_num_4_0_i4);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__c_util__set_line_num_4_0_i4);
	r1 = (Word) MR_string_const("#line ", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__c_util__set_line_num_4_0_i8,
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i8);
	update_prof_current_proc(LABEL(mercury__c_util__set_line_num_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__c_util__set_line_num_4_0_i9,
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i9);
	update_prof_current_proc(LABEL(mercury__c_util__set_line_num_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" \"", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__c_util__set_line_num_4_0_i10,
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i10);
	update_prof_current_proc(LABEL(mercury__c_util__set_line_num_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__c_util__output_quoted_string_3_0),
		mercury__c_util__set_line_num_4_0_i11,
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i11);
	update_prof_current_proc(LABEL(mercury__c_util__set_line_num_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\"\n", 2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__c_util__set_line_num_4_0));
Define_label(mercury__c_util__set_line_num_4_0_i4);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__io__get_output_line_number_3_0);
Declare_entry(mercury__io__output_stream_name_3_0);

BEGIN_MODULE(c_util_module2)
	init_entry(mercury__c_util__reset_line_num_2_0);
	init_label(mercury__c_util__reset_line_num_2_0_i2);
	init_label(mercury__c_util__reset_line_num_2_0_i3);
	init_label(mercury__c_util__reset_line_num_2_0_i4);
	init_label(mercury__c_util__reset_line_num_2_0_i10);
	init_label(mercury__c_util__reset_line_num_2_0_i11);
	init_label(mercury__c_util__reset_line_num_2_0_i12);
	init_label(mercury__c_util__reset_line_num_2_0_i13);
	init_label(mercury__c_util__reset_line_num_2_0_i6);
BEGIN_CODE

/* code for predicate 'reset_line_num'/2 in mode 0 */
Define_entry(mercury__c_util__reset_line_num_2_0);
	MR_incr_sp_push_msg(4, "c_util:reset_line_num/2");
	MR_stackvar(4) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_output_line_number_3_0),
		mercury__c_util__reset_line_num_2_0_i2,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i2);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__output_stream_name_3_0),
		mercury__c_util__reset_line_num_2_0_i3,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i3);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 55;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__c_util__reset_line_num_2_0_i4,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i4);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	if (((Integer) MR_stackvar(1) <= (Integer) 0))
		GOTO_LABEL(mercury__c_util__reset_line_num_2_0_i6);
	if ((strcmp((char *)MR_stackvar(2), (char *)(Word) MR_string_const("", 0)) == 0))
		GOTO_LABEL(mercury__c_util__reset_line_num_2_0_i6);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__c_util__reset_line_num_2_0_i6);
	r1 = (Word) MR_string_const("#line ", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__c_util__reset_line_num_2_0_i10,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i10);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	r2 = r1;
	r1 = ((Integer) MR_stackvar(1) + (Integer) 1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__c_util__reset_line_num_2_0_i11,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i11);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" \"", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__c_util__reset_line_num_2_0_i12,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i12);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__c_util__output_quoted_string_3_0),
		mercury__c_util__reset_line_num_2_0_i13,
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i13);
	update_prof_current_proc(LABEL(mercury__c_util__reset_line_num_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\"\n", 2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__c_util__reset_line_num_2_0));
Define_label(mercury__c_util__reset_line_num_2_0_i6);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__string__first_char_3_3);
Declare_entry(mercury__io__write_char_3_0);

BEGIN_MODULE(c_util_module3)
	init_entry(mercury__c_util__output_quoted_string_3_0);
	init_label(mercury__c_util__output_quoted_string_3_0_i1006);
	init_label(mercury__c_util__output_quoted_string_3_0_i4);
	init_label(mercury__c_util__output_quoted_string_3_0_i8);
	init_label(mercury__c_util__output_quoted_string_3_0_i9);
	init_label(mercury__c_util__output_quoted_string_3_0_i10);
	init_label(mercury__c_util__output_quoted_string_3_0_i11);
	init_label(mercury__c_util__output_quoted_string_3_0_i7);
	init_label(mercury__c_util__output_quoted_string_3_0_i13);
	init_label(mercury__c_util__output_quoted_string_3_0_i6);
	init_label(mercury__c_util__output_quoted_string_3_0_i15);
	init_label(mercury__c_util__output_quoted_string_3_0_i2);
BEGIN_CODE

/* code for predicate 'output_quoted_string'/3 in mode 0 */
Define_entry(mercury__c_util__output_quoted_string_3_0);
	MR_incr_sp_push_msg(4, "c_util:output_quoted_string/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__c_util__output_quoted_string_3_0_i1006);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__first_char_3_3),
		mercury__c_util__output_quoted_string_3_0_i4,
		ENTRY(mercury__c_util__output_quoted_string_3_0));
Define_label(mercury__c_util__output_quoted_string_3_0_i4);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_string_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i2);
	if (((Integer) r2 != (Integer) 8))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i8);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = (Integer) 98;
	GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i7);
Define_label(mercury__c_util__output_quoted_string_3_0_i8);
	if (((Integer) r2 != (Integer) 9))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i9);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = (Integer) 116;
	GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i7);
Define_label(mercury__c_util__output_quoted_string_3_0_i9);
	if (((Integer) r2 != (Integer) 10))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i10);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = (Integer) 110;
	GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i7);
Define_label(mercury__c_util__output_quoted_string_3_0_i10);
	if (((Integer) r2 != (Integer) 34))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i11);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = (Integer) 34;
	GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i7);
Define_label(mercury__c_util__output_quoted_string_3_0_i11);
	if (((Integer) r2 != (Integer) 92))
		GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i6);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = (Integer) 92;
Define_label(mercury__c_util__output_quoted_string_3_0_i7);
	r1 = (Integer) 92;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_string_3_0_i13,
		ENTRY(mercury__c_util__output_quoted_string_3_0));
Define_label(mercury__c_util__output_quoted_string_3_0_i13);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_string_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_string_3_0_i15,
		ENTRY(mercury__c_util__output_quoted_string_3_0));
Define_label(mercury__c_util__output_quoted_string_3_0_i6);
	MR_stackvar(2) = r3;
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_string_3_0_i15,
		ENTRY(mercury__c_util__output_quoted_string_3_0));
Define_label(mercury__c_util__output_quoted_string_3_0_i15);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_string_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__c_util__output_quoted_string_3_0_i1006);
Define_label(mercury__c_util__output_quoted_string_3_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(c_util_module4)
	init_entry(mercury__c_util__output_quoted_multi_string_4_0);
BEGIN_CODE

/* code for predicate 'output_quoted_multi_string'/4 in mode 0 */
Define_entry(mercury__c_util__output_quoted_multi_string_4_0);
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = (Integer) 0;
	tailcall(STATIC(mercury__c_util__output_quoted_multi_string_2_5_0),
		ENTRY(mercury__c_util__output_quoted_multi_string_4_0));
END_MODULE

Declare_entry(mercury__string__foldl_4_0);
Declare_entry(mercury__string__from_rev_char_list_2_0);

BEGIN_MODULE(c_util_module5)
	init_entry(mercury__c_util__quote_string_2_0);
	init_label(mercury__c_util__quote_string_2_0_i2);
BEGIN_CODE

/* code for predicate 'quote_string'/2 in mode 0 */
Define_entry(mercury__c_util__quote_string_2_0);
	MR_incr_sp_push_msg(1, "c_util:quote_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_c_util__common_3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__foldl_4_0),
		mercury__c_util__quote_string_2_0_i2,
		ENTRY(mercury__c_util__quote_string_2_0));
Define_label(mercury__c_util__quote_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__c_util__quote_string_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__from_rev_char_list_2_0),
		ENTRY(mercury__c_util__quote_string_2_0));
END_MODULE


BEGIN_MODULE(c_util_module6)
	init_entry(mercury__c_util__quote_char_2_0);
	init_label(mercury__c_util__quote_char_2_0_i3);
	init_label(mercury__c_util__quote_char_2_0_i4);
	init_label(mercury__c_util__quote_char_2_0_i5);
	init_label(mercury__c_util__quote_char_2_0_i6);
	init_label(mercury__c_util__quote_char_2_0_i1);
BEGIN_CODE

/* code for predicate 'quote_char'/2 in mode 0 */
Define_entry(mercury__c_util__quote_char_2_0);
	if (((Integer) r1 != (Integer) 8))
		GOTO_LABEL(mercury__c_util__quote_char_2_0_i3);
	r2 = (Integer) 98;
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__quote_char_2_0_i3);
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__c_util__quote_char_2_0_i4);
	r2 = (Integer) 116;
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__quote_char_2_0_i4);
	if (((Integer) r1 != (Integer) 10))
		GOTO_LABEL(mercury__c_util__quote_char_2_0_i5);
	r2 = (Integer) 110;
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__quote_char_2_0_i5);
	if (((Integer) r1 != (Integer) 34))
		GOTO_LABEL(mercury__c_util__quote_char_2_0_i6);
	r2 = (Integer) 34;
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__quote_char_2_0_i6);
	if (((Integer) r1 != (Integer) 92))
		GOTO_LABEL(mercury__c_util__quote_char_2_0_i1);
	r2 = (Integer) 92;
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__quote_char_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

static const struct mercury_const_12_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_const_12 = {
	MR_string_const("==", 2),
	MR_string_const("!=", 2),
	MR_string_const("<", 1),
	MR_string_const(">", 1),
	MR_string_const("<=", 2),
	MR_string_const(">=", 2)
};

BEGIN_MODULE(c_util_module7)
	init_entry(mercury__c_util__string_compare_op_2_0);
	init_label(mercury__c_util__string_compare_op_2_0_i1);
BEGIN_CODE

/* code for predicate 'string_compare_op'/2 in mode 0 */
Define_entry(mercury__c_util__string_compare_op_2_0);
	r3 = ((Integer) r1 + (Integer) -15);
	if (((Unsigned)(r3) > (Integer) 5))
		GOTO_LABEL(mercury__c_util__string_compare_op_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_12), r3);
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__string_compare_op_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

static const struct mercury_const_13_struct {
	String f1;
	String f2;
	String f3;
	String f4;
}  mercury_const_13 = {
	MR_string_const("+", 1),
	MR_string_const("-", 1),
	MR_string_const("*", 1),
	MR_string_const("/", 1)
};

BEGIN_MODULE(c_util_module8)
	init_entry(mercury__c_util__float_op_2_0);
	init_label(mercury__c_util__float_op_2_0_i1);
BEGIN_CODE

/* code for predicate 'float_op'/2 in mode 0 */
Define_entry(mercury__c_util__float_op_2_0);
	r3 = ((Integer) r1 + (Integer) -25);
	if (((Unsigned)(r3) > (Integer) 3))
		GOTO_LABEL(mercury__c_util__float_op_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_13), r3);
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__float_op_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

static const struct mercury_const_14_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_const_14 = {
	MR_string_const("==", 2),
	MR_string_const("!=", 2),
	MR_string_const("<", 1),
	MR_string_const(">", 1),
	MR_string_const("<=", 2),
	MR_string_const(">=", 2)
};

BEGIN_MODULE(c_util_module9)
	init_entry(mercury__c_util__float_compare_op_2_0);
	init_label(mercury__c_util__float_compare_op_2_0_i1);
BEGIN_CODE

/* code for predicate 'float_compare_op'/2 in mode 0 */
Define_entry(mercury__c_util__float_compare_op_2_0);
	r3 = ((Integer) r1 + (Integer) -29);
	if (((Unsigned)(r3) > (Integer) 5))
		GOTO_LABEL(mercury__c_util__float_compare_op_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_14), r3);
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__float_compare_op_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

static const struct mercury_const_15_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
}  mercury_const_15 = {
	MR_string_const("MR_mktag", 8),
	MR_string_const("MR_tag", 6),
	MR_string_const("MR_unmktag", 10),
	MR_string_const("MR_mkbody", 9),
	MR_string_const("MR_body", 7),
	MR_string_const("MR_unmkbody", 11),
	MR_string_const("(Unsigned)", 10),
	MR_string_const("hash_string", 11),
	MR_string_const("~", 1),
	MR_string_const("!", 1)
};

BEGIN_MODULE(c_util_module10)
	init_entry(mercury__c_util__unary_prefix_op_2_0);
BEGIN_CODE

/* code for predicate 'unary_prefix_op'/2 in mode 0 */
Define_entry(mercury__c_util__unary_prefix_op_2_0);
	r1 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_15), r1);
	proceed();
END_MODULE

static const struct mercury_const_17_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
	String f13;
	String f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	String f22;
	String f23;
	String f24;
	String f25;
}  mercury_const_17 = {
	MR_string_const("+", 1),
	MR_string_const("-", 1),
	MR_string_const("*", 1),
	MR_string_const("/", 1),
	MR_string_const("%", 1),
	MR_string_const("<<", 2),
	MR_string_const(">>", 2),
	MR_string_const("&", 1),
	MR_string_const("|", 1),
	MR_string_const("^", 1),
	MR_string_const("&&", 2),
	MR_string_const("||", 2),
	MR_string_const("==", 2),
	MR_string_const("!=", 2),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("<", 1),
	MR_string_const(">", 1),
	MR_string_const("<=", 2),
	MR_string_const(">=", 2)
};

BEGIN_MODULE(c_util_module11)
	init_entry(mercury__c_util__binary_infix_op_2_0);
	init_label(mercury__c_util__binary_infix_op_2_0_i1);
BEGIN_CODE

/* code for predicate 'binary_infix_op'/2 in mode 0 */
Define_entry(mercury__c_util__binary_infix_op_2_0);
	if (!((((Integer) 1 << (Unsigned)(r1)) & (Integer) 31473663)))
		GOTO_LABEL(mercury__c_util__binary_infix_op_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_17), r1);
	r1 = TRUE;
	proceed();
Define_label(mercury__c_util__binary_infix_op_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__string__unsafe_index_3_0);
Declare_entry(mercury__char__to_int_2_1);

BEGIN_MODULE(c_util_module12)
	init_entry(mercury__c_util__output_quoted_multi_string_2_5_0);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i1007);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i3);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i5);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i4);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i10);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i11);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i12);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i13);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i15);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i8);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i17);
	init_label(mercury__c_util__output_quoted_multi_string_2_5_0_i2);
BEGIN_CODE

/* code for predicate 'output_quoted_multi_string_2'/5 in mode 0 */
Define_static(mercury__c_util__output_quoted_multi_string_2_5_0);
	MR_incr_sp_push_msg(6, "c_util:output_quoted_multi_string_2/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i1007);
	if (((Integer) r1 >= (Integer) r2))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i2);
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__string__unsafe_index_3_0),
		mercury__c_util__output_quoted_multi_string_2_5_0_i3,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i3);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_multi_string_2_5_0));
	MR_stackvar(5) = r1;
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__char__to_int_2_1),
		mercury__c_util__output_quoted_multi_string_2_5_0_i5,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_multi_string_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i4);
	r1 = (Word) MR_string_const("\\0", 2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__c_util__output_quoted_multi_string_2_5_0_i17,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i4);
	if (((Integer) MR_stackvar(5) != (Integer) 8))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i10);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = (Integer) 98;
	GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i10);
	if (((Integer) MR_stackvar(5) != (Integer) 9))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i11);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = (Integer) 116;
	GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i11);
	if (((Integer) MR_stackvar(5) != (Integer) 10))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i12);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = (Integer) 110;
	GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i12);
	if (((Integer) MR_stackvar(5) != (Integer) 34))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i13);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = (Integer) 34;
	GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i13);
	if (((Integer) MR_stackvar(5) != (Integer) 92))
		GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i8);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = (Integer) 92;
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i9);
	r1 = (Integer) 92;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_multi_string_2_5_0_i15,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_multi_string_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_multi_string_2_5_0_i17,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i8);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__c_util__output_quoted_multi_string_2_5_0_i17,
		STATIC(mercury__c_util__output_quoted_multi_string_2_5_0));
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__c_util__output_quoted_multi_string_2_5_0));
	r4 = r1;
	r1 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__c_util__output_quoted_multi_string_2_5_0_i1007);
Define_label(mercury__c_util__output_quoted_multi_string_2_5_0_i2);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(c_util_module13)
	init_entry(mercury____Unify___c_util__multi_string_0_0);
	init_label(mercury____Unify___c_util__multi_string_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___c_util__multi_string_0_0);
	if ((strcmp((char *)r1, (char *)r2) != 0))
		GOTO_LABEL(mercury____Unify___c_util__multi_string_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___c_util__multi_string_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_string_2_0);

BEGIN_MODULE(c_util_module14)
	init_entry(mercury____Index___c_util__multi_string_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___c_util__multi_string_0_0);
	tailcall(ENTRY(mercury__builtin_index_string_2_0),
		ENTRY(mercury____Index___c_util__multi_string_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(c_util_module15)
	init_entry(mercury____Compare___c_util__multi_string_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___c_util__multi_string_0_0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___c_util__multi_string_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__c_util_maybe_bunch_0(void)
{
	c_util_module0();
	c_util_module1();
	c_util_module2();
	c_util_module3();
	c_util_module4();
	c_util_module5();
	c_util_module6();
	c_util_module7();
	c_util_module8();
	c_util_module9();
	c_util_module10();
	c_util_module11();
	c_util_module12();
	c_util_module13();
	c_util_module14();
	c_util_module15();
}

#endif

void mercury__c_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__c_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__c_util_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_c_util__type_ctor_info_multi_string_0,
			c_util__multi_string_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
