/*
** Automatically generated from `call_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__call_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__call_gen__aditi_builtin_setup__ua0_6_0);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i4);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i5);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i6);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i7);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i8);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i9);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i10);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i11);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i1031);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i14);
Declare_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i15);
Declare_static(mercury__call_gen__generate_generic_call__ua0_9_0);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i2);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i3);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i4);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i5);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i6);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i7);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i8);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i9);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i10);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i11);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i12);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i13);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i14);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i15);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i16);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i17);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i19);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i20);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i21);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i22);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i23);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i24);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i25);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i26);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i27);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i28);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i29);
Declare_label(mercury__call_gen__generate_generic_call__ua0_9_0_i30);
Declare_static(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i4);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i5);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i8);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i9);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i3);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i12);
Declare_static(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0);
Declare_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i3);
Declare_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i4);
Declare_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i5);
Declare_static(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i3);
Declare_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i4);
Declare_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0);
Declare_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0_i1);
Declare_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0);
Declare_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0_i1);
Declare_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0);
Declare_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0_i1);
Declare_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0);
Declare_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0_i1);
Define_extern_entry(mercury__call_gen__generate_generic_call_9_0);
Define_extern_entry(mercury__call_gen__generate_call_8_0);
Declare_label(mercury__call_gen__generate_call_8_0_i2);
Declare_label(mercury__call_gen__generate_call_8_0_i3);
Declare_label(mercury__call_gen__generate_call_8_0_i4);
Declare_label(mercury__call_gen__generate_call_8_0_i5);
Declare_label(mercury__call_gen__generate_call_8_0_i6);
Declare_label(mercury__call_gen__generate_call_8_0_i7);
Declare_label(mercury__call_gen__generate_call_8_0_i8);
Declare_label(mercury__call_gen__generate_call_8_0_i10);
Declare_label(mercury__call_gen__generate_call_8_0_i11);
Declare_label(mercury__call_gen__generate_call_8_0_i12);
Declare_label(mercury__call_gen__generate_call_8_0_i13);
Declare_label(mercury__call_gen__generate_call_8_0_i14);
Declare_label(mercury__call_gen__generate_call_8_0_i9);
Declare_label(mercury__call_gen__generate_call_8_0_i15);
Declare_label(mercury__call_gen__generate_call_8_0_i16);
Declare_label(mercury__call_gen__generate_call_8_0_i1005);
Declare_label(mercury__call_gen__generate_call_8_0_i18);
Declare_label(mercury__call_gen__generate_call_8_0_i19);
Declare_label(mercury__call_gen__generate_call_8_0_i20);
Declare_label(mercury__call_gen__generate_call_8_0_i21);
Declare_label(mercury__call_gen__generate_call_8_0_i22);
Declare_label(mercury__call_gen__generate_call_8_0_i23);
Declare_label(mercury__call_gen__generate_call_8_0_i24);
Declare_label(mercury__call_gen__generate_call_8_0_i25);
Declare_label(mercury__call_gen__generate_call_8_0_i26);
Declare_label(mercury__call_gen__generate_call_8_0_i27);
Define_extern_entry(mercury__call_gen__generate_builtin_7_0);
Declare_label(mercury__call_gen__generate_builtin_7_0_i2);
Declare_label(mercury__call_gen__generate_builtin_7_0_i3);
Declare_label(mercury__call_gen__generate_builtin_7_0_i4);
Declare_label(mercury__call_gen__generate_builtin_7_0_i7);
Declare_label(mercury__call_gen__generate_builtin_7_0_i6);
Declare_label(mercury__call_gen__generate_builtin_7_0_i9);
Declare_label(mercury__call_gen__generate_builtin_7_0_i10);
Declare_label(mercury__call_gen__generate_builtin_7_0_i16);
Declare_label(mercury__call_gen__generate_builtin_7_0_i13);
Declare_label(mercury__call_gen__generate_builtin_7_0_i12);
Declare_label(mercury__call_gen__generate_builtin_7_0_i26);
Declare_label(mercury__call_gen__generate_builtin_7_0_i24);
Declare_label(mercury__call_gen__generate_builtin_7_0_i27);
Declare_label(mercury__call_gen__generate_builtin_7_0_i30);
Declare_label(mercury__call_gen__generate_builtin_7_0_i28);
Declare_label(mercury__call_gen__generate_builtin_7_0_i22);
Declare_label(mercury__call_gen__generate_builtin_7_0_i36);
Declare_label(mercury__call_gen__generate_builtin_7_0_i34);
Declare_label(mercury__call_gen__generate_builtin_7_0_i32);
Declare_label(mercury__call_gen__generate_builtin_7_0_i38);
Declare_label(mercury__call_gen__generate_builtin_7_0_i41);
Declare_label(mercury__call_gen__generate_builtin_7_0_i44);
Declare_label(mercury__call_gen__generate_builtin_7_0_i42);
Declare_label(mercury__call_gen__generate_builtin_7_0_i20);
Declare_label(mercury__call_gen__generate_builtin_7_0_i19);
Define_extern_entry(mercury__call_gen__partition_args_3_0);
Declare_label(mercury__call_gen__partition_args_3_0_i6);
Declare_label(mercury__call_gen__partition_args_3_0_i4);
Declare_label(mercury__call_gen__partition_args_3_0_i7);
Declare_label(mercury__call_gen__partition_args_3_0_i3);
Define_extern_entry(mercury__call_gen__input_arg_locs_2_0);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i7);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i8);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i6);
Declare_label(mercury__call_gen__input_arg_locs_2_0_i2);
Define_extern_entry(mercury__call_gen__output_arg_locs_2_0);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i7);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i8);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i6);
Declare_label(mercury__call_gen__output_arg_locs_2_0_i2);
Define_extern_entry(mercury__call_gen__save_variables_4_0);
Declare_label(mercury__call_gen__save_variables_4_0_i2);
Declare_label(mercury__call_gen__save_variables_4_0_i3);
Declare_label(mercury__call_gen__save_variables_4_0_i4);
Declare_label(mercury__call_gen__save_variables_4_0_i5);
Declare_label(mercury__call_gen__save_variables_4_0_i8);
Declare_label(mercury__call_gen__save_variables_4_0_i9);
Declare_label(mercury__call_gen__save_variables_4_0_i10);
Declare_label(mercury__call_gen__save_variables_4_0_i6);
Declare_label(mercury__call_gen__save_variables_4_0_i12);
Declare_label(mercury__call_gen__save_variables_4_0_i13);
Declare_static(mercury__call_gen__extra_livevals_2_0);
Declare_static(mercury__call_gen__extra_livevals_3_0);
Declare_label(mercury__call_gen__extra_livevals_3_0_i3);
Declare_label(mercury__call_gen__extra_livevals_3_0_i2);
Declare_static(mercury__call_gen__generic_call_info_4_0);
Declare_label(mercury__call_gen__generic_call_info_4_0_i5);
Declare_label(mercury__call_gen__generic_call_info_4_0_i8);
Declare_label(mercury__call_gen__generic_call_info_4_0_i10);
Declare_label(mercury__call_gen__generic_call_info_4_0_i11);
Declare_label(mercury__call_gen__generic_call_info_4_0_i9);
Declare_label(mercury__call_gen__generic_call_info_4_0_i12);
Declare_label(mercury__call_gen__generic_call_info_4_0_i13);
Declare_label(mercury__call_gen__generic_call_info_4_0_i14);
Declare_label(mercury__call_gen__generic_call_info_4_0_i15);
Declare_label(mercury__call_gen__generic_call_info_4_0_i16);
Declare_label(mercury__call_gen__generic_call_info_4_0_i19);
Declare_label(mercury__call_gen__generic_call_info_4_0_i20);
Declare_label(mercury__call_gen__generic_call_info_4_0_i17);
Declare_label(mercury__call_gen__generic_call_info_4_0_i21);
Declare_label(mercury__call_gen__generic_call_info_4_0_i4);
Declare_static(mercury__call_gen__generic_call_setup_6_0);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i10);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i11);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i12);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i1032);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i4);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i5);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i6);
Declare_label(mercury__call_gen__generic_call_setup_6_0_i7);
Declare_static(mercury__call_gen__place_generic_call_var_5_0);
Declare_label(mercury__call_gen__place_generic_call_var_5_0_i2);
Declare_label(mercury__call_gen__place_generic_call_var_5_0_i3);
Declare_label(mercury__call_gen__place_generic_call_var_5_0_i8);
Declare_static(mercury__call_gen__setup_base_relation_name_4_0);
Declare_label(mercury__call_gen__setup_base_relation_name_4_0_i2);
Declare_label(mercury__call_gen__setup_base_relation_name_4_0_i3);
Declare_static(mercury__call_gen__prepare_for_call_5_0);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i2);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i4);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i5);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i6);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i7);
Declare_label(mercury__call_gen__prepare_for_call_5_0_i8);
Declare_static(mercury__call_gen__handle_failure_4_0);
Declare_label(mercury__call_gen__handle_failure_4_0_i4);
Declare_label(mercury__call_gen__handle_failure_4_0_i5);
Declare_label(mercury__call_gen__handle_failure_4_0_i2);
Declare_static(mercury__call_gen__save_variables_2_4_0);
Declare_label(mercury__call_gen__save_variables_2_4_0_i4);
Declare_label(mercury__call_gen__save_variables_2_4_0_i5);
Declare_label(mercury__call_gen__save_variables_2_4_0_i3);
Declare_static(mercury__call_gen__rebuild_registers_3_0);
Declare_label(mercury__call_gen__rebuild_registers_3_0_i2);
Declare_static(mercury__call_gen__rebuild_registers_2_3_0);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i1002);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i6);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i4);
Declare_label(mercury__call_gen__rebuild_registers_2_3_0_i3);
Declare_static(mercury__call_gen__input_args_2_0);
Declare_label(mercury__call_gen__input_args_2_0_i7);
Declare_label(mercury__call_gen__input_args_2_0_i8);
Declare_label(mercury__call_gen__input_args_2_0_i6);
Declare_label(mercury__call_gen__input_args_2_0_i2);
Declare_static(mercury__call_gen__generate_immediate_args_6_0);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i4);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i5);
Declare_label(mercury__call_gen__generate_immediate_args_6_0_i3);
Declare_static(mercury__call_gen__outvars_to_outargs_3_0);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i5);
Declare_label(mercury__call_gen__outvars_to_outargs_3_0_i2);

static const struct mercury_data_call_gen__common_0_struct {
	Integer f1;
	Integer f2;
}  mercury_data_call_gen__common_0;

static const struct mercury_data_call_gen__common_1_struct {
	Integer f1;
	Integer f2;
}  mercury_data_call_gen__common_1;

static const struct mercury_data_call_gen__common_2_struct {
	Integer f1;
	Integer f2;
}  mercury_data_call_gen__common_2;

static const struct mercury_data_call_gen__common_3_struct {
	Integer f1;
	Integer f2;
}  mercury_data_call_gen__common_3;

static const struct mercury_data_call_gen__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_call_gen__common_4;

static const struct mercury_data_call_gen__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_call_gen__common_5;

static const struct mercury_data_call_gen__common_6_struct {
	Word * f1;
}  mercury_data_call_gen__common_6;

static const struct mercury_data_call_gen__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_call_gen__common_7;

static const struct mercury_data_call_gen__common_8_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_call_gen__common_8;

static const struct mercury_data_call_gen__common_9_struct {
	Word * f1;
}  mercury_data_call_gen__common_9;

static const struct mercury_data_call_gen__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_call_gen__common_10;

static const struct mercury_data_call_gen__common_11_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_call_gen__common_11;

static const struct mercury_data_call_gen__common_12_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_call_gen__common_12;

static const struct mercury_data_call_gen__common_13_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_call_gen__common_13;

static const struct mercury_data_call_gen__common_14_struct {
	Word * f1;
}  mercury_data_call_gen__common_14;

static const struct mercury_data_call_gen__common_0_struct mercury_data_call_gen__common_0 = {
	(Integer) 0,
	(Integer) 1
};

static const struct mercury_data_call_gen__common_1_struct mercury_data_call_gen__common_1 = {
	(Integer) 0,
	(Integer) 2
};

static const struct mercury_data_call_gen__common_2_struct mercury_data_call_gen__common_2 = {
	(Integer) 0,
	(Integer) 3
};

static const struct mercury_data_call_gen__common_3_struct mercury_data_call_gen__common_3 = {
	(Integer) 0,
	(Integer) 4
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_call_gen__common_4_struct mercury_data_call_gen__common_4 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_call_gen__common_5_struct mercury_data_call_gen__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_code_info__type_ctor_info_code_info_0;
static const struct mercury_data_call_gen__common_6_struct mercury_data_call_gen__common_6 = {
	(Word *) &mercury_data_code_info__type_ctor_info_code_info_0
};

static const struct mercury_data_call_gen__common_7_struct mercury_data_call_gen__common_7 = {
	(Integer) 0,
	MR_string_const("code_info", 9),
	MR_string_const("code_info", 9),
	MR_string_const("variable_type", 13),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_6)
};

Declare_entry(mercury__code_info__variable_type_4_0);
static const struct mercury_data_call_gen__common_8_struct mercury_data_call_gen__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_7),
	ENTRY(mercury__code_info__variable_type_4_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_code_model_0;
static const struct mercury_data_call_gen__common_9_struct mercury_data_call_gen__common_9 = {
	(Word *) &mercury_data_llds__type_ctor_info_code_model_0
};

static const struct mercury_data_call_gen__common_10_struct mercury_data_call_gen__common_10 = {
	(Integer) 0,
	MR_string_const("call_gen", 8),
	MR_string_const("call_gen", 8),
	MR_string_const("IntroducedFrom__pred__generic_call_info__257__3", 47),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9)
};

static const struct mercury_data_call_gen__common_11_struct mercury_data_call_gen__common_11 = {
	(Integer) 0,
	MR_string_const("call_gen", 8),
	MR_string_const("call_gen", 8),
	MR_string_const("IntroducedFrom__pred__generic_call_info__260__2", 47),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9)
};

static const struct mercury_data_call_gen__common_12_struct mercury_data_call_gen__common_12 = {
	(Integer) 0,
	MR_string_const("call_gen", 8),
	MR_string_const("call_gen", 8),
	MR_string_const("IntroducedFrom__pred__generic_call_info__267__1", 47),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9)
};

static const struct mercury_data_call_gen__common_13_struct mercury_data_call_gen__common_13 = {
	(Integer) 0,
	MR_string_const("call_gen", 8),
	MR_string_const("call_gen", 8),
	MR_string_const("IntroducedFrom__pred__generic_call_info__271__4", 47),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_9)
};

static const struct mercury_data_call_gen__common_14_struct mercury_data_call_gen__common_14 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_0)
};

Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__rl__get_entry_proc_name_3_0);
Declare_entry(mercury__rl__proc_name_to_string_2_0);
Declare_entry(mercury__rl__schema_to_string_3_0);
Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(call_gen_module0)
	init_entry(mercury__call_gen__aditi_builtin_setup__ua0_6_0);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i4);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i5);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i6);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i7);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i8);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i9);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i10);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i11);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i1031);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i14);
	init_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i15);
BEGIN_CODE

/* code for predicate 'aditi_builtin_setup__ua0'/6 in mode 0 */
Define_static(mercury__call_gen__aditi_builtin_setup__ua0_6_0);
	MR_incr_sp_push_msg(6, "call_gen:aditi_builtin_setup__ua0/6");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i4) AND
		LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i9) AND
		LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i1031) AND
		LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i14));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = r3;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i5,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__rl__get_entry_proc_name_3_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i6,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	call_localret(ENTRY(mercury__rl__proc_name_to_string_2_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i7,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__rl__schema_to_string_3_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i8,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_0);
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Assign name of procedure to call", 32);
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Assign number of input arguments", 32);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_2);
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("Assign schema of input arguments", 32);
	MR_field(MR_mktag(3), r7, (Integer) 2) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_3);
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r8, (Integer) 2) = r9;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Assign number of output arguments", 33);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i9);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__call_gen__setup_base_relation_name_4_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i10,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__aditi_builtin_setup__ua0_6_0_i11,
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__aditi_builtin_setup__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r7;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Assign arity of relation to insert into", 39);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i1031);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = r3;
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__call_gen__setup_base_relation_name_4_0),
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__call_gen__setup_base_relation_name_4_0),
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
Define_label(mercury__call_gen__aditi_builtin_setup__ua0_6_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__call_gen__setup_base_relation_name_4_0),
		STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0));
END_MODULE

Declare_entry(mercury__list__map_foldl_5_1);
Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Declare_entry(mercury__arg_info__make_arg_infos_5_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__code_info__generate_call_stack_vn_livevals_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__set__insert_list_3_0);
Declare_entry(mercury__code_info__get_instmap_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
Declare_entry(mercury__trace__prepare_for_call_3_0);
Declare_entry(mercury__code_info__generate_return_live_lvalues_5_0);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);

BEGIN_MODULE(call_gen_module1)
	init_entry(mercury__call_gen__generate_generic_call__ua0_9_0);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i2);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i3);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i4);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i5);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i6);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i7);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i8);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i9);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i10);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i11);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i12);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i13);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i14);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i15);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i16);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i17);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i19);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i20);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i21);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i22);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i23);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i24);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i25);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i26);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i27);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i28);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i29);
	init_label(mercury__call_gen__generate_generic_call__ua0_9_0_i30);
BEGIN_CODE

/* code for predicate 'generate_generic_call__ua0'/9 in mode 0 */
Define_static(mercury__call_gen__generate_generic_call__ua0_9_0);
	MR_incr_sp_push_msg(16, "call_gen:generate_generic_call__ua0/9");
	MR_stackvar(16) = (Word) MR_succip;
	MR_stackvar(5) = r5;
	r5 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_5);
	r3 = (Word) (Word *) &mercury_data_code_info__type_ctor_info_code_info_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_8);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__call_gen__generate_generic_call__ua0_9_0_i2,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i3,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i4,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__arg_info__make_arg_infos_5_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i5,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i6,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	call_localret(STATIC(mercury__call_gen__partition_args_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i7,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i8,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i9,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__call_gen__prepare_for_call_5_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i10,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(8) = r1;
	MR_stackvar(9) = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	MR_stackvar(10) = r3;
	call_localret(STATIC(mercury__call_gen__generic_call_info_4_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i11,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = MR_stackvar(10);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(11) = r2;
	call_localret(STATIC(mercury__call_gen__generate_immediate_args_6_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i12,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(12) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__generate_call_stack_vn_livevals_4_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i13,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
	}
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	r1 = MR_stackvar(11);
	MR_stackvar(11) = r3;
	MR_stackvar(13) = r2;
	call_localret(STATIC(mercury__call_gen__extra_livevals_2_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i14,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i15,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i16,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	if (((Integer) MR_stackvar(6) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__generate_generic_call__ua0_9_0_i17);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r2 = (Integer) 2;
	GOTO_LABEL(mercury__call_gen__generate_generic_call__ua0_9_0_i19);
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i17);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r2 = (Integer) 1;
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i19);
	MR_stackvar(3) = r1;
	call_localret(STATIC(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i20,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i20);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(13);
	MR_stackvar(13) = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i21,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i21);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(15) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i22,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i22);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i23,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i23);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(15);
	call_localret(STATIC(mercury__call_gen__generic_call_setup_6_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i24,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
	}
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i24);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__trace__prepare_for_call_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i25,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i25);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(11);
	call_localret(STATIC(mercury__call_gen__rebuild_registers_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i26,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i26);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__generate_return_live_lvalues_5_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i27,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i27);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i28,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i28);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i29,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i29);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__call_gen__generate_generic_call__ua0_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 6, mercury__call_gen__generate_generic_call__ua0_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), r6, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(3), r6, (Integer) 4) = r1;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generate_generic_call__ua0_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Setup and call", 14);
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(11);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("Continuation label", 18);
	call_localret(STATIC(mercury__call_gen__handle_failure_4_0),
		mercury__call_gen__generate_generic_call__ua0_9_0_i30,
		STATIC(mercury__call_gen__generate_generic_call__ua0_9_0));
	}
Define_label(mercury__call_gen__generate_generic_call__ua0_9_0_i30);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_generic_call__ua0_9_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_generic_call__ua0_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
	}
END_MODULE

Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(call_gen_module2)
	init_entry(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i4);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i5);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i8);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i9);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i3);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i12);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__generate_call__586__4'/3 in mode 0 */
Define_static(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0);
	MR_incr_sp_push_msg(5, "call_gen:DeforestationIn__pred__generate_call__586__4/3");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0,
		LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i4),
		STATIC(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i5);
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i8,
		STATIC(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i5);
	MR_stackvar(4) = r2;
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i9);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i9);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i12,
		STATIC(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
Define_label(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module3)
	init_entry(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0);
	init_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i3);
	init_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i4);
	init_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i5);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3'/4 in mode 0 */
Define_static(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0);
	MR_incr_sp_push_msg(4, "call_gen:DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Integer) 1;
	call_localret(STATIC(mercury__call_gen__outvars_to_outargs_3_0),
		mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i4,
		STATIC(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0));
	}
Define_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	call_localret(STATIC(mercury__call_gen__output_arg_locs_2_0),
		mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i5,
		STATIC(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0));
Define_label(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
END_MODULE


BEGIN_MODULE(call_gen_module4)
	init_entry(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i3);
	init_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i4);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__generate_generic_call__671__2'/4 in mode 0 */
Define_static(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0);
	MR_incr_sp_push_msg(4, "call_gen:DeforestationIn__pred__generate_generic_call__671__2/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Integer) 1;
	call_localret(STATIC(mercury__call_gen__DeforestationIn__pred__DeforestationIn__pred__generate_generic_call__671__2__671__3_4_0),
		mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i4,
		STATIC(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0));
	}
Define_label(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__DeforestationIn__pred__generate_generic_call__671__2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module5)
	init_entry(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0);
	init_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generic_call_info__271__4'/2 in mode 0 */
Define_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module6)
	init_entry(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0);
	init_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generic_call_info__257__3'/2 in mode 0 */
Define_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module7)
	init_entry(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0);
	init_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generic_call_info__260__2'/2 in mode 0 */
Define_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module8)
	init_entry(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0);
	init_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generic_call_info__267__1'/2 in mode 0 */
Define_static(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module9)
	init_entry(mercury__call_gen__generate_generic_call_9_0);
BEGIN_CODE

/* code for predicate 'generate_generic_call'/9 in mode 0 */
Define_entry(mercury__call_gen__generate_generic_call_9_0);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r5 = r6;
	r6 = r7;
	tailcall(STATIC(mercury__call_gen__generate_generic_call__ua0_9_0),
		ENTRY(mercury__call_gen__generate_generic_call_9_0));
END_MODULE

Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
Declare_entry(mercury__code_info__succip_is_used_2_0);
Declare_entry(mercury__code_info__may_use_nondet_tailcall_3_0);
Declare_entry(mercury__code_info__flush_resume_vars_to_stack_3_0);
Declare_entry(mercury__code_info__set_resume_point_and_frame_to_unknown_2_0);
Declare_entry(mercury__code_info__setup_call_5_0);
Declare_entry(mercury__code_info__generate_call_vn_livevals_5_0);
Declare_entry(mercury__code_info__clear_all_registers_2_0);
Declare_entry(mercury__code_info__make_entry_label_7_0);

BEGIN_MODULE(call_gen_module10)
	init_entry(mercury__call_gen__generate_call_8_0);
	init_label(mercury__call_gen__generate_call_8_0_i2);
	init_label(mercury__call_gen__generate_call_8_0_i3);
	init_label(mercury__call_gen__generate_call_8_0_i4);
	init_label(mercury__call_gen__generate_call_8_0_i5);
	init_label(mercury__call_gen__generate_call_8_0_i6);
	init_label(mercury__call_gen__generate_call_8_0_i7);
	init_label(mercury__call_gen__generate_call_8_0_i8);
	init_label(mercury__call_gen__generate_call_8_0_i10);
	init_label(mercury__call_gen__generate_call_8_0_i11);
	init_label(mercury__call_gen__generate_call_8_0_i12);
	init_label(mercury__call_gen__generate_call_8_0_i13);
	init_label(mercury__call_gen__generate_call_8_0_i14);
	init_label(mercury__call_gen__generate_call_8_0_i9);
	init_label(mercury__call_gen__generate_call_8_0_i15);
	init_label(mercury__call_gen__generate_call_8_0_i16);
	init_label(mercury__call_gen__generate_call_8_0_i1005);
	init_label(mercury__call_gen__generate_call_8_0_i18);
	init_label(mercury__call_gen__generate_call_8_0_i19);
	init_label(mercury__call_gen__generate_call_8_0_i20);
	init_label(mercury__call_gen__generate_call_8_0_i21);
	init_label(mercury__call_gen__generate_call_8_0_i22);
	init_label(mercury__call_gen__generate_call_8_0_i23);
	init_label(mercury__call_gen__generate_call_8_0_i24);
	init_label(mercury__call_gen__generate_call_8_0_i25);
	init_label(mercury__call_gen__generate_call_8_0_i26);
	init_label(mercury__call_gen__generate_call_8_0_i27);
BEGIN_CODE

/* code for predicate 'generate_call'/8 in mode 0 */
Define_entry(mercury__call_gen__generate_call_8_0);
	MR_incr_sp_push_msg(15, "call_gen:generate_call/8");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(3) = r3;
	r3 = r6;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__call_gen__generate_call_8_0_i2,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = MR_stackvar(4);
	r4 = r1;
	MR_stackvar(4) = r1;
	MR_stackvar(6) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__call_gen__generate_call_8_0_i3,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__call_gen__input_args_2_0),
		mercury__call_gen__generate_call_8_0_i4,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__call_gen__generate_call_8_0_i5,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__call_gen__DeforestationIn__pred__generate_call__586__4_3_0),
		mercury__call_gen__generate_call_8_0_i6,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(13) = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	call_localret(STATIC(mercury__call_gen__save_variables_4_0),
		mercury__call_gen__generate_call_8_0_i7,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__succip_is_used_2_0),
		mercury__call_gen__generate_call_8_0_i8,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__generate_call_8_0_i10);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(8) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(14) = (Word) MR_string_const("branch to det procedure", 23);
	GOTO_LABEL(mercury__call_gen__generate_call_8_0_i9);
Define_label(mercury__call_gen__generate_call_8_0_i10);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__generate_call_8_0_i11);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(8) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_stackvar(14) = (Word) MR_string_const("branch to semidet procedure", 27);
	GOTO_LABEL(mercury__call_gen__generate_call_8_0_i9);
Define_label(mercury__call_gen__generate_call_8_0_i11);
	call_localret(ENTRY(mercury__code_info__may_use_nondet_tailcall_3_0),
		mercury__call_gen__generate_call_8_0_i12,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__generate_call_8_0, "origin_lost_in_value_number");
	MR_stackvar(9) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__flush_resume_vars_to_stack_3_0),
		mercury__call_gen__generate_call_8_0_i13,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__set_resume_point_and_frame_to_unknown_2_0),
		mercury__call_gen__generate_call_8_0_i14,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i14);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(14) = (Word) MR_string_const("branch to nondet procedure", 26);
Define_label(mercury__call_gen__generate_call_8_0_i9);
	MR_stackvar(4) = r1;
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__call_gen__generate_call_8_0_i15,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(10) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__trace__prepare_for_call_3_0),
		mercury__call_gen__generate_call_8_0_i16,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(11);
	call_localret(ENTRY(mercury__code_info__generate_call_vn_livevals_5_0),
		mercury__call_gen__generate_call_8_0_i1005,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i1005);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	tag_incr_hp_msg(MR_stackvar(11), MR_mktag(1), (Integer) 1, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_call_8_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_call_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__call_gen__generate_call_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(1), MR_stackvar(11), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__call_gen__generate_call_8_0_i18,
		ENTRY(mercury__call_gen__generate_call_8_0));
	}
Define_label(mercury__call_gen__generate_call_8_0_i18);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = r2;
	r2 = MR_stackvar(12);
	MR_stackvar(12) = r3;
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__call_gen__generate_call_8_0_i19,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i19);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__generate_call_8_0_i20,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i20);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		mercury__call_gen__generate_call_8_0_i21,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i21);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = r1;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__code_info__generate_return_live_lvalues_5_0),
		mercury__call_gen__generate_call_8_0_i22,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i22);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_call_8_0_i23,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i23);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r5 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__call_gen__generate_call_8_0_i24,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i24);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__generate_call_8_0_i25,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i25);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__call_gen__generate_call_8_0_i26,
		ENTRY(mercury__call_gen__generate_call_8_0));
Define_label(mercury__call_gen__generate_call_8_0_i26);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_call_8_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_call_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 6, mercury__call_gen__generate_call_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r5, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(3), r5, (Integer) 4) = r1;
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generate_call_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_call_8_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__generate_call_8_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__call_gen__generate_call_8_0, "origin_lost_in_value_number");
	r1 = r2;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("continuation label", 18);
	call_localret(STATIC(mercury__call_gen__handle_failure_4_0),
		mercury__call_gen__generate_call_8_0_i27,
		ENTRY(mercury__call_gen__generate_call_8_0));
	}
Define_label(mercury__call_gen__generate_call_8_0_i27);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_call_8_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_call_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
END_MODULE

Declare_entry(mercury__hlds_module__predicate_module_3_0);
Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__code_util__translate_builtin_6_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__code_info__cache_expression_4_0);
Declare_entry(mercury__code_info__produce_variable_5_0);
Declare_entry(mercury__code_info__fail_if_rval_is_false_4_0);

BEGIN_MODULE(call_gen_module11)
	init_entry(mercury__call_gen__generate_builtin_7_0);
	init_label(mercury__call_gen__generate_builtin_7_0_i2);
	init_label(mercury__call_gen__generate_builtin_7_0_i3);
	init_label(mercury__call_gen__generate_builtin_7_0_i4);
	init_label(mercury__call_gen__generate_builtin_7_0_i7);
	init_label(mercury__call_gen__generate_builtin_7_0_i6);
	init_label(mercury__call_gen__generate_builtin_7_0_i9);
	init_label(mercury__call_gen__generate_builtin_7_0_i10);
	init_label(mercury__call_gen__generate_builtin_7_0_i16);
	init_label(mercury__call_gen__generate_builtin_7_0_i13);
	init_label(mercury__call_gen__generate_builtin_7_0_i12);
	init_label(mercury__call_gen__generate_builtin_7_0_i26);
	init_label(mercury__call_gen__generate_builtin_7_0_i24);
	init_label(mercury__call_gen__generate_builtin_7_0_i27);
	init_label(mercury__call_gen__generate_builtin_7_0_i30);
	init_label(mercury__call_gen__generate_builtin_7_0_i28);
	init_label(mercury__call_gen__generate_builtin_7_0_i22);
	init_label(mercury__call_gen__generate_builtin_7_0_i36);
	init_label(mercury__call_gen__generate_builtin_7_0_i34);
	init_label(mercury__call_gen__generate_builtin_7_0_i32);
	init_label(mercury__call_gen__generate_builtin_7_0_i38);
	init_label(mercury__call_gen__generate_builtin_7_0_i41);
	init_label(mercury__call_gen__generate_builtin_7_0_i44);
	init_label(mercury__call_gen__generate_builtin_7_0_i42);
	init_label(mercury__call_gen__generate_builtin_7_0_i20);
	init_label(mercury__call_gen__generate_builtin_7_0_i19);
BEGIN_CODE

/* code for predicate 'generate_builtin'/7 in mode 0 */
Define_entry(mercury__call_gen__generate_builtin_7_0);
	MR_incr_sp_push_msg(7, "call_gen:generate_builtin/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__generate_builtin_7_0_i2,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	MR_stackvar(6) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__call_gen__generate_builtin_7_0_i3,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__call_gen__generate_builtin_7_0_i4,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_util__translate_builtin_6_0),
		mercury__call_gen__generate_builtin_7_0_i7,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i6);
	MR_stackvar(2) = r3;
	r1 = r2;
	r3 = MR_stackvar(6);
	GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i10);
Define_label(mercury__call_gen__generate_builtin_7_0_i6);
	r1 = (Word) MR_string_const("Unknown builtin predicate", 25);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__call_gen__generate_builtin_7_0_i9,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r3 = MR_stackvar(6);
Define_label(mercury__call_gen__generate_builtin_7_0_i10);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i12);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i13);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i13);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__call_gen__generate_builtin_7_0_i16,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
	}
Define_label(mercury__call_gen__generate_builtin_7_0_i16);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__call_gen__generate_builtin_7_0_i13);
	r1 = (Word) MR_string_const("Malformed det builtin predicate", 31);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i12);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i19);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i20);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i22);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i22);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	r4 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r5 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i24);
	MR_stackvar(4) = r1;
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = r3;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__generate_builtin_7_0_i26,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i26);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	r2 = r3;
	GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i27);
Define_label(mercury__call_gen__generate_builtin_7_0_i24);
	MR_stackvar(4) = r1;
	r1 = r4;
	r2 = r3;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__call_gen__generate_builtin_7_0_i27);
	if ((MR_tag(MR_stackvar(4)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i28);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__generate_builtin_7_0_i30,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i30);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r4 = MR_stackvar(3);
	r5 = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_builtin_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	r2 = r3;
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__call_gen__generate_builtin_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r5;
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__call_gen__generate_builtin_7_0_i41,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
	}
Define_label(mercury__call_gen__generate_builtin_7_0_i28);
	r3 = MR_stackvar(3);
	r4 = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_builtin_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__call_gen__generate_builtin_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r4;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__call_gen__generate_builtin_7_0_i41,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
	}
Define_label(mercury__call_gen__generate_builtin_7_0_i22);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i32);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i32);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i34);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__generate_builtin_7_0_i36,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i36);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r4 = MR_stackvar(3);
	r5 = r2;
	r2 = r3;
	MR_stackvar(3) = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__call_gen__generate_builtin_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r5;
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__call_gen__generate_builtin_7_0_i41,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i34);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__call_gen__generate_builtin_7_0_i41,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i32);
	r1 = (Word) MR_string_const("Malformed semi builtin predicate", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__call_gen__generate_builtin_7_0_i38,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i38);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r3 = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__call_gen__generate_builtin_7_0_i41,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i41);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_builtin_7_0_i42);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r3 = r2;
	MR_stackvar(2) = r1;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__call_gen__generate_builtin_7_0_i44,
		ENTRY(mercury__call_gen__generate_builtin_7_0));
	}
Define_label(mercury__call_gen__generate_builtin_7_0_i44);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_builtin_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_builtin_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__call_gen__generate_builtin_7_0_i42);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_builtin_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__call_gen__generate_builtin_7_0_i20);
	r1 = (Word) MR_string_const("Malformed semi builtin predicate", 32);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__call_gen__generate_builtin_7_0));
Define_label(mercury__call_gen__generate_builtin_7_0_i19);
	r1 = (Word) MR_string_const("Nondet builtin predicate", 24);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__call_gen__generate_builtin_7_0));
END_MODULE


BEGIN_MODULE(call_gen_module12)
	init_entry(mercury__call_gen__partition_args_3_0);
	init_label(mercury__call_gen__partition_args_3_0_i6);
	init_label(mercury__call_gen__partition_args_3_0_i4);
	init_label(mercury__call_gen__partition_args_3_0_i7);
	init_label(mercury__call_gen__partition_args_3_0_i3);
BEGIN_CODE

/* code for predicate 'partition_args'/3 in mode 0 */
Define_entry(mercury__call_gen__partition_args_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__partition_args_3_0_i3);
	MR_incr_sp_push_msg(2, "call_gen:partition_args/3");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__partition_args_3_0_i4);
	MR_stackvar(1) = r3;
	r4 = r1;
	r1 = r2;
	localcall(mercury__call_gen__partition_args_3_0,
		LABEL(mercury__call_gen__partition_args_3_0_i6),
		ENTRY(mercury__call_gen__partition_args_3_0));
Define_label(mercury__call_gen__partition_args_3_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__partition_args_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__partition_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__partition_args_3_0_i4);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__call_gen__partition_args_3_0,
		LABEL(mercury__call_gen__partition_args_3_0_i7),
		ENTRY(mercury__call_gen__partition_args_3_0));
Define_label(mercury__call_gen__partition_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__partition_args_3_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__call_gen__partition_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__partition_args_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module13)
	init_entry(mercury__call_gen__input_arg_locs_2_0);
	init_label(mercury__call_gen__input_arg_locs_2_0_i7);
	init_label(mercury__call_gen__input_arg_locs_2_0_i8);
	init_label(mercury__call_gen__input_arg_locs_2_0_i6);
	init_label(mercury__call_gen__input_arg_locs_2_0_i2);
BEGIN_CODE

/* code for predicate 'input_arg_locs'/2 in mode 0 */
Define_entry(mercury__call_gen__input_arg_locs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i2);
	r4 = (Word) MR_sp;
Define_label(mercury__call_gen__input_arg_locs_2_0_i7);
	while (1) {
	MR_incr_sp_push_msg(3, "call_gen:input_arg_locs");
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__call_gen__input_arg_locs_2_0_i8);
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i6);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__input_arg_locs_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__input_arg_locs_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
Define_label(mercury__call_gen__input_arg_locs_2_0_i6);
	MR_decr_sp_pop_msg(3);
	if (((Integer) MR_sp > (Integer) r4))
		GOTO_LABEL(mercury__call_gen__input_arg_locs_2_0_i8);
	proceed();
Define_label(mercury__call_gen__input_arg_locs_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module14)
	init_entry(mercury__call_gen__output_arg_locs_2_0);
	init_label(mercury__call_gen__output_arg_locs_2_0_i7);
	init_label(mercury__call_gen__output_arg_locs_2_0_i8);
	init_label(mercury__call_gen__output_arg_locs_2_0_i6);
	init_label(mercury__call_gen__output_arg_locs_2_0_i2);
BEGIN_CODE

/* code for predicate 'output_arg_locs'/2 in mode 0 */
Define_entry(mercury__call_gen__output_arg_locs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i2);
	r4 = (Word) MR_sp;
Define_label(mercury__call_gen__output_arg_locs_2_0_i7);
	while (1) {
	MR_incr_sp_push_msg(3, "call_gen:output_arg_locs");
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__call_gen__output_arg_locs_2_0_i8);
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i6);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__output_arg_locs_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__output_arg_locs_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
Define_label(mercury__call_gen__output_arg_locs_2_0_i6);
	MR_decr_sp_pop_msg(3);
	if (((Integer) MR_sp > (Integer) r4))
		GOTO_LABEL(mercury__call_gen__output_arg_locs_2_0_i8);
	proceed();
Define_label(mercury__call_gen__output_arg_locs_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_known_variables_3_0);
Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__hlds_pred__body_should_use_typeinfo_liveness_2_0);
Declare_entry(mercury__code_info__get_proc_info_3_0);
Declare_entry(mercury__hlds_pred__proc_info_get_typeinfo_vars_setwise_3_0);
Declare_entry(mercury__set__union_3_0);
Declare_entry(mercury__set__difference_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(call_gen_module15)
	init_entry(mercury__call_gen__save_variables_4_0);
	init_label(mercury__call_gen__save_variables_4_0_i2);
	init_label(mercury__call_gen__save_variables_4_0_i3);
	init_label(mercury__call_gen__save_variables_4_0_i4);
	init_label(mercury__call_gen__save_variables_4_0_i5);
	init_label(mercury__call_gen__save_variables_4_0_i8);
	init_label(mercury__call_gen__save_variables_4_0_i9);
	init_label(mercury__call_gen__save_variables_4_0_i10);
	init_label(mercury__call_gen__save_variables_4_0_i6);
	init_label(mercury__call_gen__save_variables_4_0_i12);
	init_label(mercury__call_gen__save_variables_4_0_i13);
BEGIN_CODE

/* code for predicate 'save_variables'/4 in mode 0 */
Define_entry(mercury__call_gen__save_variables_4_0);
	MR_incr_sp_push_msg(4, "call_gen:save_variables/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_known_variables_3_0),
		mercury__call_gen__save_variables_4_0_i2,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__call_gen__save_variables_4_0_i3,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__call_gen__save_variables_4_0_i4,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__body_should_use_typeinfo_liveness_2_0),
		mercury__call_gen__save_variables_4_0_i5,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__save_variables_4_0_i6);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__call_gen__save_variables_4_0_i8,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	MR_stackvar(3) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_typeinfo_vars_setwise_3_0),
		mercury__call_gen__save_variables_4_0_i9,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i9);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__call_gen__save_variables_4_0_i10,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__call_gen__save_variables_4_0_i12,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i6);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__call_gen__save_variables_4_0_i12,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__call_gen__save_variables_4_0_i13,
		ENTRY(mercury__call_gen__save_variables_4_0));
Define_label(mercury__call_gen__save_variables_4_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_4_0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__call_gen__save_variables_2_4_0),
		ENTRY(mercury__call_gen__save_variables_4_0));
END_MODULE


BEGIN_MODULE(call_gen_module16)
	init_entry(mercury__call_gen__extra_livevals_2_0);
BEGIN_CODE

/* code for predicate 'extra_livevals'/2 in mode 0 */
Define_static(mercury__call_gen__extra_livevals_2_0);
	r2 = r1;
	r1 = (Integer) 1;
	tailcall(STATIC(mercury__call_gen__extra_livevals_3_0),
		STATIC(mercury__call_gen__extra_livevals_2_0));
END_MODULE


BEGIN_MODULE(call_gen_module17)
	init_entry(mercury__call_gen__extra_livevals_3_0);
	init_label(mercury__call_gen__extra_livevals_3_0_i3);
	init_label(mercury__call_gen__extra_livevals_3_0_i2);
BEGIN_CODE

/* code for predicate 'extra_livevals'/3 in mode 0 */
Define_static(mercury__call_gen__extra_livevals_3_0);
	if (((Integer) r1 >= (Integer) r2))
		GOTO_LABEL(mercury__call_gen__extra_livevals_3_0_i2);
	MR_incr_sp_push_msg(2, "call_gen:extra_livevals/3");
	MR_stackvar(2) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__extra_livevals_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = ((Integer) r1 + (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Integer) 0;
	localcall(mercury__call_gen__extra_livevals_3_0,
		LABEL(mercury__call_gen__extra_livevals_3_0_i3),
		STATIC(mercury__call_gen__extra_livevals_3_0));
Define_label(mercury__call_gen__extra_livevals_3_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__extra_livevals_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__extra_livevals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__extra_livevals_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__require__require_2_0);

BEGIN_MODULE(call_gen_module18)
	init_entry(mercury__call_gen__generic_call_info_4_0);
	init_label(mercury__call_gen__generic_call_info_4_0_i5);
	init_label(mercury__call_gen__generic_call_info_4_0_i8);
	init_label(mercury__call_gen__generic_call_info_4_0_i10);
	init_label(mercury__call_gen__generic_call_info_4_0_i11);
	init_label(mercury__call_gen__generic_call_info_4_0_i9);
	init_label(mercury__call_gen__generic_call_info_4_0_i12);
	init_label(mercury__call_gen__generic_call_info_4_0_i13);
	init_label(mercury__call_gen__generic_call_info_4_0_i14);
	init_label(mercury__call_gen__generic_call_info_4_0_i15);
	init_label(mercury__call_gen__generic_call_info_4_0_i16);
	init_label(mercury__call_gen__generic_call_info_4_0_i19);
	init_label(mercury__call_gen__generic_call_info_4_0_i20);
	init_label(mercury__call_gen__generic_call_info_4_0_i17);
	init_label(mercury__call_gen__generic_call_info_4_0_i21);
	init_label(mercury__call_gen__generic_call_info_4_0_i4);
BEGIN_CODE

/* code for predicate 'generic_call_info'/4 in mode 0 */
Define_static(mercury__call_gen__generic_call_info_4_0);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i4);
	MR_incr_sp_push_msg(2, "call_gen:generic_call_info/4");
	MR_stackvar(2) = (Word) MR_succip;
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	r2 = (Integer) 4;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i5);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__call_gen__generic_call_info_4_0_i8) AND
		LABEL(mercury__call_gen__generic_call_info_4_0_i12) AND
		LABEL(mercury__call_gen__generic_call_info_4_0_i14) AND
		LABEL(mercury__call_gen__generic_call_info_4_0_i16));
Define_label(mercury__call_gen__generic_call_info_4_0_i8);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i10);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7));
	GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i9);
Define_label(mercury__call_gen__generic_call_info_4_0_i10);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 8));
	GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i9);
Define_label(mercury__call_gen__generic_call_info_4_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 9));
Define_label(mercury__call_gen__generic_call_info_4_0_i9);
	r2 = (Integer) 5;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__call_gen__generic_call_info_4_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_10);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__call_gen__IntroducedFrom__pred__generic_call_info__257__3_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Integer) 0;
	r2 = (Word) MR_string_const("aditi_insert not model_det", 26);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__call_gen__generic_call_info_4_0_i13,
		STATIC(mercury__call_gen__generic_call_info_4_0));
Define_label(mercury__call_gen__generic_call_info_4_0_i13);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_info_4_0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 10));
	r2 = (Integer) 3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__call_gen__generic_call_info_4_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_11);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__call_gen__IntroducedFrom__pred__generic_call_info__260__2_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Integer) 0;
	r2 = (Word) MR_string_const("aditi_delete not model_det", 26);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__call_gen__generic_call_info_4_0_i15,
		STATIC(mercury__call_gen__generic_call_info_4_0));
Define_label(mercury__call_gen__generic_call_info_4_0_i15);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_info_4_0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 11));
	r2 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i16);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i17);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__generic_call_info_4_0_i19);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 12));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__call_gen__generic_call_info_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	r2 = (Word) MR_string_const("aditi_bulk_operation not model_det", 34);
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_12);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__call_gen__generic_call_info_4_0_i20,
		STATIC(mercury__call_gen__generic_call_info_4_0));
Define_label(mercury__call_gen__generic_call_info_4_0_i19);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 13));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__call_gen__generic_call_info_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	r2 = (Word) MR_string_const("aditi_bulk_operation not model_det", 34);
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__call_gen__IntroducedFrom__pred__generic_call_info__267__1_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_12);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__call_gen__generic_call_info_4_0_i20,
		STATIC(mercury__call_gen__generic_call_info_4_0));
Define_label(mercury__call_gen__generic_call_info_4_0_i20);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_info_4_0));
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i17);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__call_gen__generic_call_info_4_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_13);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__call_gen__IntroducedFrom__pred__generic_call_info__271__4_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Integer) 0;
	r2 = (Word) MR_string_const("aditi_modify not model_det", 26);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__call_gen__generic_call_info_4_0_i21,
		STATIC(mercury__call_gen__generic_call_info_4_0));
Define_label(mercury__call_gen__generic_call_info_4_0_i21);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_info_4_0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 14));
	r2 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__generic_call_info_4_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6));
	r2 = (Integer) 5;
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module19)
	init_entry(mercury__call_gen__generic_call_setup_6_0);
	init_label(mercury__call_gen__generic_call_setup_6_0_i10);
	init_label(mercury__call_gen__generic_call_setup_6_0_i11);
	init_label(mercury__call_gen__generic_call_setup_6_0_i12);
	init_label(mercury__call_gen__generic_call_setup_6_0_i1032);
	init_label(mercury__call_gen__generic_call_setup_6_0_i4);
	init_label(mercury__call_gen__generic_call_setup_6_0_i5);
	init_label(mercury__call_gen__generic_call_setup_6_0_i6);
	init_label(mercury__call_gen__generic_call_setup_6_0_i7);
BEGIN_CODE

/* code for predicate 'generic_call_setup'/6 in mode 0 */
Define_static(mercury__call_gen__generic_call_setup_6_0);
	MR_incr_sp_push_msg(5, "call_gen:generic_call_setup/6");
	MR_stackvar(5) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__generic_call_setup_6_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__call_gen__generic_call_setup_6_0_i1032);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = (Word) MR_string_const("closure", 7);
	r3 = r4;
	call_localret(STATIC(mercury__call_gen__place_generic_call_var_5_0),
		mercury__call_gen__generic_call_setup_6_0_i10,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i10);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generic_call_setup_6_0_i11,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i11);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generic_call_setup_6_0_i12,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i12);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__call_gen__generic_call_setup_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Assign number of immediate input arguments", 42);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__call_gen__generic_call_setup_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_2);
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r7, (Integer) 2) = r8;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("Assign number of output arguments", 33);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__call_gen__generic_call_setup_6_0_i1032);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r3 = r4;
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__call_gen__aditi_builtin_setup__ua0_6_0),
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const("typeclass_info", 14);
	r3 = r4;
	call_localret(STATIC(mercury__call_gen__place_generic_call_var_5_0),
		mercury__call_gen__generic_call_setup_6_0_i5,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generic_call_setup_6_0_i6,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__call_gen__generic_call_setup_6_0_i7,
		STATIC(mercury__call_gen__generic_call_setup_6_0));
Define_label(mercury__call_gen__generic_call_setup_6_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__generic_call_setup_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__call_gen__generic_call_setup_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Index of class method in typeclass info", 39);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__call_gen__generic_call_setup_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_2);
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("Assign number of immediate input arguments", 42);
	MR_field(MR_mktag(3), r7, (Integer) 2) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__call_gen__generic_call_setup_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_3);
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__call_gen__generic_call_setup_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__generic_call_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r8, (Integer) 2) = r9;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Assign number of output arguments", 33);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE

Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(call_gen_module20)
	init_entry(mercury__call_gen__place_generic_call_var_5_0);
	init_label(mercury__call_gen__place_generic_call_var_5_0_i2);
	init_label(mercury__call_gen__place_generic_call_var_5_0_i3);
	init_label(mercury__call_gen__place_generic_call_var_5_0_i8);
BEGIN_CODE

/* code for predicate 'place_generic_call_var'/5 in mode 0 */
Define_static(mercury__call_gen__place_generic_call_var_5_0);
	MR_incr_sp_push_msg(4, "call_gen:place_generic_call_var/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__call_gen__place_generic_call_var_5_0_i2,
		STATIC(mercury__call_gen__place_generic_call_var_5_0));
Define_label(mercury__call_gen__place_generic_call_var_5_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__place_generic_call_var_5_0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__call_gen__place_generic_call_var_5_0_i3);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__call_gen__place_generic_call_var_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__place_generic_call_var_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__place_generic_call_var_5_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__call_gen__place_generic_call_var_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__call_gen__place_generic_call_var_5_0_i3);
	MR_stackvar(3) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("Copy ", 5);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__call_gen__place_generic_call_var_5_0_i8,
		STATIC(mercury__call_gen__place_generic_call_var_5_0));
Define_label(mercury__call_gen__place_generic_call_var_5_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__place_generic_call_var_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__place_generic_call_var_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__place_generic_call_var_5_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__call_gen__place_generic_call_var_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__call_gen__place_generic_call_var_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__call_gen__place_generic_call_var_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_0);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
END_MODULE

Declare_entry(mercury__rl__permanent_relation_name_3_0);

BEGIN_MODULE(call_gen_module21)
	init_entry(mercury__call_gen__setup_base_relation_name_4_0);
	init_label(mercury__call_gen__setup_base_relation_name_4_0_i2);
	init_label(mercury__call_gen__setup_base_relation_name_4_0_i3);
BEGIN_CODE

/* code for predicate 'setup_base_relation_name'/4 in mode 0 */
Define_static(mercury__call_gen__setup_base_relation_name_4_0);
	MR_incr_sp_push_msg(2, "call_gen:setup_base_relation_name/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__call_gen__setup_base_relation_name_4_0_i2,
		STATIC(mercury__call_gen__setup_base_relation_name_4_0));
Define_label(mercury__call_gen__setup_base_relation_name_4_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__setup_base_relation_name_4_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__rl__permanent_relation_name_3_0),
		mercury__call_gen__setup_base_relation_name_4_0_i3,
		STATIC(mercury__call_gen__setup_base_relation_name_4_0));
Define_label(mercury__call_gen__setup_base_relation_name_4_0_i3);
	update_prof_current_proc(LABEL(mercury__call_gen__setup_base_relation_name_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__call_gen__setup_base_relation_name_4_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__setup_base_relation_name_4_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__setup_base_relation_name_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__call_gen__setup_base_relation_name_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_call_gen__common_0);
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__call_gen__setup_base_relation_name_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__call_gen__setup_base_relation_name_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Assign name of base relation", 28);
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE


BEGIN_MODULE(call_gen_module22)
	init_entry(mercury__call_gen__prepare_for_call_5_0);
	init_label(mercury__call_gen__prepare_for_call_5_0_i2);
	init_label(mercury__call_gen__prepare_for_call_5_0_i4);
	init_label(mercury__call_gen__prepare_for_call_5_0_i5);
	init_label(mercury__call_gen__prepare_for_call_5_0_i6);
	init_label(mercury__call_gen__prepare_for_call_5_0_i7);
	init_label(mercury__call_gen__prepare_for_call_5_0_i8);
BEGIN_CODE

/* code for predicate 'prepare_for_call'/5 in mode 0 */
Define_static(mercury__call_gen__prepare_for_call_5_0);
	MR_incr_sp_push_msg(3, "call_gen:prepare_for_call/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__succip_is_used_2_0),
		mercury__call_gen__prepare_for_call_5_0_i2,
		STATIC(mercury__call_gen__prepare_for_call_5_0));
Define_label(mercury__call_gen__prepare_for_call_5_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__prepare_for_call_5_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__prepare_for_call_5_0_i4);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__call_gen__prepare_for_call_5_0_i4);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__prepare_for_call_5_0_i5);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__call_gen__prepare_for_call_5_0_i5);
	call_localret(ENTRY(mercury__code_info__may_use_nondet_tailcall_3_0),
		mercury__call_gen__prepare_for_call_5_0_i6,
		STATIC(mercury__call_gen__prepare_for_call_5_0));
Define_label(mercury__call_gen__prepare_for_call_5_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__prepare_for_call_5_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__call_gen__prepare_for_call_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__flush_resume_vars_to_stack_3_0),
		mercury__call_gen__prepare_for_call_5_0_i7,
		STATIC(mercury__call_gen__prepare_for_call_5_0));
Define_label(mercury__call_gen__prepare_for_call_5_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__prepare_for_call_5_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__set_resume_point_and_frame_to_unknown_2_0),
		mercury__call_gen__prepare_for_call_5_0_i8,
		STATIC(mercury__call_gen__prepare_for_call_5_0));
Define_label(mercury__call_gen__prepare_for_call_5_0_i8);
	update_prof_current_proc(LABEL(mercury__call_gen__prepare_for_call_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__generate_failure_3_0);

BEGIN_MODULE(call_gen_module23)
	init_entry(mercury__call_gen__handle_failure_4_0);
	init_label(mercury__call_gen__handle_failure_4_0_i4);
	init_label(mercury__call_gen__handle_failure_4_0_i5);
	init_label(mercury__call_gen__handle_failure_4_0_i2);
BEGIN_CODE

/* code for predicate 'handle_failure'/4 in mode 0 */
Define_static(mercury__call_gen__handle_failure_4_0);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__handle_failure_4_0_i2);
	MR_incr_sp_push_msg(3, "call_gen:handle_failure/4");
	MR_stackvar(3) = (Word) MR_succip;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__call_gen__handle_failure_4_0_i4,
		STATIC(mercury__call_gen__handle_failure_4_0));
Define_label(mercury__call_gen__handle_failure_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__handle_failure_4_0));
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 1, mercury__call_gen__handle_failure_4_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__call_gen__handle_failure_4_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__call_gen__handle_failure_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__call_gen__handle_failure_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_call_gen__common_14);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__call_gen__handle_failure_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = r2;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("test for success", 16);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__call_gen__handle_failure_4_0_i5,
		STATIC(mercury__call_gen__handle_failure_4_0));
	}
Define_label(mercury__call_gen__handle_failure_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__handle_failure_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__handle_failure_4_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__call_gen__handle_failure_4_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__call_gen__handle_failure_4_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__call_gen__handle_failure_4_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__call_gen__handle_failure_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__call_gen__handle_failure_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__call_gen__handle_failure_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__code_info__save_variable_on_stack_4_0);

BEGIN_MODULE(call_gen_module24)
	init_entry(mercury__call_gen__save_variables_2_4_0);
	init_label(mercury__call_gen__save_variables_2_4_0_i4);
	init_label(mercury__call_gen__save_variables_2_4_0_i5);
	init_label(mercury__call_gen__save_variables_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'save_variables_2'/4 in mode 0 */
Define_static(mercury__call_gen__save_variables_2_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__save_variables_2_4_0_i3);
	MR_incr_sp_push_msg(2, "call_gen:save_variables_2/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__save_variable_on_stack_4_0),
		mercury__call_gen__save_variables_2_4_0_i4,
		STATIC(mercury__call_gen__save_variables_2_4_0));
Define_label(mercury__call_gen__save_variables_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_2_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__call_gen__save_variables_2_4_0,
		LABEL(mercury__call_gen__save_variables_2_4_0_i5),
		STATIC(mercury__call_gen__save_variables_2_4_0));
Define_label(mercury__call_gen__save_variables_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__save_variables_2_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__call_gen__save_variables_2_4_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__call_gen__save_variables_2_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module25)
	init_entry(mercury__call_gen__rebuild_registers_3_0);
	init_label(mercury__call_gen__rebuild_registers_3_0_i2);
BEGIN_CODE

/* code for predicate 'rebuild_registers'/3 in mode 0 */
Define_static(mercury__call_gen__rebuild_registers_3_0);
	MR_incr_sp_push_msg(2, "call_gen:rebuild_registers/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__call_gen__rebuild_registers_3_0_i2,
		STATIC(mercury__call_gen__rebuild_registers_3_0));
Define_label(mercury__call_gen__rebuild_registers_3_0_i2);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__call_gen__rebuild_registers_2_3_0),
		STATIC(mercury__call_gen__rebuild_registers_3_0));
END_MODULE

Declare_entry(mercury__code_util__arg_loc_to_register_2_0);
Declare_entry(mercury__code_info__set_var_location_4_0);

BEGIN_MODULE(call_gen_module26)
	init_entry(mercury__call_gen__rebuild_registers_2_3_0);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i1002);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i6);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i4);
	init_label(mercury__call_gen__rebuild_registers_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'rebuild_registers_2'/3 in mode 0 */
Define_static(mercury__call_gen__rebuild_registers_2_3_0);
	MR_incr_sp_push_msg(4, "call_gen:rebuild_registers_2/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr3, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i4);
	MR_stackvar(3) = r3;
	r1 = MR_const_field(MR_mktag(0), MR_tempr3, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__call_gen__rebuild_registers_2_3_0_i6,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
	}
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__set_var_location_4_0),
		mercury__call_gen__rebuild_registers_2_3_0_i7,
		STATIC(mercury__call_gen__rebuild_registers_2_3_0));
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__call_gen__rebuild_registers_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i1002);
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i4);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__call_gen__rebuild_registers_2_3_0_i1002);
Define_label(mercury__call_gen__rebuild_registers_2_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module27)
	init_entry(mercury__call_gen__input_args_2_0);
	init_label(mercury__call_gen__input_args_2_0_i7);
	init_label(mercury__call_gen__input_args_2_0_i8);
	init_label(mercury__call_gen__input_args_2_0_i6);
	init_label(mercury__call_gen__input_args_2_0_i2);
BEGIN_CODE

/* code for predicate 'input_args'/2 in mode 0 */
Define_static(mercury__call_gen__input_args_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i2);
	r3 = (Word) MR_sp;
Define_label(mercury__call_gen__input_args_2_0_i7);
	while (1) {
	MR_incr_sp_push_msg(2, "call_gen:input_args");
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__call_gen__input_args_2_0_i8);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i6);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__input_args_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
Define_label(mercury__call_gen__input_args_2_0_i6);
	MR_decr_sp_pop_msg(2);
	if (((Integer) MR_sp > (Integer) r3))
		GOTO_LABEL(mercury__call_gen__input_args_2_0_i8);
	proceed();
Define_label(mercury__call_gen__input_args_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__code_info__place_var_5_0);

BEGIN_MODULE(call_gen_module28)
	init_entry(mercury__call_gen__generate_immediate_args_6_0);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i4);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i5);
	init_label(mercury__call_gen__generate_immediate_args_6_0_i3);
BEGIN_CODE

/* code for predicate 'generate_immediate_args'/6 in mode 0 */
Define_static(mercury__call_gen__generate_immediate_args_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__generate_immediate_args_6_0_i3);
	MR_incr_sp_push_msg(4, "call_gen:generate_immediate_args/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_immediate_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_tempr1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__place_var_5_0),
		mercury__call_gen__generate_immediate_args_6_0_i4,
		STATIC(mercury__call_gen__generate_immediate_args_6_0));
	}
Define_label(mercury__call_gen__generate_immediate_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_immediate_args_6_0));
	r3 = r2;
	r2 = ((Integer) MR_stackvar(1) + (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__call_gen__generate_immediate_args_6_0,
		LABEL(mercury__call_gen__generate_immediate_args_6_0_i5),
		STATIC(mercury__call_gen__generate_immediate_args_6_0));
Define_label(mercury__call_gen__generate_immediate_args_6_0_i5);
	update_prof_current_proc(LABEL(mercury__call_gen__generate_immediate_args_6_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__generate_immediate_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__call_gen__generate_immediate_args_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__call_gen__generate_immediate_args_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(call_gen_module29)
	init_entry(mercury__call_gen__outvars_to_outargs_3_0);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i5);
	init_label(mercury__call_gen__outvars_to_outargs_3_0_i2);
BEGIN_CODE

/* code for predicate 'outvars_to_outargs'/3 in mode 0 */
Define_static(mercury__call_gen__outvars_to_outargs_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__call_gen__outvars_to_outargs_3_0_i2);
	r5 = (Word) MR_sp;
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "call_gen:outvars_to_outargs");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__outvars_to_outargs_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__call_gen__outvars_to_outargs_3_0, "hlds_pred:arg_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = r3;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r4 = r2;
	r2 = ((Integer) r4 + (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__call_gen__outvars_to_outargs_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r5))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__call_gen__outvars_to_outargs_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__call_gen_maybe_bunch_0(void)
{
	call_gen_module0();
	call_gen_module1();
	call_gen_module2();
	call_gen_module3();
	call_gen_module4();
	call_gen_module5();
	call_gen_module6();
	call_gen_module7();
	call_gen_module8();
	call_gen_module9();
	call_gen_module10();
	call_gen_module11();
	call_gen_module12();
	call_gen_module13();
	call_gen_module14();
	call_gen_module15();
	call_gen_module16();
	call_gen_module17();
	call_gen_module18();
	call_gen_module19();
	call_gen_module20();
	call_gen_module21();
	call_gen_module22();
	call_gen_module23();
	call_gen_module24();
	call_gen_module25();
	call_gen_module26();
	call_gen_module27();
	call_gen_module28();
	call_gen_module29();
}

#endif

void mercury__call_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__call_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__call_gen_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
