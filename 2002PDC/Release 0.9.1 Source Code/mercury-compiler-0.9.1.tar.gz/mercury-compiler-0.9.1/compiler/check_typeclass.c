/*
** Automatically generated from `check_typeclass.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__check_typeclass__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___check_typeclass__triple_3__ua0_2_0);
Declare_static(mercury____Index___check_typeclass__instance_method_info_0__ua0_2_0);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0_i2);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1011);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1013);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1011);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1013);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__385__7_2_0);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__339__6_3_0);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i2);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i3);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i4);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1005);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_class_instance__185__3_2_0);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0);
Declare_label(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0_i1);
Declare_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_decls__87__1_3_0);
Define_extern_entry(mercury__check_typeclass__check_instance_decls_5_0);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i2);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i3);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i4);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i5);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i8);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i9);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i6);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i10);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i11);
Declare_label(mercury__check_typeclass__check_instance_decls_5_0_i12);
Declare_static(mercury__check_typeclass__check_one_class_5_0);
Declare_label(mercury__check_typeclass__check_one_class_5_0_i2);
Declare_label(mercury__check_typeclass__check_one_class_5_0_i3);
Declare_label(mercury__check_typeclass__check_one_class_5_0_i4);
Declare_static(mercury__check_typeclass__check_class_instance_10_0);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i3);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i4);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i6);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i5);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i8);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i10);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i11);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i12);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i7);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i14);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i15);
Declare_label(mercury__check_typeclass__check_class_instance_10_0_i16);
Declare_static(mercury__check_typeclass__check_instance_pred_8_0);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i2);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i3);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i4);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i5);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i6);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i8);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i9);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i10);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i11);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i12);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i13);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i14);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i15);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i16);
Declare_label(mercury__check_typeclass__check_instance_pred_8_0_i17);
Declare_static(mercury__check_typeclass__check_instance_pred_procs_7_0);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i2);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i6);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i7);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i1002);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i9);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i3);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i14);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i15);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i17);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i18);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i19);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i20);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i21);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i22);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i23);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i11);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i24);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i25);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i27);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i28);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i29);
Declare_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i30);
Declare_static(mercury__check_typeclass__get_matching_instance_names_5_0);
Declare_label(mercury__check_typeclass__get_matching_instance_names_5_0_i3);
Declare_static(mercury__check_typeclass__produce_auxiliary_procs_10_0);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i2);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i3);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i4);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i5);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i6);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i7);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i8);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i9);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i10);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i11);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i12);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i13);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i14);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i15);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i16);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i17);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i18);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i19);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i20);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i21);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i22);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i23);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i24);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i1001);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i27);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i26);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i28);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i29);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i30);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i31);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i32);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i33);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i34);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i35);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i36);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i38);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i39);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i40);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i41);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i42);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i43);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i44);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i45);
Declare_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i46);
Declare_static(mercury__check_typeclass__make_introduced_pred_name_5_0);
Declare_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i2);
Declare_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i3);
Declare_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i4);
Declare_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i5);
Declare_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i6);
Declare_static(mercury__check_typeclass__check_superclass_conformance_8_0);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i2);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i3);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i4);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i6);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i5);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i8);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i9);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i10);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i11);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i12);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i13);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i14);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i16);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i17);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i19);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i20);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i21);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i22);
Declare_label(mercury__check_typeclass__check_superclass_conformance_8_0_i23);
Declare_static(mercury__check_typeclass__constraint_list_to_string_2_3_0);
Declare_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i4);
Declare_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i5);
Declare_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i3);
Declare_static(mercury____Unify___check_typeclass__error_message_0_0);
Declare_static(mercury____Index___check_typeclass__error_message_0_0);
Declare_static(mercury____Compare___check_typeclass__error_message_0_0);
Declare_static(mercury____Unify___check_typeclass__error_messages_0_0);
Declare_static(mercury____Index___check_typeclass__error_messages_0_0);
Declare_static(mercury____Compare___check_typeclass__error_messages_0_0);
Declare_static(mercury____Unify___check_typeclass__instance_method_info_0_0);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i2);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i4);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i6);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i8);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i10);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i12);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i14);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i16);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i18);
Declare_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
Declare_static(mercury____Index___check_typeclass__instance_method_info_0_0);
Declare_static(mercury____Compare___check_typeclass__instance_method_info_0_0);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i3);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i7);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i11);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i15);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i19);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i23);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i27);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i31);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i35);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i39);
Declare_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
Declare_static(mercury____Unify___check_typeclass__triple_3_0);
Declare_label(mercury____Unify___check_typeclass__triple_3_0_i2);
Declare_label(mercury____Unify___check_typeclass__triple_3_0_i4);
Declare_label(mercury____Unify___check_typeclass__triple_3_0_i1);
Declare_static(mercury____Index___check_typeclass__triple_3_0);
Declare_static(mercury____Compare___check_typeclass__triple_3_0);
Declare_label(mercury____Compare___check_typeclass__triple_3_0_i3);
Declare_label(mercury____Compare___check_typeclass__triple_3_0_i7);
Declare_label(mercury____Compare___check_typeclass__triple_3_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_error_message_0;

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_error_messages_0;

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_instance_method_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_triple_3;

static const struct mercury_data_check_typeclass__common_0_struct {
	String f1;
}  mercury_data_check_typeclass__common_0;

static const struct mercury_data_check_typeclass__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_1;

static const struct mercury_data_check_typeclass__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_2;

static const struct mercury_data_check_typeclass__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_3;

static const struct mercury_data_check_typeclass__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_4;

static const struct mercury_data_check_typeclass__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_5;

static const struct mercury_data_check_typeclass__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_6;

static const struct mercury_data_check_typeclass__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_7;

static const struct mercury_data_check_typeclass__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_8;

static const struct mercury_data_check_typeclass__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_check_typeclass__common_9;

static const struct mercury_data_check_typeclass__common_10_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_10;

static const struct mercury_data_check_typeclass__common_11_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_check_typeclass__common_11;

static const struct mercury_data_check_typeclass__common_12_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_check_typeclass__common_12;

static const struct mercury_data_check_typeclass__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_13;

static const struct mercury_data_check_typeclass__common_14_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_14;

static const struct mercury_data_check_typeclass__common_15_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_check_typeclass__common_15;

static const struct mercury_data_check_typeclass__common_16_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_16;

static const struct mercury_data_check_typeclass__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_17;

static const struct mercury_data_check_typeclass__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_18;

static const struct mercury_data_check_typeclass__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_19;

static const struct mercury_data_check_typeclass__common_20_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_20;

static const struct mercury_data_check_typeclass__common_21_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_21;

static const struct mercury_data_check_typeclass__common_22_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_22;

static const struct mercury_data_check_typeclass__common_23_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
	Word * f17;
	Word * f18;
}  mercury_data_check_typeclass__common_23;

static const struct mercury_data_check_typeclass__common_24_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
}  mercury_data_check_typeclass__common_24;

static const struct mercury_data_check_typeclass__common_25_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_25;

static const struct mercury_data_check_typeclass__common_26_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_26;

static const struct mercury_data_check_typeclass__common_27_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_check_typeclass__common_27;

static const struct mercury_data_check_typeclass__common_28_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_check_typeclass__common_28;

static const struct mercury_data_check_typeclass__common_29_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_29;

static const struct mercury_data_check_typeclass__common_30_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_30;

static const struct mercury_data_check_typeclass__common_31_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_31;

static const struct mercury_data_check_typeclass__common_32_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_check_typeclass__common_32;

static const struct mercury_data_check_typeclass__common_33_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_33;

static const struct mercury_data_check_typeclass__common_34_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_34;

static const struct mercury_data_check_typeclass__common_35_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_35;

static const struct mercury_data_check_typeclass__common_36_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_check_typeclass__common_36;

static const struct mercury_data_check_typeclass__common_37_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_check_typeclass__common_37;

static const struct mercury_data_check_typeclass__common_38_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_38;

static const struct mercury_data_check_typeclass__common_39_struct {
	String f1;
}  mercury_data_check_typeclass__common_39;

static const struct mercury_data_check_typeclass__common_40_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_40;

static const struct mercury_data_check_typeclass__common_41_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_check_typeclass__common_41;

static const struct mercury_data_check_typeclass__common_42_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_check_typeclass__common_42;

static const struct mercury_data_check_typeclass__common_43_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_check_typeclass__common_43;

static const struct mercury_data_check_typeclass__common_44_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_44;

static const struct mercury_data_check_typeclass__common_45_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_45;

static const struct mercury_data_check_typeclass__common_46_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_46;

static const struct mercury_data_check_typeclass__common_47_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_check_typeclass__common_47;

static const struct mercury_data_check_typeclass__common_48_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_check_typeclass__common_48;

static const struct mercury_data_check_typeclass__common_49_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_49;

static const struct mercury_data_check_typeclass__common_50_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_50;

static const struct mercury_data_check_typeclass__common_51_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_51;

static const struct mercury_data_check_typeclass__common_52_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_52;

static const struct mercury_data_check_typeclass__common_53_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_check_typeclass__common_53;

static const struct mercury_data_check_typeclass__common_54_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_54;

static const struct mercury_data_check_typeclass__common_55_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_55;

static const struct mercury_data_check_typeclass__common_56_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_56;

static const struct mercury_data_check_typeclass__common_57_struct {
	String f1;
	Word * f2;
}  mercury_data_check_typeclass__common_57;

static const struct mercury_data_check_typeclass__common_58_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_check_typeclass__common_58;

static const struct mercury_data_check_typeclass__common_59_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_59;

static const struct mercury_data_check_typeclass__common_60_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_60;

static const struct mercury_data_check_typeclass__common_61_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_61;

static const struct mercury_data_check_typeclass__common_62_struct {
	Word * f1;
	Word * f2;
}  mercury_data_check_typeclass__common_62;

static const struct mercury_data_check_typeclass__common_63_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_63;

static const struct mercury_data_check_typeclass__common_64_struct {
	Word * f1;
}  mercury_data_check_typeclass__common_64;

static const struct mercury_data_check_typeclass__common_65_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	String f13;
	Word * f14;
	Integer f15;
	Integer f16;
}  mercury_data_check_typeclass__common_65;

static const struct mercury_data_check_typeclass__common_66_struct {
	Integer f1;
	Word * f2;
}  mercury_data_check_typeclass__common_66;

static const struct mercury_data_check_typeclass__common_67_struct {
	Integer f1;
	Word * f2;
}  mercury_data_check_typeclass__common_67;

static const struct mercury_data_check_typeclass__type_ctor_functors_triple_3_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_check_typeclass__type_ctor_functors_triple_3;

static const struct mercury_data_check_typeclass__type_ctor_layout_triple_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_check_typeclass__type_ctor_layout_triple_3;

static const struct mercury_data_check_typeclass__type_ctor_functors_instance_method_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_check_typeclass__type_ctor_functors_instance_method_info_0;

static const struct mercury_data_check_typeclass__type_ctor_layout_instance_method_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_check_typeclass__type_ctor_layout_instance_method_info_0;

static const struct mercury_data_check_typeclass__type_ctor_functors_error_messages_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_check_typeclass__type_ctor_functors_error_messages_0;

static const struct mercury_data_check_typeclass__type_ctor_layout_error_messages_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_check_typeclass__type_ctor_layout_error_messages_0;

static const struct mercury_data_check_typeclass__type_ctor_functors_error_message_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_check_typeclass__type_ctor_functors_error_message_0;

static const struct mercury_data_check_typeclass__type_ctor_layout_error_message_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_check_typeclass__type_ctor_layout_error_message_0;

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_error_message_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___check_typeclass__error_message_0_0),
	STATIC(mercury____Index___check_typeclass__error_message_0_0),
	STATIC(mercury____Compare___check_typeclass__error_message_0_0),
	(Integer) 6,
	(Word *) &mercury_data_check_typeclass__type_ctor_functors_error_message_0,
	(Word *) &mercury_data_check_typeclass__type_ctor_layout_error_message_0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("error_message", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_error_messages_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___check_typeclass__error_messages_0_0),
	STATIC(mercury____Index___check_typeclass__error_messages_0_0),
	STATIC(mercury____Compare___check_typeclass__error_messages_0_0),
	(Integer) 6,
	(Word *) &mercury_data_check_typeclass__type_ctor_functors_error_messages_0,
	(Word *) &mercury_data_check_typeclass__type_ctor_layout_error_messages_0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("error_messages", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_instance_method_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0),
	STATIC(mercury____Index___check_typeclass__instance_method_info_0_0),
	STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_check_typeclass__type_ctor_functors_instance_method_info_0,
	(Word *) &mercury_data_check_typeclass__type_ctor_layout_instance_method_info_0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("instance_method_info", 20),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_check_typeclass__type_ctor_info_triple_3 = {
	(Integer) 3,
	STATIC(mercury____Unify___check_typeclass__triple_3_0),
	STATIC(mercury____Index___check_typeclass__triple_3_0),
	STATIC(mercury____Compare___check_typeclass__triple_3_0),
	(Integer) 2,
	(Word *) &mercury_data_check_typeclass__type_ctor_functors_triple_3,
	(Word *) &mercury_data_check_typeclass__type_ctor_layout_triple_3,
	MR_string_const("check_typeclass", 15),
	MR_string_const("triple", 6),
	(Integer) 3
};

static const struct mercury_data_check_typeclass__common_0_struct mercury_data_check_typeclass__common_0 = {
	MR_string_const("Subsequent definition appears here.", 35)
};

static const struct mercury_data_check_typeclass__common_1_struct mercury_data_check_typeclass__common_1 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_check_typeclass__common_0),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
static const struct mercury_data_check_typeclass__common_2_struct mercury_data_check_typeclass__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_class_id_0;
static const struct mercury_data_check_typeclass__common_3_struct mercury_data_check_typeclass__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_error_util__type_ctor_info_format_component_0;
static const struct mercury_data_check_typeclass__common_4_struct mercury_data_check_typeclass__common_4 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_error_util__type_ctor_info_format_component_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_check_typeclass__common_5_struct mercury_data_check_typeclass__common_5 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_term__type_ctor_info_context_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_4)
};

static const struct mercury_data_check_typeclass__common_6_struct mercury_data_check_typeclass__common_6 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_check_typeclass__common_7_struct mercury_data_check_typeclass__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_6),
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
static const struct mercury_data_check_typeclass__common_8_struct mercury_data_check_typeclass__common_8 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0
};

static const struct mercury_data_check_typeclass__common_9_struct mercury_data_check_typeclass__common_9 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_one_class", 15),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_check_typeclass__common_10_struct mercury_data_check_typeclass__common_10 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_check_typeclass__common_11_struct mercury_data_check_typeclass__common_11 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_instance_decls__87__1", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_10)
};

static const struct mercury_data_check_typeclass__common_12_struct mercury_data_check_typeclass__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_11),
	STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_decls__87__1_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
static const struct mercury_data_check_typeclass__common_13_struct mercury_data_check_typeclass__common_13 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_check_typeclass__common_14_struct mercury_data_check_typeclass__common_14 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_check_typeclass__common_15_struct mercury_data_check_typeclass__common_15 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_one_class__112__2", 45),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_14)
};

static const struct mercury_data_check_typeclass__common_16_struct mercury_data_check_typeclass__common_16 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;
static const struct mercury_data_check_typeclass__common_17_struct mercury_data_check_typeclass__common_17 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_check_typeclass__common_18_struct mercury_data_check_typeclass__common_18 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_check_typeclass__common_19_struct mercury_data_check_typeclass__common_19 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_check_typeclass__common_20_struct mercury_data_check_typeclass__common_20 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_check_typeclass__common_21_struct mercury_data_check_typeclass__common_21 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_check_typeclass__common_22_struct mercury_data_check_typeclass__common_22 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0
};

static const struct mercury_data_check_typeclass__common_23_struct mercury_data_check_typeclass__common_23 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_class_instance", 20),
	10,
	0,
	0,
	10,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_16),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_19),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_20),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_21),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7)
};

static const struct mercury_data_check_typeclass__common_24_struct mercury_data_check_typeclass__common_24 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_instance_pred", 19),
	8,
	0,
	0,
	8,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_16),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_19),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7)
};

static const struct mercury_data_check_typeclass__common_25_struct mercury_data_check_typeclass__common_25 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_check_typeclass__common_26_struct mercury_data_check_typeclass__common_26 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0
};

static const struct mercury_data_check_typeclass__common_27_struct mercury_data_check_typeclass__common_27 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_class_instance__185__3", 50),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_26),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_14)
};

static const struct mercury_data_check_typeclass__common_28_struct mercury_data_check_typeclass__common_28 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_27),
	STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_class_instance__185__3_2_0),
	(Integer) 0
};

static const struct mercury_data_check_typeclass__common_29_struct mercury_data_check_typeclass__common_29 = {
	MR_string_const("incorrect method name(s).", 25),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_check_typeclass__common_30_struct mercury_data_check_typeclass__common_30 = {
	MR_string_const("': ", 3),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_29)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
static const struct mercury_data_check_typeclass__common_31_struct mercury_data_check_typeclass__common_31 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

static const struct mercury_data_check_typeclass__common_32_struct mercury_data_check_typeclass__common_32 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_instance_pred__250__4", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_31)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
static const struct mercury_data_check_typeclass__common_33_struct mercury_data_check_typeclass__common_33 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_mode_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_determinism_0;
static const struct mercury_data_check_typeclass__common_34_struct mercury_data_check_typeclass__common_34 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_33),
	(Word *) &mercury_data_prog_data__type_ctor_info_determinism_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_data_check_typeclass__common_35_struct mercury_data_check_typeclass__common_35 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_check_typeclass__common_36_struct mercury_data_check_typeclass__common_36 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_instance_pred__280__5", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34)
};

static const struct mercury_data_check_typeclass__common_37_struct mercury_data_check_typeclass__common_37 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_instance_pred_procs__339__6", 55),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_26)
};

static const struct mercury_data_check_typeclass__common_38_struct mercury_data_check_typeclass__common_38 = {
	MR_string_const("'.", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_check_typeclass__common_39_struct mercury_data_check_typeclass__common_39 = {
	MR_string_const("First definition appears here.", 30)
};

static const struct mercury_data_check_typeclass__common_40_struct mercury_data_check_typeclass__common_40 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_check_typeclass__common_39),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_check_typeclass__common_41_struct mercury_data_check_typeclass__common_41 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_check_typeclass__common_42_struct mercury_data_check_typeclass__common_42 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__check_instance_pred_procs__385__7", 55),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5)
};

static const struct mercury_data_check_typeclass__common_43_struct mercury_data_check_typeclass__common_43 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_42),
	STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__385__7_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_instance_body_0;
static const struct mercury_data_check_typeclass__common_44_struct mercury_data_check_typeclass__common_44 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_instance_body_0
};

static const struct mercury_data_check_typeclass__common_45_struct mercury_data_check_typeclass__common_45 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_check_typeclass__common_46_struct mercury_data_check_typeclass__common_46 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_check_typeclass__common_47_struct mercury_data_check_typeclass__common_47 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__get_matching_instance_names__437__9", 57),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_44),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_45),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_46),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41)
};

static const struct mercury_data_check_typeclass__common_48_struct mercury_data_check_typeclass__common_48 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__get_matching_instance_names__452__8", 57),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_44),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_45),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_46),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
static const struct mercury_data_check_typeclass__common_49_struct mercury_data_check_typeclass__common_49 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_check_typeclass__common_50_struct mercury_data_check_typeclass__common_50 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_check_typeclass__common_51_struct mercury_data_check_typeclass__common_51 = {
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
static const struct mercury_data_check_typeclass__common_52_struct mercury_data_check_typeclass__common_52 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

static const struct mercury_data_check_typeclass__common_53_struct mercury_data_check_typeclass__common_53 = {
	(Integer) 0,
	MR_string_const("check_typeclass", 15),
	MR_string_const("check_typeclass", 15),
	MR_string_const("IntroducedFrom__pred__produce_auxiliary_procs__551__10", 54),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_51),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_46),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_52),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_52)
};

static const struct mercury_data_check_typeclass__common_54_struct mercury_data_check_typeclass__common_54 = {
	MR_string_const(".", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_check_typeclass__common_55_struct mercury_data_check_typeclass__common_55 = {
	MR_string_const("", 0),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_54)
};

static const struct mercury_data_check_typeclass__common_56_struct mercury_data_check_typeclass__common_56 = {
	MR_string_const("superclass constraint(s) not satisfied: ", 40),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_55)
};

static const struct mercury_data_check_typeclass__common_57_struct mercury_data_check_typeclass__common_57 = {
	MR_string_const(")': ", 4),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_56)
};

static const struct mercury_data_check_typeclass__common_58_struct mercury_data_check_typeclass__common_58 = {
	(Integer) 3,
	(Integer) 1,
	(Integer) 2,
	(Integer) 3,
	MR_string_const("triple", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_check_typeclass__common_59_struct mercury_data_check_typeclass__common_59 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_check_typeclass__common_60_struct mercury_data_check_typeclass__common_60 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraints_0;
static const struct mercury_data_check_typeclass__common_61_struct mercury_data_check_typeclass__common_61 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraints_0
};

static const struct mercury_data_check_typeclass__common_62_struct mercury_data_check_typeclass__common_62 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_import_status_0;
static const struct mercury_data_check_typeclass__common_63_struct mercury_data_check_typeclass__common_63 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_import_status_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_pred_or_func_0;
static const struct mercury_data_check_typeclass__common_64_struct mercury_data_check_typeclass__common_64 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_pred_or_func_0
};

static const struct mercury_data_check_typeclass__common_65_struct mercury_data_check_typeclass__common_65 = {
	(Integer) 11,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_59),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_45),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_46),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_60),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_61),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_62),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_63),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_64),
	MR_string_const("instance_method_info", 20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_check_typeclass__common_66_struct mercury_data_check_typeclass__common_66 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_6)
};

static const struct mercury_data_check_typeclass__common_67_struct mercury_data_check_typeclass__common_67 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5)
};

static const struct mercury_data_check_typeclass__type_ctor_functors_triple_3_struct mercury_data_check_typeclass__type_ctor_functors_triple_3 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_58)
};

static const struct mercury_data_check_typeclass__type_ctor_layout_triple_3_struct mercury_data_check_typeclass__type_ctor_layout_triple_3 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_58),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_check_typeclass__type_ctor_functors_instance_method_info_0_struct mercury_data_check_typeclass__type_ctor_functors_instance_method_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_65)
};

static const struct mercury_data_check_typeclass__type_ctor_layout_instance_method_info_0_struct mercury_data_check_typeclass__type_ctor_layout_instance_method_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_65),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_check_typeclass__type_ctor_functors_error_messages_0_struct mercury_data_check_typeclass__type_ctor_functors_error_messages_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_6)
};

static const struct mercury_data_check_typeclass__type_ctor_layout_error_messages_0_struct mercury_data_check_typeclass__type_ctor_layout_error_messages_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_66)
};

static const struct mercury_data_check_typeclass__type_ctor_functors_error_message_0_struct mercury_data_check_typeclass__type_ctor_functors_error_message_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5)
};

static const struct mercury_data_check_typeclass__type_ctor_layout_error_message_0_struct mercury_data_check_typeclass__type_ctor_layout_error_message_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_67),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_67),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_67),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_check_typeclass__common_67)
};


BEGIN_MODULE(check_typeclass_module0)
	init_entry(mercury____Index___check_typeclass__triple_3__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___check_typeclass__triple_3__ua0'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__triple_3__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(check_typeclass_module1)
	init_entry(mercury____Index___check_typeclass__instance_method_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___check_typeclass__instance_method_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__instance_method_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__make_hlds__add_new_proc_10_0);

BEGIN_MODULE(check_typeclass_module2)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__produce_auxiliary_procs__551__10'/6 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0);
	MR_incr_sp_push_msg(1, "check_typeclass:IntroducedFrom__pred__produce_auxiliary_procs__551__10/6");
	MR_stackvar(1) = (Word) MR_succip;
	r7 = r1;
	r1 = r4;
	r8 = r3;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r3;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_const_field(MR_mktag(0), r8, (Integer) 1);
	r8 = (Integer) 0;
	call_localret(ENTRY(mercury__make_hlds__add_new_proc_10_0),
		mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0_i2,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0));
	r3 = r1;
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(do_redo);
Declare_entry(do_fail);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_instance_method_0;
Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);

BEGIN_MODULE(check_typeclass_module3)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1011);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1013);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_matching_instance_names__437__9'/4 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	MR_mkframe("check_typeclass:IntroducedFrom__pred__get_matching_instance_names__437__9/4", 5, ENTRY(do_fail));
	MR_framevar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_instance_method_0;
	MR_framevar(2) = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1011,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1011);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_framevar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_framevar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_framevar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r1 = MR_framevar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1013,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0_i1013);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	if ((MR_framevar(2) != MR_framevar(5)))
		GOTO(ENTRY(do_redo));
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_framevar(4);
	MR_succeed();
END_MODULE


BEGIN_MODULE(check_typeclass_module4)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1011);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1013);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_matching_instance_names__452__8'/4 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	MR_mkframe("check_typeclass:IntroducedFrom__pred__get_matching_instance_names__452__8/4", 5, ENTRY(do_fail));
	MR_framevar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_instance_method_0;
	MR_framevar(2) = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1011,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1011);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO(ENTRY(do_redo));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_framevar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_framevar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = MR_framevar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1013,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0_i1013);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	if ((MR_framevar(2) != MR_framevar(5)))
		GOTO(ENTRY(do_redo));
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_framevar(4);
	MR_succeed();
END_MODULE


BEGIN_MODULE(check_typeclass_module5)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__385__7_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_instance_pred_procs__385__7'/2 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__385__7_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__385__7_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_1);
	proceed();
END_MODULE


BEGIN_MODULE(check_typeclass_module6)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__339__6_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_instance_pred_procs__339__6'/3 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__339__6_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__339__6_3_0, "hlds_data:hlds_class_proc/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);

BEGIN_MODULE(check_typeclass_module7)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i2);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i3);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i4);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_instance_pred__280__5'/3 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0);
	MR_incr_sp_push_msg(2, "check_typeclass:IntroducedFrom__pred__check_instance_pred__280__5/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i2,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i3,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i4,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);

BEGIN_MODULE(check_typeclass_module8)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1005);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_instance_pred__250__4'/3 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0);
	MR_mkframe("check_typeclass:IntroducedFrom__pred__check_instance_pred__250__4/3", 2, ENTRY(do_fail));
	MR_framevar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_framevar(1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1005,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0_i1005);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(2);
	MR_succeed();
END_MODULE


BEGIN_MODULE(check_typeclass_module9)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_class_instance__185__3_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_class_instance__185__3'/2 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_class_instance__185__3_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(check_typeclass_module10)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0);
	init_label(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_one_class__112__2'/2 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0);
	MR_mkframe("check_typeclass:IntroducedFrom__pred__check_one_class__112__2/2", 0, ENTRY(do_fail));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0_i1,
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0));
Define_label(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0_i1);
	update_prof_current_proc(LABEL(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succeed();
END_MODULE

Declare_entry(mercury__error_util__write_error_pieces_5_0);

BEGIN_MODULE(check_typeclass_module11)
	init_entry(mercury__check_typeclass__IntroducedFrom__pred__check_instance_decls__87__1_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_instance_decls__87__1'/3 in mode 0 */
Define_static(mercury__check_typeclass__IntroducedFrom__pred__check_instance_decls__87__1_3_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r4 = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = (Integer) 0;
	tailcall(ENTRY(mercury__error_util__write_error_pieces_5_0),
		STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_decls__87__1_3_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_classes_2_0);
Declare_entry(mercury__hlds_module__module_info_instances_2_0);
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__list__map_foldl_5_1);
Declare_entry(mercury__map__from_assoc_list_2_0);
Declare_entry(mercury__hlds_module__module_info_set_instances_3_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__list__foldl_4_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(check_typeclass_module12)
	init_entry(mercury__check_typeclass__check_instance_decls_5_0);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i2);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i3);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i4);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i5);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i8);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i9);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i6);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i10);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i11);
	init_label(mercury__check_typeclass__check_instance_decls_5_0_i12);
BEGIN_CODE

/* code for predicate 'check_instance_decls'/5 in mode 0 */
Define_entry(mercury__check_typeclass__check_instance_decls_5_0);
	MR_incr_sp_push_msg(4, "check_typeclass:check_instance_decls/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_classes_2_0),
		mercury__check_typeclass__check_instance_decls_5_0_i2,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_instances_2_0),
		mercury__check_typeclass__check_instance_decls_5_0_i3,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_2);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__check_typeclass__check_instance_decls_5_0_i4,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7);
	r5 = r1;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__check_typeclass__check_instance_decls_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__check_one_class_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_3);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_decls_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r6, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__check_typeclass__check_instance_decls_5_0_i5,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i5);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_decls_5_0_i6);
	MR_stackvar(1) = r3;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_2);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__check_typeclass__check_instance_decls_5_0_i8,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i8);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_instances_3_0),
		mercury__check_typeclass__check_instance_decls_5_0_i9,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i9);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r2 = (Integer) 0;
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i6);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r2 = r4;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__check_typeclass__check_instance_decls_5_0_i10,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i10);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_12);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__check_typeclass__check_instance_decls_5_0_i11,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i11);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r2 = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__check_typeclass__check_instance_decls_5_0_i12,
		ENTRY(mercury__check_typeclass__check_instance_decls_5_0));
Define_label(mercury__check_typeclass__check_instance_decls_5_0_i12);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_decls_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__std_util__solutions_2_1);

BEGIN_MODULE(check_typeclass_module13)
	init_entry(mercury__check_typeclass__check_one_class_5_0);
	init_label(mercury__check_typeclass__check_one_class_5_0_i2);
	init_label(mercury__check_typeclass__check_one_class_5_0_i3);
	init_label(mercury__check_typeclass__check_one_class_5_0_i4);
BEGIN_CODE

/* code for predicate 'check_one_class'/5 in mode 0 */
Define_static(mercury__check_typeclass__check_one_class_5_0);
	MR_incr_sp_push_msg(8, "check_typeclass:check_one_class/5");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = r4;
	r3 = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__check_typeclass__check_one_class_5_0_i2,
		STATIC(mercury__check_typeclass__check_one_class_5_0));
Define_label(mercury__check_typeclass__check_one_class_5_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_one_class_5_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__check_typeclass__check_one_class_5_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(6) = r3;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_15);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_one_class__112__2_2_0);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__check_typeclass__check_one_class_5_0_i3,
		STATIC(mercury__check_typeclass__check_one_class_5_0));
Define_label(mercury__check_typeclass__check_one_class_5_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_one_class_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 9, mercury__check_typeclass__check_one_class_5_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_23);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__check_class_instance_10_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 6;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r4, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 6) = MR_stackvar(6);
	MR_field(MR_mktag(0), r4, (Integer) 7) = MR_stackvar(7);
	MR_field(MR_mktag(0), r4, (Integer) 8) = r5;
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__check_typeclass__check_one_class_5_0_i4,
		STATIC(mercury__check_typeclass__check_one_class_5_0));
Define_label(mercury__check_typeclass__check_one_class_5_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_one_class_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_one_class_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__list__foldl2_6_0);
Declare_entry(mercury__list__same_length_2_2);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__remove_dups_2_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(check_typeclass_module14)
	init_entry(mercury__check_typeclass__check_class_instance_10_0);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i3);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i4);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i6);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i5);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i8);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i10);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i11);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i12);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i7);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i14);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i15);
	init_label(mercury__check_typeclass__check_class_instance_10_0_i16);
BEGIN_CODE

/* code for predicate 'check_class_instance'/10 in mode 0 */
Define_static(mercury__check_typeclass__check_class_instance_10_0);
	MR_incr_sp_push_msg(12, "check_typeclass:check_class_instance/10");
	MR_stackvar(12) = (Word) MR_succip;
	r9 = MR_const_field(MR_mktag(0), r7, (Integer) 4);
	if (((Integer) r9 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_class_instance_10_0_i3);
	r4 = r5;
	r5 = r7;
	r6 = r8;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__check_typeclass__check_superclass_conformance_8_0),
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i3);
	MR_stackvar(5) = r5;
	MR_stackvar(4) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__check_typeclass__check_class_instance_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r4;
	r5 = r6;
	r4 = MR_tempr1;
	r6 = r7;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r9, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_7);
	r7 = r8;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__check_instance_pred_8_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_24);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__check_typeclass__check_class_instance_10_0_i4,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
	}
Define_label(mercury__check_typeclass__check_class_instance_10_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_class_instance_10_0_i6);
	r4 = MR_stackvar(4);
	r5 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_25);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__check_typeclass__check_class_instance_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(8) = MR_tempr1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	r1 = r5;
	MR_stackvar(4) = r3;
	MR_stackvar(10) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 5) = r5;
	GOTO_LABEL(mercury__check_typeclass__check_class_instance_10_0_i5);
	}
Define_label(mercury__check_typeclass__check_class_instance_10_0_i6);
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = r3;
	MR_stackvar(10) = r2;
Define_label(mercury__check_typeclass__check_class_instance_10_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(9) = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__check_typeclass__check_class_instance_10_0_i8,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i8);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__check_typeclass__check_class_instance_10_0_i7);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_28);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__check_typeclass__check_class_instance_10_0_i10,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i10);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__list__remove_dups_2_0),
		mercury__check_typeclass__check_class_instance_10_0_i11,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i11);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_instance_method_0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__check_typeclass__check_class_instance_10_0_i12,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i12);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__check_typeclass__check_class_instance_10_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__check_typeclass__check_superclass_conformance_8_0),
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i7);
	r2 = MR_stackvar(1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_class_instance_10_0_i14,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i14);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__check_class_instance_10_0_i15,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
Define_label(mercury__check_typeclass__check_class_instance_10_0_i15);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("In instance declaration for `", 29);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_30);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_class_instance_10_0_i16,
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
	}
Define_label(mercury__check_typeclass__check_class_instance_10_0_i16);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_class_instance_10_0));
	r7 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(4);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r9, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_class_instance_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__check_typeclass__check_class_instance_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r9, (Integer) 1) = r10;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__check_typeclass__check_superclass_conformance_8_0),
		STATIC(mercury__check_typeclass__check_class_instance_10_0));
	}
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_arg_types_4_0);
Declare_entry(mercury__hlds_pred__pred_info_get_class_context_2_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);

BEGIN_MODULE(check_typeclass_module15)
	init_entry(mercury__check_typeclass__check_instance_pred_8_0);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i2);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i3);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i4);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i5);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i6);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i8);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i9);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i10);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i11);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i12);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i13);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i14);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i15);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i16);
	init_label(mercury__check_typeclass__check_instance_pred_8_0_i17);
BEGIN_CODE

/* code for predicate 'check_instance_pred'/8 in mode 0 */
Define_static(mercury__check_typeclass__check_instance_pred_8_0);
	MR_incr_sp_push_msg(15, "check_typeclass:check_instance_pred/8");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__check_typeclass__check_instance_pred_8_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r6, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 4) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__250__4_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_32);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__check_typeclass__check_instance_pred_8_0_i2,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__check_typeclass__check_instance_pred_8_0_i3,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_4_0),
		mercury__check_typeclass__check_instance_pred_8_0_i4,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(9) = r2;
	MR_stackvar(10) = r3;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_class_context_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i5,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i5);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_8_0_i6);
	r2 = r1;
	r1 = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_pred_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(11) = r3;
	GOTO_LABEL(mercury__check_typeclass__check_instance_pred_8_0_i9);
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i6);
	r1 = (Word) MR_string_const("check_instance_pred: no constraint on class method", 50);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__check_typeclass__check_instance_pred_8_0_i8,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i8);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r1 = MR_stackvar(7);
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i9);
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i10,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i10);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i11,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i11);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r2 = MR_stackvar(12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_8_0, "origin_lost_in_value_number");
	MR_stackvar(12) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(7);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i12,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i12);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i13,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i13);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__check_typeclass__check_instance_pred_8_0_i14,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i14);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__check_typeclass__check_instance_pred_8_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_36);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred__280__5_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r4;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__check_typeclass__check_instance_pred_8_0_i15,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i15);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	MR_stackvar(3) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(13);
	call_localret(STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0),
		mercury__check_typeclass__check_instance_pred_8_0_i16,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
	}
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i16);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(12);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 11, mercury__check_typeclass__check_instance_pred_8_0, "check_typeclass:instance_method_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(13);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 5) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 6) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 7) = MR_stackvar(5);
	MR_field(MR_mktag(0), r5, (Integer) 8) = MR_stackvar(8);
	MR_field(MR_mktag(0), r5, (Integer) 9) = MR_stackvar(14);
	MR_field(MR_mktag(0), r5, (Integer) 10) = MR_stackvar(7);
	call_localret(STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0),
		mercury__check_typeclass__check_instance_pred_8_0_i17,
		STATIC(mercury__check_typeclass__check_instance_pred_8_0));
Define_label(mercury__check_typeclass__check_instance_pred_8_0_i17);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_8_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_pred_8_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__mercury_to_mercury__mercury_type_list_to_string_3_0);

BEGIN_MODULE(check_typeclass_module16)
	init_entry(mercury__check_typeclass__check_instance_pred_procs_7_0);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i2);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i6);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i7);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i1002);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i9);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i3);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i14);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i15);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i17);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i18);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i19);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i20);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i21);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i22);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i23);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i11);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i24);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i25);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i27);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i28);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i29);
	init_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i30);
BEGIN_CODE

/* code for predicate 'check_instance_pred_procs'/7 in mode 0 */
Define_static(mercury__check_typeclass__check_instance_pred_procs_7_0);
	MR_incr_sp_push_msg(25, "check_typeclass:check_instance_pred_procs/7");
	MR_stackvar(25) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 4);
	MR_stackvar(10) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r4, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r4, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r4, (Integer) 6);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r4, (Integer) 7);
	r2 = MR_const_field(MR_mktag(0), r5, (Integer) 10);
	r4 = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	MR_stackvar(24) = r2;
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r5, (Integer) 9);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r5, (Integer) 8);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r5, (Integer) 7);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r5, (Integer) 6);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r5, (Integer) 5);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r5, (Integer) 4);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r5, (Integer) 3);
	MR_stackvar(16) = r4;
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r5;
	call_localret(STATIC(mercury__check_typeclass__get_matching_instance_names_5_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i2,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r6;
	r5 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(12);
	r7 = MR_stackvar(5);
	call_localret(STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i6,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
	}
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i6);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__check_instance_pred_procs__339__6_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_37);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i7,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i7);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	if (((Integer) MR_stackvar(11) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i9);
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i1002);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 8, mercury__check_typeclass__check_instance_pred_procs_7_0, "hlds_data:hlds_instance_defn/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 5) = r3;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(25);
	MR_decr_sp_pop_msg(25);
	proceed();
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i9);
	r3 = r1;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(11), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i1002,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i3);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i11);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i11);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_stackvar(3);
	MR_stackvar(1) = MR_stackvar(4);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i14,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i14);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i15,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i15);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	if (((Integer) MR_stackvar(24) != (Integer) 0))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i17);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(16);
	MR_stackvar(5) = (Word) MR_string_const("predicate", 9);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i18,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i17);
	MR_stackvar(4) = r1;
	r1 = ((Integer) MR_stackvar(16) + (Integer) -1);
	MR_stackvar(5) = (Word) MR_string_const("function", 8);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i18,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i18);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_type_list_to_string_3_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i19,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i19);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("In instance declaration for `", 29);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(")': ", 4);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("multiple implementations of type class ", 39);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const(" method `", 9);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("/", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r11, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_38);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i20,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i20);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_40);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = r5;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_43);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i21,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
	}
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i21);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i22,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i22);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r3 = MR_stackvar(21);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i23,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i23);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 11, mercury__check_typeclass__check_instance_pred_procs_7_0, "check_typeclass:instance_method_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(16);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(17);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(18);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(19);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(20);
	MR_field(MR_mktag(0), r2, (Integer) 7) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_stackvar(22);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_stackvar(23);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_stackvar(24);
	MR_succip = (Code *) MR_stackvar(25);
	MR_decr_sp_pop_msg(25);
	proceed();
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i11);
	MR_stackvar(1) = MR_stackvar(4);
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i24,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i24);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i25,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i25);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	if (((Integer) MR_stackvar(24) != (Integer) 0))
		GOTO_LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0_i27);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(16);
	MR_stackvar(4) = (Word) MR_string_const("predicate", 9);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i28,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i27);
	MR_stackvar(3) = r1;
	r1 = ((Integer) MR_stackvar(16) + (Integer) -1);
	MR_stackvar(4) = (Word) MR_string_const("function", 8);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i28,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i28);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_type_list_to_string_3_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i29,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i29);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("In instance declaration for `", 29);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(")': ", 4);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("no implementation for type class ", 33);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const(" method `", 9);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("/", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r11, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_38);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_instance_pred_procs_7_0_i30,
		STATIC(mercury__check_typeclass__check_instance_pred_procs_7_0));
Define_label(mercury__check_typeclass__check_instance_pred_procs_7_0_i30);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_instance_pred_procs_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 11, mercury__check_typeclass__check_instance_pred_procs_7_0, "check_typeclass:instance_method_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(16);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(17);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(18);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(19);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(20);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_instance_pred_procs_7_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__check_typeclass__check_instance_pred_procs_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_stackvar(24);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_stackvar(23);
	MR_field(MR_mktag(0), r2, (Integer) 7) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_stackvar(22);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(25);
	MR_decr_sp_pop_msg(25);
	proceed();
	}
END_MODULE


BEGIN_MODULE(check_typeclass_module17)
	init_entry(mercury__check_typeclass__get_matching_instance_names_5_0);
	init_label(mercury__check_typeclass__get_matching_instance_names_5_0_i3);
BEGIN_CODE

/* code for predicate 'get_matching_instance_names'/5 in mode 0 */
Define_static(mercury__check_typeclass__get_matching_instance_names_5_0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__check_typeclass__get_matching_instance_names_5_0_i3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__check_typeclass__get_matching_instance_names_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41);
	MR_field(MR_mktag(0), r2, (Integer) 5) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__437__9_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_47);
	tailcall(ENTRY(mercury__std_util__solutions_2_1),
		STATIC(mercury__check_typeclass__get_matching_instance_names_5_0));
Define_label(mercury__check_typeclass__get_matching_instance_names_5_0_i3);
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_41);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__check_typeclass__get_matching_instance_names_5_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_48);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__get_matching_instance_names__452__8_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 5) = ((Integer) r4 - (Integer) 1);
	tailcall(ENTRY(mercury__std_util__solutions_2_1),
		STATIC(mercury__check_typeclass__get_matching_instance_names_5_0));
END_MODULE

Declare_entry(mercury__varset__merge_subst_4_0);
Declare_entry(mercury__term__apply_substitution_to_list_3_0);
Declare_entry(mercury__type_util__apply_subst_to_constraint_list_3_0);
Declare_entry(mercury__map__from_corresponding_lists_3_0);
Declare_entry(mercury__type_util__apply_subst_to_constraints_3_0);
Declare_entry(mercury__term__vars_list_2_0);
Declare_entry(mercury__list__sort_and_remove_dups_2_0);
Declare_entry(mercury__varset__squash_4_0);
Declare_entry(mercury__term__apply_variable_renaming_to_list_3_0);
Declare_entry(mercury__type_util__apply_variable_renaming_to_constraints_3_0);
Declare_entry(mercury__type_util__apply_partial_map_to_list_3_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__hlds_pred__init_markers_1_0);
Declare_entry(mercury__hlds_pred__add_marker_3_0);
Declare_entry(mercury__hlds_module__module_info_globals_2_0);
Declare_entry(mercury__globals__lookup_string_option_3_0);
Declare_entry(mercury__varset__init_1_0);
Declare_entry(mercury__hlds_pred__make_n_fresh_vars_5_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
Declare_entry(mercury__hlds_pred__status_is_imported_2_0);
Declare_entry(mercury__hlds_pred__pred_info_init_17_0);
Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
Declare_entry(mercury__hlds_goal__goal_info_set_context_3_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__hlds_goal__goal_info_set_nonlocals_3_0);
Declare_entry(mercury__hlds_pred__invalid_pred_id_1_0);
Declare_entry(mercury__hlds_pred__invalid_proc_id_1_0);
Declare_entry(mercury__hlds_pred__clauses_info_set_clauses_3_0);
Declare_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
Declare_entry(mercury__hlds_pred__pred_info_set_clauses_info_3_0);
Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_module__module_info_get_partial_qualifier_info_2_0);
Declare_entry(mercury__hlds_module__predicate_table_insert_6_0);
Declare_entry(mercury__hlds_module__module_info_set_predicate_table_3_0);

BEGIN_MODULE(check_typeclass_module18)
	init_entry(mercury__check_typeclass__produce_auxiliary_procs_10_0);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i2);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i3);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i4);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i5);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i6);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i7);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i8);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i9);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i10);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i11);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i12);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i13);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i14);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i15);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i16);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i17);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i18);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i19);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i20);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i21);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i22);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i23);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i24);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i1001);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i27);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i26);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i28);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i29);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i30);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i31);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i32);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i33);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i34);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i35);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i36);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i38);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i39);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i40);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i41);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i42);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i43);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i44);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i45);
	init_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i46);
BEGIN_CODE

/* code for predicate 'produce_auxiliary_procs'/10 in mode 0 */
Define_static(mercury__check_typeclass__produce_auxiliary_procs_10_0);
	MR_incr_sp_push_msg(25, "check_typeclass:produce_auxiliary_procs/10");
	MR_stackvar(25) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = MR_const_field(MR_mktag(0), r7, (Integer) 8);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r7, (Integer) 10);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r7, (Integer) 9);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r7, (Integer) 7);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r7, (Integer) 6);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r7, (Integer) 5);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r7, (Integer) 4);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r7, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r7, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r7, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r7, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__varset__merge_subst_4_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i2,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r2;
	MR_stackvar(16) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i3,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(16);
	call_localret(ENTRY(mercury__type_util__apply_subst_to_constraint_list_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i4,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i5,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i5);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i6,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i6);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__type_util__apply_subst_to_constraints_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i7,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i7);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i8,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i8);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__vars_list_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i9,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i9);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i10,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i10);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__squash_4_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i11,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i11);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r2;
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_variable_renaming_to_list_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i12,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i12);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__type_util__apply_variable_renaming_to_constraints_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i13,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i13);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = MR_stackvar(9);
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__type_util__apply_partial_map_to_list_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i14,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i14);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i15,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i15);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(16) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i16,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i16);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(17) = r1;
	call_localret(ENTRY(mercury__hlds_pred__init_markers_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i17,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i17);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = (Integer) 17;
	call_localret(ENTRY(mercury__hlds_pred__add_marker_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i18,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i18);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i19,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i19);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = (Integer) 232;
	call_localret(ENTRY(mercury__globals__lookup_string_option_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i20,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i20);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(19) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i21,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i21);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = (Word) MR_string_const("HeadVar__", 9);
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__make_n_fresh_vars_5_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i22,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i22);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(20) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_50);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i23,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i23);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i24,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i24);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(21) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_50);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i1001,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i1001);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__check_typeclass__produce_auxiliary_procs_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(21);
	MR_stackvar(21) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 6) = r1;
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(14);
	MR_field(MR_mktag(0), r2, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(20);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__status_is_imported_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i27,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i27);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0_i26);
	r8 = MR_stackvar(5);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r13 = MR_stackvar(15);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(10);
	r14 = MR_stackvar(9);
	r5 = MR_stackvar(11);
	r1 = MR_stackvar(16);
	r15 = MR_stackvar(17);
	r11 = MR_stackvar(18);
	r16 = MR_stackvar(19);
	r9 = MR_stackvar(21);
	r10 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r12 = (Integer) 3;
	GOTO_LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0_i28);
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i26);
	r8 = MR_stackvar(5);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r13 = MR_stackvar(15);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(10);
	r14 = MR_stackvar(9);
	r5 = MR_stackvar(11);
	r1 = MR_stackvar(16);
	r15 = MR_stackvar(17);
	r11 = MR_stackvar(18);
	r16 = MR_stackvar(19);
	r9 = MR_stackvar(21);
	r10 = MR_stackvar(14);
	r12 = (Integer) 3;
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i28);
	MR_stackvar(5) = r8;
	MR_stackvar(7) = r2;
	MR_stackvar(8) = r3;
	MR_stackvar(15) = r13;
	MR_stackvar(3) = r4;
	MR_stackvar(10) = r6;
	MR_stackvar(9) = r14;
	MR_stackvar(11) = r5;
	MR_stackvar(21) = r9;
	MR_stackvar(22) = r10;
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_init_17_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i29,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i29);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r3 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__check_typeclass__produce_auxiliary_procs_10_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_53);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__check_typeclass__IntroducedFrom__pred__produce_auxiliary_procs__551__10_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(8);
	r6 = r5;
	r5 = MR_stackvar(12);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i30,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i30);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i31,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i31);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i32,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i32);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(23) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_50);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i33,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i33);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = r1;
	r1 = MR_stackvar(23);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_nonlocals_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i34,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i34);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(23) = r1;
	call_localret(ENTRY(mercury__hlds_pred__invalid_pred_id_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i35,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i35);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(24) = r1;
	call_localret(ENTRY(mercury__hlds_pred__invalid_proc_id_1_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i36,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i36);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	if (((Integer) MR_stackvar(15) != (Integer) 0))
		GOTO_LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0_i38);
	r3 = r1;
	r1 = MR_stackvar(21);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 3, mercury__check_typeclass__produce_auxiliary_procs_10_0, "hlds_pred:clause/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 6, mercury__check_typeclass__produce_auxiliary_procs_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = (Integer) 2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = MR_stackvar(20);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(24);
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(23);
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_set_clauses_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i41,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	}
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i38);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_50);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i39,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i39);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "hlds_goal:unify_rhs/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i40,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	}
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i40);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r3 = r1;
	r1 = MR_stackvar(21);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 3, mercury__check_typeclass__produce_auxiliary_procs_10_0, "hlds_pred:clause/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__check_typeclass__produce_auxiliary_procs_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_set_clauses_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i41,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	}
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i41);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_clauses_info_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i42,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i42);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i43,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i43);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(23) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_partial_qualifier_info_2_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i44,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i44);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r4 = r1;
	r1 = MR_stackvar(23);
	r2 = MR_stackvar(1);
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_module__predicate_table_insert_6_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i45,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i45);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_predicate_table_3_0),
		mercury__check_typeclass__produce_auxiliary_procs_10_0_i46,
		STATIC(mercury__check_typeclass__produce_auxiliary_procs_10_0));
Define_label(mercury__check_typeclass__produce_auxiliary_procs_10_0_i46);
	update_prof_current_proc(LABEL(mercury__check_typeclass__produce_auxiliary_procs_10_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 11, mercury__check_typeclass__produce_auxiliary_procs_10_0, "check_typeclass:instance_method_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_stackvar(22);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_stackvar(15);
	MR_succip = (Code *) MR_stackvar(25);
	MR_decr_sp_pop_msg(25);
	proceed();
END_MODULE

Declare_entry(mercury__prog_out__sym_name_to_string_3_0);
Declare_entry(mercury__base_typeclass_info__make_instance_string_2_0);

BEGIN_MODULE(check_typeclass_module19)
	init_entry(mercury__check_typeclass__make_introduced_pred_name_5_0);
	init_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i2);
	init_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i3);
	init_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i4);
	init_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i5);
	init_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i6);
BEGIN_CODE

/* code for predicate 'make_introduced_pred_name'/5 in mode 0 */
Define_static(mercury__check_typeclass__make_introduced_pred_name_5_0);
	MR_incr_sp_push_msg(4, "check_typeclass:make_introduced_pred_name/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = (Word) MR_string_const("__", 2);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_3_0),
		mercury__check_typeclass__make_introduced_pred_name_5_0_i2,
		STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0));
Define_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__make_introduced_pred_name_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = (Word) MR_string_const("__", 2);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_3_0),
		mercury__check_typeclass__make_introduced_pred_name_5_0_i3,
		STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0));
Define_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__make_introduced_pred_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__check_typeclass__make_introduced_pred_name_5_0_i4,
		STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0));
Define_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__make_introduced_pred_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__base_typeclass_info__make_instance_string_2_0),
		mercury__check_typeclass__make_introduced_pred_name_5_0_i5,
		STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0));
Define_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i5);
	update_prof_current_proc(LABEL(mercury__check_typeclass__make_introduced_pred_name_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("Introduced_pred_for_", 20);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("__", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("____", 4);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__check_typeclass__make_introduced_pred_name_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__make_introduced_pred_name_5_0_i6,
		STATIC(mercury__check_typeclass__make_introduced_pred_name_5_0));
Define_label(mercury__check_typeclass__make_introduced_pred_name_5_0_i6);
	update_prof_current_proc(LABEL(mercury__check_typeclass__make_introduced_pred_name_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__check_typeclass__make_introduced_pred_name_5_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__map__apply_to_list_3_0);
Declare_entry(mercury__term__var_list_to_term_list_2_1);
Declare_entry(mercury__hlds_module__module_info_superclasses_2_0);
Declare_entry(mercury__typecheck__reduce_context_by_rule_application_10_0);
Declare_entry(mercury__mercury_to_mercury__mercury_constraint_to_string_3_0);

BEGIN_MODULE(check_typeclass_module20)
	init_entry(mercury__check_typeclass__check_superclass_conformance_8_0);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i2);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i3);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i4);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i6);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i5);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i8);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i9);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i10);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i11);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i12);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i13);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i14);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i16);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i17);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i19);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i20);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i21);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i22);
	init_label(mercury__check_typeclass__check_superclass_conformance_8_0_i23);
BEGIN_CODE

/* code for predicate 'check_superclass_conformance'/8 in mode 0 */
Define_static(mercury__check_typeclass__check_superclass_conformance_8_0);
	MR_incr_sp_push_msg(19, "check_typeclass:check_superclass_conformance/8");
	MR_stackvar(19) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r6, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r5, (Integer) 6);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r5, (Integer) 7);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r5, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r5, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r5, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = r4;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__varset__merge_subst_4_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i2,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i2);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	MR_stackvar(16) = r2;
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__type_util__apply_subst_to_constraint_list_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i3,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i3);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r4 = MR_stackvar(16);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i4,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__var_list_to_term_list_2_1),
		mercury__check_typeclass__check_superclass_conformance_8_0_i6,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i6);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__check_typeclass__check_superclass_conformance_8_0_i5);
	r3 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r4 = MR_stackvar(12);
	GOTO_LABEL(mercury__check_typeclass__check_superclass_conformance_8_0_i9);
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i5);
	r1 = (Word) MR_string_const("ClassVarTerms are not vars", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i8,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i8);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r4 = MR_stackvar(12);
	}
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i9);
	MR_stackvar(12) = r4;
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i10,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i10);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_module__module_info_instances_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i11,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i11);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_module__module_info_superclasses_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i12,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i12);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r2 = r1;
	r1 = MR_stackvar(17);
	r3 = MR_stackvar(11);
	r4 = MR_stackvar(16);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(15);
	r7 = MR_stackvar(3);
	call_localret(ENTRY(mercury__typecheck__reduce_context_by_rule_application_10_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i13,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i13);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_superclass_conformance_8_0_i14);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__check_typeclass__check_superclass_conformance_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 6) = r1;
	r1 = r3;
	MR_field(MR_mktag(0), r3, (Integer) 7) = r2;
	r2 = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i14);
	MR_stackvar(16) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_stackvar(17) = r3;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i16,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i16);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r3 = r1;
	r1 = MR_stackvar(16);
	MR_stackvar(16) = r3;
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_type_list_to_string_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i17,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i17);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	if (((Integer) MR_stackvar(17) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__check_superclass_conformance_8_0_i19);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("In instance declaration for `", 29);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_57);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i23,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
	}
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i19);
	r3 = MR_stackvar(17);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(18) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_constraint_to_string_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i20,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i20);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r2 = MR_stackvar(18);
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__check_typeclass__constraint_list_to_string_2_3_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i21,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i21);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("`", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("'", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i22,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
	}
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i22);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("In instance declaration for `", 29);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(17);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(")': ", 4);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("superclass constraint(s) not satisfied: ", 40);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_check_typeclass__common_54);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__check_typeclass__check_superclass_conformance_8_0_i23,
		STATIC(mercury__check_typeclass__check_superclass_conformance_8_0));
	}
Define_label(mercury__check_typeclass__check_superclass_conformance_8_0_i23);
	update_prof_current_proc(LABEL(mercury__check_typeclass__check_superclass_conformance_8_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__check_typeclass__check_superclass_conformance_8_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__check_typeclass__check_superclass_conformance_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
END_MODULE


BEGIN_MODULE(check_typeclass_module21)
	init_entry(mercury__check_typeclass__constraint_list_to_string_2_3_0);
	init_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i4);
	init_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i5);
	init_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'constraint_list_to_string_2'/3 in mode 0 */
Define_static(mercury__check_typeclass__constraint_list_to_string_2_3_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__check_typeclass__constraint_list_to_string_2_3_0_i3);
	MR_incr_sp_push_msg(3, "check_typeclass:constraint_list_to_string_2/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_constraint_to_string_3_0),
		mercury__check_typeclass__constraint_list_to_string_2_3_0_i4,
		STATIC(mercury__check_typeclass__constraint_list_to_string_2_3_0));
Define_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__check_typeclass__constraint_list_to_string_2_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	localcall(mercury__check_typeclass__constraint_list_to_string_2_3_0,
		LABEL(mercury__check_typeclass__constraint_list_to_string_2_3_0_i5),
		STATIC(mercury__check_typeclass__constraint_list_to_string_2_3_0));
Define_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__check_typeclass__constraint_list_to_string_2_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__constraint_list_to_string_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(", `", 3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__check_typeclass__constraint_list_to_string_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__check_typeclass__constraint_list_to_string_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("'", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__check_typeclass__constraint_list_to_string_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__check_typeclass__constraint_list_to_string_2_3_0));
	}
Define_label(mercury__check_typeclass__constraint_list_to_string_2_3_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(check_typeclass_module22)
	init_entry(mercury____Unify___check_typeclass__error_message_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___check_typeclass__error_message_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_4);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___check_typeclass__error_message_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(check_typeclass_module23)
	init_entry(mercury____Index___check_typeclass__error_message_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__error_message_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_4);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		STATIC(mercury____Index___check_typeclass__error_message_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(check_typeclass_module24)
	init_entry(mercury____Compare___check_typeclass__error_message_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___check_typeclass__error_message_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_4);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___check_typeclass__error_message_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(check_typeclass_module25)
	init_entry(mercury____Unify___check_typeclass__error_messages_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___check_typeclass__error_messages_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___check_typeclass__error_messages_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(check_typeclass_module26)
	init_entry(mercury____Index___check_typeclass__error_messages_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__error_messages_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___check_typeclass__error_messages_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(check_typeclass_module27)
	init_entry(mercury____Compare___check_typeclass__error_messages_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___check_typeclass__error_messages_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___check_typeclass__error_messages_0_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___prog_data__class_constraints_0_0);
Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___hlds_pred__import_status_0_0);

BEGIN_MODULE(check_typeclass_module28)
	init_entry(mercury____Unify___check_typeclass__instance_method_info_0_0);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i2);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i4);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i6);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i8);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i10);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i12);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i14);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i16);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i18);
	init_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___check_typeclass__instance_method_info_0_0);
	MR_incr_sp_push_msg(21, "check_typeclass:__Unify__/2");
	MR_stackvar(21) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i2,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i4,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(12)))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i6,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i8,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Unify___prog_data__class_constraints_0_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i10,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i12,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(17);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i14,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i16,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury____Unify___hlds_pred__import_status_0_0),
		mercury____Unify___check_typeclass__instance_method_info_0_0_i18,
		STATIC(mercury____Unify___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	if ((MR_stackvar(10) != MR_stackvar(20)))
		GOTO_LABEL(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___check_typeclass__instance_method_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(check_typeclass_module29)
	init_entry(mercury____Index___check_typeclass__instance_method_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__instance_method_info_0_0);
	tailcall(STATIC(mercury____Index___check_typeclass__instance_method_info_0__ua0_2_0),
		STATIC(mercury____Index___check_typeclass__instance_method_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___prog_data__class_constraints_0_0);
Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___hlds_pred__import_status_0_0);

BEGIN_MODULE(check_typeclass_module30)
	init_entry(mercury____Compare___check_typeclass__instance_method_info_0_0);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i3);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i7);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i11);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i15);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i19);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i23);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i27);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i31);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i35);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i39);
	init_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___check_typeclass__instance_method_info_0_0);
	MR_incr_sp_push_msg(21, "check_typeclass:__Compare__/3");
	MR_stackvar(21) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i3,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i7,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i11,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_18);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i15,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_49);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i19,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Compare___prog_data__class_constraints_0_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i23,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_34);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i27,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_check_typeclass__common_5);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(17);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i31,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i35,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury____Compare___hlds_pred__import_status_0_0),
		mercury____Compare___check_typeclass__instance_method_info_0_0_i39,
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(20);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___check_typeclass__instance_method_info_0_0));
Define_label(mercury____Compare___check_typeclass__instance_method_info_0_0_i52);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
END_MODULE

Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(check_typeclass_module31)
	init_entry(mercury____Unify___check_typeclass__triple_3_0);
	init_label(mercury____Unify___check_typeclass__triple_3_0_i2);
	init_label(mercury____Unify___check_typeclass__triple_3_0_i4);
	init_label(mercury____Unify___check_typeclass__triple_3_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___check_typeclass__triple_3_0);
	MR_incr_sp_push_msg(7, "check_typeclass:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(5) = r2;
	MR_stackvar(6) = r3;
	r3 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___check_typeclass__triple_3_0_i2,
		STATIC(mercury____Unify___check_typeclass__triple_3_0));
Define_label(mercury____Unify___check_typeclass__triple_3_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__triple_3_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__triple_3_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___check_typeclass__triple_3_0_i4,
		STATIC(mercury____Unify___check_typeclass__triple_3_0));
Define_label(mercury____Unify___check_typeclass__triple_3_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___check_typeclass__triple_3_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___check_typeclass__triple_3_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__unify_2_0),
		STATIC(mercury____Unify___check_typeclass__triple_3_0));
Define_label(mercury____Unify___check_typeclass__triple_3_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(check_typeclass_module32)
	init_entry(mercury____Index___check_typeclass__triple_3_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___check_typeclass__triple_3_0);
	tailcall(STATIC(mercury____Index___check_typeclass__triple_3__ua0_2_0),
		STATIC(mercury____Index___check_typeclass__triple_3_0));
END_MODULE

Declare_entry(mercury__compare_3_3);

BEGIN_MODULE(check_typeclass_module33)
	init_entry(mercury____Compare___check_typeclass__triple_3_0);
	init_label(mercury____Compare___check_typeclass__triple_3_0_i3);
	init_label(mercury____Compare___check_typeclass__triple_3_0_i7);
	init_label(mercury____Compare___check_typeclass__triple_3_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___check_typeclass__triple_3_0);
	MR_incr_sp_push_msg(7, "check_typeclass:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(5) = r2;
	MR_stackvar(6) = r3;
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___check_typeclass__triple_3_0_i3,
		STATIC(mercury____Compare___check_typeclass__triple_3_0));
Define_label(mercury____Compare___check_typeclass__triple_3_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__triple_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__triple_3_0_i12);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___check_typeclass__triple_3_0_i7,
		STATIC(mercury____Compare___check_typeclass__triple_3_0));
Define_label(mercury____Compare___check_typeclass__triple_3_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___check_typeclass__triple_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___check_typeclass__triple_3_0_i12);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__compare_3_3),
		STATIC(mercury____Compare___check_typeclass__triple_3_0));
Define_label(mercury____Compare___check_typeclass__triple_3_0_i12);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__check_typeclass_maybe_bunch_0(void)
{
	check_typeclass_module0();
	check_typeclass_module1();
	check_typeclass_module2();
	check_typeclass_module3();
	check_typeclass_module4();
	check_typeclass_module5();
	check_typeclass_module6();
	check_typeclass_module7();
	check_typeclass_module8();
	check_typeclass_module9();
	check_typeclass_module10();
	check_typeclass_module11();
	check_typeclass_module12();
	check_typeclass_module13();
	check_typeclass_module14();
	check_typeclass_module15();
	check_typeclass_module16();
	check_typeclass_module17();
	check_typeclass_module18();
	check_typeclass_module19();
	check_typeclass_module20();
	check_typeclass_module21();
	check_typeclass_module22();
	check_typeclass_module23();
	check_typeclass_module24();
	check_typeclass_module25();
	check_typeclass_module26();
	check_typeclass_module27();
	check_typeclass_module28();
	check_typeclass_module29();
	check_typeclass_module30();
	check_typeclass_module31();
	check_typeclass_module32();
	check_typeclass_module33();
}

#endif

void mercury__check_typeclass__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__check_typeclass__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__check_typeclass_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_check_typeclass__type_ctor_info_error_message_0,
			check_typeclass__error_message_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_check_typeclass__type_ctor_info_error_messages_0,
			check_typeclass__error_messages_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_check_typeclass__type_ctor_info_instance_method_info_0,
			check_typeclass__instance_method_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_check_typeclass__type_ctor_info_triple_3,
			check_typeclass__triple_3_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
