/*
** Automatically generated from `code_aux.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__code_aux__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__code_aux__contains_only_builtins_1_0);
Define_extern_entry(mercury__code_aux__goal_cannot_loop_2_0);
Define_extern_entry(mercury__code_aux__goal_is_flat_1_0);
Define_extern_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
Declare_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1);
Define_extern_entry(mercury__code_aux__explain_stack_slots_3_0);
Declare_label(mercury__code_aux__explain_stack_slots_3_0_i2);
Declare_label(mercury__code_aux__explain_stack_slots_3_0_i3);
Declare_static(mercury__code_aux__contains_only_builtins_2_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1016);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i4);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i5);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i14);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i16);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i19);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i22);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
Declare_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
Declare_static(mercury__code_aux__contains_only_builtins_cases_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1002);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i2);
Declare_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
Declare_static(mercury__code_aux__contains_only_builtins_list_1_0);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i1002);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i2);
Declare_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
Declare_static(mercury__code_aux__goal_cannot_loop_2_2_0);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1028);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i58);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i59);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1018);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i47);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i52);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i54);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i4);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i5);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i10);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i13);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i16);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i22);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i24);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i29);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i31);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i34);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i37);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i40);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i41);
Declare_label(mercury__code_aux__goal_cannot_loop_2_2_0_i43);
Declare_static(mercury__code_aux__goal_is_flat_2_1_0);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i4);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i9);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i11);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i14);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1002);
Declare_label(mercury__code_aux__goal_is_flat_2_1_0_i1);
Declare_static(mercury__code_aux__goal_is_flat_list_1_0);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i1002);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i2);
Declare_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
Declare_static(mercury__code_aux__contains_simple_recursive_call_2_3_0);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1008);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i3);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i11);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i17);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
Declare_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
Declare_static(mercury__code_aux__explain_stack_slots_2_4_0);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i5);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
Declare_label(mercury__code_aux__explain_stack_slots_2_4_0_i3);

static const struct mercury_data_code_aux__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_aux__common_0;

static const struct mercury_data_code_aux__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_code_aux__common_1;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_code_aux__common_0_struct mercury_data_code_aux__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_code_aux__common_1_struct mercury_data_code_aux__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};


BEGIN_MODULE(code_aux_module0)
	init_entry(mercury__code_aux__contains_only_builtins_1_0);
BEGIN_CODE

/* code for predicate 'contains_only_builtins'/1 in mode 0 */
Define_entry(mercury__code_aux__contains_only_builtins_1_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		ENTRY(mercury__code_aux__contains_only_builtins_1_0));
END_MODULE


BEGIN_MODULE(code_aux_module1)
	init_entry(mercury__code_aux__goal_cannot_loop_2_0);
BEGIN_CODE

/* code for predicate 'goal_cannot_loop'/2 in mode 0 */
Define_entry(mercury__code_aux__goal_cannot_loop_2_0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(STATIC(mercury__code_aux__goal_cannot_loop_2_2_0),
		ENTRY(mercury__code_aux__goal_cannot_loop_2_0));
END_MODULE


BEGIN_MODULE(code_aux_module2)
	init_entry(mercury__code_aux__goal_is_flat_1_0);
BEGIN_CODE

/* code for predicate 'goal_is_flat'/1 in mode 0 */
Define_entry(mercury__code_aux__goal_is_flat_1_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_aux__goal_is_flat_2_1_0),
		ENTRY(mercury__code_aux__goal_is_flat_1_0));
END_MODULE


BEGIN_MODULE(code_aux_module3)
	init_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	init_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1);
BEGIN_CODE

/* code for predicate 'contains_simple_recursive_call'/3 in mode 0 */
Define_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_3_0_i1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tailcall(STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0),
		ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(code_aux_module4)
	init_entry(mercury__code_aux__explain_stack_slots_3_0);
	init_label(mercury__code_aux__explain_stack_slots_3_0_i2);
	init_label(mercury__code_aux__explain_stack_slots_3_0_i3);
BEGIN_CODE

/* code for predicate 'explain_stack_slots'/3 in mode 0 */
Define_entry(mercury__code_aux__explain_stack_slots_3_0);
	MR_incr_sp_push_msg(2, "code_aux:explain_stack_slots/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_aux__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__code_aux__explain_stack_slots_3_0_i2,
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
Define_label(mercury__code_aux__explain_stack_slots_3_0_i2);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_3_0));
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const("", 0);
	call_localret(STATIC(mercury__code_aux__explain_stack_slots_2_4_0),
		mercury__code_aux__explain_stack_slots_3_0_i3,
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
Define_label(mercury__code_aux__explain_stack_slots_3_0_i3);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nStack slot assignments (if any):\n", 34);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__code_aux__explain_stack_slots_3_0));
END_MODULE


BEGIN_MODULE(code_aux_module5)
	init_entry(mercury__code_aux__contains_only_builtins_2_1_0);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1016);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i4);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i5);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i14);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i16);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i19);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i22);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
	init_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
BEGIN_CODE

/* code for predicate 'contains_only_builtins_2'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_2_1_0);
	MR_incr_sp_push_msg(3, "code_aux:contains_only_builtins_2/1");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i4);
	if ((r2 == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	if ((r2 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1016);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i32);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i4);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i5) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i8) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i16) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i19) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i22) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i25) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_cases_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i8);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1016) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1016) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1016) AND
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i14));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1016);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i19);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i22);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i25);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__code_aux__contains_only_builtins_2_1_0,
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i26),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i26);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_2_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	localcall(mercury__code_aux__contains_only_builtins_2_1_0,
		LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i28),
		STATIC(mercury__code_aux__contains_only_builtins_2_1_0));
Define_label(mercury__code_aux__contains_only_builtins_2_1_0_i28);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_2_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1006);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_2_1_0_i1022);
END_MODULE


BEGIN_MODULE(code_aux_module6)
	init_entry(mercury__code_aux__contains_only_builtins_cases_1_0);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1002);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i2);
	init_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
BEGIN_CODE

/* code for predicate 'contains_only_builtins_cases'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_cases_1_0);
	MR_incr_sp_push_msg(2, "code_aux:contains_only_builtins_cases/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_cases_1_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 0);
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		mercury__code_aux__contains_only_builtins_cases_1_0_i4,
		STATIC(mercury__code_aux__contains_only_builtins_cases_1_0));
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_cases_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_cases_1_0_i1002);
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_cases_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_aux_module7)
	init_entry(mercury__code_aux__contains_only_builtins_list_1_0);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i1002);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i2);
	init_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
BEGIN_CODE

/* code for predicate 'contains_only_builtins_list'/1 in mode 0 */
Define_static(mercury__code_aux__contains_only_builtins_list_1_0);
	MR_incr_sp_push_msg(2, "code_aux:contains_only_builtins_list/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_list_1_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		mercury__code_aux__contains_only_builtins_list_1_0_i4,
		STATIC(mercury__code_aux__contains_only_builtins_list_1_0));
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_only_builtins_list_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_only_builtins_list_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_aux__contains_only_builtins_list_1_0_i1002);
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_aux__contains_only_builtins_list_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0);
Declare_entry(mercury__list__member_2_1);
Declare_entry(do_redo);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_case_0;

BEGIN_MODULE(code_aux_module8)
	init_entry(mercury__code_aux__goal_cannot_loop_2_2_0);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1028);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i58);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i59);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1018);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i47);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i52);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i54);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i4);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i5);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i10);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i13);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i16);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i22);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i24);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i29);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i31);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i34);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i37);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i40);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i41);
	init_label(mercury__code_aux__goal_cannot_loop_2_2_0_i43);
BEGIN_CODE

/* code for predicate 'goal_cannot_loop_2'/2 in mode 0 */
Define_static(mercury__code_aux__goal_cannot_loop_2_2_0);
	MR_incr_sp_push_msg(7, "code_aux:goal_cannot_loop_2/2");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1028);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i4);
	if ((r3 == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i47);
	if ((r3 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__code_aux__goal_cannot_loop_2_2_0_i58,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i58);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0),
		mercury__code_aux__goal_cannot_loop_2_2_0_i59,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i59);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1018);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i47);
	MR_stackvar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_aux__common_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__code_aux__goal_cannot_loop_2_2_0_i52,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i52);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_stackvar(1);
	localcall(mercury__code_aux__goal_cannot_loop_2_2_0,
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i54),
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i54);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
	GOTO(ENTRY(do_redo));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i5) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i16) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i24) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i34) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i37) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i40) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i5);
	MR_stackvar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__code_aux__goal_cannot_loop_2_2_0_i10,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i10);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__code_aux__goal_cannot_loop_2_0),
		mercury__code_aux__goal_cannot_loop_2_2_0_i13,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i13);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
	GOTO(ENTRY(do_redo));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i16);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1018) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1018) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1018) AND
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i22));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i22);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1018);
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i24);
	MR_stackvar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_aux__common_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__code_aux__goal_cannot_loop_2_2_0_i29,
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i29);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_stackvar(1);
	localcall(mercury__code_aux__goal_cannot_loop_2_2_0,
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i31),
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i31);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
	GOTO(ENTRY(do_redo));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1060);
	MR_maxfr = (Word *) MR_stackvar(6);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(5);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i1064);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i34);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1028);
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i37);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__code_aux__goal_cannot_loop_2_0),
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i40);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r1;
	localcall(mercury__code_aux__goal_cannot_loop_2_2_0,
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i41),
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i41);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	r1 = MR_stackvar(1);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	localcall(mercury__code_aux__goal_cannot_loop_2_2_0,
		LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i43),
		STATIC(mercury__code_aux__goal_cannot_loop_2_2_0));
Define_label(mercury__code_aux__goal_cannot_loop_2_2_0_i43);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_cannot_loop_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1007);
	r1 = MR_stackvar(1);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__code_aux__goal_cannot_loop_2_2_0_i1028);
END_MODULE


BEGIN_MODULE(code_aux_module9)
	init_entry(mercury__code_aux__goal_is_flat_2_1_0);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i4);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i9);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i11);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i14);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1002);
	init_label(mercury__code_aux__goal_is_flat_2_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_is_flat_2'/1 in mode 0 */
Define_static(mercury__code_aux__goal_is_flat_2_1_0);
	MR_incr_sp_push_msg(1, "code_aux:goal_is_flat_2/1");
	MR_stackvar(1) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i4) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i9));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__code_aux__goal_is_flat_list_1_0),
		STATIC(mercury__code_aux__goal_is_flat_2_1_0));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i11) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i14) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i11);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i4) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i9));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i14);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i4) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i1002) AND
		LABEL(mercury__code_aux__goal_is_flat_2_1_0_i9));
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1002);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__code_aux__goal_is_flat_2_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(code_aux_module10)
	init_entry(mercury__code_aux__goal_is_flat_list_1_0);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i1002);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i2);
	init_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_is_flat_list'/1 in mode 0 */
Define_static(mercury__code_aux__goal_is_flat_list_1_0);
	MR_incr_sp_push_msg(2, "code_aux:goal_is_flat_list/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_list_1_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__code_aux__goal_is_flat_2_1_0),
		mercury__code_aux__goal_is_flat_list_1_0_i4,
		STATIC(mercury__code_aux__goal_is_flat_list_1_0));
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__goal_is_flat_list_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__goal_is_flat_list_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_aux__goal_is_flat_list_1_0_i1002);
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_aux__goal_is_flat_list_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_pred_id_3_0);
Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);
Declare_entry(mercury__code_info__get_proc_id_3_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);

BEGIN_MODULE(code_aux_module11)
	init_entry(mercury__code_aux__contains_simple_recursive_call_2_3_0);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1008);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i3);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i11);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i17);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
	init_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'contains_simple_recursive_call_2'/3 in mode 0 */
Define_static(mercury__code_aux__contains_simple_recursive_call_2_3_0);
	MR_incr_sp_push_msg(5, "code_aux:contains_simple_recursive_call_2/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1008);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_2_1_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i5,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i3);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1008);
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i3);
	r2 = MR_stackvar(3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 3);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i11,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i12,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i12);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i14,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i14);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i15,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i15);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i17);
	r2 = (Integer) 1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i17);
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__code_aux__contains_only_builtins_list_1_0),
		mercury__code_aux__contains_simple_recursive_call_2_3_0_i19,
		STATIC(mercury__code_aux__contains_simple_recursive_call_2_3_0));
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i19);
	update_prof_current_proc(LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r2 = (Integer) 0;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_aux__contains_simple_recursive_call_2_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__llds_out__lval_to_string_2_0);
Declare_entry(mercury__varset__lookup_name_3_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(code_aux_module12)
	init_entry(mercury__code_aux__explain_stack_slots_2_4_0);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i5);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
	init_label(mercury__code_aux__explain_stack_slots_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'explain_stack_slots_2'/4 in mode 0 */
Define_static(mercury__code_aux__explain_stack_slots_2_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i3);
	MR_incr_sp_push_msg(5, "code_aux:explain_stack_slots_2/4");
	MR_stackvar(5) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	localcall(mercury__code_aux__explain_stack_slots_2_4_0,
		LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i4),
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
	}
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__llds_out__lval_to_string_2_0),
		mercury__code_aux__explain_stack_slots_2_4_0_i7,
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_aux__explain_stack_slots_2_4_0_i5);
	MR_stackvar(4) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__code_aux__explain_stack_slots_2_4_0_i10,
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i5);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_stackvar(4) = (Word) MR_string_const("some lval", 9);
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__code_aux__explain_stack_slots_2_4_0_i10,
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__code_aux__explain_stack_slots_2_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_aux__explain_stack_slots_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_aux__explain_stack_slots_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\t ->\t", 5);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__code_aux__explain_stack_slots_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__code_aux__explain_stack_slots_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_aux__explain_stack_slots_2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__code_aux__explain_stack_slots_2_4_0));
Define_label(mercury__code_aux__explain_stack_slots_2_4_0_i3);
	r1 = r3;
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__code_aux_maybe_bunch_0(void)
{
	code_aux_module0();
	code_aux_module1();
	code_aux_module2();
	code_aux_module3();
	code_aux_module4();
	code_aux_module5();
	code_aux_module6();
	code_aux_module7();
	code_aux_module8();
	code_aux_module9();
	code_aux_module10();
	code_aux_module11();
	code_aux_module12();
}

#endif

void mercury__code_aux__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__code_aux__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__code_aux_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
