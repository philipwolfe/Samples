/*
** Automatically generated from `code_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__code_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___code_gen__frame_info_0__ua0_2_0);
Declare_static(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0);
Declare_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i1);
Declare_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i2);
Define_extern_entry(mercury__code_gen__generate_code_7_0);
Declare_label(mercury__code_gen__generate_code_7_0_i2);
Define_extern_entry(mercury__code_gen__generate_proc_code_11_0);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i2);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i3);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i4);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i5);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i8);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i7);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i6);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i9);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i10);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i12);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i13);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i14);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i15);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i16);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i17);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i18);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i21);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i19);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i22);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i25);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i26);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i27);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i23);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i29);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i30);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i31);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i36);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i37);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i38);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i33);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i39);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i40);
Declare_label(mercury__code_gen__generate_proc_code_11_0_i41);
Define_extern_entry(mercury__code_gen__generate_goal_5_0);
Declare_label(mercury__code_gen__generate_goal_5_0_i4);
Declare_label(mercury__code_gen__generate_goal_5_0_i2);
Declare_label(mercury__code_gen__generate_goal_5_0_i6);
Declare_label(mercury__code_gen__generate_goal_5_0_i7);
Declare_label(mercury__code_gen__generate_goal_5_0_i8);
Declare_label(mercury__code_gen__generate_goal_5_0_i11);
Declare_label(mercury__code_gen__generate_goal_5_0_i13);
Declare_label(mercury__code_gen__generate_goal_5_0_i15);
Declare_label(mercury__code_gen__generate_goal_5_0_i18);
Declare_label(mercury__code_gen__generate_goal_5_0_i16);
Declare_label(mercury__code_gen__generate_goal_5_0_i23);
Declare_label(mercury__code_gen__generate_goal_5_0_i25);
Declare_label(mercury__code_gen__generate_goal_5_0_i14);
Declare_label(mercury__code_gen__generate_goal_5_0_i27);
Declare_label(mercury__code_gen__generate_goal_5_0_i28);
Declare_label(mercury__code_gen__generate_goal_5_0_i29);
Declare_label(mercury__code_gen__generate_goal_5_0_i9);
Declare_label(mercury__code_gen__generate_goal_5_0_i31);
Declare_static(mercury__code_gen__generate_pred_list_code_8_0);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i4);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i5);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i6);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i10);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i12);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i9);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i7);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i14);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i17);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i18);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i19);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i20);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i21);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i15);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i22);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i23);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i24);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i25);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i26);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i28);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i29);
Declare_label(mercury__code_gen__generate_pred_list_code_8_0_i3);
Declare_static(mercury__code_gen__generate_proc_list_code_11_0);
Declare_label(mercury__code_gen__generate_proc_list_code_11_0_i1001);
Declare_label(mercury__code_gen__generate_proc_list_code_11_0_i4);
Declare_label(mercury__code_gen__generate_proc_list_code_11_0_i5);
Declare_label(mercury__code_gen__generate_proc_list_code_11_0_i6);
Declare_label(mercury__code_gen__generate_proc_list_code_11_0_i3);
Declare_static(mercury__code_gen__generate_category_code_9_0);
Declare_label(mercury__code_gen__generate_category_code_9_0_i5);
Declare_label(mercury__code_gen__generate_category_code_9_0_i6);
Declare_label(mercury__code_gen__generate_category_code_9_0_i8);
Declare_label(mercury__code_gen__generate_category_code_9_0_i4);
Declare_label(mercury__code_gen__generate_category_code_9_0_i10);
Declare_label(mercury__code_gen__generate_category_code_9_0_i11);
Declare_label(mercury__code_gen__generate_category_code_9_0_i14);
Declare_label(mercury__code_gen__generate_category_code_9_0_i12);
Declare_label(mercury__code_gen__generate_category_code_9_0_i15);
Declare_label(mercury__code_gen__generate_category_code_9_0_i16);
Declare_label(mercury__code_gen__generate_category_code_9_0_i17);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1041);
Declare_label(mercury__code_gen__generate_category_code_9_0_i3);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1045);
Declare_label(mercury__code_gen__generate_category_code_9_0_i22);
Declare_label(mercury__code_gen__generate_category_code_9_0_i23);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1051);
Declare_label(mercury__code_gen__generate_category_code_9_0_i27);
Declare_label(mercury__code_gen__generate_category_code_9_0_i28);
Declare_label(mercury__code_gen__generate_category_code_9_0_i29);
Declare_label(mercury__code_gen__generate_category_code_9_0_i30);
Declare_label(mercury__code_gen__generate_category_code_9_0_i31);
Declare_label(mercury__code_gen__generate_category_code_9_0_i32);
Declare_label(mercury__code_gen__generate_category_code_9_0_i33);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1052);
Declare_label(mercury__code_gen__generate_category_code_9_0_i24);
Declare_label(mercury__code_gen__generate_category_code_9_0_i35);
Declare_label(mercury__code_gen__generate_category_code_9_0_i36);
Declare_label(mercury__code_gen__generate_category_code_9_0_i37);
Declare_label(mercury__code_gen__generate_category_code_9_0_i38);
Declare_label(mercury__code_gen__generate_category_code_9_0_i20);
Declare_label(mercury__code_gen__generate_category_code_9_0_i40);
Declare_label(mercury__code_gen__generate_category_code_9_0_i41);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1065);
Declare_label(mercury__code_gen__generate_category_code_9_0_i45);
Declare_label(mercury__code_gen__generate_category_code_9_0_i46);
Declare_label(mercury__code_gen__generate_category_code_9_0_i47);
Declare_label(mercury__code_gen__generate_category_code_9_0_i48);
Declare_label(mercury__code_gen__generate_category_code_9_0_i49);
Declare_label(mercury__code_gen__generate_category_code_9_0_i50);
Declare_label(mercury__code_gen__generate_category_code_9_0_i51);
Declare_label(mercury__code_gen__generate_category_code_9_0_i52);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1073);
Declare_label(mercury__code_gen__generate_category_code_9_0_i42);
Declare_label(mercury__code_gen__generate_category_code_9_0_i56);
Declare_label(mercury__code_gen__generate_category_code_9_0_i57);
Declare_label(mercury__code_gen__generate_category_code_9_0_i1079);
Declare_static(mercury__code_gen__generate_entry_7_0);
Declare_label(mercury__code_gen__generate_entry_7_0_i2);
Declare_label(mercury__code_gen__generate_entry_7_0_i3);
Declare_label(mercury__code_gen__generate_entry_7_0_i4);
Declare_label(mercury__code_gen__generate_entry_7_0_i5);
Declare_label(mercury__code_gen__generate_entry_7_0_i6);
Declare_label(mercury__code_gen__generate_entry_7_0_i7);
Declare_label(mercury__code_gen__generate_entry_7_0_i8);
Declare_label(mercury__code_gen__generate_entry_7_0_i1073);
Declare_label(mercury__code_gen__generate_entry_7_0_i10);
Declare_label(mercury__code_gen__generate_entry_7_0_i12);
Declare_label(mercury__code_gen__generate_entry_7_0_i17);
Declare_label(mercury__code_gen__generate_entry_7_0_i20);
Declare_label(mercury__code_gen__generate_entry_7_0_i18);
Declare_label(mercury__code_gen__generate_entry_7_0_i21);
Declare_label(mercury__code_gen__generate_entry_7_0_i22);
Declare_label(mercury__code_gen__generate_entry_7_0_i23);
Declare_label(mercury__code_gen__generate_entry_7_0_i24);
Declare_label(mercury__code_gen__generate_entry_7_0_i25);
Declare_label(mercury__code_gen__generate_entry_7_0_i26);
Declare_label(mercury__code_gen__generate_entry_7_0_i27);
Declare_label(mercury__code_gen__generate_entry_7_0_i30);
Declare_label(mercury__code_gen__generate_entry_7_0_i34);
Declare_label(mercury__code_gen__generate_entry_7_0_i35);
Declare_label(mercury__code_gen__generate_entry_7_0_i31);
Declare_label(mercury__code_gen__generate_entry_7_0_i28);
Declare_label(mercury__code_gen__generate_entry_7_0_i1137);
Declare_static(mercury__code_gen__generate_exit_8_0);
Declare_label(mercury__code_gen__generate_exit_8_0_i2);
Declare_label(mercury__code_gen__generate_exit_8_0_i4);
Declare_label(mercury__code_gen__generate_exit_8_0_i5);
Declare_label(mercury__code_gen__generate_exit_8_0_i6);
Declare_label(mercury__code_gen__generate_exit_8_0_i7);
Declare_label(mercury__code_gen__generate_exit_8_0_i10);
Declare_label(mercury__code_gen__generate_exit_8_0_i8);
Declare_label(mercury__code_gen__generate_exit_8_0_i12);
Declare_label(mercury__code_gen__generate_exit_8_0_i13);
Declare_label(mercury__code_gen__generate_exit_8_0_i14);
Declare_label(mercury__code_gen__generate_exit_8_0_i16);
Declare_label(mercury__code_gen__generate_exit_8_0_i19);
Declare_label(mercury__code_gen__generate_exit_8_0_i1027);
Declare_label(mercury__code_gen__generate_exit_8_0_i23);
Declare_label(mercury__code_gen__generate_exit_8_0_i1035);
Declare_label(mercury__code_gen__generate_exit_8_0_i30);
Declare_label(mercury__code_gen__generate_exit_8_0_i33);
Declare_label(mercury__code_gen__generate_exit_8_0_i34);
Declare_label(mercury__code_gen__generate_exit_8_0_i35);
Declare_label(mercury__code_gen__generate_exit_8_0_i31);
Declare_label(mercury__code_gen__generate_exit_8_0_i37);
Declare_label(mercury__code_gen__generate_exit_8_0_i38);
Declare_label(mercury__code_gen__generate_exit_8_0_i39);
Declare_label(mercury__code_gen__generate_exit_8_0_i41);
Declare_label(mercury__code_gen__generate_exit_8_0_i43);
Declare_label(mercury__code_gen__generate_exit_8_0_i42);
Declare_label(mercury__code_gen__generate_exit_8_0_i46);
Declare_label(mercury__code_gen__generate_exit_8_0_i44);
Declare_static(mercury__code_gen__generate_goal_2_6_0);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i1002);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i6);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i7);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i1004);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i14);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i15);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i17);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i19);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i21);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i23);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i25);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i27);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i29);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i31);
Declare_label(mercury__code_gen__generate_goal_2_6_0_i32);
Declare_static(mercury__code_gen__generate_goals_5_0);
Declare_label(mercury__code_gen__generate_goals_5_0_i3);
Declare_label(mercury__code_gen__generate_goals_5_0_i4);
Declare_label(mercury__code_gen__generate_goals_5_0_i5);
Declare_label(mercury__code_gen__generate_goals_5_0_i8);
Declare_label(mercury__code_gen__generate_goals_5_0_i6);
Declare_label(mercury__code_gen__generate_goals_5_0_i10);
Declare_static(mercury__code_gen__select_args_with_mode_4_0);
Declare_label(mercury__code_gen__select_args_with_mode_4_0_i4);
Declare_label(mercury__code_gen__select_args_with_mode_4_0_i6);
Declare_label(mercury__code_gen__select_args_with_mode_4_0_i3);
Declare_label(mercury__code_gen__select_args_with_mode_4_0_i2);
Declare_static(mercury__code_gen__add_saved_succip_3_0);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i7);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i11);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i5);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i14);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i12);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i17);
Declare_label(mercury__code_gen__add_saved_succip_3_0_i3);
Declare_static(mercury____Unify___code_gen__frame_info_0_0);
Declare_label(mercury____Unify___code_gen__frame_info_0_0_i2);
Declare_label(mercury____Unify___code_gen__frame_info_0_0_i1004);
Declare_label(mercury____Unify___code_gen__frame_info_0_0_i1);
Declare_static(mercury____Index___code_gen__frame_info_0_0);
Declare_static(mercury____Compare___code_gen__frame_info_0_0);
Declare_label(mercury____Compare___code_gen__frame_info_0_0_i3);
Declare_label(mercury____Compare___code_gen__frame_info_0_0_i7);
Declare_label(mercury____Compare___code_gen__frame_info_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_code_gen__type_ctor_info_frame_info_0;

static const struct mercury_data_code_gen__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_0;

static const struct mercury_data_code_gen__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_1;

static const struct mercury_data_code_gen__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_code_gen__common_2;

static const struct mercury_data_code_gen__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_3;

static const struct mercury_data_code_gen__common_4_struct {
	Integer f1;
	Word * f2;
	Integer f3;
}  mercury_data_code_gen__common_4;

static const struct mercury_data_code_gen__common_5_struct {
	Integer f1;
	Integer f2;
}  mercury_data_code_gen__common_5;

static const struct mercury_data_code_gen__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_gen__common_6;

static const struct mercury_data_code_gen__common_7_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_code_gen__common_7;

static const struct mercury_data_code_gen__common_8_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_8;

static const struct mercury_data_code_gen__common_9_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_gen__common_9;

static const struct mercury_data_code_gen__common_10_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_10;

static const struct mercury_data_code_gen__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_11;

static const struct mercury_data_code_gen__common_12_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_12;

static const struct mercury_data_code_gen__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_13;

static const struct mercury_data_code_gen__common_14_struct {
	Word * f1;
}  mercury_data_code_gen__common_14;

static const struct mercury_data_code_gen__common_15_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_gen__common_15;

static const struct mercury_data_code_gen__common_16_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_16;

static const struct mercury_data_code_gen__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_17;

static const struct mercury_data_code_gen__common_18_struct {
	Word * f1;
}  mercury_data_code_gen__common_18;

static const struct mercury_data_code_gen__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_19;

static const struct mercury_data_code_gen__common_20_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_20;

static const struct mercury_data_code_gen__common_21_struct {
	String f1;
}  mercury_data_code_gen__common_21;

static const struct mercury_data_code_gen__common_22_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_22;

static const struct mercury_data_code_gen__common_23_struct {
	Word * f1;
}  mercury_data_code_gen__common_23;

static const struct mercury_data_code_gen__common_24_struct {
	String f1;
}  mercury_data_code_gen__common_24;

static const struct mercury_data_code_gen__common_25_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_25;

static const struct mercury_data_code_gen__common_26_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_26;

static const struct mercury_data_code_gen__common_27_struct {
	Word * f1;
}  mercury_data_code_gen__common_27;

static const struct mercury_data_code_gen__common_28_struct {
	String f1;
}  mercury_data_code_gen__common_28;

static const struct mercury_data_code_gen__common_29_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_29;

static const struct mercury_data_code_gen__common_30_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_30;

static const struct mercury_data_code_gen__common_31_struct {
	Word * f1;
}  mercury_data_code_gen__common_31;

static const struct mercury_data_code_gen__common_32_struct {
	String f1;
}  mercury_data_code_gen__common_32;

static const struct mercury_data_code_gen__common_33_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_33;

static const struct mercury_data_code_gen__common_34_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_34;

static const struct mercury_data_code_gen__common_35_struct {
	Word * f1;
}  mercury_data_code_gen__common_35;

static const struct mercury_data_code_gen__common_36_struct {
	Integer f1;
	String f2;
}  mercury_data_code_gen__common_36;

static const struct mercury_data_code_gen__common_37_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_37;

static const struct mercury_data_code_gen__common_38_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Integer f4;
	Word * f5;
	Word * f6;
	Integer f7;
}  mercury_data_code_gen__common_38;

static const struct mercury_data_code_gen__common_39_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_39;

static const struct mercury_data_code_gen__common_40_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_40;

static const struct mercury_data_code_gen__common_41_struct {
	Word * f1;
}  mercury_data_code_gen__common_41;

static const struct mercury_data_code_gen__common_42_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_42;

static const struct mercury_data_code_gen__common_43_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_43;

static const struct mercury_data_code_gen__common_44_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_44;

static const struct mercury_data_code_gen__common_45_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_45;

static const struct mercury_data_code_gen__common_46_struct {
	Word * f1;
}  mercury_data_code_gen__common_46;

static const struct mercury_data_code_gen__common_47_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_code_gen__common_47;

static const struct mercury_data_code_gen__common_48_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_gen__common_48;

static const struct mercury_data_code_gen__common_49_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_code_gen__common_49;

static const struct mercury_data_code_gen__common_50_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_50;

static const struct mercury_data_code_gen__common_51_struct {
	Integer f1;
}  mercury_data_code_gen__common_51;

static const struct mercury_data_code_gen__common_52_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_gen__common_52;

static const struct mercury_data_code_gen__common_53_struct {
	Word * f1;
	String f2;
}  mercury_data_code_gen__common_53;

static const struct mercury_data_code_gen__common_54_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_54;

static const struct mercury_data_code_gen__common_55_struct {
	Word * f1;
}  mercury_data_code_gen__common_55;

static const struct mercury_data_code_gen__common_56_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_gen__common_56;

static const struct mercury_data_code_gen__common_57_struct {
	Word * f1;
}  mercury_data_code_gen__common_57;

static const struct mercury_data_code_gen__common_58_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_code_gen__common_58;

static const struct mercury_data_code_gen__type_ctor_functors_frame_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_code_gen__type_ctor_functors_frame_info_0;

static const struct mercury_data_code_gen__type_ctor_layout_frame_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_code_gen__type_ctor_layout_frame_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_code_gen__type_ctor_info_frame_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___code_gen__frame_info_0_0),
	STATIC(mercury____Index___code_gen__frame_info_0_0),
	STATIC(mercury____Compare___code_gen__frame_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_code_gen__type_ctor_functors_frame_info_0,
	(Word *) &mercury_data_code_gen__type_ctor_layout_frame_info_0,
	MR_string_const("code_gen", 8),
	MR_string_const("frame_info", 10),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_layout_locn_0;
static const struct mercury_data_code_gen__common_0_struct mercury_data_code_gen__common_0 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_llds__type_ctor_info_layout_locn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_code_gen__common_1_struct mercury_data_code_gen__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_code_gen__common_2_struct mercury_data_code_gen__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_code_gen__common_3_struct mercury_data_code_gen__common_3 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_2)
};

static const struct mercury_data_code_gen__common_4_struct mercury_data_code_gen__common_4 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0
};

static const struct mercury_data_code_gen__common_5_struct mercury_data_code_gen__common_5 = {
	(Integer) 0,
	(Integer) 1
};

static const struct mercury_data_code_gen__common_6_struct mercury_data_code_gen__common_6 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_code_gen__common_7_struct mercury_data_code_gen__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_6)
};

static const struct mercury_data_code_gen__common_8_struct mercury_data_code_gen__common_8 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_7),
	MR_string_const("Fail", 4)
};

static const struct mercury_data_code_gen__common_9_struct mercury_data_code_gen__common_9 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_10_struct mercury_data_code_gen__common_10 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_9),
	MR_string_const("Return from procedure call", 26)
};

static const struct mercury_data_code_gen__common_11_struct mercury_data_code_gen__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_12_struct mercury_data_code_gen__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_string_const("discard retry ticket", 20)
};

static const struct mercury_data_code_gen__common_13_struct mercury_data_code_gen__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_14_struct mercury_data_code_gen__common_14 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_13)
};

static const struct mercury_data_code_gen__common_15_struct mercury_data_code_gen__common_15 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))
};

static const struct mercury_data_code_gen__common_16_struct mercury_data_code_gen__common_16 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_15),
	MR_string_const("fail after fail trace port", 26)
};

static const struct mercury_data_code_gen__common_17_struct mercury_data_code_gen__common_17 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_18_struct mercury_data_code_gen__common_18 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_17)
};

static const struct mercury_data_code_gen__common_19_struct mercury_data_code_gen__common_19 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_18)
};

static const struct mercury_data_code_gen__common_20_struct mercury_data_code_gen__common_20 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_18)
};

static const struct mercury_data_code_gen__common_21_struct mercury_data_code_gen__common_21 = {
	MR_string_const("Start of procedure prologue", 27)
};

static const struct mercury_data_code_gen__common_22_struct mercury_data_code_gen__common_22 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_21),
	MR_string_const("", 0)
};

static const struct mercury_data_code_gen__common_23_struct mercury_data_code_gen__common_23 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_24_struct mercury_data_code_gen__common_24 = {
	MR_string_const("End of procedure prologue", 25)
};

static const struct mercury_data_code_gen__common_25_struct mercury_data_code_gen__common_25 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_24),
	MR_string_const("", 0)
};

static const struct mercury_data_code_gen__common_26_struct mercury_data_code_gen__common_26 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_25),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_27_struct mercury_data_code_gen__common_27 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_26)
};

static const struct mercury_data_code_gen__common_28_struct mercury_data_code_gen__common_28 = {
	MR_string_const("End of procedure epilogue", 25)
};

static const struct mercury_data_code_gen__common_29_struct mercury_data_code_gen__common_29 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_28),
	MR_string_const("", 0)
};

static const struct mercury_data_code_gen__common_30_struct mercury_data_code_gen__common_30 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_29),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_31_struct mercury_data_code_gen__common_31 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_30)
};

static const struct mercury_data_code_gen__common_32_struct mercury_data_code_gen__common_32 = {
	MR_string_const("Start of procedure epilogue", 27)
};

static const struct mercury_data_code_gen__common_33_struct mercury_data_code_gen__common_33 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_32),
	MR_string_const("", 0)
};

static const struct mercury_data_code_gen__common_34_struct mercury_data_code_gen__common_34 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_33),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_35_struct mercury_data_code_gen__common_35 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_34)
};

static const struct mercury_data_code_gen__common_36_struct mercury_data_code_gen__common_36 = {
	(Integer) 1,
	MR_string_const("#undef\tMR_ORDINARY_SLOTS\n", 25)
};

static const struct mercury_data_code_gen__common_37_struct mercury_data_code_gen__common_37 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_36),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_38_struct mercury_data_code_gen__common_38 = {
	(Integer) 18,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_37),
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0
};

static const struct mercury_data_code_gen__common_39_struct mercury_data_code_gen__common_39 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_38),
	MR_string_const("", 0)
};

static const struct mercury_data_code_gen__common_40_struct mercury_data_code_gen__common_40 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_39),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_41_struct mercury_data_code_gen__common_41 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_40)
};

static const struct mercury_data_code_gen__common_42_struct mercury_data_code_gen__common_42 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_41),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_31)
};

static const struct mercury_data_code_gen__common_43_struct mercury_data_code_gen__common_43 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_35),
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_code_gen__common_42)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_code_gen__common_44_struct mercury_data_code_gen__common_44 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_code_gen__common_45_struct mercury_data_code_gen__common_45 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
static const struct mercury_data_code_gen__common_46_struct mercury_data_code_gen__common_46 = {
	(Word *) &mercury_data_llds__type_ctor_info_lval_0
};

static const struct mercury_data_code_gen__common_47_struct mercury_data_code_gen__common_47 = {
	(Integer) 0,
	MR_string_const("code_gen", 8),
	MR_string_const("code_gen", 8),
	MR_string_const("IntroducedFrom__pred__generate_exit__742__1", 43),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_45),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_46)
};

static const struct mercury_data_code_gen__common_48_struct mercury_data_code_gen__common_48 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_gen__common_49_struct mercury_data_code_gen__common_49 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_48)
};

static const struct mercury_data_code_gen__common_50_struct mercury_data_code_gen__common_50 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_49),
	MR_string_const("Succeed", 7)
};

static const struct mercury_data_code_gen__common_51_struct mercury_data_code_gen__common_51 = {
	(Integer) 0
};

static const struct mercury_data_code_gen__common_52_struct mercury_data_code_gen__common_52 = {
	(Integer) 5,
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_51)
};

static const struct mercury_data_code_gen__common_53_struct mercury_data_code_gen__common_53 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_gen__common_52),
	MR_string_const("Return from procedure call", 26)
};

static const struct mercury_data_code_gen__common_54_struct mercury_data_code_gen__common_54 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_53),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_code_gen__common_55_struct mercury_data_code_gen__common_55 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_code_gen__common_56_struct mercury_data_code_gen__common_56 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_code_gen__common_57_struct mercury_data_code_gen__common_57 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_code_gen__common_58_struct mercury_data_code_gen__common_58 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_56),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_57),
	MR_string_const("frame", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_code_gen__type_ctor_functors_frame_info_0_struct mercury_data_code_gen__type_ctor_functors_frame_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_58)
};

static const struct mercury_data_code_gen__type_ctor_layout_frame_info_0_struct mercury_data_code_gen__type_ctor_layout_frame_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_58),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(code_gen_module0)
	init_entry(mercury____Index___code_gen__frame_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___code_gen__frame_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___code_gen__frame_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(do_fail);
Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__set__member_2_1);

BEGIN_MODULE(code_gen_module1)
	init_entry(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0);
	init_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i1);
	init_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generate_exit__742__1'/2 in mode 0 */
Define_static(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0);
	MR_mkframe("code_gen:IntroducedFrom__pred__generate_exit__742__1/2", 0, ENTRY(do_fail));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_0);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i1,
		STATIC(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0));
Define_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i1);
	update_prof_current_proc(LABEL(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_layout_locn_0;
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i2,
		STATIC(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0));
Define_label(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0));
	r1 = MR_const_mask_field(r1, (Integer) 0);
	MR_succeed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);

BEGIN_MODULE(code_gen_module2)
	init_entry(mercury__code_gen__generate_code_7_0);
	init_label(mercury__code_gen__generate_code_7_0_i2);
BEGIN_CODE

/* code for predicate 'generate_code'/7 in mode 0 */
Define_entry(mercury__code_gen__generate_code_7_0);
	MR_incr_sp_push_msg(4, "code_gen:generate_code/7");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__code_gen__generate_code_7_0_i2,
		ENTRY(mercury__code_gen__generate_code_7_0));
Define_label(mercury__code_gen__generate_code_7_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_code_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_gen__generate_pred_list_code_8_0),
		ENTRY(mercury__code_gen__generate_code_7_0));
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_follow_vars_2_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__continuation_info__basic_stack_layout_for_proc_4_0);
Declare_entry(mercury__code_info__init_11_0);
Declare_entry(mercury__code_info__get_max_reg_in_use_at_trace_3_0);
Declare_entry(mercury__code_info__get_cell_count_3_0);
Declare_entry(mercury__tree__flatten_2_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__code_info__get_layout_info_3_0);
Declare_entry(mercury__code_util__make_local_entry_label_5_0);
Declare_entry(mercury__llds__global_data_add_new_proc_layout_4_0);
Declare_entry(mercury__code_info__get_non_common_static_data_3_0);
Declare_entry(mercury__llds__global_data_add_new_non_common_static_datas_3_0);
Declare_entry(mercury__hlds_pred__proc_info_eval_method_2_0);
Declare_entry(mercury__code_util__make_proc_label_4_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__llds__global_data_add_new_proc_var_4_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);

BEGIN_MODULE(code_gen_module3)
	init_entry(mercury__code_gen__generate_proc_code_11_0);
	init_label(mercury__code_gen__generate_proc_code_11_0_i2);
	init_label(mercury__code_gen__generate_proc_code_11_0_i3);
	init_label(mercury__code_gen__generate_proc_code_11_0_i4);
	init_label(mercury__code_gen__generate_proc_code_11_0_i5);
	init_label(mercury__code_gen__generate_proc_code_11_0_i8);
	init_label(mercury__code_gen__generate_proc_code_11_0_i7);
	init_label(mercury__code_gen__generate_proc_code_11_0_i6);
	init_label(mercury__code_gen__generate_proc_code_11_0_i9);
	init_label(mercury__code_gen__generate_proc_code_11_0_i10);
	init_label(mercury__code_gen__generate_proc_code_11_0_i12);
	init_label(mercury__code_gen__generate_proc_code_11_0_i13);
	init_label(mercury__code_gen__generate_proc_code_11_0_i14);
	init_label(mercury__code_gen__generate_proc_code_11_0_i15);
	init_label(mercury__code_gen__generate_proc_code_11_0_i16);
	init_label(mercury__code_gen__generate_proc_code_11_0_i17);
	init_label(mercury__code_gen__generate_proc_code_11_0_i18);
	init_label(mercury__code_gen__generate_proc_code_11_0_i21);
	init_label(mercury__code_gen__generate_proc_code_11_0_i19);
	init_label(mercury__code_gen__generate_proc_code_11_0_i22);
	init_label(mercury__code_gen__generate_proc_code_11_0_i25);
	init_label(mercury__code_gen__generate_proc_code_11_0_i26);
	init_label(mercury__code_gen__generate_proc_code_11_0_i27);
	init_label(mercury__code_gen__generate_proc_code_11_0_i23);
	init_label(mercury__code_gen__generate_proc_code_11_0_i29);
	init_label(mercury__code_gen__generate_proc_code_11_0_i30);
	init_label(mercury__code_gen__generate_proc_code_11_0_i31);
	init_label(mercury__code_gen__generate_proc_code_11_0_i36);
	init_label(mercury__code_gen__generate_proc_code_11_0_i37);
	init_label(mercury__code_gen__generate_proc_code_11_0_i38);
	init_label(mercury__code_gen__generate_proc_code_11_0_i33);
	init_label(mercury__code_gen__generate_proc_code_11_0_i39);
	init_label(mercury__code_gen__generate_proc_code_11_0_i40);
	init_label(mercury__code_gen__generate_proc_code_11_0_i41);
BEGIN_CODE

/* code for predicate 'generate_proc_code'/11 in mode 0 */
Define_entry(mercury__code_gen__generate_proc_code_11_0);
	MR_incr_sp_push_msg(18, "code_gen:generate_proc_code/11");
	MR_stackvar(18) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		mercury__code_gen__generate_proc_code_11_0_i2,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__code_gen__generate_proc_code_11_0_i3,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__code_gen__generate_proc_code_11_0_i4,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(11) = r1;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_follow_vars_2_0),
		mercury__code_gen__generate_proc_code_11_0_i5,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_1);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__code_gen__generate_proc_code_11_0_i8,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i6);
Define_label(mercury__code_gen__generate_proc_code_11_0_i7);
	MR_stackvar(12) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
Define_label(mercury__code_gen__generate_proc_code_11_0_i6);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__continuation_info__basic_stack_layout_for_proc_4_0),
		mercury__code_gen__generate_proc_code_11_0_i9,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i9);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i10);
	r6 = MR_stackvar(12);
	r8 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	MR_stackvar(12) = r2;
	r1 = (Integer) 1;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	r7 = MR_stackvar(5);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i12);
Define_label(mercury__code_gen__generate_proc_code_11_0_i10);
	r6 = MR_stackvar(12);
	r8 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	MR_stackvar(12) = r2;
	r1 = (Integer) 0;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	r7 = MR_stackvar(5);
Define_label(mercury__code_gen__generate_proc_code_11_0_i12);
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r7;
	call_localret(ENTRY(mercury__code_info__init_11_0),
		mercury__code_gen__generate_proc_code_11_0_i13,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r5 = r3;
	r3 = r1;
	r1 = MR_stackvar(10);
	r4 = r2;
	MR_stackvar(10) = r2;
	r2 = MR_stackvar(11);
	call_localret(STATIC(mercury__code_gen__generate_category_code_9_0),
		mercury__code_gen__generate_proc_code_11_0_i14,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(6) = r1;
	r1 = r4;
	MR_stackvar(11) = r2;
	MR_stackvar(13) = r3;
	MR_stackvar(14) = r4;
	call_localret(ENTRY(mercury__code_info__get_max_reg_in_use_at_trace_3_0),
		mercury__code_gen__generate_proc_code_11_0_i15,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i15);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__get_cell_count_3_0),
		mercury__code_gen__generate_proc_code_11_0_i16,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_3);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__code_gen__generate_proc_code_11_0_i17,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_2);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__code_gen__generate_proc_code_11_0_i18,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(13), (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(13), (Integer) 0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i19);
	MR_stackvar(16) = r2;
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(13) = r3;
	call_localret(STATIC(mercury__code_gen__add_saved_succip_3_0),
		mercury__code_gen__generate_proc_code_11_0_i21,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i22);
Define_label(mercury__code_gen__generate_proc_code_11_0_i19);
	MR_stackvar(16) = r2;
	r2 = r1;
	r1 = MR_stackvar(14);
	MR_stackvar(13) = r3;
Define_label(mercury__code_gen__generate_proc_code_11_0_i22);
	if (((Integer) MR_stackvar(8) != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i23);
	MR_stackvar(14) = r1;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__code_info__get_layout_info_3_0),
		mercury__code_gen__generate_proc_code_11_0_i25,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_gen__generate_proc_code_11_0_i26,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i26);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r4 = r1;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_proc_code_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	r1 = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 9, mercury__code_gen__generate_proc_code_11_0, "continuation_info:proc_layout_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(16);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(15);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(17);
	call_localret(ENTRY(mercury__llds__global_data_add_new_proc_layout_4_0),
		mercury__code_gen__generate_proc_code_11_0_i27,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__get_non_common_static_data_3_0),
		mercury__code_gen__generate_proc_code_11_0_i29,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i23);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__code_info__get_non_common_static_data_3_0),
		mercury__code_gen__generate_proc_code_11_0_i29,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__llds__global_data_add_new_non_common_static_datas_3_0),
		mercury__code_gen__generate_proc_code_11_0_i30,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_eval_method_2_0),
		mercury__code_gen__generate_proc_code_11_0_i31,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i31);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	if (((Integer) r1 == (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i33);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_util__make_proc_label_4_0),
		mercury__code_gen__generate_proc_code_11_0_i36,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i36);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__code_gen__generate_proc_code_11_0_i37,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i37);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_proc_code_11_0, "hlds_pred:pred_proc_id/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_proc_code_11_0, "llds:comp_gen_c_var/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__llds__global_data_add_new_proc_var_4_0),
		mercury__code_gen__generate_proc_code_11_0_i38,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i38);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__code_gen__generate_proc_code_11_0_i39);
Define_label(mercury__code_gen__generate_proc_code_11_0_i33);
	r1 = MR_stackvar(1);
	MR_stackvar(2) = MR_stackvar(7);
Define_label(mercury__code_gen__generate_proc_code_11_0_i39);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_gen__generate_proc_code_11_0_i40,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i40);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_gen__generate_proc_code_11_0_i41,
		ENTRY(mercury__code_gen__generate_proc_code_11_0));
Define_label(mercury__code_gen__generate_proc_code_11_0_i41);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_code_11_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__code_gen__generate_proc_code_11_0, "llds:c_procedure/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_proc_code_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
END_MODULE

Declare_entry(mercury__hlds_goal__goal_is_atomic_1_0);
Declare_entry(mercury__code_info__pre_goal_update_4_0);
Declare_entry(mercury__code_info__get_instmap_3_0);
Declare_entry(mercury__instmap__is_reachable_1_0);
Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__code_info__set_instmap_3_0);
Declare_entry(mercury__code_info__post_goal_update_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_code_info__type_ctor_info_code_info_0;
Declare_entry(mercury__f_cut_2_1);

BEGIN_MODULE(code_gen_module4)
	init_entry(mercury__code_gen__generate_goal_5_0);
	init_label(mercury__code_gen__generate_goal_5_0_i4);
	init_label(mercury__code_gen__generate_goal_5_0_i2);
	init_label(mercury__code_gen__generate_goal_5_0_i6);
	init_label(mercury__code_gen__generate_goal_5_0_i7);
	init_label(mercury__code_gen__generate_goal_5_0_i8);
	init_label(mercury__code_gen__generate_goal_5_0_i11);
	init_label(mercury__code_gen__generate_goal_5_0_i13);
	init_label(mercury__code_gen__generate_goal_5_0_i15);
	init_label(mercury__code_gen__generate_goal_5_0_i18);
	init_label(mercury__code_gen__generate_goal_5_0_i16);
	init_label(mercury__code_gen__generate_goal_5_0_i23);
	init_label(mercury__code_gen__generate_goal_5_0_i25);
	init_label(mercury__code_gen__generate_goal_5_0_i14);
	init_label(mercury__code_gen__generate_goal_5_0_i27);
	init_label(mercury__code_gen__generate_goal_5_0_i28);
	init_label(mercury__code_gen__generate_goal_5_0_i29);
	init_label(mercury__code_gen__generate_goal_5_0_i9);
	init_label(mercury__code_gen__generate_goal_5_0_i31);
BEGIN_CODE

/* code for predicate 'generate_goal'/5 in mode 0 */
Define_entry(mercury__code_gen__generate_goal_5_0);
	MR_incr_sp_push_msg(9, "code_gen:generate_goal/5");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__code_gen__generate_goal_5_0_i4,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i2);
	r3 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	r2 = (Integer) 1;
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i6);
Define_label(mercury__code_gen__generate_goal_5_0_i2);
	r1 = MR_stackvar(5);
	r2 = (Integer) 0;
	r3 = MR_stackvar(3);
Define_label(mercury__code_gen__generate_goal_5_0_i6);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__code_info__pre_goal_update_4_0),
		mercury__code_gen__generate_goal_5_0_i7,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_goal_5_0_i8,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	MR_stackvar(6) = r1;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__code_gen__generate_goal_5_0_i11,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i9);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__code_gen__generate_goal_5_0_i13,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i13);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i15);
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i15);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i16);
	if (((Integer) MR_stackvar(1) == (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i18);
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i18);
	MR_stackvar(7) = r1;
	r1 = (Word) MR_string_const("semidet model in det context", 28);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_5_0_i25,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i16);
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i23);
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(8);
	GOTO_LABEL(mercury__code_gen__generate_goal_5_0_i14);
Define_label(mercury__code_gen__generate_goal_5_0_i23);
	MR_stackvar(7) = r1;
	r1 = (Word) MR_string_const("nondet model in det/semidet context", 35);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_5_0_i25,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
Define_label(mercury__code_gen__generate_goal_5_0_i14);
	MR_stackvar(5) = r2;
	call_localret(STATIC(mercury__code_gen__generate_goal_2_6_0),
		mercury__code_gen__generate_goal_5_0_i27,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__set_instmap_3_0),
		mercury__code_gen__generate_goal_5_0_i28,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__post_goal_update_3_0),
		mercury__code_gen__generate_goal_5_0_i29,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_code_info__type_ctor_info_code_info_0;
	call_localret(ENTRY(mercury__f_cut_2_1),
		mercury__code_gen__generate_goal_5_0_i31,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i9);
	r2 = MR_stackvar(8);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_code_info__type_ctor_info_code_info_0;
	call_localret(ENTRY(mercury__f_cut_2_1),
		mercury__code_gen__generate_goal_5_0_i31,
		ENTRY(mercury__code_gen__generate_goal_5_0));
Define_label(mercury__code_gen__generate_goal_5_0_i31);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
Declare_entry(mercury__hlds_pred__pred_info_is_aditi_relation_1_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_id_4_0);
Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);
Declare_entry(mercury__hlds_module__module_info_get_cell_count_2_0);
Declare_entry(mercury__globals__io_get_globals_3_0);
Declare_entry(mercury__hlds_module__module_info_set_cell_count_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_c_procedure_0;
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(code_gen_module5)
	init_entry(mercury__code_gen__generate_pred_list_code_8_0);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i4);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i5);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i6);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i10);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i12);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i9);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i7);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i14);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i17);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i18);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i19);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i20);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i21);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i15);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i22);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i23);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i24);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i25);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i26);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i28);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i29);
	init_label(mercury__code_gen__generate_pred_list_code_8_0_i3);
BEGIN_CODE

/* code for predicate 'generate_pred_list_code'/8 in mode 0 */
Define_static(mercury__code_gen__generate_pred_list_code_8_0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i3);
	MR_incr_sp_push_msg(11, "code_gen:generate_pred_list_code/8");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	MR_stackvar(5) = r4;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_gen__generate_pred_list_code_8_0_i4,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i5,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__code_gen__generate_pred_list_code_8_0_i6,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i10);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i9);
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i10);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_aditi_relation_1_0),
		mercury__code_gen__generate_pred_list_code_8_0_i12,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r3 = MR_stackvar(8);
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i9);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__code_gen__generate_pred_list_code_8_0,
		LABEL(mercury__code_gen__generate_pred_list_code_8_0_i28),
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i7);
	r1 = (Integer) 18;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__code_gen__generate_pred_list_code_8_0_i14,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i15);
	r1 = (Word) MR_string_const("% Generating code for ", 22);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i17,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__code_gen__generate_pred_list_code_8_0_i18,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i18);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i19,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i19);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r2 = r1;
	r1 = (Integer) 20;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__code_gen__generate_pred_list_code_8_0_i20,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i21,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i21);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__code_gen__generate_pred_list_code_8_0_i22);
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i15);
	r1 = MR_stackvar(1);
	MR_stackvar(2) = r2;
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i22);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_cell_count_2_0),
		mercury__code_gen__generate_pred_list_code_8_0_i23,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__globals__io_get_globals_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i24,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r6 = MR_stackvar(3);
	r5 = r1;
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(1);
	r7 = MR_stackvar(2);
	r8 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__code_gen__generate_proc_list_code_11_0),
		mercury__code_gen__generate_pred_list_code_8_0_i25,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_set_cell_count_3_0),
		mercury__code_gen__generate_pred_list_code_8_0_i26,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
	}
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i26);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r3 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	localcall(mercury__code_gen__generate_pred_list_code_8_0,
		LABEL(mercury__code_gen__generate_pred_list_code_8_0_i28),
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_c_procedure_0;
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__code_gen__generate_pred_list_code_8_0_i29,
		STATIC(mercury__code_gen__generate_pred_list_code_8_0));
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_pred_list_code_8_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__code_gen__generate_pred_list_code_8_0_i3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;

BEGIN_MODULE(code_gen_module6)
	init_entry(mercury__code_gen__generate_proc_list_code_11_0);
	init_label(mercury__code_gen__generate_proc_list_code_11_0_i1001);
	init_label(mercury__code_gen__generate_proc_list_code_11_0_i4);
	init_label(mercury__code_gen__generate_proc_list_code_11_0_i5);
	init_label(mercury__code_gen__generate_proc_list_code_11_0_i6);
	init_label(mercury__code_gen__generate_proc_list_code_11_0_i3);
BEGIN_CODE

/* code for predicate 'generate_proc_list_code'/11 in mode 0 */
Define_static(mercury__code_gen__generate_proc_list_code_11_0);
	MR_incr_sp_push_msg(10, "code_gen:generate_proc_list_code/11");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__code_gen__generate_proc_list_code_11_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_proc_list_code_11_0_i3);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__code_gen__generate_proc_list_code_11_0_i4,
		STATIC(mercury__code_gen__generate_proc_list_code_11_0));
Define_label(mercury__code_gen__generate_proc_list_code_11_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_11_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__code_gen__generate_proc_list_code_11_0_i5,
		STATIC(mercury__code_gen__generate_proc_list_code_11_0));
Define_label(mercury__code_gen__generate_proc_list_code_11_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_11_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	call_localret(STATIC(mercury__code_gen__generate_proc_code_11_0),
		mercury__code_gen__generate_proc_list_code_11_0_i6,
		STATIC(mercury__code_gen__generate_proc_list_code_11_0));
Define_label(mercury__code_gen__generate_proc_list_code_11_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_proc_list_code_11_0));
	r6 = r1;
	r7 = r2;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_proc_list_code_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 0) = r3;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__code_gen__generate_proc_list_code_11_0_i1001);
Define_label(mercury__code_gen__generate_proc_list_code_11_0_i3);
	r1 = r6;
	r2 = r7;
	r3 = r8;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__globals__lookup_bool_option_3_1);
Declare_entry(mercury__middle_rec__match_and_generate_4_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__code_info__get_maybe_trace_info_3_0);
Declare_entry(mercury__trace__generate_external_event_code_8_0);
Declare_entry(mercury__set__singleton_set_2_1);
Declare_entry(mercury__code_info__generate_resume_point_4_0);
Declare_entry(mercury__code_info__resume_point_vars_2_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__code_info__set_forward_live_vars_3_0);

BEGIN_MODULE(code_gen_module7)
	init_entry(mercury__code_gen__generate_category_code_9_0);
	init_label(mercury__code_gen__generate_category_code_9_0_i5);
	init_label(mercury__code_gen__generate_category_code_9_0_i6);
	init_label(mercury__code_gen__generate_category_code_9_0_i8);
	init_label(mercury__code_gen__generate_category_code_9_0_i4);
	init_label(mercury__code_gen__generate_category_code_9_0_i10);
	init_label(mercury__code_gen__generate_category_code_9_0_i11);
	init_label(mercury__code_gen__generate_category_code_9_0_i14);
	init_label(mercury__code_gen__generate_category_code_9_0_i12);
	init_label(mercury__code_gen__generate_category_code_9_0_i15);
	init_label(mercury__code_gen__generate_category_code_9_0_i16);
	init_label(mercury__code_gen__generate_category_code_9_0_i17);
	init_label(mercury__code_gen__generate_category_code_9_0_i1041);
	init_label(mercury__code_gen__generate_category_code_9_0_i3);
	init_label(mercury__code_gen__generate_category_code_9_0_i1045);
	init_label(mercury__code_gen__generate_category_code_9_0_i22);
	init_label(mercury__code_gen__generate_category_code_9_0_i23);
	init_label(mercury__code_gen__generate_category_code_9_0_i1051);
	init_label(mercury__code_gen__generate_category_code_9_0_i27);
	init_label(mercury__code_gen__generate_category_code_9_0_i28);
	init_label(mercury__code_gen__generate_category_code_9_0_i29);
	init_label(mercury__code_gen__generate_category_code_9_0_i30);
	init_label(mercury__code_gen__generate_category_code_9_0_i31);
	init_label(mercury__code_gen__generate_category_code_9_0_i32);
	init_label(mercury__code_gen__generate_category_code_9_0_i33);
	init_label(mercury__code_gen__generate_category_code_9_0_i1052);
	init_label(mercury__code_gen__generate_category_code_9_0_i24);
	init_label(mercury__code_gen__generate_category_code_9_0_i35);
	init_label(mercury__code_gen__generate_category_code_9_0_i36);
	init_label(mercury__code_gen__generate_category_code_9_0_i37);
	init_label(mercury__code_gen__generate_category_code_9_0_i38);
	init_label(mercury__code_gen__generate_category_code_9_0_i20);
	init_label(mercury__code_gen__generate_category_code_9_0_i40);
	init_label(mercury__code_gen__generate_category_code_9_0_i41);
	init_label(mercury__code_gen__generate_category_code_9_0_i1065);
	init_label(mercury__code_gen__generate_category_code_9_0_i45);
	init_label(mercury__code_gen__generate_category_code_9_0_i46);
	init_label(mercury__code_gen__generate_category_code_9_0_i47);
	init_label(mercury__code_gen__generate_category_code_9_0_i48);
	init_label(mercury__code_gen__generate_category_code_9_0_i49);
	init_label(mercury__code_gen__generate_category_code_9_0_i50);
	init_label(mercury__code_gen__generate_category_code_9_0_i51);
	init_label(mercury__code_gen__generate_category_code_9_0_i52);
	init_label(mercury__code_gen__generate_category_code_9_0_i1073);
	init_label(mercury__code_gen__generate_category_code_9_0_i42);
	init_label(mercury__code_gen__generate_category_code_9_0_i56);
	init_label(mercury__code_gen__generate_category_code_9_0_i57);
	init_label(mercury__code_gen__generate_category_code_9_0_i1079);
BEGIN_CODE

/* code for predicate 'generate_category_code'/9 in mode 0 */
Define_static(mercury__code_gen__generate_category_code_9_0);
	MR_incr_sp_push_msg(13, "code_gen:generate_category_code/9");
	MR_stackvar(13) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	r1 = r5;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__code_gen__generate_category_code_9_0_i5,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(5) = r2;
	r2 = (Integer) 191;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__code_gen__generate_category_code_9_0_i6,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__middle_rec__match_and_generate_4_0),
		mercury__code_gen__generate_category_code_9_0_i8,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i4);
	r1 = r2;
	r4 = r3;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_4);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__code_gen__generate_category_code_9_0_i4);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__code_gen__generate_category_code_9_0_i10,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_category_code_9_0_i11,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i12);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Integer) 0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_category_code_9_0_i14,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r2 = MR_stackvar(1);
	MR_stackvar(6) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Integer) 0;
	r3 = r4;
	MR_stackvar(4) = MR_tempr1;
	GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i15);
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i12);
	r3 = r2;
	r1 = (Integer) 0;
	r2 = MR_stackvar(1);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__code_gen__generate_category_code_9_0_i15);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_9_0_i16,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i16);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r3 = MR_stackvar(2);
	r4 = r2;
	MR_stackvar(2) = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__code_gen__generate_entry_7_0),
		mercury__code_gen__generate_category_code_9_0_i17,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r5 = r3;
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Integer) 0;
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__code_gen__generate_exit_8_0),
		mercury__code_gen__generate_category_code_9_0_i1041,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1041);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i20);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_5);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__code_gen__generate_category_code_9_0_i1045,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1045);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_11);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__code_gen__generate_category_code_9_0_i22,
		STATIC(mercury__code_gen__generate_category_code_9_0));
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_category_code_9_0_i23,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i24);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = r2;
	r1 = (Integer) 0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_category_code_9_0_i1051,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1051);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(8) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	r3 = r4;
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_9_0_i27,
		STATIC(mercury__code_gen__generate_category_code_9_0));
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r4 = r2;
	MR_stackvar(9) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__code_gen__generate_entry_7_0),
		mercury__code_gen__generate_category_code_9_0_i28,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i28);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r5 = r3;
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Integer) 1;
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__code_gen__generate_exit_8_0),
		mercury__code_gen__generate_category_code_9_0_i29,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i29);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(10) = r1;
	MR_stackvar(11) = r2;
	r1 = MR_stackvar(2);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__generate_resume_point_4_0),
		mercury__code_gen__generate_category_code_9_0_i30,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__code_info__resume_point_vars_2_0),
		mercury__code_gen__generate_category_code_9_0_i31,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i31);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_1);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__code_gen__generate_category_code_9_0_i32,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i32);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__code_info__set_forward_live_vars_3_0),
		mercury__code_gen__generate_category_code_9_0_i33,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i33);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r4 = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_category_code_9_0_i1052,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1052);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r10, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r10, (Integer) 0) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r10, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(2), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i24);
	r1 = (Integer) 1;
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_9_0_i35,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i35);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r4 = r2;
	MR_stackvar(4) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__code_gen__generate_entry_7_0),
		mercury__code_gen__generate_category_code_9_0_i36,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i36);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r5 = r3;
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Integer) 1;
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__code_gen__generate_exit_8_0),
		mercury__code_gen__generate_category_code_9_0_i37,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i37);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(6) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__generate_resume_point_4_0),
		mercury__code_gen__generate_category_code_9_0_i38,
		STATIC(mercury__code_gen__generate_category_code_9_0));
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i38);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = r3;
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i20);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = r5;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_category_code_9_0_i40,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i40);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__code_gen__generate_category_code_9_0_i41,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i41);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	if (((Integer) MR_stackvar(4) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i42);
	r4 = MR_stackvar(5);
	r3 = r1;
	MR_stackvar(5) = r1;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	MR_stackvar(6) = r2;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_category_code_9_0_i1065,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1065);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(7) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(1);
	r3 = r4;
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_9_0_i45,
		STATIC(mercury__code_gen__generate_category_code_9_0));
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i45);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r4 = r2;
	MR_stackvar(8) = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__code_gen__generate_entry_7_0),
		mercury__code_gen__generate_category_code_9_0_i46,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i46);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(9) = r2;
	r2 = r1;
	r5 = r3;
	MR_stackvar(1) = r1;
	r1 = (Integer) 2;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__code_gen__generate_exit_8_0),
		mercury__code_gen__generate_category_code_9_0_i47,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i47);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	MR_stackvar(10) = r2;
	r1 = MR_stackvar(2);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__generate_resume_point_4_0),
		mercury__code_gen__generate_category_code_9_0_i48,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i48);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__code_info__resume_point_vars_2_0),
		mercury__code_gen__generate_category_code_9_0_i49,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i49);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_1);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__code_gen__generate_category_code_9_0_i50,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i50);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__code_info__set_forward_live_vars_3_0),
		mercury__code_gen__generate_category_code_9_0_i51,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i51);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r4 = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_category_code_9_0_i52,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i52);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 2);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_category_code_9_0_i1073);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_code_gen__common_19);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i1073);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_code_gen__common_20);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(13);
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(4);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__code_gen__generate_category_code_9_0_i42);
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_category_code_9_0_i56,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i56);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r3 = MR_stackvar(2);
	r4 = r2;
	MR_stackvar(2) = r1;
	r1 = (Integer) 2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__code_gen__generate_entry_7_0),
		mercury__code_gen__generate_category_code_9_0_i57,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i57);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	r5 = r3;
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Integer) 2;
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__code_gen__generate_exit_8_0),
		mercury__code_gen__generate_category_code_9_0_i1079,
		STATIC(mercury__code_gen__generate_category_code_9_0));
Define_label(mercury__code_gen__generate_category_code_9_0_i1079);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_category_code_9_0));
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_category_code_9_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__get_stack_slots_3_0);
Declare_entry(mercury__code_info__get_varset_3_0);
Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
Declare_entry(mercury__code_info__get_pred_id_3_0);
Declare_entry(mercury__code_info__get_proc_id_3_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__code_info__get_succip_used_3_0);
Declare_entry(mercury__trace__generate_slot_fill_code_4_0);
Declare_entry(mercury__hlds_module__predicate_module_3_0);
Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__hlds_module__predicate_arity_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__code_info__resume_point_stack_addr_2_0);
Declare_entry(mercury__pragma_c_gen__struct_name_5_0);
Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(code_gen_module8)
	init_entry(mercury__code_gen__generate_entry_7_0);
	init_label(mercury__code_gen__generate_entry_7_0_i2);
	init_label(mercury__code_gen__generate_entry_7_0_i3);
	init_label(mercury__code_gen__generate_entry_7_0_i4);
	init_label(mercury__code_gen__generate_entry_7_0_i5);
	init_label(mercury__code_gen__generate_entry_7_0_i6);
	init_label(mercury__code_gen__generate_entry_7_0_i7);
	init_label(mercury__code_gen__generate_entry_7_0_i8);
	init_label(mercury__code_gen__generate_entry_7_0_i1073);
	init_label(mercury__code_gen__generate_entry_7_0_i10);
	init_label(mercury__code_gen__generate_entry_7_0_i12);
	init_label(mercury__code_gen__generate_entry_7_0_i17);
	init_label(mercury__code_gen__generate_entry_7_0_i20);
	init_label(mercury__code_gen__generate_entry_7_0_i18);
	init_label(mercury__code_gen__generate_entry_7_0_i21);
	init_label(mercury__code_gen__generate_entry_7_0_i22);
	init_label(mercury__code_gen__generate_entry_7_0_i23);
	init_label(mercury__code_gen__generate_entry_7_0_i24);
	init_label(mercury__code_gen__generate_entry_7_0_i25);
	init_label(mercury__code_gen__generate_entry_7_0_i26);
	init_label(mercury__code_gen__generate_entry_7_0_i27);
	init_label(mercury__code_gen__generate_entry_7_0_i30);
	init_label(mercury__code_gen__generate_entry_7_0_i34);
	init_label(mercury__code_gen__generate_entry_7_0_i35);
	init_label(mercury__code_gen__generate_entry_7_0_i31);
	init_label(mercury__code_gen__generate_entry_7_0_i28);
	init_label(mercury__code_gen__generate_entry_7_0_i1137);
BEGIN_CODE

/* code for predicate 'generate_entry'/7 in mode 0 */
Define_static(mercury__code_gen__generate_entry_7_0);
	MR_incr_sp_push_msg(20, "code_gen:generate_entry/7");
	MR_stackvar(20) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__code_gen__generate_entry_7_0_i2,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i2);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__code_gen__generate_entry_7_0_i3,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i3);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__code_gen__generate_entry_7_0_i4,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_22);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__code_gen__generate_entry_7_0_i5,
		STATIC(mercury__code_gen__generate_entry_7_0));
	}
Define_label(mercury__code_gen__generate_entry_7_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__code_gen__generate_entry_7_0_i6,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__code_gen__generate_entry_7_0_i7,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__code_gen__generate_entry_7_0_i8,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_gen__generate_entry_7_0_i1073,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i1073);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	tag_incr_hp_msg(MR_stackvar(10), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	r1 = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(10), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("Procedure entry point", 21);
	call_localret(ENTRY(mercury__code_info__get_succip_used_3_0),
		mercury__code_gen__generate_entry_7_0_i10,
		STATIC(mercury__code_gen__generate_entry_7_0));
	}
Define_label(mercury__code_gen__generate_entry_7_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i12);
	if (((Integer) MR_stackvar(1) == (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i12);
	r1 = ((Integer) MR_stackvar(6) + (Integer) 1);
	tag_incr_hp_msg(MR_stackvar(11), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__code_gen__generate_entry_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_23);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Save the success ip", 19);
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(11), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_stackvar(12) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	r3 = r1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_stackvar(13) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_entry_7_0_i17,
		STATIC(mercury__code_gen__generate_entry_7_0));
	}
Define_label(mercury__code_gen__generate_entry_7_0_i12);
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(12) = MR_stackvar(6);
	MR_stackvar(13) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_entry_7_0_i17,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i18);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__trace__generate_slot_fill_code_4_0),
		mercury__code_gen__generate_entry_7_0_i20,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i20);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(4) = r2;
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i21);
Define_label(mercury__code_gen__generate_entry_7_0_i18);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	MR_stackvar(14) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__code_gen__generate_entry_7_0_i21);
	MR_stackvar(7) = r2;
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__code_gen__generate_entry_7_0_i22,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i22);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_gen__generate_entry_7_0_i23,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i23);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__code_gen__generate_entry_7_0_i24,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i24);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(15);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__code_gen__generate_entry_7_0_i25,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i25);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(17);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__code_gen__generate_entry_7_0_i26,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i26);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(":", 1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__code_gen__generate_entry_7_0_i27,
		STATIC(mercury__code_gen__generate_entry_7_0));
	}
Define_label(mercury__code_gen__generate_entry_7_0_i27);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i28);
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__resume_point_stack_addr_2_0),
		mercury__code_gen__generate_entry_7_0_i30,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i31);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i31);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 7)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i31);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r1;
	r1 = MR_stackvar(15);
	MR_stackvar(15) = MR_tempr1;
	r2 = MR_stackvar(16);
	r3 = MR_stackvar(17);
	MR_tempr2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 7);
	MR_stackvar(17) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1);
	MR_stackvar(16) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__pragma_c_gen__struct_name_5_0),
		mercury__code_gen__generate_entry_7_0_i34,
		STATIC(mercury__code_gen__generate_entry_7_0));
	}
Define_label(mercury__code_gen__generate_entry_7_0_i34);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	r2 = MR_stackvar(16);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(17);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = (Word) MR_string_const("#define\tMR_ORDINARY_SLOTS\t%d\n", 29);
	MR_stackvar(16) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(12);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__code_gen__generate_entry_7_0_i35,
		STATIC(mercury__code_gen__generate_entry_7_0));
Define_label(mercury__code_gen__generate_entry_7_0_i35);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_entry_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__code_gen__generate_entry_7_0, "code_gen:frame_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 1;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 3, mercury__code_gen__generate_entry_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 3, mercury__code_gen__generate_entry_7_0, "llds:nondet_frame_info/0");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(18);
	MR_field(MR_mktag(1), r10, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), r9, (Integer) 2) = MR_stackvar(15);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("Allocate stack frame", 20);
	MR_field(MR_mktag(3), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r10, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 7, mercury__code_gen__generate_entry_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 18;
	MR_field(MR_mktag(3), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	MR_field(MR_mktag(3), r10, (Integer) 6) = (Integer) 0;
	MR_field(MR_mktag(3), r10, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r10, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r10, (Integer) 3) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(3), r10, (Integer) 2) = r11;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_27);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(20);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__code_gen__generate_entry_7_0_i31);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__code_gen__generate_entry_7_0, "code_gen:frame_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 3, mercury__code_gen__generate_entry_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r9, (Integer) 2) = r3;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 3, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(18);
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("Allocate stack frame", 20);
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_27);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(20);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__code_gen__generate_entry_7_0_i28);
	if (((Integer) MR_stackvar(12) <= (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_entry_7_0_i1137);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__code_gen__generate_entry_7_0, "code_gen:frame_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_entry_7_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_entry_7_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 16;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("Allocate stack frame", 20);
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_27);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(20);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__code_gen__generate_entry_7_0_i1137);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__code_gen__generate_entry_7_0, "code_gen:frame_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 0;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_entry_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_27);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(20);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(2), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__get_arginfo_3_0);
Declare_entry(mercury__code_info__get_headvars_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
Declare_entry(mercury__instmap__is_unreachable_1_0);
Declare_entry(mercury__code_info__setup_call_5_0);
Declare_entry(mercury__map__values_2_0);
Declare_entry(mercury__std_util__solutions_2_1);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__trace__maybe_setup_redo_event_2_0);

BEGIN_MODULE(code_gen_module9)
	init_entry(mercury__code_gen__generate_exit_8_0);
	init_label(mercury__code_gen__generate_exit_8_0_i2);
	init_label(mercury__code_gen__generate_exit_8_0_i4);
	init_label(mercury__code_gen__generate_exit_8_0_i5);
	init_label(mercury__code_gen__generate_exit_8_0_i6);
	init_label(mercury__code_gen__generate_exit_8_0_i7);
	init_label(mercury__code_gen__generate_exit_8_0_i10);
	init_label(mercury__code_gen__generate_exit_8_0_i8);
	init_label(mercury__code_gen__generate_exit_8_0_i12);
	init_label(mercury__code_gen__generate_exit_8_0_i13);
	init_label(mercury__code_gen__generate_exit_8_0_i14);
	init_label(mercury__code_gen__generate_exit_8_0_i16);
	init_label(mercury__code_gen__generate_exit_8_0_i19);
	init_label(mercury__code_gen__generate_exit_8_0_i1027);
	init_label(mercury__code_gen__generate_exit_8_0_i23);
	init_label(mercury__code_gen__generate_exit_8_0_i1035);
	init_label(mercury__code_gen__generate_exit_8_0_i30);
	init_label(mercury__code_gen__generate_exit_8_0_i33);
	init_label(mercury__code_gen__generate_exit_8_0_i34);
	init_label(mercury__code_gen__generate_exit_8_0_i35);
	init_label(mercury__code_gen__generate_exit_8_0_i31);
	init_label(mercury__code_gen__generate_exit_8_0_i37);
	init_label(mercury__code_gen__generate_exit_8_0_i38);
	init_label(mercury__code_gen__generate_exit_8_0_i39);
	init_label(mercury__code_gen__generate_exit_8_0_i41);
	init_label(mercury__code_gen__generate_exit_8_0_i43);
	init_label(mercury__code_gen__generate_exit_8_0_i42);
	init_label(mercury__code_gen__generate_exit_8_0_i46);
	init_label(mercury__code_gen__generate_exit_8_0_i44);
BEGIN_CODE

/* code for predicate 'generate_exit'/8 in mode 0 */
Define_static(mercury__code_gen__generate_exit_8_0);
	MR_incr_sp_push_msg(19, "code_gen:generate_exit/8");
	MR_stackvar(19) = (Word) MR_succip;
	r6 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r7 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r8 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_31);
	r9 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_35);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 2) != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_code_gen__common_43);
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__code_gen__generate_exit_8_0_i2);
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(6) = r9;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r7;
	MR_stackvar(9) = r6;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_exit_8_0_i4,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__code_gen__generate_exit_8_0_i5,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__code_gen__generate_exit_8_0_i6,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r3 = r1;
	MR_stackvar(17) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__code_gen__generate_exit_8_0_i7,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i7);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_exit_8_0_i10,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i8);
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = MR_stackvar(17);
	GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i13);
Define_label(mercury__code_gen__generate_exit_8_0_i8);
	r1 = MR_stackvar(10);
	r2 = (Integer) 1;
	r3 = MR_stackvar(17);
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__code_gen__generate_exit_8_0_i12,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i12);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(11) = r1;
	r1 = r2;
Define_label(mercury__code_gen__generate_exit_8_0_i13);
	if (((Integer) MR_stackvar(9) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i14);
	tag_incr_hp_msg(MR_stackvar(12), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__code_gen__generate_exit_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 1, mercury__code_gen__generate_exit_8_0, "llds:rval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_stackvar(9), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("restore the success ip", 22);
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	MR_field(MR_mktag(1), MR_stackvar(12), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i16);
	}
Define_label(mercury__code_gen__generate_exit_8_0_i14);
	MR_stackvar(12) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__code_gen__generate_exit_8_0_i16);
	if (((Integer) MR_stackvar(8) == (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i19);
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i1027);
Define_label(mercury__code_gen__generate_exit_8_0_i19);
	MR_stackvar(13) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i23);
Define_label(mercury__code_gen__generate_exit_8_0_i1027);
	tag_incr_hp_msg(MR_stackvar(13), MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 17;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("Deallocate stack frame", 22);
	MR_field(MR_mktag(1), MR_stackvar(13), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	}
Define_label(mercury__code_gen__generate_exit_8_0_i23);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i1035);
	if (((Integer) MR_stackvar(1) == (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i1035);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(12);
	MR_stackvar(4) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(2), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_14);
	MR_field(MR_mktag(2), MR_stackvar(4), (Integer) 1) = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_exit_8_0_i30,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i1035);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(12);
	MR_stackvar(4) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(2), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(2), MR_stackvar(4), (Integer) 1) = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__code_gen__generate_exit_8_0_i30,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i30);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i31);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(14) = r1;
	r1 = (Integer) 1;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__trace__generate_external_event_code_8_0),
		mercury__code_gen__generate_exit_8_0_i33,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i33);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(15) = r3;
	r3 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_44);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_0);
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__code_gen__generate_exit_8_0_i34,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i34);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__code_gen__generate_exit_8_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_47);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__code_gen__IntroducedFrom__pred__generate_exit__742__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__code_gen__generate_exit_8_0_i35,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i35);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 1;
	call_localret(STATIC(mercury__code_gen__select_args_with_mode_4_0),
		mercury__code_gen__generate_exit_8_0_i37,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i31);
	MR_stackvar(5) = r2;
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 1;
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(16) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__code_gen__select_args_with_mode_4_0),
		mercury__code_gen__generate_exit_8_0_i37,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i37);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r3 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__code_gen__generate_exit_8_0_i38,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i38);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__code_gen__generate_exit_8_0_i39,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i39);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i41);
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = r1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r10, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_11);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
Define_label(mercury__code_gen__generate_exit_8_0_i41);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i42);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_5);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__code_gen__generate_exit_8_0_i43,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i43);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = r1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_50);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r11, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_11);
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
Define_label(mercury__code_gen__generate_exit_8_0_i42);
	if (((Integer) MR_stackvar(14) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_exit_8_0_i44);
	r2 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__trace__maybe_setup_redo_event_2_0),
		mercury__code_gen__generate_exit_8_0_i46,
		STATIC(mercury__code_gen__generate_exit_8_0));
Define_label(mercury__code_gen__generate_exit_8_0_i46);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_exit_8_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = r3;
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r10, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_54);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
Define_label(mercury__code_gen__generate_exit_8_0_i44);
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__code_gen__generate_exit_8_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__code_gen__generate_exit_8_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__code_gen__generate_exit_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__generate_exit_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r10, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_gen__common_54);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
END_MODULE

Declare_entry(mercury__call_gen__generate_call_8_0);
Declare_entry(mercury__call_gen__generate_builtin_7_0);
Declare_entry(mercury__call_gen__generate_generic_call_9_0);
Declare_entry(mercury__switch_gen__generate_switch_9_0);
Declare_entry(mercury__unify_gen__generate_unification_5_0);
Declare_entry(mercury__disj_gen__generate_disj_6_0);
Declare_entry(mercury__ite_gen__generate_negation_5_0);
Declare_entry(mercury__commit_gen__generate_commit_5_0);
Declare_entry(mercury__ite_gen__generate_ite_8_0);
Declare_entry(mercury__pragma_c_gen__generate_pragma_c_code_12_0);
Declare_entry(mercury__par_conj_gen__generate_par_conj_6_0);

BEGIN_MODULE(code_gen_module10)
	init_entry(mercury__code_gen__generate_goal_2_6_0);
	init_label(mercury__code_gen__generate_goal_2_6_0_i1002);
	init_label(mercury__code_gen__generate_goal_2_6_0_i6);
	init_label(mercury__code_gen__generate_goal_2_6_0_i7);
	init_label(mercury__code_gen__generate_goal_2_6_0_i1004);
	init_label(mercury__code_gen__generate_goal_2_6_0_i14);
	init_label(mercury__code_gen__generate_goal_2_6_0_i15);
	init_label(mercury__code_gen__generate_goal_2_6_0_i17);
	init_label(mercury__code_gen__generate_goal_2_6_0_i19);
	init_label(mercury__code_gen__generate_goal_2_6_0_i21);
	init_label(mercury__code_gen__generate_goal_2_6_0_i23);
	init_label(mercury__code_gen__generate_goal_2_6_0_i25);
	init_label(mercury__code_gen__generate_goal_2_6_0_i27);
	init_label(mercury__code_gen__generate_goal_2_6_0_i29);
	init_label(mercury__code_gen__generate_goal_2_6_0_i31);
	init_label(mercury__code_gen__generate_goal_2_6_0_i32);
BEGIN_CODE

/* code for predicate 'generate_goal_2'/6 in mode 0 */
Define_static(mercury__code_gen__generate_goal_2_6_0);
	MR_incr_sp_push_msg(2, "code_gen:generate_goal_2/6");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_gen__generate_goal_2_6_0_i1002) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i6) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i1004) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i14));
Define_label(mercury__code_gen__generate_goal_2_6_0_i1002);
	r2 = r3;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r3 = r4;
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__code_gen__generate_goals_5_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i6);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) 2))
		GOTO_LABEL(mercury__code_gen__generate_goal_2_6_0_i7);
	r1 = r3;
	r3 = r6;
	r6 = r4;
	r4 = r5;
	r5 = r2;
	r2 = r7;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__call_gen__generate_call_8_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i7);
	{
	Word MR_tempr1;
	MR_tempr1 = r4;
	r4 = r5;
	r5 = MR_tempr1;
	r1 = r3;
	r2 = r7;
	r3 = r6;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__call_gen__generate_builtin_7_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i1004);
	r6 = r2;
	r7 = r4;
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r5 = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r3;
	r3 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 1);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__call_gen__generate_generic_call_9_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_gen__generate_goal_2_6_0_i15) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i17) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i19) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i21) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i23) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i25) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i27) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i29) AND
		LABEL(mercury__code_gen__generate_goal_2_6_0_i31));
Define_label(mercury__code_gen__generate_goal_2_6_0_i15);
	r6 = r2;
	r7 = r4;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r3;
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__switch_gen__generate_switch_9_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i17);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__unify_gen__generate_unification_5_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i19);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r3;
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__disj_gen__generate_disj_6_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i21);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__ite_gen__generate_negation_5_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i23);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__commit_gen__generate_commit_5_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i25);
	r6 = r4;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r3;
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__ite_gen__generate_ite_8_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i27);
	r8 = r2;
	r10 = r4;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r6 = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r7 = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	r9 = MR_const_field(MR_mktag(3), r1, (Integer) 7);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r3;
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__pragma_c_gen__generate_pragma_c_code_12_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
	}
Define_label(mercury__code_gen__generate_goal_2_6_0_i29);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__par_conj_gen__generate_par_conj_6_0),
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i31);
	MR_stackvar(1) = r4;
	r1 = (Word) MR_string_const("code_gen__generate_goal_2: unexpected bi_implication", 52);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_gen__generate_goal_2_6_0_i32,
		STATIC(mercury__code_gen__generate_goal_2_6_0));
Define_label(mercury__code_gen__generate_goal_2_6_0_i32);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goal_2_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_gen_module11)
	init_entry(mercury__code_gen__generate_goals_5_0);
	init_label(mercury__code_gen__generate_goals_5_0_i3);
	init_label(mercury__code_gen__generate_goals_5_0_i4);
	init_label(mercury__code_gen__generate_goals_5_0_i5);
	init_label(mercury__code_gen__generate_goals_5_0_i8);
	init_label(mercury__code_gen__generate_goals_5_0_i6);
	init_label(mercury__code_gen__generate_goals_5_0_i10);
BEGIN_CODE

/* code for predicate 'generate_goals'/5 in mode 0 */
Define_static(mercury__code_gen__generate_goals_5_0);
	MR_incr_sp_push_msg(5, "code_gen:generate_goals/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__generate_goals_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_goals_5_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__code_gen__generate_goal_5_0),
		mercury__code_gen__generate_goals_5_0_i4,
		STATIC(mercury__code_gen__generate_goals_5_0));
	}
Define_label(mercury__code_gen__generate_goals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__code_gen__generate_goals_5_0_i5,
		STATIC(mercury__code_gen__generate_goals_5_0));
Define_label(mercury__code_gen__generate_goals_5_0_i5);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__code_gen__generate_goals_5_0_i8,
		STATIC(mercury__code_gen__generate_goals_5_0));
Define_label(mercury__code_gen__generate_goals_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_gen__generate_goals_5_0_i6);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_gen__generate_goals_5_0_i6);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	localcall(mercury__code_gen__generate_goals_5_0,
		LABEL(mercury__code_gen__generate_goals_5_0_i10),
		STATIC(mercury__code_gen__generate_goals_5_0));
Define_label(mercury__code_gen__generate_goals_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_gen__generate_goals_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__code_gen__generate_goals_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__code_util__arg_loc_to_register_2_0);

BEGIN_MODULE(code_gen_module12)
	init_entry(mercury__code_gen__select_args_with_mode_4_0);
	init_label(mercury__code_gen__select_args_with_mode_4_0_i4);
	init_label(mercury__code_gen__select_args_with_mode_4_0_i6);
	init_label(mercury__code_gen__select_args_with_mode_4_0_i3);
	init_label(mercury__code_gen__select_args_with_mode_4_0_i2);
BEGIN_CODE

/* code for predicate 'select_args_with_mode'/4 in mode 0 */
Define_static(mercury__code_gen__select_args_with_mode_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__select_args_with_mode_4_0_i3);
	MR_incr_sp_push_msg(4, "code_gen:select_args_with_mode/4");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	localcall(mercury__code_gen__select_args_with_mode_4_0,
		LABEL(mercury__code_gen__select_args_with_mode_4_0_i4),
		STATIC(mercury__code_gen__select_args_with_mode_4_0));
Define_label(mercury__code_gen__select_args_with_mode_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_gen__select_args_with_mode_4_0));
	if ((MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 1) != MR_stackvar(1)))
		GOTO_LABEL(mercury__code_gen__select_args_with_mode_4_0_i2);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_util__arg_loc_to_register_2_0),
		mercury__code_gen__select_args_with_mode_4_0_i6,
		STATIC(mercury__code_gen__select_args_with_mode_4_0));
Define_label(mercury__code_gen__select_args_with_mode_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_gen__select_args_with_mode_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_gen__select_args_with_mode_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_gen__select_args_with_mode_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_gen__select_args_with_mode_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__code_gen__select_args_with_mode_4_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(code_gen_module13)
	init_entry(mercury__code_gen__add_saved_succip_3_0);
	init_label(mercury__code_gen__add_saved_succip_3_0_i7);
	init_label(mercury__code_gen__add_saved_succip_3_0_i11);
	init_label(mercury__code_gen__add_saved_succip_3_0_i5);
	init_label(mercury__code_gen__add_saved_succip_3_0_i14);
	init_label(mercury__code_gen__add_saved_succip_3_0_i12);
	init_label(mercury__code_gen__add_saved_succip_3_0_i17);
	init_label(mercury__code_gen__add_saved_succip_3_0_i3);
BEGIN_CODE

/* code for predicate 'add_saved_succip'/3 in mode 0 */
Define_static(mercury__code_gen__add_saved_succip_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i3);
	MR_incr_sp_push_msg(9, "code_gen:add_saved_succip/3");
	MR_stackvar(9) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i5);
	r7 = MR_const_field(MR_mktag(2), r6, (Integer) 0);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i7);
	r8 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 0);
	if ((MR_tag(r8) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r8, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r8, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i5);
Define_label(mercury__code_gen__add_saved_succip_3_0_i7);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = r7;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r4;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__code_gen__add_saved_succip_3_0_i11,
		STATIC(mercury__code_gen__add_saved_succip_3_0));
Define_label(mercury__code_gen__add_saved_succip_3_0_i11);
	update_prof_current_proc(LABEL(mercury__code_gen__add_saved_succip_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(0), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__code_gen__add_saved_succip_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 1) = MR_stackvar(3);
	localcall(mercury__code_gen__add_saved_succip_3_0,
		LABEL(mercury__code_gen__add_saved_succip_3_0_i17),
		STATIC(mercury__code_gen__add_saved_succip_3_0));
	}
Define_label(mercury__code_gen__add_saved_succip_3_0_i5);
	if ((MR_tag(r6) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i12);
	if (((Integer) MR_const_field(MR_mktag(3), r6, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__code_gen__add_saved_succip_3_0_i12);
	MR_stackvar(1) = r2;
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r6, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r6, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r6, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r6, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r6, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_44);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_gen__common_0);
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__code_gen__add_saved_succip_3_0_i14,
		STATIC(mercury__code_gen__add_saved_succip_3_0));
Define_label(mercury__code_gen__add_saved_succip_3_0_i14);
	update_prof_current_proc(LABEL(mercury__code_gen__add_saved_succip_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(0), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 6, mercury__code_gen__add_saved_succip_3_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_stackvar(5);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 3, mercury__code_gen__add_saved_succip_3_0, "llds:liveinfo/0");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 1, mercury__code_gen__add_saved_succip_3_0, "llds:layout_locn/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r5, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(3), r5, (Integer) 4) = r4;
	MR_field(MR_mktag(3), r5, (Integer) 3) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 0) = r5;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 2) = r3;
	localcall(mercury__code_gen__add_saved_succip_3_0,
		LABEL(mercury__code_gen__add_saved_succip_3_0_i17),
		STATIC(mercury__code_gen__add_saved_succip_3_0));
	}
Define_label(mercury__code_gen__add_saved_succip_3_0_i12);
	r1 = r4;
	MR_stackvar(6) = r3;
	localcall(mercury__code_gen__add_saved_succip_3_0,
		LABEL(mercury__code_gen__add_saved_succip_3_0_i17),
		STATIC(mercury__code_gen__add_saved_succip_3_0));
Define_label(mercury__code_gen__add_saved_succip_3_0_i17);
	update_prof_current_proc(LABEL(mercury__code_gen__add_saved_succip_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_gen__add_saved_succip_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__code_gen__add_saved_succip_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__maybe_1_0);

BEGIN_MODULE(code_gen_module14)
	init_entry(mercury____Unify___code_gen__frame_info_0_0);
	init_label(mercury____Unify___code_gen__frame_info_0_0_i2);
	init_label(mercury____Unify___code_gen__frame_info_0_0_i1004);
	init_label(mercury____Unify___code_gen__frame_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___code_gen__frame_info_0_0);
	MR_incr_sp_push_msg(3, "code_gen:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___code_gen__frame_info_0_0_i1004);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___code_gen__frame_info_0_0_i2,
		STATIC(mercury____Unify___code_gen__frame_info_0_0));
Define_label(mercury____Unify___code_gen__frame_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___code_gen__frame_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___code_gen__frame_info_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___code_gen__frame_info_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___code_gen__frame_info_0_0_i1004);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___code_gen__frame_info_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(code_gen_module15)
	init_entry(mercury____Index___code_gen__frame_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___code_gen__frame_info_0_0);
	tailcall(STATIC(mercury____Index___code_gen__frame_info_0__ua0_2_0),
		STATIC(mercury____Index___code_gen__frame_info_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);

BEGIN_MODULE(code_gen_module16)
	init_entry(mercury____Compare___code_gen__frame_info_0_0);
	init_label(mercury____Compare___code_gen__frame_info_0_0_i3);
	init_label(mercury____Compare___code_gen__frame_info_0_0_i7);
	init_label(mercury____Compare___code_gen__frame_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___code_gen__frame_info_0_0);
	MR_incr_sp_push_msg(5, "code_gen:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___code_gen__frame_info_0_0_i3,
		STATIC(mercury____Compare___code_gen__frame_info_0_0));
Define_label(mercury____Compare___code_gen__frame_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___code_gen__frame_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___code_gen__frame_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___code_gen__frame_info_0_0_i7,
		STATIC(mercury____Compare___code_gen__frame_info_0_0));
Define_label(mercury____Compare___code_gen__frame_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___code_gen__frame_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___code_gen__frame_info_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___code_gen__frame_info_0_0));
Define_label(mercury____Compare___code_gen__frame_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__code_gen_maybe_bunch_0(void)
{
	code_gen_module0();
	code_gen_module1();
	code_gen_module2();
	code_gen_module3();
	code_gen_module4();
	code_gen_module5();
	code_gen_module6();
	code_gen_module7();
	code_gen_module8();
	code_gen_module9();
	code_gen_module10();
	code_gen_module11();
	code_gen_module12();
	code_gen_module13();
	code_gen_module14();
	code_gen_module15();
	code_gen_module16();
}

#endif

void mercury__code_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__code_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__code_gen_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_code_gen__type_ctor_info_frame_info_0,
			code_gen__frame_info_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
