/*
** Automatically generated from `code_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__code_util__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__code_util__make_entry_label_5_0);
Declare_label(mercury__code_util__make_entry_label_5_0_i2);
Declare_label(mercury__code_util__make_entry_label_5_0_i3);
Declare_label(mercury__code_util__make_entry_label_5_0_i9);
Declare_label(mercury__code_util__make_entry_label_5_0_i7);
Declare_label(mercury__code_util__make_entry_label_5_0_i11);
Declare_label(mercury__code_util__make_entry_label_5_0_i13);
Declare_label(mercury__code_util__make_entry_label_5_0_i14);
Declare_label(mercury__code_util__make_entry_label_5_0_i16);
Declare_label(mercury__code_util__make_entry_label_5_0_i5);
Declare_label(mercury__code_util__make_entry_label_5_0_i17);
Define_extern_entry(mercury__code_util__make_local_entry_label_5_0);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i2);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i3);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i4);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i7);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i10);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i16);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i18);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i1018);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i6);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i1019);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i22);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i28);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i30);
Declare_label(mercury__code_util__make_local_entry_label_5_0_i1022);
Define_extern_entry(mercury__code_util__make_internal_label_5_0);
Declare_label(mercury__code_util__make_internal_label_5_0_i2);
Define_extern_entry(mercury__code_util__make_proc_label_4_0);
Declare_label(mercury__code_util__make_proc_label_4_0_i2);
Declare_label(mercury__code_util__make_proc_label_4_0_i3);
Declare_label(mercury__code_util__make_proc_label_4_0_i4);
Declare_label(mercury__code_util__make_proc_label_4_0_i5);
Declare_label(mercury__code_util__make_proc_label_4_0_i7);
Declare_label(mercury__code_util__make_proc_label_4_0_i8);
Declare_label(mercury__code_util__make_proc_label_4_0_i9);
Declare_label(mercury__code_util__make_proc_label_4_0_i11);
Declare_label(mercury__code_util__make_proc_label_4_0_i13);
Declare_label(mercury__code_util__make_proc_label_4_0_i15);
Declare_label(mercury__code_util__make_proc_label_4_0_i22);
Declare_label(mercury__code_util__make_proc_label_4_0_i26);
Declare_label(mercury__code_util__make_proc_label_4_0_i27);
Declare_label(mercury__code_util__make_proc_label_4_0_i18);
Declare_label(mercury__code_util__make_proc_label_4_0_i19);
Declare_label(mercury__code_util__make_proc_label_4_0_i1017);
Declare_label(mercury__code_util__make_proc_label_4_0_i30);
Declare_label(mercury__code_util__make_proc_label_4_0_i6);
Declare_label(mercury__code_util__make_proc_label_4_0_i37);
Declare_label(mercury__code_util__make_proc_label_4_0_i41);
Declare_label(mercury__code_util__make_proc_label_4_0_i34);
Declare_label(mercury__code_util__make_proc_label_4_0_i43);
Declare_label(mercury__code_util__make_proc_label_4_0_i44);
Declare_label(mercury__code_util__make_proc_label_4_0_i45);
Define_extern_entry(mercury__code_util__make_uni_label_4_0);
Declare_label(mercury__code_util__make_uni_label_4_0_i2);
Declare_label(mercury__code_util__make_uni_label_4_0_i6);
Declare_label(mercury__code_util__make_uni_label_4_0_i7);
Declare_label(mercury__code_util__make_uni_label_4_0_i1005);
Declare_label(mercury__code_util__make_uni_label_4_0_i3);
Define_extern_entry(mercury__code_util__extract_proc_label_from_code_addr_2_0);
Declare_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i4);
Declare_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i2);
Define_extern_entry(mercury__code_util__extract_proc_label_from_label_2_0);
Define_extern_entry(mercury__code_util__arg_loc_to_register_2_0);
Define_extern_entry(mercury__code_util__goal_may_allocate_heap_1_0);
Define_extern_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1002);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i5);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
Declare_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1);
Define_extern_entry(mercury__code_util__neg_rval_2_0);
Declare_label(mercury__code_util__neg_rval_2_0_i6);
Declare_label(mercury__code_util__neg_rval_2_0_i8);
Declare_label(mercury__code_util__neg_rval_2_0_i10);
Declare_label(mercury__code_util__neg_rval_2_0_i12);
Declare_label(mercury__code_util__neg_rval_2_0_i26);
Declare_label(mercury__code_util__neg_rval_2_0_i27);
Declare_label(mercury__code_util__neg_rval_2_0_i29);
Declare_label(mercury__code_util__neg_rval_2_0_i30);
Declare_label(mercury__code_util__neg_rval_2_0_i31);
Declare_label(mercury__code_util__neg_rval_2_0_i32);
Declare_label(mercury__code_util__neg_rval_2_0_i33);
Declare_label(mercury__code_util__neg_rval_2_0_i34);
Declare_label(mercury__code_util__neg_rval_2_0_i35);
Declare_label(mercury__code_util__neg_rval_2_0_i36);
Declare_label(mercury__code_util__neg_rval_2_0_i37);
Declare_label(mercury__code_util__neg_rval_2_0_i38);
Declare_label(mercury__code_util__neg_rval_2_0_i43);
Declare_label(mercury__code_util__neg_rval_2_0_i44);
Declare_label(mercury__code_util__neg_rval_2_0_i45);
Declare_label(mercury__code_util__neg_rval_2_0_i46);
Declare_label(mercury__code_util__neg_rval_2_0_i47);
Declare_label(mercury__code_util__neg_rval_2_0_i48);
Declare_label(mercury__code_util__neg_rval_2_0_i2);
Define_extern_entry(mercury__code_util__negate_the_test_2_0);
Declare_label(mercury__code_util__negate_the_test_2_0_i3);
Declare_label(mercury__code_util__negate_the_test_2_0_i7);
Declare_label(mercury__code_util__negate_the_test_2_0_i5);
Declare_label(mercury__code_util__negate_the_test_2_0_i8);
Define_extern_entry(mercury__code_util__compiler_generated_1_0);
Declare_label(mercury__code_util__compiler_generated_1_0_i2);
Declare_label(mercury__code_util__compiler_generated_1_0_i3);
Define_extern_entry(mercury__code_util__predinfo_is_builtin_1_0);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i2);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i3);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i4);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i5);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i6);
Declare_label(mercury__code_util__predinfo_is_builtin_1_0_i1);
Define_extern_entry(mercury__code_util__builtin_state_4_0);
Declare_label(mercury__code_util__builtin_state_4_0_i2);
Declare_label(mercury__code_util__builtin_state_4_0_i3);
Declare_label(mercury__code_util__builtin_state_4_0_i4);
Declare_label(mercury__code_util__builtin_state_4_0_i5);
Declare_label(mercury__code_util__builtin_state_4_0_i8);
Declare_label(mercury__code_util__builtin_state_4_0_i9);
Declare_label(mercury__code_util__builtin_state_4_0_i11);
Declare_label(mercury__code_util__builtin_state_4_0_i7);
Define_extern_entry(mercury__code_util__translate_builtin_6_0);
Declare_label(mercury__code_util__translate_builtin_6_0_i2);
Declare_label(mercury__code_util__translate_builtin_6_0_i1);
Define_extern_entry(mercury__code_util__cons_id_to_tag_4_0);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i4);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i12);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i14);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i5);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i6);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i17);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i15);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i19);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i21);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i22);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i23);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i24);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i26);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i30);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i31);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i32);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i33);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i34);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i35);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i36);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i37);
Declare_label(mercury__code_util__cons_id_to_tag_4_0_i38);
Define_extern_entry(mercury__code_util__cannot_stack_flush_1_0);
Define_extern_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i9);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1);
Define_extern_entry(mercury__code_util__count_recursive_calls_5_0);
Define_extern_entry(mercury__code_util__output_args_2_0);
Declare_label(mercury__code_util__output_args_2_0_i4);
Declare_label(mercury__code_util__output_args_2_0_i3);
Declare_label(mercury__code_util__output_args_2_0_i2);
Define_extern_entry(mercury__code_util__lvals_in_rval_2_0);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i4);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i5);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i8);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i11);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i12);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i14);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i15);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i16);
Declare_label(mercury__code_util__lvals_in_rval_2_0_i18);
Define_extern_entry(mercury__code_util__lvals_in_lval_2_0);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i12);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i25);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i26);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i27);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i29);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i1003);
Declare_label(mercury__code_util__lvals_in_lval_2_0_i31);
Declare_static(mercury__code_util__translate_builtin_2_6_0);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i5);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i11);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i1085);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i13);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i14);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i17);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i20);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i23);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i27);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i28);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i30);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i34);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i35);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i37);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i40);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i43);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i47);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i45);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i49);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i55);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i59);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i60);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i62);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i66);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i64);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i68);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i74);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i78);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i79);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i81);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i84);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i88);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i89);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i91);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i95);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i96);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i98);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i101);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i9);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i106);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i1312);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i1075);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i108);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i109);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i112);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i115);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i118);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i122);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i126);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i130);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i134);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i138);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i139);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i141);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i145);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i149);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i153);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i157);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i161);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i164);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i168);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i172);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i173);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i175);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i178);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i182);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i183);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i185);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i189);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i187);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i191);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i197);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i201);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i202);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i204);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i208);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i206);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i210);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i216);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i219);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i223);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i227);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i231);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i235);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i236);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i238);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i241);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i244);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i248);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i249);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i104);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i255);
Declare_label(mercury__code_util__translate_builtin_2_6_0_i256);
Declare_static(mercury__code_util__goal_may_allocate_heap_2_1_0);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i4);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i7);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i11);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i12);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i15);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i18);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i21);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i27);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i30);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i33);
Declare_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
Declare_static(mercury__code_util__cases_may_allocate_heap_1_0);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i1002);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i5);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
Declare_label(mercury__code_util__cases_may_allocate_heap_1_0_i1);
Declare_static(mercury__code_util__cannot_stack_flush_2_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i11);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i4);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i5);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1004);
Declare_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
Declare_static(mercury__code_util__cannot_stack_flush_goals_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1002);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i2);
Declare_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
Declare_static(mercury__code_util__cannot_stack_flush_cases_1_0);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1002);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i2);
Declare_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
Declare_static(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i7);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i5);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i11);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i12);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i2);
Declare_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
Declare_static(mercury__code_util__count_recursive_calls_2_5_0);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i1003);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i6);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i8);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i10);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i14);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i15);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i18);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i20);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i22);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i24);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i25);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i26);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i27);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i28);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i1005);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i30);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i31);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i33);
Declare_label(mercury__code_util__count_recursive_calls_2_5_0_i34);
Declare_static(mercury__code_util__count_recursive_calls_conj_7_0);
Declare_label(mercury__code_util__count_recursive_calls_conj_7_0_i1001);
Declare_label(mercury__code_util__count_recursive_calls_conj_7_0_i4);
Declare_label(mercury__code_util__count_recursive_calls_conj_7_0_i3);
Declare_static(mercury__code_util__count_recursive_calls_disj_5_0);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i1003);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i4);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i7);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i8);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i9);
Declare_label(mercury__code_util__count_recursive_calls_disj_5_0_i10);
Declare_static(mercury__code_util__count_recursive_calls_cases_5_0);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i1003);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i5);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i8);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i9);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i10);
Declare_label(mercury__code_util__count_recursive_calls_cases_5_0_i11);
Declare_static(mercury__code_util__lvals_in_mem_ref_2_0);
Declare_label(mercury__code_util__lvals_in_mem_ref_2_0_i1001);
Declare_label(mercury__code_util__lvals_in_mem_ref_2_0_i5);

static const struct mercury_data_code_util__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_code_util__common_0;

static const struct mercury_data_code_util__common_1_struct {
	String f1;
	Word * f2;
}  mercury_data_code_util__common_1;

static const struct mercury_data_code_util__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_util__common_2;

static const struct mercury_data_code_util__common_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_util__common_3;

static const struct mercury_data_code_util__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_code_util__common_4;

static const struct mercury_data_code_util__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	Integer f8;
	String f9;
	Integer f10;
	String f11;
	String f12;
	String f13;
	Integer f14;
	String f15;
	Integer f16;
	Integer f17;
	Integer f18;
	String f19;
	Integer f20;
	Integer f21;
	Integer f22;
	String f23;
	Integer f24;
	Integer f25;
	String f26;
	Integer f27;
	Integer f28;
	Integer f29;
	String f30;
	Integer f31;
	String f32;
}  mercury_data_code_util__common_5;

static const struct mercury_data_code_util__common_6_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_code_util__common_6;

static const struct mercury_data_code_util__common_7_struct {
	Word * f1;
}  mercury_data_code_util__common_7;

static const struct mercury_data_code_util__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_util__common_8;

static const struct mercury_data_code_util__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	Integer f5;
	Integer f6;
	String f7;
	Integer f8;
	String f9;
	String f10;
	Integer f11;
	Integer f12;
	Integer f13;
	String f14;
	String f15;
	Integer f16;
	Integer f17;
	String f18;
	String f19;
	String f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	String f26;
	String f27;
	Integer f28;
	Integer f29;
	String f30;
	Integer f31;
	String f32;
	Integer f33;
	Integer f34;
	String f35;
	String f36;
	Integer f37;
	Integer f38;
	Integer f39;
	Integer f40;
	String f41;
	Integer f42;
	String f43;
	String f44;
	String f45;
	Integer f46;
	Integer f47;
	String f48;
	Integer f49;
	String f50;
	Integer f51;
	String f52;
	String f53;
	String f54;
	Integer f55;
	Integer f56;
	String f57;
	Integer f58;
	Integer f59;
	Integer f60;
	Integer f61;
	String f62;
	Integer f63;
	String f64;
}  mercury_data_code_util__common_9;

static const struct mercury_data_code_util__common_10_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
	Integer f33;
	Integer f34;
	Integer f35;
	Integer f36;
	Integer f37;
	Integer f38;
	Integer f39;
	Integer f40;
	Integer f41;
	Integer f42;
	Integer f43;
	Integer f44;
	Integer f45;
	Integer f46;
	Integer f47;
	Integer f48;
	Integer f49;
	Integer f50;
	Integer f51;
	Integer f52;
	Integer f53;
	Integer f54;
	Integer f55;
	Integer f56;
	Integer f57;
	Integer f58;
	Integer f59;
	Integer f60;
	Integer f61;
	Integer f62;
	Integer f63;
	Integer f64;
}  mercury_data_code_util__common_10;

static const struct mercury_data_code_util__common_11_struct {
	Integer f1;
}  mercury_data_code_util__common_11;

static const struct mercury_data_code_util__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_code_util__common_12;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_code_util__common_0_struct mercury_data_code_util__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_code_util__common_1_struct mercury_data_code_util__common_1 = {
	MR_string_const("'", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_code_util__common_2_struct mercury_data_code_util__common_2 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_code_util__common_3_struct mercury_data_code_util__common_3 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_code_util__common_4_struct mercury_data_code_util__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_code_util__common_5_struct mercury_data_code_util__common_5 = {
	(Integer) 0,
	MR_string_const(">=", 2),
	MR_string_const("=<", 2),
	MR_string_const("builtin_float_ge", 16),
	MR_string_const("builtin_float_times", 19),
	MR_string_const("/", 1),
	MR_string_const("builtin_float_lt", 16),
	(Integer) 0,
	MR_string_const("builtin_float_le", 16),
	(Integer) 0,
	MR_string_const("+", 1),
	MR_string_const("*", 1),
	MR_string_const("-", 1),
	(Integer) 0,
	MR_string_const("builtin_float_minus", 19),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_float_gt", 16),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_float_divide", 20),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_float_plus", 18),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("<", 1),
	(Integer) 0,
	MR_string_const(">", 1)
};

static const struct mercury_data_code_util__common_6_struct mercury_data_code_util__common_6 = {
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) 2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) 5,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) 6,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1
};

static const Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_code_util__common_7_struct mercury_data_code_util__common_7 = {
	(Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_code_util__common_8_struct mercury_data_code_util__common_8 = {
	(Integer) 1,
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_code_util__common_7)
};

static const struct mercury_data_code_util__common_9_struct mercury_data_code_util__common_9 = {
	(Integer) 0,
	MR_string_const(">=", 2),
	MR_string_const("<", 1),
	MR_string_const(">", 1),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("xor", 3),
	(Integer) 0,
	MR_string_const("builtin_left_shift", 18),
	MR_string_const("unchecked_right_shift", 21),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_bit_or", 14),
	MR_string_const("builtin_div", 11),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("/\\", 2),
	MR_string_const("builtin_right_shift", 19),
	MR_string_const("builtin_mod", 11),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("rem", 3),
	MR_string_const("builtin_bit_and", 15),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("\\", 1),
	(Integer) 0,
	MR_string_const("^", 1),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("//", 2),
	MR_string_const("=<", 2),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_plus", 12),
	(Integer) 0,
	MR_string_const("+", 1),
	MR_string_const("*", 1),
	MR_string_const("-", 1),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_unary_minus", 19),
	(Integer) 0,
	MR_string_const("\\/", 2),
	(Integer) 0,
	MR_string_const("unchecked_left_shift", 20),
	MR_string_const("builtin_bit_xor", 15),
	MR_string_const("builtin_times", 13),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_unary_plus", 18),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("builtin_bit_neg", 15),
	(Integer) 0,
	MR_string_const("builtin_minus", 13)
};

static const struct mercury_data_code_util__common_10_struct mercury_data_code_util__common_10 = {
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 2,
	(Integer) -2,
	(Integer) 3
};

static const struct mercury_data_code_util__common_11_struct mercury_data_code_util__common_11 = {
	(Integer) 0
};

static const struct mercury_data_code_util__common_12_struct mercury_data_code_util__common_12 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_util__common_11)
};

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
Declare_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
Declare_entry(mercury__hlds_pred__in_in_unification_proc_id_1_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);

BEGIN_MODULE(code_util_module0)
	init_entry(mercury__code_util__make_entry_label_5_0);
	init_label(mercury__code_util__make_entry_label_5_0_i2);
	init_label(mercury__code_util__make_entry_label_5_0_i3);
	init_label(mercury__code_util__make_entry_label_5_0_i9);
	init_label(mercury__code_util__make_entry_label_5_0_i7);
	init_label(mercury__code_util__make_entry_label_5_0_i11);
	init_label(mercury__code_util__make_entry_label_5_0_i13);
	init_label(mercury__code_util__make_entry_label_5_0_i14);
	init_label(mercury__code_util__make_entry_label_5_0_i16);
	init_label(mercury__code_util__make_entry_label_5_0_i5);
	init_label(mercury__code_util__make_entry_label_5_0_i17);
BEGIN_CODE

/* code for predicate 'make_entry_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_entry_label_5_0);
	MR_incr_sp_push_msg(6, "code_util:make_entry_label/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_util__make_entry_label_5_0_i2,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__code_util__make_entry_label_5_0_i3,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__code_util__make_entry_label_5_0_i9,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_entry_label_5_0_i16,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i7);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0),
		mercury__code_util__make_entry_label_5_0_i11,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i5);
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__code_util__make_entry_label_5_0_i13,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i13);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__make_entry_label_5_0_i14,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i14);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_entry_label_5_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_entry_label_5_0_i16,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i16);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__code_util__make_entry_label_5_0, "llds:code_addr/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_entry_label_5_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__code_util__make_local_entry_label_5_0),
		mercury__code_util__make_entry_label_5_0_i17,
		ENTRY(mercury__code_util__make_entry_label_5_0));
Define_label(mercury__code_util__make_entry_label_5_0_i17);
	update_prof_current_proc(LABEL(mercury__code_util__make_entry_label_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__code_util__make_entry_label_5_0, "llds:code_addr/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__procedure_is_exported_2_0);
Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);

BEGIN_MODULE(code_util_module1)
	init_entry(mercury__code_util__make_local_entry_label_5_0);
	init_label(mercury__code_util__make_local_entry_label_5_0_i2);
	init_label(mercury__code_util__make_local_entry_label_5_0_i3);
	init_label(mercury__code_util__make_local_entry_label_5_0_i4);
	init_label(mercury__code_util__make_local_entry_label_5_0_i7);
	init_label(mercury__code_util__make_local_entry_label_5_0_i10);
	init_label(mercury__code_util__make_local_entry_label_5_0_i16);
	init_label(mercury__code_util__make_local_entry_label_5_0_i18);
	init_label(mercury__code_util__make_local_entry_label_5_0_i1018);
	init_label(mercury__code_util__make_local_entry_label_5_0_i6);
	init_label(mercury__code_util__make_local_entry_label_5_0_i1019);
	init_label(mercury__code_util__make_local_entry_label_5_0_i22);
	init_label(mercury__code_util__make_local_entry_label_5_0_i28);
	init_label(mercury__code_util__make_local_entry_label_5_0_i30);
	init_label(mercury__code_util__make_local_entry_label_5_0_i1022);
BEGIN_CODE

/* code for predicate 'make_local_entry_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_local_entry_label_5_0);
	MR_incr_sp_push_msg(6, "code_util:make_local_entry_label/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_local_entry_label_5_0_i2,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__code_util__make_local_entry_label_5_0_i3,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__code_util__make_local_entry_label_5_0_i4,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__procedure_is_exported_2_0),
		mercury__code_util__make_local_entry_label_5_0_i7,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i6);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i10);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 1, mercury__code_util__make_local_entry_label_5_0, "llds:label/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_local_entry_label_5_0_i10);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1018);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__code_util__make_local_entry_label_5_0_i16,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i16);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1019);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__make_local_entry_label_5_0_i18,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i18);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1019);
Define_label(mercury__code_util__make_local_entry_label_5_0_i1018);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__code_util__make_local_entry_label_5_0, "llds:label/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_local_entry_label_5_0_i6);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i22);
Define_label(mercury__code_util__make_local_entry_label_5_0_i1019);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__code_util__make_local_entry_label_5_0, "llds:label/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_local_entry_label_5_0_i22);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1022);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__code_util__make_local_entry_label_5_0_i28,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
	}
Define_label(mercury__code_util__make_local_entry_label_5_0_i28);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1019);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__make_local_entry_label_5_0_i30,
		ENTRY(mercury__code_util__make_local_entry_label_5_0));
Define_label(mercury__code_util__make_local_entry_label_5_0_i30);
	update_prof_current_proc(LABEL(mercury__code_util__make_local_entry_label_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_local_entry_label_5_0_i1019);
Define_label(mercury__code_util__make_local_entry_label_5_0_i1022);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__code_util__make_local_entry_label_5_0, "llds:label/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module2)
	init_entry(mercury__code_util__make_internal_label_5_0);
	init_label(mercury__code_util__make_internal_label_5_0_i2);
BEGIN_CODE

/* code for predicate 'make_internal_label'/5 in mode 0 */
Define_entry(mercury__code_util__make_internal_label_5_0);
	MR_incr_sp_push_msg(2, "code_util:make_internal_label/5");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r4;
	call_localret(STATIC(mercury__code_util__make_proc_label_4_0),
		mercury__code_util__make_internal_label_5_0_i2,
		ENTRY(mercury__code_util__make_internal_label_5_0));
Define_label(mercury__code_util__make_internal_label_5_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_internal_label_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__make_internal_label_5_0, "llds:label/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__special_pred__special_pred_name_arity_4_2);
Declare_entry(mercury__hlds_pred__pred_info_arg_types_2_0);
Declare_entry(mercury__special_pred__special_pred_get_type_3_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);

BEGIN_MODULE(code_util_module3)
	init_entry(mercury__code_util__make_proc_label_4_0);
	init_label(mercury__code_util__make_proc_label_4_0_i2);
	init_label(mercury__code_util__make_proc_label_4_0_i3);
	init_label(mercury__code_util__make_proc_label_4_0_i4);
	init_label(mercury__code_util__make_proc_label_4_0_i5);
	init_label(mercury__code_util__make_proc_label_4_0_i7);
	init_label(mercury__code_util__make_proc_label_4_0_i8);
	init_label(mercury__code_util__make_proc_label_4_0_i9);
	init_label(mercury__code_util__make_proc_label_4_0_i11);
	init_label(mercury__code_util__make_proc_label_4_0_i13);
	init_label(mercury__code_util__make_proc_label_4_0_i15);
	init_label(mercury__code_util__make_proc_label_4_0_i22);
	init_label(mercury__code_util__make_proc_label_4_0_i26);
	init_label(mercury__code_util__make_proc_label_4_0_i27);
	init_label(mercury__code_util__make_proc_label_4_0_i18);
	init_label(mercury__code_util__make_proc_label_4_0_i19);
	init_label(mercury__code_util__make_proc_label_4_0_i1017);
	init_label(mercury__code_util__make_proc_label_4_0_i30);
	init_label(mercury__code_util__make_proc_label_4_0_i6);
	init_label(mercury__code_util__make_proc_label_4_0_i37);
	init_label(mercury__code_util__make_proc_label_4_0_i41);
	init_label(mercury__code_util__make_proc_label_4_0_i34);
	init_label(mercury__code_util__make_proc_label_4_0_i43);
	init_label(mercury__code_util__make_proc_label_4_0_i44);
	init_label(mercury__code_util__make_proc_label_4_0_i45);
BEGIN_CODE

/* code for predicate 'make_proc_label'/4 in mode 0 */
Define_entry(mercury__code_util__make_proc_label_4_0);
	MR_incr_sp_push_msg(9, "code_util:make_proc_label/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__code_util__make_proc_label_4_0_i2,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__code_util__make_proc_label_4_0_i3,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__make_proc_label_4_0_i4,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__code_util__make_proc_label_4_0_i5,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__make_proc_label_4_0_i7,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__make_proc_label_4_0_i8,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__special_pred__special_pred_name_arity_4_2),
		mercury__code_util__make_proc_label_4_0_i9,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i6);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__code_util__make_proc_label_4_0_i11,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__special_pred__special_pred_get_type_3_0),
		mercury__code_util__make_proc_label_4_0_i13,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i13);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i1017);
	r1 = r2;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__code_util__make_proc_label_4_0_i15,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i15);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i1017);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i1017);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__code_util__make_proc_label_4_0_i22,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i22);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i18);
	r1 = MR_stackvar(8);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(6);
	if ((strcmp((char *)MR_stackvar(1), (char *)(Word) MR_string_const("__Unify__", 9)) != 0))
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i19);
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__code_util__make_proc_label_4_0_i26,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i26);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__make_proc_label_4_0_i27,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i27);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i18);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 6, mercury__code_util__make_proc_label_4_0, "llds:proc_label/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(1), r1, (Integer) 5) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__code_util__make_proc_label_4_0_i18);
	r5 = MR_stackvar(6);
	r4 = MR_stackvar(7);
	r1 = MR_stackvar(8);
Define_label(mercury__code_util__make_proc_label_4_0_i19);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 6, mercury__code_util__make_proc_label_4_0, "llds:proc_label/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(1), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(1), r1, (Integer) 4) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 5) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__code_util__make_proc_label_4_0_i1017);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_util__make_proc_label_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("code_util__make_proc_label:\n", 28);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__code_util__make_proc_label_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_string_const("cannot make label for special pred `", 36);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_util__make_proc_label_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_code_util__common_1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__code_util__make_proc_label_4_0_i30,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i30);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i6);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__code_util__make_proc_label_4_0_i37,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i37);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i34);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__code_util__make_proc_label_4_0_i41,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i41);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i34);
	r1 = MR_stackvar(3);
	MR_stackvar(6) = MR_stackvar(5);
	GOTO_LABEL(mercury__code_util__make_proc_label_4_0_i43);
Define_label(mercury__code_util__make_proc_label_4_0_i34);
	r1 = MR_stackvar(3);
	MR_stackvar(6) = MR_stackvar(4);
Define_label(mercury__code_util__make_proc_label_4_0_i43);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__code_util__make_proc_label_4_0_i44,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i44);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__make_proc_label_4_0_i45,
		ENTRY(mercury__code_util__make_proc_label_4_0));
Define_label(mercury__code_util__make_proc_label_4_0_i45);
	update_prof_current_proc(LABEL(mercury__code_util__make_proc_label_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 6, mercury__code_util__make_proc_label_4_0, "llds:proc_label/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module4)
	init_entry(mercury__code_util__make_uni_label_4_0);
	init_label(mercury__code_util__make_uni_label_4_0_i2);
	init_label(mercury__code_util__make_uni_label_4_0_i6);
	init_label(mercury__code_util__make_uni_label_4_0_i7);
	init_label(mercury__code_util__make_uni_label_4_0_i1005);
	init_label(mercury__code_util__make_uni_label_4_0_i3);
BEGIN_CODE

/* code for predicate 'make_uni_label'/4 in mode 0 */
Define_entry(mercury__code_util__make_uni_label_4_0);
	MR_incr_sp_push_msg(6, "code_util:make_uni_label/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__code_util__make_uni_label_4_0_i2,
		ENTRY(mercury__code_util__make_uni_label_4_0));
Define_label(mercury__code_util__make_uni_label_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__make_uni_label_4_0));
	r3 = MR_stackvar(1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__make_uni_label_4_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__code_util__make_uni_label_4_0_i6,
		ENTRY(mercury__code_util__make_uni_label_4_0));
Define_label(mercury__code_util__make_uni_label_4_0_i6);
	update_prof_current_proc(LABEL(mercury__code_util__make_uni_label_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__make_uni_label_4_0_i7,
		ENTRY(mercury__code_util__make_uni_label_4_0));
Define_label(mercury__code_util__make_uni_label_4_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__make_uni_label_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__make_uni_label_4_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 6, mercury__code_util__make_uni_label_4_0, "origin_lost_in_value_number");
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 5) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_string_const("__Unify__", 9);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_uni_label_4_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 6, mercury__code_util__make_uni_label_4_0, "llds:proc_label/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_string_const("__Unify__", 9);
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 5) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__make_uni_label_4_0_i3);
	r1 = (Word) MR_string_const("code_util__make_uni_label: unqualified type_id", 46);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__make_uni_label_4_0));
END_MODULE


BEGIN_MODULE(code_util_module5)
	init_entry(mercury__code_util__extract_proc_label_from_code_addr_2_0);
	init_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i4);
	init_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i2);
BEGIN_CODE

/* code for predicate 'extract_proc_label_from_code_addr'/2 in mode 0 */
Define_entry(mercury__code_util__extract_proc_label_from_code_addr_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__extract_proc_label_from_code_addr_2_0_i4);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_mask_field(r2, (Integer) 0);
	proceed();
Define_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i4);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__code_util__extract_proc_label_from_code_addr_2_0_i2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	proceed();
Define_label(mercury__code_util__extract_proc_label_from_code_addr_2_0_i2);
	r1 = (Word) MR_string_const("code_util__extract_label_from_code_addr failed", 46);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__extract_proc_label_from_code_addr_2_0));
END_MODULE


BEGIN_MODULE(code_util_module6)
	init_entry(mercury__code_util__extract_proc_label_from_label_2_0);
BEGIN_CODE

/* code for predicate 'extract_proc_label_from_label'/2 in mode 0 */
Define_entry(mercury__code_util__extract_proc_label_from_label_2_0);
	r1 = MR_const_mask_field(r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module7)
	init_entry(mercury__code_util__arg_loc_to_register_2_0);
BEGIN_CODE

/* code for predicate 'arg_loc_to_register'/2 in mode 0 */
Define_entry(mercury__code_util__arg_loc_to_register_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_util__arg_loc_to_register_2_0, "llds:lval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module8)
	init_entry(mercury__code_util__goal_may_allocate_heap_1_0);
BEGIN_CODE

/* code for predicate 'goal_may_allocate_heap'/1 in mode 0 */
Define_entry(mercury__code_util__goal_may_allocate_heap_1_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0),
		ENTRY(mercury__code_util__goal_may_allocate_heap_1_0));
END_MODULE


BEGIN_MODULE(code_util_module9)
	init_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1002);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i5);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	init_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_list_may_allocate_heap'/1 in mode 0 */
Define_entry(mercury__code_util__goal_list_may_allocate_heap_1_0);
	MR_incr_sp_push_msg(2, "code_util:goal_list_may_allocate_heap/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0),
		mercury__code_util__goal_list_may_allocate_heap_1_0_i5,
		ENTRY(mercury__code_util__goal_list_may_allocate_heap_1_0));
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_util__goal_list_may_allocate_heap_1_0_i1002);
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__goal_list_may_allocate_heap_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module10)
	init_entry(mercury__code_util__neg_rval_2_0);
	init_label(mercury__code_util__neg_rval_2_0_i6);
	init_label(mercury__code_util__neg_rval_2_0_i8);
	init_label(mercury__code_util__neg_rval_2_0_i10);
	init_label(mercury__code_util__neg_rval_2_0_i12);
	init_label(mercury__code_util__neg_rval_2_0_i26);
	init_label(mercury__code_util__neg_rval_2_0_i27);
	init_label(mercury__code_util__neg_rval_2_0_i29);
	init_label(mercury__code_util__neg_rval_2_0_i30);
	init_label(mercury__code_util__neg_rval_2_0_i31);
	init_label(mercury__code_util__neg_rval_2_0_i32);
	init_label(mercury__code_util__neg_rval_2_0_i33);
	init_label(mercury__code_util__neg_rval_2_0_i34);
	init_label(mercury__code_util__neg_rval_2_0_i35);
	init_label(mercury__code_util__neg_rval_2_0_i36);
	init_label(mercury__code_util__neg_rval_2_0_i37);
	init_label(mercury__code_util__neg_rval_2_0_i38);
	init_label(mercury__code_util__neg_rval_2_0_i43);
	init_label(mercury__code_util__neg_rval_2_0_i44);
	init_label(mercury__code_util__neg_rval_2_0_i45);
	init_label(mercury__code_util__neg_rval_2_0_i46);
	init_label(mercury__code_util__neg_rval_2_0_i47);
	init_label(mercury__code_util__neg_rval_2_0_i48);
	init_label(mercury__code_util__neg_rval_2_0_i2);
BEGIN_CODE

/* code for predicate 'neg_rval'/2 in mode 0 */
Define_entry(mercury__code_util__neg_rval_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i6) AND
		LABEL(mercury__code_util__neg_rval_2_0_i10) AND
		LABEL(mercury__code_util__neg_rval_2_0_i12) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2));
Define_label(mercury__code_util__neg_rval_2_0_i6);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_util__common_2);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i8);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_util__common_3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i10);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) 9))
		GOTO_LABEL(mercury__code_util__neg_rval_2_0_i2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i12);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i26) AND
		LABEL(mercury__code_util__neg_rval_2_0_i27) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i29) AND
		LABEL(mercury__code_util__neg_rval_2_0_i30) AND
		LABEL(mercury__code_util__neg_rval_2_0_i31) AND
		LABEL(mercury__code_util__neg_rval_2_0_i32) AND
		LABEL(mercury__code_util__neg_rval_2_0_i33) AND
		LABEL(mercury__code_util__neg_rval_2_0_i34) AND
		LABEL(mercury__code_util__neg_rval_2_0_i35) AND
		LABEL(mercury__code_util__neg_rval_2_0_i36) AND
		LABEL(mercury__code_util__neg_rval_2_0_i37) AND
		LABEL(mercury__code_util__neg_rval_2_0_i38) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i2) AND
		LABEL(mercury__code_util__neg_rval_2_0_i43) AND
		LABEL(mercury__code_util__neg_rval_2_0_i44) AND
		LABEL(mercury__code_util__neg_rval_2_0_i45) AND
		LABEL(mercury__code_util__neg_rval_2_0_i46) AND
		LABEL(mercury__code_util__neg_rval_2_0_i47) AND
		LABEL(mercury__code_util__neg_rval_2_0_i48));
Define_label(mercury__code_util__neg_rval_2_0_i26);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 13;
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i27);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i29);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 16;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i30);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 15;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i31);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 20;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i32);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 19;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i33);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 18;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i34);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 17;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i35);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 24;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i36);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 23;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i37);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 22;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i38);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 21;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i43);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 30;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i44);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 29;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i45);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 34;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i46);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 33;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i47);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 32;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i48);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 31;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	proceed();
Define_label(mercury__code_util__neg_rval_2_0_i2);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__code_util__neg_rval_2_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 9;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module11)
	init_entry(mercury__code_util__negate_the_test_2_0);
	init_label(mercury__code_util__negate_the_test_2_0_i3);
	init_label(mercury__code_util__negate_the_test_2_0_i7);
	init_label(mercury__code_util__negate_the_test_2_0_i5);
	init_label(mercury__code_util__negate_the_test_2_0_i8);
BEGIN_CODE

/* code for predicate 'negate_the_test'/2 in mode 0 */
Define_entry(mercury__code_util__negate_the_test_2_0);
	MR_incr_sp_push_msg(3, "code_util:negate_the_test/2");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i3);
	r1 = (Word) MR_string_const("code_util__negate_the_test on empty list", 40);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__code_util__negate_the_test_2_0));
Define_label(mercury__code_util__negate_the_test_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__code_util__negate_the_test_2_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	call_localret(STATIC(mercury__code_util__neg_rval_2_0),
		mercury__code_util__negate_the_test_2_0_i7,
		ENTRY(mercury__code_util__negate_the_test_2_0));
	}
Define_label(mercury__code_util__negate_the_test_2_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__negate_the_test_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_util__negate_the_test_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__code_util__negate_the_test_2_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__code_util__negate_the_test_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__code_util__negate_the_test_2_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__code_util__negate_the_test_2_0,
		LABEL(mercury__code_util__negate_the_test_2_0_i8),
		ENTRY(mercury__code_util__negate_the_test_2_0));
Define_label(mercury__code_util__negate_the_test_2_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__negate_the_test_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_util__negate_the_test_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module12)
	init_entry(mercury__code_util__compiler_generated_1_0);
	init_label(mercury__code_util__compiler_generated_1_0_i2);
	init_label(mercury__code_util__compiler_generated_1_0_i3);
BEGIN_CODE

/* code for predicate 'compiler_generated'/1 in mode 0 */
Define_entry(mercury__code_util__compiler_generated_1_0);
	MR_incr_sp_push_msg(2, "code_util:compiler_generated/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__compiler_generated_1_0_i2,
		ENTRY(mercury__code_util__compiler_generated_1_0));
Define_label(mercury__code_util__compiler_generated_1_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__compiler_generated_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__compiler_generated_1_0_i3,
		ENTRY(mercury__code_util__compiler_generated_1_0));
Define_label(mercury__code_util__compiler_generated_1_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__compiler_generated_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__special_pred__special_pred_name_arity_4_2),
		ENTRY(mercury__code_util__compiler_generated_1_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
Declare_entry(mercury__varset__init_1_0);
Declare_entry(mercury__varset__new_vars_4_0);

BEGIN_MODULE(code_util_module13)
	init_entry(mercury__code_util__predinfo_is_builtin_1_0);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i2);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i3);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i4);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i5);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i6);
	init_label(mercury__code_util__predinfo_is_builtin_1_0_i1);
BEGIN_CODE

/* code for predicate 'predinfo_is_builtin'/1 in mode 0 */
Define_entry(mercury__code_util__predinfo_is_builtin_1_0);
	MR_incr_sp_push_msg(4, "code_util:predinfo_is_builtin/1");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__code_util__predinfo_is_builtin_1_0_i2,
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin_1_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__code_util__predinfo_is_builtin_1_0_i3,
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__code_util__predinfo_is_builtin_1_0_i4,
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin_1_0));
	if (((Integer) r1 > (Integer) 3))
		GOTO_LABEL(mercury__code_util__predinfo_is_builtin_1_0_i1);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__code_util__predinfo_is_builtin_1_0_i5,
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin_1_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__varset__new_vars_4_0),
		mercury__code_util__predinfo_is_builtin_1_0_i6,
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i6);
	update_prof_current_proc(LABEL(mercury__code_util__predinfo_is_builtin_1_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__predinfo_is_builtin_1_0_i1);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_stackvar(1);
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_util__translate_builtin_2_6_0),
		ENTRY(mercury__code_util__predinfo_is_builtin_1_0));
	}
Define_label(mercury__code_util__predinfo_is_builtin_1_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__predicate_module_3_0);
Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__hlds_module__predicate_arity_3_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);

BEGIN_MODULE(code_util_module14)
	init_entry(mercury__code_util__builtin_state_4_0);
	init_label(mercury__code_util__builtin_state_4_0_i2);
	init_label(mercury__code_util__builtin_state_4_0_i3);
	init_label(mercury__code_util__builtin_state_4_0_i4);
	init_label(mercury__code_util__builtin_state_4_0_i5);
	init_label(mercury__code_util__builtin_state_4_0_i8);
	init_label(mercury__code_util__builtin_state_4_0_i9);
	init_label(mercury__code_util__builtin_state_4_0_i11);
	init_label(mercury__code_util__builtin_state_4_0_i7);
BEGIN_CODE

/* code for predicate 'builtin_state'/4 in mode 0 */
Define_entry(mercury__code_util__builtin_state_4_0);
	MR_incr_sp_push_msg(5, "code_util:builtin_state/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__code_util__builtin_state_4_0_i2,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__code_util__builtin_state_4_0_i3,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__predicate_arity_3_0),
		mercury__code_util__builtin_state_4_0_i4,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__code_util__builtin_state_4_0_i5,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	if (((Integer) MR_stackvar(2) > (Integer) 3))
		GOTO_LABEL(mercury__code_util__builtin_state_4_0_i7);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__code_util__builtin_state_4_0_i8,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__new_vars_4_0),
		mercury__code_util__builtin_state_4_0_i9,
		ENTRY(mercury__code_util__builtin_state_4_0));
Define_label(mercury__code_util__builtin_state_4_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__builtin_state_4_0_i7);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__code_util__translate_builtin_2_6_0),
		mercury__code_util__builtin_state_4_0_i11,
		ENTRY(mercury__code_util__builtin_state_4_0));
	}
Define_label(mercury__code_util__builtin_state_4_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__builtin_state_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__builtin_state_4_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__code_util__builtin_state_4_0_i7);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module15)
	init_entry(mercury__code_util__translate_builtin_6_0);
	init_label(mercury__code_util__translate_builtin_6_0_i2);
	init_label(mercury__code_util__translate_builtin_6_0_i1);
BEGIN_CODE

/* code for predicate 'translate_builtin'/6 in mode 0 */
Define_entry(mercury__code_util__translate_builtin_6_0);
	MR_incr_sp_push_msg(4, "code_util:translate_builtin/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__code_util__translate_builtin_6_0_i2,
		ENTRY(mercury__code_util__translate_builtin_6_0));
Define_label(mercury__code_util__translate_builtin_6_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__translate_builtin_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__translate_builtin_6_0_i1);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_util__translate_builtin_2_6_0),
		ENTRY(mercury__code_util__translate_builtin_6_0));
	}
Define_label(mercury__code_util__translate_builtin_6_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__string__char_to_string_2_1);
Declare_entry(mercury__char__to_int_2_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;

BEGIN_MODULE(code_util_module16)
	init_entry(mercury__code_util__cons_id_to_tag_4_0);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i4);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i12);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i14);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i5);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i6);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i17);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i15);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i19);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i21);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i22);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i23);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i24);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i26);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i30);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i31);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i32);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i33);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i34);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i35);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i36);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i37);
	init_label(mercury__code_util__cons_id_to_tag_4_0_i38);
BEGIN_CODE

/* code for predicate 'cons_id_to_tag'/4 in mode 0 */
Define_entry(mercury__code_util__cons_id_to_tag_4_0);
	MR_incr_sp_push_msg(4, "code_util:cons_id_to_tag/4");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i4) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i30) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i31) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i32));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r4, (Integer) 0), (char *)(Word) MR_string_const("character", 9)) != 0))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i6);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__string__char_to_string_2_1),
		mercury__code_util__cons_id_to_tag_4_0_i12,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i12);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i5);
	r1 = r2;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i14,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i14);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
Define_label(mercury__code_util__cons_id_to_tag_4_0_i6);
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__code_util__cons_id_to_tag_4_0_i17,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i17);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i15);
	r1 = MR_stackvar(3);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i21,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i15);
	r1 = (Word) MR_string_const("code_util__cons_id_to_tag: invalid type", 39);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__cons_id_to_tag_4_0_i19,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i19);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i21,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i21);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_4);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__code_util__cons_id_to_tag_4_0_i22,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i22);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__code_util__cons_id_to_tag_4_0_i23,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i23);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cons_id_to_tag_4_0_i24);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0;
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__lookup_3_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i24);
	r1 = (Word) MR_string_const("code_util__cons_id_to_tag: type is not d.u. type?", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__cons_id_to_tag_4_0_i26,
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i26);
	update_prof_current_proc(LABEL(mercury__code_util__cons_id_to_tag_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__lookup_3_0),
		ENTRY(mercury__code_util__cons_id_to_tag_4_0));
	}
Define_label(mercury__code_util__cons_id_to_tag_4_0_i30);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i31);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i32);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i33) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i34) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i35) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i36) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i37) AND
		LABEL(mercury__code_util__cons_id_to_tag_4_0_i38));
Define_label(mercury__code_util__cons_id_to_tag_4_0_i33);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i34);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i35);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i36);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i37);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__cons_id_to_tag_4_0_i38);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__code_util__cons_id_to_tag_4_0, "hlds_data:cons_tag/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module17)
	init_entry(mercury__code_util__cannot_stack_flush_1_0);
BEGIN_CODE

/* code for predicate 'cannot_stack_flush'/1 in mode 0 */
Define_entry(mercury__code_util__cannot_stack_flush_1_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_2_1_0),
		ENTRY(mercury__code_util__cannot_stack_flush_1_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);

BEGIN_MODULE(code_util_module18)
	init_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i9);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1);
BEGIN_CODE

/* code for predicate 'cannot_fail_before_stack_flush'/1 in mode 0 */
Define_entry(mercury__code_util__cannot_fail_before_stack_flush_1_0);
	MR_incr_sp_push_msg(2, "code_util:cannot_fail_before_stack_flush/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__code_util__cannot_fail_before_stack_flush_1_0_i2,
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i2);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__code_util__cannot_fail_before_stack_flush_1_0_i3,
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i3);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0));
	if (((Integer) r1 == (Integer) 1))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0_i9);
	r2 = MR_stackvar(1);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0),
		ENTRY(mercury__code_util__cannot_fail_before_stack_flush_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i9);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_1_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module19)
	init_entry(mercury__code_util__count_recursive_calls_5_0);
BEGIN_CODE

/* code for predicate 'count_recursive_calls'/5 in mode 0 */
Define_entry(mercury__code_util__count_recursive_calls_5_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		ENTRY(mercury__code_util__count_recursive_calls_5_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(code_util_module20)
	init_entry(mercury__code_util__output_args_2_0);
	init_label(mercury__code_util__output_args_2_0_i4);
	init_label(mercury__code_util__output_args_2_0_i3);
	init_label(mercury__code_util__output_args_2_0_i2);
BEGIN_CODE

/* code for predicate 'output_args'/2 in mode 0 */
Define_entry(mercury__code_util__output_args_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__output_args_2_0_i3);
	MR_incr_sp_push_msg(3, "code_util:output_args/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__code_util__output_args_2_0,
		LABEL(mercury__code_util__output_args_2_0_i4),
		ENTRY(mercury__code_util__output_args_2_0));
Define_label(mercury__code_util__output_args_2_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__output_args_2_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__code_util__output_args_2_0_i2);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__code_util__output_args_2_0, "llds:lval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__set__insert_3_1),
		ENTRY(mercury__code_util__output_args_2_0));
Define_label(mercury__code_util__output_args_2_0_i3);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	tailcall(ENTRY(mercury__set__init_1_0),
		ENTRY(mercury__code_util__output_args_2_0));
Define_label(mercury__code_util__output_args_2_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(code_util_module21)
	init_entry(mercury__code_util__lvals_in_rval_2_0);
	init_label(mercury__code_util__lvals_in_rval_2_0_i4);
	init_label(mercury__code_util__lvals_in_rval_2_0_i5);
	init_label(mercury__code_util__lvals_in_rval_2_0_i8);
	init_label(mercury__code_util__lvals_in_rval_2_0_i11);
	init_label(mercury__code_util__lvals_in_rval_2_0_i12);
	init_label(mercury__code_util__lvals_in_rval_2_0_i14);
	init_label(mercury__code_util__lvals_in_rval_2_0_i15);
	init_label(mercury__code_util__lvals_in_rval_2_0_i16);
	init_label(mercury__code_util__lvals_in_rval_2_0_i18);
BEGIN_CODE

/* code for predicate 'lvals_in_rval'/2 in mode 0 */
Define_entry(mercury__code_util__lvals_in_rval_2_0);
	MR_incr_sp_push_msg(2, "code_util:lvals_in_rval/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__lvals_in_rval_2_0_i4) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i11) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i11) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i8));
Define_label(mercury__code_util__lvals_in_rval_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__code_util__lvals_in_lval_2_0),
		mercury__code_util__lvals_in_rval_2_0_i5,
		ENTRY(mercury__code_util__lvals_in_rval_2_0));
Define_label(mercury__code_util__lvals_in_rval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__lvals_in_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__code_util__lvals_in_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__lvals_in_rval_2_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__lvals_in_rval_2_0_i12) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i11) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i12) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i14) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i18));
Define_label(mercury__code_util__lvals_in_rval_2_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__lvals_in_rval_2_0_i12);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__lvals_in_rval_2_0_i4) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i11) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i11) AND
		LABEL(mercury__code_util__lvals_in_rval_2_0_i8));
Define_label(mercury__code_util__lvals_in_rval_2_0_i14);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__code_util__lvals_in_rval_2_0,
		LABEL(mercury__code_util__lvals_in_rval_2_0_i15),
		ENTRY(mercury__code_util__lvals_in_rval_2_0));
Define_label(mercury__code_util__lvals_in_rval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__code_util__lvals_in_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__code_util__lvals_in_rval_2_0,
		LABEL(mercury__code_util__lvals_in_rval_2_0_i16),
		ENTRY(mercury__code_util__lvals_in_rval_2_0));
Define_label(mercury__code_util__lvals_in_rval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__code_util__lvals_in_rval_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__code_util__lvals_in_rval_2_0));
Define_label(mercury__code_util__lvals_in_rval_2_0_i18);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__code_util__lvals_in_mem_ref_2_0),
		ENTRY(mercury__code_util__lvals_in_rval_2_0));
END_MODULE


BEGIN_MODULE(code_util_module22)
	init_entry(mercury__code_util__lvals_in_lval_2_0);
	init_label(mercury__code_util__lvals_in_lval_2_0_i12);
	init_label(mercury__code_util__lvals_in_lval_2_0_i25);
	init_label(mercury__code_util__lvals_in_lval_2_0_i26);
	init_label(mercury__code_util__lvals_in_lval_2_0_i27);
	init_label(mercury__code_util__lvals_in_lval_2_0_i29);
	init_label(mercury__code_util__lvals_in_lval_2_0_i1003);
	init_label(mercury__code_util__lvals_in_lval_2_0_i31);
BEGIN_CODE

/* code for predicate 'lvals_in_lval'/2 in mode 0 */
Define_entry(mercury__code_util__lvals_in_lval_2_0);
	MR_incr_sp_push_msg(2, "code_util:lvals_in_lval/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__lvals_in_lval_2_0_i1003) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i1003) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i1003) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i12));
Define_label(mercury__code_util__lvals_in_lval_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__lvals_in_lval_2_0_i31) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i31) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i25) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i29) AND
		LABEL(mercury__code_util__lvals_in_lval_2_0_i31));
Define_label(mercury__code_util__lvals_in_lval_2_0_i25);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__code_util__lvals_in_rval_2_0),
		mercury__code_util__lvals_in_lval_2_0_i26,
		ENTRY(mercury__code_util__lvals_in_lval_2_0));
Define_label(mercury__code_util__lvals_in_lval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__code_util__lvals_in_lval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__code_util__lvals_in_rval_2_0),
		mercury__code_util__lvals_in_lval_2_0_i27,
		ENTRY(mercury__code_util__lvals_in_lval_2_0));
Define_label(mercury__code_util__lvals_in_lval_2_0_i27);
	update_prof_current_proc(LABEL(mercury__code_util__lvals_in_lval_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__code_util__lvals_in_lval_2_0));
Define_label(mercury__code_util__lvals_in_lval_2_0_i29);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__code_util__lvals_in_rval_2_0),
		ENTRY(mercury__code_util__lvals_in_lval_2_0));
Define_label(mercury__code_util__lvals_in_lval_2_0_i1003);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__lvals_in_lval_2_0_i31);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module23)
	init_entry(mercury__code_util__translate_builtin_2_6_0);
	init_label(mercury__code_util__translate_builtin_2_6_0_i5);
	init_label(mercury__code_util__translate_builtin_2_6_0_i11);
	init_label(mercury__code_util__translate_builtin_2_6_0_i1085);
	init_label(mercury__code_util__translate_builtin_2_6_0_i13);
	init_label(mercury__code_util__translate_builtin_2_6_0_i14);
	init_label(mercury__code_util__translate_builtin_2_6_0_i17);
	init_label(mercury__code_util__translate_builtin_2_6_0_i20);
	init_label(mercury__code_util__translate_builtin_2_6_0_i23);
	init_label(mercury__code_util__translate_builtin_2_6_0_i27);
	init_label(mercury__code_util__translate_builtin_2_6_0_i28);
	init_label(mercury__code_util__translate_builtin_2_6_0_i30);
	init_label(mercury__code_util__translate_builtin_2_6_0_i34);
	init_label(mercury__code_util__translate_builtin_2_6_0_i35);
	init_label(mercury__code_util__translate_builtin_2_6_0_i37);
	init_label(mercury__code_util__translate_builtin_2_6_0_i40);
	init_label(mercury__code_util__translate_builtin_2_6_0_i43);
	init_label(mercury__code_util__translate_builtin_2_6_0_i47);
	init_label(mercury__code_util__translate_builtin_2_6_0_i45);
	init_label(mercury__code_util__translate_builtin_2_6_0_i49);
	init_label(mercury__code_util__translate_builtin_2_6_0_i55);
	init_label(mercury__code_util__translate_builtin_2_6_0_i59);
	init_label(mercury__code_util__translate_builtin_2_6_0_i60);
	init_label(mercury__code_util__translate_builtin_2_6_0_i62);
	init_label(mercury__code_util__translate_builtin_2_6_0_i66);
	init_label(mercury__code_util__translate_builtin_2_6_0_i64);
	init_label(mercury__code_util__translate_builtin_2_6_0_i68);
	init_label(mercury__code_util__translate_builtin_2_6_0_i74);
	init_label(mercury__code_util__translate_builtin_2_6_0_i78);
	init_label(mercury__code_util__translate_builtin_2_6_0_i79);
	init_label(mercury__code_util__translate_builtin_2_6_0_i81);
	init_label(mercury__code_util__translate_builtin_2_6_0_i84);
	init_label(mercury__code_util__translate_builtin_2_6_0_i88);
	init_label(mercury__code_util__translate_builtin_2_6_0_i89);
	init_label(mercury__code_util__translate_builtin_2_6_0_i91);
	init_label(mercury__code_util__translate_builtin_2_6_0_i95);
	init_label(mercury__code_util__translate_builtin_2_6_0_i96);
	init_label(mercury__code_util__translate_builtin_2_6_0_i98);
	init_label(mercury__code_util__translate_builtin_2_6_0_i101);
	init_label(mercury__code_util__translate_builtin_2_6_0_i9);
	init_label(mercury__code_util__translate_builtin_2_6_0_i106);
	init_label(mercury__code_util__translate_builtin_2_6_0_i1312);
	init_label(mercury__code_util__translate_builtin_2_6_0_i1075);
	init_label(mercury__code_util__translate_builtin_2_6_0_i108);
	init_label(mercury__code_util__translate_builtin_2_6_0_i109);
	init_label(mercury__code_util__translate_builtin_2_6_0_i112);
	init_label(mercury__code_util__translate_builtin_2_6_0_i115);
	init_label(mercury__code_util__translate_builtin_2_6_0_i118);
	init_label(mercury__code_util__translate_builtin_2_6_0_i122);
	init_label(mercury__code_util__translate_builtin_2_6_0_i126);
	init_label(mercury__code_util__translate_builtin_2_6_0_i130);
	init_label(mercury__code_util__translate_builtin_2_6_0_i134);
	init_label(mercury__code_util__translate_builtin_2_6_0_i138);
	init_label(mercury__code_util__translate_builtin_2_6_0_i139);
	init_label(mercury__code_util__translate_builtin_2_6_0_i141);
	init_label(mercury__code_util__translate_builtin_2_6_0_i145);
	init_label(mercury__code_util__translate_builtin_2_6_0_i149);
	init_label(mercury__code_util__translate_builtin_2_6_0_i153);
	init_label(mercury__code_util__translate_builtin_2_6_0_i157);
	init_label(mercury__code_util__translate_builtin_2_6_0_i161);
	init_label(mercury__code_util__translate_builtin_2_6_0_i164);
	init_label(mercury__code_util__translate_builtin_2_6_0_i168);
	init_label(mercury__code_util__translate_builtin_2_6_0_i172);
	init_label(mercury__code_util__translate_builtin_2_6_0_i173);
	init_label(mercury__code_util__translate_builtin_2_6_0_i175);
	init_label(mercury__code_util__translate_builtin_2_6_0_i178);
	init_label(mercury__code_util__translate_builtin_2_6_0_i182);
	init_label(mercury__code_util__translate_builtin_2_6_0_i183);
	init_label(mercury__code_util__translate_builtin_2_6_0_i185);
	init_label(mercury__code_util__translate_builtin_2_6_0_i189);
	init_label(mercury__code_util__translate_builtin_2_6_0_i187);
	init_label(mercury__code_util__translate_builtin_2_6_0_i191);
	init_label(mercury__code_util__translate_builtin_2_6_0_i197);
	init_label(mercury__code_util__translate_builtin_2_6_0_i201);
	init_label(mercury__code_util__translate_builtin_2_6_0_i202);
	init_label(mercury__code_util__translate_builtin_2_6_0_i204);
	init_label(mercury__code_util__translate_builtin_2_6_0_i208);
	init_label(mercury__code_util__translate_builtin_2_6_0_i206);
	init_label(mercury__code_util__translate_builtin_2_6_0_i210);
	init_label(mercury__code_util__translate_builtin_2_6_0_i216);
	init_label(mercury__code_util__translate_builtin_2_6_0_i219);
	init_label(mercury__code_util__translate_builtin_2_6_0_i223);
	init_label(mercury__code_util__translate_builtin_2_6_0_i227);
	init_label(mercury__code_util__translate_builtin_2_6_0_i231);
	init_label(mercury__code_util__translate_builtin_2_6_0_i235);
	init_label(mercury__code_util__translate_builtin_2_6_0_i236);
	init_label(mercury__code_util__translate_builtin_2_6_0_i238);
	init_label(mercury__code_util__translate_builtin_2_6_0_i241);
	init_label(mercury__code_util__translate_builtin_2_6_0_i244);
	init_label(mercury__code_util__translate_builtin_2_6_0_i248);
	init_label(mercury__code_util__translate_builtin_2_6_0_i249);
	init_label(mercury__code_util__translate_builtin_2_6_0_i104);
	init_label(mercury__code_util__translate_builtin_2_6_0_i255);
	init_label(mercury__code_util__translate_builtin_2_6_0_i256);
BEGIN_CODE

/* code for predicate 'translate_builtin_2'/6 in mode 0 */
Define_static(mercury__code_util__translate_builtin_2_6_0);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("builtin", 7)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i5);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("unsafe_promise_unique", 21)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i5);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i9);
	r1 = (hash_string(r2) & (Integer) 31);
Define_label(mercury__code_util__translate_builtin_2_6_0_i11);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_5))[(Integer) r1];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1085);
	if ((strcmp((char *)MR_tempr1, (char *)r2) == 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i13);
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i1085);
	r1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_6))[(Integer) r1];
	if (((Integer) r1 >= (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i11);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i13);
	COMPUTED_GOTO((Unsigned) r1,
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i14) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i17) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i20) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i23) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i30) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i37) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i40) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i43) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i55) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i62) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i74) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i81) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i84) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i91) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i98) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i101));
Define_label(mercury__code_util__translate_builtin_2_6_0_i14);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 34;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i17);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 33;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i20);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 34;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i23);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i27);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 27;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i27);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i28);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i30);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i34);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i34);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i35);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 27;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i35);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i37);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 31;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i40);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 33;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i43);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i45);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i47);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i47);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 25;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i45);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i49);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i49);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i55);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i59);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 27;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i59);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i60);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i60);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i62);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i64);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i66);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	MR_field(MR_mktag(3), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_util__common_8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i66);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i64);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i68);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 25;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i68);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i74);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i78);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i78);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i79);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 25;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i79);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i81);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 32;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i84);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i88);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i88);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i89);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 27;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i89);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 28;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i91);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i95);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 25;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i95);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i96);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i96);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 26;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i98);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 31;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i101);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 32;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i9);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i104);
	r1 = (hash_string(r2) & (Integer) 63);
Define_label(mercury__code_util__translate_builtin_2_6_0_i106);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_9))[(Integer) r1];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1312);
	if ((strcmp((char *)MR_tempr1, (char *)r2) == 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i108);
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i1312);
	r1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_code_util__common_10))[(Integer) r1];
	if (((Integer) r1 >= (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i106);
Define_label(mercury__code_util__translate_builtin_2_6_0_i1075);
	r1 = FALSE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i108);
	COMPUTED_GOTO((Unsigned) r1,
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i109) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i112) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i115) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i118) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i122) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i126) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i130) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i134) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i141) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i145) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i149) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i153) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i157) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i161) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i164) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i168) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i175) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i178) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i185) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i197) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i204) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i216) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i219) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i223) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i227) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i231) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i238) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i241) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i1075) AND
		LABEL(mercury__code_util__translate_builtin_2_6_0_i244));
Define_label(mercury__code_util__translate_builtin_2_6_0_i109);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 24;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i112);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 21;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i115);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 22;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i118);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 9;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i122);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i126);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 6;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i130);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i134);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i138);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i138);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i139);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i139);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i141);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 7;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i145);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 6;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i149);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i153);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i157);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 7;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i161);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i164);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 9;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i168);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i172);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i172);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i173);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i173);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i175);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 23;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i178);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i182);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i182);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i183);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i183);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i185);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i187);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i189);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i189);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i187);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i191);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i191);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i197);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i201);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i201);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i202);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i202);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i204);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i206);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i208);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_util__common_12);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i208);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i206);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i210);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i210);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i216);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_code_util__common_12);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i219);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i223);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i227);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 9;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i231);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i235);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i235);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i236);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i236);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i238);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i241);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i244);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i248);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i248);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i249);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i249);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	r1 = TRUE;
	proceed();
	}
Define_label(mercury__code_util__translate_builtin_2_6_0_i104);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("private_builtin", 15)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("builtin_int_gt", 14)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i255);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 22;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i255);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("builtin_int_lt", 14)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i256);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 21;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "llds:rval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__translate_builtin_2_6_0_i256);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("unsafe_type_cast", 16)) != 0))
		GOTO_LABEL(mercury__code_util__translate_builtin_2_6_0_i1075);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "std_util:maybe/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__code_util__translate_builtin_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__code_util__translate_builtin_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	r1 = TRUE;
	proceed();
	}
END_MODULE


BEGIN_MODULE(code_util_module24)
	init_entry(mercury__code_util__goal_may_allocate_heap_2_1_0);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i4);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i7);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i11);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i12);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i15);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i18);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i21);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i27);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i30);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i33);
	init_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_may_allocate_heap_2'/1 in mode 0 */
Define_static(mercury__code_util__goal_may_allocate_heap_2_1_0);
	MR_incr_sp_push_msg(3, "code_util:goal_may_allocate_heap_2/1");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i4) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i7) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i11));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_util__goal_list_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) == (Integer) 0))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i11);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i12) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i15) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i18) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i21) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i24) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i27) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i12);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_util__cases_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i15);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i18);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__code_util__goal_list_may_allocate_heap_1_0),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i21);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i4) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i7) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i11));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i24);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i4) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i7) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i11));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i27);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__code_util__goal_may_allocate_heap_2_1_0,
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i30),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i30);
	update_prof_current_proc(LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	localcall(mercury__code_util__goal_may_allocate_heap_2_1_0,
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i33),
		STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i33);
	update_prof_current_proc(LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i4) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i7) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i1013) AND
		LABEL(mercury__code_util__goal_may_allocate_heap_2_1_0_i11));
Define_label(mercury__code_util__goal_may_allocate_heap_2_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module25)
	init_entry(mercury__code_util__cases_may_allocate_heap_1_0);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i1002);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i5);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	init_label(mercury__code_util__cases_may_allocate_heap_1_0_i1);
BEGIN_CODE

/* code for predicate 'cases_may_allocate_heap'/1 in mode 0 */
Define_static(mercury__code_util__cases_may_allocate_heap_1_0);
	MR_incr_sp_push_msg(2, "code_util:cases_may_allocate_heap/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cases_may_allocate_heap_1_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 0);
	call_localret(STATIC(mercury__code_util__goal_may_allocate_heap_2_1_0),
		mercury__code_util__cases_may_allocate_heap_1_0_i5,
		STATIC(mercury__code_util__cases_may_allocate_heap_1_0));
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i5);
	update_prof_current_proc(LABEL(mercury__code_util__cases_may_allocate_heap_1_0));
	if (r1)
		GOTO_LABEL(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_util__cases_may_allocate_heap_1_0_i1002);
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cases_may_allocate_heap_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module26)
	init_entry(mercury__code_util__cannot_stack_flush_2_1_0);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i11);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i4);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i5);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1004);
	init_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
BEGIN_CODE

/* code for predicate 'cannot_stack_flush_2'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_2_1_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i4);
	if ((r2 == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i11);
	if ((r2 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i11);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_goals_1_0),
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i4);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i5) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i8) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1) AND
		LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1));
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	tailcall(STATIC(mercury__code_util__cannot_stack_flush_cases_1_0),
		STATIC(mercury__code_util__cannot_stack_flush_2_1_0));
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i8);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1004);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 == (Integer) 1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_2_1_0_i1);
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1004);
	r1 = TRUE;
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_2_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module27)
	init_entry(mercury__code_util__cannot_stack_flush_goals_1_0);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1002);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i2);
	init_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
BEGIN_CODE

/* code for predicate 'cannot_stack_flush_goals'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_goals_1_0);
	MR_incr_sp_push_msg(2, "code_util:cannot_stack_flush_goals/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_goals_1_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__code_util__cannot_stack_flush_2_1_0),
		mercury__code_util__cannot_stack_flush_goals_1_0_i4,
		STATIC(mercury__code_util__cannot_stack_flush_goals_1_0));
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_stack_flush_goals_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_util__cannot_stack_flush_goals_1_0_i1002);
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_goals_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module28)
	init_entry(mercury__code_util__cannot_stack_flush_cases_1_0);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1002);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i2);
	init_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
BEGIN_CODE

/* code for predicate 'cannot_stack_flush_cases'/1 in mode 0 */
Define_static(mercury__code_util__cannot_stack_flush_cases_1_0);
	MR_incr_sp_push_msg(2, "code_util:cannot_stack_flush_cases/1");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_cases_1_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 0);
	call_localret(STATIC(mercury__code_util__cannot_stack_flush_2_1_0),
		mercury__code_util__cannot_stack_flush_cases_1_0_i4,
		STATIC(mercury__code_util__cannot_stack_flush_cases_1_0));
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_stack_flush_cases_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__code_util__cannot_stack_flush_cases_1_0_i1002);
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__code_util__cannot_stack_flush_cases_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module29)
	init_entry(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i7);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i5);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i11);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i12);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i2);
	init_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
BEGIN_CODE

/* code for predicate 'cannot_fail_before_stack_flush_conj'/1 in mode 0 */
Define_static(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0);
	MR_incr_sp_push_msg(3, "code_util:cannot_fail_before_stack_flush_conj/1");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i2);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 3) == (Integer) 0))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i5);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i7);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i5);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i11,
		STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i12,
		STATIC(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i12);
	update_prof_current_proc(LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1005);
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__code_util__cannot_fail_before_stack_flush_conj_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__int__min_3_0);
Declare_entry(mercury__int__max_3_0);

BEGIN_MODULE(code_util_module30)
	init_entry(mercury__code_util__count_recursive_calls_2_5_0);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i1003);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i6);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i8);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i10);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i14);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i15);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i18);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i20);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i22);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i24);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i25);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i26);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i27);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i28);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i1005);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i30);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i31);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i33);
	init_label(mercury__code_util__count_recursive_calls_2_5_0_i34);
BEGIN_CODE

/* code for predicate 'count_recursive_calls_2'/5 in mode 0 */
Define_static(mercury__code_util__count_recursive_calls_2_5_0);
	MR_incr_sp_push_msg(6, "code_util:count_recursive_calls_2/5");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i1003) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i6) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i1005) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i14));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i1003);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_conj_7_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__code_util__count_recursive_calls_2_5_0_i8,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
	}
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_2_5_0_i30);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__code_util__count_recursive_calls_2_5_0_i10,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_2_5_0_i30);
	r1 = (Integer) 1;
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i15) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i30) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i18) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i20) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i22) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i24) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i30) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i31) AND
		LABEL(mercury__code_util__count_recursive_calls_2_5_0_i33));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_cases_5_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i18);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_disj_5_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i20);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_5_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i22);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_5_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i24);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__code_util__count_recursive_calls_5_0),
		mercury__code_util__count_recursive_calls_2_5_0_i25,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(5) = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__code_util__count_recursive_calls_5_0),
		mercury__code_util__count_recursive_calls_2_5_0_i26,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
	}
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__code_util__count_recursive_calls_5_0),
		mercury__code_util__count_recursive_calls_2_5_0_i27,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	r3 = r1;
	r1 = ((Integer) MR_stackvar(3) + (Integer) MR_stackvar(1));
	MR_stackvar(1) = r2;
	r2 = r3;
	MR_stackvar(2) = ((Integer) MR_stackvar(5) + (Integer) MR_stackvar(2));
	call_localret(ENTRY(mercury__int__min_3_0),
		mercury__code_util__count_recursive_calls_2_5_0_i28,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__code_util__count_recursive_calls_2_5_0_i34,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i1005);
	r1 = (Integer) 0;
	r2 = (Integer) 0;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i30);
	r1 = (Integer) 0;
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i31);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_conj_7_0),
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i33);
	r1 = (Word) MR_string_const("code_util__count_recursive_calls_2: unexpected bi_implication", 61);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__count_recursive_calls_2_5_0_i34,
		STATIC(mercury__code_util__count_recursive_calls_2_5_0));
Define_label(mercury__code_util__count_recursive_calls_2_5_0_i34);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module31)
	init_entry(mercury__code_util__count_recursive_calls_conj_7_0);
	init_label(mercury__code_util__count_recursive_calls_conj_7_0_i1001);
	init_label(mercury__code_util__count_recursive_calls_conj_7_0_i4);
	init_label(mercury__code_util__count_recursive_calls_conj_7_0_i3);
BEGIN_CODE

/* code for predicate 'count_recursive_calls_conj'/7 in mode 0 */
Define_static(mercury__code_util__count_recursive_calls_conj_7_0);
	MR_incr_sp_push_msg(6, "code_util:count_recursive_calls_conj/7");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__code_util__count_recursive_calls_conj_7_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_conj_7_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		mercury__code_util__count_recursive_calls_conj_7_0_i4,
		STATIC(mercury__code_util__count_recursive_calls_conj_7_0));
Define_label(mercury__code_util__count_recursive_calls_conj_7_0_i4);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_conj_7_0));
	r4 = ((Integer) MR_stackvar(3) + (Integer) r1);
	r5 = ((Integer) MR_stackvar(4) + (Integer) r2);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__code_util__count_recursive_calls_conj_7_0_i1001);
Define_label(mercury__code_util__count_recursive_calls_conj_7_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module32)
	init_entry(mercury__code_util__count_recursive_calls_disj_5_0);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i1003);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i4);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i7);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i8);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i9);
	init_label(mercury__code_util__count_recursive_calls_disj_5_0_i10);
BEGIN_CODE

/* code for predicate 'count_recursive_calls_disj'/5 in mode 0 */
Define_static(mercury__code_util__count_recursive_calls_disj_5_0);
	MR_incr_sp_push_msg(4, "code_util:count_recursive_calls_disj/5");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_disj_5_0_i1003);
	r1 = (Integer) 0;
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i1003);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_disj_5_0_i4);
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		STATIC(mercury__code_util__count_recursive_calls_disj_5_0));
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	call_localret(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		mercury__code_util__count_recursive_calls_disj_5_0_i7,
		STATIC(mercury__code_util__count_recursive_calls_disj_5_0));
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i7);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_disj_5_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	localcall(mercury__code_util__count_recursive_calls_disj_5_0,
		LABEL(mercury__code_util__count_recursive_calls_disj_5_0_i8),
		STATIC(mercury__code_util__count_recursive_calls_disj_5_0));
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_disj_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__int__min_3_0),
		mercury__code_util__count_recursive_calls_disj_5_0_i9,
		STATIC(mercury__code_util__count_recursive_calls_disj_5_0));
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_disj_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__code_util__count_recursive_calls_disj_5_0_i10,
		STATIC(mercury__code_util__count_recursive_calls_disj_5_0));
Define_label(mercury__code_util__count_recursive_calls_disj_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_disj_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module33)
	init_entry(mercury__code_util__count_recursive_calls_cases_5_0);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i1003);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i5);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i8);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i9);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i10);
	init_label(mercury__code_util__count_recursive_calls_cases_5_0_i11);
BEGIN_CODE

/* code for predicate 'count_recursive_calls_cases'/5 in mode 0 */
Define_static(mercury__code_util__count_recursive_calls_cases_5_0);
	MR_incr_sp_push_msg(4, "code_util:count_recursive_calls_cases/5");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_cases_5_0_i1003);
	r1 = (Word) MR_string_const("empty cases in code_util__count_recursive_calls_cases", 53);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__code_util__count_recursive_calls_cases_5_0_i11,
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i1003);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__code_util__count_recursive_calls_cases_5_0_i5);
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i5);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	call_localret(STATIC(mercury__code_util__count_recursive_calls_2_5_0),
		mercury__code_util__count_recursive_calls_cases_5_0_i8,
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i8);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_cases_5_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	localcall(mercury__code_util__count_recursive_calls_cases_5_0,
		LABEL(mercury__code_util__count_recursive_calls_cases_5_0_i9),
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i9);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_cases_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__int__min_3_0),
		mercury__code_util__count_recursive_calls_cases_5_0_i10,
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i10);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_cases_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__code_util__count_recursive_calls_cases_5_0_i11,
		STATIC(mercury__code_util__count_recursive_calls_cases_5_0));
Define_label(mercury__code_util__count_recursive_calls_cases_5_0_i11);
	update_prof_current_proc(LABEL(mercury__code_util__count_recursive_calls_cases_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(code_util_module34)
	init_entry(mercury__code_util__lvals_in_mem_ref_2_0);
	init_label(mercury__code_util__lvals_in_mem_ref_2_0_i1001);
	init_label(mercury__code_util__lvals_in_mem_ref_2_0_i5);
BEGIN_CODE

/* code for predicate 'lvals_in_mem_ref'/2 in mode 0 */
Define_static(mercury__code_util__lvals_in_mem_ref_2_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__code_util__lvals_in_mem_ref_2_0_i1001);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__code_util__lvals_in_mem_ref_2_0_i5);
Define_label(mercury__code_util__lvals_in_mem_ref_2_0_i1001);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__code_util__lvals_in_mem_ref_2_0_i5);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	tailcall(STATIC(mercury__code_util__lvals_in_rval_2_0),
		STATIC(mercury__code_util__lvals_in_mem_ref_2_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__code_util_maybe_bunch_0(void)
{
	code_util_module0();
	code_util_module1();
	code_util_module2();
	code_util_module3();
	code_util_module4();
	code_util_module5();
	code_util_module6();
	code_util_module7();
	code_util_module8();
	code_util_module9();
	code_util_module10();
	code_util_module11();
	code_util_module12();
	code_util_module13();
	code_util_module14();
	code_util_module15();
	code_util_module16();
	code_util_module17();
	code_util_module18();
	code_util_module19();
	code_util_module20();
	code_util_module21();
	code_util_module22();
	code_util_module23();
	code_util_module24();
	code_util_module25();
	code_util_module26();
	code_util_module27();
	code_util_module28();
	code_util_module29();
	code_util_module30();
	code_util_module31();
	code_util_module32();
	code_util_module33();
	code_util_module34();
}

#endif

void mercury__code_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__code_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__code_util_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
