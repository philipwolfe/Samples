/*
** Automatically generated from `commit_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__commit_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__commit_gen__generate_commit_5_0);
Declare_label(mercury__commit_gen__generate_commit_5_0_i2);
Declare_label(mercury__commit_gen__generate_commit_5_0_i6);
Declare_label(mercury__commit_gen__generate_commit_5_0_i8);
Declare_label(mercury__commit_gen__generate_commit_5_0_i10);
Declare_label(mercury__commit_gen__generate_commit_5_0_i11);
Declare_label(mercury__commit_gen__generate_commit_5_0_i4);
Declare_label(mercury__commit_gen__generate_commit_5_0_i15);
Declare_label(mercury__commit_gen__generate_commit_5_0_i1005);
Declare_label(mercury__commit_gen__generate_commit_5_0_i17);
Declare_label(mercury__commit_gen__generate_commit_5_0_i19);
Declare_label(mercury__commit_gen__generate_commit_5_0_i20);
Declare_label(mercury__commit_gen__generate_commit_5_0_i21);

Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__code_info__prepare_for_det_commit_4_0);
Declare_entry(mercury__code_info__generate_det_commit_4_0);
Declare_entry(mercury__code_info__prepare_for_semi_commit_4_0);
Declare_entry(mercury__code_info__generate_semi_commit_4_0);

BEGIN_MODULE(commit_gen_module0)
	init_entry(mercury__commit_gen__generate_commit_5_0);
	init_label(mercury__commit_gen__generate_commit_5_0_i2);
	init_label(mercury__commit_gen__generate_commit_5_0_i6);
	init_label(mercury__commit_gen__generate_commit_5_0_i8);
	init_label(mercury__commit_gen__generate_commit_5_0_i10);
	init_label(mercury__commit_gen__generate_commit_5_0_i11);
	init_label(mercury__commit_gen__generate_commit_5_0_i4);
	init_label(mercury__commit_gen__generate_commit_5_0_i15);
	init_label(mercury__commit_gen__generate_commit_5_0_i1005);
	init_label(mercury__commit_gen__generate_commit_5_0_i17);
	init_label(mercury__commit_gen__generate_commit_5_0_i19);
	init_label(mercury__commit_gen__generate_commit_5_0_i20);
	init_label(mercury__commit_gen__generate_commit_5_0_i21);
BEGIN_CODE

/* code for predicate 'generate_commit'/5 in mode 0 */
Define_entry(mercury__commit_gen__generate_commit_5_0);
	MR_incr_sp_push_msg(4, "commit_gen:generate_commit/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__commit_gen__generate_commit_5_0_i2,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i2);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i4);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__code_gen__generate_goal_5_0),
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i6);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i8);
	r1 = (Word) MR_string_const("semidet model in det context", 28);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i8);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__prepare_for_det_commit_4_0),
		mercury__commit_gen__generate_commit_5_0_i10,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i10);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_tempr2 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr2;
	MR_stackvar(1) = MR_tempr1;
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__commit_gen__generate_commit_5_0_i11,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
	}
Define_label(mercury__commit_gen__generate_commit_5_0_i11);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__code_info__generate_det_commit_4_0),
		mercury__commit_gen__generate_commit_5_0_i21,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i4);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i1005);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i15);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__code_gen__generate_goal_5_0),
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i15);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__commit_gen__generate_commit_5_0_i17);
Define_label(mercury__commit_gen__generate_commit_5_0_i1005);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__code_gen__generate_goal_5_0),
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i17);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__prepare_for_semi_commit_4_0),
		mercury__commit_gen__generate_commit_5_0_i19,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i19);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_tempr2 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr2;
	MR_stackvar(1) = MR_tempr1;
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__commit_gen__generate_commit_5_0_i20,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
	}
Define_label(mercury__commit_gen__generate_commit_5_0_i20);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__code_info__generate_semi_commit_4_0),
		mercury__commit_gen__generate_commit_5_0_i21,
		ENTRY(mercury__commit_gen__generate_commit_5_0));
Define_label(mercury__commit_gen__generate_commit_5_0_i21);
	update_prof_current_proc(LABEL(mercury__commit_gen__generate_commit_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__commit_gen__generate_commit_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__commit_gen__generate_commit_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__commit_gen_maybe_bunch_0(void)
{
	commit_gen_module0();
}

#endif

void mercury__commit_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__commit_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__commit_gen_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
