/*
** Automatically generated from `common.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__common__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___common__call_args_0__ua0_2_0);
Declare_static(mercury____Index___common__structure_0__ua0_2_0);
Declare_static(mercury____Index___common__common_info_0__ua0_2_0);
Declare_static(mercury__common__optimise_unification__ua0_11_0);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i4);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i5);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i6);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i11);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i7);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i14);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i15);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i17);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i18);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i19);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i21);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i23);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i24);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i25);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i26);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i13);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i30);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i31);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i33);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i36);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i32);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i39);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i40);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i41);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i43);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i45);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i46);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i47);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i38);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i52);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i54);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i56);
Declare_label(mercury__common__optimise_unification__ua0_11_0_i55);
Define_extern_entry(mercury__common__optimise_unification_11_0);
Define_extern_entry(mercury__common__optimise_call_8_0);
Declare_label(mercury__common__optimise_call_8_0_i3);
Declare_label(mercury__common__optimise_call_8_0_i4);
Declare_label(mercury__common__optimise_call_8_0_i6);
Declare_label(mercury__common__optimise_call_8_0_i5);
Declare_label(mercury__common__optimise_call_8_0_i8);
Declare_label(mercury__common__optimise_call_8_0_i9);
Declare_label(mercury__common__optimise_call_8_0_i10);
Declare_label(mercury__common__optimise_call_8_0_i11);
Declare_label(mercury__common__optimise_call_8_0_i2);
Define_extern_entry(mercury__common__optimise_higher_order_call_9_0);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i3);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i5);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i4);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i7);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i8);
Declare_label(mercury__common__optimise_higher_order_call_9_0_i2);
Define_extern_entry(mercury__common__vars_are_equivalent_3_0);
Declare_label(mercury__common__vars_are_equivalent_3_0_i4);
Declare_label(mercury__common__vars_are_equivalent_3_0_i6);
Declare_label(mercury__common__vars_are_equivalent_3_0_i8);
Declare_label(mercury__common__vars_are_equivalent_3_0_i2);
Declare_label(mercury__common__vars_are_equivalent_3_0_i1);
Define_extern_entry(mercury__common__common_info_init_1_0);
Declare_label(mercury__common__common_info_init_1_0_i2);
Declare_label(mercury__common__common_info_init_1_0_i3);
Declare_label(mercury__common__common_info_init_1_0_i4);
Define_extern_entry(mercury__common__common_info_clear_structs_2_0);
Declare_label(mercury__common__common_info_clear_structs_2_0_i2);
Declare_static(mercury__common__find_matching_cell_2_8_0);
Declare_label(mercury__common__find_matching_cell_2_8_0_i1011);
Declare_label(mercury__common__find_matching_cell_2_8_0_i4);
Declare_label(mercury__common__find_matching_cell_2_8_0_i10);
Declare_label(mercury__common__find_matching_cell_2_8_0_i9);
Declare_label(mercury__common__find_matching_cell_2_8_0_i12);
Declare_label(mercury__common__find_matching_cell_2_8_0_i14);
Declare_label(mercury__common__find_matching_cell_2_8_0_i16);
Declare_label(mercury__common__find_matching_cell_2_8_0_i7);
Declare_label(mercury__common__find_matching_cell_2_8_0_i18);
Declare_label(mercury__common__find_matching_cell_2_8_0_i20);
Declare_label(mercury__common__find_matching_cell_2_8_0_i21);
Declare_label(mercury__common__find_matching_cell_2_8_0_i23);
Declare_label(mercury__common__find_matching_cell_2_8_0_i25);
Declare_label(mercury__common__find_matching_cell_2_8_0_i3);
Declare_label(mercury__common__find_matching_cell_2_8_0_i1);
Declare_static(mercury__common__var_lists_are_equiv_3_0);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i1007);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i3);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i8);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i7);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i10);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i12);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i14);
Declare_label(mercury__common__var_lists_are_equiv_3_0_i1);
Declare_static(mercury__common__record_cell_5_0);
Declare_label(mercury__common__record_cell_5_0_i2);
Declare_label(mercury__common__record_cell_5_0_i3);
Declare_label(mercury__common__record_cell_5_0_i4);
Declare_label(mercury__common__record_cell_5_0_i6);
Declare_label(mercury__common__record_cell_5_0_i8);
Declare_label(mercury__common__record_cell_5_0_i7);
Declare_label(mercury__common__record_cell_5_0_i10);
Declare_label(mercury__common__record_cell_5_0_i11);
Declare_label(mercury__common__record_cell_5_0_i13);
Declare_label(mercury__common__record_cell_5_0_i12);
Declare_label(mercury__common__record_cell_5_0_i16);
Declare_static(mercury__common__record_equivalence_4_0);
Declare_label(mercury__common__record_equivalence_4_0_i2);
Declare_label(mercury__common__record_equivalence_4_0_i3);
Declare_static(mercury__common__optimise_call_2_9_0);
Declare_label(mercury__common__optimise_call_2_9_0_i2);
Declare_label(mercury__common__optimise_call_2_9_0_i4);
Declare_label(mercury__common__optimise_call_2_9_0_i8);
Declare_label(mercury__common__optimise_call_2_9_0_i10);
Declare_label(mercury__common__optimise_call_2_9_0_i11);
Declare_label(mercury__common__optimise_call_2_9_0_i12);
Declare_label(mercury__common__optimise_call_2_9_0_i13);
Declare_label(mercury__common__optimise_call_2_9_0_i15);
Declare_label(mercury__common__optimise_call_2_9_0_i17);
Declare_label(mercury__common__optimise_call_2_9_0_i18);
Declare_label(mercury__common__optimise_call_2_9_0_i19);
Declare_label(mercury__common__optimise_call_2_9_0_i21);
Declare_label(mercury__common__optimise_call_2_9_0_i22);
Declare_label(mercury__common__optimise_call_2_9_0_i14);
Declare_label(mercury__common__optimise_call_2_9_0_i24);
Declare_label(mercury__common__optimise_call_2_9_0_i25);
Declare_label(mercury__common__optimise_call_2_9_0_i26);
Declare_label(mercury__common__optimise_call_2_9_0_i6);
Declare_label(mercury__common__optimise_call_2_9_0_i27);
Declare_label(mercury__common__optimise_call_2_9_0_i3);
Declare_label(mercury__common__optimise_call_2_9_0_i30);
Declare_label(mercury__common__optimise_call_2_9_0_i31);
Declare_label(mercury__common__optimise_call_2_9_0_i33);
Declare_static(mercury__common__partition_call_args_6_0);
Declare_label(mercury__common__partition_call_args_6_0_i5);
Declare_label(mercury__common__partition_call_args_6_0_i3);
Declare_label(mercury__common__partition_call_args_6_0_i9);
Declare_label(mercury__common__partition_call_args_6_0_i8);
Declare_label(mercury__common__partition_call_args_6_0_i10);
Declare_label(mercury__common__partition_call_args_6_0_i12);
Declare_label(mercury__common__partition_call_args_6_0_i15);
Declare_label(mercury__common__partition_call_args_6_0_i13);
Declare_label(mercury__common__partition_call_args_6_0_i17);
Declare_label(mercury__common__partition_call_args_6_0_i19);
Declare_label(mercury__common__partition_call_args_6_0_i21);
Declare_label(mercury__common__partition_call_args_6_0_i1);
Declare_static(mercury__common__find_previous_call_5_0);
Declare_label(mercury__common__find_previous_call_5_0_i5);
Declare_label(mercury__common__find_previous_call_5_0_i3);
Declare_label(mercury__common__find_previous_call_5_0_i7);
Declare_label(mercury__common__find_previous_call_5_0_i9);
Declare_label(mercury__common__find_previous_call_5_0_i1005);
Declare_label(mercury__common__find_previous_call_5_0_i1);
Declare_static(mercury__common__create_output_unifications_7_0);
Declare_label(mercury__common__create_output_unifications_7_0_i1007);
Declare_label(mercury__common__create_output_unifications_7_0_i9);
Declare_label(mercury__common__create_output_unifications_7_0_i11);
Declare_label(mercury__common__create_output_unifications_7_0_i12);
Declare_label(mercury__common__create_output_unifications_7_0_i6);
Declare_label(mercury__common__create_output_unifications_7_0_i2);
Declare_label(mercury__common__create_output_unifications_7_0_i15);
Declare_static(mercury__common__generate_assign_7_0);
Declare_label(mercury__common__generate_assign_7_0_i2);
Declare_label(mercury__common__generate_assign_7_0_i3);
Declare_label(mercury__common__generate_assign_7_0_i4);
Declare_label(mercury__common__generate_assign_7_0_i5);
Declare_label(mercury__common__generate_assign_7_0_i6);
Declare_label(mercury__common__generate_assign_7_0_i14);
Declare_label(mercury__common__generate_assign_7_0_i11);
Declare_label(mercury__common__generate_assign_7_0_i16);
Declare_label(mercury__common__generate_assign_7_0_i18);
Declare_label(mercury__common__generate_assign_7_0_i20);
Declare_label(mercury__common__generate_assign_7_0_i22);
Declare_label(mercury__common__generate_assign_7_0_i9);
Declare_label(mercury__common__generate_assign_7_0_i7);
Declare_label(mercury__common__generate_assign_7_0_i25);
Declare_label(mercury__common__generate_assign_7_0_i26);
Declare_label(mercury__common__generate_assign_7_0_i27);
Declare_label(mercury__common__generate_assign_7_0_i29);
Declare_label(mercury__common__generate_assign_7_0_i32);
Declare_label(mercury__common__generate_assign_7_0_i34);
Declare_label(mercury__common__generate_assign_7_0_i28);
Declare_label(mercury__common__generate_assign_7_0_i35);
Declare_label(mercury__common__generate_assign_7_0_i36);
Declare_label(mercury__common__generate_assign_7_0_i37);
Declare_label(mercury__common__generate_assign_7_0_i39);
Declare_label(mercury__common__generate_assign_7_0_i40);
Declare_static(mercury__common__types_match_exactly_list_2_0);
Declare_label(mercury__common__types_match_exactly_list_2_0_i1010);
Declare_label(mercury__common__types_match_exactly_list_2_0_i3);
Declare_label(mercury__common__types_match_exactly_list_2_0_i11);
Declare_label(mercury__common__types_match_exactly_list_2_0_i7);
Declare_label(mercury__common__types_match_exactly_list_2_0_i8);
Declare_label(mercury__common__types_match_exactly_list_2_0_i13);
Declare_label(mercury__common__types_match_exactly_list_2_0_i15);
Declare_label(mercury__common__types_match_exactly_list_2_0_i17);
Declare_label(mercury__common__types_match_exactly_list_2_0_i19);
Declare_label(mercury__common__types_match_exactly_list_2_0_i1);
Define_extern_entry(mercury____Unify___common__common_info_0_0);
Declare_label(mercury____Unify___common__common_info_0_0_i2);
Declare_label(mercury____Unify___common__common_info_0_0_i4);
Declare_label(mercury____Unify___common__common_info_0_0_i6);
Declare_label(mercury____Unify___common__common_info_0_0_i1);
Define_extern_entry(mercury____Index___common__common_info_0_0);
Define_extern_entry(mercury____Compare___common__common_info_0_0);
Declare_label(mercury____Compare___common__common_info_0_0_i3);
Declare_label(mercury____Compare___common__common_info_0_0_i7);
Declare_label(mercury____Compare___common__common_info_0_0_i11);
Declare_label(mercury____Compare___common__common_info_0_0_i17);
Declare_static(mercury____Unify___common__structure_0_0);
Declare_label(mercury____Unify___common__structure_0_0_i2);
Declare_label(mercury____Unify___common__structure_0_0_i4);
Declare_label(mercury____Unify___common__structure_0_0_i6);
Declare_label(mercury____Unify___common__structure_0_0_i1);
Declare_static(mercury____Index___common__structure_0_0);
Declare_static(mercury____Compare___common__structure_0_0);
Declare_label(mercury____Compare___common__structure_0_0_i3);
Declare_label(mercury____Compare___common__structure_0_0_i7);
Declare_label(mercury____Compare___common__structure_0_0_i11);
Declare_label(mercury____Compare___common__structure_0_0_i17);
Declare_static(mercury____Unify___common__call_args_0_0);
Declare_label(mercury____Unify___common__call_args_0_0_i2);
Declare_label(mercury____Unify___common__call_args_0_0_i4);
Declare_label(mercury____Unify___common__call_args_0_0_i1);
Declare_static(mercury____Index___common__call_args_0_0);
Declare_static(mercury____Compare___common__call_args_0_0);
Declare_label(mercury____Compare___common__call_args_0_0_i3);
Declare_label(mercury____Compare___common__call_args_0_0_i7);
Declare_label(mercury____Compare___common__call_args_0_0_i12);
Declare_static(mercury____Unify___common__struct_map_0_0);
Declare_static(mercury____Index___common__struct_map_0_0);
Declare_static(mercury____Compare___common__struct_map_0_0);
Declare_static(mercury____Unify___common__seen_calls_0_0);
Declare_static(mercury____Index___common__seen_calls_0_0);
Declare_static(mercury____Compare___common__seen_calls_0_0);
Declare_static(mercury____Unify___common__unification_type_0_0);
Declare_label(mercury____Unify___common__unification_type_0_0_i1);
Declare_static(mercury____Index___common__unification_type_0_0);
Declare_static(mercury____Compare___common__unification_type_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_call_args_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_common_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_seen_calls_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_struct_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_structure_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_unification_type_0;

static const struct mercury_data_common__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_0;

static const struct mercury_data_common__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_1;

static const struct mercury_data_common__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_2;

static const struct mercury_data_common__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_3;

static const struct mercury_data_common__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_4;

static const struct mercury_data_common__common_5_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_common__common_5;

static const struct mercury_data_common__common_6_struct {
	Word * f1;
}  mercury_data_common__common_6;

static const struct mercury_data_common__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_7;

static const struct mercury_data_common__common_8_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_common__common_8;

static const struct mercury_data_common__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_common__common_9;

static const struct mercury_data_common__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_common__common_10;

static const struct mercury_data_common__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_common__common_11;

static const struct mercury_data_common__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_common__common_12;

static const struct mercury_data_common__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_common__common_13;

static const struct mercury_data_common__common_14_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_common__common_14;

static const struct mercury_data_common__common_15_struct {
	Word * f1;
}  mercury_data_common__common_15;

static const struct mercury_data_common__common_16_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_common__common_16;

static const struct mercury_data_common__type_ctor_functors_unification_type_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_common__type_ctor_functors_unification_type_0;

static const struct mercury_data_common__type_ctor_layout_unification_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_unification_type_0;

static const struct mercury_data_common__type_ctor_functors_structure_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_common__type_ctor_functors_structure_0;

static const struct mercury_data_common__type_ctor_layout_structure_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_structure_0;

static const struct mercury_data_common__type_ctor_functors_struct_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_common__type_ctor_functors_struct_map_0;

static const struct mercury_data_common__type_ctor_layout_struct_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_struct_map_0;

static const struct mercury_data_common__type_ctor_functors_seen_calls_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_common__type_ctor_functors_seen_calls_0;

static const struct mercury_data_common__type_ctor_layout_seen_calls_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_seen_calls_0;

static const struct mercury_data_common__type_ctor_functors_common_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_common__type_ctor_functors_common_info_0;

static const struct mercury_data_common__type_ctor_layout_common_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_common_info_0;

static const struct mercury_data_common__type_ctor_functors_call_args_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_common__type_ctor_functors_call_args_0;

static const struct mercury_data_common__type_ctor_layout_call_args_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_common__type_ctor_layout_call_args_0;

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_call_args_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___common__call_args_0_0),
	STATIC(mercury____Index___common__call_args_0_0),
	STATIC(mercury____Compare___common__call_args_0_0),
	(Integer) 2,
	(Word *) &mercury_data_common__type_ctor_functors_call_args_0,
	(Word *) &mercury_data_common__type_ctor_layout_call_args_0,
	MR_string_const("common", 6),
	MR_string_const("call_args", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_common_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___common__common_info_0_0),
	ENTRY(mercury____Index___common__common_info_0_0),
	ENTRY(mercury____Compare___common__common_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_common__type_ctor_functors_common_info_0,
	(Word *) &mercury_data_common__type_ctor_layout_common_info_0,
	MR_string_const("common", 6),
	MR_string_const("common_info", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_seen_calls_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___common__seen_calls_0_0),
	STATIC(mercury____Index___common__seen_calls_0_0),
	STATIC(mercury____Compare___common__seen_calls_0_0),
	(Integer) 6,
	(Word *) &mercury_data_common__type_ctor_functors_seen_calls_0,
	(Word *) &mercury_data_common__type_ctor_layout_seen_calls_0,
	MR_string_const("common", 6),
	MR_string_const("seen_calls", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_struct_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___common__struct_map_0_0),
	STATIC(mercury____Index___common__struct_map_0_0),
	STATIC(mercury____Compare___common__struct_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_common__type_ctor_functors_struct_map_0,
	(Word *) &mercury_data_common__type_ctor_layout_struct_map_0,
	MR_string_const("common", 6),
	MR_string_const("struct_map", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_structure_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___common__structure_0_0),
	STATIC(mercury____Index___common__structure_0_0),
	STATIC(mercury____Compare___common__structure_0_0),
	(Integer) 2,
	(Word *) &mercury_data_common__type_ctor_functors_structure_0,
	(Word *) &mercury_data_common__type_ctor_layout_structure_0,
	MR_string_const("common", 6),
	MR_string_const("structure", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_common__type_ctor_info_unification_type_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___common__unification_type_0_0),
	STATIC(mercury____Index___common__unification_type_0_0),
	STATIC(mercury____Compare___common__unification_type_0_0),
	(Integer) 0,
	(Word *) &mercury_data_common__type_ctor_functors_unification_type_0,
	(Word *) &mercury_data_common__type_ctor_layout_unification_type_0,
	MR_string_const("common", 6),
	MR_string_const("unification_type", 16),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_common__common_0_struct mercury_data_common__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_common__type_ctor_info_structure_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_common__common_1_struct mercury_data_common__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_common__common_2_struct mercury_data_common__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_common__type_ctor_info_call_args_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_common__common_3_struct mercury_data_common__common_3 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_common__common_4_struct mercury_data_common__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_common__common_5_struct mercury_data_common__common_5 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("deconstruction", 14),
	MR_string_const("construction", 12)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_common__common_6_struct mercury_data_common__common_6 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

static const struct mercury_data_common__common_7_struct mercury_data_common__common_7 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1)
};

static const struct mercury_data_common__common_8_struct mercury_data_common__common_8 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_7),
	MR_string_const("structure", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_common__common_9_struct mercury_data_common__common_9 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0)
};

static const struct mercury_data_common__common_10_struct mercury_data_common__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_9)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_det_report__type_ctor_info_seen_call_id_0;
static const struct mercury_data_common__common_11_struct mercury_data_common__common_11 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2)
};

static const struct mercury_data_common__common_12_struct mercury_data_common__common_12 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_11)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_eqvclass__type_ctor_info_eqvclass_1;
static const struct mercury_data_common__common_13_struct mercury_data_common__common_13 = {
	(Word *) &mercury_data_eqvclass__type_ctor_info_eqvclass_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1)
};

static const struct mercury_data_common__common_14_struct mercury_data_common__common_14 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_11),
	MR_string_const("common", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_common__common_15_struct mercury_data_common__common_15 = {
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_common__common_16_struct mercury_data_common__common_16 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_7),
	MR_string_const("call_args", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_common__type_ctor_functors_unification_type_0_struct mercury_data_common__type_ctor_functors_unification_type_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_5)
};

static const struct mercury_data_common__type_ctor_layout_unification_type_0_struct mercury_data_common__type_ctor_layout_unification_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_5)
};

static const struct mercury_data_common__type_ctor_functors_structure_0_struct mercury_data_common__type_ctor_functors_structure_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_8)
};

static const struct mercury_data_common__type_ctor_layout_structure_0_struct mercury_data_common__type_ctor_layout_structure_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_common__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_common__type_ctor_functors_struct_map_0_struct mercury_data_common__type_ctor_functors_struct_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_9)
};

static const struct mercury_data_common__type_ctor_layout_struct_map_0_struct mercury_data_common__type_ctor_layout_struct_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_10)
};

static const struct mercury_data_common__type_ctor_functors_seen_calls_0_struct mercury_data_common__type_ctor_functors_seen_calls_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_11)
};

static const struct mercury_data_common__type_ctor_layout_seen_calls_0_struct mercury_data_common__type_ctor_layout_seen_calls_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_common__common_12)
};

static const struct mercury_data_common__type_ctor_functors_common_info_0_struct mercury_data_common__type_ctor_functors_common_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_14)
};

static const struct mercury_data_common__type_ctor_layout_common_info_0_struct mercury_data_common__type_ctor_layout_common_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_common__common_14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_common__type_ctor_functors_call_args_0_struct mercury_data_common__type_ctor_functors_call_args_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_16)
};

static const struct mercury_data_common__type_ctor_layout_call_args_0_struct mercury_data_common__type_ctor_layout_call_args_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_common__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(common_module0)
	init_entry(mercury____Index___common__call_args_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___common__call_args_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___common__call_args_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(common_module1)
	init_entry(mercury____Index___common__structure_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___common__structure_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___common__structure_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(common_module2)
	init_entry(mercury____Index___common__common_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___common__common_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___common__common_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__simplify__simplify_info_get_module_info_2_0);
Declare_entry(mercury__mode_util__mode_get_insts_4_0);
Declare_entry(mercury__inst_match__inst_is_ground_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__instmap_delta_search_var_3_0);
Declare_entry(mercury__simplify__simplify_info_get_common_info_2_0);
Declare_entry(mercury__simplify__simplify_info_get_var_types_2_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__simplify__simplify_info_set_requantify_2_0);
Declare_entry(mercury__pd_cost__goal_2_0);
Declare_entry(mercury__simplify__simplify_info_incr_cost_delta_3_0);

BEGIN_MODULE(common_module3)
	init_entry(mercury__common__optimise_unification__ua0_11_0);
	init_label(mercury__common__optimise_unification__ua0_11_0_i4);
	init_label(mercury__common__optimise_unification__ua0_11_0_i5);
	init_label(mercury__common__optimise_unification__ua0_11_0_i6);
	init_label(mercury__common__optimise_unification__ua0_11_0_i11);
	init_label(mercury__common__optimise_unification__ua0_11_0_i7);
	init_label(mercury__common__optimise_unification__ua0_11_0_i14);
	init_label(mercury__common__optimise_unification__ua0_11_0_i15);
	init_label(mercury__common__optimise_unification__ua0_11_0_i17);
	init_label(mercury__common__optimise_unification__ua0_11_0_i18);
	init_label(mercury__common__optimise_unification__ua0_11_0_i19);
	init_label(mercury__common__optimise_unification__ua0_11_0_i21);
	init_label(mercury__common__optimise_unification__ua0_11_0_i23);
	init_label(mercury__common__optimise_unification__ua0_11_0_i24);
	init_label(mercury__common__optimise_unification__ua0_11_0_i25);
	init_label(mercury__common__optimise_unification__ua0_11_0_i26);
	init_label(mercury__common__optimise_unification__ua0_11_0_i13);
	init_label(mercury__common__optimise_unification__ua0_11_0_i30);
	init_label(mercury__common__optimise_unification__ua0_11_0_i31);
	init_label(mercury__common__optimise_unification__ua0_11_0_i33);
	init_label(mercury__common__optimise_unification__ua0_11_0_i36);
	init_label(mercury__common__optimise_unification__ua0_11_0_i32);
	init_label(mercury__common__optimise_unification__ua0_11_0_i39);
	init_label(mercury__common__optimise_unification__ua0_11_0_i40);
	init_label(mercury__common__optimise_unification__ua0_11_0_i41);
	init_label(mercury__common__optimise_unification__ua0_11_0_i43);
	init_label(mercury__common__optimise_unification__ua0_11_0_i45);
	init_label(mercury__common__optimise_unification__ua0_11_0_i46);
	init_label(mercury__common__optimise_unification__ua0_11_0_i47);
	init_label(mercury__common__optimise_unification__ua0_11_0_i38);
	init_label(mercury__common__optimise_unification__ua0_11_0_i52);
	init_label(mercury__common__optimise_unification__ua0_11_0_i54);
	init_label(mercury__common__optimise_unification__ua0_11_0_i56);
	init_label(mercury__common__optimise_unification__ua0_11_0_i55);
BEGIN_CODE

/* code for predicate 'optimise_unification__ua0'/11 in mode 0 */
Define_static(mercury__common__optimise_unification__ua0_11_0);
	MR_incr_sp_push_msg(10, "common:optimise_unification__ua0/11");
	MR_stackvar(10) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__common__optimise_unification__ua0_11_0_i4) AND
		LABEL(mercury__common__optimise_unification__ua0_11_0_i30) AND
		LABEL(mercury__common__optimise_unification__ua0_11_0_i52) AND
		LABEL(mercury__common__optimise_unification__ua0_11_0_i54));
Define_label(mercury__common__optimise_unification__ua0_11_0_i4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__optimise_unification__ua0_11_0_i5,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i5);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mode_util__mode_get_insts_4_0),
		mercury__common__optimise_unification__ua0_11_0_i6,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i6);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_2_0),
		mercury__common__optimise_unification__ua0_11_0_i11,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i11);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (r1)
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i7);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__common__optimise_unification__ua0_11_0_i7);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__common__optimise_unification__ua0_11_0_i14,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i14);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__instmap__instmap_delta_search_var_3_0),
		mercury__common__optimise_unification__ua0_11_0_i15,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i15);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i13);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_common_info_2_0),
		mercury__common__optimise_unification__ua0_11_0_i17,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i17);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_var_types_2_0),
		mercury__common__optimise_unification__ua0_11_0_i18,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i18);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__optimise_unification__ua0_11_0_i19,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
	}
Define_label(mercury__common__optimise_unification__ua0_11_0_i19);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i13);
	r1 = r2;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
	r5 = (Integer) 1;
	r6 = MR_stackvar(9);
	r7 = MR_stackvar(4);
	call_localret(STATIC(mercury__common__find_matching_cell_2_8_0),
		mercury__common__optimise_unification__ua0_11_0_i21,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i21);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i13);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__common__optimise_unification__ua0_11_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__common__optimise_unification__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__common__optimise_unification__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	MR_tempr2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_tempr2;
	call_localret(STATIC(mercury__common__generate_assign_7_0),
		mercury__common__optimise_unification__ua0_11_0_i23,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
	}
Define_label(mercury__common__optimise_unification__ua0_11_0_i23);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = r2;
	call_localret(ENTRY(mercury__simplify__simplify_info_set_requantify_2_0),
		mercury__common__optimise_unification__ua0_11_0_i24,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i24);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	MR_stackvar(9) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__common__optimise_unification__ua0_11_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	call_localret(ENTRY(mercury__pd_cost__goal_2_0),
		mercury__common__optimise_unification__ua0_11_0_i25,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i25);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__simplify__simplify_info_incr_cost_delta_3_0),
		mercury__common__optimise_unification__ua0_11_0_i26,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i26);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__common__optimise_unification__ua0_11_0_i13);
	MR_stackvar(1) = MR_stackvar(2);
	MR_stackvar(4) = MR_stackvar(3);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__common__record_cell_5_0),
		mercury__common__optimise_unification__ua0_11_0_i56,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i30);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__optimise_unification__ua0_11_0_i31,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i31);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mode_util__mode_get_insts_4_0),
		mercury__common__optimise_unification__ua0_11_0_i33,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i33);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_2_0),
		mercury__common__optimise_unification__ua0_11_0_i36,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i36);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (r1)
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i32);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__common__optimise_unification__ua0_11_0_i32);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_common_info_2_0),
		mercury__common__optimise_unification__ua0_11_0_i39,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i39);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_var_types_2_0),
		mercury__common__optimise_unification__ua0_11_0_i40,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i40);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__optimise_unification__ua0_11_0_i41,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
	}
Define_label(mercury__common__optimise_unification__ua0_11_0_i41);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i38);
	r1 = r2;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
	r5 = (Integer) 0;
	r6 = MR_stackvar(9);
	r7 = MR_stackvar(1);
	call_localret(STATIC(mercury__common__find_matching_cell_2_8_0),
		mercury__common__optimise_unification__ua0_11_0_i43,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i43);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i38);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	call_localret(STATIC(mercury__common__create_output_unifications_7_0),
		mercury__common__optimise_unification__ua0_11_0_i45,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i45);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__simplify__simplify_info_set_requantify_2_0),
		mercury__common__optimise_unification__ua0_11_0_i46,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i46);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(4) = r1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__common__optimise_unification__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__common__optimise_unification__ua0_11_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	call_localret(ENTRY(mercury__pd_cost__goal_2_0),
		mercury__common__optimise_unification__ua0_11_0_i47,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i47);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__simplify__simplify_info_incr_cost_delta_3_0),
		mercury__common__optimise_unification__ua0_11_0_i56,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i38);
	MR_stackvar(1) = MR_stackvar(2);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__common__record_cell_5_0),
		mercury__common__optimise_unification__ua0_11_0_i56,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i52);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(1) = r3;
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r3 = r5;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__common__record_equivalence_4_0),
		mercury__common__optimise_unification__ua0_11_0_i56,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i54);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__common__optimise_unification__ua0_11_0_i55);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r3;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = r5;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__common__record_equivalence_4_0),
		mercury__common__optimise_unification__ua0_11_0_i56,
		STATIC(mercury__common__optimise_unification__ua0_11_0));
Define_label(mercury__common__optimise_unification__ua0_11_0_i56);
	update_prof_current_proc(LABEL(mercury__common__optimise_unification__ua0_11_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__common__optimise_unification__ua0_11_0_i55);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(common_module4)
	init_entry(mercury__common__optimise_unification_11_0);
BEGIN_CODE

/* code for predicate 'optimise_unification'/11 in mode 0 */
Define_entry(mercury__common__optimise_unification_11_0);
	r2 = r4;
	r3 = r6;
	r4 = r7;
	r5 = r8;
	tailcall(STATIC(mercury__common__optimise_unification__ua0_11_0),
		ENTRY(mercury__common__optimise_unification_11_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);

BEGIN_MODULE(common_module5)
	init_entry(mercury__common__optimise_call_8_0);
	init_label(mercury__common__optimise_call_8_0_i3);
	init_label(mercury__common__optimise_call_8_0_i4);
	init_label(mercury__common__optimise_call_8_0_i6);
	init_label(mercury__common__optimise_call_8_0_i5);
	init_label(mercury__common__optimise_call_8_0_i8);
	init_label(mercury__common__optimise_call_8_0_i9);
	init_label(mercury__common__optimise_call_8_0_i10);
	init_label(mercury__common__optimise_call_8_0_i11);
	init_label(mercury__common__optimise_call_8_0_i2);
BEGIN_CODE

/* code for predicate 'optimise_call'/8 in mode 0 */
Define_entry(mercury__common__optimise_call_8_0);
	MR_incr_sp_push_msg(8, "common:optimise_call/8");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__common__optimise_call_8_0_i3,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i3);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__common__optimise_call_8_0_i4,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__common__optimise_call_8_0_i6);
	r1 = MR_stackvar(6);
	GOTO_LABEL(mercury__common__optimise_call_8_0_i5);
Define_label(mercury__common__optimise_call_8_0_i6);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__common__optimise_call_8_0_i2);
	r1 = MR_stackvar(6);
Define_label(mercury__common__optimise_call_8_0_i5);
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__optimise_call_8_0_i8,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i8);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	MR_stackvar(7) = r1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__common__optimise_call_8_0_i9,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i9);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__common__optimise_call_8_0_i10,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i10);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__common__partition_call_args_6_0),
		mercury__common__optimise_call_8_0_i11,
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i11);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_call_8_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__common__optimise_call_8_0, "det_report:seen_call_id/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__common__optimise_call_2_9_0),
		ENTRY(mercury__common__optimise_call_8_0));
Define_label(mercury__common__optimise_call_8_0_i2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(common_module6)
	init_entry(mercury__common__optimise_higher_order_call_9_0);
	init_label(mercury__common__optimise_higher_order_call_9_0_i3);
	init_label(mercury__common__optimise_higher_order_call_9_0_i5);
	init_label(mercury__common__optimise_higher_order_call_9_0_i4);
	init_label(mercury__common__optimise_higher_order_call_9_0_i7);
	init_label(mercury__common__optimise_higher_order_call_9_0_i8);
	init_label(mercury__common__optimise_higher_order_call_9_0_i2);
BEGIN_CODE

/* code for predicate 'optimise_higher_order_call'/9 in mode 0 */
Define_entry(mercury__common__optimise_higher_order_call_9_0);
	MR_incr_sp_push_msg(7, "common:optimise_higher_order_call/9");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__common__optimise_higher_order_call_9_0_i3,
		ENTRY(mercury__common__optimise_higher_order_call_9_0));
Define_label(mercury__common__optimise_higher_order_call_9_0_i3);
	update_prof_current_proc(LABEL(mercury__common__optimise_higher_order_call_9_0));
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__common__optimise_higher_order_call_9_0_i5);
	r1 = MR_stackvar(6);
	GOTO_LABEL(mercury__common__optimise_higher_order_call_9_0_i4);
Define_label(mercury__common__optimise_higher_order_call_9_0_i5);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__common__optimise_higher_order_call_9_0_i2);
	r1 = MR_stackvar(6);
Define_label(mercury__common__optimise_higher_order_call_9_0_i4);
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__optimise_higher_order_call_9_0_i7,
		ENTRY(mercury__common__optimise_higher_order_call_9_0));
Define_label(mercury__common__optimise_higher_order_call_9_0_i7);
	update_prof_current_proc(LABEL(mercury__common__optimise_higher_order_call_9_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__common__partition_call_args_6_0),
		mercury__common__optimise_higher_order_call_9_0_i8,
		ENTRY(mercury__common__optimise_higher_order_call_9_0));
Define_label(mercury__common__optimise_higher_order_call_9_0_i8);
	update_prof_current_proc(LABEL(mercury__common__optimise_higher_order_call_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_higher_order_call_9_0_i2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__common__optimise_higher_order_call_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__common__optimise_call_2_9_0),
		ENTRY(mercury__common__optimise_higher_order_call_9_0));
	}
Define_label(mercury__common__optimise_higher_order_call_9_0_i2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury__eqvclass__is_member_2_0);
Declare_entry(mercury__eqvclass__same_eqvclass_3_0);

BEGIN_MODULE(common_module7)
	init_entry(mercury__common__vars_are_equivalent_3_0);
	init_label(mercury__common__vars_are_equivalent_3_0_i4);
	init_label(mercury__common__vars_are_equivalent_3_0_i6);
	init_label(mercury__common__vars_are_equivalent_3_0_i8);
	init_label(mercury__common__vars_are_equivalent_3_0_i2);
	init_label(mercury__common__vars_are_equivalent_3_0_i1);
BEGIN_CODE

/* code for predicate 'vars_are_equivalent'/3 in mode 0 */
Define_entry(mercury__common__vars_are_equivalent_3_0);
	MR_incr_sp_push_msg(4, "common:vars_are_equivalent/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r3 = r2;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__vars_are_equivalent_3_0_i4,
		ENTRY(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i4);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (r1)
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__vars_are_equivalent_3_0_i6,
		ENTRY(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i6);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__vars_are_equivalent_3_0_i8,
		ENTRY(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i8);
	update_prof_current_proc(LABEL(mercury__common__vars_are_equivalent_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__vars_are_equivalent_3_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__eqvclass__same_eqvclass_3_0),
		ENTRY(mercury__common__vars_are_equivalent_3_0));
Define_label(mercury__common__vars_are_equivalent_3_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__common__vars_are_equivalent_3_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__eqvclass__init_1_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(common_module8)
	init_entry(mercury__common__common_info_init_1_0);
	init_label(mercury__common__common_info_init_1_0_i2);
	init_label(mercury__common__common_info_init_1_0_i3);
	init_label(mercury__common__common_info_init_1_0_i4);
BEGIN_CODE

/* code for predicate 'common_info_init'/1 in mode 0 */
Define_entry(mercury__common__common_info_init_1_0);
	MR_incr_sp_push_msg(3, "common:common_info_init/1");
	MR_stackvar(3) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	call_localret(ENTRY(mercury__eqvclass__init_1_0),
		mercury__common__common_info_init_1_0_i2,
		ENTRY(mercury__common__common_info_init_1_0));
Define_label(mercury__common__common_info_init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__common__common_info_init_1_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__common__common_info_init_1_0_i3,
		ENTRY(mercury__common__common_info_init_1_0));
Define_label(mercury__common__common_info_init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__common__common_info_init_1_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__common__common_info_init_1_0_i4,
		ENTRY(mercury__common__common_info_init_1_0));
Define_label(mercury__common__common_info_init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__common__common_info_init_1_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__common__common_info_init_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = r2;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(common_module9)
	init_entry(mercury__common__common_info_clear_structs_2_0);
	init_label(mercury__common__common_info_clear_structs_2_0_i2);
BEGIN_CODE

/* code for predicate 'common_info_clear_structs'/2 in mode 0 */
Define_entry(mercury__common__common_info_clear_structs_2_0);
	MR_incr_sp_push_msg(4, "common:common_info_clear_structs/2");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__common__common_info_clear_structs_2_0_i2,
		ENTRY(mercury__common__common_info_clear_structs_2_0));
Define_label(mercury__common__common_info_clear_structs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__common__common_info_clear_structs_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 4, mercury__common__common_info_clear_structs_2_0, "common:common_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(common_module10)
	init_entry(mercury__common__find_matching_cell_2_8_0);
	init_label(mercury__common__find_matching_cell_2_8_0_i1011);
	init_label(mercury__common__find_matching_cell_2_8_0_i4);
	init_label(mercury__common__find_matching_cell_2_8_0_i10);
	init_label(mercury__common__find_matching_cell_2_8_0_i9);
	init_label(mercury__common__find_matching_cell_2_8_0_i12);
	init_label(mercury__common__find_matching_cell_2_8_0_i14);
	init_label(mercury__common__find_matching_cell_2_8_0_i16);
	init_label(mercury__common__find_matching_cell_2_8_0_i7);
	init_label(mercury__common__find_matching_cell_2_8_0_i18);
	init_label(mercury__common__find_matching_cell_2_8_0_i20);
	init_label(mercury__common__find_matching_cell_2_8_0_i21);
	init_label(mercury__common__find_matching_cell_2_8_0_i23);
	init_label(mercury__common__find_matching_cell_2_8_0_i25);
	init_label(mercury__common__find_matching_cell_2_8_0_i3);
	init_label(mercury__common__find_matching_cell_2_8_0_i1);
BEGIN_CODE

/* code for predicate 'find_matching_cell_2'/8 in mode 0 */
Define_static(mercury__common__find_matching_cell_2_8_0);
	MR_incr_sp_push_msg(12, "common:find_matching_cell_2/8");
	MR_stackvar(12) = (Word) MR_succip;
Define_label(mercury__common__find_matching_cell_2_8_0_i1011);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = MR_tempr1;
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__common__find_matching_cell_2_8_0_i4,
		STATIC(mercury__common__find_matching_cell_2_8_0));
	}
Define_label(mercury__common__find_matching_cell_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i7);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__find_matching_cell_2_8_0_i10,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i9);
	r2 = MR_stackvar(7);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__common__find_matching_cell_2_8_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__find_matching_cell_2_8_0_i12,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i12);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__find_matching_cell_2_8_0_i14,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i14);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury__eqvclass__same_eqvclass_3_0),
		mercury__common__find_matching_cell_2_8_0_i16,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i16);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r2 = MR_stackvar(7);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__common__find_matching_cell_2_8_0_i7);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__common__var_lists_are_equiv_3_0),
		mercury__common__find_matching_cell_2_8_0_i18,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i18);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__common__find_matching_cell_2_8_0_i20,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i20);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__find_matching_cell_2_8_0_i21,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i21);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	MR_stackvar(9) = r2;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__find_matching_cell_2_8_0_i23,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i23);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__common__find_matching_cell_2_8_0_i25,
		STATIC(mercury__common__find_matching_cell_2_8_0));
Define_label(mercury__common__find_matching_cell_2_8_0_i25);
	update_prof_current_proc(LABEL(mercury__common__find_matching_cell_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i3);
	r2 = MR_stackvar(7);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__common__find_matching_cell_2_8_0_i3);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__common__find_matching_cell_2_8_0_i1011);
Define_label(mercury__common__find_matching_cell_2_8_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(common_module11)
	init_entry(mercury__common__var_lists_are_equiv_3_0);
	init_label(mercury__common__var_lists_are_equiv_3_0_i1007);
	init_label(mercury__common__var_lists_are_equiv_3_0_i3);
	init_label(mercury__common__var_lists_are_equiv_3_0_i8);
	init_label(mercury__common__var_lists_are_equiv_3_0_i7);
	init_label(mercury__common__var_lists_are_equiv_3_0_i10);
	init_label(mercury__common__var_lists_are_equiv_3_0_i12);
	init_label(mercury__common__var_lists_are_equiv_3_0_i14);
	init_label(mercury__common__var_lists_are_equiv_3_0_i1);
BEGIN_CODE

/* code for predicate 'var_lists_are_equiv'/3 in mode 0 */
Define_static(mercury__common__var_lists_are_equiv_3_0);
	MR_incr_sp_push_msg(6, "common:var_lists_are_equiv/3");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__common__var_lists_are_equiv_3_0_i1007);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__common__var_lists_are_equiv_3_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__var_lists_are_equiv_3_0_i8,
		STATIC(mercury__common__var_lists_are_equiv_3_0));
Define_label(mercury__common__var_lists_are_equiv_3_0_i8);
	update_prof_current_proc(LABEL(mercury__common__var_lists_are_equiv_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i7);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1007);
Define_label(mercury__common__var_lists_are_equiv_3_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__var_lists_are_equiv_3_0_i10,
		STATIC(mercury__common__var_lists_are_equiv_3_0));
Define_label(mercury__common__var_lists_are_equiv_3_0_i10);
	update_prof_current_proc(LABEL(mercury__common__var_lists_are_equiv_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__eqvclass__is_member_2_0),
		mercury__common__var_lists_are_equiv_3_0_i12,
		STATIC(mercury__common__var_lists_are_equiv_3_0));
Define_label(mercury__common__var_lists_are_equiv_3_0_i12);
	update_prof_current_proc(LABEL(mercury__common__var_lists_are_equiv_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__eqvclass__same_eqvclass_3_0),
		mercury__common__var_lists_are_equiv_3_0_i14,
		STATIC(mercury__common__var_lists_are_equiv_3_0));
Define_label(mercury__common__var_lists_are_equiv_3_0_i14);
	update_prof_current_proc(LABEL(mercury__common__var_lists_are_equiv_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__common__var_lists_are_equiv_3_0_i1007);
Define_label(mercury__common__var_lists_are_equiv_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__simplify__simplify_info_set_common_info_3_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(common_module12)
	init_entry(mercury__common__record_cell_5_0);
	init_label(mercury__common__record_cell_5_0_i2);
	init_label(mercury__common__record_cell_5_0_i3);
	init_label(mercury__common__record_cell_5_0_i4);
	init_label(mercury__common__record_cell_5_0_i6);
	init_label(mercury__common__record_cell_5_0_i8);
	init_label(mercury__common__record_cell_5_0_i7);
	init_label(mercury__common__record_cell_5_0_i10);
	init_label(mercury__common__record_cell_5_0_i11);
	init_label(mercury__common__record_cell_5_0_i13);
	init_label(mercury__common__record_cell_5_0_i12);
	init_label(mercury__common__record_cell_5_0_i16);
BEGIN_CODE

/* code for predicate 'record_cell'/5 in mode 0 */
Define_static(mercury__common__record_cell_5_0);
	MR_incr_sp_push_msg(9, "common:record_cell/5");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_common_info_2_0),
		mercury__common__record_cell_5_0_i2,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i2);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_var_types_2_0),
		mercury__common__record_cell_5_0_i3,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i3);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	if (((Integer) MR_stackvar(3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__record_cell_5_0_i4);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__simplify__simplify_info_set_common_info_3_0),
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i4);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r3 = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__common__record_cell_5_0_i6,
		STATIC(mercury__common__record_cell_5_0));
	}
Define_label(mercury__common__record_cell_5_0_i6);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__common__record_cell_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r4 = MR_stackvar(2);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r4;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__record_cell_5_0_i8,
		STATIC(mercury__common__record_cell_5_0));
	}
Define_label(mercury__common__record_cell_5_0_i8);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__record_cell_5_0_i7);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__record_cell_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	GOTO_LABEL(mercury__common__record_cell_5_0_i10);
Define_label(mercury__common__record_cell_5_0_i7);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__record_cell_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
Define_label(mercury__common__record_cell_5_0_i10);
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__record_cell_5_0_i11,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i11);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__record_cell_5_0_i13,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i13);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__record_cell_5_0_i12);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__record_cell_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__record_cell_5_0_i16,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i12);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__record_cell_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__common__record_cell_5_0_i16,
		STATIC(mercury__common__record_cell_5_0));
Define_label(mercury__common__record_cell_5_0_i16);
	update_prof_current_proc(LABEL(mercury__common__record_cell_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__common__record_cell_5_0, "common:common_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__simplify__simplify_info_set_common_info_3_0),
		STATIC(mercury__common__record_cell_5_0));
END_MODULE

Declare_entry(mercury__eqvclass__ensure_equivalence_4_0);

BEGIN_MODULE(common_module13)
	init_entry(mercury__common__record_equivalence_4_0);
	init_label(mercury__common__record_equivalence_4_0_i2);
	init_label(mercury__common__record_equivalence_4_0_i3);
BEGIN_CODE

/* code for predicate 'record_equivalence'/4 in mode 0 */
Define_static(mercury__common__record_equivalence_4_0);
	MR_incr_sp_push_msg(5, "common:record_equivalence/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_common_info_2_0),
		mercury__common__record_equivalence_4_0_i2,
		STATIC(mercury__common__record_equivalence_4_0));
Define_label(mercury__common__record_equivalence_4_0_i2);
	update_prof_current_proc(LABEL(mercury__common__record_equivalence_4_0));
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	call_localret(ENTRY(mercury__eqvclass__ensure_equivalence_4_0),
		mercury__common__record_equivalence_4_0_i3,
		STATIC(mercury__common__record_equivalence_4_0));
Define_label(mercury__common__record_equivalence_4_0_i3);
	update_prof_current_proc(LABEL(mercury__common__record_equivalence_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__common__record_equivalence_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__simplify__simplify_info_set_common_info_3_0),
		STATIC(mercury__common__record_equivalence_4_0));
END_MODULE

Declare_entry(mercury__mode_util__modes_to_uni_modes_4_0);
Declare_entry(mercury__simplify__simplify_do_warn_calls_1_0);
Declare_entry(mercury__map__apply_to_list_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__simplify__simplify_info_do_add_msg_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(common_module14)
	init_entry(mercury__common__optimise_call_2_9_0);
	init_label(mercury__common__optimise_call_2_9_0_i2);
	init_label(mercury__common__optimise_call_2_9_0_i4);
	init_label(mercury__common__optimise_call_2_9_0_i8);
	init_label(mercury__common__optimise_call_2_9_0_i10);
	init_label(mercury__common__optimise_call_2_9_0_i11);
	init_label(mercury__common__optimise_call_2_9_0_i12);
	init_label(mercury__common__optimise_call_2_9_0_i13);
	init_label(mercury__common__optimise_call_2_9_0_i15);
	init_label(mercury__common__optimise_call_2_9_0_i17);
	init_label(mercury__common__optimise_call_2_9_0_i18);
	init_label(mercury__common__optimise_call_2_9_0_i19);
	init_label(mercury__common__optimise_call_2_9_0_i21);
	init_label(mercury__common__optimise_call_2_9_0_i22);
	init_label(mercury__common__optimise_call_2_9_0_i14);
	init_label(mercury__common__optimise_call_2_9_0_i24);
	init_label(mercury__common__optimise_call_2_9_0_i25);
	init_label(mercury__common__optimise_call_2_9_0_i26);
	init_label(mercury__common__optimise_call_2_9_0_i6);
	init_label(mercury__common__optimise_call_2_9_0_i27);
	init_label(mercury__common__optimise_call_2_9_0_i3);
	init_label(mercury__common__optimise_call_2_9_0_i30);
	init_label(mercury__common__optimise_call_2_9_0_i31);
	init_label(mercury__common__optimise_call_2_9_0_i33);
BEGIN_CODE

/* code for predicate 'optimise_call_2'/9 in mode 0 */
Define_static(mercury__common__optimise_call_2_9_0);
	MR_incr_sp_push_msg(18, "common:optimise_call_2/9");
	MR_stackvar(18) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r7;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_common_info_2_0),
		mercury__common__optimise_call_2_9_0_i2,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i2);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(12) = r3;
	MR_stackvar(8) = r1;
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__common__optimise_call_2_9_0_i4,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i4);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_call_2_9_0_i3);
	r1 = r2;
	MR_stackvar(13) = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(9);
	call_localret(STATIC(mercury__common__find_previous_call_5_0),
		mercury__common__optimise_call_2_9_0_i8,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i8);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_call_2_9_0_i6);
	MR_stackvar(14) = r2;
	MR_stackvar(15) = r3;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__optimise_call_2_9_0_i10,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i10);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r3 = r1;
	r2 = MR_stackvar(4);
	r1 = r2;
	call_localret(ENTRY(mercury__mode_util__modes_to_uni_modes_4_0),
		mercury__common__optimise_call_2_9_0_i11,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i11);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(14);
	r5 = MR_stackvar(7);
	call_localret(STATIC(mercury__common__create_output_unifications_7_0),
		mercury__common__optimise_call_2_9_0_i12,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i12);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__common__optimise_call_2_9_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(16) = r2;
	call_localret(ENTRY(mercury__simplify__simplify_info_get_var_types_2_0),
		mercury__common__optimise_call_2_9_0_i13,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i13);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(16);
	call_localret(ENTRY(mercury__simplify__simplify_do_warn_calls_1_0),
		mercury__common__optimise_call_2_9_0_i15,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i15);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_call_2_9_0_i14);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(17);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__common__optimise_call_2_9_0_i17,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i17);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r3 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r4 = MR_stackvar(17);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__common__optimise_call_2_9_0_i18,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i18);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(STATIC(mercury__common__types_match_exactly_list_2_0),
		mercury__common__optimise_call_2_9_0_i19,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i19);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__optimise_call_2_9_0_i14);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__common__optimise_call_2_9_0_i21,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i21);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r3 = r1;
	r1 = MR_stackvar(16);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__common__optimise_call_2_9_0, "det_report:det_msg/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 10;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(15);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r3;
	call_localret(ENTRY(mercury__simplify__simplify_info_do_add_msg_3_0),
		mercury__common__optimise_call_2_9_0_i22,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i22);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	MR_stackvar(14) = r1;
	MR_stackvar(15) = MR_stackvar(8);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__common__optimise_call_2_9_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	call_localret(ENTRY(mercury__pd_cost__goal_2_0),
		mercury__common__optimise_call_2_9_0_i24,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i14);
	MR_stackvar(14) = MR_stackvar(16);
	MR_stackvar(15) = MR_stackvar(8);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__common__optimise_call_2_9_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	call_localret(ENTRY(mercury__pd_cost__goal_2_0),
		mercury__common__optimise_call_2_9_0_i24,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i24);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__simplify__simplify_info_incr_cost_delta_3_0),
		mercury__common__optimise_call_2_9_0_i25,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i25);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	call_localret(ENTRY(mercury__simplify__simplify_info_set_requantify_2_0),
		mercury__common__optimise_call_2_9_0_i26,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i26);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury__simplify__simplify_info_set_common_info_3_0),
		mercury__common__optimise_call_2_9_0_i33,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i6);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__common__optimise_call_2_9_0_i27,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i27);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	r3 = MR_stackvar(12);
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__optimise_call_2_9_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__common__optimise_call_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r6;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__common__optimise_call_2_9_0_i31,
		STATIC(mercury__common__optimise_call_2_9_0));
	}
Define_label(mercury__common__optimise_call_2_9_0_i3);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__common__optimise_call_2_9_0_i30,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i30);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	r3 = MR_stackvar(12);
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__optimise_call_2_9_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__common__optimise_call_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r6;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__common__optimise_call_2_9_0_i31,
		STATIC(mercury__common__optimise_call_2_9_0));
	}
Define_label(mercury__common__optimise_call_2_9_0_i31);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	MR_stackvar(4) = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__common__optimise_call_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(11);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(9);
	call_localret(ENTRY(mercury__simplify__simplify_info_set_common_info_3_0),
		mercury__common__optimise_call_2_9_0_i33,
		STATIC(mercury__common__optimise_call_2_9_0));
Define_label(mercury__common__optimise_call_2_9_0_i33);
	update_prof_current_proc(LABEL(mercury__common__optimise_call_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__inst_match__inst_matches_binding_3_0);
Declare_entry(mercury__inst_match__inst_is_not_partly_unique_2_0);
Declare_entry(mercury__inst_match__inst_is_free_2_0);

BEGIN_MODULE(common_module15)
	init_entry(mercury__common__partition_call_args_6_0);
	init_label(mercury__common__partition_call_args_6_0_i5);
	init_label(mercury__common__partition_call_args_6_0_i3);
	init_label(mercury__common__partition_call_args_6_0_i9);
	init_label(mercury__common__partition_call_args_6_0_i8);
	init_label(mercury__common__partition_call_args_6_0_i10);
	init_label(mercury__common__partition_call_args_6_0_i12);
	init_label(mercury__common__partition_call_args_6_0_i15);
	init_label(mercury__common__partition_call_args_6_0_i13);
	init_label(mercury__common__partition_call_args_6_0_i17);
	init_label(mercury__common__partition_call_args_6_0_i19);
	init_label(mercury__common__partition_call_args_6_0_i21);
	init_label(mercury__common__partition_call_args_6_0_i1);
BEGIN_CODE

/* code for predicate 'partition_call_args'/6 in mode 0 */
Define_static(mercury__common__partition_call_args_6_0);
	MR_incr_sp_push_msg(9, "common:partition_call_args/6");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i5);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__partition_call_args_6_0_i5);
	r1 = (Word) MR_string_const("common__partition_call_args", 27);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__common__partition_call_args_6_0_i9,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i8);
	r1 = (Word) MR_string_const("common__partition_call_args", 27);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__common__partition_call_args_6_0_i9,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i9);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__partition_call_args_6_0_i8);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	localcall(mercury__common__partition_call_args_6_0,
		LABEL(mercury__common__partition_call_args_6_0_i10),
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i10);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i1);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(8);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__mode_util__mode_get_insts_4_0),
		mercury__common__partition_call_args_6_0_i12,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i12);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_matches_binding_3_0),
		mercury__common__partition_call_args_6_0_i15,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i15);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i13);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__common__partition_call_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__partition_call_args_6_0_i13);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__inst_match__inst_is_not_partly_unique_2_0),
		mercury__common__partition_call_args_6_0_i17,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i17);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i1);
	r1 = MR_stackvar(7);
	r2 = r1;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_matches_binding_3_0),
		mercury__common__partition_call_args_6_0_i19,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i19);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_match__inst_is_free_2_0),
		mercury__common__partition_call_args_6_0_i21,
		STATIC(mercury__common__partition_call_args_6_0));
Define_label(mercury__common__partition_call_args_6_0_i21);
	update_prof_current_proc(LABEL(mercury__common__partition_call_args_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__partition_call_args_6_0_i1);
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__common__partition_call_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__common__partition_call_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__partition_call_args_6_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__context_0_0);

BEGIN_MODULE(common_module16)
	init_entry(mercury__common__find_previous_call_5_0);
	init_label(mercury__common__find_previous_call_5_0_i5);
	init_label(mercury__common__find_previous_call_5_0_i3);
	init_label(mercury__common__find_previous_call_5_0_i7);
	init_label(mercury__common__find_previous_call_5_0_i9);
	init_label(mercury__common__find_previous_call_5_0_i1005);
	init_label(mercury__common__find_previous_call_5_0_i1);
BEGIN_CODE

/* code for predicate 'find_previous_call'/5 in mode 0 */
Define_static(mercury__common__find_previous_call_5_0);
	MR_incr_sp_push_msg(6, "common:find_previous_call/5");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__find_previous_call_5_0_i1005);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__common__var_lists_are_equiv_3_0),
		mercury__common__find_previous_call_5_0_i5,
		STATIC(mercury__common__find_previous_call_5_0));
	}
Define_label(mercury__common__find_previous_call_5_0_i5);
	update_prof_current_proc(LABEL(mercury__common__find_previous_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_previous_call_5_0_i3);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__common__find_previous_call_5_0_i3);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__common__find_previous_call_5_0,
		LABEL(mercury__common__find_previous_call_5_0_i7),
		STATIC(mercury__common__find_previous_call_5_0));
Define_label(mercury__common__find_previous_call_5_0_i7);
	update_prof_current_proc(LABEL(mercury__common__find_previous_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_previous_call_5_0_i1);
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(3);
	r2 = r3;
	call_localret(ENTRY(mercury____Unify___term__context_0_0),
		mercury__common__find_previous_call_5_0_i9,
		STATIC(mercury__common__find_previous_call_5_0));
Define_label(mercury__common__find_previous_call_5_0_i9);
	update_prof_current_proc(LABEL(mercury__common__find_previous_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__find_previous_call_5_0_i1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__common__find_previous_call_5_0_i1005);
	r1 = FALSE;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__common__find_previous_call_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(common_module17)
	init_entry(mercury__common__create_output_unifications_7_0);
	init_label(mercury__common__create_output_unifications_7_0_i1007);
	init_label(mercury__common__create_output_unifications_7_0_i9);
	init_label(mercury__common__create_output_unifications_7_0_i11);
	init_label(mercury__common__create_output_unifications_7_0_i12);
	init_label(mercury__common__create_output_unifications_7_0_i6);
	init_label(mercury__common__create_output_unifications_7_0_i2);
	init_label(mercury__common__create_output_unifications_7_0_i15);
BEGIN_CODE

/* code for predicate 'create_output_unifications'/7 in mode 0 */
Define_static(mercury__common__create_output_unifications_7_0);
	MR_incr_sp_push_msg(9, "common:create_output_unifications/7");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__common__create_output_unifications_7_0_i1007);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i2);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i2);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i2);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(5) = r3;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r5;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__create_output_unifications_7_0_i9,
		STATIC(mercury__common__create_output_unifications_7_0));
Define_label(mercury__common__create_output_unifications_7_0_i9);
	update_prof_current_proc(LABEL(mercury__common__create_output_unifications_7_0));
	if (r1)
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i6);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__common__generate_assign_7_0),
		mercury__common__create_output_unifications_7_0_i11,
		STATIC(mercury__common__create_output_unifications_7_0));
Define_label(mercury__common__create_output_unifications_7_0_i11);
	update_prof_current_proc(LABEL(mercury__common__create_output_unifications_7_0));
	r5 = r2;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	localcall(mercury__common__create_output_unifications_7_0,
		LABEL(mercury__common__create_output_unifications_7_0_i12),
		STATIC(mercury__common__create_output_unifications_7_0));
Define_label(mercury__common__create_output_unifications_7_0_i12);
	update_prof_current_proc(LABEL(mercury__common__create_output_unifications_7_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__common__create_output_unifications_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__create_output_unifications_7_0_i6);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__common__create_output_unifications_7_0_i1007);
Define_label(mercury__common__create_output_unifications_7_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i15);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i15);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__create_output_unifications_7_0_i15);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__common__create_output_unifications_7_0_i15);
	r1 = (Word) MR_string_const("comon__create_output_unifications: mode mismatch", 48);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__common__create_output_unifications_7_0));
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury__hlds_module__predicate_table_search_pred_sym_arity_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__hlds_pred__initial_proc_id_1_0);
Declare_entry(mercury__instmap__instmap_delta_restrict_3_0);
Declare_entry(mercury__hlds_goal__goal_info_init_4_0);

BEGIN_MODULE(common_module18)
	init_entry(mercury__common__generate_assign_7_0);
	init_label(mercury__common__generate_assign_7_0_i2);
	init_label(mercury__common__generate_assign_7_0_i3);
	init_label(mercury__common__generate_assign_7_0_i4);
	init_label(mercury__common__generate_assign_7_0_i5);
	init_label(mercury__common__generate_assign_7_0_i6);
	init_label(mercury__common__generate_assign_7_0_i14);
	init_label(mercury__common__generate_assign_7_0_i11);
	init_label(mercury__common__generate_assign_7_0_i16);
	init_label(mercury__common__generate_assign_7_0_i18);
	init_label(mercury__common__generate_assign_7_0_i20);
	init_label(mercury__common__generate_assign_7_0_i22);
	init_label(mercury__common__generate_assign_7_0_i9);
	init_label(mercury__common__generate_assign_7_0_i7);
	init_label(mercury__common__generate_assign_7_0_i25);
	init_label(mercury__common__generate_assign_7_0_i26);
	init_label(mercury__common__generate_assign_7_0_i27);
	init_label(mercury__common__generate_assign_7_0_i29);
	init_label(mercury__common__generate_assign_7_0_i32);
	init_label(mercury__common__generate_assign_7_0_i34);
	init_label(mercury__common__generate_assign_7_0_i28);
	init_label(mercury__common__generate_assign_7_0_i35);
	init_label(mercury__common__generate_assign_7_0_i36);
	init_label(mercury__common__generate_assign_7_0_i37);
	init_label(mercury__common__generate_assign_7_0_i39);
	init_label(mercury__common__generate_assign_7_0_i40);
BEGIN_CODE

/* code for predicate 'generate_assign'/7 in mode 0 */
Define_static(mercury__common__generate_assign_7_0);
	MR_incr_sp_push_msg(9, "common:generate_assign/7");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__common__generate_assign_7_0_i2,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i2);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_var_types_2_0),
		mercury__common__generate_assign_7_0_i3,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i3);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__common__generate_assign_7_0_i4,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i4);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_3);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__common__generate_assign_7_0_i5,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i5);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	MR_stackvar(7) = r1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__common__generate_assign_7_0_i6,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i6);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if ((MR_tag(MR_stackvar(6)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i11);
	if ((MR_tag(MR_stackvar(7)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i11);
	MR_stackvar(8) = r1;
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(7), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(6), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__generate_assign_7_0_i14,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i14);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (r1)
		GOTO_LABEL(mercury__common__generate_assign_7_0_i9);
	r1 = MR_stackvar(8);
Define_label(mercury__common__generate_assign_7_0_i11);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__generate_assign_7_0_i16,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i16);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i7);
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__generate_assign_7_0_i18,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i18);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i7);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(6);
	MR_stackvar(6) = MR_tempr1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__common__generate_assign_7_0_i20,
		STATIC(mercury__common__generate_assign_7_0));
	}
Define_label(mercury__common__generate_assign_7_0_i20);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i7);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__common__types_match_exactly_list_2_0),
		mercury__common__generate_assign_7_0_i22,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i22);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i7);
Define_label(mercury__common__generate_assign_7_0_i9);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 6, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_stackvar(3) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__common__generate_assign_7_0, "hlds_goal:unify_rhs/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_stackvar(3), (Integer) 2) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__common__generate_assign_7_0, "std_util:pair/2");
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_stackvar(3), (Integer) 3) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__common__generate_assign_7_0, "hlds_goal:unification/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_stackvar(3), (Integer) 4) = r2;
	MR_field(MR_mktag(3), MR_stackvar(3), (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_4);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__common__generate_assign_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__instmap__instmap_delta_from_assoc_list_2_0),
		mercury__common__generate_assign_7_0_i37,
		STATIC(mercury__common__generate_assign_7_0));
	}
Define_label(mercury__common__generate_assign_7_0_i7);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__simplify__simplify_info_get_module_info_2_0),
		mercury__common__generate_assign_7_0_i25,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i25);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__common__generate_assign_7_0_i26,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i26);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__common__generate_assign_7_0_i27,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i27);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r2 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = r2;
	r2 = MR_tempr1;
	MR_stackvar(3) = MR_tempr1;
	r3 = (Integer) 2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_string_const("unsafe_type_cast", 16);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_pred_sym_arity_4_0),
		mercury__common__generate_assign_7_0_i29,
		STATIC(mercury__common__generate_assign_7_0));
	}
Define_label(mercury__common__generate_assign_7_0_i29);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i28);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i28);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__common__generate_assign_7_0_i32,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i32);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__generate_assign_7_0_i28);
	call_localret(ENTRY(mercury__hlds_pred__initial_proc_id_1_0),
		mercury__common__generate_assign_7_0_i34,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i34);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(8);
	r4 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 6, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 5) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 3) = (Integer) 0;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 2) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	GOTO_LABEL(mercury__common__generate_assign_7_0_i36);
	}
Define_label(mercury__common__generate_assign_7_0_i28);
	r1 = (Word) MR_string_const("common__generate_assign: \t\t\t\tcan't find unsafe_type_cast", 56);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__common__generate_assign_7_0_i35,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i35);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(8);
Define_label(mercury__common__generate_assign_7_0_i36);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__instmap__instmap_delta_restrict_3_0),
		mercury__common__generate_assign_7_0_i37,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i37);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_4_0),
		mercury__common__generate_assign_7_0_i39,
		STATIC(mercury__common__generate_assign_7_0));
Define_label(mercury__common__generate_assign_7_0_i39);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r2 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__common__generate_assign_7_0, "origin_lost_in_value_number");
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__common__record_equivalence_4_0),
		mercury__common__generate_assign_7_0_i40,
		STATIC(mercury__common__generate_assign_7_0));
	}
Define_label(mercury__common__generate_assign_7_0_i40);
	update_prof_current_proc(LABEL(mercury__common__generate_assign_7_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(common_module19)
	init_entry(mercury__common__types_match_exactly_list_2_0);
	init_label(mercury__common__types_match_exactly_list_2_0_i1010);
	init_label(mercury__common__types_match_exactly_list_2_0_i3);
	init_label(mercury__common__types_match_exactly_list_2_0_i11);
	init_label(mercury__common__types_match_exactly_list_2_0_i7);
	init_label(mercury__common__types_match_exactly_list_2_0_i8);
	init_label(mercury__common__types_match_exactly_list_2_0_i13);
	init_label(mercury__common__types_match_exactly_list_2_0_i15);
	init_label(mercury__common__types_match_exactly_list_2_0_i17);
	init_label(mercury__common__types_match_exactly_list_2_0_i19);
	init_label(mercury__common__types_match_exactly_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'types_match_exactly_list'/2 in mode 0 */
Define_static(mercury__common__types_match_exactly_list_2_0);
	MR_incr_sp_push_msg(5, "common:types_match_exactly_list/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__common__types_match_exactly_list_2_0_i1010);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__common__types_match_exactly_list_2_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i8);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i8);
	MR_stackvar(4) = r3;
	r3 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__common__types_match_exactly_list_2_0_i11,
		STATIC(mercury__common__types_match_exactly_list_2_0));
Define_label(mercury__common__types_match_exactly_list_2_0_i11);
	update_prof_current_proc(LABEL(mercury__common__types_match_exactly_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i7);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1010);
Define_label(mercury__common__types_match_exactly_list_2_0_i7);
	r6 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(4);
Define_label(mercury__common__types_match_exactly_list_2_0_i8);
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	r1 = r6;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__types_match_exactly_list_2_0_i13,
		STATIC(mercury__common__types_match_exactly_list_2_0));
Define_label(mercury__common__types_match_exactly_list_2_0_i13);
	update_prof_current_proc(LABEL(mercury__common__types_match_exactly_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__common__types_match_exactly_list_2_0_i15,
		STATIC(mercury__common__types_match_exactly_list_2_0));
Define_label(mercury__common__types_match_exactly_list_2_0_i15);
	update_prof_current_proc(LABEL(mercury__common__types_match_exactly_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__common__types_match_exactly_list_2_0_i17,
		STATIC(mercury__common__types_match_exactly_list_2_0));
	}
Define_label(mercury__common__types_match_exactly_list_2_0_i17);
	update_prof_current_proc(LABEL(mercury__common__types_match_exactly_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__common__types_match_exactly_list_2_0,
		LABEL(mercury__common__types_match_exactly_list_2_0_i19),
		STATIC(mercury__common__types_match_exactly_list_2_0));
Define_label(mercury__common__types_match_exactly_list_2_0_i19);
	update_prof_current_proc(LABEL(mercury__common__types_match_exactly_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__common__types_match_exactly_list_2_0_i1010);
Define_label(mercury__common__types_match_exactly_list_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___eqvclass__eqvclass_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(common_module20)
	init_entry(mercury____Unify___common__common_info_0_0);
	init_label(mercury____Unify___common__common_info_0_0_i2);
	init_label(mercury____Unify___common__common_info_0_0_i4);
	init_label(mercury____Unify___common__common_info_0_0_i6);
	init_label(mercury____Unify___common__common_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___common__common_info_0_0);
	MR_incr_sp_push_msg(7, "common:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	call_localret(ENTRY(mercury____Unify___eqvclass__eqvclass_1_0),
		mercury____Unify___common__common_info_0_0_i2,
		ENTRY(mercury____Unify___common__common_info_0_0));
Define_label(mercury____Unify___common__common_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___common__common_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__common_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___common__common_info_0_0_i4,
		ENTRY(mercury____Unify___common__common_info_0_0));
Define_label(mercury____Unify___common__common_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___common__common_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__common_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___common__common_info_0_0_i6,
		ENTRY(mercury____Unify___common__common_info_0_0));
Define_label(mercury____Unify___common__common_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___common__common_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__common_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___common__common_info_0_0));
Define_label(mercury____Unify___common__common_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(common_module21)
	init_entry(mercury____Index___common__common_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___common__common_info_0_0);
	tailcall(STATIC(mercury____Index___common__common_info_0__ua0_2_0),
		ENTRY(mercury____Index___common__common_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___eqvclass__eqvclass_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(common_module22)
	init_entry(mercury____Compare___common__common_info_0_0);
	init_label(mercury____Compare___common__common_info_0_0_i3);
	init_label(mercury____Compare___common__common_info_0_0_i7);
	init_label(mercury____Compare___common__common_info_0_0_i11);
	init_label(mercury____Compare___common__common_info_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___common__common_info_0_0);
	MR_incr_sp_push_msg(7, "common:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	call_localret(ENTRY(mercury____Compare___eqvclass__eqvclass_1_0),
		mercury____Compare___common__common_info_0_0_i3,
		ENTRY(mercury____Compare___common__common_info_0_0));
Define_label(mercury____Compare___common__common_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___common__common_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__common_info_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___common__common_info_0_0_i7,
		ENTRY(mercury____Compare___common__common_info_0_0));
Define_label(mercury____Compare___common__common_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___common__common_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__common_info_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___common__common_info_0_0_i11,
		ENTRY(mercury____Compare___common__common_info_0_0));
Define_label(mercury____Compare___common__common_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___common__common_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__common_info_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___common__common_info_0_0));
Define_label(mercury____Compare___common__common_info_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__term_1_0);

BEGIN_MODULE(common_module23)
	init_entry(mercury____Unify___common__structure_0_0);
	init_label(mercury____Unify___common__structure_0_0_i2);
	init_label(mercury____Unify___common__structure_0_0_i4);
	init_label(mercury____Unify___common__structure_0_0_i6);
	init_label(mercury____Unify___common__structure_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__structure_0_0);
	MR_incr_sp_push_msg(7, "common:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury____Unify___common__structure_0_0_i2,
		STATIC(mercury____Unify___common__structure_0_0));
Define_label(mercury____Unify___common__structure_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__term_1_0),
		mercury____Unify___common__structure_0_0_i4,
		STATIC(mercury____Unify___common__structure_0_0));
Define_label(mercury____Unify___common__structure_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___common__structure_0_0_i6,
		STATIC(mercury____Unify___common__structure_0_0));
Define_label(mercury____Unify___common__structure_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___common__structure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__structure_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___common__structure_0_0));
Define_label(mercury____Unify___common__structure_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(common_module24)
	init_entry(mercury____Index___common__structure_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__structure_0_0);
	tailcall(STATIC(mercury____Index___common__structure_0__ua0_2_0),
		STATIC(mercury____Index___common__structure_0_0));
END_MODULE

Declare_entry(mercury____Compare___term__var_1_0);
Declare_entry(mercury____Compare___term__term_1_0);
Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(common_module25)
	init_entry(mercury____Compare___common__structure_0_0);
	init_label(mercury____Compare___common__structure_0_0_i3);
	init_label(mercury____Compare___common__structure_0_0_i7);
	init_label(mercury____Compare___common__structure_0_0_i11);
	init_label(mercury____Compare___common__structure_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__structure_0_0);
	MR_incr_sp_push_msg(7, "common:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___term__var_1_0),
		mercury____Compare___common__structure_0_0_i3,
		STATIC(mercury____Compare___common__structure_0_0));
Define_label(mercury____Compare___common__structure_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___term__term_1_0),
		mercury____Compare___common__structure_0_0_i7,
		STATIC(mercury____Compare___common__structure_0_0));
Define_label(mercury____Compare___common__structure_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i17);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___common__structure_0_0_i11,
		STATIC(mercury____Compare___common__structure_0_0));
Define_label(mercury____Compare___common__structure_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___common__structure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__structure_0_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___common__structure_0_0));
Define_label(mercury____Compare___common__structure_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(common_module26)
	init_entry(mercury____Unify___common__call_args_0_0);
	init_label(mercury____Unify___common__call_args_0_0_i2);
	init_label(mercury____Unify___common__call_args_0_0_i4);
	init_label(mercury____Unify___common__call_args_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__call_args_0_0);
	MR_incr_sp_push_msg(5, "common:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___term__context_0_0),
		mercury____Unify___common__call_args_0_0_i2,
		STATIC(mercury____Unify___common__call_args_0_0));
Define_label(mercury____Unify___common__call_args_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___common__call_args_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__call_args_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___common__call_args_0_0_i4,
		STATIC(mercury____Unify___common__call_args_0_0));
Define_label(mercury____Unify___common__call_args_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___common__call_args_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___common__call_args_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___common__call_args_0_0));
Define_label(mercury____Unify___common__call_args_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(common_module27)
	init_entry(mercury____Index___common__call_args_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__call_args_0_0);
	tailcall(STATIC(mercury____Index___common__call_args_0__ua0_2_0),
		STATIC(mercury____Index___common__call_args_0_0));
END_MODULE

Declare_entry(mercury____Compare___term__context_0_0);

BEGIN_MODULE(common_module28)
	init_entry(mercury____Compare___common__call_args_0_0);
	init_label(mercury____Compare___common__call_args_0_0_i3);
	init_label(mercury____Compare___common__call_args_0_0_i7);
	init_label(mercury____Compare___common__call_args_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__call_args_0_0);
	MR_incr_sp_push_msg(5, "common:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___term__context_0_0),
		mercury____Compare___common__call_args_0_0_i3,
		STATIC(mercury____Compare___common__call_args_0_0));
Define_label(mercury____Compare___common__call_args_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___common__call_args_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__call_args_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___common__call_args_0_0_i7,
		STATIC(mercury____Compare___common__call_args_0_0));
Define_label(mercury____Compare___common__call_args_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___common__call_args_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___common__call_args_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___common__call_args_0_0));
Define_label(mercury____Compare___common__call_args_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(common_module29)
	init_entry(mercury____Unify___common__struct_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__struct_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___common__struct_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(common_module30)
	init_entry(mercury____Index___common__struct_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__struct_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___common__struct_map_0_0));
END_MODULE


BEGIN_MODULE(common_module31)
	init_entry(mercury____Compare___common__struct_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__struct_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___common__struct_map_0_0));
END_MODULE


BEGIN_MODULE(common_module32)
	init_entry(mercury____Unify___common__seen_calls_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__seen_calls_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___common__seen_calls_0_0));
END_MODULE


BEGIN_MODULE(common_module33)
	init_entry(mercury____Index___common__seen_calls_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__seen_calls_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___common__seen_calls_0_0));
END_MODULE


BEGIN_MODULE(common_module34)
	init_entry(mercury____Compare___common__seen_calls_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__seen_calls_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_det_report__type_ctor_info_seen_call_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_common__common_2);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___common__seen_calls_0_0));
END_MODULE


BEGIN_MODULE(common_module35)
	init_entry(mercury____Unify___common__unification_type_0_0);
	init_label(mercury____Unify___common__unification_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___common__unification_type_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___common__unification_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___common__unification_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(common_module36)
	init_entry(mercury____Index___common__unification_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___common__unification_type_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(common_module37)
	init_entry(mercury____Compare___common__unification_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___common__unification_type_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___common__unification_type_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__common_maybe_bunch_0(void)
{
	common_module0();
	common_module1();
	common_module2();
	common_module3();
	common_module4();
	common_module5();
	common_module6();
	common_module7();
	common_module8();
	common_module9();
	common_module10();
	common_module11();
	common_module12();
	common_module13();
	common_module14();
	common_module15();
	common_module16();
	common_module17();
	common_module18();
	common_module19();
	common_module20();
	common_module21();
	common_module22();
	common_module23();
	common_module24();
	common_module25();
	common_module26();
	common_module27();
	common_module28();
	common_module29();
	common_module30();
	common_module31();
	common_module32();
	common_module33();
	common_module34();
	common_module35();
	common_module36();
	common_module37();
}

#endif

void mercury__common__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__common__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__common_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_call_args_0,
			common__call_args_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_common_info_0,
			common__common_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_seen_calls_0,
			common__seen_calls_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_struct_map_0,
			common__struct_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_structure_0,
			common__structure_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_common__type_ctor_info_unification_type_0,
			common__unification_type_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
