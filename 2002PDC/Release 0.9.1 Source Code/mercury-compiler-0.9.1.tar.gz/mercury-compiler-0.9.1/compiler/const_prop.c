/*
** Automatically generated from `const_prop.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__const_prop__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0);
Declare_label(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0_i2);
Define_extern_entry(mercury__const_prop__evaluate_builtin_9_0);
Declare_label(mercury__const_prop__evaluate_builtin_9_0_i2);
Declare_label(mercury__const_prop__evaluate_builtin_9_0_i3);
Declare_label(mercury__const_prop__evaluate_builtin_9_0_i4);
Declare_label(mercury__const_prop__evaluate_builtin_9_0_i5);
Declare_static(mercury__const_prop__evaluate_builtin_2_9_0);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i8);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i10);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i11);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i12);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i3);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i4);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i20);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i22);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i23);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i24);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i25);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i14);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i15);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i26);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i1037);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i29);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i1019);
Declare_label(mercury__const_prop__evaluate_builtin_2_9_0_i1);
Declare_static(mercury__const_prop__evaluate_builtin_bi_7_0);
Declare_label(mercury__const_prop__evaluate_builtin_bi_7_0_i11);
Declare_label(mercury__const_prop__evaluate_builtin_bi_7_0_i9);
Declare_label(mercury__const_prop__evaluate_builtin_bi_7_0_i15);
Declare_label(mercury__const_prop__evaluate_builtin_bi_7_0_i16);
Declare_label(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
Declare_static(mercury__const_prop__evaluate_builtin_tri_8_0);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i7);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i18);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i5);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i46);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i57);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i44);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i81);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i92);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i79);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i116);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i129);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i3);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i155);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1345);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i157);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i158);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i171);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i184);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i198);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i210);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i224);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i225);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i237);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i249);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i251);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i262);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i284);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i296);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i298);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i309);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i331);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i343);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i355);
Declare_label(mercury__const_prop__evaluate_builtin_tri_8_0_i369);
Declare_static(mercury__const_prop__evaluate_builtin_test_5_0);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i19);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i22);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i25);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i15);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i35);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i38);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i41);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i45);
Declare_label(mercury__const_prop__evaluate_builtin_test_5_0_i1);

static const struct mercury_data_const_prop__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_const_prop__common_0;

static const struct mercury_data_const_prop__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_const_prop__common_1;

static const struct mercury_data_const_prop__common_2_struct {
	Word * f1;
}  mercury_data_const_prop__common_2;

static const struct mercury_data_const_prop__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_const_prop__common_3;

static const struct mercury_data_const_prop__common_4_struct {
	Word * f1;
}  mercury_data_const_prop__common_4;

static const struct mercury_data_const_prop__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	Integer f8;
	Integer f9;
	String f10;
	String f11;
	String f12;
	String f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	String f18;
	Integer f19;
	String f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	String f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	String f32;
}  mercury_data_const_prop__common_5;

static const struct mercury_data_const_prop__common_6_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_const_prop__common_6;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_const_prop__common_0_struct mercury_data_const_prop__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_inst__type_ctor_info_inst_0;
static const struct mercury_data_const_prop__common_1_struct mercury_data_const_prop__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_0),
	(Word *) &mercury_data_inst__type_ctor_info_inst_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_instmap__type_ctor_info_instmap_0;
static const struct mercury_data_const_prop__common_2_struct mercury_data_const_prop__common_2 = {
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0
};

static const struct mercury_data_const_prop__common_3_struct mercury_data_const_prop__common_3 = {
	(Integer) 0,
	MR_string_const("const_prop", 10),
	MR_string_const("const_prop", 10),
	MR_string_const("IntroducedFrom__pred__evaluate_builtin__48__1", 45),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_1)
};

static const struct mercury_data_const_prop__common_4_struct mercury_data_const_prop__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_const_prop__common_5_struct mercury_data_const_prop__common_5 = {
	(Integer) 0,
	MR_string_const("<<", 2),
	MR_string_const(">>", 2),
	MR_string_const("//", 2),
	MR_string_const("/\\", 2),
	MR_string_const("mod", 3),
	MR_string_const("xor", 3),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("unchecked_right_shift", 21),
	MR_string_const("+", 1),
	MR_string_const("*", 1),
	MR_string_const("-", 1),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("\\/", 2),
	(Integer) 0,
	MR_string_const("unchecked_left_shift", 20),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("rem", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("^", 1)
};

static const struct mercury_data_const_prop__common_6_struct mercury_data_const_prop__common_6 = {
	(Integer) -2,
	(Integer) 3,
	(Integer) 1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 4,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1
};

Declare_entry(mercury__instmap__lookup_var_3_0);

BEGIN_MODULE(const_prop_module0)
	init_entry(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0);
	init_label(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__evaluate_builtin__48__1'/3 in mode 0 */
Define_static(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0);
	MR_incr_sp_push_msg(2, "const_prop:IntroducedFrom__pred__evaluate_builtin__48__1/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0_i2,
		STATIC(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0));
Define_label(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0_i2);
	update_prof_current_proc(LABEL(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__predicate_module_3_0);
Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);
Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(const_prop_module1)
	init_entry(mercury__const_prop__evaluate_builtin_9_0);
	init_label(mercury__const_prop__evaluate_builtin_9_0_i2);
	init_label(mercury__const_prop__evaluate_builtin_9_0_i3);
	init_label(mercury__const_prop__evaluate_builtin_9_0_i4);
	init_label(mercury__const_prop__evaluate_builtin_9_0_i5);
BEGIN_CODE

/* code for predicate 'evaluate_builtin'/9 in mode 0 */
Define_entry(mercury__const_prop__evaluate_builtin_9_0);
	MR_incr_sp_push_msg(7, "const_prop:evaluate_builtin/9");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = r6;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__const_prop__evaluate_builtin_9_0_i2,
		ENTRY(mercury__const_prop__evaluate_builtin_9_0));
Define_label(mercury__const_prop__evaluate_builtin_9_0_i2);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_9_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__const_prop__evaluate_builtin_9_0_i3,
		ENTRY(mercury__const_prop__evaluate_builtin_9_0));
Define_label(mercury__const_prop__evaluate_builtin_9_0_i3);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_9_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__const_prop__evaluate_builtin_9_0_i4,
		ENTRY(mercury__const_prop__evaluate_builtin_9_0));
Define_label(mercury__const_prop__evaluate_builtin_9_0_i4);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_9_0));
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__const_prop__evaluate_builtin_9_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_1);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__const_prop__IntroducedFrom__pred__evaluate_builtin__48__1_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__const_prop__evaluate_builtin_9_0_i5,
		ENTRY(mercury__const_prop__evaluate_builtin_9_0));
Define_label(mercury__const_prop__evaluate_builtin_9_0_i5);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_9_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__const_prop__evaluate_builtin_2_9_0),
		ENTRY(mercury__const_prop__evaluate_builtin_9_0));
END_MODULE

Declare_entry(mercury__hlds_goal__make_const_construction_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__instmap_delta_set_4_0);
Declare_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(const_prop_module2)
	init_entry(mercury__const_prop__evaluate_builtin_2_9_0);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i8);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i10);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i11);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i12);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i3);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i4);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i20);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i22);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i23);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i24);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i25);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i14);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i26);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i1037);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i29);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i1019);
	init_label(mercury__const_prop__evaluate_builtin_2_9_0_i1);
BEGIN_CODE

/* code for predicate 'evaluate_builtin_2'/9 in mode 0 */
Define_static(mercury__const_prop__evaluate_builtin_2_9_0);
	MR_incr_sp_push_msg(10, "const_prop:evaluate_builtin_2/9");
	MR_stackvar(10) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i1019);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i4);
	r8 = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	if (((Integer) r8 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i4);
	if (((Integer) MR_const_field(MR_mktag(1), r8, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i4);
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	r5 = MR_const_field(MR_mktag(1), r8, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = r7;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	call_localret(STATIC(mercury__const_prop__evaluate_builtin_bi_7_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i8,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i8);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(8) = r2;
	r2 = r3;
	MR_stackvar(9) = r3;
	call_localret(ENTRY(mercury__hlds_goal__make_const_construction_3_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i10,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i10);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i11,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i11);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(8), (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__const_prop__evaluate_builtin_2_9_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__const_prop__evaluate_builtin_2_9_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__const_prop__evaluate_builtin_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(ENTRY(mercury__instmap__instmap_delta_set_4_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i12,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
	}
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i12);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_instmap_delta_3_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i25,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i4);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r6;
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = r7;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(7) = r7;
	call_localret(STATIC(mercury__const_prop__evaluate_builtin_tri_8_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i20,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i20);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i14);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(8) = r2;
	r2 = r3;
	MR_stackvar(9) = r3;
	call_localret(ENTRY(mercury__hlds_goal__make_const_construction_3_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i22,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i22);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i23,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i23);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(8), (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__const_prop__evaluate_builtin_2_9_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__const_prop__evaluate_builtin_2_9_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__const_prop__evaluate_builtin_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(ENTRY(mercury__instmap__instmap_delta_set_4_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i24,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
	}
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i24);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_instmap_delta_3_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i25,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i25);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	r2 = MR_stackvar(5);
	r3 = r1;
	r4 = MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i15);
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r6;
	r1 = r7;
	call_localret(STATIC(mercury__const_prop__evaluate_builtin_test_5_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i26,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i26);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_2_9_0_i29);
	MR_stackvar(1) = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__const_prop__evaluate_builtin_2_9_0_i1037,
		STATIC(mercury__const_prop__evaluate_builtin_2_9_0));
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i1037);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_2_9_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__const_prop__evaluate_builtin_2_9_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i29);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_4);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i1019);
	r1 = FALSE;
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_2_9_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(const_prop_module3)
	init_entry(mercury__const_prop__evaluate_builtin_bi_7_0);
	init_label(mercury__const_prop__evaluate_builtin_bi_7_0_i11);
	init_label(mercury__const_prop__evaluate_builtin_bi_7_0_i9);
	init_label(mercury__const_prop__evaluate_builtin_bi_7_0_i15);
	init_label(mercury__const_prop__evaluate_builtin_bi_7_0_i16);
	init_label(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
BEGIN_CODE

/* code for predicate 'evaluate_builtin_bi'/7 in mode 0 */
Define_static(mercury__const_prop__evaluate_builtin_bi_7_0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i9);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("+", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i11);
	r2 = r5;
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_bi_7_0_i11);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("-", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_bi_7_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) 0 - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_bi_7_0_i9);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("+", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i15);
	r2 = r5;
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_bi_7_0_i15);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("-", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i16);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_bi_7_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) 0 - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_bi_7_0_i16);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("\\", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_bi_7_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ~((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_bi_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

static const Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
Declare_entry(mercury__fn__f_105_110_116_95_95_60_60_2_0);
Declare_entry(mercury__fn__f_105_110_116_95_95_62_62_2_0);
Declare_entry(mercury__fn__int__mod_2_0);

BEGIN_MODULE(const_prop_module4)
	init_entry(mercury__const_prop__evaluate_builtin_tri_8_0);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i7);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i18);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i5);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i46);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i57);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i44);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i81);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i92);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i79);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i116);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i129);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i3);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i155);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1345);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i157);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i158);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i171);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i184);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i198);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i210);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i224);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i225);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i237);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i249);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i251);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i262);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i284);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i296);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i298);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i309);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i331);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i343);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i355);
	init_label(mercury__const_prop__evaluate_builtin_tri_8_0_i369);
BEGIN_CODE

/* code for predicate 'evaluate_builtin_tri'/8 in mode 0 */
Define_static(mercury__const_prop__evaluate_builtin_tri_8_0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i3);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("*", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i5);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i7);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) * word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i7);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i18);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r4;
	r5 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(r5) / word_to_float(r1)));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i18);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r5;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(r4) / word_to_float(r1)));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i5);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("+", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i44);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i46);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) + word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i46);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i57);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) - word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i57);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) - word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i44);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("-", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i79);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i81);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) - word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i81);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i92);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) + word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i92);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) - word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i79);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("//", 2)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i116);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r6;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(r4) / word_to_float(r1)));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i116);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i129);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) * word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i129);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1);
	if ((word_to_float(r2) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r5;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = float_to_word((word_to_float(r1) / word_to_float(r4)));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = (hash_string(r2) & (Integer) 31);
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i155);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_5))[(Integer) r1];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1345);
	if ((strcmp((char *)MR_tempr1, (char *)r2) == 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i157);
	}
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1345);
	r1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_const_prop__common_6))[(Integer) r1];
	if (((Integer) r1 >= (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i155);
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = FALSE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i157);
	COMPUTED_GOTO((Unsigned) r1,
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i158) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i171) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i184) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i198) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i210) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i225) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i237) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i249) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i284) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i296) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i331) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i343) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i355) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143) AND
		LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i369));
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i158);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	MR_incr_sp_push_msg(2, "const_prop:evaluate_builtin_tri/8");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r6;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_60_60_2_0),
		mercury__const_prop__evaluate_builtin_tri_8_0_i224,
		STATIC(mercury__const_prop__evaluate_builtin_tri_8_0));
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i171);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	MR_incr_sp_push_msg(2, "const_prop:evaluate_builtin_tri/8");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r6;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_62_62_2_0),
		mercury__const_prop__evaluate_builtin_tri_8_0_i224,
		STATIC(mercury__const_prop__evaluate_builtin_tri_8_0));
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i184);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	if (((Integer) r1 == (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r6;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) r4 / (Integer) r1);
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i198);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) & (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i210);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	MR_incr_sp_push_msg(2, "const_prop:evaluate_builtin_tri/8");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r6;
	call_localret(ENTRY(mercury__fn__int__mod_2_0),
		mercury__const_prop__evaluate_builtin_tri_8_0_i224,
		STATIC(mercury__const_prop__evaluate_builtin_tri_8_0));
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i224);
	update_prof_current_proc(LABEL(mercury__const_prop__evaluate_builtin_tri_8_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i225);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) ^ (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i237);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) >> (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i249);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i251);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) + (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i251);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i262);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i262);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i284);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) * (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i296);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i298);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i298);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i309);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) + (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i309);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r6, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) - (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r6, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i331);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) | (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i343);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) << (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i355);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0);
	if (((Integer) r1 == (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r3 = r2;
	r2 = r6;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) r4 % (Integer) r1);
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_tri_8_0_i369);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r4, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_tri_8_0_i1143);
	r2 = r6;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__const_prop__evaluate_builtin_tri_8_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) ^ (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0));
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(const_prop_module5)
	init_entry(mercury__const_prop__evaluate_builtin_test_5_0);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i19);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i22);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i25);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i15);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i35);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i38);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i41);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	init_label(mercury__const_prop__evaluate_builtin_test_5_0_i1);
BEGIN_CODE

/* code for predicate 'evaluate_builtin_test'/5 in mode 0 */
Define_static(mercury__const_prop__evaluate_builtin_test_5_0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i15);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("<", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i19);
	if ((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) >= word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i19);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("=<", 2)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i22);
	if ((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) > word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i22);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const(">", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i25);
	if ((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) <= word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i25);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const(">=", 2)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1)) < word_to_float(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 1))))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i15);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("<", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i35);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) >= (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i35);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("=<", 2)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i38);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) > (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i38);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const(">", 1)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i41);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) <= (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i41);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const(">=", 2)) != 0))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0) < (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 2), (Integer) 0), (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i45);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__const_prop__evaluate_builtin_test_5_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__const_prop_maybe_bunch_0(void)
{
	const_prop_module0();
	const_prop_module1();
	const_prop_module2();
	const_prop_module3();
	const_prop_module4();
	const_prop_module5();
}

#endif

void mercury__const_prop__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__const_prop__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__const_prop_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
