/*
** Automatically generated from `cse_detection.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__cse_detection__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___cse_detection__cse_info_0__ua0_2_0);
Define_extern_entry(mercury__cse_detection__detect_cse_4_0);
Declare_label(mercury__cse_detection__detect_cse_4_0_i2);
Define_extern_entry(mercury__cse_detection__detect_cse_in_proc_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i1006);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i2);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i8);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i9);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i10);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i12);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i13);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i14);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i15);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i16);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i17);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i18);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i19);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i20);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i21);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i11);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i24);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i27);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i28);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i29);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i25);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i30);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i31);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i33);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i32);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i34);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i37);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i38);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i39);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i35);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i40);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i41);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i44);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i45);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i46);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i42);
Declare_label(mercury__cse_detection__detect_cse_in_proc_6_0_i49);
Declare_static(mercury__cse_detection__detect_cse_in_preds_5_0);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i1001);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_preds_5_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_procs_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_procs_6_0_i1001);
Declare_label(mercury__cse_detection__detect_cse_in_procs_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_procs_6_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_goal_6_0);
Declare_static(mercury__cse_detection__detect_cse_in_goal_1_7_0);
Declare_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i2);
Declare_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i4);
Declare_static(mercury__cse_detection__detect_cse_in_goal_2_7_0);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i8);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i9);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i10);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i11);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i13);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i16);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i17);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i19);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i20);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i22);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i23);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i26);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i27);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i28);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i29);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i30);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i31);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i32);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i1011);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i34);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i35);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i36);
Declare_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i37);
Declare_static(mercury__cse_detection__detect_cse_in_conj_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i10);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i8);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i12);
Declare_label(mercury__cse_detection__detect_cse_in_conj_6_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_par_conj_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_disj_9_0);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i1004);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i9);
Declare_label(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
Declare_static(mercury__cse_detection__detect_cse_in_disj_2_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_cases_11_0);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i1005);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i8);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i10);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i11);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i13);
Declare_label(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
Declare_static(mercury__cse_detection__detect_cse_in_cases_2_6_0);
Declare_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i3);
Declare_static(mercury__cse_detection__detect_cse_in_ite_12_0);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i1007);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i9);
Declare_label(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
Declare_static(mercury__cse_detection__detect_cse_in_ite_2_10_0);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i2);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i3);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i4);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i5);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i6);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i7);
Declare_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i8);
Declare_static(mercury__cse_detection__common_deconstruct_2_7_0);
Declare_label(mercury__cse_detection__common_deconstruct_2_7_0_i3);
Declare_label(mercury__cse_detection__common_deconstruct_2_7_0_i4);
Declare_label(mercury__cse_detection__common_deconstruct_2_7_0_i6);
Declare_label(mercury__cse_detection__common_deconstruct_2_7_0_i1);
Declare_static(mercury__cse_detection__common_deconstruct_cases_2_7_0);
Declare_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i3);
Declare_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i4);
Declare_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i6);
Declare_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
Declare_static(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i7);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i9);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i10);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i11);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i12);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i13);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i14);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i3);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i16);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i24);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i26);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i27);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i29);
Declare_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i1039);
Declare_static(mercury__cse_detection__create_parallel_subterms_9_0);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i4);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i5);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i6);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i7);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i8);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i9);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i3);
Declare_label(mercury__cse_detection__create_parallel_subterms_9_0_i10);
Declare_static(mercury__cse_detection__pair_subterms_5_0);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i5);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i7);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i6);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i9);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i2);
Declare_label(mercury__cse_detection__pair_subterms_5_0_i11);
Declare_static(mercury____Unify___cse_detection__cse_info_0_0);
Declare_label(mercury____Unify___cse_detection__cse_info_0_0_i2);
Declare_label(mercury____Unify___cse_detection__cse_info_0_0_i4);
Declare_label(mercury____Unify___cse_detection__cse_info_0_0_i1);
Declare_static(mercury____Index___cse_detection__cse_info_0_0);
Declare_static(mercury____Compare___cse_detection__cse_info_0_0);
Declare_label(mercury____Compare___cse_detection__cse_info_0_0_i3);
Declare_label(mercury____Compare___cse_detection__cse_info_0_0_i7);
Declare_label(mercury____Compare___cse_detection__cse_info_0_0_i12);
Declare_static(mercury____Unify___cse_detection__cse_result_0_0);
Declare_static(mercury____Index___cse_detection__cse_result_0_0);
Declare_static(mercury____Compare___cse_detection__cse_result_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_cse_detection__type_ctor_info_cse_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_cse_detection__type_ctor_info_cse_result_0;

static const struct mercury_data_cse_detection__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_cse_detection__common_0;

static const struct mercury_data_cse_detection__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_cse_detection__common_1;

static const struct mercury_data_cse_detection__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_cse_detection__common_2;

static const struct mercury_data_cse_detection__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_cse_detection__common_3;

static const struct mercury_data_cse_detection__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_cse_detection__common_4;

static const struct mercury_data_cse_detection__common_5_struct {
	Word * f1;
}  mercury_data_cse_detection__common_5;

static const struct mercury_data_cse_detection__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_cse_detection__common_6;

static const struct mercury_data_cse_detection__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_cse_detection__common_7;

static const struct mercury_data_cse_detection__common_8_struct {
	Word * f1;
	Integer f2;
}  mercury_data_cse_detection__common_8;

static const struct mercury_data_cse_detection__common_9_struct {
	Word * f1;
	Word * f2;
}  mercury_data_cse_detection__common_9;

static const struct mercury_data_cse_detection__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_cse_detection__common_10;

static const struct mercury_data_cse_detection__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_cse_detection__common_11;

static const struct mercury_data_cse_detection__common_12_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_cse_detection__common_12;

static const struct mercury_data_cse_detection__common_13_struct {
	Word * f1;
}  mercury_data_cse_detection__common_13;

static const struct mercury_data_cse_detection__common_14_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_cse_detection__common_14;

static const struct mercury_data_cse_detection__type_ctor_functors_cse_result_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_cse_detection__type_ctor_functors_cse_result_0;

static const struct mercury_data_cse_detection__type_ctor_layout_cse_result_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_cse_detection__type_ctor_layout_cse_result_0;

static const struct mercury_data_cse_detection__type_ctor_functors_cse_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_cse_detection__type_ctor_functors_cse_info_0;

static const struct mercury_data_cse_detection__type_ctor_layout_cse_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_cse_detection__type_ctor_layout_cse_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_cse_detection__type_ctor_info_cse_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___cse_detection__cse_info_0_0),
	STATIC(mercury____Index___cse_detection__cse_info_0_0),
	STATIC(mercury____Compare___cse_detection__cse_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_cse_detection__type_ctor_functors_cse_info_0,
	(Word *) &mercury_data_cse_detection__type_ctor_layout_cse_info_0,
	MR_string_const("cse_detection", 13),
	MR_string_const("cse_info", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_cse_detection__type_ctor_info_cse_result_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___cse_detection__cse_result_0_0),
	STATIC(mercury____Index___cse_detection__cse_result_0_0),
	STATIC(mercury____Compare___cse_detection__cse_result_0_0),
	(Integer) 6,
	(Word *) &mercury_data_cse_detection__type_ctor_functors_cse_result_0,
	(Word *) &mercury_data_cse_detection__type_ctor_layout_cse_result_0,
	MR_string_const("cse_detection", 13),
	MR_string_const("cse_result", 10),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_cse_detection__common_0_struct mercury_data_cse_detection__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_cse_detection__common_1_struct mercury_data_cse_detection__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_cse_detection__common_2_struct mercury_data_cse_detection__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_cse_detection__common_3_struct mercury_data_cse_detection__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_2),
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_cse_detection__common_4_struct mercury_data_cse_detection__common_4 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_1)
};

static const struct mercury_data_cse_detection__common_5_struct mercury_data_cse_detection__common_5 = {
	(Word *) &mercury_data_cse_detection__type_ctor_info_cse_info_0
};

static const struct mercury_data_cse_detection__common_6_struct mercury_data_cse_detection__common_6 = {
	(Integer) 0,
	MR_string_const("cse_detection", 13),
	MR_string_const("cse_detection", 13),
	MR_string_const("find_bind_var_for_cse_in_deconstruct", 36),
	7,
	0,
	0,
	7,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_5)
};

static const struct mercury_data_cse_detection__common_7_struct mercury_data_cse_detection__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_6),
	STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0),
	(Integer) 0
};

static const struct mercury_data_cse_detection__common_8_struct mercury_data_cse_detection__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_cse_detection__common_9_struct mercury_data_cse_detection__common_9 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_cse_detection__common_10_struct mercury_data_cse_detection__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_cse_detection__common_11_struct mercury_data_cse_detection__common_11 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_cse_detection__common_12_struct mercury_data_cse_detection__common_12 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_9)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_cse_detection__common_13_struct mercury_data_cse_detection__common_13 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_cse_detection__common_14_struct mercury_data_cse_detection__common_14 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_13),
	MR_string_const("cse_info", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_cse_detection__type_ctor_functors_cse_result_0_struct mercury_data_cse_detection__type_ctor_functors_cse_result_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3)
};

static const struct mercury_data_cse_detection__type_ctor_layout_cse_result_0_struct mercury_data_cse_detection__type_ctor_layout_cse_result_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_cse_detection__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_cse_detection__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_cse_detection__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_cse_detection__common_10)
};

static const struct mercury_data_cse_detection__type_ctor_functors_cse_info_0_struct mercury_data_cse_detection__type_ctor_functors_cse_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_14)
};

static const struct mercury_data_cse_detection__type_ctor_layout_cse_info_0_struct mercury_data_cse_detection__type_ctor_layout_cse_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_cse_detection__common_14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(cse_detection_module0)
	init_entry(mercury____Index___cse_detection__cse_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___cse_detection__cse_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___cse_detection__cse_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);

BEGIN_MODULE(cse_detection_module1)
	init_entry(mercury__cse_detection__detect_cse_4_0);
	init_label(mercury__cse_detection__detect_cse_4_0_i2);
BEGIN_CODE

/* code for predicate 'detect_cse'/4 in mode 0 */
Define_entry(mercury__cse_detection__detect_cse_4_0);
	MR_incr_sp_push_msg(3, "cse_detection:detect_cse/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__cse_detection__detect_cse_4_0_i2,
		ENTRY(mercury__cse_detection__detect_cse_4_0));
Define_label(mercury__cse_detection__detect_cse_4_0_i2);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__cse_detection__detect_cse_in_preds_5_0),
		ENTRY(mercury__cse_detection__detect_cse_4_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_id_4_0);
Declare_entry(mercury__modes__modecheck_proc_8_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__switch_detection__detect_switches_in_proc_4_0);

BEGIN_MODULE(cse_detection_module2)
	init_entry(mercury__cse_detection__detect_cse_in_proc_6_0);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i1006);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i2);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i8);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i9);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i10);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i12);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i13);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i14);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i15);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i16);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i17);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i18);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i19);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i20);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i21);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i11);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i24);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i27);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i28);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i29);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i25);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i30);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i31);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i33);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i32);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i34);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i37);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i38);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i39);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i35);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i40);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i41);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i44);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i45);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i46);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i42);
	init_label(mercury__cse_detection__detect_cse_in_proc_6_0_i49);
BEGIN_CODE

/* code for predicate 'detect_cse_in_proc'/6 in mode 0 */
Define_entry(mercury__cse_detection__detect_cse_in_proc_6_0);
	MR_incr_sp_push_msg(13, "cse_detection:detect_cse_in_proc/6");
	MR_stackvar(13) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i1006);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i2,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i2);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i3,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i3);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i4,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i5,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i6,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i7,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i8,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i8);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i9,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__cse_detection__detect_cse_in_proc_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(11);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i10,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i10);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i12);
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i11);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i12);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_stackvar(9);
	MR_stackvar(5) = r2;
	MR_stackvar(10) = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i13,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i13);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(11);
	r4 = MR_stackvar(12);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i14,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i14);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = r2;
	r2 = MR_tempr1;
	MR_stackvar(10) = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i15,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i15);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_varset_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i16,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i16);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i17,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i17);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i18,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i18);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i19,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i19);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i20,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i20);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i21,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i21);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = MR_stackvar(4);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i11);
	if (((Integer) MR_stackvar(5) == (Integer) 0))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i49);
	MR_stackvar(3) = r1;
	r1 = (Integer) 18;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i24,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i24);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i25);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("% Repeating mode check for ", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i27,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i27);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i28,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i28);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i29,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i29);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i30);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i25);
	r4 = r2;
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i30);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__modes__modecheck_proc_8_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i31,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i31);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i32);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("mode check fails when repeated", 30);
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i33,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i33);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i34);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i32);
	MR_stackvar(3) = r1;
	r2 = r4;
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i34);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i35);
	r1 = (Word) MR_string_const("% Repeating switch detection for ", 33);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i37,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i37);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i38,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i38);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i39,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i39);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i40);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i35);
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i40);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i41,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i41);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i42);
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("% Repeating common deconstruction detection for ", 48);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i44,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i44);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i45,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i45);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__cse_detection__detect_cse_in_proc_6_0_i46,
		ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0));
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i46);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_proc_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i1006);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i42);
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_proc_6_0_i1006);
Define_label(mercury__cse_detection__detect_cse_in_proc_6_0_i49);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);

BEGIN_MODULE(cse_detection_module3)
	init_entry(mercury__cse_detection__detect_cse_in_preds_5_0);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i1001);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_preds_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_preds'/5 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_preds_5_0);
	MR_incr_sp_push_msg(5, "cse_detection:detect_cse_in_preds/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_preds_5_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__cse_detection__detect_cse_in_preds_5_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_preds_5_0));
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_preds_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__cse_detection__detect_cse_in_preds_5_0_i5,
		STATIC(mercury__cse_detection__detect_cse_in_preds_5_0));
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_preds_5_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__cse_detection__detect_cse_in_preds_5_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_preds_5_0));
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_preds_5_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_procs_6_0),
		mercury__cse_detection__detect_cse_in_preds_5_0_i7,
		STATIC(mercury__cse_detection__detect_cse_in_preds_5_0));
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_preds_5_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_preds_5_0_i1001);
Define_label(mercury__cse_detection__detect_cse_in_preds_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module4)
	init_entry(mercury__cse_detection__detect_cse_in_procs_6_0);
	init_label(mercury__cse_detection__detect_cse_in_procs_6_0_i1001);
	init_label(mercury__cse_detection__detect_cse_in_procs_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_procs_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_procs'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_procs_6_0);
	MR_incr_sp_push_msg(3, "cse_detection:detect_cse_in_procs/6");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_procs_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_procs_6_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_proc_6_0),
		mercury__cse_detection__detect_cse_in_procs_6_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_procs_6_0));
Define_label(mercury__cse_detection__detect_cse_in_procs_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_procs_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_procs_6_0_i1001);
Define_label(mercury__cse_detection__detect_cse_in_procs_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module5)
	init_entry(mercury__cse_detection__detect_cse_in_goal_6_0);
BEGIN_CODE

/* code for predicate 'detect_cse_in_goal'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_goal_6_0);
	tailcall(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		STATIC(mercury__cse_detection__detect_cse_in_goal_6_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);

BEGIN_MODULE(cse_detection_module6)
	init_entry(mercury__cse_detection__detect_cse_in_goal_1_7_0);
	init_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i2);
	init_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i4);
BEGIN_CODE

/* code for predicate 'detect_cse_in_goal_1'/7 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_goal_1_7_0);
	MR_incr_sp_push_msg(5, "cse_detection:detect_cse_in_goal_1/7");
	MR_stackvar(5) = (Word) MR_succip;
	r4 = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0),
		mercury__cse_detection__detect_cse_in_goal_1_7_0_i2,
		STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i2);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_1_7_0));
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_goal_1_7_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_tempr2;
	MR_stackvar(2) = r1;
	r1 = MR_tempr2;
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(3) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__cse_detection__detect_cse_in_goal_1_7_0_i3,
		STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i3);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_1_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__cse_detection__detect_cse_in_goal_1_7_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_1_7_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_1_7_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__instmap__pre_lambda_update_5_0);

BEGIN_MODULE(cse_detection_module7)
	init_entry(mercury__cse_detection__detect_cse_in_goal_2_7_0);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i8);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i9);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i10);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i11);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i13);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i16);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i17);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i19);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i20);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i22);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i23);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i26);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i27);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i28);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i29);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i30);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i31);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i32);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i1011);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i34);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i35);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i36);
	init_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i37);
BEGIN_CODE

/* code for predicate 'detect_cse_in_goal_2'/7 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_goal_2_7_0);
	MR_incr_sp_push_msg(14, "cse_detection:detect_cse_in_goal_2/7");
	MR_stackvar(14) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i4) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i1011) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i1011) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i8));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i4);
	r2 = r3;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r3 = r4;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_conj_6_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i5,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__cse_detection__detect_cse_in_goal_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i9) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i13) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i19) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i26) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i28) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i30) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i34) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i35) AND
		LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i37));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i9);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i10,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i11,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(2);
	r8 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	tailcall(STATIC(mercury__cse_detection__detect_cse_in_cases_11_0),
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i13);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i34);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r2, (Integer) 5);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	r4 = r3;
	r3 = MR_tempr1;
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r2, (Integer) 3);
	MR_stackvar(11) = MR_tempr1;
	MR_stackvar(12) = MR_const_field(MR_mktag(2), r2, (Integer) 6);
	MR_stackvar(13) = MR_const_field(MR_mktag(2), r2, (Integer) 7);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 4);
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__instmap__pre_lambda_update_5_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i16,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = r1;
	r1 = MR_stackvar(13);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_6_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i17,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i17);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 6, mercury__cse_detection__detect_cse_in_goal_2_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 8, mercury__cse_detection__detect_cse_in_goal_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(3), r3, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(3), r3, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 7) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 6) = MR_stackvar(12);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 5) = MR_stackvar(11);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 3) = MR_stackvar(9);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i19);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r6 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0_i20);
	r1 = r4;
	r2 = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__cse_detection__detect_cse_in_goal_2_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r3, (Integer) 2) = r5;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i20);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i22,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i22);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i23,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i23);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	tailcall(STATIC(mercury__cse_detection__detect_cse_in_disj_9_0),
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i26);
	r2 = r3;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = r4;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_6_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i27,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i27);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__cse_detection__detect_cse_in_goal_2_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i28);
	r2 = r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r3 = r4;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_6_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i29,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i29);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__cse_detection__detect_cse_in_goal_2_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 3) = r4;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i30);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i31,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i31);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i32,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i32);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(1);
	r7 = MR_stackvar(8);
	r8 = MR_stackvar(2);
	r9 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	tailcall(STATIC(mercury__cse_detection__detect_cse_in_ite_12_0),
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i1011);
	r3 = r1;
	r1 = r4;
	r2 = (Integer) 0;
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i34);
	r3 = r1;
	r1 = r4;
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i35);
	r2 = r3;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = r4;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_par_conj_6_0),
		mercury__cse_detection__detect_cse_in_goal_2_7_0_i36,
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i36);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_goal_2_7_0));
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__cse_detection__detect_cse_in_goal_2_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_goal_2_7_0_i37);
	r1 = (Word) MR_string_const("detect_cse_in_goal_2: unexpected bi_implication", 47);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0));
END_MODULE

Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__bool__or_3_0);

BEGIN_MODULE(cse_detection_module8)
	init_entry(mercury__cse_detection__detect_cse_in_conj_6_0);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i10);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i8);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i12);
	init_label(mercury__cse_detection__detect_cse_in_conj_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_conj'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_conj_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_conj_6_0_i3);
	MR_incr_sp_push_msg(6, "cse_detection:detect_cse_in_conj/6");
	MR_stackvar(6) = (Word) MR_succip;
	r4 = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0),
		mercury__cse_detection__detect_cse_in_conj_6_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_conj_6_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_tempr2;
	MR_stackvar(3) = r1;
	r1 = MR_tempr2;
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(4) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__cse_detection__detect_cse_in_conj_6_0_i5,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__cse_detection__detect_cse_in_conj_6_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	localcall(mercury__cse_detection__detect_cse_in_conj_6_0,
		LABEL(mercury__cse_detection__detect_cse_in_conj_6_0_i7),
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	r4 = MR_const_field(MR_mktag(0), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_conj_6_0_i8);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__cse_detection__detect_cse_in_conj_6_0_i10,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i10);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_conj_6_0_i12,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i8);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_conj_6_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	r1 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_conj_6_0_i12,
		STATIC(mercury__cse_detection__detect_cse_in_conj_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i12);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_conj_6_0_i3);
	r1 = r3;
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module9)
	init_entry(mercury__cse_detection__detect_cse_in_par_conj_6_0);
	init_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_par_conj'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_par_conj_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_par_conj_6_0_i3);
	MR_incr_sp_push_msg(3, "cse_detection:detect_cse_in_par_conj/6");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_par_conj_6_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_par_conj_6_0));
Define_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_par_conj_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r3 = MR_tempr1;
	localcall(mercury__cse_detection__detect_cse_in_par_conj_6_0,
		LABEL(mercury__cse_detection__detect_cse_in_par_conj_6_0_i5),
		STATIC(mercury__cse_detection__detect_cse_in_par_conj_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_par_conj_6_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_par_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_par_conj_6_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_par_conj_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_par_conj_6_0_i3);
	r1 = r3;
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__inst_match__inst_is_ground_or_any_2_0);

BEGIN_MODULE(cse_detection_module10)
	init_entry(mercury__cse_detection__detect_cse_in_disj_9_0);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i1004);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i9);
	init_label(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
BEGIN_CODE

/* code for predicate 'detect_cse_in_disj'/9 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_disj_9_0);
	MR_incr_sp_push_msg(8, "cse_detection:detect_cse_in_disj/9");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_9_0_i3);
	MR_stackvar(3) = r4;
	r1 = r2;
	r2 = r5;
	r3 = r6;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_disj_2_6_0),
		mercury__cse_detection__detect_cse_in_disj_9_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_disj_9_0));
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_9_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__cse_detection__detect_cse_in_disj_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r2 = MR_tempr1;
	MR_stackvar(6) = MR_tempr1;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__cse_detection__detect_cse_in_disj_9_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_disj_9_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_9_0));
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(5), (Integer) 2);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__cse_detection__detect_cse_in_disj_9_0_i7,
		STATIC(mercury__cse_detection__detect_cse_in_disj_9_0));
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__cse_detection__common_deconstruct_2_7_0),
		mercury__cse_detection__detect_cse_in_disj_9_0_i9,
		STATIC(mercury__cse_detection__detect_cse_in_disj_9_0));
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
	r1 = r2;
	r2 = (Integer) 1;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__cse_detection__detect_cse_in_disj_9_0, "hlds_goal:hlds_goal_expr/0");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_disj_9_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_disj_9_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_disj_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__cse_detection__detect_cse_in_disj_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r9, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r9, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_disj_9_0_i5);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_9_0_i1004);
END_MODULE


BEGIN_MODULE(cse_detection_module11)
	init_entry(mercury__cse_detection__detect_cse_in_disj_2_6_0);
	init_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_disj_2'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_disj_2_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_disj_2_6_0_i3);
	MR_incr_sp_push_msg(3, "cse_detection:detect_cse_in_disj_2/6");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_disj_2_6_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_disj_2_6_0));
Define_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_2_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r3 = MR_tempr1;
	localcall(mercury__cse_detection__detect_cse_in_disj_2_6_0,
		LABEL(mercury__cse_detection__detect_cse_in_disj_2_6_0_i5),
		STATIC(mercury__cse_detection__detect_cse_in_disj_2_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_2_6_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_disj_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_disj_2_6_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_disj_2_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_disj_2_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_disj_2_6_0_i3);
	r1 = r3;
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__var_1_0);

BEGIN_MODULE(cse_detection_module12)
	init_entry(mercury__cse_detection__detect_cse_in_cases_11_0);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i1005);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i8);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i10);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i11);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i13);
	init_label(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
BEGIN_CODE

/* code for predicate 'detect_cse_in_cases'/11 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_cases_11_0);
	MR_incr_sp_push_msg(10, "cse_detection:detect_cse_in_cases/11");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i1005);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = r4;
	r2 = r7;
	r3 = r8;
	MR_stackvar(5) = r6;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_cases_2_6_0),
		mercury__cse_detection__detect_cse_in_cases_11_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_cases_11_0));
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_11_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__cse_detection__detect_cse_in_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i3);
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(8) = r2;
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__cse_detection__detect_cse_in_cases_11_0_i8,
		STATIC(mercury__cse_detection__detect_cse_in_cases_11_0));
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i8);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_11_0));
	if (r1)
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__cse_detection__detect_cse_in_cases_11_0_i10,
		STATIC(mercury__cse_detection__detect_cse_in_cases_11_0));
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i10);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_11_0));
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(7), (Integer) 2);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__cse_detection__detect_cse_in_cases_11_0_i11,
		STATIC(mercury__cse_detection__detect_cse_in_cases_11_0));
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i11);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(7);
	call_localret(STATIC(mercury__cse_detection__common_deconstruct_cases_2_7_0),
		mercury__cse_detection__detect_cse_in_cases_11_0_i13,
		STATIC(mercury__cse_detection__detect_cse_in_cases_11_0));
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i13);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
	r1 = r2;
	r2 = (Integer) 1;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__cse_detection__detect_cse_in_cases_11_0, "hlds_goal:hlds_goal_expr/0");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_cases_11_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_cases_11_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_cases_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__cse_detection__detect_cse_in_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r9, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r9, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_cases_11_0_i5);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_11_0_i1005);
END_MODULE


BEGIN_MODULE(cse_detection_module13)
	init_entry(mercury__cse_detection__detect_cse_in_cases_2_6_0);
	init_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_cse_in_cases_2'/6 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_cases_2_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_cases_2_6_0_i3);
	MR_incr_sp_push_msg(4, "cse_detection:detect_cse_in_cases_2/6");
	MR_stackvar(4) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_cases_2_6_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_cases_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__cse_detection__detect_cse_in_cases_2_6_0,
		LABEL(mercury__cse_detection__detect_cse_in_cases_2_6_0_i5),
		STATIC(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r5 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_cases_2_6_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	r1 = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_cases_2_6_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_cases_2_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__cse_detection__detect_cse_in_cases_2_6_0_i3);
	r1 = r3;
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module14)
	init_entry(mercury__cse_detection__detect_cse_in_ite_12_0);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i1007);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i9);
	init_label(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
BEGIN_CODE

/* code for predicate 'detect_cse_in_ite'/12 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_ite_12_0);
	MR_incr_sp_push_msg(12, "cse_detection:detect_cse_in_ite/12");
	MR_stackvar(12) = (Word) MR_succip;
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i1007);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i3);
	r1 = r3;
	MR_stackvar(1) = r2;
	r2 = r4;
	r3 = r5;
	r4 = r8;
	r5 = r9;
	MR_stackvar(6) = r7;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0),
		mercury__cse_detection__detect_cse_in_ite_12_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_ite_12_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_12_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__cse_detection__detect_cse_in_ite_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	r3 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r2 = MR_tempr1;
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r9, (Integer) 2);
	r1 = r8;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__cse_detection__detect_cse_in_ite_12_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_ite_12_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_12_0));
	r2 = r1;
	r1 = MR_stackvar(11);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__cse_detection__detect_cse_in_ite_12_0_i7,
		STATIC(mercury__cse_detection__detect_cse_in_ite_12_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_12_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_12_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(9);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__cse_detection__common_deconstruct_2_7_0),
		mercury__cse_detection__detect_cse_in_ite_12_0_i9,
		STATIC(mercury__cse_detection__detect_cse_in_ite_12_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	r1 = r2;
	r5 = r2;
	r2 = (Integer) 1;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__cse_detection__detect_cse_in_ite_12_0, "hlds_goal:hlds_goal_expr/0");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_12_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_12_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_12_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__cse_detection__detect_cse_in_ite_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r9, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r6, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(6);
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r9, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__cse_detection__detect_cse_in_ite_12_0_i5);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__cse_detection__detect_cse_in_ite_12_0_i1007);
END_MODULE


BEGIN_MODULE(cse_detection_module15)
	init_entry(mercury__cse_detection__detect_cse_in_ite_2_10_0);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i2);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i3);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i4);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i5);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i6);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i7);
	init_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i8);
BEGIN_CODE

/* code for predicate 'detect_cse_in_ite_2'/10 in mode 0 */
Define_static(mercury__cse_detection__detect_cse_in_ite_2_10_0);
	MR_incr_sp_push_msg(7, "cse_detection:detect_cse_in_ite_2/10");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = r2;
	r3 = r4;
	MR_stackvar(3) = r4;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r5;
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_2_7_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i2,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i2);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__cse_detection__detect_cse_in_ite_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(6) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i3,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i3);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i4,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i5,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__cse_detection__detect_cse_in_goal_1_7_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i6,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	}
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	MR_stackvar(5) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i7,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__cse_detection__detect_cse_in_ite_2_10_0_i8,
		STATIC(mercury__cse_detection__detect_cse_in_ite_2_10_0));
Define_label(mercury__cse_detection__detect_cse_in_ite_2_10_0_i8);
	update_prof_current_proc(LABEL(mercury__cse_detection__detect_cse_in_ite_2_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__switch_detection__find_bind_var_8_0);

BEGIN_MODULE(cse_detection_module16)
	init_entry(mercury__cse_detection__common_deconstruct_2_7_0);
	init_label(mercury__cse_detection__common_deconstruct_2_7_0_i3);
	init_label(mercury__cse_detection__common_deconstruct_2_7_0_i4);
	init_label(mercury__cse_detection__common_deconstruct_2_7_0_i6);
	init_label(mercury__cse_detection__common_deconstruct_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'common_deconstruct_2'/7 in mode 0 */
Define_static(mercury__cse_detection__common_deconstruct_2_7_0);
	MR_incr_sp_push_msg(3, "cse_detection:common_deconstruct_2/7");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_2_7_0_i3);
	r2 = r4;
	r4 = r3;
	r1 = TRUE;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__cse_detection__common_deconstruct_2_7_0_i3);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__cse_detection__common_deconstruct_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r6, (Integer) 0) = r3;
	r3 = r2;
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r7 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3);
	r2 = (Word) (Word *) &mercury_data_cse_detection__type_ctor_info_cse_info_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_7);
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Integer) 0;
	call_localret(ENTRY(mercury__switch_detection__find_bind_var_8_0),
		mercury__cse_detection__common_deconstruct_2_7_0_i4,
		STATIC(mercury__cse_detection__common_deconstruct_2_7_0));
Define_label(mercury__cse_detection__common_deconstruct_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__common_deconstruct_2_7_0));
	if (((Integer) 1 != (Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_2_7_0_i1);
	r4 = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_2_7_0_i1);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__cse_detection__common_deconstruct_2_7_0,
		LABEL(mercury__cse_detection__common_deconstruct_2_7_0_i6),
		STATIC(mercury__cse_detection__common_deconstruct_2_7_0));
Define_label(mercury__cse_detection__common_deconstruct_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__common_deconstruct_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_2_7_0_i1);
	r1 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__cse_detection__common_deconstruct_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__cse_detection__common_deconstruct_2_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module17)
	init_entry(mercury__cse_detection__common_deconstruct_cases_2_7_0);
	init_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i3);
	init_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i4);
	init_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i6);
	init_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'common_deconstruct_cases_2'/7 in mode 0 */
Define_static(mercury__cse_detection__common_deconstruct_cases_2_7_0);
	MR_incr_sp_push_msg(4, "cse_detection:common_deconstruct_cases_2/7");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0_i3);
	r2 = r4;
	r4 = r3;
	r1 = TRUE;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i3);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__cse_detection__common_deconstruct_cases_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r6, (Integer) 0) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	r7 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_3);
	r2 = (Word) (Word *) &mercury_data_cse_detection__type_ctor_info_cse_info_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_7);
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Integer) 0;
	call_localret(ENTRY(mercury__switch_detection__find_bind_var_8_0),
		mercury__cse_detection__common_deconstruct_cases_2_7_0_i4,
		STATIC(mercury__cse_detection__common_deconstruct_cases_2_7_0));
	}
Define_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0));
	if (((Integer) 1 != (Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
	r4 = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__cse_detection__common_deconstruct_cases_2_7_0, "origin_lost_in_value_number");
	MR_tempr2 = r2;
	r2 = r4;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__cse_detection__common_deconstruct_cases_2_7_0,
		LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0_i6),
		STATIC(mercury__cse_detection__common_deconstruct_cases_2_7_0));
	}
Define_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
	r1 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__cse_detection__common_deconstruct_cases_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__cse_detection__common_deconstruct_cases_2_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__goal_util__rename_vars_in_goal_3_0);
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(cse_detection_module18)
	init_entry(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i7);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i9);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i10);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i11);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i12);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i13);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i14);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i3);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i16);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i24);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i26);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i27);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i29);
	init_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i1039);
BEGIN_CODE

/* code for predicate 'find_bind_var_for_cse_in_deconstruct'/7 in mode 0 */
Define_static(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0);
	MR_incr_sp_push_msg(9, "cse_detection:find_bind_var_for_cse_in_deconstruct/7");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i3);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
	MR_tempr3 = MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 4);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
	r6 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r9 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r8 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r7 = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 2);
	MR_tempr4 = MR_const_field(MR_mktag(3), MR_tempr3, (Integer) 2);
	r5 = MR_const_field(MR_mktag(3), MR_tempr3, (Integer) 5);
	if ((MR_tag(MR_tempr4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i7);
	r10 = r1;
	tag_incr_hp_msg(MR_tempr5, MR_mktag(3), (Integer) 6, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr5, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr5, (Integer) 3) = MR_const_field(MR_mktag(3), MR_tempr3, (Integer) 3);
	r1 = r6;
	MR_stackvar(1) = r9;
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r7;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r3;
	MR_stackvar(7) = MR_tempr5;
	MR_field(MR_mktag(3), MR_tempr5, (Integer) 2) = MR_tempr4;
	MR_field(MR_mktag(3), MR_tempr5, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 5, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 4) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 4);
	MR_field(MR_mktag(3), MR_stackvar(7), (Integer) 5) = r5;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 2) = r3;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = r10;
	MR_field(MR_mktag(3), MR_stackvar(7), (Integer) 4) = MR_tempr2;
	GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i10);
	}
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i7);
	MR_stackvar(1) = r9;
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r7;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r3;
	r1 = (Word) MR_string_const("unexpected unify structure in construct_common_unify", 52);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i9,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r1 = MR_stackvar(4);
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i10);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i11,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i11);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__cse_detection__create_parallel_subterms_9_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i12,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i12);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r5 = MR_stackvar(4);
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "origin_lost_in_value_number");
	r2 = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(7);
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goal_3_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i13,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i13);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "cse_detection:cse_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i4);
	r1 = (Word) MR_string_const("unexpected goal in construct_common_unify", 41);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i14,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i14);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i16,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	}
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i16);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0), (Integer) 4)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	if ((MR_tag(MR_const_field(MR_mktag(3), r2, (Integer) 4)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 4), (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r2, (Integer) 4), (Integer) 2);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 4), (Integer) 1);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r5, (Integer) 4), (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i24,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i24);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i1039);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i26,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i26);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i27,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i27);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	if ((MR_stackvar(8) != r1))
		GOTO_LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i1039);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__cse_detection__pair_subterms_5_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i29,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i19);
	r1 = (Word) MR_string_const("find_similar_deconstruct: non-deconstruct unify", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i29,
		STATIC(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i29);
	update_prof_current_proc(LABEL(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0));
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0_i1039);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__cse_detection__find_bind_var_for_cse_in_deconstruct_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_8);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__varset__new_var_3_0);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(cse_detection_module19)
	init_entry(mercury__cse_detection__create_parallel_subterms_9_0);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i4);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i5);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i6);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i7);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i8);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i9);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i3);
	init_label(mercury__cse_detection__create_parallel_subterms_9_0_i10);
BEGIN_CODE

/* code for predicate 'create_parallel_subterms'/9 in mode 0 */
Define_static(mercury__cse_detection__create_parallel_subterms_9_0);
	MR_incr_sp_push_msg(9, "cse_detection:create_parallel_subterms/9");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__create_parallel_subterms_9_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__cse_detection__create_parallel_subterms_9_0,
		LABEL(mercury__cse_detection__create_parallel_subterms_9_0_i4),
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i4);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(6) = r3;
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i5,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	MR_stackvar(3) = r2;
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_9);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i6,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i6);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_9);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i7,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i8,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i8);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__cse_detection__create_parallel_subterms_9_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i9,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
	}
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__cse_detection__create_parallel_subterms_9_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i3);
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__cse_detection__create_parallel_subterms_9_0_i10,
		STATIC(mercury__cse_detection__create_parallel_subterms_9_0));
Define_label(mercury__cse_detection__create_parallel_subterms_9_0_i10);
	update_prof_current_proc(LABEL(mercury__cse_detection__create_parallel_subterms_9_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module20)
	init_entry(mercury__cse_detection__pair_subterms_5_0);
	init_label(mercury__cse_detection__pair_subterms_5_0_i5);
	init_label(mercury__cse_detection__pair_subterms_5_0_i7);
	init_label(mercury__cse_detection__pair_subterms_5_0_i6);
	init_label(mercury__cse_detection__pair_subterms_5_0_i9);
	init_label(mercury__cse_detection__pair_subterms_5_0_i2);
	init_label(mercury__cse_detection__pair_subterms_5_0_i11);
BEGIN_CODE

/* code for predicate 'pair_subterms'/5 in mode 0 */
Define_static(mercury__cse_detection__pair_subterms_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__pair_subterms_5_0_i2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__pair_subterms_5_0_i2);
	MR_incr_sp_push_msg(6, "cse_detection:pair_subterms/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	localcall(mercury__cse_detection__pair_subterms_5_0,
		LABEL(mercury__cse_detection__pair_subterms_5_0_i5),
		STATIC(mercury__cse_detection__pair_subterms_5_0));
Define_label(mercury__cse_detection__pair_subterms_5_0_i5);
	update_prof_current_proc(LABEL(mercury__cse_detection__pair_subterms_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__cse_detection__pair_subterms_5_0_i7,
		STATIC(mercury__cse_detection__pair_subterms_5_0));
Define_label(mercury__cse_detection__pair_subterms_5_0_i7);
	update_prof_current_proc(LABEL(mercury__cse_detection__pair_subterms_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__cse_detection__pair_subterms_5_0_i6);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__cse_detection__pair_subterms_5_0_i6);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__cse_detection__pair_subterms_5_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__cse_detection__pair_subterms_5_0_i9,
		STATIC(mercury__cse_detection__pair_subterms_5_0));
	}
Define_label(mercury__cse_detection__pair_subterms_5_0_i9);
	update_prof_current_proc(LABEL(mercury__cse_detection__pair_subterms_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__cse_detection__pair_subterms_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__cse_detection__pair_subterms_5_0_i2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__pair_subterms_5_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__cse_detection__pair_subterms_5_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__cse_detection__pair_subterms_5_0_i11);
	r1 = (Word) MR_string_const("mismatched length lists in pair_subterms", 40);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__cse_detection__pair_subterms_5_0));
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);

BEGIN_MODULE(cse_detection_module21)
	init_entry(mercury____Unify___cse_detection__cse_info_0_0);
	init_label(mercury____Unify___cse_detection__cse_info_0_0_i2);
	init_label(mercury____Unify___cse_detection__cse_info_0_0_i4);
	init_label(mercury____Unify___cse_detection__cse_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___cse_detection__cse_info_0_0);
	MR_incr_sp_push_msg(5, "cse_detection:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___cse_detection__cse_info_0_0_i2,
		STATIC(mercury____Unify___cse_detection__cse_info_0_0));
Define_label(mercury____Unify___cse_detection__cse_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___cse_detection__cse_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___cse_detection__cse_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_9);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___cse_detection__cse_info_0_0_i4,
		STATIC(mercury____Unify___cse_detection__cse_info_0_0));
Define_label(mercury____Unify___cse_detection__cse_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___cse_detection__cse_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___cse_detection__cse_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		STATIC(mercury____Unify___cse_detection__cse_info_0_0));
Define_label(mercury____Unify___cse_detection__cse_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(cse_detection_module22)
	init_entry(mercury____Index___cse_detection__cse_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___cse_detection__cse_info_0_0);
	tailcall(STATIC(mercury____Index___cse_detection__cse_info_0__ua0_2_0),
		STATIC(mercury____Index___cse_detection__cse_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);

BEGIN_MODULE(cse_detection_module23)
	init_entry(mercury____Compare___cse_detection__cse_info_0_0);
	init_label(mercury____Compare___cse_detection__cse_info_0_0_i3);
	init_label(mercury____Compare___cse_detection__cse_info_0_0_i7);
	init_label(mercury____Compare___cse_detection__cse_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___cse_detection__cse_info_0_0);
	MR_incr_sp_push_msg(5, "cse_detection:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___cse_detection__cse_info_0_0_i3,
		STATIC(mercury____Compare___cse_detection__cse_info_0_0));
Define_label(mercury____Compare___cse_detection__cse_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___cse_detection__cse_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___cse_detection__cse_info_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_9);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___cse_detection__cse_info_0_0_i7,
		STATIC(mercury____Compare___cse_detection__cse_info_0_0));
Define_label(mercury____Compare___cse_detection__cse_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___cse_detection__cse_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___cse_detection__cse_info_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		STATIC(mercury____Compare___cse_detection__cse_info_0_0));
Define_label(mercury____Compare___cse_detection__cse_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(cse_detection_module24)
	init_entry(mercury____Unify___cse_detection__cse_result_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___cse_detection__cse_result_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_2);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___cse_detection__cse_result_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(cse_detection_module25)
	init_entry(mercury____Index___cse_detection__cse_result_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___cse_detection__cse_result_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_2);
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		STATIC(mercury____Index___cse_detection__cse_result_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(cse_detection_module26)
	init_entry(mercury____Compare___cse_detection__cse_result_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___cse_detection__cse_result_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_cse_detection__common_2);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___cse_detection__cse_result_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__cse_detection_maybe_bunch_0(void)
{
	cse_detection_module0();
	cse_detection_module1();
	cse_detection_module2();
	cse_detection_module3();
	cse_detection_module4();
	cse_detection_module5();
	cse_detection_module6();
	cse_detection_module7();
	cse_detection_module8();
	cse_detection_module9();
	cse_detection_module10();
	cse_detection_module11();
	cse_detection_module12();
	cse_detection_module13();
	cse_detection_module14();
	cse_detection_module15();
	cse_detection_module16();
	cse_detection_module17();
	cse_detection_module18();
	cse_detection_module19();
	cse_detection_module20();
	cse_detection_module21();
	cse_detection_module22();
	cse_detection_module23();
	cse_detection_module24();
	cse_detection_module25();
	cse_detection_module26();
}

#endif

void mercury__cse_detection__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__cse_detection__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__cse_detection_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_cse_detection__type_ctor_info_cse_info_0,
			cse_detection__cse_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_cse_detection__type_ctor_info_cse_result_0,
			cse_detection__cse_result_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
