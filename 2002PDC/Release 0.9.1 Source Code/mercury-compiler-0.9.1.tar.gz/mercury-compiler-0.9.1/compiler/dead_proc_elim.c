/*
** Automatically generated from `dead_proc_elim.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__dead_proc_elim__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___dead_proc_elim__dead_pred_info_0__ua0_2_0);
Declare_static(mercury____Index___dead_proc_elim__elim_info_0__ua0_2_0);
Declare_static(mercury__dead_proc_elim__IntroducedFrom__pred__pre_modecheck_examine_goal__838__4_3_0);
Declare_static(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i2);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i3);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i4);
Declare_static(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i2);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i3);
Declare_static(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i3);
Declare_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i2);
Define_extern_entry(mercury__dead_proc_elim__dead_proc_elim_4_0);
Declare_label(mercury__dead_proc_elim__dead_proc_elim_4_0_i2);
Define_extern_entry(mercury__dead_proc_elim__analyze_2_0);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i2);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i3);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i4);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i5);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i6);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i7);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i8);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i9);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i10);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i11);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i12);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i13);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i14);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i15);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i16);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i17);
Declare_label(mercury__dead_proc_elim__analyze_2_0_i18);
Define_extern_entry(mercury__dead_proc_elim__eliminate_5_0);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i2);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i3);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i4);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i5);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i6);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i7);
Declare_label(mercury__dead_proc_elim__eliminate_5_0_i8);
Define_extern_entry(mercury__dead_proc_elim__dead_pred_elim_2_0);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i2);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i3);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i4);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i5);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i6);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i7);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i8);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i9);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i10);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i11);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i12);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i13);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i14);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i15);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i16);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i17);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i18);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i19);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i20);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i21);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i22);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i23);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i24);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i25);
Declare_static(mercury__dead_proc_elim__initialize_preds_6_0);
Declare_label(mercury__dead_proc_elim__initialize_preds_6_0_i1001);
Declare_label(mercury__dead_proc_elim__initialize_preds_6_0_i4);
Declare_label(mercury__dead_proc_elim__initialize_preds_6_0_i5);
Declare_label(mercury__dead_proc_elim__initialize_preds_6_0_i6);
Declare_label(mercury__dead_proc_elim__initialize_preds_6_0_i3);
Declare_static(mercury__dead_proc_elim__initialize_procs_6_0);
Declare_label(mercury__dead_proc_elim__initialize_procs_6_0_i1001);
Declare_label(mercury__dead_proc_elim__initialize_procs_6_0_i4);
Declare_label(mercury__dead_proc_elim__initialize_procs_6_0_i5);
Declare_label(mercury__dead_proc_elim__initialize_procs_6_0_i3);
Declare_static(mercury__dead_proc_elim__initialize_pragma_exports_5_0);
Declare_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i1001);
Declare_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i4);
Declare_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i5);
Declare_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i3);
Declare_static(mercury__dead_proc_elim__initialize_base_gen_infos_5_0);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i1002);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i6);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i8);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i9);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i4);
Declare_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i3);
Declare_static(mercury__dead_proc_elim__initialize_class_methods_6_0);
Declare_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i2);
Declare_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i3);
Declare_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i4);
Declare_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i5);
Declare_static(mercury__dead_proc_elim__get_instance_pred_procs_5_0);
Declare_label(mercury__dead_proc_elim__get_instance_pred_procs_5_0_i3);
Declare_static(mercury__dead_proc_elim__get_class_pred_procs_5_0);
Declare_static(mercury__dead_proc_elim__examine_5_0);
Declare_label(mercury__dead_proc_elim__examine_5_0_i1005);
Declare_label(mercury__dead_proc_elim__examine_5_0_i3);
Declare_label(mercury__dead_proc_elim__examine_5_0_i6);
Declare_label(mercury__dead_proc_elim__examine_5_0_i5);
Declare_label(mercury__dead_proc_elim__examine_5_0_i9);
Declare_label(mercury__dead_proc_elim__examine_5_0_i13);
Declare_label(mercury__dead_proc_elim__examine_5_0_i14);
Declare_label(mercury__dead_proc_elim__examine_5_0_i15);
Declare_label(mercury__dead_proc_elim__examine_5_0_i16);
Declare_label(mercury__dead_proc_elim__examine_5_0_i18);
Declare_label(mercury__dead_proc_elim__examine_5_0_i19);
Declare_label(mercury__dead_proc_elim__examine_5_0_i20);
Declare_label(mercury__dead_proc_elim__examine_5_0_i11);
Declare_label(mercury__dead_proc_elim__examine_5_0_i23);
Declare_label(mercury__dead_proc_elim__examine_5_0_i26);
Declare_label(mercury__dead_proc_elim__examine_5_0_i28);
Declare_label(mercury__dead_proc_elim__examine_5_0_i25);
Declare_label(mercury__dead_proc_elim__examine_5_0_i2);
Declare_static(mercury__dead_proc_elim__find_base_gen_info_5_0);
Declare_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1004);
Declare_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i4);
Declare_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
Declare_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1);
Declare_static(mercury__dead_proc_elim__examine_refs_5_0);
Declare_label(mercury__dead_proc_elim__examine_refs_5_0_i1001);
Declare_label(mercury__dead_proc_elim__examine_refs_5_0_i4);
Declare_label(mercury__dead_proc_elim__examine_refs_5_0_i5);
Declare_label(mercury__dead_proc_elim__examine_refs_5_0_i3);
Declare_static(mercury__dead_proc_elim__examine_goals_6_0);
Declare_label(mercury__dead_proc_elim__examine_goals_6_0_i1001);
Declare_label(mercury__dead_proc_elim__examine_goals_6_0_i4);
Declare_label(mercury__dead_proc_elim__examine_goals_6_0_i3);
Declare_static(mercury__dead_proc_elim__examine_cases_6_0);
Declare_label(mercury__dead_proc_elim__examine_cases_6_0_i1001);
Declare_label(mercury__dead_proc_elim__examine_cases_6_0_i4);
Declare_label(mercury__dead_proc_elim__examine_cases_6_0_i3);
Declare_static(mercury__dead_proc_elim__examine_goal_6_0);
Declare_static(mercury__dead_proc_elim__examine_expr_6_0);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i1011);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i6);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i7);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i9);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i11);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i8);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i15);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i18);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i14);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i24);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i25);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i27);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i34);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i35);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i30);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i36);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i1013);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i28);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i41);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i43);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i45);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i46);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i47);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i49);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i50);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i52);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i54);
Declare_label(mercury__dead_proc_elim__examine_expr_6_0_i55);
Declare_static(mercury__dead_proc_elim__eliminate_pred_5_0);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i2);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i3);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i10);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i11);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i12);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i6);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i13);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i14);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i15);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i16);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i17);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i5);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i20);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i21);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i22);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i23);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i24);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i25);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i26);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i29);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i1015);
Declare_label(mercury__dead_proc_elim__eliminate_pred_5_0_i18);
Declare_static(mercury__dead_proc_elim__eliminate_proc_8_0);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i6);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i5);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i9);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i2);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i11);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i14);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i12);
Declare_label(mercury__dead_proc_elim__eliminate_proc_8_0_i16);
Declare_static(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i4);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i6);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i5);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i8);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i9);
Declare_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i3);
Declare_static(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i4);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i5);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i3);
Declare_static(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i2);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i4);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i5);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i6);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i10);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i8);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i13);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i14);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i12);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i17);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i18);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i16);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i24);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i27);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i28);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i20);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i31);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i30);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i34);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i35);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i36);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i3);
Declare_static(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i1002);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i3);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i6);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i5);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i8);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i9);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i10);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i11);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i12);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i14);
Declare_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i2);
Declare_static(mercury__dead_proc_elim__dead_pred_elim_process_clause_3_0);
Declare_static(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i1000);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i4);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i6);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i9);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i10);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i12);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i14);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i16);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i18);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i20);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i22);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i23);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i25);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i26);
Declare_static(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i1001);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i20);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i4);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i8);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i7);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i10);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i11);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i14);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i16);
Declare_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i12);
Declare_static(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i3);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i2);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i5);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i6);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i9);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i11);
Declare_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i7);
Define_extern_entry(mercury____Unify___dead_proc_elim__entity_0_0);
Declare_label(mercury____Unify___dead_proc_elim__entity_0_0_i5);
Declare_label(mercury____Unify___dead_proc_elim__entity_0_0_i3);
Declare_label(mercury____Unify___dead_proc_elim__entity_0_0_i10);
Declare_label(mercury____Unify___dead_proc_elim__entity_0_0_i1009);
Declare_label(mercury____Unify___dead_proc_elim__entity_0_0_i1);
Define_extern_entry(mercury____Index___dead_proc_elim__entity_0_0);
Declare_label(mercury____Index___dead_proc_elim__entity_0_0_i3);
Define_extern_entry(mercury____Compare___dead_proc_elim__entity_0_0);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i3);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i2);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i5);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i4);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i6);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i7);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i14);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i11);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i21);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i25);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i1017);
Declare_label(mercury____Compare___dead_proc_elim__entity_0_0_i34);
Define_extern_entry(mercury____Unify___dead_proc_elim__needed_map_0_0);
Define_extern_entry(mercury____Index___dead_proc_elim__needed_map_0_0);
Define_extern_entry(mercury____Compare___dead_proc_elim__needed_map_0_0);
Declare_static(mercury____Unify___dead_proc_elim__entity_queue_0_0);
Declare_static(mercury____Index___dead_proc_elim__entity_queue_0_0);
Declare_static(mercury____Compare___dead_proc_elim__entity_queue_0_0);
Declare_static(mercury____Unify___dead_proc_elim__examined_set_0_0);
Declare_static(mercury____Index___dead_proc_elim__examined_set_0_0);
Declare_static(mercury____Compare___dead_proc_elim__examined_set_0_0);
Declare_static(mercury____Unify___dead_proc_elim__elim_info_0_0);
Declare_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i2);
Declare_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i4);
Declare_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i1);
Declare_static(mercury____Index___dead_proc_elim__elim_info_0_0);
Declare_static(mercury____Compare___dead_proc_elim__elim_info_0_0);
Declare_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i3);
Declare_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i7);
Declare_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i12);
Declare_static(mercury____Unify___dead_proc_elim__dead_pred_info_0_0);
Declare_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i2);
Declare_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i4);
Declare_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i6);
Declare_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i8);
Declare_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
Declare_static(mercury____Index___dead_proc_elim__dead_pred_info_0_0);
Declare_static(mercury____Compare___dead_proc_elim__dead_pred_info_0_0);
Declare_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i3);
Declare_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i7);
Declare_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i11);
Declare_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i15);
Declare_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_elim_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_entity_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_entity_queue_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_examined_set_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_needed_map_0;

static const struct mercury_data_dead_proc_elim__common_0_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_0;

static const struct mercury_data_dead_proc_elim__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_1;

static const struct mercury_data_dead_proc_elim__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_2;

static const struct mercury_data_dead_proc_elim__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_3;

static const struct mercury_data_dead_proc_elim__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_4;

static const struct mercury_data_dead_proc_elim__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dead_proc_elim__common_5;

static const struct mercury_data_dead_proc_elim__common_6_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_6;

static const struct mercury_data_dead_proc_elim__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_dead_proc_elim__common_7;

static const struct mercury_data_dead_proc_elim__common_8_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_8;

static const struct mercury_data_dead_proc_elim__common_9_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_9;

static const struct mercury_data_dead_proc_elim__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_dead_proc_elim__common_10;

static const struct mercury_data_dead_proc_elim__common_11_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_11;

static const struct mercury_data_dead_proc_elim__common_12_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_12;

static const struct mercury_data_dead_proc_elim__common_13_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_13;

static const struct mercury_data_dead_proc_elim__common_14_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_14;

static const struct mercury_data_dead_proc_elim__common_15_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_dead_proc_elim__common_15;

static const struct mercury_data_dead_proc_elim__common_16_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_16;

static const struct mercury_data_dead_proc_elim__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_17;

static const struct mercury_data_dead_proc_elim__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_18;

static const struct mercury_data_dead_proc_elim__common_19_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_19;

static const struct mercury_data_dead_proc_elim__common_20_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_dead_proc_elim__common_20;

static const struct mercury_data_dead_proc_elim__common_21_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_21;

static const struct mercury_data_dead_proc_elim__common_22_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_22;

static const struct mercury_data_dead_proc_elim__common_23_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_dead_proc_elim__common_23;

static const struct mercury_data_dead_proc_elim__common_24_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_24;

static const struct mercury_data_dead_proc_elim__common_25_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dead_proc_elim__common_25;

static const struct mercury_data_dead_proc_elim__common_26_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_dead_proc_elim__common_26;

static const struct mercury_data_dead_proc_elim__common_27_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_27;

static const struct mercury_data_dead_proc_elim__common_28_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_dead_proc_elim__common_28;

static const struct mercury_data_dead_proc_elim__common_29_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_29;

static const struct mercury_data_dead_proc_elim__common_30_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_30;

static const struct mercury_data_dead_proc_elim__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_dead_proc_elim__common_31;

static const struct mercury_data_dead_proc_elim__common_32_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_32;

static const struct mercury_data_dead_proc_elim__common_33_struct {
	Integer f1;
}  mercury_data_dead_proc_elim__common_33;

static const struct mercury_data_dead_proc_elim__common_34_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dead_proc_elim__common_34;

static const struct mercury_data_dead_proc_elim__common_35_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_35;

static const struct mercury_data_dead_proc_elim__common_36_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_36;

static const struct mercury_data_dead_proc_elim__common_37_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
}  mercury_data_dead_proc_elim__common_37;

static const struct mercury_data_dead_proc_elim__common_38_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_dead_proc_elim__common_38;

static const struct mercury_data_dead_proc_elim__common_39_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_39;

static const struct mercury_data_dead_proc_elim__common_40_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_dead_proc_elim__common_40;

static const struct mercury_data_dead_proc_elim__common_41_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_41;

static const struct mercury_data_dead_proc_elim__common_42_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dead_proc_elim__common_42;

static const struct mercury_data_dead_proc_elim__common_43_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_dead_proc_elim__common_43;

static const struct mercury_data_dead_proc_elim__common_44_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_44;

static const struct mercury_data_dead_proc_elim__common_45_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_45;

static const struct mercury_data_dead_proc_elim__common_46_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_dead_proc_elim__common_46;

static const struct mercury_data_dead_proc_elim__common_47_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_dead_proc_elim__common_47;

static const struct mercury_data_dead_proc_elim__common_48_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_48;

static const struct mercury_data_dead_proc_elim__common_49_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_49;

static const struct mercury_data_dead_proc_elim__common_50_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_50;

static const struct mercury_data_dead_proc_elim__common_51_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_51;

static const struct mercury_data_dead_proc_elim__common_52_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_52;

static const struct mercury_data_dead_proc_elim__common_53_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_53;

static const struct mercury_data_dead_proc_elim__common_54_struct {
	Word * f1;
}  mercury_data_dead_proc_elim__common_54;

static const struct mercury_data_dead_proc_elim__common_55_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_dead_proc_elim__common_55;

static const struct mercury_data_dead_proc_elim__common_56_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_dead_proc_elim__common_56;

static const struct mercury_data_dead_proc_elim__common_57_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dead_proc_elim__common_57;

static const struct mercury_data_dead_proc_elim__common_58_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_dead_proc_elim__common_58;

static const struct mercury_data_dead_proc_elim__common_59_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dead_proc_elim__common_59;

static const struct mercury_data_dead_proc_elim__common_60_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_dead_proc_elim__common_60;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_needed_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__type_ctor_functors_needed_map_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_needed_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_needed_map_0;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_examined_set_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__type_ctor_functors_examined_set_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_examined_set_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_examined_set_0;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_entity_queue_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_dead_proc_elim__type_ctor_functors_entity_queue_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_entity_queue_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_entity_queue_0;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_entity_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_functors_entity_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_entity_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_entity_0;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_elim_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_dead_proc_elim__type_ctor_functors_elim_info_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_elim_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_elim_info_0;

static const struct mercury_data_dead_proc_elim__type_ctor_functors_dead_pred_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_dead_proc_elim__type_ctor_functors_dead_pred_info_0;

static const struct mercury_data_dead_proc_elim__type_ctor_layout_dead_pred_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dead_proc_elim__type_ctor_layout_dead_pred_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0),
	STATIC(mercury____Index___dead_proc_elim__dead_pred_info_0_0),
	STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_dead_pred_info_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_dead_pred_info_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_pred_info", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_elim_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dead_proc_elim__elim_info_0_0),
	STATIC(mercury____Index___dead_proc_elim__elim_info_0_0),
	STATIC(mercury____Compare___dead_proc_elim__elim_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_elim_info_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_elim_info_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("elim_info", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_entity_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dead_proc_elim__entity_0_0),
	ENTRY(mercury____Index___dead_proc_elim__entity_0_0),
	ENTRY(mercury____Compare___dead_proc_elim__entity_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_entity_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_entity_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("entity", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_entity_queue_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dead_proc_elim__entity_queue_0_0),
	STATIC(mercury____Index___dead_proc_elim__entity_queue_0_0),
	STATIC(mercury____Compare___dead_proc_elim__entity_queue_0_0),
	(Integer) 6,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_entity_queue_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_entity_queue_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("entity_queue", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_examined_set_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dead_proc_elim__examined_set_0_0),
	STATIC(mercury____Index___dead_proc_elim__examined_set_0_0),
	STATIC(mercury____Compare___dead_proc_elim__examined_set_0_0),
	(Integer) 6,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_examined_set_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_examined_set_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("examined_set", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_dead_proc_elim__type_ctor_info_needed_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___dead_proc_elim__needed_map_0_0),
	ENTRY(mercury____Index___dead_proc_elim__needed_map_0_0),
	ENTRY(mercury____Compare___dead_proc_elim__needed_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_functors_needed_map_0,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_layout_needed_map_0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("needed_map", 10),
	(Integer) 3
};

static const struct mercury_data_dead_proc_elim__common_0_struct mercury_data_dead_proc_elim__common_0 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_dead_proc_elim__common_1_struct mercury_data_dead_proc_elim__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_dead_proc_elim__common_2_struct mercury_data_dead_proc_elim__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
static const struct mercury_data_dead_proc_elim__common_3_struct mercury_data_dead_proc_elim__common_3 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_queue__type_ctor_info_queue_1;
static const struct mercury_data_dead_proc_elim__common_4_struct mercury_data_dead_proc_elim__common_4 = {
	(Word *) &mercury_data_queue__type_ctor_info_queue_1,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_dead_proc_elim__common_5_struct mercury_data_dead_proc_elim__common_5 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1)
};

static const struct mercury_data_dead_proc_elim__common_6_struct mercury_data_dead_proc_elim__common_6 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0
};

static const struct mercury_data_dead_proc_elim__common_7_struct mercury_data_dead_proc_elim__common_7 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("get_instance_pred_procs", 23),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5)
};

static const struct mercury_data_dead_proc_elim__common_8_struct mercury_data_dead_proc_elim__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_7),
	STATIC(mercury__dead_proc_elim__get_instance_pred_procs_5_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
static const struct mercury_data_dead_proc_elim__common_9_struct mercury_data_dead_proc_elim__common_9 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0
};

static const struct mercury_data_dead_proc_elim__common_10_struct mercury_data_dead_proc_elim__common_10 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("get_class_pred_procs", 20),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5)
};

static const struct mercury_data_dead_proc_elim__common_11_struct mercury_data_dead_proc_elim__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_10),
	STATIC(mercury__dead_proc_elim__get_class_pred_procs_5_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_12_struct mercury_data_dead_proc_elim__common_12 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_dead_proc_elim__common_13_struct mercury_data_dead_proc_elim__common_13 = {
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_elim_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_dead_proc_elim__common_14_struct mercury_data_dead_proc_elim__common_14 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_dead_proc_elim__common_15_struct mercury_data_dead_proc_elim__common_15 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("eliminate_pred", 14),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_14)
};

static const struct mercury_data_dead_proc_elim__common_16_struct mercury_data_dead_proc_elim__common_16 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_15),
	STATIC(mercury__dead_proc_elim__eliminate_pred_5_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_17_struct mercury_data_dead_proc_elim__common_17 = {
	(Word *) &mercury_data_queue__type_ctor_info_queue_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_dead_proc_elim__common_18_struct mercury_data_dead_proc_elim__common_18 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_dead_proc_elim__common_19_struct mercury_data_dead_proc_elim__common_19 = {
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0
};

static const struct mercury_data_dead_proc_elim__common_20_struct mercury_data_dead_proc_elim__common_20 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_pred_elim_add_entity", 25),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_19),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18)
};

static const struct mercury_data_dead_proc_elim__common_21_struct mercury_data_dead_proc_elim__common_21 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_20),
	STATIC(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_22_struct mercury_data_dead_proc_elim__common_22 = {
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0
};

static const struct mercury_data_dead_proc_elim__common_23_struct mercury_data_dead_proc_elim__common_23 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_pred_elim_initialize", 25),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22)
};

static const struct mercury_data_dead_proc_elim__common_24_struct mercury_data_dead_proc_elim__common_24 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_23),
	STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_25_struct mercury_data_dead_proc_elim__common_25 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_2)
};

static const struct mercury_data_dead_proc_elim__common_26_struct mercury_data_dead_proc_elim__common_26 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("IntroducedFrom__pred__dead_pred_elim__722__1", 44),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_25),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_dead_proc_elim__common_27_struct mercury_data_dead_proc_elim__common_27 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_dead_proc_elim__common_28_struct mercury_data_dead_proc_elim__common_28 = {
	(Integer) 0,
	MR_string_const("hlds_module", 11),
	MR_string_const("hlds_module", 11),
	MR_string_const("module_info_remove_predicate", 28),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_27)
};

Declare_entry(mercury__hlds_module__module_info_remove_predicate_3_0);
static const struct mercury_data_dead_proc_elim__common_29_struct mercury_data_dead_proc_elim__common_29 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_28),
	ENTRY(mercury__hlds_module__module_info_remove_predicate_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
static const struct mercury_data_dead_proc_elim__common_30_struct mercury_data_dead_proc_elim__common_30 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0
};

static const struct mercury_data_dead_proc_elim__common_31_struct mercury_data_dead_proc_elim__common_31 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("IntroducedFrom__pred__get_class_interface_pred_procs__261__2", 60),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_30),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5)
};

static const struct mercury_data_dead_proc_elim__common_32_struct mercury_data_dead_proc_elim__common_32 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_31),
	STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_33_struct mercury_data_dead_proc_elim__common_33 = {
	(Integer) 1
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_data_dead_proc_elim__common_34_struct mercury_data_dead_proc_elim__common_34 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_dead_proc_elim__common_35_struct mercury_data_dead_proc_elim__common_35 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

static const struct mercury_data_dead_proc_elim__common_36_struct mercury_data_dead_proc_elim__common_36 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

static const struct mercury_data_dead_proc_elim__common_37_struct mercury_data_dead_proc_elim__common_37 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("eliminate_proc", 14),
	8,
	0,
	0,
	8,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_14)
};

static const struct mercury_data_dead_proc_elim__common_38_struct mercury_data_dead_proc_elim__common_38 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("IntroducedFrom__pred__eliminate_pred__571__3", 44),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_clause_0;
static const struct mercury_data_dead_proc_elim__common_39_struct mercury_data_dead_proc_elim__common_39 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_clause_0
};

static const struct mercury_data_dead_proc_elim__common_40_struct mercury_data_dead_proc_elim__common_40 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_pred_elim_process_clause", 29),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_39),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22)
};

static const struct mercury_data_dead_proc_elim__common_41_struct mercury_data_dead_proc_elim__common_41 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_40),
	STATIC(mercury__dead_proc_elim__dead_pred_elim_process_clause_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_dead_proc_elim__common_42_struct mercury_data_dead_proc_elim__common_42 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

static const struct mercury_data_dead_proc_elim__common_43_struct mercury_data_dead_proc_elim__common_43 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("pre_modecheck_examine_goal", 26),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_42),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22)
};

static const struct mercury_data_dead_proc_elim__common_44_struct mercury_data_dead_proc_elim__common_44 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_43),
	STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_case_0;
static const struct mercury_data_dead_proc_elim__common_45_struct mercury_data_dead_proc_elim__common_45 = {
	(Word *) &mercury_data_hlds_goal__type_ctor_info_case_0
};

static const struct mercury_data_dead_proc_elim__common_46_struct mercury_data_dead_proc_elim__common_46 = {
	(Integer) 0,
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("dead_proc_elim", 14),
	MR_string_const("IntroducedFrom__pred__pre_modecheck_examine_goal__838__4", 56),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_45),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_22)
};

static const struct mercury_data_dead_proc_elim__common_47_struct mercury_data_dead_proc_elim__common_47 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_46),
	STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__pre_modecheck_examine_goal__838__4_3_0),
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_48_struct mercury_data_dead_proc_elim__common_48 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5)
};

static const struct mercury_data_dead_proc_elim__common_49_struct mercury_data_dead_proc_elim__common_49 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0
};

static const struct mercury_data_dead_proc_elim__common_50_struct mercury_data_dead_proc_elim__common_50 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_49)
};

static const struct mercury_data_dead_proc_elim__common_51_struct mercury_data_dead_proc_elim__common_51 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_dead_proc_elim__common_52_struct mercury_data_dead_proc_elim__common_52 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_dead_proc_elim__common_53_struct mercury_data_dead_proc_elim__common_53 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_dead_proc_elim__common_54_struct mercury_data_dead_proc_elim__common_54 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_dead_proc_elim__common_55_struct mercury_data_dead_proc_elim__common_55 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_53),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_54),
	MR_string_const("base_gen_info", 13),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_56_struct mercury_data_dead_proc_elim__common_56 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_36),
	MR_string_const("proc", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
static const struct mercury_data_dead_proc_elim__common_57_struct mercury_data_dead_proc_elim__common_57 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

static const struct mercury_data_dead_proc_elim__common_58_struct mercury_data_dead_proc_elim__common_58 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_57),
	MR_string_const("elimination_info", 16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__common_59_struct mercury_data_dead_proc_elim__common_59 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0
};

static const struct mercury_data_dead_proc_elim__common_60_struct mercury_data_dead_proc_elim__common_60 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_59),
	MR_string_const("dead_pred_info", 14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_needed_map_0_struct mercury_data_dead_proc_elim__type_ctor_functors_needed_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_needed_map_0_struct mercury_data_dead_proc_elim__type_ctor_layout_needed_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_48),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_48),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_48),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_48)
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_examined_set_0_struct mercury_data_dead_proc_elim__type_ctor_functors_examined_set_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_49)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_examined_set_0_struct mercury_data_dead_proc_elim__type_ctor_layout_examined_set_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_50),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_50),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_50),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_50)
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_entity_queue_0_struct mercury_data_dead_proc_elim__type_ctor_functors_entity_queue_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_entity_queue_0_struct mercury_data_dead_proc_elim__type_ctor_layout_entity_queue_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_51),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_51),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_51),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_dead_proc_elim__common_51)
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_entity_0_struct mercury_data_dead_proc_elim__type_ctor_functors_entity_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_56)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_entity_0_struct mercury_data_dead_proc_elim__type_ctor_layout_entity_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_56),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_55),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_elim_info_0_struct mercury_data_dead_proc_elim__type_ctor_functors_elim_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_58)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_elim_info_0_struct mercury_data_dead_proc_elim__type_ctor_layout_elim_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_58),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_dead_proc_elim__type_ctor_functors_dead_pred_info_0_struct mercury_data_dead_proc_elim__type_ctor_functors_dead_pred_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_60)
};

static const struct mercury_data_dead_proc_elim__type_ctor_layout_dead_pred_info_0_struct mercury_data_dead_proc_elim__type_ctor_layout_dead_pred_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_60),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(dead_proc_elim_module0)
	init_entry(mercury____Index___dead_proc_elim__dead_pred_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dead_proc_elim__dead_pred_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__dead_pred_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module1)
	init_entry(mercury____Index___dead_proc_elim__elim_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dead_proc_elim__elim_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__elim_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module2)
	init_entry(mercury__dead_proc_elim__IntroducedFrom__pred__pre_modecheck_examine_goal__838__4_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pre_modecheck_examine_goal__838__4'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__IntroducedFrom__pred__pre_modecheck_examine_goal__838__4_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0),
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__pre_modecheck_examine_goal__838__4_3_0));
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(dead_proc_elim_module3)
	init_entry(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i2);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i3);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i4);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__eliminate_pred__571__3'/4 in mode 0 */
Define_static(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0);
	MR_incr_sp_push_msg(4, "dead_proc_elim:IntroducedFrom__pred__eliminate_pred__571__3/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r1;
	r4 = r2;
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i2,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i3,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i4,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__det_update_4_0),
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0));
END_MODULE

Declare_entry(mercury__queue__put_3_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(dead_proc_elim_module4)
	init_entry(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i2);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i3);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_class_interface_pred_procs__261__2'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0);
	MR_incr_sp_push_msg(3, "dead_proc_elim:IntroducedFrom__pred__get_class_interface_pred_procs__261__2/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i2,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i3,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__get_class_interface_pred_procs__261__2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__set__insert_list_3_0);

BEGIN_MODULE(dead_proc_elim_module5)
	init_entry(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i3);
	init_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__dead_pred_elim__722__1'/4 in mode 0 */
Define_static(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0);
	MR_incr_sp_push_msg(2, "dead_proc_elim:IntroducedFrom__pred__dead_pred_elim__722__1/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = r1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i3,
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i2);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0));
Define_label(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module6)
	init_entry(mercury__dead_proc_elim__dead_proc_elim_4_0);
	init_label(mercury__dead_proc_elim__dead_proc_elim_4_0_i2);
BEGIN_CODE

/* code for predicate 'dead_proc_elim'/4 in mode 0 */
Define_entry(mercury__dead_proc_elim__dead_proc_elim_4_0);
	MR_incr_sp_push_msg(3, "dead_proc_elim:dead_proc_elim/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__dead_proc_elim__analyze_2_0),
		mercury__dead_proc_elim__dead_proc_elim_4_0_i2,
		ENTRY(mercury__dead_proc_elim__dead_proc_elim_4_0));
Define_label(mercury__dead_proc_elim__dead_proc_elim_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_proc_elim_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__dead_proc_elim__eliminate_5_0),
		ENTRY(mercury__dead_proc_elim__dead_proc_elim_4_0));
END_MODULE

Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__queue__init_1_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__hlds_module__module_info_preds_2_0);
Declare_entry(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0);
Declare_entry(mercury__hlds_module__module_info_base_gen_infos_2_0);
Declare_entry(mercury__hlds_module__module_info_classes_2_0);
Declare_entry(mercury__hlds_module__module_info_instances_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_class_id_0;
Declare_entry(mercury__map__values_2_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__list__foldl2_6_0);

BEGIN_MODULE(dead_proc_elim_module7)
	init_entry(mercury__dead_proc_elim__analyze_2_0);
	init_label(mercury__dead_proc_elim__analyze_2_0_i2);
	init_label(mercury__dead_proc_elim__analyze_2_0_i3);
	init_label(mercury__dead_proc_elim__analyze_2_0_i4);
	init_label(mercury__dead_proc_elim__analyze_2_0_i5);
	init_label(mercury__dead_proc_elim__analyze_2_0_i6);
	init_label(mercury__dead_proc_elim__analyze_2_0_i7);
	init_label(mercury__dead_proc_elim__analyze_2_0_i8);
	init_label(mercury__dead_proc_elim__analyze_2_0_i9);
	init_label(mercury__dead_proc_elim__analyze_2_0_i10);
	init_label(mercury__dead_proc_elim__analyze_2_0_i11);
	init_label(mercury__dead_proc_elim__analyze_2_0_i12);
	init_label(mercury__dead_proc_elim__analyze_2_0_i13);
	init_label(mercury__dead_proc_elim__analyze_2_0_i14);
	init_label(mercury__dead_proc_elim__analyze_2_0_i15);
	init_label(mercury__dead_proc_elim__analyze_2_0_i16);
	init_label(mercury__dead_proc_elim__analyze_2_0_i17);
	init_label(mercury__dead_proc_elim__analyze_2_0_i18);
BEGIN_CODE

/* code for predicate 'analyze'/2 in mode 0 */
Define_entry(mercury__dead_proc_elim__analyze_2_0);
	MR_incr_sp_push_msg(6, "dead_proc_elim:analyze/2");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__dead_proc_elim__analyze_2_0_i2,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__dead_proc_elim__analyze_2_0_i3,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__dead_proc_elim__analyze_2_0_i4,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dead_proc_elim__analyze_2_0_i5,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dead_proc_elim__analyze_2_0_i6,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_preds_6_0),
		mercury__dead_proc_elim__analyze_2_0_i7,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i7);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__dead_proc_elim__analyze_2_0_i8,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_pragma_exports_5_0),
		mercury__dead_proc_elim__analyze_2_0_i9,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_base_gen_infos_2_0),
		mercury__dead_proc_elim__analyze_2_0_i10,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i10);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_base_gen_infos_5_0),
		mercury__dead_proc_elim__analyze_2_0_i11,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_classes_2_0),
		mercury__dead_proc_elim__analyze_2_0_i12,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i12);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_instances_2_0),
		mercury__dead_proc_elim__analyze_2_0_i13,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i13);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_3);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__dead_proc_elim__analyze_2_0_i14,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__dead_proc_elim__analyze_2_0_i15,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i15);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_8);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__dead_proc_elim__analyze_2_0_i16,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__dead_proc_elim__analyze_2_0_i17,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i17);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_11);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__dead_proc_elim__analyze_2_0_i18,
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
Define_label(mercury__dead_proc_elim__analyze_2_0_i18);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__analyze_2_0));
	r4 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_5_0),
		ENTRY(mercury__dead_proc_elim__analyze_2_0));
END_MODULE

Declare_entry(mercury__list__foldl2_6_4);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
Declare_entry(mercury__hlds_module__module_info_set_base_gen_infos_3_0);

BEGIN_MODULE(dead_proc_elim_module8)
	init_entry(mercury__dead_proc_elim__eliminate_5_0);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i2);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i3);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i4);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i5);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i6);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i7);
	init_label(mercury__dead_proc_elim__eliminate_5_0_i8);
BEGIN_CODE

/* code for predicate 'eliminate'/5 in mode 0 */
Define_entry(mercury__dead_proc_elim__eliminate_5_0);
	MR_incr_sp_push_msg(5, "dead_proc_elim:eliminate/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dead_proc_elim__eliminate_5_0_i2,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dead_proc_elim__eliminate_5_0_i3,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 3, mercury__dead_proc_elim__eliminate_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r6, (Integer) 2) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_elim_info_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_16);
	r5 = MR_stackvar(4);
	r7 = MR_stackvar(3);
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl2_6_4),
		mercury__dead_proc_elim__eliminate_5_0_i4,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__dead_proc_elim__eliminate_5_0_i5,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_base_gen_infos_2_0),
		mercury__dead_proc_elim__eliminate_5_0_i6,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0),
		mercury__dead_proc_elim__eliminate_5_0_i7,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i7);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_base_gen_infos_3_0),
		mercury__dead_proc_elim__eliminate_5_0_i8,
		ENTRY(mercury__dead_proc_elim__eliminate_5_0));
Define_label(mercury__dead_proc_elim__eliminate_5_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__list__foldl_4_1);
Declare_entry(mercury__hlds_module__module_info_type_spec_info_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__set__intersect_3_0);
Declare_entry(mercury__hlds_module__module_info_set_type_spec_info_3_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__set__difference_3_0);

BEGIN_MODULE(dead_proc_elim_module9)
	init_entry(mercury__dead_proc_elim__dead_pred_elim_2_0);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i2);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i3);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i4);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i5);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i6);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i7);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i8);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i9);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i10);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i11);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i12);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i13);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i14);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i15);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i16);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i17);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i18);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i19);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i20);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i21);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i22);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i23);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i24);
	init_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i25);
BEGIN_CODE

/* code for predicate 'dead_pred_elim'/2 in mode 0 */
Define_entry(mercury__dead_proc_elim__dead_pred_elim_2_0);
	MR_incr_sp_push_msg(8, "dead_proc_elim:dead_pred_elim/2");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i2,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i3,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i4,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_pragma_exports_5_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i5,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r1 = MR_stackvar(1);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_instances_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i6,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_classes_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i7,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i7);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i8,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r3 = r2;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i9,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i10,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i10);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i11,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r7 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_17);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_21);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i12,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i12);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i13,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i13);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i14,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_elim_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i15,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i15);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r5 = MR_stackvar(1);
	r4 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_24);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i16,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	call_localret(STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i17,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i17);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_type_spec_info_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i18,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i18);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i19,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i19);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_18);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__dead_proc_elim__dead_pred_elim_2_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_26);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__dead_pred_elim__722__1_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i20,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i20);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r3 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i21,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i21);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__dead_proc_elim__dead_pred_elim_2_0, "hlds_module:type_spec_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_type_spec_info_3_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i22,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i22);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i23,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i23);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i24,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i24);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dead_proc_elim__dead_pred_elim_2_0_i25,
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_2_0_i25);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_2_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_29);
	r5 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		ENTRY(mercury__dead_proc_elim__dead_pred_elim_2_0));
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_exported_procids_2_0);

BEGIN_MODULE(dead_proc_elim_module10)
	init_entry(mercury__dead_proc_elim__initialize_preds_6_0);
	init_label(mercury__dead_proc_elim__initialize_preds_6_0_i1001);
	init_label(mercury__dead_proc_elim__initialize_preds_6_0_i4);
	init_label(mercury__dead_proc_elim__initialize_preds_6_0_i5);
	init_label(mercury__dead_proc_elim__initialize_preds_6_0_i6);
	init_label(mercury__dead_proc_elim__initialize_preds_6_0_i3);
BEGIN_CODE

/* code for predicate 'initialize_preds'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__initialize_preds_6_0);
	MR_incr_sp_push_msg(6, "dead_proc_elim:initialize_preds/6");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__initialize_preds_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__initialize_preds_6_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dead_proc_elim__initialize_preds_6_0_i4,
		STATIC(mercury__dead_proc_elim__initialize_preds_6_0));
Define_label(mercury__dead_proc_elim__initialize_preds_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_preds_6_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_exported_procids_2_0),
		mercury__dead_proc_elim__initialize_preds_6_0_i5,
		STATIC(mercury__dead_proc_elim__initialize_preds_6_0));
Define_label(mercury__dead_proc_elim__initialize_preds_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_preds_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__dead_proc_elim__initialize_procs_6_0),
		mercury__dead_proc_elim__initialize_preds_6_0_i6,
		STATIC(mercury__dead_proc_elim__initialize_preds_6_0));
Define_label(mercury__dead_proc_elim__initialize_preds_6_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_preds_6_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__dead_proc_elim__initialize_preds_6_0_i1001);
Define_label(mercury__dead_proc_elim__initialize_preds_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module11)
	init_entry(mercury__dead_proc_elim__initialize_procs_6_0);
	init_label(mercury__dead_proc_elim__initialize_procs_6_0_i1001);
	init_label(mercury__dead_proc_elim__initialize_procs_6_0_i4);
	init_label(mercury__dead_proc_elim__initialize_procs_6_0_i5);
	init_label(mercury__dead_proc_elim__initialize_procs_6_0_i3);
BEGIN_CODE

/* code for predicate 'initialize_procs'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__initialize_procs_6_0);
	MR_incr_sp_push_msg(5, "dead_proc_elim:initialize_procs/6");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__initialize_procs_6_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__initialize_procs_6_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__initialize_procs_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__initialize_procs_6_0_i4,
		STATIC(mercury__dead_proc_elim__initialize_procs_6_0));
	}
Define_label(mercury__dead_proc_elim__initialize_procs_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_procs_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r4 = MR_stackvar(4);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__initialize_procs_6_0_i5,
		STATIC(mercury__dead_proc_elim__initialize_procs_6_0));
Define_label(mercury__dead_proc_elim__initialize_procs_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_procs_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__dead_proc_elim__initialize_procs_6_0_i1001);
Define_label(mercury__dead_proc_elim__initialize_procs_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module12)
	init_entry(mercury__dead_proc_elim__initialize_pragma_exports_5_0);
	init_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i1001);
	init_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i4);
	init_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i5);
	init_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i3);
BEGIN_CODE

/* code for predicate 'initialize_pragma_exports'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__initialize_pragma_exports_5_0);
	MR_incr_sp_push_msg(4, "dead_proc_elim:initialize_pragma_exports/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i3);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__initialize_pragma_exports_5_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__initialize_pragma_exports_5_0_i4,
		STATIC(mercury__dead_proc_elim__initialize_pragma_exports_5_0));
	}
Define_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_pragma_exports_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r4 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__initialize_pragma_exports_5_0_i5,
		STATIC(mercury__dead_proc_elim__initialize_pragma_exports_5_0));
Define_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_pragma_exports_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i1001);
Define_label(mercury__dead_proc_elim__initialize_pragma_exports_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__std_util__semidet_succeed_0_0);

BEGIN_MODULE(dead_proc_elim_module13)
	init_entry(mercury__dead_proc_elim__initialize_base_gen_infos_5_0);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i1002);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i6);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i8);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i9);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i4);
	init_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i3);
BEGIN_CODE

/* code for predicate 'initialize_base_gen_infos'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__initialize_base_gen_infos_5_0);
	MR_incr_sp_push_msg(7, "dead_proc_elim:initialize_base_gen_infos/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__std_util__semidet_succeed_0_0),
		mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i6,
		STATIC(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
	}
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__dead_proc_elim__initialize_base_gen_infos_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_stackvar(4) = r3;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i8,
		STATIC(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i9,
		STATIC(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i1002);
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i1002);
Define_label(mercury__dead_proc_elim__initialize_base_gen_infos_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module14)
	init_entry(mercury__dead_proc_elim__initialize_class_methods_6_0);
	init_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i2);
	init_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i3);
	init_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i4);
	init_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i5);
BEGIN_CODE

/* code for predicate 'initialize_class_methods'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__initialize_class_methods_6_0);
	MR_incr_sp_push_msg(4, "dead_proc_elim:initialize_class_methods/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_3);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__dead_proc_elim__initialize_class_methods_6_0_i2,
		STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0));
Define_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_class_methods_6_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__dead_proc_elim__initialize_class_methods_6_0_i3,
		STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0));
Define_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_class_methods_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_instance_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_8);
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__dead_proc_elim__initialize_class_methods_6_0_i4,
		STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0));
Define_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_class_methods_6_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_class_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__dead_proc_elim__initialize_class_methods_6_0_i5,
		STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0));
Define_label(mercury__dead_proc_elim__initialize_class_methods_6_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__initialize_class_methods_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_11);
	r6 = MR_stackvar(1);
	r7 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl2_6_0),
		STATIC(mercury__dead_proc_elim__initialize_class_methods_6_0));
END_MODULE


BEGIN_MODULE(dead_proc_elim_module15)
	init_entry(mercury__dead_proc_elim__get_instance_pred_procs_5_0);
	init_label(mercury__dead_proc_elim__get_instance_pred_procs_5_0_i3);
BEGIN_CODE

/* code for predicate 'get_instance_pred_procs'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__get_instance_pred_procs_5_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__get_instance_pred_procs_5_0_i3);
	r1 = r2;
	r2 = r3;
	proceed();
Define_label(mercury__dead_proc_elim__get_instance_pred_procs_5_0_i3);
	r5 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 5), (Integer) 0);
	r6 = r2;
	r7 = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_32);
	tailcall(ENTRY(mercury__list__foldl2_6_0),
		STATIC(mercury__dead_proc_elim__get_instance_pred_procs_5_0));
END_MODULE


BEGIN_MODULE(dead_proc_elim_module16)
	init_entry(mercury__dead_proc_elim__get_class_pred_procs_5_0);
BEGIN_CODE

/* code for predicate 'get_class_pred_procs'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__get_class_pred_procs_5_0);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r6 = r2;
	r7 = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_class_proc_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_32);
	tailcall(ENTRY(mercury__list__foldl2_6_0),
		STATIC(mercury__dead_proc_elim__get_class_pred_procs_5_0));
END_MODULE

Declare_entry(mercury__queue__get_3_0);
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);

BEGIN_MODULE(dead_proc_elim_module17)
	init_entry(mercury__dead_proc_elim__examine_5_0);
	init_label(mercury__dead_proc_elim__examine_5_0_i1005);
	init_label(mercury__dead_proc_elim__examine_5_0_i3);
	init_label(mercury__dead_proc_elim__examine_5_0_i6);
	init_label(mercury__dead_proc_elim__examine_5_0_i5);
	init_label(mercury__dead_proc_elim__examine_5_0_i9);
	init_label(mercury__dead_proc_elim__examine_5_0_i13);
	init_label(mercury__dead_proc_elim__examine_5_0_i14);
	init_label(mercury__dead_proc_elim__examine_5_0_i15);
	init_label(mercury__dead_proc_elim__examine_5_0_i16);
	init_label(mercury__dead_proc_elim__examine_5_0_i18);
	init_label(mercury__dead_proc_elim__examine_5_0_i19);
	init_label(mercury__dead_proc_elim__examine_5_0_i20);
	init_label(mercury__dead_proc_elim__examine_5_0_i11);
	init_label(mercury__dead_proc_elim__examine_5_0_i23);
	init_label(mercury__dead_proc_elim__examine_5_0_i26);
	init_label(mercury__dead_proc_elim__examine_5_0_i28);
	init_label(mercury__dead_proc_elim__examine_5_0_i25);
	init_label(mercury__dead_proc_elim__examine_5_0_i2);
BEGIN_CODE

/* code for predicate 'examine'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_5_0);
	MR_incr_sp_push_msg(8, "dead_proc_elim:examine/5");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__examine_5_0_i1005);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__dead_proc_elim__examine_5_0_i3,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i2);
	MR_stackvar(5) = r3;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r3 = MR_stackvar(1);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dead_proc_elim__examine_5_0_i6,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i5);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i1005);
Define_label(mercury__dead_proc_elim__examine_5_0_i5);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__examine_5_0_i9,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	if ((MR_tag(MR_stackvar(4)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i11);
	r3 = MR_stackvar(4);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__examine_5_0, "origin_lost_in_value_number");
	MR_stackvar(6) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(7) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = MR_stackvar(2);
	MR_stackvar(4) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_tempr2;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dead_proc_elim__examine_5_0_i13,
		STATIC(mercury__dead_proc_elim__examine_5_0));
	}
Define_label(mercury__dead_proc_elim__examine_5_0_i13);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dead_proc_elim__examine_5_0_i14,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__dead_proc_elim__examine_5_0_i15,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i15);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__dead_proc_elim__examine_5_0_i16,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i25);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dead_proc_elim__examine_5_0_i18,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i18);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dead_proc_elim__examine_5_0_i19,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i19);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__dead_proc_elim__examine_5_0_i20,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i20);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__dead_proc_elim__examine_expr_6_0),
		mercury__dead_proc_elim__examine_5_0_i28,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i11);
	r2 = MR_stackvar(4);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_base_gen_infos_2_0),
		mercury__dead_proc_elim__examine_5_0_i23,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i23);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	call_localret(STATIC(mercury__dead_proc_elim__find_base_gen_info_5_0),
		mercury__dead_proc_elim__examine_5_0_i26,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i26);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i25);
	r1 = r2;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__dead_proc_elim__examine_refs_5_0),
		mercury__dead_proc_elim__examine_5_0_i28,
		STATIC(mercury__dead_proc_elim__examine_5_0));
Define_label(mercury__dead_proc_elim__examine_5_0_i28);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_5_0));
	r3 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i1005);
Define_label(mercury__dead_proc_elim__examine_5_0_i25);
	r3 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(5);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__examine_5_0_i1005);
Define_label(mercury__dead_proc_elim__examine_5_0_i2);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___prog_data__sym_name_0_0);

BEGIN_MODULE(dead_proc_elim_module18)
	init_entry(mercury__dead_proc_elim__find_base_gen_info_5_0);
	init_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1004);
	init_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i4);
	init_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
	init_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1);
BEGIN_CODE

/* code for predicate 'find_base_gen_info'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__find_base_gen_info_5_0);
	MR_incr_sp_push_msg(8, "dead_proc_elim:find_base_gen_info/5");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1004);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0_i1);
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__dead_proc_elim__find_base_gen_info_5_0_i4,
		STATIC(mercury__dead_proc_elim__find_base_gen_info_5_0));
	}
Define_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
	if ((strcmp((char *)MR_stackvar(2), (char *)MR_stackvar(6)) != 0))
		GOTO_LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
	if ((MR_stackvar(3) != MR_stackvar(7)))
		GOTO_LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
	r2 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i3);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__find_base_gen_info_5_0_i1004);
Define_label(mercury__dead_proc_elim__find_base_gen_info_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module19)
	init_entry(mercury__dead_proc_elim__examine_refs_5_0);
	init_label(mercury__dead_proc_elim__examine_refs_5_0_i1001);
	init_label(mercury__dead_proc_elim__examine_refs_5_0_i4);
	init_label(mercury__dead_proc_elim__examine_refs_5_0_i5);
	init_label(mercury__dead_proc_elim__examine_refs_5_0_i3);
BEGIN_CODE

/* code for predicate 'examine_refs'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_refs_5_0);
	MR_incr_sp_push_msg(4, "dead_proc_elim:examine_refs/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__examine_refs_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__examine_refs_5_0_i3);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__examine_refs_5_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__examine_refs_5_0_i4,
		STATIC(mercury__dead_proc_elim__examine_refs_5_0));
	}
Define_label(mercury__dead_proc_elim__examine_refs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_refs_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r4 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__examine_refs_5_0_i5,
		STATIC(mercury__dead_proc_elim__examine_refs_5_0));
Define_label(mercury__dead_proc_elim__examine_refs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_refs_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__dead_proc_elim__examine_refs_5_0_i1001);
Define_label(mercury__dead_proc_elim__examine_refs_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module20)
	init_entry(mercury__dead_proc_elim__examine_goals_6_0);
	init_label(mercury__dead_proc_elim__examine_goals_6_0_i1001);
	init_label(mercury__dead_proc_elim__examine_goals_6_0_i4);
	init_label(mercury__dead_proc_elim__examine_goals_6_0_i3);
BEGIN_CODE

/* code for predicate 'examine_goals'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_goals_6_0);
	MR_incr_sp_push_msg(3, "dead_proc_elim:examine_goals/6");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__examine_goals_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__examine_goals_6_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		mercury__dead_proc_elim__examine_goals_6_0_i4,
		STATIC(mercury__dead_proc_elim__examine_goals_6_0));
Define_label(mercury__dead_proc_elim__examine_goals_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_goals_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__dead_proc_elim__examine_goals_6_0_i1001);
Define_label(mercury__dead_proc_elim__examine_goals_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module21)
	init_entry(mercury__dead_proc_elim__examine_cases_6_0);
	init_label(mercury__dead_proc_elim__examine_cases_6_0_i1001);
	init_label(mercury__dead_proc_elim__examine_cases_6_0_i4);
	init_label(mercury__dead_proc_elim__examine_cases_6_0_i3);
BEGIN_CODE

/* code for predicate 'examine_cases'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_cases_6_0);
	MR_incr_sp_push_msg(3, "dead_proc_elim:examine_cases/6");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__examine_cases_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__examine_cases_6_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		mercury__dead_proc_elim__examine_cases_6_0_i4,
		STATIC(mercury__dead_proc_elim__examine_cases_6_0));
Define_label(mercury__dead_proc_elim__examine_cases_6_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_cases_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__dead_proc_elim__examine_cases_6_0_i1001);
Define_label(mercury__dead_proc_elim__examine_cases_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module22)
	init_entry(mercury__dead_proc_elim__examine_goal_6_0);
BEGIN_CODE

/* code for predicate 'examine_goal'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_goal_6_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__dead_proc_elim__examine_expr_6_0),
		STATIC(mercury__dead_proc_elim__examine_goal_6_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(dead_proc_elim_module23)
	init_entry(mercury__dead_proc_elim__examine_expr_6_0);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i1011);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i6);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i7);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i9);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i11);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i8);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i15);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i18);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i14);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i24);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i25);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i27);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i34);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i35);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i30);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i36);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i1013);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i28);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i41);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i43);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i45);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i46);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i47);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i49);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i50);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i52);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i54);
	init_label(mercury__dead_proc_elim__examine_expr_6_0_i55);
BEGIN_CODE

/* code for predicate 'examine_expr'/6 in mode 0 */
Define_static(mercury__dead_proc_elim__examine_expr_6_0);
	MR_incr_sp_push_msg(6, "dead_proc_elim:examine_expr/6");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i1011) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i6) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i1013) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i24));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i1011);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_goals_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i6);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__examine_expr_6_0, "origin_lost_in_value_number");
	MR_stackvar(3) = MR_tempr2;
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(5) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr2;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__examine_expr_6_0_i7,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
	}
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i7);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r3 = MR_stackvar(1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury__dead_proc_elim__examine_expr_6_0_i9,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i8);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__dead_proc_elim__examine_expr_6_0_i11,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i8);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i8);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__dead_proc_elim__examine_expr_6_0_i15,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i15);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i14);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i18);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i18);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__dead_proc_elim__examine_expr_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) + (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i14);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r5 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_33);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i24);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i25) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i27) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i52) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i41) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i43) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i45) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i49) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i52) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i54));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i25);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_cases_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i27);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i28);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i28);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i28) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i34) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i34) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i35) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i28) AND
		LABEL(mercury__dead_proc_elim__examine_expr_6_0_i28));
	}
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i34);
	r1 = r2;
	r2 = r3;
	MR_stackvar(2) = r4;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__examine_expr_6_0, "dead_proc_elim:entity/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	GOTO_LABEL(mercury__dead_proc_elim__examine_expr_6_0_i30);
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i35);
	r1 = r2;
	r2 = r3;
	MR_stackvar(2) = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__dead_proc_elim__examine_expr_6_0, "dead_proc_elim:entity/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_field(MR_mktag(1), r3, (Integer) 2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i30);
	MR_stackvar(1) = r3;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__examine_expr_6_0_i36,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i36);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i1013);
	r1 = r3;
	r2 = r4;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i28);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i41);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i43);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i45);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		mercury__dead_proc_elim__examine_expr_6_0_i46,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i46);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		mercury__dead_proc_elim__examine_expr_6_0_i47,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i47);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r4 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_goal_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i49);
	MR_stackvar(2) = r4;
	r2 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__examine_expr_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__examine_expr_6_0_i50,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i50);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	r3 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i52);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__dead_proc_elim__examine_goals_6_0),
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i54);
	r1 = (Word) MR_string_const("detect_cse_in_goal_2: unexpected bi_implication", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dead_proc_elim__examine_expr_6_0_i55,
		STATIC(mercury__dead_proc_elim__examine_expr_6_0));
Define_label(mercury__dead_proc_elim__examine_expr_6_0_i55);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__examine_expr_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_import_status_2_0);
Declare_entry(mercury__hlds_pred__in_in_unification_proc_id_1_0);
Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_pred__pred_info_set_import_status_3_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__passes_aux__write_pred_progress_message_5_0);

BEGIN_MODULE(dead_proc_elim_module24)
	init_entry(mercury__dead_proc_elim__eliminate_pred_5_0);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i2);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i3);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i10);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i11);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i12);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i6);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i13);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i14);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i15);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i16);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i17);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i5);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i20);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i21);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i22);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i23);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i24);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i25);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i26);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i29);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i1015);
	init_label(mercury__dead_proc_elim__eliminate_pred_5_0_i18);
BEGIN_CODE

/* code for predicate 'eliminate_pred'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__eliminate_pred_5_0);
	MR_incr_sp_push_msg(11, "dead_proc_elim:eliminate_pred/5");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = r3;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i2,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i3,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i12) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i10) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i5) AND
		LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i12));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i10);
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i11,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__dead_proc_elim__eliminate_pred_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(4) = r2;
	GOTO_LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i6);
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i12);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(8);
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i6);
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i13,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i13);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i14,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34);
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 6, mercury__dead_proc_elim__eliminate_pred_5_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_37);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__dead_proc_elim__eliminate_proc_8_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r4, (Integer) 5) = MR_stackvar(2);
	r6 = r5;
	r5 = MR_stackvar(10);
	r7 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl2_6_4),
		mercury__dead_proc_elim__eliminate_pred_5_0_i15,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i15);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i16,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i17,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i17);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__dead_proc_elim__eliminate_pred_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i5);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i18);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i20,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i20);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i21,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i21);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_34);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__dead_proc_elim__eliminate_pred_5_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_38);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__dead_proc_elim__IntroducedFrom__pred__eliminate_pred__571__3_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r4;
	r5 = r4;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__dead_proc_elim__eliminate_pred_5_0_i22,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i22);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i23,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i23);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_dead_proc_elim__common_33);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_import_status_3_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i24,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i24);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i25,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i25);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 18;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i26,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i26);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_pred_5_0_i1015);
	r4 = r2;
	r1 = (Word) MR_string_const("% Eliminated opt_imported predicate ", 36);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__write_pred_progress_message_5_0),
		mercury__dead_proc_elim__eliminate_pred_5_0_i29,
		STATIC(mercury__dead_proc_elim__eliminate_pred_5_0));
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i29);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_pred_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__dead_proc_elim__eliminate_pred_5_0, "dead_proc_elim:elim_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i1015);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__dead_proc_elim__eliminate_pred_5_0, "dead_proc_elim:elim_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_pred_5_0_i18);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE

Declare_entry(mercury__passes_aux__write_proc_progress_message_6_0);
Declare_entry(mercury__map__delete_3_1);

BEGIN_MODULE(dead_proc_elim_module25)
	init_entry(mercury__dead_proc_elim__eliminate_proc_8_0);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i6);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i5);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i9);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i2);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i11);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i14);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i12);
	init_label(mercury__dead_proc_elim__eliminate_proc_8_0_i16);
BEGIN_CODE

/* code for predicate 'eliminate_proc'/8 in mode 0 */
Define_static(mercury__dead_proc_elim__eliminate_proc_8_0);
	MR_incr_sp_push_msg(7, "dead_proc_elim:eliminate_proc/8");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(3) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__dead_proc_elim__eliminate_proc_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	r4 = MR_tempr1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__dead_proc_elim__eliminate_proc_8_0_i6,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
	}
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_proc_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_proc_8_0_i5);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i5);
	r3 = MR_stackvar(2);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_proc_8_0_i2);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__dead_proc_elim__eliminate_proc_8_0_i9,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_proc_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_proc_8_0_i2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i2);
	r1 = (Integer) 18;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__dead_proc_elim__eliminate_proc_8_0_i11,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_proc_8_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_proc_8_0_i12);
	r5 = r2;
	r1 = (Word) MR_string_const("% Eliminated the dead procedure ", 32);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__write_proc_progress_message_6_0),
		mercury__dead_proc_elim__eliminate_proc_8_0_i14,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_proc_8_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__dead_proc_elim__eliminate_proc_8_0_i16,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i12);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__dead_proc_elim__eliminate_proc_8_0_i16,
		STATIC(mercury__dead_proc_elim__eliminate_proc_8_0));
Define_label(mercury__dead_proc_elim__eliminate_proc_8_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_proc_8_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(dead_proc_elim_module26)
	init_entry(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i4);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i6);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i5);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i8);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i9);
	init_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i3);
BEGIN_CODE

/* code for predicate 'eliminate_base_gen_infos'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i3);
	MR_incr_sp_push_msg(11, "dead_proc_elim:eliminate_base_gen_infos/3");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0,
		LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i4),
		STATIC(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 3, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr2 = MR_stackvar(2);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_tempr4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(5) = MR_tempr3;
	MR_stackvar(6) = MR_tempr4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr3;
	MR_field(MR_mktag(1), r4, (Integer) 2) = MR_tempr4;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i6,
		STATIC(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
	}
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i5);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i8,
		STATIC(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0));
	if (((Integer) MR_stackvar(8) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i9);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "hlds_module:base_gen_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) r2 + (Integer) MR_const_field(MR_mktag(1), MR_stackvar(8), (Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i9);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "hlds_module:base_gen_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__dead_proc_elim__eliminate_base_gen_infos_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__dead_proc_elim__eliminate_base_gen_infos_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module27)
	init_entry(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0);
	init_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i4);
	init_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i5);
	init_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i3);
BEGIN_CODE

/* code for predicate 'dead_pred_elim_add_entity'/5 in mode 0 */
Define_static(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i3);
	MR_incr_sp_push_msg(3, "dead_proc_elim:dead_pred_elim_add_entity/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i4,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i5,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dead_proc_elim__dead_pred_elim_add_entity_5_0_i3);
	r1 = r2;
	r2 = r3;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__code_util__compiler_generated_1_0);
Declare_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
Declare_entry(mercury____Unify___hlds_pred__import_status_0_0);
Declare_entry(mercury__string__remove_suffix_3_0);
Declare_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);

BEGIN_MODULE(dead_proc_elim_module28)
	init_entry(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i2);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i4);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i5);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i6);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i10);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i8);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i13);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i14);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i12);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i17);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i18);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i16);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i24);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i27);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i28);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i20);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i31);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i30);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i34);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i35);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i36);
	init_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i3);
BEGIN_CODE

/* code for predicate 'dead_pred_elim_initialize'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0);
	MR_incr_sp_push_msg(12, "dead_proc_elim:dead_pred_elim_initialize/3");
	MR_stackvar(12) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	r1 = r3;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i2,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i2);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i4,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i4);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i5,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i6,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__code_util__compiler_generated_1_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i10,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i10);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i8);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i8);
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i13,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i13);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i14,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i12);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i12);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i17,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i17);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i18,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i18);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i16);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i16);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i24,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i24);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (r1)
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i20);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_import_status_2_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i27,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i27);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___hlds_pred__import_status_0_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i28,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i28);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (r1)
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i20);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i20);
	r1 = MR_stackvar(10);
	r2 = (Word) MR_string_const("_init_any", 9);
	call_localret(ENTRY(mercury__string__remove_suffix_3_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i31,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i31);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i30);
	if (((Integer) MR_stackvar(11) != (Integer) 1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i30);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i30);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_goal_type_2_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i34,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i34);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	if (((Integer) 2 != (Integer) r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i3);
	r2 = MR_stackvar(7);
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i7);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__dead_pred_elim_initialize_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(10);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i35,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i35);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i36,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i36);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_elim_initialize_3_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__dead_proc_elim__dead_pred_elim_initialize_3_0_i3);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
Declare_entry(mercury__hlds_pred__clauses_info_clauses_2_0);

BEGIN_MODULE(dead_proc_elim_module29)
	init_entry(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i1002);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i3);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i6);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i5);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i8);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i9);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i10);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i11);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i12);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i14);
	init_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i2);
BEGIN_CODE

/* code for predicate 'dead_pred_elim_analyze'/2 in mode 0 */
Define_static(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0);
	MR_incr_sp_push_msg(8, "dead_proc_elim:dead_pred_elim_analyze/2");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i1002);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i3,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i2);
	MR_stackvar(7) = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = MR_stackvar(3);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i6,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_elim_analyze_2_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i1002);
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i5);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i8,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i9,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_elim_analyze_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r2 = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i10,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i10);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i11,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_clauses_2_0),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i12,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i12);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_clause_0;
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_41);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i14,
		STATIC(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0));
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i1002);
Define_label(mercury__dead_proc_elim__dead_pred_elim_analyze_2_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module30)
	init_entry(mercury__dead_proc_elim__dead_pred_elim_process_clause_3_0);
BEGIN_CODE

/* code for predicate 'dead_pred_elim_process_clause'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__dead_pred_elim_process_clause_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0),
		STATIC(mercury__dead_proc_elim__dead_pred_elim_process_clause_3_0));
END_MODULE


BEGIN_MODULE(dead_proc_elim_module31)
	init_entry(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i1000);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i4);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i6);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i9);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i10);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i12);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i14);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i16);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i18);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i20);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i22);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i23);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i25);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i26);
BEGIN_CODE

/* code for predicate 'pre_modecheck_examine_goal'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0);
	MR_incr_sp_push_msg(2, "dead_proc_elim:pre_modecheck_examine_goal/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i1000);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i4) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i6) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i22) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i9));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i4);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_42);
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_44);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i6);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 5);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r3, (Integer) 0),
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i10) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i12) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i14) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i16) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i18) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i20) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i22) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i23) AND
		LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i25));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i10);
	r4 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_47);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i12);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i14);
	r4 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_42);
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_44);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i16);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i1000);
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i18);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i1000);
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i20);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_42);
	r6 = r2;
	r5 = r3;
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_44);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	r5 = r6;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r7;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
	}
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i22);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i23);
	r4 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_42);
	r2 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_44);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__foldl_4_1),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i25);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("pre_modecheck_examine_goal: unexpected bi_implication", 53);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i26,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0_i26);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_module__predicate_table_search_sym_3_0);
Declare_entry(mercury__queue__put_list_3_0);

BEGIN_MODULE(dead_proc_elim_module32)
	init_entry(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i1001);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i20);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i4);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i8);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i7);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i10);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i11);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i14);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i16);
	init_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i12);
BEGIN_CODE

/* code for predicate 'pre_modecheck_examine_unify_rhs'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i20);
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i1001);
	r1 = r2;
	proceed();
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i20);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 7);
	tailcall(STATIC(mercury__dead_proc_elim__pre_modecheck_examine_goal_3_0),
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i1001);
	MR_incr_sp_push_msg(8, "dead_proc_elim:pre_modecheck_examine_unify_rhs/3");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(7) = r3;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i8,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i8);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i7);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i7);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i10,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i10);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i11,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_sym_3_0),
		mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i14,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i14);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i12);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = r2;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i16,
		STATIC(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i16);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0_i12);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__pre_modecheck_examine_unify_rhs_3_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module33)
	init_entry(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i3);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i2);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i5);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i6);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i9);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i11);
	init_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i7);
BEGIN_CODE

/* code for predicate 'dead_pred_info_add_pred_name'/3 in mode 0 */
Define_static(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0);
	MR_incr_sp_push_msg(8, "dead_proc_elim:dead_pred_info_add_pred_name/3");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(7) = r3;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i3,
		STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i2);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i2);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i5,
		STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i5);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i6,
		STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i6);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_sym_3_0),
		mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i9,
		STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i9);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i7);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = r2;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i11,
		STATIC(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i11);
	update_prof_current_proc(LABEL(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0_i7);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__dead_proc_elim__dead_pred_info_add_pred_name_3_0, "dead_proc_elim:dead_pred_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module34)
	init_entry(mercury____Unify___dead_proc_elim__entity_0_0);
	init_label(mercury____Unify___dead_proc_elim__entity_0_0_i5);
	init_label(mercury____Unify___dead_proc_elim__entity_0_0_i3);
	init_label(mercury____Unify___dead_proc_elim__entity_0_0_i10);
	init_label(mercury____Unify___dead_proc_elim__entity_0_0_i1009);
	init_label(mercury____Unify___dead_proc_elim__entity_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dead_proc_elim__entity_0_0);
	MR_incr_sp_push_msg(5, "dead_proc_elim:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1009);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury____Unify___dead_proc_elim__entity_0_0_i5,
		ENTRY(mercury____Unify___dead_proc_elim__entity_0_0));
Define_label(mercury____Unify___dead_proc_elim__entity_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__entity_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		ENTRY(mercury____Unify___dead_proc_elim__entity_0_0));
Define_label(mercury____Unify___dead_proc_elim__entity_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___dead_proc_elim__entity_0_0_i10,
		ENTRY(mercury____Unify___dead_proc_elim__entity_0_0));
Define_label(mercury____Unify___dead_proc_elim__entity_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__entity_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	if ((strcmp((char *)MR_stackvar(1), (char *)MR_stackvar(3)) != 0))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(4)))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___dead_proc_elim__entity_0_0_i1009);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___dead_proc_elim__entity_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module35)
	init_entry(mercury____Index___dead_proc_elim__entity_0_0);
	init_label(mercury____Index___dead_proc_elim__entity_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dead_proc_elim__entity_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___dead_proc_elim__entity_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___dead_proc_elim__entity_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Compare___hlds_pred__proc_id_0_0);
Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(dead_proc_elim_module36)
	init_entry(mercury____Compare___dead_proc_elim__entity_0_0);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i3);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i2);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i5);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i4);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i6);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i7);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i14);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i11);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i21);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i25);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i1017);
	init_label(mercury____Compare___dead_proc_elim__entity_0_0_i34);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dead_proc_elim__entity_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i2);
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i4);
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i1017);
	MR_incr_sp_push_msg(5, "dead_proc_elim:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
		mercury____Compare___dead_proc_elim__entity_0_0_i14,
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__entity_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i34);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__proc_id_0_0),
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i1017);
	MR_incr_sp_push_msg(5, "dead_proc_elim:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___dead_proc_elim__entity_0_0_i21,
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__entity_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i34);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___dead_proc_elim__entity_0_0_i25,
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i25);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__entity_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__entity_0_0_i34);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i1017);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___dead_proc_elim__entity_0_0));
Define_label(mercury____Compare___dead_proc_elim__entity_0_0_i34);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(dead_proc_elim_module37)
	init_entry(mercury____Unify___dead_proc_elim__needed_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___dead_proc_elim__needed_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___dead_proc_elim__needed_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(dead_proc_elim_module38)
	init_entry(mercury____Index___dead_proc_elim__needed_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___dead_proc_elim__needed_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___dead_proc_elim__needed_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(dead_proc_elim_module39)
	init_entry(mercury____Compare___dead_proc_elim__needed_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___dead_proc_elim__needed_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___dead_proc_elim__needed_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___queue__queue_1_0);

BEGIN_MODULE(dead_proc_elim_module40)
	init_entry(mercury____Unify___dead_proc_elim__entity_queue_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dead_proc_elim__entity_queue_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Unify___queue__queue_1_0),
		STATIC(mercury____Unify___dead_proc_elim__entity_queue_0_0));
END_MODULE

Declare_entry(mercury____Index___queue__queue_1_0);

BEGIN_MODULE(dead_proc_elim_module41)
	init_entry(mercury____Index___dead_proc_elim__entity_queue_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__entity_queue_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Index___queue__queue_1_0),
		STATIC(mercury____Index___dead_proc_elim__entity_queue_0_0));
END_MODULE

Declare_entry(mercury____Compare___queue__queue_1_0);

BEGIN_MODULE(dead_proc_elim_module42)
	init_entry(mercury____Compare___dead_proc_elim__entity_queue_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dead_proc_elim__entity_queue_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Compare___queue__queue_1_0),
		STATIC(mercury____Compare___dead_proc_elim__entity_queue_0_0));
END_MODULE

Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(dead_proc_elim_module43)
	init_entry(mercury____Unify___dead_proc_elim__examined_set_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dead_proc_elim__examined_set_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		STATIC(mercury____Unify___dead_proc_elim__examined_set_0_0));
END_MODULE

Declare_entry(mercury____Index___set__set_1_0);

BEGIN_MODULE(dead_proc_elim_module44)
	init_entry(mercury____Index___dead_proc_elim__examined_set_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__examined_set_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Index___set__set_1_0),
		STATIC(mercury____Index___dead_proc_elim__examined_set_0_0));
END_MODULE

Declare_entry(mercury____Compare___set__set_1_0);

BEGIN_MODULE(dead_proc_elim_module45)
	init_entry(mercury____Compare___dead_proc_elim__examined_set_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dead_proc_elim__examined_set_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		STATIC(mercury____Compare___dead_proc_elim__examined_set_0_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_module__module_info_0_0);

BEGIN_MODULE(dead_proc_elim_module46)
	init_entry(mercury____Unify___dead_proc_elim__elim_info_0_0);
	init_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i2);
	init_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i4);
	init_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dead_proc_elim__elim_info_0_0);
	MR_incr_sp_push_msg(5, "dead_proc_elim:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___dead_proc_elim__elim_info_0_0_i2,
		STATIC(mercury____Unify___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__elim_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__elim_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___dead_proc_elim__elim_info_0_0_i4,
		STATIC(mercury____Unify___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__elim_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__elim_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__elim_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module47)
	init_entry(mercury____Index___dead_proc_elim__elim_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__elim_info_0_0);
	tailcall(STATIC(mercury____Index___dead_proc_elim__elim_info_0__ua0_2_0),
		STATIC(mercury____Index___dead_proc_elim__elim_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_module__module_info_0_0);

BEGIN_MODULE(dead_proc_elim_module48)
	init_entry(mercury____Compare___dead_proc_elim__elim_info_0_0);
	init_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i3);
	init_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i7);
	init_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dead_proc_elim__elim_info_0_0);
	MR_incr_sp_push_msg(5, "dead_proc_elim:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_dead_proc_elim__type_ctor_info_entity_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dead_proc_elim__common_1);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___dead_proc_elim__elim_info_0_0_i3,
		STATIC(mercury____Compare___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__elim_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__elim_info_0_0_i12);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___dead_proc_elim__elim_info_0_0_i7,
		STATIC(mercury____Compare___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__elim_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__elim_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___dead_proc_elim__elim_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__elim_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module49)
	init_entry(mercury____Unify___dead_proc_elim__dead_pred_info_0_0);
	init_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i2);
	init_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i4);
	init_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i6);
	init_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i8);
	init_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dead_proc_elim__dead_pred_info_0_0);
	MR_incr_sp_push_msg(9, "dead_proc_elim:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i2,
		STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___queue__queue_1_0),
		mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i4,
		STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i6,
		STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i8,
		STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		STATIC(mercury____Unify___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Unify___dead_proc_elim__dead_pred_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dead_proc_elim_module50)
	init_entry(mercury____Index___dead_proc_elim__dead_pred_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dead_proc_elim__dead_pred_info_0_0);
	tailcall(STATIC(mercury____Index___dead_proc_elim__dead_pred_info_0__ua0_2_0),
		STATIC(mercury____Index___dead_proc_elim__dead_pred_info_0_0));
END_MODULE


BEGIN_MODULE(dead_proc_elim_module51)
	init_entry(mercury____Compare___dead_proc_elim__dead_pred_info_0_0);
	init_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i3);
	init_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i7);
	init_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i11);
	init_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i15);
	init_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dead_proc_elim__dead_pred_info_0_0);
	MR_incr_sp_push_msg(9, "dead_proc_elim:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i3,
		STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___queue__queue_1_0),
		mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i7,
		STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i11,
		STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i15,
		STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		STATIC(mercury____Compare___dead_proc_elim__dead_pred_info_0_0));
Define_label(mercury____Compare___dead_proc_elim__dead_pred_info_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__dead_proc_elim_maybe_bunch_0(void)
{
	dead_proc_elim_module0();
	dead_proc_elim_module1();
	dead_proc_elim_module2();
	dead_proc_elim_module3();
	dead_proc_elim_module4();
	dead_proc_elim_module5();
	dead_proc_elim_module6();
	dead_proc_elim_module7();
	dead_proc_elim_module8();
	dead_proc_elim_module9();
	dead_proc_elim_module10();
	dead_proc_elim_module11();
	dead_proc_elim_module12();
	dead_proc_elim_module13();
	dead_proc_elim_module14();
	dead_proc_elim_module15();
	dead_proc_elim_module16();
	dead_proc_elim_module17();
	dead_proc_elim_module18();
	dead_proc_elim_module19();
	dead_proc_elim_module20();
	dead_proc_elim_module21();
	dead_proc_elim_module22();
	dead_proc_elim_module23();
	dead_proc_elim_module24();
	dead_proc_elim_module25();
	dead_proc_elim_module26();
	dead_proc_elim_module27();
	dead_proc_elim_module28();
	dead_proc_elim_module29();
	dead_proc_elim_module30();
	dead_proc_elim_module31();
	dead_proc_elim_module32();
	dead_proc_elim_module33();
	dead_proc_elim_module34();
	dead_proc_elim_module35();
	dead_proc_elim_module36();
	dead_proc_elim_module37();
	dead_proc_elim_module38();
	dead_proc_elim_module39();
}

static void mercury__dead_proc_elim_maybe_bunch_1(void)
{
	dead_proc_elim_module40();
	dead_proc_elim_module41();
	dead_proc_elim_module42();
	dead_proc_elim_module43();
	dead_proc_elim_module44();
	dead_proc_elim_module45();
	dead_proc_elim_module46();
	dead_proc_elim_module47();
	dead_proc_elim_module48();
	dead_proc_elim_module49();
	dead_proc_elim_module50();
	dead_proc_elim_module51();
}

#endif

void mercury__dead_proc_elim__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__dead_proc_elim__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__dead_proc_elim_maybe_bunch_0();
		mercury__dead_proc_elim_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_dead_pred_info_0,
			dead_proc_elim__dead_pred_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_elim_info_0,
			dead_proc_elim__elim_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_entity_0,
			dead_proc_elim__entity_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_entity_queue_0,
			dead_proc_elim__entity_queue_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_examined_set_0,
			dead_proc_elim__examined_set_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dead_proc_elim__type_ctor_info_needed_map_0,
			dead_proc_elim__needed_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
