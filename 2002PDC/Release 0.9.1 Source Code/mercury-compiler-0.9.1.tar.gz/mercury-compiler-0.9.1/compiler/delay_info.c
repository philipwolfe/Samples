/*
** Automatically generated from `delay_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__delay_info__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___delay_info__delay_info_0__ua0_2_0);
Declare_static(mercury__delay_info__check_invariant__ua0_1_0);
Define_extern_entry(mercury__delay_info__check_invariant_1_0);
Define_extern_entry(mercury__delay_info__init_1_0);
Declare_label(mercury__delay_info__init_1_0_i2);
Declare_label(mercury__delay_info__init_1_0_i3);
Declare_label(mercury__delay_info__init_1_0_i4);
Declare_label(mercury__delay_info__init_1_0_i5);
Define_extern_entry(mercury__delay_info__enter_conj_2_0);
Declare_label(mercury__delay_info__enter_conj_2_0_i2);
Declare_label(mercury__delay_info__enter_conj_2_0_i3);
Declare_label(mercury__delay_info__enter_conj_2_0_i4);
Define_extern_entry(mercury__delay_info__leave_conj_3_0);
Declare_label(mercury__delay_info__leave_conj_3_0_i2);
Declare_label(mercury__delay_info__leave_conj_3_0_i3);
Declare_label(mercury__delay_info__leave_conj_3_0_i4);
Declare_label(mercury__delay_info__leave_conj_3_0_i5);
Declare_label(mercury__delay_info__leave_conj_3_0_i6);
Define_extern_entry(mercury__delay_info__delay_goal_4_0);
Declare_label(mercury__delay_info__delay_goal_4_0_i2);
Declare_label(mercury__delay_info__delay_goal_4_0_i3);
Declare_label(mercury__delay_info__delay_goal_4_0_i4);
Declare_label(mercury__delay_info__delay_goal_4_0_i5);
Declare_label(mercury__delay_info__delay_goal_4_0_i6);
Declare_label(mercury__delay_info__delay_goal_4_0_i7);
Declare_label(mercury__delay_info__delay_goal_4_0_i8);
Define_extern_entry(mercury__delay_info__bind_var_list_3_0);
Declare_label(mercury__delay_info__bind_var_list_3_0_i1001);
Declare_label(mercury__delay_info__bind_var_list_3_0_i4);
Declare_label(mercury__delay_info__bind_var_list_3_0_i3);
Define_extern_entry(mercury__delay_info__bind_var_3_0);
Declare_label(mercury__delay_info__bind_var_3_0_i3);
Declare_label(mercury__delay_info__bind_var_3_0_i5);
Declare_label(mercury__delay_info__bind_var_3_0_i6);
Declare_label(mercury__delay_info__bind_var_3_0_i2);
Define_extern_entry(mercury__delay_info__bind_all_vars_2_0);
Declare_label(mercury__delay_info__bind_all_vars_2_0_i2);
Define_extern_entry(mercury__delay_info__wakeup_goals_3_0);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i3);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i6);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i7);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i8);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i9);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i10);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i11);
Declare_label(mercury__delay_info__wakeup_goals_3_0_i2);
Declare_static(mercury__delay_info__remove_delayed_goals_5_0);
Declare_label(mercury__delay_info__remove_delayed_goals_5_0_i1001);
Declare_label(mercury__delay_info__remove_delayed_goals_5_0_i4);
Declare_label(mercury__delay_info__remove_delayed_goals_5_0_i5);
Declare_label(mercury__delay_info__remove_delayed_goals_5_0_i6);
Declare_label(mercury__delay_info__remove_delayed_goals_5_0_i3);
Declare_static(mercury__delay_info__add_waiting_vars_5_0);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i1002);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i5);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i4);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i7);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i8);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i9);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i10);
Declare_label(mercury__delay_info__add_waiting_vars_5_0_i3);
Declare_static(mercury__delay_info__add_pending_goals_6_0);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i1002);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i4);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i5);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i7);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i9);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i6);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i11);
Declare_label(mercury__delay_info__add_pending_goals_6_0_i3);
Declare_static(mercury__delay_info__delete_waiting_vars_4_0);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i1002);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i4);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i5);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i7);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i6);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i10);
Declare_label(mercury__delay_info__delete_waiting_vars_4_0_i3);
Define_extern_entry(mercury____Unify___delay_info__delay_info_0_0);
Declare_label(mercury____Unify___delay_info__delay_info_0_0_i2);
Declare_label(mercury____Unify___delay_info__delay_info_0_0_i4);
Declare_label(mercury____Unify___delay_info__delay_info_0_0_i6);
Declare_label(mercury____Unify___delay_info__delay_info_0_0_i1005);
Declare_label(mercury____Unify___delay_info__delay_info_0_0_i1);
Define_extern_entry(mercury____Index___delay_info__delay_info_0_0);
Define_extern_entry(mercury____Compare___delay_info__delay_info_0_0);
Declare_label(mercury____Compare___delay_info__delay_info_0_0_i3);
Declare_label(mercury____Compare___delay_info__delay_info_0_0_i7);
Declare_label(mercury____Compare___delay_info__delay_info_0_0_i11);
Declare_label(mercury____Compare___delay_info__delay_info_0_0_i15);
Declare_label(mercury____Compare___delay_info__delay_info_0_0_i22);
Declare_static(mercury____Unify___delay_info__waiting_goals_table_0_0);
Declare_static(mercury____Index___delay_info__waiting_goals_table_0_0);
Declare_static(mercury____Compare___delay_info__waiting_goals_table_0_0);
Declare_static(mercury____Unify___delay_info__waiting_goals_0_0);
Declare_static(mercury____Index___delay_info__waiting_goals_0_0);
Declare_static(mercury____Compare___delay_info__waiting_goals_0_0);
Declare_static(mercury____Unify___delay_info__pending_goals_table_0_0);
Declare_static(mercury____Index___delay_info__pending_goals_table_0_0);
Declare_static(mercury____Compare___delay_info__pending_goals_table_0_0);
Declare_static(mercury____Unify___delay_info__goal_num_0_0);
Declare_static(mercury____Index___delay_info__goal_num_0_0);
Declare_static(mercury____Compare___delay_info__goal_num_0_0);
Declare_static(mercury____Unify___delay_info__depth_num_0_0);
Declare_label(mercury____Unify___delay_info__depth_num_0_0_i1);
Declare_static(mercury____Index___delay_info__depth_num_0_0);
Declare_static(mercury____Compare___delay_info__depth_num_0_0);
Declare_static(mercury____Unify___delay_info__seq_num_0_0);
Declare_label(mercury____Unify___delay_info__seq_num_0_0_i1);
Declare_static(mercury____Index___delay_info__seq_num_0_0);
Declare_static(mercury____Compare___delay_info__seq_num_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_delay_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_depth_num_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_goal_num_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_pending_goals_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_seq_num_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_waiting_goals_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_waiting_goals_table_0;

static const struct mercury_data_delay_info__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_info__common_0;

static const struct mercury_data_delay_info__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_delay_info__common_1;

static const struct mercury_data_delay_info__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_info__common_2;

static const struct mercury_data_delay_info__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_delay_info__common_3;

static const struct mercury_data_delay_info__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_info__common_4;

static const struct mercury_data_delay_info__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_delay_info__common_5;

static const struct mercury_data_delay_info__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_info__common_6;

static const struct mercury_data_delay_info__common_7_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__common_7;

static const struct mercury_data_delay_info__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__common_8;

static const struct mercury_data_delay_info__common_9_struct {
	Word * f1;
}  mercury_data_delay_info__common_9;

static const struct mercury_data_delay_info__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__common_10;

static const struct mercury_data_delay_info__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_info__common_11;

static const struct mercury_data_delay_info__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__common_12;

static const struct mercury_data_delay_info__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__common_13;

static const struct mercury_data_delay_info__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_delay_info__common_14;

static const struct mercury_data_delay_info__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_delay_info__common_15;

static const struct mercury_data_delay_info__common_16_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_delay_info__common_16;

static const struct mercury_data_delay_info__type_ctor_functors_waiting_goals_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_waiting_goals_table_0;

static const struct mercury_data_delay_info__type_ctor_layout_waiting_goals_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_waiting_goals_table_0;

static const struct mercury_data_delay_info__type_ctor_functors_waiting_goals_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_waiting_goals_0;

static const struct mercury_data_delay_info__type_ctor_layout_waiting_goals_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_waiting_goals_0;

static const struct mercury_data_delay_info__type_ctor_functors_seq_num_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_seq_num_0;

static const struct mercury_data_delay_info__type_ctor_layout_seq_num_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_seq_num_0;

static const struct mercury_data_delay_info__type_ctor_functors_pending_goals_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_pending_goals_table_0;

static const struct mercury_data_delay_info__type_ctor_layout_pending_goals_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_pending_goals_table_0;

static const struct mercury_data_delay_info__type_ctor_functors_goal_num_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_goal_num_0;

static const struct mercury_data_delay_info__type_ctor_layout_goal_num_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_goal_num_0;

static const struct mercury_data_delay_info__type_ctor_functors_depth_num_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_delay_info__type_ctor_functors_depth_num_0;

static const struct mercury_data_delay_info__type_ctor_layout_depth_num_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_depth_num_0;

static const struct mercury_data_delay_info__type_ctor_functors_delay_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_delay_info__type_ctor_functors_delay_info_0;

static const struct mercury_data_delay_info__type_ctor_layout_delay_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_delay_info__type_ctor_layout_delay_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_delay_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___delay_info__delay_info_0_0),
	ENTRY(mercury____Index___delay_info__delay_info_0_0),
	ENTRY(mercury____Compare___delay_info__delay_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_delay_info__type_ctor_functors_delay_info_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_delay_info_0,
	MR_string_const("delay_info", 10),
	MR_string_const("delay_info", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_depth_num_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__depth_num_0_0),
	STATIC(mercury____Index___delay_info__depth_num_0_0),
	STATIC(mercury____Compare___delay_info__depth_num_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_depth_num_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_depth_num_0,
	MR_string_const("delay_info", 10),
	MR_string_const("depth_num", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_goal_num_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__goal_num_0_0),
	STATIC(mercury____Index___delay_info__goal_num_0_0),
	STATIC(mercury____Compare___delay_info__goal_num_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_goal_num_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_goal_num_0,
	MR_string_const("delay_info", 10),
	MR_string_const("goal_num", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_pending_goals_table_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__pending_goals_table_0_0),
	STATIC(mercury____Index___delay_info__pending_goals_table_0_0),
	STATIC(mercury____Compare___delay_info__pending_goals_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_pending_goals_table_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_pending_goals_table_0,
	MR_string_const("delay_info", 10),
	MR_string_const("pending_goals_table", 19),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_seq_num_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__seq_num_0_0),
	STATIC(mercury____Index___delay_info__seq_num_0_0),
	STATIC(mercury____Compare___delay_info__seq_num_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_seq_num_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_seq_num_0,
	MR_string_const("delay_info", 10),
	MR_string_const("seq_num", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_waiting_goals_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__waiting_goals_0_0),
	STATIC(mercury____Index___delay_info__waiting_goals_0_0),
	STATIC(mercury____Compare___delay_info__waiting_goals_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_waiting_goals_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_waiting_goals_0,
	MR_string_const("delay_info", 10),
	MR_string_const("waiting_goals", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_delay_info__type_ctor_info_waiting_goals_table_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___delay_info__waiting_goals_table_0_0),
	STATIC(mercury____Index___delay_info__waiting_goals_table_0_0),
	STATIC(mercury____Compare___delay_info__waiting_goals_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_delay_info__type_ctor_functors_waiting_goals_table_0,
	(Word *) &mercury_data_delay_info__type_ctor_layout_waiting_goals_table_0,
	MR_string_const("delay_info", 10),
	MR_string_const("waiting_goals_table", 19),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
static const struct mercury_data_delay_info__common_0_struct mercury_data_delay_info__common_0 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_delay_info__common_1_struct mercury_data_delay_info__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_delay_info__common_2_struct mercury_data_delay_info__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_delay_info__common_3_struct mercury_data_delay_info__common_3 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1)
};

static const struct mercury_data_delay_info__common_4_struct mercury_data_delay_info__common_4 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3)
};

static const struct mercury_data_delay_info__common_5_struct mercury_data_delay_info__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_delay_info__common_6_struct mercury_data_delay_info__common_6 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4)
};

static const struct mercury_data_delay_info__common_7_struct mercury_data_delay_info__common_7 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_6)
};

static const struct mercury_data_delay_info__common_8_struct mercury_data_delay_info__common_8 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4)
};

static const struct mercury_data_delay_info__common_9_struct mercury_data_delay_info__common_9 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_delay_info__common_10_struct mercury_data_delay_info__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_9)
};

static const struct mercury_data_delay_info__common_11_struct mercury_data_delay_info__common_11 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5)
};

static const struct mercury_data_delay_info__common_12_struct mercury_data_delay_info__common_12 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_11)
};

static const struct mercury_data_delay_info__common_13_struct mercury_data_delay_info__common_13 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_stack__type_ctor_info_stack_1;
static const struct mercury_data_delay_info__common_14_struct mercury_data_delay_info__common_14 = {
	(Word *) &mercury_data_stack__type_ctor_info_stack_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0)
};

static const struct mercury_data_delay_info__common_15_struct mercury_data_delay_info__common_15 = {
	(Word *) &mercury_data_stack__type_ctor_info_stack_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_delay_info__common_16_struct mercury_data_delay_info__common_16 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_15),
	MR_string_const("delay_info", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_delay_info__type_ctor_functors_waiting_goals_table_0_struct mercury_data_delay_info__type_ctor_functors_waiting_goals_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_6)
};

static const struct mercury_data_delay_info__type_ctor_layout_waiting_goals_table_0_struct mercury_data_delay_info__type_ctor_layout_waiting_goals_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_7)
};

static const struct mercury_data_delay_info__type_ctor_functors_waiting_goals_0_struct mercury_data_delay_info__type_ctor_functors_waiting_goals_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4)
};

static const struct mercury_data_delay_info__type_ctor_layout_waiting_goals_0_struct mercury_data_delay_info__type_ctor_layout_waiting_goals_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_8)
};

static const struct mercury_data_delay_info__type_ctor_functors_seq_num_0_struct mercury_data_delay_info__type_ctor_functors_seq_num_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_9)
};

static const struct mercury_data_delay_info__type_ctor_layout_seq_num_0_struct mercury_data_delay_info__type_ctor_layout_seq_num_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10)
};

static const struct mercury_data_delay_info__type_ctor_functors_pending_goals_table_0_struct mercury_data_delay_info__type_ctor_functors_pending_goals_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_11)
};

static const struct mercury_data_delay_info__type_ctor_layout_pending_goals_table_0_struct mercury_data_delay_info__type_ctor_layout_pending_goals_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_12)
};

static const struct mercury_data_delay_info__type_ctor_functors_goal_num_0_struct mercury_data_delay_info__type_ctor_functors_goal_num_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2)
};

static const struct mercury_data_delay_info__type_ctor_layout_goal_num_0_struct mercury_data_delay_info__type_ctor_layout_goal_num_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_13)
};

static const struct mercury_data_delay_info__type_ctor_functors_depth_num_0_struct mercury_data_delay_info__type_ctor_functors_depth_num_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_9)
};

static const struct mercury_data_delay_info__type_ctor_layout_depth_num_0_struct mercury_data_delay_info__type_ctor_layout_depth_num_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_info__common_10)
};

static const struct mercury_data_delay_info__type_ctor_functors_delay_info_0_struct mercury_data_delay_info__type_ctor_functors_delay_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_16)
};

static const struct mercury_data_delay_info__type_ctor_layout_delay_info_0_struct mercury_data_delay_info__type_ctor_layout_delay_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_delay_info__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(delay_info_module0)
	init_entry(mercury____Index___delay_info__delay_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___delay_info__delay_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___delay_info__delay_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module1)
	init_entry(mercury__delay_info__check_invariant__ua0_1_0);
BEGIN_CODE

/* code for predicate 'check_invariant__ua0'/1 in mode 0 */
Define_static(mercury__delay_info__check_invariant__ua0_1_0);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module2)
	init_entry(mercury__delay_info__check_invariant_1_0);
BEGIN_CODE

/* code for predicate 'check_invariant'/1 in mode 0 */
Define_entry(mercury__delay_info__check_invariant_1_0);
	tailcall(STATIC(mercury__delay_info__check_invariant__ua0_1_0),
		ENTRY(mercury__delay_info__check_invariant_1_0));
END_MODULE

Declare_entry(mercury__stack__init_1_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(delay_info_module3)
	init_entry(mercury__delay_info__init_1_0);
	init_label(mercury__delay_info__init_1_0_i2);
	init_label(mercury__delay_info__init_1_0_i3);
	init_label(mercury__delay_info__init_1_0_i4);
	init_label(mercury__delay_info__init_1_0_i5);
BEGIN_CODE

/* code for predicate 'init'/1 in mode 0 */
Define_entry(mercury__delay_info__init_1_0);
	MR_incr_sp_push_msg(4, "delay_info:init/1");
	MR_stackvar(4) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	call_localret(ENTRY(mercury__stack__init_1_0),
		mercury__delay_info__init_1_0_i2,
		ENTRY(mercury__delay_info__init_1_0));
Define_label(mercury__delay_info__init_1_0_i2);
	update_prof_current_proc(LABEL(mercury__delay_info__init_1_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__delay_info__init_1_0_i3,
		ENTRY(mercury__delay_info__init_1_0));
Define_label(mercury__delay_info__init_1_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__init_1_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__delay_info__init_1_0_i4,
		ENTRY(mercury__delay_info__init_1_0));
Define_label(mercury__delay_info__init_1_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__init_1_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__stack__init_1_0),
		mercury__delay_info__init_1_0_i5,
		ENTRY(mercury__delay_info__init_1_0));
Define_label(mercury__delay_info__init_1_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__init_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__delay_info__init_1_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__stack__push_3_0);

BEGIN_MODULE(delay_info_module4)
	init_entry(mercury__delay_info__enter_conj_2_0);
	init_label(mercury__delay_info__enter_conj_2_0_i2);
	init_label(mercury__delay_info__enter_conj_2_0_i3);
	init_label(mercury__delay_info__enter_conj_2_0_i4);
BEGIN_CODE

/* code for predicate 'enter_conj'/2 in mode 0 */
Define_entry(mercury__delay_info__enter_conj_2_0);
	MR_incr_sp_push_msg(6, "delay_info:enter_conj/2");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__delay_info__enter_conj_2_0_i2,
		ENTRY(mercury__delay_info__enter_conj_2_0));
Define_label(mercury__delay_info__enter_conj_2_0_i2);
	update_prof_current_proc(LABEL(mercury__delay_info__enter_conj_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__delay_info__enter_conj_2_0_i3,
		ENTRY(mercury__delay_info__enter_conj_2_0));
Define_label(mercury__delay_info__enter_conj_2_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__enter_conj_2_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__delay_info__enter_conj_2_0_i4,
		ENTRY(mercury__delay_info__enter_conj_2_0));
Define_label(mercury__delay_info__enter_conj_2_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__enter_conj_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__delay_info__enter_conj_2_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = ((Integer) MR_stackvar(1) + (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__stack__pop_det_3_0);
Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__map__values_2_0);

BEGIN_MODULE(delay_info_module5)
	init_entry(mercury__delay_info__leave_conj_3_0);
	init_label(mercury__delay_info__leave_conj_3_0_i2);
	init_label(mercury__delay_info__leave_conj_3_0_i3);
	init_label(mercury__delay_info__leave_conj_3_0_i4);
	init_label(mercury__delay_info__leave_conj_3_0_i5);
	init_label(mercury__delay_info__leave_conj_3_0_i6);
BEGIN_CODE

/* code for predicate 'leave_conj'/3 in mode 0 */
Define_entry(mercury__delay_info__leave_conj_3_0);
	MR_incr_sp_push_msg(7, "delay_info:leave_conj/3");
	MR_stackvar(7) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__delay_info__leave_conj_3_0_i2,
		ENTRY(mercury__delay_info__leave_conj_3_0));
Define_label(mercury__delay_info__leave_conj_3_0_i2);
	update_prof_current_proc(LABEL(mercury__delay_info__leave_conj_3_0));
	r3 = r1;
	MR_stackvar(5) = r1;
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__delay_info__leave_conj_3_0_i3,
		ENTRY(mercury__delay_info__leave_conj_3_0));
Define_label(mercury__delay_info__leave_conj_3_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__leave_conj_3_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__delay_info__remove_delayed_goals_5_0),
		mercury__delay_info__leave_conj_3_0_i4,
		ENTRY(mercury__delay_info__leave_conj_3_0));
Define_label(mercury__delay_info__leave_conj_3_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__leave_conj_3_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__delay_info__leave_conj_3_0_i5,
		ENTRY(mercury__delay_info__leave_conj_3_0));
Define_label(mercury__delay_info__leave_conj_3_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__leave_conj_3_0));
	MR_stackvar(4) = ((Integer) MR_stackvar(1) + (Integer) -1);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__delay_info__leave_conj_3_0_i6,
		ENTRY(mercury__delay_info__leave_conj_3_0));
Define_label(mercury__delay_info__leave_conj_3_0_i6);
	update_prof_current_proc(LABEL(mercury__delay_info__leave_conj_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__delay_info__leave_conj_3_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__map__set_4_1);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(delay_info_module6)
	init_entry(mercury__delay_info__delay_goal_4_0);
	init_label(mercury__delay_info__delay_goal_4_0_i2);
	init_label(mercury__delay_info__delay_goal_4_0_i3);
	init_label(mercury__delay_info__delay_goal_4_0_i4);
	init_label(mercury__delay_info__delay_goal_4_0_i5);
	init_label(mercury__delay_info__delay_goal_4_0_i6);
	init_label(mercury__delay_info__delay_goal_4_0_i7);
	init_label(mercury__delay_info__delay_goal_4_0_i8);
BEGIN_CODE

/* code for predicate 'delay_goal'/4 in mode 0 */
Define_entry(mercury__delay_info__delay_goal_4_0);
	MR_incr_sp_push_msg(9, "delay_info:delay_goal/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__delay_info__delay_goal_4_0_i2,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = ((Integer) MR_stackvar(8) + (Integer) 1);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__delay_info__delay_goal_4_0_i3,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__delay_info__delay_goal_4_0_i4,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__delay_info__delay_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(1);
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	r4 = MR_stackvar(8);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__delay_goal_4_0_i5,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__delay_info__delay_goal_4_0_i6,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__delay_info__delay_goal_4_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__delay_info__delay_goal_4_0_i7,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	r2 = MR_stackvar(2);
	r3 = r1;
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__delay_info__add_waiting_vars_5_0),
		mercury__delay_info__delay_goal_4_0_i8,
		ENTRY(mercury__delay_info__delay_goal_4_0));
Define_label(mercury__delay_info__delay_goal_4_0_i8);
	update_prof_current_proc(LABEL(mercury__delay_info__delay_goal_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__delay_info__delay_goal_4_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module7)
	init_entry(mercury__delay_info__bind_var_list_3_0);
	init_label(mercury__delay_info__bind_var_list_3_0_i1001);
	init_label(mercury__delay_info__bind_var_list_3_0_i4);
	init_label(mercury__delay_info__bind_var_list_3_0_i3);
BEGIN_CODE

/* code for predicate 'bind_var_list'/3 in mode 0 */
Define_entry(mercury__delay_info__bind_var_list_3_0);
	MR_incr_sp_push_msg(2, "delay_info:bind_var_list/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__delay_info__bind_var_list_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__bind_var_list_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__delay_info__bind_var_3_0),
		mercury__delay_info__bind_var_list_3_0_i4,
		ENTRY(mercury__delay_info__bind_var_list_3_0));
Define_label(mercury__delay_info__bind_var_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__bind_var_list_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__delay_info__bind_var_list_3_0_i1001);
Define_label(mercury__delay_info__bind_var_list_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);

BEGIN_MODULE(delay_info_module8)
	init_entry(mercury__delay_info__bind_var_3_0);
	init_label(mercury__delay_info__bind_var_3_0_i3);
	init_label(mercury__delay_info__bind_var_3_0_i5);
	init_label(mercury__delay_info__bind_var_3_0_i6);
	init_label(mercury__delay_info__bind_var_3_0_i2);
BEGIN_CODE

/* code for predicate 'bind_var'/3 in mode 0 */
Define_entry(mercury__delay_info__bind_var_3_0);
	MR_incr_sp_push_msg(8, "delay_info:bind_var/3");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = r3;
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__delay_info__bind_var_3_0_i3,
		ENTRY(mercury__delay_info__bind_var_3_0));
Define_label(mercury__delay_info__bind_var_3_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__bind_var_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__delay_info__bind_var_3_0_i2);
	MR_stackvar(7) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__delay_info__bind_var_3_0_i5,
		ENTRY(mercury__delay_info__bind_var_3_0));
Define_label(mercury__delay_info__bind_var_3_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__bind_var_3_0));
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__delay_info__add_pending_goals_6_0),
		mercury__delay_info__bind_var_3_0_i6,
		ENTRY(mercury__delay_info__bind_var_3_0));
Define_label(mercury__delay_info__bind_var_3_0_i6);
	update_prof_current_proc(LABEL(mercury__delay_info__bind_var_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__delay_info__bind_var_3_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__delay_info__bind_var_3_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module9)
	init_entry(mercury__delay_info__bind_all_vars_2_0);
	init_label(mercury__delay_info__bind_all_vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'bind_all_vars'/2 in mode 0 */
Define_entry(mercury__delay_info__bind_all_vars_2_0);
	MR_incr_sp_push_msg(2, "delay_info:bind_all_vars/2");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__delay_info__bind_all_vars_2_0_i2,
		ENTRY(mercury__delay_info__bind_all_vars_2_0));
Define_label(mercury__delay_info__bind_all_vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__delay_info__bind_all_vars_2_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__delay_info__bind_var_list_3_0),
		ENTRY(mercury__delay_info__bind_all_vars_2_0));
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__map__delete_3_1);

BEGIN_MODULE(delay_info_module10)
	init_entry(mercury__delay_info__wakeup_goals_3_0);
	init_label(mercury__delay_info__wakeup_goals_3_0_i3);
	init_label(mercury__delay_info__wakeup_goals_3_0_i6);
	init_label(mercury__delay_info__wakeup_goals_3_0_i7);
	init_label(mercury__delay_info__wakeup_goals_3_0_i8);
	init_label(mercury__delay_info__wakeup_goals_3_0_i9);
	init_label(mercury__delay_info__wakeup_goals_3_0_i10);
	init_label(mercury__delay_info__wakeup_goals_3_0_i11);
	init_label(mercury__delay_info__wakeup_goals_3_0_i2);
BEGIN_CODE

/* code for predicate 'wakeup_goals'/3 in mode 0 */
Define_entry(mercury__delay_info__wakeup_goals_3_0);
	MR_incr_sp_push_msg(9, "delay_info:wakeup_goals/3");
	MR_stackvar(9) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(5) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__delay_info__wakeup_goals_3_0_i3,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i3);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__delay_info__wakeup_goals_3_0_i2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__wakeup_goals_3_0_i2);
	r3 = MR_stackvar(5);
	r5 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__wakeup_goals_3_0_i6,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__stack__pop_det_3_0),
		mercury__delay_info__wakeup_goals_3_0_i7,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i7);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	r3 = r1;
	MR_stackvar(2) = r1;
	MR_stackvar(8) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__delay_info__wakeup_goals_3_0_i8,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i8);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__delay_info__wakeup_goals_3_0_i9,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i9);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__stack__push_3_0),
		mercury__delay_info__wakeup_goals_3_0_i10,
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i10);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__delay_info__wakeup_goals_3_0, "delay_info:delay_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(6);
	localcall(mercury__delay_info__wakeup_goals_3_0,
		LABEL(mercury__delay_info__wakeup_goals_3_0_i11),
		ENTRY(mercury__delay_info__wakeup_goals_3_0));
Define_label(mercury__delay_info__wakeup_goals_3_0_i11);
	update_prof_current_proc(LABEL(mercury__delay_info__wakeup_goals_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__delay_info__wakeup_goals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__delay_info__wakeup_goals_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module11)
	init_entry(mercury__delay_info__remove_delayed_goals_5_0);
	init_label(mercury__delay_info__remove_delayed_goals_5_0_i1001);
	init_label(mercury__delay_info__remove_delayed_goals_5_0_i4);
	init_label(mercury__delay_info__remove_delayed_goals_5_0_i5);
	init_label(mercury__delay_info__remove_delayed_goals_5_0_i6);
	init_label(mercury__delay_info__remove_delayed_goals_5_0_i3);
BEGIN_CODE

/* code for predicate 'remove_delayed_goals'/5 in mode 0 */
Define_static(mercury__delay_info__remove_delayed_goals_5_0);
	MR_incr_sp_push_msg(6, "delay_info:remove_delayed_goals/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__delay_info__remove_delayed_goals_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__remove_delayed_goals_5_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_delayed_goal_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__delay_info__remove_delayed_goals_5_0_i4,
		STATIC(mercury__delay_info__remove_delayed_goals_5_0));
Define_label(mercury__delay_info__remove_delayed_goals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__remove_delayed_goals_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__delay_info__remove_delayed_goals_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(4) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__delay_info__remove_delayed_goals_5_0_i5,
		STATIC(mercury__delay_info__remove_delayed_goals_5_0));
Define_label(mercury__delay_info__remove_delayed_goals_5_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__remove_delayed_goals_5_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__delay_info__delete_waiting_vars_4_0),
		mercury__delay_info__remove_delayed_goals_5_0_i6,
		STATIC(mercury__delay_info__remove_delayed_goals_5_0));
Define_label(mercury__delay_info__remove_delayed_goals_5_0_i6);
	update_prof_current_proc(LABEL(mercury__delay_info__remove_delayed_goals_5_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__delay_info__remove_delayed_goals_5_0_i1001);
Define_label(mercury__delay_info__remove_delayed_goals_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module12)
	init_entry(mercury__delay_info__add_waiting_vars_5_0);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i1002);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i5);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i4);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i7);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i8);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i9);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i10);
	init_label(mercury__delay_info__add_waiting_vars_5_0_i3);
BEGIN_CODE

/* code for predicate 'add_waiting_vars'/5 in mode 0 */
Define_static(mercury__delay_info__add_waiting_vars_5_0);
	MR_incr_sp_push_msg(6, "delay_info:add_waiting_vars/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__delay_info__add_waiting_vars_5_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__add_waiting_vars_5_0_i3);
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__delay_info__add_waiting_vars_5_0_i5,
		STATIC(mercury__delay_info__add_waiting_vars_5_0));
Define_label(mercury__delay_info__add_waiting_vars_5_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__add_waiting_vars_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__delay_info__add_waiting_vars_5_0_i4);
	r3 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	GOTO_LABEL(mercury__delay_info__add_waiting_vars_5_0_i8);
Define_label(mercury__delay_info__add_waiting_vars_5_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__delay_info__add_waiting_vars_5_0_i7,
		STATIC(mercury__delay_info__add_waiting_vars_5_0));
Define_label(mercury__delay_info__add_waiting_vars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__delay_info__add_waiting_vars_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
Define_label(mercury__delay_info__add_waiting_vars_5_0_i8);
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r5;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__add_waiting_vars_5_0_i9,
		STATIC(mercury__delay_info__add_waiting_vars_5_0));
Define_label(mercury__delay_info__add_waiting_vars_5_0_i9);
	update_prof_current_proc(LABEL(mercury__delay_info__add_waiting_vars_5_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__add_waiting_vars_5_0_i10,
		STATIC(mercury__delay_info__add_waiting_vars_5_0));
Define_label(mercury__delay_info__add_waiting_vars_5_0_i10);
	update_prof_current_proc(LABEL(mercury__delay_info__add_waiting_vars_5_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__delay_info__add_waiting_vars_5_0_i1002);
Define_label(mercury__delay_info__add_waiting_vars_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(delay_info_module13)
	init_entry(mercury__delay_info__add_pending_goals_6_0);
	init_label(mercury__delay_info__add_pending_goals_6_0_i1002);
	init_label(mercury__delay_info__add_pending_goals_6_0_i4);
	init_label(mercury__delay_info__add_pending_goals_6_0_i5);
	init_label(mercury__delay_info__add_pending_goals_6_0_i7);
	init_label(mercury__delay_info__add_pending_goals_6_0_i9);
	init_label(mercury__delay_info__add_pending_goals_6_0_i6);
	init_label(mercury__delay_info__add_pending_goals_6_0_i11);
	init_label(mercury__delay_info__add_pending_goals_6_0_i3);
BEGIN_CODE

/* code for predicate 'add_pending_goals'/6 in mode 0 */
Define_static(mercury__delay_info__add_pending_goals_6_0);
	MR_incr_sp_push_msg(8, "delay_info:add_pending_goals/6");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__delay_info__add_pending_goals_6_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__add_pending_goals_6_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(7) = r4;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__delay_info__add_pending_goals_6_0_i4,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__add_pending_goals_6_0));
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__delay_info__delete_waiting_vars_4_0),
		mercury__delay_info__add_pending_goals_6_0_i5,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__add_pending_goals_6_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__delay_info__add_pending_goals_6_0_i7,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i7);
	update_prof_current_proc(LABEL(mercury__delay_info__add_pending_goals_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__delay_info__add_pending_goals_6_0_i6);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__delay_info__add_pending_goals_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__delay_info__add_pending_goals_6_0_i9,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i9);
	update_prof_current_proc(LABEL(mercury__delay_info__add_pending_goals_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__add_pending_goals_6_0_i11,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i6);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__delay_info__add_pending_goals_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__add_pending_goals_6_0_i11,
		STATIC(mercury__delay_info__add_pending_goals_6_0));
Define_label(mercury__delay_info__add_pending_goals_6_0_i11);
	update_prof_current_proc(LABEL(mercury__delay_info__add_pending_goals_6_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__delay_info__add_pending_goals_6_0_i1002);
Define_label(mercury__delay_info__add_pending_goals_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__map__is_empty_1_0);

BEGIN_MODULE(delay_info_module14)
	init_entry(mercury__delay_info__delete_waiting_vars_4_0);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i1002);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i4);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i5);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i7);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i6);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i10);
	init_label(mercury__delay_info__delete_waiting_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'delete_waiting_vars'/4 in mode 0 */
Define_static(mercury__delay_info__delete_waiting_vars_4_0);
	MR_incr_sp_push_msg(6, "delay_info:delete_waiting_vars/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_info__delete_waiting_vars_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__delay_info__delete_waiting_vars_4_0_i4,
		STATIC(mercury__delay_info__delete_waiting_vars_4_0));
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__delay_info__delete_waiting_vars_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__delay_info__delete_waiting_vars_4_0_i5,
		STATIC(mercury__delay_info__delete_waiting_vars_4_0));
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i5);
	update_prof_current_proc(LABEL(mercury__delay_info__delete_waiting_vars_4_0));
	r3 = r1;
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__delay_info__delete_waiting_vars_4_0_i7,
		STATIC(mercury__delay_info__delete_waiting_vars_4_0));
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i7);
	update_prof_current_proc(LABEL(mercury__delay_info__delete_waiting_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__delay_info__delete_waiting_vars_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__delay_info__delete_waiting_vars_4_0_i10,
		STATIC(mercury__delay_info__delete_waiting_vars_4_0));
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__delay_info__delete_waiting_vars_4_0_i10,
		STATIC(mercury__delay_info__delete_waiting_vars_4_0));
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i10);
	update_prof_current_proc(LABEL(mercury__delay_info__delete_waiting_vars_4_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__delay_info__delete_waiting_vars_4_0_i1002);
Define_label(mercury__delay_info__delete_waiting_vars_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___stack__stack_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(delay_info_module15)
	init_entry(mercury____Unify___delay_info__delay_info_0_0);
	init_label(mercury____Unify___delay_info__delay_info_0_0_i2);
	init_label(mercury____Unify___delay_info__delay_info_0_0_i4);
	init_label(mercury____Unify___delay_info__delay_info_0_0_i6);
	init_label(mercury____Unify___delay_info__delay_info_0_0_i1005);
	init_label(mercury____Unify___delay_info__delay_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___delay_info__delay_info_0_0);
	MR_incr_sp_push_msg(7, "delay_info:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___delay_info__delay_info_0_0_i1005);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	call_localret(ENTRY(mercury____Unify___stack__stack_1_0),
		mercury____Unify___delay_info__delay_info_0_0_i2,
		ENTRY(mercury____Unify___delay_info__delay_info_0_0));
Define_label(mercury____Unify___delay_info__delay_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___delay_info__delay_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___delay_info__delay_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___delay_info__delay_info_0_0_i4,
		ENTRY(mercury____Unify___delay_info__delay_info_0_0));
Define_label(mercury____Unify___delay_info__delay_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___delay_info__delay_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___delay_info__delay_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___delay_info__delay_info_0_0_i6,
		ENTRY(mercury____Unify___delay_info__delay_info_0_0));
Define_label(mercury____Unify___delay_info__delay_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___delay_info__delay_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___delay_info__delay_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___stack__stack_1_0),
		ENTRY(mercury____Unify___delay_info__delay_info_0_0));
Define_label(mercury____Unify___delay_info__delay_info_0_0_i1005);
	r1 = FALSE;
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___delay_info__delay_info_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module16)
	init_entry(mercury____Index___delay_info__delay_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___delay_info__delay_info_0_0);
	tailcall(STATIC(mercury____Index___delay_info__delay_info_0__ua0_2_0),
		ENTRY(mercury____Index___delay_info__delay_info_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___stack__stack_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(delay_info_module17)
	init_entry(mercury____Compare___delay_info__delay_info_0_0);
	init_label(mercury____Compare___delay_info__delay_info_0_0_i3);
	init_label(mercury____Compare___delay_info__delay_info_0_0_i7);
	init_label(mercury____Compare___delay_info__delay_info_0_0_i11);
	init_label(mercury____Compare___delay_info__delay_info_0_0_i15);
	init_label(mercury____Compare___delay_info__delay_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___delay_info__delay_info_0_0);
	MR_incr_sp_push_msg(9, "delay_info:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___delay_info__delay_info_0_0_i3,
		ENTRY(mercury____Compare___delay_info__delay_info_0_0));
Define_label(mercury____Compare___delay_info__delay_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___delay_info__delay_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___delay_info__delay_info_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___stack__stack_1_0),
		mercury____Compare___delay_info__delay_info_0_0_i7,
		ENTRY(mercury____Compare___delay_info__delay_info_0_0));
Define_label(mercury____Compare___delay_info__delay_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___delay_info__delay_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___delay_info__delay_info_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___delay_info__delay_info_0_0_i11,
		ENTRY(mercury____Compare___delay_info__delay_info_0_0));
Define_label(mercury____Compare___delay_info__delay_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___delay_info__delay_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___delay_info__delay_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___delay_info__delay_info_0_0_i15,
		ENTRY(mercury____Compare___delay_info__delay_info_0_0));
Define_label(mercury____Compare___delay_info__delay_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___delay_info__delay_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___delay_info__delay_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___stack__stack_1_0),
		ENTRY(mercury____Compare___delay_info__delay_info_0_0));
Define_label(mercury____Compare___delay_info__delay_info_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module18)
	init_entry(mercury____Unify___delay_info__waiting_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__waiting_goals_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___delay_info__waiting_goals_table_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(delay_info_module19)
	init_entry(mercury____Index___delay_info__waiting_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__waiting_goals_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___delay_info__waiting_goals_table_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module20)
	init_entry(mercury____Compare___delay_info__waiting_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__waiting_goals_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_1);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_4);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___delay_info__waiting_goals_table_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module21)
	init_entry(mercury____Unify___delay_info__waiting_goals_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__waiting_goals_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___delay_info__waiting_goals_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module22)
	init_entry(mercury____Index___delay_info__waiting_goals_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__waiting_goals_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___delay_info__waiting_goals_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module23)
	init_entry(mercury____Compare___delay_info__waiting_goals_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__waiting_goals_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_2);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_3);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___delay_info__waiting_goals_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module24)
	init_entry(mercury____Unify___delay_info__pending_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__pending_goals_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___delay_info__pending_goals_table_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module25)
	init_entry(mercury____Index___delay_info__pending_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__pending_goals_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___delay_info__pending_goals_table_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module26)
	init_entry(mercury____Compare___delay_info__pending_goals_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__pending_goals_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_info__common_5);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___delay_info__pending_goals_table_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(delay_info_module27)
	init_entry(mercury____Unify___delay_info__goal_num_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__goal_num_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___delay_info__goal_num_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(delay_info_module28)
	init_entry(mercury____Index___delay_info__goal_num_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__goal_num_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		STATIC(mercury____Index___delay_info__goal_num_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(delay_info_module29)
	init_entry(mercury____Compare___delay_info__goal_num_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__goal_num_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___delay_info__goal_num_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module30)
	init_entry(mercury____Unify___delay_info__depth_num_0_0);
	init_label(mercury____Unify___delay_info__depth_num_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__depth_num_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___delay_info__depth_num_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___delay_info__depth_num_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_index_int_2_0);

BEGIN_MODULE(delay_info_module31)
	init_entry(mercury____Index___delay_info__depth_num_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__depth_num_0_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		STATIC(mercury____Index___delay_info__depth_num_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module32)
	init_entry(mercury____Compare___delay_info__depth_num_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__depth_num_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___delay_info__depth_num_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module33)
	init_entry(mercury____Unify___delay_info__seq_num_0_0);
	init_label(mercury____Unify___delay_info__seq_num_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___delay_info__seq_num_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___delay_info__seq_num_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___delay_info__seq_num_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(delay_info_module34)
	init_entry(mercury____Index___delay_info__seq_num_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___delay_info__seq_num_0_0);
	tailcall(ENTRY(mercury__builtin_index_int_2_0),
		STATIC(mercury____Index___delay_info__seq_num_0_0));
END_MODULE


BEGIN_MODULE(delay_info_module35)
	init_entry(mercury____Compare___delay_info__seq_num_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___delay_info__seq_num_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___delay_info__seq_num_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__delay_info_maybe_bunch_0(void)
{
	delay_info_module0();
	delay_info_module1();
	delay_info_module2();
	delay_info_module3();
	delay_info_module4();
	delay_info_module5();
	delay_info_module6();
	delay_info_module7();
	delay_info_module8();
	delay_info_module9();
	delay_info_module10();
	delay_info_module11();
	delay_info_module12();
	delay_info_module13();
	delay_info_module14();
	delay_info_module15();
	delay_info_module16();
	delay_info_module17();
	delay_info_module18();
	delay_info_module19();
	delay_info_module20();
	delay_info_module21();
	delay_info_module22();
	delay_info_module23();
	delay_info_module24();
	delay_info_module25();
	delay_info_module26();
	delay_info_module27();
	delay_info_module28();
	delay_info_module29();
	delay_info_module30();
	delay_info_module31();
	delay_info_module32();
	delay_info_module33();
	delay_info_module34();
	delay_info_module35();
}

#endif

void mercury__delay_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__delay_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__delay_info_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_delay_info_0,
			delay_info__delay_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_depth_num_0,
			delay_info__depth_num_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_goal_num_0,
			delay_info__goal_num_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_pending_goals_table_0,
			delay_info__pending_goals_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_seq_num_0,
			delay_info__seq_num_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_waiting_goals_0,
			delay_info__waiting_goals_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_delay_info__type_ctor_info_waiting_goals_table_0,
			delay_info__waiting_goals_table_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
