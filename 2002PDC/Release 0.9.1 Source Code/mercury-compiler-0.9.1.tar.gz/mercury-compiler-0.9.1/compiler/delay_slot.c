/*
** Automatically generated from `delay_slot.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__delay_slot__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__delay_slot__fill_branch_delay_slot_2_0);
Declare_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i15);
Declare_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i16);
Declare_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
Declare_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i17);
Declare_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i3);

static const struct mercury_data_delay_slot__common_0_struct {
	Integer f1;
	Integer f2;
}  mercury_data_delay_slot__common_0;

static const struct mercury_data_delay_slot__common_1_struct {
	Word * f1;
}  mercury_data_delay_slot__common_1;

static const struct mercury_data_delay_slot__common_2_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_delay_slot__common_2;

static const struct mercury_data_delay_slot__common_0_struct mercury_data_delay_slot__common_0 = {
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_delay_slot__common_1_struct mercury_data_delay_slot__common_1 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_delay_slot__common_2_struct mercury_data_delay_slot__common_2 = {
	(Integer) 1,
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_slot__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_delay_slot__common_1)
};

Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(delay_slot_module0)
	init_entry(mercury__delay_slot__fill_branch_delay_slot_2_0);
	init_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i15);
	init_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i16);
	init_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	init_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i17);
	init_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i3);
BEGIN_CODE

/* code for predicate 'fill_branch_delay_slot'/2 in mode 0 */
Define_entry(mercury__delay_slot__fill_branch_delay_slot_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i3);
	MR_incr_sp_push_msg(5, "delay_slot:fill_branch_delay_slot/2");
	MR_stackvar(5) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	r6 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 16))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if ((MR_const_field(MR_mktag(3), r5, (Integer) 1) != MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 1)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 2), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r6;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0), (Integer) 1);
	r5 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1);
	localcall(mercury__delay_slot__fill_branch_delay_slot_2_0,
		LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i15),
		ENTRY(mercury__delay_slot__fill_branch_delay_slot_2_0));
Define_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i15);
	update_prof_current_proc(LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	r2 = (Word) MR_string_const(" (early save in delay slot)", 27);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__delay_slot__fill_branch_delay_slot_2_0_i16,
		ENTRY(mercury__delay_slot__fill_branch_delay_slot_2_0));
Define_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i16);
	update_prof_current_proc(LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_delay_slot__common_2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i4);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__delay_slot__fill_branch_delay_slot_2_0,
		LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0_i17),
		ENTRY(mercury__delay_slot__fill_branch_delay_slot_2_0));
Define_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i17);
	update_prof_current_proc(LABEL(mercury__delay_slot__fill_branch_delay_slot_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__delay_slot__fill_branch_delay_slot_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__delay_slot__fill_branch_delay_slot_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__delay_slot_maybe_bunch_0(void)
{
	delay_slot_module0();
}

#endif

void mercury__delay_slot__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__delay_slot__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__delay_slot_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
