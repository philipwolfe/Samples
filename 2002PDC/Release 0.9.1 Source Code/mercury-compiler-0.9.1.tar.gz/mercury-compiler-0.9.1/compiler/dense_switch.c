/*
** Automatically generated from `dense_switch.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__dense_switch__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__dense_switch__is_dense_switch_9_0);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i2);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i5);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i9);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i10);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i11);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i13);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i12);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i7);
Declare_label(mercury__dense_switch__is_dense_switch_9_0_i1);
Define_extern_entry(mercury__dense_switch__generate_13_0);
Declare_label(mercury__dense_switch__generate_13_0_i2);
Declare_label(mercury__dense_switch__generate_13_0_i3);
Declare_label(mercury__dense_switch__generate_13_0_i5);
Declare_label(mercury__dense_switch__generate_13_0_i8);
Declare_label(mercury__dense_switch__generate_13_0_i7);
Declare_label(mercury__dense_switch__generate_13_0_i9);
Define_extern_entry(mercury__dense_switch__calc_density_3_0);
Define_extern_entry(mercury__dense_switch__type_range_5_0);
Declare_label(mercury__dense_switch__type_range_5_0_i4);
Declare_label(mercury__dense_switch__type_range_5_0_i5);
Declare_label(mercury__dense_switch__type_range_5_0_i3);
Declare_label(mercury__dense_switch__type_range_5_0_i9);
Declare_label(mercury__dense_switch__type_range_5_0_i7);
Declare_label(mercury__dense_switch__type_range_5_0_i11);
Declare_label(mercury__dense_switch__type_range_5_0_i13);
Declare_label(mercury__dense_switch__type_range_5_0_i14);
Declare_label(mercury__dense_switch__type_range_5_0_i15);
Declare_label(mercury__dense_switch__type_range_5_0_i16);
Declare_label(mercury__dense_switch__type_range_5_0_i17);
Declare_label(mercury__dense_switch__type_range_5_0_i20);
Declare_label(mercury__dense_switch__type_range_5_0_i1);
Declare_static(mercury__dense_switch__generate_cases_12_0);
Declare_label(mercury__dense_switch__generate_cases_12_0_i2);
Declare_label(mercury__dense_switch__generate_cases_12_0_i3);
Declare_label(mercury__dense_switch__generate_cases_12_0_i7);
Declare_label(mercury__dense_switch__generate_cases_12_0_i8);
Declare_label(mercury__dense_switch__generate_cases_12_0_i9);
Declare_label(mercury__dense_switch__generate_cases_12_0_i10);
Declare_label(mercury__dense_switch__generate_cases_12_0_i11);
Declare_label(mercury__dense_switch__generate_cases_12_0_i4);
Declare_label(mercury__dense_switch__generate_cases_12_0_i12);
Declare_label(mercury__dense_switch__generate_cases_12_0_i14);

static const struct mercury_data_dense_switch__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dense_switch__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_dense_switch__common_0_struct mercury_data_dense_switch__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_switch_gen__type_ctor_info_extended_case_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__index1_det_3_0);
Declare_entry(mercury__code_info__variable_type_4_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__type_util__classify_type_3_0);

BEGIN_MODULE(dense_switch_module0)
	init_entry(mercury__dense_switch__is_dense_switch_9_0);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i2);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i5);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i9);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i10);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i11);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i13);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i12);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i7);
	init_label(mercury__dense_switch__is_dense_switch_9_0_i1);
BEGIN_CODE

/* code for predicate 'is_dense_switch'/9 in mode 0 */
Define_entry(mercury__dense_switch__is_dense_switch_9_0);
	MR_incr_sp_push_msg(8, "dense_switch:is_dense_switch/9");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__dense_switch__is_dense_switch_9_0_i2,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
Define_label(mercury__dense_switch__is_dense_switch_9_0_i2);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	if (((Integer) r1 <= (Integer) 2))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_stackvar(2);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0), (Integer) 1);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	r2 = MR_tempr1;
	r3 = r1;
	MR_stackvar(2) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(3), MR_tempr3, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	call_localret(ENTRY(mercury__list__index1_det_3_0),
		mercury__dense_switch__is_dense_switch_9_0_i5,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
	}
Define_label(mercury__dense_switch__is_dense_switch_9_0_i5);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	r2 = (((Integer) MR_stackvar(2) * (Integer) 100) / (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) - (Integer) MR_stackvar(6)) + (Integer) 1));
	if (((Integer) r2 <= (Integer) MR_stackvar(4)))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i1);
	r2 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1);
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i7);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__dense_switch__is_dense_switch_9_0_i9,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
Define_label(mercury__dense_switch__is_dense_switch_9_0_i9);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__dense_switch__is_dense_switch_9_0_i10,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
Define_label(mercury__dense_switch__is_dense_switch_9_0_i10);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	MR_stackvar(7) = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__dense_switch__is_dense_switch_9_0_i11,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
Define_label(mercury__dense_switch__is_dense_switch_9_0_i11);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	call_localret(STATIC(mercury__dense_switch__type_range_5_0),
		mercury__dense_switch__is_dense_switch_9_0_i13,
		ENTRY(mercury__dense_switch__is_dense_switch_9_0));
Define_label(mercury__dense_switch__is_dense_switch_9_0_i13);
	update_prof_current_proc(LABEL(mercury__dense_switch__is_dense_switch_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i12);
	if (((((Integer) MR_stackvar(2) * (Integer) 100) / (Integer) r2) <= (Integer) MR_stackvar(4)))
		GOTO_LABEL(mercury__dense_switch__is_dense_switch_9_0_i12);
	r5 = r3;
	r1 = TRUE;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = (Integer) 0;
	r3 = ((Integer) MR_tempr1 + (Integer) -1);
	r4 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__dense_switch__is_dense_switch_9_0_i12);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__dense_switch__is_dense_switch_9_0_i7);
	r3 = r2;
	r1 = TRUE;
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__dense_switch__is_dense_switch_9_0_i1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__produce_variable_5_0);
Declare_entry(mercury__code_info__fail_if_rval_is_false_4_0);

BEGIN_MODULE(dense_switch_module1)
	init_entry(mercury__dense_switch__generate_13_0);
	init_label(mercury__dense_switch__generate_13_0_i2);
	init_label(mercury__dense_switch__generate_13_0_i3);
	init_label(mercury__dense_switch__generate_13_0_i5);
	init_label(mercury__dense_switch__generate_13_0_i8);
	init_label(mercury__dense_switch__generate_13_0_i7);
	init_label(mercury__dense_switch__generate_13_0_i9);
BEGIN_CODE

/* code for predicate 'generate'/13 in mode 0 */
Define_entry(mercury__dense_switch__generate_13_0);
	MR_incr_sp_push_msg(10, "dense_switch:generate/13");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r4;
	r2 = r10;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__dense_switch__generate_13_0_i2,
		ENTRY(mercury__dense_switch__generate_13_0));
Define_label(mercury__dense_switch__generate_13_0_i2);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_13_0));
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__generate_13_0_i3);
	MR_stackvar(9) = r2;
	r2 = r3;
	GOTO_LABEL(mercury__dense_switch__generate_13_0_i5);
Define_label(mercury__dense_switch__generate_13_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__dense_switch__generate_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_stackvar(9) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_13_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	r2 = r3;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_stackvar(9), (Integer) 3) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_tempr1;
	}
Define_label(mercury__dense_switch__generate_13_0_i5);
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__generate_13_0_i7);
	MR_stackvar(5) = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__dense_switch__generate_13_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 23;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__dense_switch__generate_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 6;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_13_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_stackvar(3) - (Integer) MR_stackvar(2));
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__dense_switch__generate_13_0_i8,
		ENTRY(mercury__dense_switch__generate_13_0));
Define_label(mercury__dense_switch__generate_13_0_i8);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_13_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r8 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(8);
	call_localret(STATIC(mercury__dense_switch__generate_cases_12_0),
		mercury__dense_switch__generate_13_0_i9,
		ENTRY(mercury__dense_switch__generate_13_0));
	}
Define_label(mercury__dense_switch__generate_13_0_i7);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	r8 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(8);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__dense_switch__generate_cases_12_0),
		mercury__dense_switch__generate_13_0_i9,
		ENTRY(mercury__dense_switch__generate_13_0));
Define_label(mercury__dense_switch__generate_13_0_i9);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_13_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_13_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_13_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_13_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_13_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__dense_switch__generate_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r10, (Integer) 0) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("switch (using dense jump table)", 31);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
END_MODULE


BEGIN_MODULE(dense_switch_module2)
	init_entry(mercury__dense_switch__calc_density_3_0);
BEGIN_CODE

/* code for predicate 'calc_density'/3 in mode 0 */
Define_entry(mercury__dense_switch__calc_density_3_0);
	r1 = (((Integer) r1 * (Integer) 100) / (Integer) r2);
	proceed();
END_MODULE

Declare_entry(mercury__char__max_char_value_1_0);
Declare_entry(mercury__char__min_char_value_1_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;
Declare_entry(mercury__map__count_2_0);

BEGIN_MODULE(dense_switch_module3)
	init_entry(mercury__dense_switch__type_range_5_0);
	init_label(mercury__dense_switch__type_range_5_0_i4);
	init_label(mercury__dense_switch__type_range_5_0_i5);
	init_label(mercury__dense_switch__type_range_5_0_i3);
	init_label(mercury__dense_switch__type_range_5_0_i9);
	init_label(mercury__dense_switch__type_range_5_0_i7);
	init_label(mercury__dense_switch__type_range_5_0_i11);
	init_label(mercury__dense_switch__type_range_5_0_i13);
	init_label(mercury__dense_switch__type_range_5_0_i14);
	init_label(mercury__dense_switch__type_range_5_0_i15);
	init_label(mercury__dense_switch__type_range_5_0_i16);
	init_label(mercury__dense_switch__type_range_5_0_i17);
	init_label(mercury__dense_switch__type_range_5_0_i20);
	init_label(mercury__dense_switch__type_range_5_0_i1);
BEGIN_CODE

/* code for predicate 'type_range'/5 in mode 0 */
Define_entry(mercury__dense_switch__type_range_5_0);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__dense_switch__type_range_5_0_i3);
	MR_incr_sp_push_msg(4, "dense_switch:type_range/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__char__max_char_value_1_0),
		mercury__dense_switch__type_range_5_0_i4,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i4);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__char__min_char_value_1_0),
		mercury__dense_switch__type_range_5_0_i5,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i5);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	r2 = (((Integer) MR_stackvar(1) - (Integer) r1) + (Integer) 1);
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__dense_switch__type_range_5_0_i3);
	if (((Integer) r1 != (Integer) 5))
		GOTO_LABEL(mercury__dense_switch__type_range_5_0_i1);
	MR_incr_sp_push_msg(4, "dense_switch:type_range/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r1 = r2;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__dense_switch__type_range_5_0_i9,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i9);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dense_switch__type_range_5_0_i7);
	r1 = MR_stackvar(1);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__dense_switch__type_range_5_0_i13,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i7);
	r1 = (Word) MR_string_const("dense_switch__type_range: invalid enum type?", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dense_switch__type_range_5_0_i11,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i11);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__dense_switch__type_range_5_0_i13,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i13);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__dense_switch__type_range_5_0_i14,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i14);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dense_switch__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dense_switch__type_range_5_0_i15,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i15);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__dense_switch__type_range_5_0_i16,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i16);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__dense_switch__type_range_5_0_i17);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0;
	call_localret(ENTRY(mercury__map__count_2_0),
		mercury__dense_switch__type_range_5_0_i20,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i17);
	r1 = (Word) MR_string_const("dense_switch__type_range: enum type is not d.u. type?", 53);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__dense_switch__type_range_5_0_i20,
		ENTRY(mercury__dense_switch__type_range_5_0));
Define_label(mercury__dense_switch__type_range_5_0_i20);
	update_prof_current_proc(LABEL(mercury__dense_switch__type_range_5_0));
	r2 = r1;
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__dense_switch__type_range_5_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);
Declare_entry(mercury__code_info__generate_failure_3_0);

BEGIN_MODULE(dense_switch_module4)
	init_entry(mercury__dense_switch__generate_cases_12_0);
	init_label(mercury__dense_switch__generate_cases_12_0_i2);
	init_label(mercury__dense_switch__generate_cases_12_0_i3);
	init_label(mercury__dense_switch__generate_cases_12_0_i7);
	init_label(mercury__dense_switch__generate_cases_12_0_i8);
	init_label(mercury__dense_switch__generate_cases_12_0_i9);
	init_label(mercury__dense_switch__generate_cases_12_0_i10);
	init_label(mercury__dense_switch__generate_cases_12_0_i11);
	init_label(mercury__dense_switch__generate_cases_12_0_i4);
	init_label(mercury__dense_switch__generate_cases_12_0_i12);
	init_label(mercury__dense_switch__generate_cases_12_0_i14);
BEGIN_CODE

/* code for predicate 'generate_cases'/12 in mode 0 */
Define_static(mercury__dense_switch__generate_cases_12_0);
	MR_incr_sp_push_msg(11, "dense_switch:generate_cases/12");
	MR_stackvar(11) = (Word) MR_succip;
	if (((Integer) r2 <= (Integer) r3))
		GOTO_LABEL(mercury__dense_switch__generate_cases_12_0_i2);
	r1 = r7;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("End of dense switch", 19);
	MR_succip = (Code *) MR_stackvar(11);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	r4 = r8;
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__dense_switch__generate_cases_12_0_i2);
	MR_stackvar(1) = r1;
	r1 = r8;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__dense_switch__generate_cases_12_0_i3,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i3);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dense_switch__generate_cases_12_0_i4);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0), (Integer) 1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dense_switch__generate_cases_12_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__dense_switch__generate_cases_12_0_i4);
	if ((MR_stackvar(2) != MR_const_field(MR_mktag(3), r3, (Integer) 1)))
		GOTO_LABEL(mercury__dense_switch__generate_cases_12_0_i4);
	r3 = MR_stackvar(1);
	MR_stackvar(8) = r1;
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 3);
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__dense_switch__generate_cases_12_0_i7,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i7);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__dense_switch__generate_cases_12_0_i8,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i8);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__dense_switch__generate_cases_12_0_i9,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i9);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r3 = r2;
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__dense_switch__generate_cases_12_0_i10,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i10);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r5 = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r4;
	MR_stackvar(7) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_stackvar(7), (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r1 = MR_stackvar(10);
	r2 = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__dense_switch__generate_cases_12_0_i11,
		STATIC(mercury__dense_switch__generate_cases_12_0));
	}
Define_label(mercury__dense_switch__generate_cases_12_0_i11);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("case of dense switch", 20);
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r10, (Integer) 0) = MR_tempr1;
	r9 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	r8 = r2;
	MR_field(MR_mktag(3), r12, (Integer) 1) = MR_tempr1;
	r2 = ((Integer) r9 + (Integer) 1);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("branch to end of dense switch", 29);
	localcall(mercury__dense_switch__generate_cases_12_0,
		LABEL(mercury__dense_switch__generate_cases_12_0_i14),
		STATIC(mercury__dense_switch__generate_cases_12_0));
	}
Define_label(mercury__dense_switch__generate_cases_12_0_i4);
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__dense_switch__generate_cases_12_0_i12,
		STATIC(mercury__dense_switch__generate_cases_12_0));
Define_label(mercury__dense_switch__generate_cases_12_0_i12);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r7 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r12, (Integer) 1) = (Word) MR_string_const("compiler-introduced `fail' case of dense switch", 47);
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = MR_tempr1;
	r11 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r14, MR_mktag(3), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r14, (Integer) 0) = (Integer) 5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	r8 = r2;
	MR_field(MR_mktag(3), r14, (Integer) 1) = MR_tempr1;
	r2 = ((Integer) r11 + (Integer) 1);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(1), r12, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("branch to end of dense switch", 29);
	localcall(mercury__dense_switch__generate_cases_12_0,
		LABEL(mercury__dense_switch__generate_cases_12_0_i14),
		STATIC(mercury__dense_switch__generate_cases_12_0));
	}
Define_label(mercury__dense_switch__generate_cases_12_0_i14);
	update_prof_current_proc(LABEL(mercury__dense_switch__generate_cases_12_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__dense_switch__generate_cases_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r3, (Integer) 1) = r7;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__dense_switch_maybe_bunch_0(void)
{
	dense_switch_module0();
	dense_switch_module1();
	dense_switch_module2();
	dense_switch_module3();
	dense_switch_module4();
}

#endif

void mercury__dense_switch__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__dense_switch__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__dense_switch_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
