/*
** Automatically generated from `det_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__det_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___det_util__det_info_0__ua0_2_0);
Define_extern_entry(mercury__det_util__update_instmap_3_0);
Declare_label(mercury__det_util__update_instmap_3_0_i2);
Define_extern_entry(mercury__det_util__delete_unreachable_cases_3_0);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i1008);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i3);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i1001);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i5);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i8);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i6);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i12);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i11);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i18);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i20);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i16);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i22);
Declare_label(mercury__det_util__delete_unreachable_cases_3_0_i21);
Define_extern_entry(mercury__det_util__interpret_unify_4_0);
Declare_label(mercury__det_util__interpret_unify_4_0_i1007);
Declare_label(mercury__det_util__interpret_unify_4_0_i4);
Declare_label(mercury__det_util__interpret_unify_4_0_i5);
Declare_label(mercury__det_util__interpret_unify_4_0_i6);
Declare_label(mercury__det_util__interpret_unify_4_0_i1);
Define_extern_entry(mercury__det_util__det_lookup_detism_4_0);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i2);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i3);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i4);
Declare_label(mercury__det_util__det_lookup_detism_4_0_i5);
Define_extern_entry(mercury__det_util__det_get_proc_info_2_0);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i2);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i3);
Declare_label(mercury__det_util__det_get_proc_info_2_0_i4);
Define_extern_entry(mercury__det_util__det_lookup_var_type_4_0);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i2);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i3);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i6);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i8);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i5);
Declare_label(mercury__det_util__det_lookup_var_type_4_0_i11);
Define_extern_entry(mercury__det_util__det_no_output_vars_4_0);
Define_extern_entry(mercury__det_util__det_info_init_5_0);
Declare_label(mercury__det_util__det_info_init_5_0_i2);
Declare_label(mercury__det_util__det_info_init_5_0_i3);
Declare_label(mercury__det_util__det_info_init_5_0_i4);
Define_extern_entry(mercury__det_util__det_info_get_module_info_2_0);
Define_extern_entry(mercury__det_util__det_info_get_pred_id_2_0);
Define_extern_entry(mercury__det_util__det_info_get_proc_id_2_0);
Define_extern_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
Define_extern_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
Define_extern_entry(mercury__det_util__det_info_get_fully_strict_2_0);
Define_extern_entry(mercury__det_util__det_info_set_module_info_3_0);
Define_extern_entry(mercury____Unify___det_util__maybe_changed_0_0);
Declare_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
Define_extern_entry(mercury____Index___det_util__maybe_changed_0_0);
Define_extern_entry(mercury____Compare___det_util__maybe_changed_0_0);
Define_extern_entry(mercury____Unify___det_util__det_info_0_0);
Declare_label(mercury____Unify___det_util__det_info_0_0_i2);
Declare_label(mercury____Unify___det_util__det_info_0_0_i4);
Declare_label(mercury____Unify___det_util__det_info_0_0_i6);
Declare_label(mercury____Unify___det_util__det_info_0_0_i1);
Define_extern_entry(mercury____Index___det_util__det_info_0_0);
Define_extern_entry(mercury____Compare___det_util__det_info_0_0);
Declare_label(mercury____Compare___det_util__det_info_0_0_i3);
Declare_label(mercury____Compare___det_util__det_info_0_0_i7);
Declare_label(mercury____Compare___det_util__det_info_0_0_i11);
Declare_label(mercury____Compare___det_util__det_info_0_0_i15);
Declare_label(mercury____Compare___det_util__det_info_0_0_i19);
Declare_label(mercury____Compare___det_util__det_info_0_0_i27);

const struct MR_TypeCtorInfo_struct mercury_data_det_util__type_ctor_info_det_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_det_util__type_ctor_info_maybe_changed_0;

static const struct mercury_data_det_util__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_det_util__common_0;

static const struct mercury_data_det_util__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_det_util__common_1;

static const struct mercury_data_det_util__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_det_util__common_2;

static const struct mercury_data_det_util__common_3_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_det_util__common_3;

static const struct mercury_data_det_util__common_4_struct {
	Word * f1;
}  mercury_data_det_util__common_4;

static const struct mercury_data_det_util__common_5_struct {
	Word * f1;
}  mercury_data_det_util__common_5;

static const struct mercury_data_det_util__common_6_struct {
	Word * f1;
}  mercury_data_det_util__common_6;

static const struct mercury_data_det_util__common_7_struct {
	Word * f1;
}  mercury_data_det_util__common_7;

static const struct mercury_data_det_util__common_8_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	String f8;
	Word * f9;
	Integer f10;
	Integer f11;
}  mercury_data_det_util__common_8;

static const struct mercury_data_det_util__type_ctor_functors_maybe_changed_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_det_util__type_ctor_functors_maybe_changed_0;

static const struct mercury_data_det_util__type_ctor_layout_maybe_changed_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_det_util__type_ctor_layout_maybe_changed_0;

static const struct mercury_data_det_util__type_ctor_functors_det_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_det_util__type_ctor_functors_det_info_0;

static const struct mercury_data_det_util__type_ctor_layout_det_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_det_util__type_ctor_layout_det_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_det_util__type_ctor_info_det_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___det_util__det_info_0_0),
	ENTRY(mercury____Index___det_util__det_info_0_0),
	ENTRY(mercury____Compare___det_util__det_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_det_util__type_ctor_functors_det_info_0,
	(Word *) &mercury_data_det_util__type_ctor_layout_det_info_0,
	MR_string_const("det_util", 8),
	MR_string_const("det_info", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_det_util__type_ctor_info_maybe_changed_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___det_util__maybe_changed_0_0),
	ENTRY(mercury____Index___det_util__maybe_changed_0_0),
	ENTRY(mercury____Compare___det_util__maybe_changed_0_0),
	(Integer) 0,
	(Word *) &mercury_data_det_util__type_ctor_functors_maybe_changed_0,
	(Word *) &mercury_data_det_util__type_ctor_layout_maybe_changed_0,
	MR_string_const("det_util", 8),
	MR_string_const("maybe_changed", 13),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_det_util__common_0_struct mercury_data_det_util__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_det_util__common_1_struct mercury_data_det_util__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_det_util__common_2_struct mercury_data_det_util__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_det_util__common_3_struct mercury_data_det_util__common_3 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("changed", 7),
	MR_string_const("unchanged", 9)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_det_util__common_4_struct mercury_data_det_util__common_4 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_det_util__common_5_struct mercury_data_det_util__common_5 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
static const struct mercury_data_det_util__common_6_struct mercury_data_det_util__common_6 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_det_util__common_7_struct mercury_data_det_util__common_7 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_det_util__common_8_struct mercury_data_det_util__common_8 = {
	(Integer) 6,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_7),
	MR_string_const("det_info", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_det_util__type_ctor_functors_maybe_changed_0_struct mercury_data_det_util__type_ctor_functors_maybe_changed_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_3)
};

static const struct mercury_data_det_util__type_ctor_layout_maybe_changed_0_struct mercury_data_det_util__type_ctor_layout_maybe_changed_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_3)
};

static const struct mercury_data_det_util__type_ctor_functors_det_info_0_struct mercury_data_det_util__type_ctor_functors_det_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_8)
};

static const struct mercury_data_det_util__type_ctor_layout_det_info_0_struct mercury_data_det_util__type_ctor_layout_det_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_det_util__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(det_util_module0)
	init_entry(mercury____Index___det_util__det_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___det_util__det_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___det_util__det_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);

BEGIN_MODULE(det_util_module1)
	init_entry(mercury__det_util__update_instmap_3_0);
	init_label(mercury__det_util__update_instmap_3_0_i2);
BEGIN_CODE

/* code for predicate 'update_instmap'/3 in mode 0 */
Define_entry(mercury__det_util__update_instmap_3_0);
	MR_incr_sp_push_msg(2, "det_util:update_instmap/3");
	MR_stackvar(2) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__det_util__update_instmap_3_0_i2,
		ENTRY(mercury__det_util__update_instmap_3_0));
Define_label(mercury__det_util__update_instmap_3_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__update_instmap_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		ENTRY(mercury__det_util__update_instmap_3_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);

BEGIN_MODULE(det_util_module2)
	init_entry(mercury__det_util__delete_unreachable_cases_3_0);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i1008);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i3);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i1001);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i5);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i8);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i6);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i12);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i11);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i18);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i20);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i16);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i22);
	init_label(mercury__det_util__delete_unreachable_cases_3_0_i21);
BEGIN_CODE

/* code for predicate 'delete_unreachable_cases'/3 in mode 0 */
Define_entry(mercury__det_util__delete_unreachable_cases_3_0);
	MR_incr_sp_push_msg(8, "det_util:delete_unreachable_cases/3");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i1008);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i5);
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i1001);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(7) = r3;
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__det_util__delete_unreachable_cases_3_0_i8,
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i8);
	update_prof_current_proc(LABEL(mercury__det_util__delete_unreachable_cases_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i6);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(4);
	localcall(mercury__det_util__delete_unreachable_cases_3_0,
		LABEL(mercury__det_util__delete_unreachable_cases_3_0_i20),
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i6);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury__det_util__delete_unreachable_cases_3_0_i12,
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i12);
	update_prof_current_proc(LABEL(mercury__det_util__delete_unreachable_cases_3_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i11);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i1008);
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i11);
	r3 = MR_stackvar(4);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i1001);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_stackvar(1);
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1);
	MR_stackvar(7) = MR_tempr1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__det_util__delete_unreachable_cases_3_0_i18,
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
	}
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i18);
	update_prof_current_proc(LABEL(mercury__det_util__delete_unreachable_cases_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i16);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	localcall(mercury__det_util__delete_unreachable_cases_3_0,
		LABEL(mercury__det_util__delete_unreachable_cases_3_0_i20),
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i20);
	update_prof_current_proc(LABEL(mercury__det_util__delete_unreachable_cases_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__det_util__delete_unreachable_cases_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i16);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury__det_util__delete_unreachable_cases_3_0_i22,
		ENTRY(mercury__det_util__delete_unreachable_cases_3_0));
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i22);
	update_prof_current_proc(LABEL(mercury__det_util__delete_unreachable_cases_3_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i21);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i1008);
Define_label(mercury__det_util__delete_unreachable_cases_3_0_i21);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__det_util__delete_unreachable_cases_3_0_i1008);
END_MODULE

Declare_entry(mercury__term__unify_4_0);
Declare_entry(mercury__term__var_list_to_term_list_2_0);
Declare_entry(mercury__hlds_data__cons_id_and_args_to_term_3_0);

BEGIN_MODULE(det_util_module3)
	init_entry(mercury__det_util__interpret_unify_4_0);
	init_label(mercury__det_util__interpret_unify_4_0_i1007);
	init_label(mercury__det_util__interpret_unify_4_0_i4);
	init_label(mercury__det_util__interpret_unify_4_0_i5);
	init_label(mercury__det_util__interpret_unify_4_0_i6);
	init_label(mercury__det_util__interpret_unify_4_0_i1);
BEGIN_CODE

/* code for predicate 'interpret_unify'/4 in mode 0 */
Define_entry(mercury__det_util__interpret_unify_4_0);
	MR_incr_sp_push_msg(4, "det_util:interpret_unify/4");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r2) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i4);
	if ((MR_tag(r2) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i1007);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__det_util__interpret_unify_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__det_util__interpret_unify_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__term__unify_4_0),
		ENTRY(mercury__det_util__interpret_unify_4_0));
Define_label(mercury__det_util__interpret_unify_4_0_i1007);
	r1 = TRUE;
	r2 = r3;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__det_util__interpret_unify_4_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__term__var_list_to_term_list_2_0),
		mercury__det_util__interpret_unify_4_0_i5,
		ENTRY(mercury__det_util__interpret_unify_4_0));
Define_label(mercury__det_util__interpret_unify_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_data__cons_id_and_args_to_term_3_0),
		mercury__det_util__interpret_unify_4_0_i6,
		ENTRY(mercury__det_util__interpret_unify_4_0));
Define_label(mercury__det_util__interpret_unify_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_util__interpret_unify_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__det_util__interpret_unify_4_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__det_util__interpret_unify_4_0, "term:term/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__term__unify_4_0),
		ENTRY(mercury__det_util__interpret_unify_4_0));
Define_label(mercury__det_util__interpret_unify_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_interface_determinism_2_0);

BEGIN_MODULE(det_util_module4)
	init_entry(mercury__det_util__det_lookup_detism_4_0);
	init_label(mercury__det_util__det_lookup_detism_4_0_i2);
	init_label(mercury__det_util__det_lookup_detism_4_0_i3);
	init_label(mercury__det_util__det_lookup_detism_4_0_i4);
	init_label(mercury__det_util__det_lookup_detism_4_0_i5);
BEGIN_CODE

/* code for predicate 'det_lookup_detism'/4 in mode 0 */
Define_entry(mercury__det_util__det_lookup_detism_4_0);
	MR_incr_sp_push_msg(3, "det_util:det_lookup_detism/4");
	MR_stackvar(3) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_util__det_lookup_detism_4_0_i2,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
Define_label(mercury__det_util__det_lookup_detism_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__det_util__det_lookup_detism_4_0_i3,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
Define_label(mercury__det_util__det_lookup_detism_4_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_util__det_lookup_detism_4_0_i4,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
Define_label(mercury__det_util__det_lookup_detism_4_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__det_util__det_lookup_detism_4_0_i5,
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
Define_label(mercury__det_util__det_lookup_detism_4_0_i5);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_detism_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_interface_determinism_2_0),
		ENTRY(mercury__det_util__det_lookup_detism_4_0));
END_MODULE


BEGIN_MODULE(det_util_module5)
	init_entry(mercury__det_util__det_get_proc_info_2_0);
	init_label(mercury__det_util__det_get_proc_info_2_0_i2);
	init_label(mercury__det_util__det_get_proc_info_2_0_i3);
	init_label(mercury__det_util__det_get_proc_info_2_0_i4);
BEGIN_CODE

/* code for predicate 'det_get_proc_info'/2 in mode 0 */
Define_entry(mercury__det_util__det_get_proc_info_2_0);
	MR_incr_sp_push_msg(3, "det_util:det_get_proc_info/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__det_util__det_get_proc_info_2_0_i2,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
Define_label(mercury__det_util__det_get_proc_info_2_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__det_util__det_get_proc_info_2_0_i3,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
Define_label(mercury__det_util__det_get_proc_info_2_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__det_util__det_get_proc_info_2_0_i4,
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
Define_label(mercury__det_util__det_get_proc_info_2_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_get_proc_info_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__map__lookup_3_0),
		ENTRY(mercury__det_util__det_get_proc_info_2_0));
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(det_util_module6)
	init_entry(mercury__det_util__det_lookup_var_type_4_0);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i2);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i3);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i6);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i8);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i5);
	init_label(mercury__det_util__det_lookup_var_type_4_0_i11);
BEGIN_CODE

/* code for predicate 'det_lookup_var_type'/4 in mode 0 */
Define_entry(mercury__det_util__det_lookup_var_type_4_0);
	MR_incr_sp_push_msg(3, "det_util:det_lookup_var_type/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__det_util__det_lookup_var_type_4_0_i2,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__det_util__det_lookup_var_type_4_0_i3,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__det_util__det_lookup_var_type_4_0_i6,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i6);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__det_util__det_lookup_var_type_4_0_i5);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__det_util__det_lookup_var_type_4_0_i8,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i8);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_det_util__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i5);
	r1 = (Word) MR_string_const("cannot lookup the type of a variable", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__det_util__det_lookup_var_type_4_0_i11,
		ENTRY(mercury__det_util__det_lookup_var_type_4_0));
Define_label(mercury__det_util__det_lookup_var_type_4_0_i11);
	update_prof_current_proc(LABEL(mercury__det_util__det_lookup_var_type_4_0));
	r2 = r1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = TRUE;
	proceed();
END_MODULE

Declare_entry(mercury__instmap__no_output_vars_4_0);

BEGIN_MODULE(det_util_module7)
	init_entry(mercury__det_util__det_no_output_vars_4_0);
BEGIN_CODE

/* code for predicate 'det_no_output_vars'/4 in mode 0 */
Define_entry(mercury__det_util__det_no_output_vars_4_0);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r4 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	tailcall(ENTRY(mercury__instmap__no_output_vars_4_0),
		ENTRY(mercury__det_util__det_no_output_vars_4_0));
	}
END_MODULE

Declare_entry(mercury__globals__lookup_bool_option_3_0);

BEGIN_MODULE(det_util_module8)
	init_entry(mercury__det_util__det_info_init_5_0);
	init_label(mercury__det_util__det_info_init_5_0_i2);
	init_label(mercury__det_util__det_info_init_5_0_i3);
	init_label(mercury__det_util__det_info_init_5_0_i4);
BEGIN_CODE

/* code for predicate 'det_info_init'/5 in mode 0 */
Define_entry(mercury__det_util__det_info_init_5_0);
	MR_incr_sp_push_msg(6, "det_util:det_info_init/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r4;
	r2 = (Integer) 65;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i2,
		ENTRY(mercury__det_util__det_info_init_5_0));
Define_label(mercury__det_util__det_info_init_5_0_i2);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	r2 = (Integer) 66;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i3,
		ENTRY(mercury__det_util__det_info_init_5_0));
Define_label(mercury__det_util__det_info_init_5_0_i3);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	r2 = (Integer) 67;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__det_util__det_info_init_5_0_i4,
		ENTRY(mercury__det_util__det_info_init_5_0));
Define_label(mercury__det_util__det_info_init_5_0_i4);
	update_prof_current_proc(LABEL(mercury__det_util__det_info_init_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 6, mercury__det_util__det_info_init_5_0, "det_util:det_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module9)
	init_entry(mercury__det_util__det_info_get_module_info_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_module_info'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_module_info_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module10)
	init_entry(mercury__det_util__det_info_get_pred_id_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_pred_id'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_pred_id_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module11)
	init_entry(mercury__det_util__det_info_get_proc_id_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_proc_id'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_proc_id_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module12)
	init_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_reorder_conj'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_reorder_conj_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module13)
	init_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_reorder_disj'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_reorder_disj_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module14)
	init_entry(mercury__det_util__det_info_get_fully_strict_2_0);
BEGIN_CODE

/* code for predicate 'det_info_get_fully_strict'/2 in mode 0 */
Define_entry(mercury__det_util__det_info_get_fully_strict_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module15)
	init_entry(mercury__det_util__det_info_set_module_info_3_0);
BEGIN_CODE

/* code for predicate 'det_info_set_module_info'/3 in mode 0 */
Define_entry(mercury__det_util__det_info_set_module_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 6, mercury__det_util__det_info_set_module_info_3_0, "det_util:det_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module16)
	init_entry(mercury____Unify___det_util__maybe_changed_0_0);
	init_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___det_util__maybe_changed_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___det_util__maybe_changed_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___det_util__maybe_changed_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module17)
	init_entry(mercury____Index___det_util__maybe_changed_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___det_util__maybe_changed_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(det_util_module18)
	init_entry(mercury____Compare___det_util__maybe_changed_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___det_util__maybe_changed_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___det_util__maybe_changed_0_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);

BEGIN_MODULE(det_util_module19)
	init_entry(mercury____Unify___det_util__det_info_0_0);
	init_label(mercury____Unify___det_util__det_info_0_0_i2);
	init_label(mercury____Unify___det_util__det_info_0_0_i4);
	init_label(mercury____Unify___det_util__det_info_0_0_i6);
	init_label(mercury____Unify___det_util__det_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___det_util__det_info_0_0);
	MR_incr_sp_push_msg(11, "det_util:__Unify__/2");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___det_util__det_info_0_0_i2,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
Define_label(mercury____Unify___det_util__det_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury____Unify___det_util__det_info_0_0_i4,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
Define_label(mercury____Unify___det_util__det_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury____Unify___det_util__det_info_0_0_i6,
		ENTRY(mercury____Unify___det_util__det_info_0_0));
Define_label(mercury____Unify___det_util__det_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___det_util__det_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(8)))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	if ((MR_stackvar(4) != MR_stackvar(9)))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(10)))
		GOTO_LABEL(mercury____Unify___det_util__det_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___det_util__det_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(det_util_module20)
	init_entry(mercury____Index___det_util__det_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___det_util__det_info_0_0);
	tailcall(STATIC(mercury____Index___det_util__det_info_0__ua0_2_0),
		ENTRY(mercury____Index___det_util__det_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Compare___hlds_pred__proc_id_0_0);

BEGIN_MODULE(det_util_module21)
	init_entry(mercury____Compare___det_util__det_info_0_0);
	init_label(mercury____Compare___det_util__det_info_0_0_i3);
	init_label(mercury____Compare___det_util__det_info_0_0_i7);
	init_label(mercury____Compare___det_util__det_info_0_0_i11);
	init_label(mercury____Compare___det_util__det_info_0_0_i15);
	init_label(mercury____Compare___det_util__det_info_0_0_i19);
	init_label(mercury____Compare___det_util__det_info_0_0_i27);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___det_util__det_info_0_0);
	MR_incr_sp_push_msg(11, "det_util:__Compare__/3");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___det_util__det_info_0_0_i3,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i27);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
		mercury____Compare___det_util__det_info_0_0_i7,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i27);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___hlds_pred__proc_id_0_0),
		mercury____Compare___det_util__det_info_0_0_i11,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i27);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___det_util__det_info_0_0_i15,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i27);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___det_util__det_info_0_0_i19,
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___det_util__det_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___det_util__det_info_0_0_i27);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___det_util__det_info_0_0));
Define_label(mercury____Compare___det_util__det_info_0_0_i27);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__det_util_maybe_bunch_0(void)
{
	det_util_module0();
	det_util_module1();
	det_util_module2();
	det_util_module3();
	det_util_module4();
	det_util_module5();
	det_util_module6();
	det_util_module7();
	det_util_module8();
	det_util_module9();
	det_util_module10();
	det_util_module11();
	det_util_module12();
	det_util_module13();
	det_util_module14();
	det_util_module15();
	det_util_module16();
	det_util_module17();
	det_util_module18();
	det_util_module19();
	det_util_module20();
	det_util_module21();
}

#endif

void mercury__det_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__det_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__det_util_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_det_util__type_ctor_info_det_info_0,
			det_util__det_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_det_util__type_ctor_info_maybe_changed_0,
			det_util__maybe_changed_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
