/*
** Automatically generated from `dnf.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__dnf__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___dnf__dnf_info_0__ua0_2_0);
Define_extern_entry(mercury__dnf__transform_module_4_0);
Declare_label(mercury__dnf__transform_module_4_0_i2);
Declare_label(mercury__dnf__transform_module_4_0_i3);
Define_extern_entry(mercury__dnf__transform_proc_8_0);
Declare_label(mercury__dnf__transform_proc_8_0_i2);
Declare_label(mercury__dnf__transform_proc_8_0_i3);
Declare_label(mercury__dnf__transform_proc_8_0_i4);
Declare_label(mercury__dnf__transform_proc_8_0_i5);
Declare_label(mercury__dnf__transform_proc_8_0_i6);
Declare_label(mercury__dnf__transform_proc_8_0_i7);
Declare_label(mercury__dnf__transform_proc_8_0_i8);
Declare_label(mercury__dnf__transform_proc_8_0_i9);
Declare_label(mercury__dnf__transform_proc_8_0_i10);
Declare_label(mercury__dnf__transform_proc_8_0_i11);
Declare_label(mercury__dnf__transform_proc_8_0_i12);
Declare_label(mercury__dnf__transform_proc_8_0_i13);
Declare_label(mercury__dnf__transform_proc_8_0_i14);
Declare_static(mercury__dnf__transform_preds_5_0);
Declare_label(mercury__dnf__transform_preds_5_0_i1004);
Declare_label(mercury__dnf__transform_preds_5_0_i7);
Declare_label(mercury__dnf__transform_preds_5_0_i9);
Declare_label(mercury__dnf__transform_preds_5_0_i10);
Declare_label(mercury__dnf__transform_preds_5_0_i11);
Declare_label(mercury__dnf__transform_preds_5_0_i14);
Declare_label(mercury__dnf__transform_preds_5_0_i13);
Declare_label(mercury__dnf__transform_preds_5_0_i16);
Declare_label(mercury__dnf__transform_preds_5_0_i6);
Declare_label(mercury__dnf__transform_preds_5_0_i18);
Declare_label(mercury__dnf__transform_preds_5_0_i19);
Declare_label(mercury__dnf__transform_preds_5_0_i20);
Declare_label(mercury__dnf__transform_preds_5_0_i21);
Declare_label(mercury__dnf__transform_preds_5_0_i22);
Declare_label(mercury__dnf__transform_preds_5_0_i4);
Declare_label(mercury__dnf__transform_preds_5_0_i3);
Declare_static(mercury__dnf__transform_procs_7_0);
Declare_label(mercury__dnf__transform_procs_7_0_i1001);
Declare_label(mercury__dnf__transform_procs_7_0_i4);
Declare_label(mercury__dnf__transform_procs_7_0_i5);
Declare_label(mercury__dnf__transform_procs_7_0_i6);
Declare_label(mercury__dnf__transform_procs_7_0_i7);
Declare_label(mercury__dnf__transform_procs_7_0_i8);
Declare_label(mercury__dnf__transform_procs_7_0_i9);
Declare_label(mercury__dnf__transform_procs_7_0_i10);
Declare_label(mercury__dnf__transform_procs_7_0_i11);
Declare_label(mercury__dnf__transform_procs_7_0_i12);
Declare_label(mercury__dnf__transform_procs_7_0_i13);
Declare_label(mercury__dnf__transform_procs_7_0_i3);
Declare_static(mercury__dnf__transform_goal_10_0);
Declare_label(mercury__dnf__transform_goal_10_0_i4);
Declare_label(mercury__dnf__transform_goal_10_0_i5);
Declare_label(mercury__dnf__transform_goal_10_0_i8);
Declare_label(mercury__dnf__transform_goal_10_0_i9);
Declare_label(mercury__dnf__transform_goal_10_0_i10);
Declare_label(mercury__dnf__transform_goal_10_0_i12);
Declare_label(mercury__dnf__transform_goal_10_0_i13);
Declare_label(mercury__dnf__transform_goal_10_0_i14);
Declare_label(mercury__dnf__transform_goal_10_0_i1020);
Declare_label(mercury__dnf__transform_goal_10_0_i16);
Declare_label(mercury__dnf__transform_goal_10_0_i1022);
Declare_label(mercury__dnf__transform_goal_10_0_i18);
Declare_label(mercury__dnf__transform_goal_10_0_i19);
Declare_label(mercury__dnf__transform_goal_10_0_i1014);
Declare_label(mercury__dnf__transform_goal_10_0_i20);
Declare_label(mercury__dnf__transform_goal_10_0_i21);
Declare_label(mercury__dnf__transform_goal_10_0_i23);
Declare_static(mercury__dnf__transform_disj_11_0);
Declare_label(mercury__dnf__transform_disj_11_0_i4);
Declare_label(mercury__dnf__transform_disj_11_0_i5);
Declare_label(mercury__dnf__transform_disj_11_0_i6);
Declare_label(mercury__dnf__transform_disj_11_0_i7);
Declare_label(mercury__dnf__transform_disj_11_0_i3);
Declare_static(mercury__dnf__transform_switch_11_0);
Declare_label(mercury__dnf__transform_switch_11_0_i4);
Declare_label(mercury__dnf__transform_switch_11_0_i5);
Declare_label(mercury__dnf__transform_switch_11_0_i6);
Declare_label(mercury__dnf__transform_switch_11_0_i7);
Declare_label(mercury__dnf__transform_switch_11_0_i3);
Declare_static(mercury__dnf__transform_ite_15_0);
Declare_label(mercury__dnf__transform_ite_15_0_i2);
Declare_label(mercury__dnf__transform_ite_15_0_i3);
Declare_label(mercury__dnf__transform_ite_15_0_i4);
Declare_label(mercury__dnf__transform_ite_15_0_i5);
Declare_label(mercury__dnf__transform_ite_15_0_i6);
Declare_label(mercury__dnf__transform_ite_15_0_i7);
Declare_label(mercury__dnf__transform_ite_15_0_i8);
Declare_label(mercury__dnf__transform_ite_15_0_i9);
Declare_label(mercury__dnf__transform_ite_15_0_i10);
Declare_static(mercury__dnf__transform_conj_12_0);
Declare_label(mercury__dnf__transform_conj_12_0_i4);
Declare_label(mercury__dnf__transform_conj_12_0_i5);
Declare_label(mercury__dnf__transform_conj_12_0_i6);
Declare_label(mercury__dnf__transform_conj_12_0_i7);
Declare_label(mercury__dnf__transform_conj_12_0_i3);
Declare_static(mercury__dnf__make_goal_literal_14_0);
Declare_label(mercury__dnf__make_goal_literal_14_0_i9);
Declare_label(mercury__dnf__make_goal_literal_14_0_i8);
Declare_label(mercury__dnf__make_goal_literal_14_0_i11);
Declare_label(mercury__dnf__make_goal_literal_14_0_i4);
Declare_label(mercury__dnf__make_goal_literal_14_0_i15);
Declare_label(mercury__dnf__make_goal_literal_14_0_i14);
Declare_label(mercury__dnf__make_goal_literal_14_0_i17);
Declare_label(mercury__dnf__make_goal_literal_14_0_i2);
Declare_label(mercury__dnf__make_goal_literal_14_0_i3);
Declare_label(mercury__dnf__make_goal_literal_14_0_i20);
Declare_label(mercury__dnf__make_goal_literal_14_0_i21);
Declare_label(mercury__dnf__make_goal_literal_14_0_i22);
Declare_label(mercury__dnf__make_goal_literal_14_0_i23);
Declare_label(mercury__dnf__make_goal_literal_14_0_i24);
Declare_static(mercury__dnf__get_new_pred_name_5_0);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i1001);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i2);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i3);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i6);
Declare_label(mercury__dnf__get_new_pred_name_5_0_i4);
Declare_static(mercury__dnf__is_atomic_expr_5_0);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i4);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i6);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i11);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i1003);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i16);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i20);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i25);
Declare_label(mercury__dnf__is_atomic_expr_5_0_i33);
Declare_static(mercury__dnf__free_of_nonatomic_2_0);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i1035);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i46);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i41);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i4);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i5);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i8);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i13);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i1024);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i15);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i16);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i18);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i21);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i24);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i27);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i28);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i30);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i31);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i33);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i38);
Declare_label(mercury__dnf__free_of_nonatomic_2_0_i1);
Declare_static(mercury__dnf__goals_free_of_nonatomic_2_0);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1002);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i2);
Declare_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
Declare_static(mercury__dnf__cases_free_of_nonatomic_2_0);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1002);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i2);
Declare_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
Declare_static(mercury____Unify___dnf__dnf_info_0_0);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i2);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i4);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i6);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i8);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i10);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i12);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i14);
Declare_label(mercury____Unify___dnf__dnf_info_0_0_i1);
Declare_static(mercury____Index___dnf__dnf_info_0_0);
Declare_static(mercury____Compare___dnf__dnf_info_0_0);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i3);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i7);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i11);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i15);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i19);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i23);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i27);
Declare_label(mercury____Compare___dnf__dnf_info_0_0_i37);

const struct MR_TypeCtorInfo_struct mercury_data_dnf__type_ctor_info_dnf_info_0;

static const struct mercury_data_dnf__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dnf__common_0;

static const struct mercury_data_dnf__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dnf__common_1;

static const struct mercury_data_dnf__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dnf__common_2;

static const struct mercury_data_dnf__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dnf__common_3;

static const struct mercury_data_dnf__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dnf__common_4;

static const struct mercury_data_dnf__common_5_struct {
	Word * f1;
}  mercury_data_dnf__common_5;

static const struct mercury_data_dnf__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_dnf__common_6;

static const struct mercury_data_dnf__common_7_struct {
	Word * f1;
}  mercury_data_dnf__common_7;

static const struct mercury_data_dnf__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dnf__common_8;

static const struct mercury_data_dnf__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_dnf__common_9;

static const struct mercury_data_dnf__common_10_struct {
	Word * f1;
}  mercury_data_dnf__common_10;

static const struct mercury_data_dnf__common_11_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	String f10;
	Word * f11;
	Integer f12;
	Integer f13;
}  mercury_data_dnf__common_11;

static const struct mercury_data_dnf__type_ctor_functors_dnf_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_dnf__type_ctor_functors_dnf_info_0;

static const struct mercury_data_dnf__type_ctor_layout_dnf_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_dnf__type_ctor_layout_dnf_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_dnf__type_ctor_info_dnf_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___dnf__dnf_info_0_0),
	STATIC(mercury____Index___dnf__dnf_info_0_0),
	STATIC(mercury____Compare___dnf__dnf_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_dnf__type_ctor_functors_dnf_info_0,
	(Word *) &mercury_data_dnf__type_ctor_layout_dnf_info_0,
	MR_string_const("dnf", 3),
	MR_string_const("dnf_info", 8),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_dnf__common_0_struct mercury_data_dnf__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_dnf__common_1_struct mercury_data_dnf__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_dnf__common_2_struct mercury_data_dnf__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_dnf__common_3_struct mercury_data_dnf__common_3 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_dnf__common_4_struct mercury_data_dnf__common_4 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraints_0;
static const struct mercury_data_dnf__common_5_struct mercury_data_dnf__common_5 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraints_0
};

static const struct mercury_data_dnf__common_6_struct mercury_data_dnf__common_6 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_markers_0;
static const struct mercury_data_dnf__common_7_struct mercury_data_dnf__common_7 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_markers_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
static const struct mercury_data_dnf__common_8_struct mercury_data_dnf__common_8 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_2),
	(Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;
static const struct mercury_data_dnf__common_9_struct mercury_data_dnf__common_9 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_dnf__common_10_struct mercury_data_dnf__common_10 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_dnf__common_11_struct mercury_data_dnf__common_11 = {
	(Integer) 8,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_10),
	MR_string_const("dnf_info", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_dnf__type_ctor_functors_dnf_info_0_struct mercury_data_dnf__type_ctor_functors_dnf_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_11)
};

static const struct mercury_data_dnf__type_ctor_layout_dnf_info_0_struct mercury_data_dnf__type_ctor_layout_dnf_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_dnf__common_11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(dnf_module0)
	init_entry(mercury____Index___dnf__dnf_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___dnf__dnf_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___dnf__dnf_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__hlds_module__module_info_clobber_dependency_info_2_0);

BEGIN_MODULE(dnf_module1)
	init_entry(mercury__dnf__transform_module_4_0);
	init_label(mercury__dnf__transform_module_4_0_i2);
	init_label(mercury__dnf__transform_module_4_0_i3);
BEGIN_CODE

/* code for predicate 'transform_module'/4 in mode 0 */
Define_entry(mercury__dnf__transform_module_4_0);
	MR_incr_sp_push_msg(4, "dnf:transform_module/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__dnf__transform_module_4_0_i2,
		ENTRY(mercury__dnf__transform_module_4_0));
Define_label(mercury__dnf__transform_module_4_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_module_4_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__dnf__transform_preds_5_0),
		mercury__dnf__transform_module_4_0_i3,
		ENTRY(mercury__dnf__transform_module_4_0));
Define_label(mercury__dnf__transform_module_4_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__transform_module_4_0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__hlds_module__module_info_clobber_dependency_info_2_0),
		ENTRY(mercury__dnf__transform_module_4_0));
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_markers_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_class_context_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_aditi_owner_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0);
Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);

BEGIN_MODULE(dnf_module2)
	init_entry(mercury__dnf__transform_proc_8_0);
	init_label(mercury__dnf__transform_proc_8_0_i2);
	init_label(mercury__dnf__transform_proc_8_0_i3);
	init_label(mercury__dnf__transform_proc_8_0_i4);
	init_label(mercury__dnf__transform_proc_8_0_i5);
	init_label(mercury__dnf__transform_proc_8_0_i6);
	init_label(mercury__dnf__transform_proc_8_0_i7);
	init_label(mercury__dnf__transform_proc_8_0_i8);
	init_label(mercury__dnf__transform_proc_8_0_i9);
	init_label(mercury__dnf__transform_proc_8_0_i10);
	init_label(mercury__dnf__transform_proc_8_0_i11);
	init_label(mercury__dnf__transform_proc_8_0_i12);
	init_label(mercury__dnf__transform_proc_8_0_i13);
	init_label(mercury__dnf__transform_proc_8_0_i14);
BEGIN_CODE

/* code for predicate 'transform_proc'/8 in mode 0 */
Define_entry(mercury__dnf__transform_proc_8_0);
	MR_incr_sp_push_msg(14, "dnf:transform_proc/8");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__dnf__transform_proc_8_0_i2,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__dnf__transform_proc_8_0_i3,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__dnf__transform_proc_8_0_i4,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_class_context_2_0),
		mercury__dnf__transform_proc_8_0_i5,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_aditi_owner_2_0),
		mercury__dnf__transform_proc_8_0_i6,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__dnf__transform_proc_8_0_i7,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__dnf__transform_proc_8_0_i8,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__dnf__transform_proc_8_0_i9,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0),
		mercury__dnf__transform_proc_8_0_i10,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0),
		mercury__dnf__transform_proc_8_0_i11,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 8, mercury__dnf__transform_proc_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 6) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__dnf__transform_proc_8_0_i12,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i12);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(10);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(5);
	call_localret(STATIC(mercury__dnf__transform_goal_10_0),
		mercury__dnf__transform_proc_8_0_i13,
		ENTRY(mercury__dnf__transform_proc_8_0));
Define_label(mercury__dnf__transform_proc_8_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__dnf__transform_proc_8_0_i14,
		ENTRY(mercury__dnf__transform_proc_8_0));
	}
Define_label(mercury__dnf__transform_proc_8_0_i14);
	update_prof_current_proc(LABEL(mercury__dnf__transform_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__check_marker_2_0);
Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(dnf_module3)
	init_entry(mercury__dnf__transform_preds_5_0);
	init_label(mercury__dnf__transform_preds_5_0_i1004);
	init_label(mercury__dnf__transform_preds_5_0_i7);
	init_label(mercury__dnf__transform_preds_5_0_i9);
	init_label(mercury__dnf__transform_preds_5_0_i10);
	init_label(mercury__dnf__transform_preds_5_0_i11);
	init_label(mercury__dnf__transform_preds_5_0_i14);
	init_label(mercury__dnf__transform_preds_5_0_i13);
	init_label(mercury__dnf__transform_preds_5_0_i16);
	init_label(mercury__dnf__transform_preds_5_0_i6);
	init_label(mercury__dnf__transform_preds_5_0_i18);
	init_label(mercury__dnf__transform_preds_5_0_i19);
	init_label(mercury__dnf__transform_preds_5_0_i20);
	init_label(mercury__dnf__transform_preds_5_0_i21);
	init_label(mercury__dnf__transform_preds_5_0_i22);
	init_label(mercury__dnf__transform_preds_5_0_i4);
	init_label(mercury__dnf__transform_preds_5_0_i3);
BEGIN_CODE

/* code for predicate 'transform_preds'/5 in mode 0 */
Define_static(mercury__dnf__transform_preds_5_0);
	MR_incr_sp_push_msg(7, "dnf:transform_preds/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__dnf__transform_preds_5_0_i1004);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i3);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i7);
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	GOTO_LABEL(mercury__dnf__transform_preds_5_0_i6);
Define_label(mercury__dnf__transform_preds_5_0_i7);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	r1 = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_preds_5_0_i9,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dnf__transform_preds_5_0_i10,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__dnf__transform_preds_5_0_i11,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	MR_stackvar(6) = r1;
	r2 = (Integer) 5;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__dnf__transform_preds_5_0_i14,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i14);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i13);
	r1 = MR_stackvar(3);
	GOTO_LABEL(mercury__dnf__transform_preds_5_0_i6);
Define_label(mercury__dnf__transform_preds_5_0_i13);
	r1 = MR_stackvar(6);
	r2 = (Integer) 6;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__dnf__transform_preds_5_0_i16,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i16);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__transform_preds_5_0_i4);
	r1 = MR_stackvar(3);
Define_label(mercury__dnf__transform_preds_5_0_i6);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_preds_5_0_i18,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i18);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dnf__transform_preds_5_0_i19,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i19);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__dnf__transform_preds_5_0_i20,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i20);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__dnf__transform_procs_7_0),
		mercury__dnf__transform_preds_5_0_i21,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i21);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__dnf__transform_preds_5_0_i22,
		STATIC(mercury__dnf__transform_preds_5_0));
Define_label(mercury__dnf__transform_preds_5_0_i22);
	update_prof_current_proc(LABEL(mercury__dnf__transform_preds_5_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__dnf__transform_preds_5_0_i1004);
Define_label(mercury__dnf__transform_preds_5_0_i4);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__dnf__transform_preds_5_0_i1004);
Define_label(mercury__dnf__transform_preds_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(dnf_module4)
	init_entry(mercury__dnf__transform_procs_7_0);
	init_label(mercury__dnf__transform_procs_7_0_i1001);
	init_label(mercury__dnf__transform_procs_7_0_i4);
	init_label(mercury__dnf__transform_procs_7_0_i5);
	init_label(mercury__dnf__transform_procs_7_0_i6);
	init_label(mercury__dnf__transform_procs_7_0_i7);
	init_label(mercury__dnf__transform_procs_7_0_i8);
	init_label(mercury__dnf__transform_procs_7_0_i9);
	init_label(mercury__dnf__transform_procs_7_0_i10);
	init_label(mercury__dnf__transform_procs_7_0_i11);
	init_label(mercury__dnf__transform_procs_7_0_i12);
	init_label(mercury__dnf__transform_procs_7_0_i13);
	init_label(mercury__dnf__transform_procs_7_0_i3);
BEGIN_CODE

/* code for predicate 'transform_procs'/7 in mode 0 */
Define_static(mercury__dnf__transform_procs_7_0);
	MR_incr_sp_push_msg(9, "dnf:transform_procs/7");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__dnf__transform_procs_7_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_procs_7_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_procs_7_0_i4,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dnf__transform_procs_7_0_i5,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__dnf__transform_procs_7_0_i6,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__dnf__transform_procs_7_0_i7,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(STATIC(mercury__dnf__transform_proc_8_0),
		mercury__dnf__transform_procs_7_0_i8,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r5 = r2;
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r3;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dnf__transform_procs_7_0_i9,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__dnf__transform_procs_7_0_i10,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__dnf__transform_procs_7_0_i11,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__dnf__transform_procs_7_0_i12,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i12);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__dnf__transform_procs_7_0_i13,
		STATIC(mercury__dnf__transform_procs_7_0));
Define_label(mercury__dnf__transform_procs_7_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__transform_procs_7_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__dnf__transform_procs_7_0_i1001);
Define_label(mercury__dnf__transform_procs_7_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(dnf_module5)
	init_entry(mercury__dnf__transform_goal_10_0);
	init_label(mercury__dnf__transform_goal_10_0_i4);
	init_label(mercury__dnf__transform_goal_10_0_i5);
	init_label(mercury__dnf__transform_goal_10_0_i8);
	init_label(mercury__dnf__transform_goal_10_0_i9);
	init_label(mercury__dnf__transform_goal_10_0_i10);
	init_label(mercury__dnf__transform_goal_10_0_i12);
	init_label(mercury__dnf__transform_goal_10_0_i13);
	init_label(mercury__dnf__transform_goal_10_0_i14);
	init_label(mercury__dnf__transform_goal_10_0_i1020);
	init_label(mercury__dnf__transform_goal_10_0_i16);
	init_label(mercury__dnf__transform_goal_10_0_i1022);
	init_label(mercury__dnf__transform_goal_10_0_i18);
	init_label(mercury__dnf__transform_goal_10_0_i19);
	init_label(mercury__dnf__transform_goal_10_0_i1014);
	init_label(mercury__dnf__transform_goal_10_0_i20);
	init_label(mercury__dnf__transform_goal_10_0_i21);
	init_label(mercury__dnf__transform_goal_10_0_i23);
BEGIN_CODE

/* code for predicate 'transform_goal'/10 in mode 0 */
Define_static(mercury__dnf__transform_goal_10_0);
	MR_incr_sp_push_msg(5, "dnf:transform_goal/10");
	MR_stackvar(5) = (Word) MR_succip;
	r8 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r8),
		LABEL(mercury__dnf__transform_goal_10_0_i4) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1014) AND
		LABEL(mercury__dnf__transform_goal_10_0_i1014) AND
		LABEL(mercury__dnf__transform_goal_10_0_i8));
Define_label(mercury__dnf__transform_goal_10_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r8, (Integer) 0);
	r8 = r7;
	r7 = r6;
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_goal_10_0_i5,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	r3 = r4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r8, (Integer) 0),
		LABEL(mercury__dnf__transform_goal_10_0_i9) AND
		LABEL(mercury__dnf__transform_goal_10_0_i20) AND
		LABEL(mercury__dnf__transform_goal_10_0_i12) AND
		LABEL(mercury__dnf__transform_goal_10_0_i14) AND
		LABEL(mercury__dnf__transform_goal_10_0_i16) AND
		LABEL(mercury__dnf__transform_goal_10_0_i18) AND
		LABEL(mercury__dnf__transform_goal_10_0_i20) AND
		LABEL(mercury__dnf__transform_goal_10_0_i21) AND
		LABEL(mercury__dnf__transform_goal_10_0_i23));
Define_label(mercury__dnf__transform_goal_10_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r8, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r8, (Integer) 4);
	r8 = r7;
	r7 = r6;
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__transform_switch_11_0),
		mercury__dnf__transform_goal_10_0_i10,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i12);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	r8 = r7;
	r7 = r6;
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__transform_disj_11_0),
		mercury__dnf__transform_goal_10_0_i13,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i14);
	r10 = r7;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	r7 = r5;
	r9 = r6;
	r5 = (Integer) 1;
	r6 = (Integer) 0;
	r8 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__make_goal_literal_14_0),
		mercury__dnf__transform_goal_10_0_i1020,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i1020);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i16);
	r10 = r7;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r8, (Integer) 3);
	r7 = r5;
	r9 = r6;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	r5 = (Integer) 0;
	r6 = (Integer) 1;
	r8 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__make_goal_literal_14_0),
		mercury__dnf__transform_goal_10_0_i1022,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i1022);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i18);
	r9 = r6;
	r10 = r7;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r6 = r4;
	r7 = r5;
	r4 = r2;
	r5 = r3;
	r1 = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), r8, (Integer) 3);
	r3 = MR_const_field(MR_mktag(3), r8, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r8, (Integer) 5);
	r8 = (Integer) 0;
	call_localret(STATIC(mercury__dnf__transform_ite_15_0),
		mercury__dnf__transform_goal_10_0_i19,
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i19);
	update_prof_current_proc(LABEL(mercury__dnf__transform_goal_10_0));
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__transform_goal_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__dnf__transform_goal_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r3 = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__dnf__transform_goal_10_0_i1014);
	r2 = r1;
	r1 = r4;
	r3 = r7;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dnf__transform_goal_10_0_i20);
	r2 = r1;
	r1 = r4;
	r3 = r7;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dnf__transform_goal_10_0_i21);
	r1 = (Word) MR_string_const("sorry, dnf of parallel conjunction not implemented", 50);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__dnf__transform_goal_10_0));
Define_label(mercury__dnf__transform_goal_10_0_i23);
	r1 = (Word) MR_string_const("dnf__transform_goal: unexpected bi_implication", 46);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__dnf__transform_goal_10_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_to_conj_list_2_0);
Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);

BEGIN_MODULE(dnf_module6)
	init_entry(mercury__dnf__transform_disj_11_0);
	init_label(mercury__dnf__transform_disj_11_0_i4);
	init_label(mercury__dnf__transform_disj_11_0_i5);
	init_label(mercury__dnf__transform_disj_11_0_i6);
	init_label(mercury__dnf__transform_disj_11_0_i7);
	init_label(mercury__dnf__transform_disj_11_0_i3);
BEGIN_CODE

/* code for predicate 'transform_disj'/11 in mode 0 */
Define_static(mercury__dnf__transform_disj_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_disj_11_0_i3);
	MR_incr_sp_push_msg(10, "dnf:transform_disj/11");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_disj_11_0_i4,
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_disj_11_0_i5,
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	MR_stackvar(3) = r1;
	MR_stackvar(5) = r2;
	r1 = r3;
	r2 = MR_stackvar(9);
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_disj_11_0_i6,
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	localcall(mercury__dnf__transform_disj_11_0,
		LABEL(mercury__dnf__transform_disj_11_0_i7),
		STATIC(mercury__dnf__transform_disj_11_0));
Define_label(mercury__dnf__transform_disj_11_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_disj_11_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__dnf__transform_disj_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__dnf__transform_disj_11_0_i3);
	r1 = r4;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r8;
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module7)
	init_entry(mercury__dnf__transform_switch_11_0);
	init_label(mercury__dnf__transform_switch_11_0_i4);
	init_label(mercury__dnf__transform_switch_11_0_i5);
	init_label(mercury__dnf__transform_switch_11_0_i6);
	init_label(mercury__dnf__transform_switch_11_0_i7);
	init_label(mercury__dnf__transform_switch_11_0_i3);
BEGIN_CODE

/* code for predicate 'transform_switch'/11 in mode 0 */
Define_static(mercury__dnf__transform_switch_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_switch_11_0_i3);
	MR_incr_sp_push_msg(11, "dnf:transform_switch/11");
	MR_stackvar(11) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(10) = r1;
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_switch_11_0_i4,
		STATIC(mercury__dnf__transform_switch_11_0));
	}
Define_label(mercury__dnf__transform_switch_11_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_switch_11_0_i5,
		STATIC(mercury__dnf__transform_switch_11_0));
Define_label(mercury__dnf__transform_switch_11_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	MR_stackvar(3) = r1;
	MR_stackvar(5) = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(10), (Integer) 1);
	r1 = r3;
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_switch_11_0_i6,
		STATIC(mercury__dnf__transform_switch_11_0));
Define_label(mercury__dnf__transform_switch_11_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__dnf__transform_switch_11_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	localcall(mercury__dnf__transform_switch_11_0,
		LABEL(mercury__dnf__transform_switch_11_0_i7),
		STATIC(mercury__dnf__transform_switch_11_0));
	}
Define_label(mercury__dnf__transform_switch_11_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_switch_11_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__dnf__transform_switch_11_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__dnf__transform_switch_11_0_i3);
	r1 = r4;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r8;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);

BEGIN_MODULE(dnf_module8)
	init_entry(mercury__dnf__transform_ite_15_0);
	init_label(mercury__dnf__transform_ite_15_0_i2);
	init_label(mercury__dnf__transform_ite_15_0_i3);
	init_label(mercury__dnf__transform_ite_15_0_i4);
	init_label(mercury__dnf__transform_ite_15_0_i5);
	init_label(mercury__dnf__transform_ite_15_0_i6);
	init_label(mercury__dnf__transform_ite_15_0_i7);
	init_label(mercury__dnf__transform_ite_15_0_i8);
	init_label(mercury__dnf__transform_ite_15_0_i9);
	init_label(mercury__dnf__transform_ite_15_0_i10);
BEGIN_CODE

/* code for predicate 'transform_ite'/15 in mode 0 */
Define_static(mercury__dnf__transform_ite_15_0);
	MR_incr_sp_push_msg(12, "dnf:transform_ite/15");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r2 = r4;
	MR_stackvar(3) = r4;
	r3 = r5;
	r4 = r6;
	MR_stackvar(4) = r5;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r5 = (Integer) 1;
	r6 = (Integer) 0;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r9;
	call_localret(STATIC(mercury__dnf__make_goal_literal_14_0),
		mercury__dnf__transform_ite_15_0_i2,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	MR_stackvar(9) = r2;
	MR_stackvar(10) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__dnf__transform_ite_15_0_i3,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__dnf__transform_ite_15_0_i4,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = MR_stackvar(1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_ite_15_0_i5,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(9);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(10);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_ite_15_0_i6,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	MR_stackvar(1) = r1;
	MR_stackvar(8) = r2;
	r1 = r3;
	r2 = MR_stackvar(11);
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_ite_15_0_i7,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = MR_stackvar(2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_to_conj_list_2_0),
		mercury__dnf__transform_ite_15_0_i8,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i8);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(9);
	call_localret(STATIC(mercury__dnf__transform_conj_12_0),
		mercury__dnf__transform_ite_15_0_i9,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	MR_stackvar(1) = r1;
	r1 = r3;
	r2 = MR_stackvar(10);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__dnf__transform_ite_15_0_i10,
		STATIC(mercury__dnf__transform_ite_15_0));
Define_label(mercury__dnf__transform_ite_15_0_i10);
	update_prof_current_proc(LABEL(mercury__dnf__transform_ite_15_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module9)
	init_entry(mercury__dnf__transform_conj_12_0);
	init_label(mercury__dnf__transform_conj_12_0_i4);
	init_label(mercury__dnf__transform_conj_12_0_i5);
	init_label(mercury__dnf__transform_conj_12_0_i6);
	init_label(mercury__dnf__transform_conj_12_0_i7);
	init_label(mercury__dnf__transform_conj_12_0_i3);
BEGIN_CODE

/* code for predicate 'transform_conj'/12 in mode 0 */
Define_static(mercury__dnf__transform_conj_12_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__transform_conj_12_0_i3);
	MR_incr_sp_push_msg(10, "dnf:transform_conj/12");
	MR_stackvar(10) = (Word) MR_succip;
	r9 = r7;
	MR_stackvar(4) = r7;
	r10 = r8;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r7 = r5;
	r8 = r6;
	MR_stackvar(3) = r5;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r1;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__dnf__make_goal_literal_14_0),
		mercury__dnf__transform_conj_12_0_i4,
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	MR_stackvar(7) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(5), (Integer) 1);
	MR_stackvar(5) = r3;
	MR_stackvar(8) = r2;
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__dnf__transform_conj_12_0_i5,
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i5);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__dnf__transform_conj_12_0_i6,
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(4);
	r8 = MR_stackvar(9);
	localcall(mercury__dnf__transform_conj_12_0,
		LABEL(mercury__dnf__transform_conj_12_0_i7),
		STATIC(mercury__dnf__transform_conj_12_0));
Define_label(mercury__dnf__transform_conj_12_0_i7);
	update_prof_current_proc(LABEL(mercury__dnf__transform_conj_12_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__dnf__transform_conj_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	r3 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__dnf__transform_conj_12_0_i3);
	r1 = r4;
	r2 = r6;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r8;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__hlds_pred__define_new_pred_18_0);

BEGIN_MODULE(dnf_module10)
	init_entry(mercury__dnf__make_goal_literal_14_0);
	init_label(mercury__dnf__make_goal_literal_14_0_i9);
	init_label(mercury__dnf__make_goal_literal_14_0_i8);
	init_label(mercury__dnf__make_goal_literal_14_0_i11);
	init_label(mercury__dnf__make_goal_literal_14_0_i4);
	init_label(mercury__dnf__make_goal_literal_14_0_i15);
	init_label(mercury__dnf__make_goal_literal_14_0_i14);
	init_label(mercury__dnf__make_goal_literal_14_0_i17);
	init_label(mercury__dnf__make_goal_literal_14_0_i2);
	init_label(mercury__dnf__make_goal_literal_14_0_i3);
	init_label(mercury__dnf__make_goal_literal_14_0_i20);
	init_label(mercury__dnf__make_goal_literal_14_0_i21);
	init_label(mercury__dnf__make_goal_literal_14_0_i22);
	init_label(mercury__dnf__make_goal_literal_14_0_i23);
	init_label(mercury__dnf__make_goal_literal_14_0_i24);
BEGIN_CODE

/* code for predicate 'make_goal_literal'/14 in mode 0 */
Define_static(mercury__dnf__make_goal_literal_14_0);
	MR_incr_sp_push_msg(15, "dnf:make_goal_literal/14");
	MR_stackvar(15) = (Word) MR_succip;
	r11 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r11) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r11, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i4);
	if (((Integer) r5 != (Integer) 0))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i3);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r11, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = (Integer) 1;
	r3 = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r10;
	MR_stackvar(9) = MR_tempr1;
	call_localret(STATIC(mercury__dnf__is_atomic_expr_5_0),
		mercury__dnf__make_goal_literal_14_0_i9,
		STATIC(mercury__dnf__make_goal_literal_14_0));
	}
Define_label(mercury__dnf__make_goal_literal_14_0_i9);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i8);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__dnf__make_goal_literal_14_0_i8);
	r3 = MR_stackvar(3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i2);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(9);
	call_localret(STATIC(mercury__dnf__free_of_nonatomic_2_0),
		mercury__dnf__make_goal_literal_14_0_i11,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i2);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__dnf__make_goal_literal_14_0_i4);
	MR_stackvar(4) = r4;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r2 = r5;
	r3 = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r10;
	call_localret(STATIC(mercury__dnf__is_atomic_expr_5_0),
		mercury__dnf__make_goal_literal_14_0_i15,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i15);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i14);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__dnf__make_goal_literal_14_0_i14);
	r3 = MR_stackvar(3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i2);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__dnf__free_of_nonatomic_2_0),
		mercury__dnf__make_goal_literal_14_0_i17,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i17);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__make_goal_literal_14_0_i2);
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__dnf__make_goal_literal_14_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(8);
Define_label(mercury__dnf__make_goal_literal_14_0_i3);
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r10;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__dnf__make_goal_literal_14_0_i20,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i20);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__dnf__get_new_pred_name_5_0),
		mercury__dnf__make_goal_literal_14_0_i21,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i21);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	r3 = MR_stackvar(7);
	MR_stackvar(5) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__dnf__make_goal_literal_14_0_i22,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i22);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__dnf__make_goal_literal_14_0_i23,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i23);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(9);
	r8 = MR_stackvar(12);
	r9 = MR_stackvar(13);
	r10 = MR_stackvar(10);
	r11 = MR_stackvar(11);
	r12 = MR_stackvar(14);
	r13 = (Integer) 1;
	r14 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__define_new_pred_18_0),
		mercury__dnf__make_goal_literal_14_0_i24,
		STATIC(mercury__dnf__make_goal_literal_14_0));
Define_label(mercury__dnf__make_goal_literal_14_0_i24);
	update_prof_current_proc(LABEL(mercury__dnf__make_goal_literal_14_0));
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__dnf__make_goal_literal_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_tempr2 = r1;
	r1 = r3;
	r3 = MR_tempr2;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__hlds_module__predicate_table_search_name_3_0);

BEGIN_MODULE(dnf_module11)
	init_entry(mercury__dnf__get_new_pred_name_5_0);
	init_label(mercury__dnf__get_new_pred_name_5_0_i1001);
	init_label(mercury__dnf__get_new_pred_name_5_0_i2);
	init_label(mercury__dnf__get_new_pred_name_5_0_i3);
	init_label(mercury__dnf__get_new_pred_name_5_0_i6);
	init_label(mercury__dnf__get_new_pred_name_5_0_i4);
BEGIN_CODE

/* code for predicate 'get_new_pred_name'/5 in mode 0 */
Define_static(mercury__dnf__get_new_pred_name_5_0);
	MR_incr_sp_push_msg(5, "dnf:get_new_pred_name/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__dnf__get_new_pred_name_5_0_i1001);
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__dnf__get_new_pred_name_5_0_i2,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
Define_label(mercury__dnf__get_new_pred_name_5_0_i2);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__dnf__get_new_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__dnf__get_new_pred_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("__part_", 7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__dnf__get_new_pred_name_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__dnf__get_new_pred_name_5_0_i3,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
	}
Define_label(mercury__dnf__get_new_pred_name_5_0_i3);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	MR_stackvar(4) = ((Integer) MR_stackvar(3) + (Integer) 1);
	r2 = r1;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_name_3_0),
		mercury__dnf__get_new_pred_name_5_0_i6,
		STATIC(mercury__dnf__get_new_pred_name_5_0));
Define_label(mercury__dnf__get_new_pred_name_5_0_i6);
	update_prof_current_proc(LABEL(mercury__dnf__get_new_pred_name_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__get_new_pred_name_5_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__dnf__get_new_pred_name_5_0_i1001);
Define_label(mercury__dnf__get_new_pred_name_5_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module12)
	init_entry(mercury__dnf__is_atomic_expr_5_0);
	init_label(mercury__dnf__is_atomic_expr_5_0_i4);
	init_label(mercury__dnf__is_atomic_expr_5_0_i6);
	init_label(mercury__dnf__is_atomic_expr_5_0_i11);
	init_label(mercury__dnf__is_atomic_expr_5_0_i1003);
	init_label(mercury__dnf__is_atomic_expr_5_0_i16);
	init_label(mercury__dnf__is_atomic_expr_5_0_i20);
	init_label(mercury__dnf__is_atomic_expr_5_0_i25);
	init_label(mercury__dnf__is_atomic_expr_5_0_i33);
BEGIN_CODE

/* code for predicate 'is_atomic_expr'/5 in mode 0 */
Define_static(mercury__dnf__is_atomic_expr_5_0);
	MR_incr_sp_push_msg(1, "dnf:is_atomic_expr/5");
	MR_stackvar(1) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__dnf__is_atomic_expr_5_0_i4) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i16));
Define_label(mercury__dnf__is_atomic_expr_5_0_i4);
	if (((Integer) MR_const_field(MR_mktag(0), r4, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i6);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_5_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	if ((MR_tag(MR_const_field(MR_mktag(0), r3, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i33);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i33);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	call_localret(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		mercury__dnf__is_atomic_expr_5_0_i11,
		STATIC(mercury__dnf__is_atomic_expr_5_0));
	}
Define_label(mercury__dnf__is_atomic_expr_5_0_i11);
	update_prof_current_proc(LABEL(mercury__dnf__is_atomic_expr_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i33);
Define_label(mercury__dnf__is_atomic_expr_5_0_i1003);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__dnf__is_atomic_expr_5_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r4, (Integer) 0),
		LABEL(mercury__dnf__is_atomic_expr_5_0_i33) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i33) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i20) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i25) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i33) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i33) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i33));
Define_label(mercury__dnf__is_atomic_expr_5_0_i20);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i33);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r4, (Integer) 1), (Integer) 0);
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__dnf__is_atomic_expr_5_0_i4) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i16));
Define_label(mercury__dnf__is_atomic_expr_5_0_i25);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__dnf__is_atomic_expr_5_0_i33);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r4, (Integer) 3), (Integer) 0);
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__dnf__is_atomic_expr_5_0_i4) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i1003) AND
		LABEL(mercury__dnf__is_atomic_expr_5_0_i16));
Define_label(mercury__dnf__is_atomic_expr_5_0_i33);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);

BEGIN_MODULE(dnf_module13)
	init_entry(mercury__dnf__free_of_nonatomic_2_0);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i1035);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i46);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i41);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i4);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i5);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i8);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i13);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i1024);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i15);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i16);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i18);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i21);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i24);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i27);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i28);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i30);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i31);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i33);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i38);
	init_label(mercury__dnf__free_of_nonatomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__free_of_nonatomic_2_0);
	MR_incr_sp_push_msg(5, "dnf:free_of_nonatomic/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__dnf__free_of_nonatomic_2_0_i1035);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i4);
	if ((MR_tag(r3) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i41);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__dnf__free_of_nonatomic_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = r2;
	r2 = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dnf__free_of_nonatomic_2_0_i46,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
	}
Define_label(mercury__dnf__free_of_nonatomic_2_0_i46);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (r1)
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dnf__free_of_nonatomic_2_0_i41);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r3, (Integer) 0),
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i5) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i8) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i15) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i21) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i24) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i27) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i1024) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i38) AND
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i1));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i5);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dnf__cases_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i8);
	if ((MR_tag(MR_const_field(MR_mktag(3), r3, (Integer) 4)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1024);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r3, (Integer) 4), (Integer) 1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1024);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r3, (Integer) 4), (Integer) 1), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1024);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__dnf__free_of_nonatomic_2_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r3, (Integer) 4), (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r3 = r4;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__dnf__free_of_nonatomic_2_0_i13,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
	}
Define_label(mercury__dnf__free_of_nonatomic_2_0_i13);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (r1)
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
Define_label(mercury__dnf__free_of_nonatomic_2_0_i1024);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__dnf__free_of_nonatomic_2_0_i15);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__dnf__free_of_nonatomic_2_0_i16,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i16);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__dnf__free_of_nonatomic_2_0_i18,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i18);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (((Integer) 3 == (Integer) r2))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i21);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1035);
Define_label(mercury__dnf__free_of_nonatomic_2_0_i24);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1035);
Define_label(mercury__dnf__free_of_nonatomic_2_0_i27);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__dnf__free_of_nonatomic_2_0_i28,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i28);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__dnf__free_of_nonatomic_2_0_i30,
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i30);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (((Integer) 3 == (Integer) r2))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	localcall(mercury__dnf__free_of_nonatomic_2_0,
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i31),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i31);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__dnf__free_of_nonatomic_2_0,
		LABEL(mercury__dnf__free_of_nonatomic_2_0_i33),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i33);
	update_prof_current_proc(LABEL(mercury__dnf__free_of_nonatomic_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__dnf__free_of_nonatomic_2_0_i1035);
Define_label(mercury__dnf__free_of_nonatomic_2_0_i38);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__dnf__goals_free_of_nonatomic_2_0),
		STATIC(mercury__dnf__free_of_nonatomic_2_0));
Define_label(mercury__dnf__free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module14)
	init_entry(mercury__dnf__goals_free_of_nonatomic_2_0);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1002);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i2);
	init_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'goals_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__goals_free_of_nonatomic_2_0);
	MR_incr_sp_push_msg(3, "dnf:goals_free_of_nonatomic/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__goals_free_of_nonatomic_2_0_i2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__dnf__free_of_nonatomic_2_0),
		mercury__dnf__goals_free_of_nonatomic_2_0_i4,
		STATIC(mercury__dnf__goals_free_of_nonatomic_2_0));
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__goals_free_of_nonatomic_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__dnf__goals_free_of_nonatomic_2_0_i1002);
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dnf__goals_free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module15)
	init_entry(mercury__dnf__cases_free_of_nonatomic_2_0);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1002);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i2);
	init_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'cases_free_of_nonatomic'/2 in mode 0 */
Define_static(mercury__dnf__cases_free_of_nonatomic_2_0);
	MR_incr_sp_push_msg(3, "dnf:cases_free_of_nonatomic/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__dnf__cases_free_of_nonatomic_2_0_i2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__dnf__free_of_nonatomic_2_0),
		mercury__dnf__cases_free_of_nonatomic_2_0_i4,
		STATIC(mercury__dnf__cases_free_of_nonatomic_2_0));
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i4);
	update_prof_current_proc(LABEL(mercury__dnf__cases_free_of_nonatomic_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__dnf__cases_free_of_nonatomic_2_0_i1002);
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__dnf__cases_free_of_nonatomic_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___prog_data__class_constraints_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_markers_0_0);

BEGIN_MODULE(dnf_module16)
	init_entry(mercury____Unify___dnf__dnf_info_0_0);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i2);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i4);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i6);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i8);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i10);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i12);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i14);
	init_label(mercury____Unify___dnf__dnf_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___dnf__dnf_info_0_0);
	MR_incr_sp_push_msg(15, "dnf:__Unify__/2");
	MR_stackvar(15) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___dnf__dnf_info_0_0_i2,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___dnf__dnf_info_0_0_i4,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___prog_data__class_constraints_0_0),
		mercury____Unify___dnf__dnf_info_0_0_i6,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___dnf__dnf_info_0_0_i8,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_markers_0_0),
		mercury____Unify___dnf__dnf_info_0_0_i10,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___dnf__dnf_info_0_0_i12,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___dnf__dnf_info_0_0_i14,
		STATIC(mercury____Unify___dnf__dnf_info_0_0));
Define_label(mercury____Unify___dnf__dnf_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___dnf__dnf_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	if ((strcmp((char *)MR_stackvar(7), (char *)MR_stackvar(14)) != 0))
		GOTO_LABEL(mercury____Unify___dnf__dnf_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___dnf__dnf_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(dnf_module17)
	init_entry(mercury____Index___dnf__dnf_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___dnf__dnf_info_0_0);
	tailcall(STATIC(mercury____Index___dnf__dnf_info_0__ua0_2_0),
		STATIC(mercury____Index___dnf__dnf_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___prog_data__class_constraints_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_markers_0_0);
Declare_entry(mercury__builtin_compare_string_3_0);

BEGIN_MODULE(dnf_module18)
	init_entry(mercury____Compare___dnf__dnf_info_0_0);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i3);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i7);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i11);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i15);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i19);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i23);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i27);
	init_label(mercury____Compare___dnf__dnf_info_0_0_i37);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___dnf__dnf_info_0_0);
	MR_incr_sp_push_msg(15, "dnf:__Compare__/3");
	MR_stackvar(15) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___dnf__dnf_info_0_0_i3,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___dnf__dnf_info_0_0_i7,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Compare___prog_data__class_constraints_0_0),
		mercury____Compare___dnf__dnf_info_0_0_i11,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___dnf__dnf_info_0_0_i15,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_markers_0_0),
		mercury____Compare___dnf__dnf_info_0_0_i19,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___dnf__dnf_info_0_0_i23,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_dnf__common_0);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___dnf__dnf_info_0_0_i27,
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___dnf__dnf_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___dnf__dnf_info_0_0_i37);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		STATIC(mercury____Compare___dnf__dnf_info_0_0));
Define_label(mercury____Compare___dnf__dnf_info_0_0_i37);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__dnf_maybe_bunch_0(void)
{
	dnf_module0();
	dnf_module1();
	dnf_module2();
	dnf_module3();
	dnf_module4();
	dnf_module5();
	dnf_module6();
	dnf_module7();
	dnf_module8();
	dnf_module9();
	dnf_module10();
	dnf_module11();
	dnf_module12();
	dnf_module13();
	dnf_module14();
	dnf_module15();
	dnf_module16();
	dnf_module17();
	dnf_module18();
}

#endif

void mercury__dnf__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__dnf__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__dnf_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_dnf__type_ctor_info_dnf_info_0,
			dnf__dnf_info_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
