/*
** Automatically generated from `equiv_type.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__equiv_type__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___equiv_type__eqv_type_body_0__ua0_2_0);
Define_extern_entry(mercury__equiv_type__expand_eqv_types_6_0);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i8);
Declare_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
Define_extern_entry(mercury__equiv_type__replace_in_type_5_0);
Declare_static(mercury__equiv_type__build_eqv_map_3_0);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i1003);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i7);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i8);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i4);
Declare_label(mercury__equiv_type__build_eqv_map_3_0_i3);
Declare_static(mercury__equiv_type__replace_in_item_list_5_0);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i8);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
Declare_label(mercury__equiv_type__replace_in_item_list_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_item_4_0);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i5);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i6);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i8);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i9);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i10);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i11);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i12);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i13);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i14);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i15);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i16);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i18);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i19);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i20);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i1032);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i22);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i23);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i24);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i1022);
Declare_label(mercury__equiv_type__replace_in_item_4_0_i1);
Declare_static(mercury__equiv_type__replace_in_type_defn_6_0);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i9);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i10);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i6);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i7);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i4);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i5);
Declare_label(mercury__equiv_type__replace_in_type_defn_6_0_i1010);
Declare_static(mercury__equiv_type__replace_in_class_constraints_5_0);
Declare_label(mercury__equiv_type__replace_in_class_constraints_5_0_i2);
Declare_label(mercury__equiv_type__replace_in_class_constraints_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_class_constraint_list_5_0);
Declare_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i6);
Declare_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_class_interface_3_0);
Declare_static(mercury__equiv_type__replace_in_class_method_3_0);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i4);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i5);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i6);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i7);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i8);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i9);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i10);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i11);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i14);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i13);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i15);
Declare_label(mercury__equiv_type__replace_in_class_method_3_0_i1011);
Declare_static(mercury__equiv_type__replace_in_subst_5_0);
Declare_label(mercury__equiv_type__replace_in_subst_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_subst_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_subst_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_du_5_0);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i6);
Declare_label(mercury__equiv_type__replace_in_du_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_type_list_2_8_0);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
Declare_label(mercury__equiv_type__replace_in_type_list_2_8_0_i3);
Declare_static(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
Declare_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i3);
Declare_static(mercury__equiv_type__replace_in_type_2_7_0);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i1007);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i9);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i12);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i14);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i20);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i21);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i24);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i4);
Declare_label(mercury__equiv_type__replace_in_type_2_7_0_i3);
Declare_static(mercury__equiv_type__replace_in_tms_5_0);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i6);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i5);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i7);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i8);
Declare_label(mercury__equiv_type__replace_in_tms_5_0_i3);
Declare_static(mercury__equiv_type__replace_in_tm_5_0);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i4);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i3);
Declare_label(mercury__equiv_type__replace_in_tm_5_0_i5);
Declare_static(mercury__equiv_type__report_circular_types_3_0);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i1003);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i3);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i7);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i8);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i9);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i10);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i11);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i12);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i13);
Declare_label(mercury__equiv_type__report_circular_types_3_0_i4);
Define_extern_entry(mercury____Unify___equiv_type__eqv_map_0_0);
Define_extern_entry(mercury____Index___equiv_type__eqv_map_0_0);
Define_extern_entry(mercury____Compare___equiv_type__eqv_map_0_0);
Declare_static(mercury____Unify___equiv_type__eqv_type_body_0_0);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
Declare_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
Declare_static(mercury____Index___equiv_type__eqv_type_body_0_0);
Declare_static(mercury____Compare___equiv_type__eqv_type_body_0_0);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i7);
Declare_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_equiv_type__type_ctor_info_eqv_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;

static const struct mercury_data_equiv_type__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_equiv_type__common_0;

static const struct mercury_data_equiv_type__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_equiv_type__common_1;

static const struct mercury_data_equiv_type__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_equiv_type__common_2;

static const struct mercury_data_equiv_type__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_equiv_type__common_3;

static const struct mercury_data_equiv_type__common_4_struct {
	Word * f1;
}  mercury_data_equiv_type__common_4;

static const struct mercury_data_equiv_type__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_equiv_type__common_5;

static const struct mercury_data_equiv_type__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_equiv_type__common_6;

static const struct mercury_data_equiv_type__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_equiv_type__common_7;

static const struct mercury_data_equiv_type__common_8_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_equiv_type__common_8;

static const struct mercury_data_equiv_type__common_9_struct {
	Integer f1;
	Word * f2;
}  mercury_data_equiv_type__common_9;

static const struct mercury_data_equiv_type__type_ctor_functors_eqv_type_body_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_equiv_type__type_ctor_functors_eqv_type_body_0;

static const struct mercury_data_equiv_type__type_ctor_layout_eqv_type_body_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_equiv_type__type_ctor_layout_eqv_type_body_0;

static const struct mercury_data_equiv_type__type_ctor_functors_eqv_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_equiv_type__type_ctor_functors_eqv_map_0;

static const struct mercury_data_equiv_type__type_ctor_layout_eqv_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_equiv_type__type_ctor_layout_eqv_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_equiv_type__type_ctor_info_eqv_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___equiv_type__eqv_map_0_0),
	ENTRY(mercury____Index___equiv_type__eqv_map_0_0),
	ENTRY(mercury____Compare___equiv_type__eqv_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_equiv_type__type_ctor_functors_eqv_map_0,
	(Word *) &mercury_data_equiv_type__type_ctor_layout_eqv_map_0,
	MR_string_const("equiv_type", 10),
	MR_string_const("eqv_map", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_equiv_type__type_ctor_info_eqv_type_body_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0),
	STATIC(mercury____Index___equiv_type__eqv_type_body_0_0),
	STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0),
	(Integer) 2,
	(Word *) &mercury_data_equiv_type__type_ctor_functors_eqv_type_body_0,
	(Word *) &mercury_data_equiv_type__type_ctor_layout_eqv_type_body_0,
	MR_string_const("equiv_type", 10),
	MR_string_const("eqv_type_body", 13),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_equiv_type__common_0_struct mercury_data_equiv_type__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_item_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_equiv_type__common_1_struct mercury_data_equiv_type__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_item_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_equiv_type__common_2_struct mercury_data_equiv_type__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_equiv_type__common_3_struct mercury_data_equiv_type__common_3 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0),
	(Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_method_0;
static const struct mercury_data_equiv_type__common_4_struct mercury_data_equiv_type__common_4 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_method_0
};

static const struct mercury_data_equiv_type__common_5_struct mercury_data_equiv_type__common_5 = {
	(Integer) 0,
	MR_string_const("equiv_type", 10),
	MR_string_const("equiv_type", 10),
	MR_string_const("replace_in_class_method", 23),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_equiv_type__common_6_struct mercury_data_equiv_type__common_6 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_equiv_type__common_7_struct mercury_data_equiv_type__common_7 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2)
};

static const struct mercury_data_equiv_type__common_8_struct mercury_data_equiv_type__common_8 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2),
	MR_string_const("eqv_type_body", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_equiv_type__common_9_struct mercury_data_equiv_type__common_9 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_3)
};

static const struct mercury_data_equiv_type__type_ctor_functors_eqv_type_body_0_struct mercury_data_equiv_type__type_ctor_functors_eqv_type_body_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_8)
};

static const struct mercury_data_equiv_type__type_ctor_layout_eqv_type_body_0_struct mercury_data_equiv_type__type_ctor_layout_eqv_type_body_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_equiv_type__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_equiv_type__type_ctor_functors_eqv_map_0_struct mercury_data_equiv_type__type_ctor_functors_eqv_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_3)
};

static const struct mercury_data_equiv_type__type_ctor_layout_eqv_map_0_struct mercury_data_equiv_type__type_ctor_layout_eqv_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_equiv_type__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_equiv_type__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_equiv_type__common_9),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_equiv_type__common_9)
};


BEGIN_MODULE(equiv_type_module0)
	init_entry(mercury____Index___equiv_type__eqv_type_body_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___equiv_type__eqv_type_body_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___equiv_type__eqv_type_body_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(equiv_type_module1)
	init_entry(mercury__equiv_type__expand_eqv_types_6_0);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i8);
	init_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
BEGIN_CODE

/* code for predicate 'expand_eqv_types'/6 in mode 0 */
Define_entry(mercury__equiv_type__expand_eqv_types_6_0);
	MR_incr_sp_push_msg(4, "equiv_type:expand_eqv_types/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__equiv_type__expand_eqv_types_6_0_i2,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i2);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__equiv_type__build_eqv_map_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i3,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i3);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	MR_stackvar(2) = r1;
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_item_list_5_0),
		mercury__equiv_type__expand_eqv_types_6_0_i4,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_1);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__equiv_type__expand_eqv_types_6_0_i5,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__expand_eqv_types_6_0_i6);
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i6);
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__equiv_type__report_circular_types_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i8,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r2 = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__equiv_type__expand_eqv_types_6_0_i9,
		ENTRY(mercury__equiv_type__expand_eqv_types_6_0));
Define_label(mercury__equiv_type__expand_eqv_types_6_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__expand_eqv_types_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module2)
	init_entry(mercury__equiv_type__replace_in_type_5_0);
BEGIN_CODE

/* code for predicate 'replace_in_type'/5 in mode 0 */
Define_entry(mercury__equiv_type__replace_in_type_5_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		ENTRY(mercury__equiv_type__replace_in_type_5_0));
END_MODULE

Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(equiv_type_module3)
	init_entry(mercury__equiv_type__build_eqv_map_3_0);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i1003);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i7);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i8);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i4);
	init_label(mercury__equiv_type__build_eqv_map_3_0_i3);
BEGIN_CODE

/* code for predicate 'build_eqv_map'/3 in mode 0 */
Define_static(mercury__equiv_type__build_eqv_map_3_0);
	MR_incr_sp_push_msg(7, "equiv_type:build_eqv_map/3");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__equiv_type__build_eqv_map_3_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 2)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i4);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__build_eqv_map_3_0_i7,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
	}
Define_label(mercury__equiv_type__build_eqv_map_3_0_i7);
	update_prof_current_proc(LABEL(mercury__equiv_type__build_eqv_map_3_0));
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__equiv_type__build_eqv_map_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__equiv_type__build_eqv_map_3_0, "equiv_type:eqv_type_body/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__equiv_type__build_eqv_map_3_0_i8,
		STATIC(mercury__equiv_type__build_eqv_map_3_0));
Define_label(mercury__equiv_type__build_eqv_map_3_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__build_eqv_map_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1003);
Define_label(mercury__equiv_type__build_eqv_map_3_0_i4);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__equiv_type__build_eqv_map_3_0_i1003);
Define_label(mercury__equiv_type__build_eqv_map_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module4)
	init_entry(mercury__equiv_type__replace_in_item_list_5_0);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i8);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
	init_label(mercury__equiv_type__replace_in_item_list_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_item_list'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_item_list_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i3);
	MR_incr_sp_push_msg(6, "equiv_type:replace_in_item_list/5");
	MR_stackvar(6) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_item_4_0),
		mercury__equiv_type__replace_in_item_list_5_0_i6,
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i4);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_list_5_0_i8);
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_item_list_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_item_list_5_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	localcall(mercury__equiv_type__replace_in_item_list_5_0,
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i12),
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i8);
	r4 = r2;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_item_list_5_0, "origin_lost_in_value_number");
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	localcall(mercury__equiv_type__replace_in_item_list_5_0,
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i12),
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i4);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_stackvar(3) = MR_stackvar(5);
	localcall(mercury__equiv_type__replace_in_item_list_5_0,
		LABEL(mercury__equiv_type__replace_in_item_list_5_0_i12),
		STATIC(mercury__equiv_type__replace_in_item_list_5_0));
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i12);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_list_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_item_list_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_list_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module5)
	init_entry(mercury__equiv_type__replace_in_item_4_0);
	init_label(mercury__equiv_type__replace_in_item_4_0_i5);
	init_label(mercury__equiv_type__replace_in_item_4_0_i6);
	init_label(mercury__equiv_type__replace_in_item_4_0_i8);
	init_label(mercury__equiv_type__replace_in_item_4_0_i9);
	init_label(mercury__equiv_type__replace_in_item_4_0_i10);
	init_label(mercury__equiv_type__replace_in_item_4_0_i11);
	init_label(mercury__equiv_type__replace_in_item_4_0_i12);
	init_label(mercury__equiv_type__replace_in_item_4_0_i13);
	init_label(mercury__equiv_type__replace_in_item_4_0_i14);
	init_label(mercury__equiv_type__replace_in_item_4_0_i15);
	init_label(mercury__equiv_type__replace_in_item_4_0_i16);
	init_label(mercury__equiv_type__replace_in_item_4_0_i18);
	init_label(mercury__equiv_type__replace_in_item_4_0_i19);
	init_label(mercury__equiv_type__replace_in_item_4_0_i20);
	init_label(mercury__equiv_type__replace_in_item_4_0_i1032);
	init_label(mercury__equiv_type__replace_in_item_4_0_i22);
	init_label(mercury__equiv_type__replace_in_item_4_0_i23);
	init_label(mercury__equiv_type__replace_in_item_4_0_i24);
	init_label(mercury__equiv_type__replace_in_item_4_0_i1022);
	init_label(mercury__equiv_type__replace_in_item_4_0_i1);
BEGIN_CODE

/* code for predicate 'replace_in_item'/4 in mode 0 */
Define_static(mercury__equiv_type__replace_in_item_4_0);
	MR_incr_sp_push_msg(11, "equiv_type:replace_in_item/4");
	MR_stackvar(11) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_4_0_i1022);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__equiv_type__replace_in_item_4_0_i5) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i8) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i11) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i16) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i1022) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i19) AND
		LABEL(mercury__equiv_type__replace_in_item_4_0_i22));
Define_label(mercury__equiv_type__replace_in_item_4_0_i5);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__equiv_type__replace_in_type_defn_6_0),
		mercury__equiv_type__replace_in_item_4_0_i6,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_4_0_i1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	r1 = TRUE;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i8);
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r1, (Integer) 8);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 9);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraints_5_0),
		mercury__equiv_type__replace_in_item_4_0_i9,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_item_4_0_i10,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 10, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 5) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	r1 = TRUE;
	r3 = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 9) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 7) = MR_stackvar(7);
	MR_field(MR_mktag(3), r2, (Integer) 6) = MR_stackvar(6);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r2, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), r2, (Integer) 8) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_4_0_i11);
	r3 = r2;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 10);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(3), r1, (Integer) 9);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_item_4_0_i12,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i12);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(10);
	MR_stackvar(10) = MR_tempr1;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_item_4_0_i13,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i13);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = r3;
	MR_stackvar(5) = MR_tempr1;
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_item_4_0_i14,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i14);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__equiv_type__replace_in_tm_5_0),
		mercury__equiv_type__replace_in_item_4_0_i15,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i15);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 11, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 6) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	r1 = TRUE;
	r3 = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 10) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 9) = MR_stackvar(9);
	MR_field(MR_mktag(3), r2, (Integer) 7) = MR_stackvar(7);
	MR_field(MR_mktag(3), r2, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r2, (Integer) 5) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 8) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_4_0_i16);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__equiv_type__replace_in_item_4_0_i1);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 7);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_subst_5_0),
		mercury__equiv_type__replace_in_item_4_0_i18,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i18);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__equiv_type__replace_in_item_4_0, "prog_data:item/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 8, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 7) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 6) = r1;
	r1 = TRUE;
	r3 = (Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__equiv_type__replace_in_item_4_0_i19);
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_item_4_0_i20,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i20);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_class_interface_3_0),
		mercury__equiv_type__replace_in_item_4_0_i1032,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i1032);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 6, mercury__equiv_type__replace_in_item_4_0, "prog_data:item/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 10;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 4) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 5) = MR_stackvar(4);
	r3 = (Integer) 0;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_4_0_i22);
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_item_4_0_i23,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i23);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_item_4_0_i24,
		STATIC(mercury__equiv_type__replace_in_item_4_0));
Define_label(mercury__equiv_type__replace_in_item_4_0_i24);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_item_4_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 6, mercury__equiv_type__replace_in_item_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 3) = r1;
	r1 = TRUE;
	r3 = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 5) = r4;
	MR_field(MR_mktag(3), r2, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 11;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_4_0_i1022);
	r1 = FALSE;
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_item_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module6)
	init_entry(mercury__equiv_type__replace_in_type_defn_6_0);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i9);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i10);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i6);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i7);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i4);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i5);
	init_label(mercury__equiv_type__replace_in_type_defn_6_0_i1010);
BEGIN_CODE

/* code for predicate 'replace_in_type_defn'/6 in mode 0 */
Define_static(mercury__equiv_type__replace_in_type_defn_6_0);
	MR_incr_sp_push_msg(6, "equiv_type:replace_in_type_defn/6");
	MR_stackvar(6) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_defn_6_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_defn_6_0_i6);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_defn_6_0_i1010);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(4) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__replace_in_type_defn_6_0_i9,
		STATIC(mercury__equiv_type__replace_in_type_defn_6_0));
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_defn_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_type_defn_6_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_type_defn_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_type_defn_6_0_i10,
		STATIC(mercury__equiv_type__replace_in_type_defn_6_0));
	}
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_defn_6_0));
	r4 = r3;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 3, mercury__equiv_type__replace_in_type_defn_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_type_defn_6_0_i7,
		STATIC(mercury__equiv_type__replace_in_type_defn_6_0));
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i7);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_defn_6_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 3, mercury__equiv_type__replace_in_type_defn_6_0, "origin_lost_in_value_number");
	r3 = r4;
	MR_field(MR_mktag(1), r2, (Integer) 2) = r1;
	r1 = TRUE;
	r4 = (Integer) 0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	call_localret(STATIC(mercury__equiv_type__replace_in_du_5_0),
		mercury__equiv_type__replace_in_type_defn_6_0_i5,
		STATIC(mercury__equiv_type__replace_in_type_defn_6_0));
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_defn_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__equiv_type__replace_in_type_defn_6_0, "prog_data:type_defn/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(3);
	r4 = (Integer) 0;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_defn_6_0_i1010);
	r1 = FALSE;
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module7)
	init_entry(mercury__equiv_type__replace_in_class_constraints_5_0);
	init_label(mercury__equiv_type__replace_in_class_constraints_5_0_i2);
	init_label(mercury__equiv_type__replace_in_class_constraints_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_class_constraints'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_class_constraints_5_0);
	MR_incr_sp_push_msg(3, "equiv_type:replace_in_class_constraints/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_constraints_5_0_i2,
		STATIC(mercury__equiv_type__replace_in_class_constraints_5_0));
Define_label(mercury__equiv_type__replace_in_class_constraints_5_0_i2);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_constraints_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_constraints_5_0_i3,
		STATIC(mercury__equiv_type__replace_in_class_constraints_5_0));
Define_label(mercury__equiv_type__replace_in_class_constraints_5_0_i3);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_constraints_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_class_constraints_5_0, "prog_data:class_constraints/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__type_util__strip_prog_contexts_2_0);

BEGIN_MODULE(equiv_type_module8)
	init_entry(mercury__equiv_type__replace_in_class_constraint_list_5_0);
	init_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i4);
	init_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i5);
	init_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i6);
	init_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_class_constraint_list'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_class_constraint_list_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_class_constraint_list_5_0_i3);
	MR_incr_sp_push_msg(5, "equiv_type:replace_in_class_constraint_list/5");
	MR_stackvar(5) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Integer) 0;
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_class_constraint_list_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_constraint_list_5_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__type_util__strip_prog_contexts_2_0),
		mercury__equiv_type__replace_in_class_constraint_list_5_0_i5,
		STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0));
Define_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_constraint_list_5_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_class_constraint_list_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	localcall(mercury__equiv_type__replace_in_class_constraint_list_5_0,
		LABEL(mercury__equiv_type__replace_in_class_constraint_list_5_0_i6),
		STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0));
	}
Define_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_constraint_list_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_class_constraint_list_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__equiv_type__replace_in_class_constraint_list_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(equiv_type_module9)
	init_entry(mercury__equiv_type__replace_in_class_interface_3_0);
BEGIN_CODE

/* code for predicate 'replace_in_class_interface'/3 in mode 0 */
Define_static(mercury__equiv_type__replace_in_class_interface_3_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__equiv_type__replace_in_class_interface_3_0, "origin_lost_in_value_number");
	r4 = r1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_method_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_method_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__equiv_type__replace_in_class_method_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_5);
	tailcall(ENTRY(mercury__list__map_3_0),
		STATIC(mercury__equiv_type__replace_in_class_interface_3_0));
END_MODULE


BEGIN_MODULE(equiv_type_module10)
	init_entry(mercury__equiv_type__replace_in_class_method_3_0);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i4);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i5);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i6);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i7);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i8);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i9);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i10);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i11);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i14);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i13);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i15);
	init_label(mercury__equiv_type__replace_in_class_method_3_0_i1011);
BEGIN_CODE

/* code for predicate 'replace_in_class_method'/3 in mode 0 */
Define_static(mercury__equiv_type__replace_in_class_method_3_0);
	MR_incr_sp_push_msg(11, "equiv_type:replace_in_class_method/3");
	MR_stackvar(11) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__equiv_type__replace_in_class_method_3_0_i4) AND
		LABEL(mercury__equiv_type__replace_in_class_method_3_0_i8) AND
		LABEL(mercury__equiv_type__replace_in_class_method_3_0_i1011) AND
		LABEL(mercury__equiv_type__replace_in_class_method_3_0_i1011));
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i4);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i5,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = MR_tempr1;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i6,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_class_method_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i7,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i7);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 9, mercury__equiv_type__replace_in_class_method_3_0, "prog_data:class_method/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 8);
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 6);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r2, (Integer) 7);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r2, (Integer) 9);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i9,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(10);
	MR_stackvar(10) = MR_tempr1;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i10,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_class_method_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = r3;
	MR_stackvar(5) = MR_tempr1;
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	call_localret(STATIC(mercury__equiv_type__replace_in_tms_5_0),
		mercury__equiv_type__replace_in_class_method_3_0_i11,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i11);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	if ((MR_tag(MR_stackvar(6)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_class_method_3_0_i13);
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(6), (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_class_method_3_0_i14,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i14);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 10, mercury__equiv_type__replace_in_class_method_3_0, "prog_data:class_method/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__equiv_type__replace_in_class_method_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 5) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 9) = MR_stackvar(9);
	MR_field(MR_mktag(1), r1, (Integer) 7) = MR_stackvar(8);
	MR_field(MR_mktag(1), r1, (Integer) 6) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 8) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r4;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i13);
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(6);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_class_method_3_0_i15,
		STATIC(mercury__equiv_type__replace_in_class_method_3_0));
	}
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i15);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_class_method_3_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 10, mercury__equiv_type__replace_in_class_method_3_0, "prog_data:class_method/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_class_method_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 5) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 9) = MR_stackvar(9);
	MR_field(MR_mktag(1), r1, (Integer) 7) = MR_stackvar(8);
	MR_field(MR_mktag(1), r1, (Integer) 6) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 8) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__equiv_type__replace_in_class_method_3_0_i1011);
	r1 = r2;
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module11)
	init_entry(mercury__equiv_type__replace_in_subst_5_0);
	init_label(mercury__equiv_type__replace_in_subst_5_0_i4);
	init_label(mercury__equiv_type__replace_in_subst_5_0_i5);
	init_label(mercury__equiv_type__replace_in_subst_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_subst'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_subst_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_subst_5_0_i3);
	MR_incr_sp_push_msg(4, "equiv_type:replace_in_subst/5");
	MR_stackvar(4) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_subst_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_subst_5_0));
	}
Define_label(mercury__equiv_type__replace_in_subst_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_subst_5_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_subst_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__equiv_type__replace_in_subst_5_0,
		LABEL(mercury__equiv_type__replace_in_subst_5_0_i5),
		STATIC(mercury__equiv_type__replace_in_subst_5_0));
	}
Define_label(mercury__equiv_type__replace_in_subst_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_subst_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_subst_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__equiv_type__replace_in_subst_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module12)
	init_entry(mercury__equiv_type__replace_in_du_5_0);
	init_label(mercury__equiv_type__replace_in_du_5_0_i4);
	init_label(mercury__equiv_type__replace_in_du_5_0_i5);
	init_label(mercury__equiv_type__replace_in_du_5_0_i6);
	init_label(mercury__equiv_type__replace_in_du_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_du'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_du_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_du_5_0_i3);
	MR_incr_sp_push_msg(6, "equiv_type:replace_in_du/5");
	MR_stackvar(6) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Integer) 0;
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0),
		mercury__equiv_type__replace_in_du_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_du_5_0));
	}
Define_label(mercury__equiv_type__replace_in_du_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_du_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__equiv_type__replace_in_class_constraint_list_5_0),
		mercury__equiv_type__replace_in_du_5_0_i5,
		STATIC(mercury__equiv_type__replace_in_du_5_0));
	}
Define_label(mercury__equiv_type__replace_in_du_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_du_5_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__equiv_type__replace_in_du_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__equiv_type__replace_in_du_5_0,
		LABEL(mercury__equiv_type__replace_in_du_5_0_i6),
		STATIC(mercury__equiv_type__replace_in_du_5_0));
	}
Define_label(mercury__equiv_type__replace_in_du_5_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_du_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_du_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_du_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__bool__or_3_0);

BEGIN_MODULE(equiv_type_module13)
	init_entry(mercury__equiv_type__replace_in_type_list_2_8_0);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
	init_label(mercury__equiv_type__replace_in_type_list_2_8_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_type_list_2'/8 in mode 0 */
Define_static(mercury__equiv_type__replace_in_type_list_2_8_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_list_2_8_0_i3);
	MR_incr_sp_push_msg(6, "equiv_type:replace_in_type_list_2/8");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_type_list_2_8_0_i4,
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(5) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_type_list_2_8_0_i5,
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
	}
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	r5 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	localcall(mercury__equiv_type__replace_in_type_list_2_8_0,
		LABEL(mercury__equiv_type__replace_in_type_list_2_8_0_i6),
		STATIC(mercury__equiv_type__replace_in_type_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_list_2_8_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_type_list_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__equiv_type__replace_in_type_list_2_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module14)
	init_entry(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
	init_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_ctor_arg_list_2'/8 in mode 0 */
Define_static(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i3);
	MR_incr_sp_push_msg(6, "equiv_type:replace_in_ctor_arg_list_2/8");
	MR_stackvar(6) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4,
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	}
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__equiv_type__replace_in_ctor_arg_list_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = MR_tempr1;
	r2 = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5,
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	}
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	localcall(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0,
		LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6),
		STATIC(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_ctor_arg_list_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__equiv_type__replace_in_ctor_arg_list_2_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	proceed();
END_MODULE

Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__varset__merge_without_names_5_0);
Declare_entry(mercury__term__term_list_to_var_list_2_0);
Declare_entry(mercury__term__substitute_corresponding_4_0);
Declare_entry(mercury__type_util__construct_type_4_0);

BEGIN_MODULE(equiv_type_module15)
	init_entry(mercury__equiv_type__replace_in_type_2_7_0);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i1007);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i9);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i12);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i14);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i20);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i21);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i24);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i4);
	init_label(mercury__equiv_type__replace_in_type_2_7_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_type_2'/7 in mode 0 */
Define_static(mercury__equiv_type__replace_in_type_2_7_0);
	MR_incr_sp_push_msg(13, "equiv_type:replace_in_type_2/7");
	MR_stackvar(13) = (Word) MR_succip;
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i1007);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__equiv_type__replace_in_type_2_7_0_i6,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i4);
	r1 = r3;
	MR_stackvar(8) = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_list_2_8_0),
		mercury__equiv_type__replace_in_type_2_7_0_i8,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	MR_stackvar(9) = r1;
	MR_stackvar(10) = r2;
	MR_stackvar(11) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__equiv_type__replace_in_type_2_7_0_i10,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(8);
	MR_stackvar(5) = (Integer) 1;
	GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i12);
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(8);
	MR_stackvar(5) = (Integer) 0;
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i12);
	MR_stackvar(3) = r3;
	MR_stackvar(8) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__equiv_type__replace_in_type_2_7_0_i14,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i14);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i13);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_type_2_7_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__varset__merge_without_names_5_0),
		mercury__equiv_type__replace_in_type_2_7_0_i16,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i13);
	if (((Integer) MR_stackvar(11) != (Integer) 0))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i13);
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i13);
	MR_stackvar(6) = r1;
	MR_stackvar(12) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__equiv_type__replace_in_type_2_7_0_i20,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i20);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(12);
	call_localret(ENTRY(mercury__term__substitute_corresponding_4_0),
		mercury__equiv_type__replace_in_type_2_7_0_i21,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i21);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_type_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__equiv_type__replace_in_type_2_7_0_i1007);
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i13);
	MR_stackvar(6) = MR_stackvar(10);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__type_util__construct_type_4_0),
		mercury__equiv_type__replace_in_type_2_7_0_i23,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i23);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(11);
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__equiv_type__replace_in_type_2_7_0_i24,
		STATIC(mercury__equiv_type__replace_in_type_2_7_0));
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i24);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_type_2_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__equiv_type__replace_in_type_2_7_0_i3);
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module16)
	init_entry(mercury__equiv_type__replace_in_tms_5_0);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i6);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i5);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i7);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i8);
	init_label(mercury__equiv_type__replace_in_tms_5_0_i3);
BEGIN_CODE

/* code for predicate 'replace_in_tms'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_tms_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__replace_in_tms_5_0_i3);
	MR_incr_sp_push_msg(4, "equiv_type:replace_in_tms/5");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_tms_5_0_i5);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_tms_5_0_i6,
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
Define_label(mercury__equiv_type__replace_in_tms_5_0_i6);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tms_5_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__equiv_type__replace_in_tms_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__equiv_type__replace_in_tms_5_0,
		LABEL(mercury__equiv_type__replace_in_tms_5_0_i8),
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
	}
Define_label(mercury__equiv_type__replace_in_tms_5_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_tms_5_0_i7,
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
	}
Define_label(mercury__equiv_type__replace_in_tms_5_0_i7);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tms_5_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_tms_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r5;
	localcall(mercury__equiv_type__replace_in_tms_5_0,
		LABEL(mercury__equiv_type__replace_in_tms_5_0_i8),
		STATIC(mercury__equiv_type__replace_in_tms_5_0));
	}
Define_label(mercury__equiv_type__replace_in_tms_5_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tms_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_tms_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__equiv_type__replace_in_tms_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module17)
	init_entry(mercury__equiv_type__replace_in_tm_5_0);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i4);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i3);
	init_label(mercury__equiv_type__replace_in_tm_5_0_i5);
BEGIN_CODE

/* code for predicate 'replace_in_tm'/5 in mode 0 */
Define_static(mercury__equiv_type__replace_in_tm_5_0);
	MR_incr_sp_push_msg(2, "equiv_type:replace_in_tm/5");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__equiv_type__replace_in_tm_5_0_i3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_tm_5_0_i4,
		STATIC(mercury__equiv_type__replace_in_tm_5_0));
Define_label(mercury__equiv_type__replace_in_tm_5_0_i4);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tm_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__equiv_type__replace_in_tm_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__equiv_type__replace_in_tm_5_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__equiv_type__replace_in_type_2_7_0),
		mercury__equiv_type__replace_in_tm_5_0_i5,
		STATIC(mercury__equiv_type__replace_in_tm_5_0));
Define_label(mercury__equiv_type__replace_in_tm_5_0_i5);
	update_prof_current_proc(LABEL(mercury__equiv_type__replace_in_tm_5_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__equiv_type__replace_in_tm_5_0, "prog_data:type_and_mode/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__prog_out__write_context_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__prog_out__write_sym_name_3_0);
Declare_entry(mercury__io__write_int_3_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(equiv_type_module18)
	init_entry(mercury__equiv_type__report_circular_types_3_0);
	init_label(mercury__equiv_type__report_circular_types_3_0_i1003);
	init_label(mercury__equiv_type__report_circular_types_3_0_i3);
	init_label(mercury__equiv_type__report_circular_types_3_0_i7);
	init_label(mercury__equiv_type__report_circular_types_3_0_i8);
	init_label(mercury__equiv_type__report_circular_types_3_0_i9);
	init_label(mercury__equiv_type__report_circular_types_3_0_i10);
	init_label(mercury__equiv_type__report_circular_types_3_0_i11);
	init_label(mercury__equiv_type__report_circular_types_3_0_i12);
	init_label(mercury__equiv_type__report_circular_types_3_0_i13);
	init_label(mercury__equiv_type__report_circular_types_3_0_i4);
BEGIN_CODE

/* code for predicate 'report_circular_types'/3 in mode 0 */
Define_static(mercury__equiv_type__report_circular_types_3_0);
	MR_incr_sp_push_msg(5, "equiv_type:report_circular_types/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__equiv_type__report_circular_types_3_0_i1003);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__equiv_type__report_circular_types_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i4);
	MR_tempr3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), MR_tempr3, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), MR_tempr3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__equiv_type__report_circular_types_3_0_i7,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
	}
Define_label(mercury__equiv_type__report_circular_types_3_0_i7);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__equiv_type__report_circular_types_3_0_i8,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i8);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Error: circular equivalence type `", 34);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i9,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i9);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__prog_out__write_sym_name_3_0),
		mercury__equiv_type__report_circular_types_3_0_i10,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i10);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'/", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i11,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i11);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__equiv_type__report_circular_types_3_0_i12,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i12);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__equiv_type__report_circular_types_3_0_i13,
		STATIC(mercury__equiv_type__report_circular_types_3_0));
Define_label(mercury__equiv_type__report_circular_types_3_0_i13);
	update_prof_current_proc(LABEL(mercury__equiv_type__report_circular_types_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__equiv_type__report_circular_types_3_0_i1003);
Define_label(mercury__equiv_type__report_circular_types_3_0_i4);
	r1 = (Word) MR_string_const("equiv_type__report_circular_types: invalid item", 47);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__equiv_type__report_circular_types_3_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(equiv_type_module19)
	init_entry(mercury____Unify___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___equiv_type__eqv_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___equiv_type__eqv_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(equiv_type_module20)
	init_entry(mercury____Index___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___equiv_type__eqv_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___equiv_type__eqv_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(equiv_type_module21)
	init_entry(mercury____Compare___equiv_type__eqv_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___equiv_type__eqv_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_equiv_type__type_ctor_info_eqv_type_body_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___equiv_type__eqv_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___term__term_1_0);

BEGIN_MODULE(equiv_type_module22)
	init_entry(mercury____Unify___equiv_type__eqv_type_body_0_0);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
	init_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___equiv_type__eqv_type_body_0_0);
	MR_incr_sp_push_msg(5, "equiv_type:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___equiv_type__eqv_type_body_0_0_i2,
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___equiv_type__eqv_type_body_0_0_i4,
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___term__term_1_0),
		STATIC(mercury____Unify___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Unify___equiv_type__eqv_type_body_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(equiv_type_module23)
	init_entry(mercury____Index___equiv_type__eqv_type_body_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___equiv_type__eqv_type_body_0_0);
	tailcall(STATIC(mercury____Index___equiv_type__eqv_type_body_0__ua0_2_0),
		STATIC(mercury____Index___equiv_type__eqv_type_body_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___term__term_1_0);

BEGIN_MODULE(equiv_type_module24)
	init_entry(mercury____Compare___equiv_type__eqv_type_body_0_0);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i7);
	init_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___equiv_type__eqv_type_body_0_0);
	MR_incr_sp_push_msg(5, "equiv_type:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___equiv_type__eqv_type_body_0_0_i3,
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_equiv_type__common_2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___equiv_type__eqv_type_body_0_0_i7,
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___equiv_type__eqv_type_body_0_0_i12);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___term__term_1_0),
		STATIC(mercury____Compare___equiv_type__eqv_type_body_0_0));
Define_label(mercury____Compare___equiv_type__eqv_type_body_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__equiv_type_maybe_bunch_0(void)
{
	equiv_type_module0();
	equiv_type_module1();
	equiv_type_module2();
	equiv_type_module3();
	equiv_type_module4();
	equiv_type_module5();
	equiv_type_module6();
	equiv_type_module7();
	equiv_type_module8();
	equiv_type_module9();
	equiv_type_module10();
	equiv_type_module11();
	equiv_type_module12();
	equiv_type_module13();
	equiv_type_module14();
	equiv_type_module15();
	equiv_type_module16();
	equiv_type_module17();
	equiv_type_module18();
	equiv_type_module19();
	equiv_type_module20();
	equiv_type_module21();
	equiv_type_module22();
	equiv_type_module23();
	equiv_type_module24();
}

#endif

void mercury__equiv_type__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__equiv_type__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__equiv_type_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_equiv_type__type_ctor_info_eqv_map_0,
			equiv_type__eqv_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_equiv_type__type_ctor_info_eqv_type_body_0,
			equiv_type__eqv_type_body_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
