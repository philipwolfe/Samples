/*
** Automatically generated from `error_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__error_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__error_util__IntroducedFrom__pred__report_error_num_args__407__1_2_0);
Define_extern_entry(mercury__error_util__list_to_pieces_2_0);
Declare_label(mercury__error_util__list_to_pieces_2_0_i3);
Declare_label(mercury__error_util__list_to_pieces_2_0_i5);
Declare_label(mercury__error_util__list_to_pieces_2_0_i8);
Declare_label(mercury__error_util__list_to_pieces_2_0_i9);
Declare_label(mercury__error_util__list_to_pieces_2_0_i7);
Define_extern_entry(mercury__error_util__write_error_pieces_5_0);
Declare_label(mercury__error_util__write_error_pieces_5_0_i2);
Declare_label(mercury__error_util__write_error_pieces_5_0_i3);
Declare_label(mercury__error_util__write_error_pieces_5_0_i4);
Declare_label(mercury__error_util__write_error_pieces_5_0_i5);
Declare_label(mercury__error_util__write_error_pieces_5_0_i6);
Declare_label(mercury__error_util__write_error_pieces_5_0_i7);
Declare_label(mercury__error_util__write_error_pieces_5_0_i9);
Declare_label(mercury__error_util__write_error_pieces_5_0_i10);
Declare_label(mercury__error_util__write_error_pieces_5_0_i12);
Declare_label(mercury__error_util__write_error_pieces_5_0_i13);
Declare_label(mercury__error_util__write_error_pieces_5_0_i14);
Declare_label(mercury__error_util__write_error_pieces_5_0_i15);
Declare_label(mercury__error_util__write_error_pieces_5_0_i1002);
Declare_label(mercury__error_util__write_error_pieces_5_0_i17);
Declare_label(mercury__error_util__write_error_pieces_5_0_i18);
Declare_label(mercury__error_util__write_error_pieces_5_0_i19);
Define_extern_entry(mercury__error_util__report_warning_5_0);
Declare_label(mercury__error_util__report_warning_5_0_i2);
Declare_label(mercury__error_util__report_warning_5_0_i5);
Declare_label(mercury__error_util__report_warning_5_0_i3);
Define_extern_entry(mercury__error_util__describe_one_pred_name_3_0);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i2);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i3);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i4);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i5);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i6);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i7);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i9);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i11);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i10);
Declare_label(mercury__error_util__describe_one_pred_name_3_0_i12);
Define_extern_entry(mercury__error_util__describe_one_proc_name_3_0);
Declare_label(mercury__error_util__describe_one_proc_name_3_0_i2);
Declare_label(mercury__error_util__describe_one_proc_name_3_0_i3);
Declare_label(mercury__error_util__describe_one_proc_name_3_0_i4);
Define_extern_entry(mercury__error_util__describe_several_proc_names_3_0);
Declare_label(mercury__error_util__describe_several_proc_names_3_0_i2);
Define_extern_entry(mercury__error_util__describe_one_call_site_3_0);
Declare_label(mercury__error_util__describe_one_call_site_3_0_i2);
Declare_label(mercury__error_util__describe_one_call_site_3_0_i3);
Declare_label(mercury__error_util__describe_one_call_site_3_0_i4);
Declare_label(mercury__error_util__describe_one_call_site_3_0_i5);
Define_extern_entry(mercury__error_util__describe_several_call_sites_3_0);
Declare_label(mercury__error_util__describe_several_call_sites_3_0_i2);
Define_extern_entry(mercury__error_util__report_error_num_args_5_0);
Declare_label(mercury__error_util__report_error_num_args_5_0_i5);
Declare_label(mercury__error_util__report_error_num_args_5_0_i6);
Declare_label(mercury__error_util__report_error_num_args_5_0_i2);
Declare_label(mercury__error_util__report_error_num_args_5_0_i8);
Declare_label(mercury__error_util__report_error_num_args_5_0_i9);
Declare_label(mercury__error_util__report_error_num_args_5_0_i10);
Declare_label(mercury__error_util__report_error_num_args_5_0_i11);
Declare_static(mercury__error_util__write_nonfirst_lines_5_0);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i1003);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i4);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i5);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i6);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i1001);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i8);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i9);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i10);
Declare_label(mercury__error_util__write_nonfirst_lines_5_0_i3);
Declare_static(mercury__error_util__write_line_rest_3_0);
Declare_label(mercury__error_util__write_line_rest_3_0_i1001);
Declare_label(mercury__error_util__write_line_rest_3_0_i4);
Declare_label(mercury__error_util__write_line_rest_3_0_i5);
Declare_label(mercury__error_util__write_line_rest_3_0_i3);
Declare_static(mercury__error_util__convert_components_to_word_list_4_0);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i1003);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i9);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i7);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i8);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i6);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i3);
Declare_label(mercury__error_util__convert_components_to_word_list_4_0_i11);
Declare_static(mercury__error_util__break_into_words_from_4_0);
Declare_label(mercury__error_util__break_into_words_from_4_0_i1001);
Declare_label(mercury__error_util__break_into_words_from_4_0_i4);
Declare_label(mercury__error_util__break_into_words_from_4_0_i6);
Declare_label(mercury__error_util__break_into_words_from_4_0_i7);
Declare_label(mercury__error_util__break_into_words_from_4_0_i2);
Declare_static(mercury__error_util__find_word_start_3_0);
Declare_label(mercury__error_util__find_word_start_3_0_i1002);
Declare_label(mercury__error_util__find_word_start_3_0_i2);
Declare_label(mercury__error_util__find_word_start_3_0_i6);
Declare_label(mercury__error_util__find_word_start_3_0_i5);
Declare_label(mercury__error_util__find_word_start_3_0_i1);
Declare_static(mercury__error_util__find_word_end_3_0);
Declare_label(mercury__error_util__find_word_end_3_0_i1002);
Declare_label(mercury__error_util__find_word_end_3_0_i4);
Declare_label(mercury__error_util__find_word_end_3_0_i8);
Declare_label(mercury__error_util__find_word_end_3_0_i1004);
Declare_label(mercury__error_util__find_word_end_3_0_i7);
Declare_static(mercury__error_util__group_words_4_0);
Declare_label(mercury__error_util__group_words_4_0_i1003);
Declare_label(mercury__error_util__group_words_4_0_i5);
Declare_label(mercury__error_util__group_words_4_0_i7);
Declare_label(mercury__error_util__group_words_4_0_i8);
Declare_label(mercury__error_util__group_words_4_0_i9);
Declare_label(mercury__error_util__group_words_4_0_i11);
Declare_label(mercury__error_util__group_words_4_0_i12);
Declare_label(mercury__error_util__group_words_4_0_i13);
Declare_label(mercury__error_util__group_words_4_0_i3);
Declare_static(mercury__error_util__group_nonfirst_line_words_3_0);
Declare_label(mercury__error_util__group_nonfirst_line_words_3_0_i4);
Declare_label(mercury__error_util__group_nonfirst_line_words_3_0_i5);
Declare_label(mercury__error_util__group_nonfirst_line_words_3_0_i6);
Declare_label(mercury__error_util__group_nonfirst_line_words_3_0_i3);
Declare_static(mercury__error_util__get_later_words_6_0);
Declare_label(mercury__error_util__get_later_words_6_0_i1002);
Declare_label(mercury__error_util__get_later_words_6_0_i3);
Declare_label(mercury__error_util__get_later_words_6_0_i4);
Declare_label(mercury__error_util__get_later_words_6_0_i6);
Declare_label(mercury__error_util__get_later_words_6_0_i5);
Declare_static(mercury__error_util__report_error_right_num_args_3_0);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i1005);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i4);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i1001);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i5);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i7);
Declare_label(mercury__error_util__report_error_right_num_args_3_0_i3);
Define_extern_entry(mercury____Unify___error_util__format_component_0_0);
Declare_label(mercury____Unify___error_util__format_component_0_0_i6);
Declare_label(mercury____Unify___error_util__format_component_0_0_i4);
Declare_label(mercury____Unify___error_util__format_component_0_0_i1);
Define_extern_entry(mercury____Index___error_util__format_component_0_0);
Declare_label(mercury____Index___error_util__format_component_0_0_i5);
Declare_label(mercury____Index___error_util__format_component_0_0_i4);
Define_extern_entry(mercury____Compare___error_util__format_component_0_0);
Declare_label(mercury____Compare___error_util__format_component_0_0_i5);
Declare_label(mercury____Compare___error_util__format_component_0_0_i4);
Declare_label(mercury____Compare___error_util__format_component_0_0_i2);
Declare_label(mercury____Compare___error_util__format_component_0_0_i9);
Declare_label(mercury____Compare___error_util__format_component_0_0_i8);
Declare_label(mercury____Compare___error_util__format_component_0_0_i6);
Declare_label(mercury____Compare___error_util__format_component_0_0_i10);
Declare_label(mercury____Compare___error_util__format_component_0_0_i11);
Declare_label(mercury____Compare___error_util__format_component_0_0_i19);
Declare_label(mercury____Compare___error_util__format_component_0_0_i16);
Declare_label(mercury____Compare___error_util__format_component_0_0_i1019);

const struct MR_TypeCtorInfo_struct mercury_data_error_util__type_ctor_info_format_component_0;

static const struct mercury_data_error_util__common_0_struct {
	String f1;
}  mercury_data_error_util__common_0;

static const struct mercury_data_error_util__common_1_struct {
	String f1;
	Word * f2;
}  mercury_data_error_util__common_1;

static const struct mercury_data_error_util__common_2_struct {
	Word * f1;
}  mercury_data_error_util__common_2;

static const struct mercury_data_error_util__common_3_struct {
	Word * f1;
}  mercury_data_error_util__common_3;

static const struct mercury_data_error_util__common_4_struct {
	Word * f1;
}  mercury_data_error_util__common_4;

static const struct mercury_data_error_util__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_error_util__common_5;

static const struct mercury_data_error_util__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_error_util__common_6;

static const struct mercury_data_error_util__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_error_util__common_7;

static const struct mercury_data_error_util__common_8_struct {
	Word * f1;
}  mercury_data_error_util__common_8;

static const struct mercury_data_error_util__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_error_util__common_9;

static const struct mercury_data_error_util__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_error_util__common_10;

static const struct mercury_data_error_util__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_error_util__common_11;

static const struct mercury_data_error_util__common_12_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_error_util__common_12;

static const struct mercury_data_error_util__common_13_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_error_util__common_13;

static const struct mercury_data_error_util__common_14_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_error_util__common_14;

static const struct mercury_data_error_util__common_15_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_error_util__common_15;

static const struct mercury_data_error_util__type_ctor_functors_format_component_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_error_util__type_ctor_functors_format_component_0;

static const struct mercury_data_error_util__type_ctor_layout_format_component_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_error_util__type_ctor_layout_format_component_0;

const struct MR_TypeCtorInfo_struct mercury_data_error_util__type_ctor_info_format_component_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___error_util__format_component_0_0),
	ENTRY(mercury____Index___error_util__format_component_0_0),
	ENTRY(mercury____Compare___error_util__format_component_0_0),
	(Integer) 2,
	(Word *) &mercury_data_error_util__type_ctor_functors_format_component_0,
	(Word *) &mercury_data_error_util__type_ctor_layout_format_component_0,
	MR_string_const("error_util", 10),
	MR_string_const("format_component", 16),
	(Integer) 3
};

static const struct mercury_data_error_util__common_0_struct mercury_data_error_util__common_0 = {
	MR_string_const("and", 3)
};

static const struct mercury_data_error_util__common_1_struct mercury_data_error_util__common_1 = {
	MR_string_const("'", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_error_util__common_2_struct mercury_data_error_util__common_2 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_error_util__common_3_struct mercury_data_error_util__common_3 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_error_util__common_4_struct mercury_data_error_util__common_4 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_error_util__common_5_struct mercury_data_error_util__common_5 = {
	(Integer) 0,
	MR_string_const("error_util", 10),
	MR_string_const("error_util", 10),
	MR_string_const("describe_one_proc_name", 22),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_error_util__common_6_struct mercury_data_error_util__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_error_util__common_7_struct mercury_data_error_util__common_7 = {
	(Integer) 0,
	MR_string_const("error_util", 10),
	MR_string_const("error_util", 10),
	MR_string_const("describe_one_call_site", 22),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_error_util__common_8_struct mercury_data_error_util__common_8 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_error_util__common_9_struct mercury_data_error_util__common_9 = {
	(Integer) 0,
	MR_string_const("error_util", 10),
	MR_string_const("error_util", 10),
	MR_string_const("IntroducedFrom__pred__report_error_num_args__407__1", 51),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_8)
};

static const struct mercury_data_error_util__common_10_struct mercury_data_error_util__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_9),
	STATIC(mercury__error_util__IntroducedFrom__pred__report_error_num_args__407__1_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_error_util__common_11_struct mercury_data_error_util__common_11 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_error_util__common_12_struct mercury_data_error_util__common_12 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_4),
	MR_string_const("fixed", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_error_util__common_13_struct mercury_data_error_util__common_13 = {
	(Integer) 0,
	MR_string_const("nl", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_error_util__common_14_struct mercury_data_error_util__common_14 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_4),
	MR_string_const("words", 5),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_error_util__common_15_struct mercury_data_error_util__common_15 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("nl", 2)
};

static const struct mercury_data_error_util__type_ctor_functors_format_component_0_struct mercury_data_error_util__type_ctor_functors_format_component_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_14)
};

static const struct mercury_data_error_util__type_ctor_layout_format_component_0_struct mercury_data_error_util__type_ctor_layout_format_component_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_15),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_error_util__common_12),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_error_util__common_14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

Declare_entry(mercury__hlds_pred__adjust_func_arity_3_1);

BEGIN_MODULE(error_util_module0)
	init_entry(mercury__error_util__IntroducedFrom__pred__report_error_num_args__407__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__report_error_num_args__407__1'/2 in mode 0 */
Define_static(mercury__error_util__IntroducedFrom__pred__report_error_num_args__407__1_2_0);
	r2 = r1;
	r1 = (Integer) 1;
	tailcall(ENTRY(mercury__hlds_pred__adjust_func_arity_3_1),
		STATIC(mercury__error_util__IntroducedFrom__pred__report_error_num_args__407__1_2_0));
END_MODULE

Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(error_util_module1)
	init_entry(mercury__error_util__list_to_pieces_2_0);
	init_label(mercury__error_util__list_to_pieces_2_0_i3);
	init_label(mercury__error_util__list_to_pieces_2_0_i5);
	init_label(mercury__error_util__list_to_pieces_2_0_i8);
	init_label(mercury__error_util__list_to_pieces_2_0_i9);
	init_label(mercury__error_util__list_to_pieces_2_0_i7);
BEGIN_CODE

/* code for predicate 'list_to_pieces'/2 in mode 0 */
Define_entry(mercury__error_util__list_to_pieces_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__list_to_pieces_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__error_util__list_to_pieces_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__list_to_pieces_2_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__list_to_pieces_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__error_util__list_to_pieces_2_0, "error_util:format_component/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__error_util__list_to_pieces_2_0_i5);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__list_to_pieces_2_0_i7);
	MR_incr_sp_push_msg(2, "error_util:list_to_pieces/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const(",", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__error_util__list_to_pieces_2_0_i8,
		ENTRY(mercury__error_util__list_to_pieces_2_0));
Define_label(mercury__error_util__list_to_pieces_2_0_i8);
	update_prof_current_proc(LABEL(mercury__error_util__list_to_pieces_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__error_util__list_to_pieces_2_0,
		LABEL(mercury__error_util__list_to_pieces_2_0_i9),
		ENTRY(mercury__error_util__list_to_pieces_2_0));
Define_label(mercury__error_util__list_to_pieces_2_0_i9);
	update_prof_current_proc(LABEL(mercury__error_util__list_to_pieces_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__list_to_pieces_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__error_util__list_to_pieces_2_0, "error_util:format_component/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__error_util__list_to_pieces_2_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__list_to_pieces_2_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__error_util__list_to_pieces_2_0, "error_util:format_component/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__list_to_pieces_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_error_util__common_0);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__error_util__list_to_pieces_2_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__error_util__list_to_pieces_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
	}
END_MODULE

Declare_entry(mercury__term__context_file_2_0);
Declare_entry(mercury__term__context_line_2_0);
Declare_entry(mercury__string__length_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__prog_out__write_context_3_0);
Declare_entry(mercury__string__pad_left_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_char_3_0);

BEGIN_MODULE(error_util_module2)
	init_entry(mercury__error_util__write_error_pieces_5_0);
	init_label(mercury__error_util__write_error_pieces_5_0_i2);
	init_label(mercury__error_util__write_error_pieces_5_0_i3);
	init_label(mercury__error_util__write_error_pieces_5_0_i4);
	init_label(mercury__error_util__write_error_pieces_5_0_i5);
	init_label(mercury__error_util__write_error_pieces_5_0_i6);
	init_label(mercury__error_util__write_error_pieces_5_0_i7);
	init_label(mercury__error_util__write_error_pieces_5_0_i9);
	init_label(mercury__error_util__write_error_pieces_5_0_i10);
	init_label(mercury__error_util__write_error_pieces_5_0_i12);
	init_label(mercury__error_util__write_error_pieces_5_0_i13);
	init_label(mercury__error_util__write_error_pieces_5_0_i14);
	init_label(mercury__error_util__write_error_pieces_5_0_i15);
	init_label(mercury__error_util__write_error_pieces_5_0_i1002);
	init_label(mercury__error_util__write_error_pieces_5_0_i17);
	init_label(mercury__error_util__write_error_pieces_5_0_i18);
	init_label(mercury__error_util__write_error_pieces_5_0_i19);
BEGIN_CODE

/* code for predicate 'write_error_pieces'/5 in mode 0 */
Define_entry(mercury__error_util__write_error_pieces_5_0);
	MR_incr_sp_push_msg(6, "error_util:write_error_pieces/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__term__context_file_2_0),
		mercury__error_util__write_error_pieces_5_0_i2,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__error_util__write_error_pieces_5_0_i3,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i3);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__error_util__write_error_pieces_5_0_i4,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__error_util__write_error_pieces_5_0_i5,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__error_util__write_error_pieces_5_0_i6,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	if (((Integer) r1 >= (Integer) 3))
		GOTO_LABEL(mercury__error_util__write_error_pieces_5_0_i7);
	r1 = MR_stackvar(3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(3) = (((Integer) 0 - (((Integer) MR_stackvar(5) + (Integer) 6) + (Integer) MR_stackvar(2))) + (Integer) 79);
	call_localret(STATIC(mercury__error_util__convert_components_to_word_list_4_0),
		mercury__error_util__write_error_pieces_5_0_i9,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i7);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = (((Integer) 0 - (((((Integer) MR_stackvar(5) + (Integer) 1) + (Integer) MR_tempr1) + (Integer) 2) + (Integer) MR_stackvar(2))) + (Integer) 79);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__error_util__convert_components_to_word_list_4_0),
		mercury__error_util__write_error_pieces_5_0_i9,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
	}
Define_label(mercury__error_util__write_error_pieces_5_0_i9);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = r1;
	r1 = (Integer) 1;
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__error_util__group_words_4_0),
		mercury__error_util__write_error_pieces_5_0_i10,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i10);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__write_error_pieces_5_0_i12);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__error_util__write_error_pieces_5_0_i12);
	r2 = MR_stackvar(4);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__error_util__write_error_pieces_5_0_i13,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i13);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("", 0);
	r2 = (Integer) 32;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__pad_left_4_0),
		mercury__error_util__write_error_pieces_5_0_i14,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i14);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__write_error_pieces_5_0_i15,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i15);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	if (((Integer) MR_stackvar(3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__write_error_pieces_5_0_i17);
Define_label(mercury__error_util__write_error_pieces_5_0_i1002);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = ((Integer) MR_stackvar(2) + (Integer) 2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__error_util__write_nonfirst_lines_5_0),
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i17);
	r2 = r1;
	r3 = MR_stackvar(3);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__write_error_pieces_5_0_i18,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i18);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__error_util__write_line_rest_3_0),
		mercury__error_util__write_error_pieces_5_0_i19,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
Define_label(mercury__error_util__write_error_pieces_5_0_i19);
	update_prof_current_proc(LABEL(mercury__error_util__write_error_pieces_5_0));
	r2 = r1;
	r1 = (Integer) 10;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__error_util__write_error_pieces_5_0_i1002,
		ENTRY(mercury__error_util__write_error_pieces_5_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(error_util_module3)
	init_entry(mercury__error_util__report_warning_5_0);
	init_label(mercury__error_util__report_warning_5_0_i2);
	init_label(mercury__error_util__report_warning_5_0_i5);
	init_label(mercury__error_util__report_warning_5_0_i3);
BEGIN_CODE

/* code for predicate 'report_warning'/5 in mode 0 */
Define_entry(mercury__error_util__report_warning_5_0);
	MR_incr_sp_push_msg(4, "error_util:report_warning/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 1;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__error_util__report_warning_5_0_i2,
		ENTRY(mercury__error_util__report_warning_5_0));
Define_label(mercury__error_util__report_warning_5_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__report_warning_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__error_util__report_warning_5_0_i3);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__error_util__report_warning_5_0_i5,
		ENTRY(mercury__error_util__report_warning_5_0));
Define_label(mercury__error_util__report_warning_5_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__report_warning_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__error_util__write_error_pieces_5_0),
		ENTRY(mercury__error_util__report_warning_5_0));
Define_label(mercury__error_util__report_warning_5_0_i3);
	r4 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__error_util__write_error_pieces_5_0),
		ENTRY(mercury__error_util__report_warning_5_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(error_util_module4)
	init_entry(mercury__error_util__describe_one_pred_name_3_0);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i2);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i3);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i4);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i5);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i6);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i7);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i9);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i11);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i10);
	init_label(mercury__error_util__describe_one_pred_name_3_0_i12);
BEGIN_CODE

/* code for predicate 'describe_one_pred_name'/3 in mode 0 */
Define_entry(mercury__error_util__describe_one_pred_name_3_0);
	MR_incr_sp_push_msg(5, "error_util:describe_one_pred_name/3");
	MR_stackvar(5) = (Word) MR_succip;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__error_util__describe_one_pred_name_3_0_i2,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i3,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i4,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i5,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i6,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i7,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i7);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__error_util__describe_one_pred_name_3_0_i9);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = (Word) MR_string_const("predicate", 9);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_goal_type_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i11,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i9);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = (Word) MR_string_const("function", 8);
	MR_stackvar(4) = ((Integer) MR_stackvar(4) + (Integer) -1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_goal_type_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i11,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i11);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	if (((Integer) 2 != (Integer) r1))
		GOTO_LABEL(mercury__error_util__describe_one_pred_name_3_0_i10);
	r1 = (Word) MR_string_const("promise", 7);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__error_util__describe_one_pred_name_3_0_i10);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__error_util__describe_one_pred_name_3_0_i12,
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
Define_label(mercury__error_util__describe_one_pred_name_3_0_i12);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_pred_name_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" `", 2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(":", 1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_pred_name_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_error_util__common_1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__error_util__describe_one_pred_name_3_0));
	}
END_MODULE

Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);

BEGIN_MODULE(error_util_module5)
	init_entry(mercury__error_util__describe_one_proc_name_3_0);
	init_label(mercury__error_util__describe_one_proc_name_3_0_i2);
	init_label(mercury__error_util__describe_one_proc_name_3_0_i3);
	init_label(mercury__error_util__describe_one_proc_name_3_0_i4);
BEGIN_CODE

/* code for predicate 'describe_one_proc_name'/3 in mode 0 */
Define_entry(mercury__error_util__describe_one_proc_name_3_0);
	MR_incr_sp_push_msg(2, "error_util:describe_one_proc_name/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__error_util__describe_one_pred_name_3_0),
		mercury__error_util__describe_one_proc_name_3_0_i2,
		ENTRY(mercury__error_util__describe_one_proc_name_3_0));
Define_label(mercury__error_util__describe_one_proc_name_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_proc_name_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__error_util__describe_one_proc_name_3_0_i3,
		ENTRY(mercury__error_util__describe_one_proc_name_3_0));
Define_label(mercury__error_util__describe_one_proc_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_proc_name_3_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__error_util__describe_one_proc_name_3_0_i4,
		ENTRY(mercury__error_util__describe_one_proc_name_3_0));
Define_label(mercury__error_util__describe_one_proc_name_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_proc_name_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_proc_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_proc_name_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" mode ", 6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_proc_name_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__error_util__describe_one_proc_name_3_0));
	}
END_MODULE

Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(error_util_module6)
	init_entry(mercury__error_util__describe_several_proc_names_3_0);
	init_label(mercury__error_util__describe_several_proc_names_3_0_i2);
BEGIN_CODE

/* code for predicate 'describe_several_proc_names'/3 in mode 0 */
Define_entry(mercury__error_util__describe_several_proc_names_3_0);
	MR_incr_sp_push_msg(1, "error_util:describe_several_proc_names/3");
	MR_stackvar(1) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__error_util__describe_several_proc_names_3_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__error_util__describe_one_proc_name_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_5);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__error_util__describe_several_proc_names_3_0_i2,
		ENTRY(mercury__error_util__describe_several_proc_names_3_0));
Define_label(mercury__error_util__describe_several_proc_names_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__describe_several_proc_names_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__error_util__list_to_pieces_2_0),
		ENTRY(mercury__error_util__describe_several_proc_names_3_0));
END_MODULE


BEGIN_MODULE(error_util_module7)
	init_entry(mercury__error_util__describe_one_call_site_3_0);
	init_label(mercury__error_util__describe_one_call_site_3_0_i2);
	init_label(mercury__error_util__describe_one_call_site_3_0_i3);
	init_label(mercury__error_util__describe_one_call_site_3_0_i4);
	init_label(mercury__error_util__describe_one_call_site_3_0_i5);
BEGIN_CODE

/* code for predicate 'describe_one_call_site'/3 in mode 0 */
Define_entry(mercury__error_util__describe_one_call_site_3_0);
	MR_incr_sp_push_msg(3, "error_util:describe_one_call_site/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__error_util__describe_one_proc_name_3_0),
		mercury__error_util__describe_one_call_site_3_0_i2,
		ENTRY(mercury__error_util__describe_one_call_site_3_0));
Define_label(mercury__error_util__describe_one_call_site_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_call_site_3_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term__context_file_2_0),
		mercury__error_util__describe_one_call_site_3_0_i3,
		ENTRY(mercury__error_util__describe_one_call_site_3_0));
Define_label(mercury__error_util__describe_one_call_site_3_0_i3);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_call_site_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__error_util__describe_one_call_site_3_0_i4,
		ENTRY(mercury__error_util__describe_one_call_site_3_0));
Define_label(mercury__error_util__describe_one_call_site_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_call_site_3_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__error_util__describe_one_call_site_3_0_i5,
		ENTRY(mercury__error_util__describe_one_call_site_3_0));
Define_label(mercury__error_util__describe_one_call_site_3_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__describe_one_call_site_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_call_site_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_call_site_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" at ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_call_site_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_call_site_3_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(":", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__error_util__describe_one_call_site_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__error_util__describe_one_call_site_3_0));
	}
END_MODULE


BEGIN_MODULE(error_util_module8)
	init_entry(mercury__error_util__describe_several_call_sites_3_0);
	init_label(mercury__error_util__describe_several_call_sites_3_0_i2);
BEGIN_CODE

/* code for predicate 'describe_several_call_sites'/3 in mode 0 */
Define_entry(mercury__error_util__describe_several_call_sites_3_0);
	MR_incr_sp_push_msg(1, "error_util:describe_several_call_sites/3");
	MR_stackvar(1) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__error_util__describe_several_call_sites_3_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_6);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__error_util__describe_one_call_site_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_7);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__error_util__describe_several_call_sites_3_0_i2,
		ENTRY(mercury__error_util__describe_several_call_sites_3_0));
Define_label(mercury__error_util__describe_several_call_sites_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__describe_several_call_sites_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__error_util__list_to_pieces_2_0),
		ENTRY(mercury__error_util__describe_several_call_sites_3_0));
END_MODULE

Declare_entry(mercury__io__write_int_3_0);

BEGIN_MODULE(error_util_module9)
	init_entry(mercury__error_util__report_error_num_args_5_0);
	init_label(mercury__error_util__report_error_num_args_5_0_i5);
	init_label(mercury__error_util__report_error_num_args_5_0_i6);
	init_label(mercury__error_util__report_error_num_args_5_0_i2);
	init_label(mercury__error_util__report_error_num_args_5_0_i8);
	init_label(mercury__error_util__report_error_num_args_5_0_i9);
	init_label(mercury__error_util__report_error_num_args_5_0_i10);
	init_label(mercury__error_util__report_error_num_args_5_0_i11);
BEGIN_CODE

/* code for predicate 'report_error_num_args'/5 in mode 0 */
Define_entry(mercury__error_util__report_error_num_args_5_0);
	MR_incr_sp_push_msg(3, "error_util:report_error_num_args/5");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__report_error_num_args_5_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__error_util__report_error_num_args_5_0_i2);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_pred__adjust_func_arity_3_1),
		mercury__error_util__report_error_num_args_5_0_i5,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_10);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__error_util__report_error_num_args_5_0_i6,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("wrong number of arguments (", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__report_error_num_args_5_0_i8,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i2);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("wrong number of arguments (", 27);
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__report_error_num_args_5_0_i8,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i8);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__error_util__report_error_num_args_5_0_i9,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i9);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("; should be ", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__report_error_num_args_5_0_i10,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i10);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__error_util__report_error_right_num_args_3_0),
		mercury__error_util__report_error_num_args_5_0_i11,
		ENTRY(mercury__error_util__report_error_num_args_5_0));
Define_label(mercury__error_util__report_error_num_args_5_0_i11);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_num_args_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__error_util__report_error_num_args_5_0));
END_MODULE


BEGIN_MODULE(error_util_module10)
	init_entry(mercury__error_util__write_nonfirst_lines_5_0);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i1003);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i4);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i5);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i6);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i1001);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i8);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i9);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i10);
	init_label(mercury__error_util__write_nonfirst_lines_5_0_i3);
BEGIN_CODE

/* code for predicate 'write_nonfirst_lines'/5 in mode 0 */
Define_static(mercury__error_util__write_nonfirst_lines_5_0);
	MR_incr_sp_push_msg(6, "error_util:write_nonfirst_lines/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__write_nonfirst_lines_5_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__error_util__write_nonfirst_lines_5_0_i4,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("", 0);
	r2 = (Integer) 32;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__pad_left_4_0),
		mercury__error_util__write_nonfirst_lines_5_0_i5,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__write_nonfirst_lines_5_0_i6,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	if (((Integer) MR_stackvar(3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__write_nonfirst_lines_5_0_i8);
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i1001);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__error_util__write_nonfirst_lines_5_0_i1003);
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i8);
	r2 = r1;
	r3 = MR_stackvar(3);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__write_nonfirst_lines_5_0_i9,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i9);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__error_util__write_line_rest_3_0),
		mercury__error_util__write_nonfirst_lines_5_0_i10,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i10);
	update_prof_current_proc(LABEL(mercury__error_util__write_nonfirst_lines_5_0));
	r2 = r1;
	r1 = (Integer) 10;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__error_util__write_nonfirst_lines_5_0_i1001,
		STATIC(mercury__error_util__write_nonfirst_lines_5_0));
Define_label(mercury__error_util__write_nonfirst_lines_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module11)
	init_entry(mercury__error_util__write_line_rest_3_0);
	init_label(mercury__error_util__write_line_rest_3_0_i1001);
	init_label(mercury__error_util__write_line_rest_3_0_i4);
	init_label(mercury__error_util__write_line_rest_3_0_i5);
	init_label(mercury__error_util__write_line_rest_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_line_rest'/3 in mode 0 */
Define_static(mercury__error_util__write_line_rest_3_0);
	MR_incr_sp_push_msg(3, "error_util:write_line_rest/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__error_util__write_line_rest_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__write_line_rest_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Integer) 32;
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__error_util__write_line_rest_3_0_i4,
		STATIC(mercury__error_util__write_line_rest_3_0));
Define_label(mercury__error_util__write_line_rest_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__write_line_rest_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__write_line_rest_3_0_i5,
		STATIC(mercury__error_util__write_line_rest_3_0));
Define_label(mercury__error_util__write_line_rest_3_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__write_line_rest_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__error_util__write_line_rest_3_0_i1001);
Define_label(mercury__error_util__write_line_rest_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(error_util_module12)
	init_entry(mercury__error_util__convert_components_to_word_list_4_0);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i1003);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i9);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i7);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i8);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i6);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i3);
	init_label(mercury__error_util__convert_components_to_word_list_4_0_i11);
BEGIN_CODE

/* code for predicate 'convert_components_to_word_list'/4 in mode 0 */
Define_static(mercury__error_util__convert_components_to_word_list_4_0);
	MR_incr_sp_push_msg(3, "error_util:convert_components_to_word_list/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r4) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i6);
	if ((MR_tag(r4) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i7);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__error_util__convert_components_to_word_list_4_0_i9,
		STATIC(mercury__error_util__convert_components_to_word_list_4_0));
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i9);
	update_prof_current_proc(LABEL(mercury__error_util__convert_components_to_word_list_4_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__convert_components_to_word_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i1003);
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i7);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__error_util__break_into_words_from_4_0),
		mercury__error_util__convert_components_to_word_list_4_0_i8,
		STATIC(mercury__error_util__convert_components_to_word_list_4_0));
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i8);
	update_prof_current_proc(LABEL(mercury__error_util__convert_components_to_word_list_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i1003);
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i6);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__error_util__convert_components_to_word_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__error_util__convert_components_to_word_list_4_0_i1003);
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i3);
	MR_stackvar(1) = r3;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__error_util__convert_components_to_word_list_4_0_i11,
		STATIC(mercury__error_util__convert_components_to_word_list_4_0));
Define_label(mercury__error_util__convert_components_to_word_list_4_0_i11);
	update_prof_current_proc(LABEL(mercury__error_util__convert_components_to_word_list_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__error_util__convert_components_to_word_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__error_util__convert_components_to_word_list_4_0));
END_MODULE

Declare_entry(mercury__string__substring_4_0);

BEGIN_MODULE(error_util_module13)
	init_entry(mercury__error_util__break_into_words_from_4_0);
	init_label(mercury__error_util__break_into_words_from_4_0_i1001);
	init_label(mercury__error_util__break_into_words_from_4_0_i4);
	init_label(mercury__error_util__break_into_words_from_4_0_i6);
	init_label(mercury__error_util__break_into_words_from_4_0_i7);
	init_label(mercury__error_util__break_into_words_from_4_0_i2);
BEGIN_CODE

/* code for predicate 'break_into_words_from'/4 in mode 0 */
Define_static(mercury__error_util__break_into_words_from_4_0);
	MR_incr_sp_push_msg(4, "error_util:break_into_words_from/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__error_util__break_into_words_from_4_0_i1001);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__error_util__find_word_start_3_0),
		mercury__error_util__break_into_words_from_4_0_i4,
		STATIC(mercury__error_util__break_into_words_from_4_0));
Define_label(mercury__error_util__break_into_words_from_4_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__break_into_words_from_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__error_util__break_into_words_from_4_0_i2);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__error_util__find_word_end_3_0),
		mercury__error_util__break_into_words_from_4_0_i6,
		STATIC(mercury__error_util__break_into_words_from_4_0));
Define_label(mercury__error_util__break_into_words_from_4_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__break_into_words_from_4_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r3 = (((Integer) MR_stackvar(3) - (Integer) r2) + (Integer) 1);
	call_localret(ENTRY(mercury__string__substring_4_0),
		mercury__error_util__break_into_words_from_4_0_i7,
		STATIC(mercury__error_util__break_into_words_from_4_0));
Define_label(mercury__error_util__break_into_words_from_4_0_i7);
	update_prof_current_proc(LABEL(mercury__error_util__break_into_words_from_4_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__break_into_words_from_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	r2 = ((Integer) MR_stackvar(3) + (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__error_util__break_into_words_from_4_0_i1001);
Define_label(mercury__error_util__break_into_words_from_4_0_i2);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__string__index_3_0);
Declare_entry(mercury__char__is_whitespace_1_0);

BEGIN_MODULE(error_util_module14)
	init_entry(mercury__error_util__find_word_start_3_0);
	init_label(mercury__error_util__find_word_start_3_0_i1002);
	init_label(mercury__error_util__find_word_start_3_0_i2);
	init_label(mercury__error_util__find_word_start_3_0_i6);
	init_label(mercury__error_util__find_word_start_3_0_i5);
	init_label(mercury__error_util__find_word_start_3_0_i1);
BEGIN_CODE

/* code for predicate 'find_word_start'/3 in mode 0 */
Define_static(mercury__error_util__find_word_start_3_0);
	MR_incr_sp_push_msg(3, "error_util:find_word_start/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__error_util__find_word_start_3_0_i1002);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__index_3_0),
		mercury__error_util__find_word_start_3_0_i2,
		STATIC(mercury__error_util__find_word_start_3_0));
Define_label(mercury__error_util__find_word_start_3_0_i2);
	update_prof_current_proc(LABEL(mercury__error_util__find_word_start_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__error_util__find_word_start_3_0_i1);
	r1 = r2;
	call_localret(ENTRY(mercury__char__is_whitespace_1_0),
		mercury__error_util__find_word_start_3_0_i6,
		STATIC(mercury__error_util__find_word_start_3_0));
Define_label(mercury__error_util__find_word_start_3_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__find_word_start_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__error_util__find_word_start_3_0_i5);
	r1 = MR_stackvar(1);
	r2 = ((Integer) MR_stackvar(2) + (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__error_util__find_word_start_3_0_i1002);
Define_label(mercury__error_util__find_word_start_3_0_i5);
	r2 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__error_util__find_word_start_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module15)
	init_entry(mercury__error_util__find_word_end_3_0);
	init_label(mercury__error_util__find_word_end_3_0_i1002);
	init_label(mercury__error_util__find_word_end_3_0_i4);
	init_label(mercury__error_util__find_word_end_3_0_i8);
	init_label(mercury__error_util__find_word_end_3_0_i1004);
	init_label(mercury__error_util__find_word_end_3_0_i7);
BEGIN_CODE

/* code for predicate 'find_word_end'/3 in mode 0 */
Define_static(mercury__error_util__find_word_end_3_0);
	MR_incr_sp_push_msg(4, "error_util:find_word_end/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__error_util__find_word_end_3_0_i1002);
	MR_stackvar(2) = r2;
	r2 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__string__index_3_0),
		mercury__error_util__find_word_end_3_0_i4,
		STATIC(mercury__error_util__find_word_end_3_0));
Define_label(mercury__error_util__find_word_end_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__find_word_end_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__error_util__find_word_end_3_0_i1004);
	r1 = r2;
	call_localret(ENTRY(mercury__char__is_whitespace_1_0),
		mercury__error_util__find_word_end_3_0_i8,
		STATIC(mercury__error_util__find_word_end_3_0));
Define_label(mercury__error_util__find_word_end_3_0_i8);
	update_prof_current_proc(LABEL(mercury__error_util__find_word_end_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__error_util__find_word_end_3_0_i7);
Define_label(mercury__error_util__find_word_end_3_0_i1004);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__error_util__find_word_end_3_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__error_util__find_word_end_3_0_i1002);
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(error_util_module16)
	init_entry(mercury__error_util__group_words_4_0);
	init_label(mercury__error_util__group_words_4_0_i1003);
	init_label(mercury__error_util__group_words_4_0_i5);
	init_label(mercury__error_util__group_words_4_0_i7);
	init_label(mercury__error_util__group_words_4_0_i8);
	init_label(mercury__error_util__group_words_4_0_i9);
	init_label(mercury__error_util__group_words_4_0_i11);
	init_label(mercury__error_util__group_words_4_0_i12);
	init_label(mercury__error_util__group_words_4_0_i13);
	init_label(mercury__error_util__group_words_4_0_i3);
BEGIN_CODE

/* code for predicate 'group_words'/4 in mode 0 */
Define_static(mercury__error_util__group_words_4_0);
	MR_incr_sp_push_msg(6, "error_util:group_words/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__error_util__group_words_4_0_i1003);
	while (1) {
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__group_words_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__group_words_4_0_i5);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	/* continue */ } /* end while */
Define_label(mercury__error_util__group_words_4_0_i5);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__error_util__group_words_4_0_i7,
		STATIC(mercury__error_util__group_words_4_0));
	}
Define_label(mercury__error_util__group_words_4_0_i7);
	update_prof_current_proc(LABEL(mercury__error_util__group_words_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__error_util__group_words_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__error_util__get_later_words_6_0),
		mercury__error_util__group_words_4_0_i8,
		STATIC(mercury__error_util__group_words_4_0));
Define_label(mercury__error_util__group_words_4_0_i8);
	update_prof_current_proc(LABEL(mercury__error_util__group_words_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__error_util__group_words_4_0_i9);
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = ((Integer) MR_stackvar(2) + (Integer) -2);
	GOTO_LABEL(mercury__error_util__group_words_4_0_i11);
Define_label(mercury__error_util__group_words_4_0_i9);
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = MR_stackvar(2);
Define_label(mercury__error_util__group_words_4_0_i11);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__error_util__group_nonfirst_line_words_3_0),
		mercury__error_util__group_words_4_0_i12,
		STATIC(mercury__error_util__group_words_4_0));
Define_label(mercury__error_util__group_words_4_0_i12);
	update_prof_current_proc(LABEL(mercury__error_util__group_words_4_0));
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__error_util__group_words_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r1 = (Integer) 0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	localcall(mercury__error_util__group_words_4_0,
		LABEL(mercury__error_util__group_words_4_0_i13),
		STATIC(mercury__error_util__group_words_4_0));
	}
Define_label(mercury__error_util__group_words_4_0_i13);
	update_prof_current_proc(LABEL(mercury__error_util__group_words_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_error_util__common_11);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__error_util__group_words_4_0));
Define_label(mercury__error_util__group_words_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module17)
	init_entry(mercury__error_util__group_nonfirst_line_words_3_0);
	init_label(mercury__error_util__group_nonfirst_line_words_3_0_i4);
	init_label(mercury__error_util__group_nonfirst_line_words_3_0_i5);
	init_label(mercury__error_util__group_nonfirst_line_words_3_0_i6);
	init_label(mercury__error_util__group_nonfirst_line_words_3_0_i3);
BEGIN_CODE

/* code for predicate 'group_nonfirst_line_words'/3 in mode 0 */
Define_static(mercury__error_util__group_nonfirst_line_words_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__group_nonfirst_line_words_3_0_i3);
	MR_incr_sp_push_msg(4, "error_util:group_nonfirst_line_words/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__error_util__group_nonfirst_line_words_3_0_i4,
		STATIC(mercury__error_util__group_nonfirst_line_words_3_0));
Define_label(mercury__error_util__group_nonfirst_line_words_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__group_nonfirst_line_words_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__error_util__group_nonfirst_line_words_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__error_util__get_later_words_6_0),
		mercury__error_util__group_nonfirst_line_words_3_0_i5,
		STATIC(mercury__error_util__group_nonfirst_line_words_3_0));
Define_label(mercury__error_util__group_nonfirst_line_words_3_0_i5);
	update_prof_current_proc(LABEL(mercury__error_util__group_nonfirst_line_words_3_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = r3;
	localcall(mercury__error_util__group_nonfirst_line_words_3_0,
		LABEL(mercury__error_util__group_nonfirst_line_words_3_0_i6),
		STATIC(mercury__error_util__group_nonfirst_line_words_3_0));
Define_label(mercury__error_util__group_nonfirst_line_words_3_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__group_nonfirst_line_words_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__error_util__group_nonfirst_line_words_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__error_util__group_nonfirst_line_words_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module18)
	init_entry(mercury__error_util__get_later_words_6_0);
	init_label(mercury__error_util__get_later_words_6_0_i1002);
	init_label(mercury__error_util__get_later_words_6_0_i3);
	init_label(mercury__error_util__get_later_words_6_0_i4);
	init_label(mercury__error_util__get_later_words_6_0_i6);
	init_label(mercury__error_util__get_later_words_6_0_i5);
BEGIN_CODE

/* code for predicate 'get_later_words'/6 in mode 0 */
Define_static(mercury__error_util__get_later_words_6_0);
	MR_incr_sp_push_msg(7, "error_util:get_later_words/6");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__error_util__get_later_words_6_0_i1002);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__get_later_words_6_0_i3);
	r1 = r4;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__error_util__get_later_words_6_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__error_util__get_later_words_6_0_i4,
		STATIC(mercury__error_util__get_later_words_6_0));
Define_label(mercury__error_util__get_later_words_6_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__get_later_words_6_0));
	r2 = (((Integer) MR_stackvar(2) + (Integer) 1) + (Integer) r1);
	if (((Integer) r2 > (Integer) MR_stackvar(3)))
		GOTO_LABEL(mercury__error_util__get_later_words_6_0_i5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__error_util__get_later_words_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__error_util__get_later_words_6_0_i6,
		STATIC(mercury__error_util__get_later_words_6_0));
Define_label(mercury__error_util__get_later_words_6_0_i6);
	update_prof_current_proc(LABEL(mercury__error_util__get_later_words_6_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__error_util__get_later_words_6_0_i1002);
Define_label(mercury__error_util__get_later_words_6_0_i5);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module19)
	init_entry(mercury__error_util__report_error_right_num_args_3_0);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i1005);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i4);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i1001);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i5);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i7);
	init_label(mercury__error_util__report_error_right_num_args_3_0_i3);
BEGIN_CODE

/* code for predicate 'report_error_right_num_args'/3 in mode 0 */
Define_static(mercury__error_util__report_error_right_num_args_3_0);
	MR_incr_sp_push_msg(2, "error_util:report_error_right_num_args/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__error_util__report_error_right_num_args_3_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__report_error_right_num_args_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__error_util__report_error_right_num_args_3_0_i4,
		STATIC(mercury__error_util__report_error_right_num_args_3_0));
Define_label(mercury__error_util__report_error_right_num_args_3_0_i4);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_right_num_args_3_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__report_error_right_num_args_3_0_i5);
Define_label(mercury__error_util__report_error_right_num_args_3_0_i1001);
	update_prof_current_proc(LABEL(mercury__error_util__report_error_right_num_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__error_util__report_error_right_num_args_3_0_i1005);
Define_label(mercury__error_util__report_error_right_num_args_3_0_i5);
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__report_error_right_num_args_3_0_i7);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__error_util__report_error_right_num_args_3_0_i7);
	r2 = r1;
	r1 = (Word) MR_string_const(" or ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__report_error_right_num_args_3_0_i1001,
		STATIC(mercury__error_util__report_error_right_num_args_3_0));
Define_label(mercury__error_util__report_error_right_num_args_3_0_i7);
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__error_util__report_error_right_num_args_3_0_i1001,
		STATIC(mercury__error_util__report_error_right_num_args_3_0));
Define_label(mercury__error_util__report_error_right_num_args_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module20)
	init_entry(mercury____Unify___error_util__format_component_0_0);
	init_label(mercury____Unify___error_util__format_component_0_0_i6);
	init_label(mercury____Unify___error_util__format_component_0_0_i4);
	init_label(mercury____Unify___error_util__format_component_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___error_util__format_component_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i6);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___error_util__format_component_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(2), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___error_util__format_component_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(1), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___error_util__format_component_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___error_util__format_component_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(error_util_module21)
	init_entry(mercury____Index___error_util__format_component_0_0);
	init_label(mercury____Index___error_util__format_component_0_0_i5);
	init_label(mercury____Index___error_util__format_component_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___error_util__format_component_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___error_util__format_component_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___error_util__format_component_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___error_util__format_component_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___error_util__format_component_0_0_i4);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(error_util_module22)
	init_entry(mercury____Compare___error_util__format_component_0_0);
	init_label(mercury____Compare___error_util__format_component_0_0_i5);
	init_label(mercury____Compare___error_util__format_component_0_0_i4);
	init_label(mercury____Compare___error_util__format_component_0_0_i2);
	init_label(mercury____Compare___error_util__format_component_0_0_i9);
	init_label(mercury____Compare___error_util__format_component_0_0_i8);
	init_label(mercury____Compare___error_util__format_component_0_0_i6);
	init_label(mercury____Compare___error_util__format_component_0_0_i10);
	init_label(mercury____Compare___error_util__format_component_0_0_i11);
	init_label(mercury____Compare___error_util__format_component_0_0_i19);
	init_label(mercury____Compare___error_util__format_component_0_0_i16);
	init_label(mercury____Compare___error_util__format_component_0_0_i1019);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___error_util__format_component_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i2);
Define_label(mercury____Compare___error_util__format_component_0_0_i5);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i2);
Define_label(mercury____Compare___error_util__format_component_0_0_i4);
	r3 = (Integer) 0;
Define_label(mercury____Compare___error_util__format_component_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i6);
	}
Define_label(mercury____Compare___error_util__format_component_0_0_i9);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i6);
Define_label(mercury____Compare___error_util__format_component_0_0_i8);
	r4 = (Integer) 0;
Define_label(mercury____Compare___error_util__format_component_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___error_util__format_component_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___error_util__format_component_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i19);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i1019);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___error_util__format_component_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i1019);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___error_util__format_component_0_0));
Define_label(mercury____Compare___error_util__format_component_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___error_util__format_component_0_0_i1019);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___error_util__format_component_0_0));
Define_label(mercury____Compare___error_util__format_component_0_0_i1019);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___error_util__format_component_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__error_util_maybe_bunch_0(void)
{
	error_util_module0();
	error_util_module1();
	error_util_module2();
	error_util_module3();
	error_util_module4();
	error_util_module5();
	error_util_module6();
	error_util_module7();
	error_util_module8();
	error_util_module9();
	error_util_module10();
	error_util_module11();
	error_util_module12();
	error_util_module13();
	error_util_module14();
	error_util_module15();
	error_util_module16();
	error_util_module17();
	error_util_module18();
	error_util_module19();
	error_util_module20();
	error_util_module21();
	error_util_module22();
}

#endif

void mercury__error_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__error_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__error_util_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_error_util__type_ctor_info_format_component_0,
			error_util__format_component_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
