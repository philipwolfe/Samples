/*
** Automatically generated from `excess.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__excess__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__excess__excess_assignments_proc__ua0_3_0);
Declare_label(mercury__excess__excess_assignments_proc__ua0_3_0_i2);
Declare_label(mercury__excess__excess_assignments_proc__ua0_3_0_i3);
Declare_label(mercury__excess__excess_assignments_proc__ua0_3_0_i4);
Declare_label(mercury__excess__excess_assignments_proc__ua0_3_0_i5);
Declare_label(mercury__excess__excess_assignments_proc__ua0_3_0_i6);
Define_extern_entry(mercury__excess__excess_assignments_proc_3_0);
Declare_static(mercury__excess__excess_assignments_in_goal_4_0);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i4);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i5);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i6);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i10);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i11);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i12);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i14);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i15);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i16);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i1007);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i18);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i19);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i20);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i21);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i22);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i23);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i24);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i25);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i26);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i27);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i28);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i29);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i2);
Declare_label(mercury__excess__excess_assignments_in_goal_4_0_i31);
Declare_static(mercury__excess__excess_assignments_in_conj_6_0);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i1005);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i11);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i8);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i14);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i16);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i17);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i18);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i19);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i20);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i4);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i5);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i21);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i3);
Declare_label(mercury__excess__excess_assignments_in_conj_6_0_i24);
Declare_static(mercury__excess__excess_assignments_in_disj_4_0);
Declare_label(mercury__excess__excess_assignments_in_disj_4_0_i4);
Declare_label(mercury__excess__excess_assignments_in_disj_4_0_i5);
Declare_label(mercury__excess__excess_assignments_in_disj_4_0_i3);
Declare_static(mercury__excess__excess_assignments_in_switch_4_0);
Declare_label(mercury__excess__excess_assignments_in_switch_4_0_i4);
Declare_label(mercury__excess__excess_assignments_in_switch_4_0_i5);
Declare_label(mercury__excess__excess_assignments_in_switch_4_0_i3);

static const struct mercury_data_excess__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_excess__common_0;

static const struct mercury_data_excess__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_excess__common_1;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_excess__common_0_struct mercury_data_excess__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_excess__common_1_struct mercury_data_excess__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__varset__delete_vars_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_varset_3_0);

BEGIN_MODULE(excess_module0)
	init_entry(mercury__excess__excess_assignments_proc__ua0_3_0);
	init_label(mercury__excess__excess_assignments_proc__ua0_3_0_i2);
	init_label(mercury__excess__excess_assignments_proc__ua0_3_0_i3);
	init_label(mercury__excess__excess_assignments_proc__ua0_3_0_i4);
	init_label(mercury__excess__excess_assignments_proc__ua0_3_0_i5);
	init_label(mercury__excess__excess_assignments_proc__ua0_3_0_i6);
BEGIN_CODE

/* code for predicate 'excess_assignments_proc__ua0'/3 in mode 0 */
Define_static(mercury__excess__excess_assignments_proc__ua0_3_0);
	MR_incr_sp_push_msg(3, "excess:excess_assignments_proc__ua0/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__excess__excess_assignments_proc__ua0_3_0_i2,
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
Define_label(mercury__excess__excess_assignments_proc__ua0_3_0_i2);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_proc__ua0_3_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__excess__excess_assignments_in_goal_4_0),
		mercury__excess__excess_assignments_proc__ua0_3_0_i3,
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
Define_label(mercury__excess__excess_assignments_proc__ua0_3_0_i3);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_proc__ua0_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__excess__excess_assignments_proc__ua0_3_0_i4,
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
Define_label(mercury__excess__excess_assignments_proc__ua0_3_0_i4);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_proc__ua0_3_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__excess__excess_assignments_proc__ua0_3_0_i5,
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
Define_label(mercury__excess__excess_assignments_proc__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_proc__ua0_3_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__varset__delete_vars_3_0),
		mercury__excess__excess_assignments_proc__ua0_3_0_i6,
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
Define_label(mercury__excess__excess_assignments_proc__ua0_3_0_i6);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_proc__ua0_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_set_varset_3_0),
		STATIC(mercury__excess__excess_assignments_proc__ua0_3_0));
END_MODULE


BEGIN_MODULE(excess_module1)
	init_entry(mercury__excess__excess_assignments_proc_3_0);
BEGIN_CODE

/* code for predicate 'excess_assignments_proc'/3 in mode 0 */
Define_entry(mercury__excess__excess_assignments_proc_3_0);
	tailcall(STATIC(mercury__excess__excess_assignments_proc__ua0_3_0),
		ENTRY(mercury__excess__excess_assignments_proc_3_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
Declare_entry(mercury__f_cut_0_0);
Declare_entry(mercury__hlds_goal__par_conj_list_to_goal_3_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(excess_module2)
	init_entry(mercury__excess__excess_assignments_in_goal_4_0);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i4);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i5);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i6);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i10);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i11);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i12);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i14);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i15);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i16);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i1007);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i18);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i19);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i20);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i21);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i22);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i23);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i24);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i25);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i26);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i27);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i28);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i29);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i2);
	init_label(mercury__excess__excess_assignments_in_goal_4_0_i31);
BEGIN_CODE

/* code for predicate 'excess_assignments_in_goal'/4 in mode 0 */
Define_static(mercury__excess__excess_assignments_in_goal_4_0);
	MR_incr_sp_push_msg(6, "excess:excess_assignments_in_goal/4");
	MR_stackvar(6) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i4) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i24) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i24) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i10));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__excess__excess_assignments_in_goal_4_0_i5,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i5);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__excess__excess_assignments_in_conj_6_0),
		mercury__excess__excess_assignments_in_goal_4_0_i6,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__excess__excess_assignments_in_goal_4_0_i28,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r3, (Integer) 0),
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i11) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i24) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i14) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i16) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i18) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i20) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i24) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i25) AND
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i29));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i11);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(STATIC(mercury__excess__excess_assignments_in_switch_4_0),
		mercury__excess__excess_assignments_in_goal_4_0_i12,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__excess__excess_assignments_in_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
	}
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i14);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(STATIC(mercury__excess__excess_assignments_in_disj_4_0),
		mercury__excess__excess_assignments_in_goal_4_0_i15,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__excess__excess_assignments_in_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
	}
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i16);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	localcall(mercury__excess__excess_assignments_in_goal_4_0,
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i1007),
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i1007);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = r3;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i18);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	localcall(mercury__excess__excess_assignments_in_goal_4_0,
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i19),
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__excess__excess_assignments_in_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
	}
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i20);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r3, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	localcall(mercury__excess__excess_assignments_in_goal_4_0,
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i21),
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i21);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	localcall(mercury__excess__excess_assignments_in_goal_4_0,
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i22),
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i22);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	localcall(mercury__excess__excess_assignments_in_goal_4_0,
		LABEL(mercury__excess__excess_assignments_in_goal_4_0_i23),
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i23);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_goal_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__excess__excess_assignments_in_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(5);
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
	}
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i24);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i25);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__excess__excess_assignments_in_goal_4_0_i26,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i26);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__excess__excess_assignments_in_conj_6_0),
		mercury__excess__excess_assignments_in_goal_4_0_i27,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i27);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_goal__par_conj_list_to_goal_3_0),
		mercury__excess__excess_assignments_in_goal_4_0_i28,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i28);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i29);
	r1 = (Word) MR_string_const("detect_cse_in_goal_2: unexpected bi_implication", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__excess__excess_assignments_in_goal_4_0_i2,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	call_localret(ENTRY(mercury__f_cut_0_0),
		mercury__excess__excess_assignments_in_goal_4_0_i31,
		STATIC(mercury__excess__excess_assignments_in_goal_4_0));
Define_label(mercury__excess__excess_assignments_in_goal_4_0_i31);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_goal_4_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__goal_util__rename_vars_in_goals_4_0);
Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(excess_module3)
	init_entry(mercury__excess__excess_assignments_in_conj_6_0);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i1005);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i11);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i8);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i14);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i16);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i17);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i18);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i19);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i20);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i4);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i5);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i21);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i3);
	init_label(mercury__excess__excess_assignments_in_conj_6_0_i24);
BEGIN_CODE

/* code for predicate 'excess_assignments_in_conj'/6 in mode 0 */
Define_static(mercury__excess__excess_assignments_in_conj_6_0);
	MR_incr_sp_push_msg(10, "excess:excess_assignments_in_conj/6");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i3);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	if ((MR_tag(r7) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r7, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(3), r7, (Integer) 4)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i5);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r7, (Integer) 4);
	r2 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	r3 = r4;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__excess__excess_assignments_in_conj_6_0_i11,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
	}
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i11);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	if (r1)
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i8);
	MR_stackvar(8) = MR_stackvar(6);
	MR_stackvar(9) = MR_stackvar(7);
	GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i16);
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__excess__excess_assignments_in_conj_6_0_i14,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i14);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	if (r1)
		GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i4);
	MR_stackvar(8) = MR_stackvar(7);
	MR_stackvar(9) = MR_stackvar(6);
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i16);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__excess__excess_assignments_in_conj_6_0_i17,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i17);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_0);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(9);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__excess__excess_assignments_in_conj_6_0_i18,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i18);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r3 = r1;
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(5);
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goals_4_0),
		mercury__excess__excess_assignments_in_conj_6_0_i19,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i19);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r3 = MR_stackvar(9);
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__goal_util__rename_vars_in_goals_4_0),
		mercury__excess__excess_assignments_in_conj_6_0_i20,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i20);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r4 = MR_stackvar(3);
	r2 = r1;
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__excess__excess_assignments_in_conj_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i1005);
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r5 = MR_stackvar(5);
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i5);
	MR_stackvar(1) = r2;
	r1 = r6;
	r2 = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(9) = r5;
	call_localret(STATIC(mercury__excess__excess_assignments_in_goal_4_0),
		mercury__excess__excess_assignments_in_conj_6_0_i21,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i21);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r4 = MR_stackvar(3);
	r3 = r1;
	r1 = MR_stackvar(9);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__excess__excess_assignments_in_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r3 = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__excess__excess_assignments_in_conj_6_0_i1005);
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i3);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_excess__common_1);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__excess__excess_assignments_in_conj_6_0_i24,
		STATIC(mercury__excess__excess_assignments_in_conj_6_0));
Define_label(mercury__excess__excess_assignments_in_conj_6_0_i24);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_conj_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(excess_module4)
	init_entry(mercury__excess__excess_assignments_in_disj_4_0);
	init_label(mercury__excess__excess_assignments_in_disj_4_0_i4);
	init_label(mercury__excess__excess_assignments_in_disj_4_0_i5);
	init_label(mercury__excess__excess_assignments_in_disj_4_0_i3);
BEGIN_CODE

/* code for predicate 'excess_assignments_in_disj'/4 in mode 0 */
Define_static(mercury__excess__excess_assignments_in_disj_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__excess__excess_assignments_in_disj_4_0_i3);
	MR_incr_sp_push_msg(2, "excess:excess_assignments_in_disj/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__excess__excess_assignments_in_goal_4_0),
		mercury__excess__excess_assignments_in_disj_4_0_i4,
		STATIC(mercury__excess__excess_assignments_in_disj_4_0));
Define_label(mercury__excess__excess_assignments_in_disj_4_0_i4);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_disj_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__excess__excess_assignments_in_disj_4_0,
		LABEL(mercury__excess__excess_assignments_in_disj_4_0_i5),
		STATIC(mercury__excess__excess_assignments_in_disj_4_0));
Define_label(mercury__excess__excess_assignments_in_disj_4_0_i5);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_disj_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__excess__excess_assignments_in_disj_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__excess__excess_assignments_in_disj_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(excess_module5)
	init_entry(mercury__excess__excess_assignments_in_switch_4_0);
	init_label(mercury__excess__excess_assignments_in_switch_4_0_i4);
	init_label(mercury__excess__excess_assignments_in_switch_4_0_i5);
	init_label(mercury__excess__excess_assignments_in_switch_4_0_i3);
BEGIN_CODE

/* code for predicate 'excess_assignments_in_switch'/4 in mode 0 */
Define_static(mercury__excess__excess_assignments_in_switch_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__excess__excess_assignments_in_switch_4_0_i3);
	MR_incr_sp_push_msg(3, "excess:excess_assignments_in_switch/4");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__excess__excess_assignments_in_goal_4_0),
		mercury__excess__excess_assignments_in_switch_4_0_i4,
		STATIC(mercury__excess__excess_assignments_in_switch_4_0));
Define_label(mercury__excess__excess_assignments_in_switch_4_0_i4);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_switch_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__excess__excess_assignments_in_switch_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__excess__excess_assignments_in_switch_4_0,
		LABEL(mercury__excess__excess_assignments_in_switch_4_0_i5),
		STATIC(mercury__excess__excess_assignments_in_switch_4_0));
Define_label(mercury__excess__excess_assignments_in_switch_4_0_i5);
	update_prof_current_proc(LABEL(mercury__excess__excess_assignments_in_switch_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__excess__excess_assignments_in_switch_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__excess__excess_assignments_in_switch_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__excess_maybe_bunch_0(void)
{
	excess_module0();
	excess_module1();
	excess_module2();
	excess_module3();
	excess_module4();
	excess_module5();
}

#endif

void mercury__excess__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__excess__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__excess_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
