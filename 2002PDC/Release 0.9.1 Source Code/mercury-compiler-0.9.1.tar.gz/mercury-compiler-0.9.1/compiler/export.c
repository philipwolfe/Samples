/*
** Automatically generated from `export.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__export__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__export__get_c_export_decls_2_0);
Declare_label(mercury__export__get_c_export_decls_2_0_i2);
Declare_label(mercury__export__get_c_export_decls_2_0_i3);
Declare_label(mercury__export__get_c_export_decls_2_0_i4);
Define_extern_entry(mercury__export__get_c_export_defns_2_0);
Declare_label(mercury__export__get_c_export_defns_2_0_i2);
Declare_label(mercury__export__get_c_export_defns_2_0_i3);
Declare_label(mercury__export__get_c_export_defns_2_0_i4);
Define_extern_entry(mercury__export__produce_header_file_4_0);
Declare_label(mercury__export__produce_header_file_4_0_i3);
Declare_label(mercury__export__produce_header_file_4_0_i4);
Declare_label(mercury__export__produce_header_file_4_0_i5);
Declare_label(mercury__export__produce_header_file_4_0_i8);
Declare_label(mercury__export__produce_header_file_4_0_i9);
Declare_label(mercury__export__produce_header_file_4_0_i10);
Declare_label(mercury__export__produce_header_file_4_0_i11);
Declare_label(mercury__export__produce_header_file_4_0_i12);
Declare_label(mercury__export__produce_header_file_4_0_i13);
Declare_label(mercury__export__produce_header_file_4_0_i14);
Declare_label(mercury__export__produce_header_file_4_0_i15);
Declare_label(mercury__export__produce_header_file_4_0_i16);
Declare_label(mercury__export__produce_header_file_4_0_i17);
Declare_label(mercury__export__produce_header_file_4_0_i18);
Declare_label(mercury__export__produce_header_file_4_0_i19);
Declare_label(mercury__export__produce_header_file_4_0_i20);
Declare_label(mercury__export__produce_header_file_4_0_i21);
Declare_label(mercury__export__produce_header_file_4_0_i22);
Declare_label(mercury__export__produce_header_file_4_0_i6);
Declare_label(mercury__export__produce_header_file_4_0_i24);
Declare_label(mercury__export__produce_header_file_4_0_i25);
Declare_label(mercury__export__produce_header_file_4_0_i26);
Declare_label(mercury__export__produce_header_file_4_0_i27);
Declare_label(mercury__export__produce_header_file_4_0_i28);
Declare_label(mercury__export__produce_header_file_4_0_i29);
Define_extern_entry(mercury__export__type_to_type_string_2_0);
Declare_label(mercury__export__type_to_type_string_2_0_i2);
Declare_label(mercury__export__type_to_type_string_2_0_i7);
Declare_label(mercury__export__type_to_type_string_2_0_i12);
Declare_label(mercury__export__type_to_type_string_2_0_i17);
Define_extern_entry(mercury__export__convert_type_to_mercury_3_0);
Declare_label(mercury__export__convert_type_to_mercury_3_0_i2);
Declare_label(mercury__export__convert_type_to_mercury_3_0_i8);
Declare_label(mercury__export__convert_type_to_mercury_3_0_i1018);
Define_extern_entry(mercury__export__convert_type_from_mercury_3_0);
Declare_label(mercury__export__convert_type_from_mercury_3_0_i2);
Declare_label(mercury__export__convert_type_from_mercury_3_0_i1012);
Declare_static(mercury__export__get_c_export_decls_2_3_0);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i4);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i6);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i7);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i11);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i12);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i15);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i16);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i18);
Declare_label(mercury__export__get_c_export_decls_2_3_0_i3);
Declare_static(mercury__export__to_c_4_0);
Declare_label(mercury__export__to_c_4_0_i4);
Declare_label(mercury__export__to_c_4_0_i6);
Declare_label(mercury__export__to_c_4_0_i7);
Declare_label(mercury__export__to_c_4_0_i8);
Declare_label(mercury__export__to_c_4_0_i9);
Declare_label(mercury__export__to_c_4_0_i5);
Declare_label(mercury__export__to_c_4_0_i10);
Declare_label(mercury__export__to_c_4_0_i11);
Declare_label(mercury__export__to_c_4_0_i12);
Declare_label(mercury__export__to_c_4_0_i15);
Declare_label(mercury__export__to_c_4_0_i16);
Declare_label(mercury__export__to_c_4_0_i3);
Declare_static(mercury__export__get_export_info_9_0);
Declare_label(mercury__export__get_export_info_9_0_i2);
Declare_label(mercury__export__get_export_info_9_0_i5);
Declare_label(mercury__export__get_export_info_9_0_i3);
Declare_label(mercury__export__get_export_info_9_0_i7);
Declare_label(mercury__export__get_export_info_9_0_i8);
Declare_label(mercury__export__get_export_info_9_0_i9);
Declare_label(mercury__export__get_export_info_9_0_i10);
Declare_label(mercury__export__get_export_info_9_0_i11);
Declare_label(mercury__export__get_export_info_9_0_i12);
Declare_label(mercury__export__get_export_info_9_0_i13);
Declare_label(mercury__export__get_export_info_9_0_i14);
Declare_label(mercury__export__get_export_info_9_0_i20);
Declare_label(mercury__export__get_export_info_9_0_i24);
Declare_label(mercury__export__get_export_info_9_0_i26);
Declare_label(mercury__export__get_export_info_9_0_i27);
Declare_label(mercury__export__get_export_info_9_0_i28);
Declare_label(mercury__export__get_export_info_9_0_i30);
Declare_label(mercury__export__get_export_info_9_0_i32);
Declare_label(mercury__export__get_export_info_9_0_i33);
Declare_label(mercury__export__get_export_info_9_0_i34);
Declare_label(mercury__export__get_export_info_9_0_i35);
Declare_label(mercury__export__get_export_info_9_0_i17);
Declare_label(mercury__export__get_export_info_9_0_i18);
Declare_label(mercury__export__get_export_info_9_0_i16);
Declare_label(mercury__export__get_export_info_9_0_i38);
Declare_label(mercury__export__get_export_info_9_0_i37);
Declare_label(mercury__export__get_export_info_9_0_i39);
Declare_static(mercury__export__include_arg_1_0);
Declare_label(mercury__export__include_arg_1_0_i6);
Declare_label(mercury__export__include_arg_1_0_i1003);
Declare_label(mercury__export__include_arg_1_0_i1);
Declare_static(mercury__export__get_argument_declarations_2_4_0);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i3);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i6);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i7);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i4);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i9);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i10);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i14);
Declare_label(mercury__export__get_argument_declarations_2_4_0_i17);
Declare_static(mercury__export__get_input_args_3_0);
Declare_label(mercury__export__get_input_args_3_0_i6);
Declare_label(mercury__export__get_input_args_3_0_i7);
Declare_label(mercury__export__get_input_args_3_0_i8);
Declare_label(mercury__export__get_input_args_3_0_i9);
Declare_label(mercury__export__get_input_args_3_0_i11);
Declare_label(mercury__export__get_input_args_3_0_i10);
Declare_label(mercury__export__get_input_args_3_0_i12);
Declare_label(mercury__export__get_input_args_3_0_i14);
Declare_label(mercury__export__get_input_args_3_0_i5);
Declare_label(mercury__export__get_input_args_3_0_i16);
Declare_label(mercury__export__get_input_args_3_0_i3);
Declare_static(mercury__export__copy_output_args_3_0);
Declare_label(mercury__export__copy_output_args_3_0_i1001);
Declare_label(mercury__export__copy_output_args_3_0_i5);
Declare_label(mercury__export__copy_output_args_3_0_i7);
Declare_label(mercury__export__copy_output_args_3_0_i8);
Declare_label(mercury__export__copy_output_args_3_0_i9);
Declare_label(mercury__export__copy_output_args_3_0_i10);
Declare_label(mercury__export__copy_output_args_3_0_i12);
Declare_label(mercury__export__copy_output_args_3_0_i14);
Declare_label(mercury__export__copy_output_args_3_0_i15);
Declare_label(mercury__export__copy_output_args_3_0_i16);
Declare_label(mercury__export__copy_output_args_3_0_i3);
Declare_static(mercury__export__produce_header_file_2_3_0);
Declare_label(mercury__export__produce_header_file_2_3_0_i1001);
Declare_label(mercury__export__produce_header_file_2_3_0_i4);
Declare_label(mercury__export__produce_header_file_2_3_0_i5);
Declare_label(mercury__export__produce_header_file_2_3_0_i6);
Declare_label(mercury__export__produce_header_file_2_3_0_i7);
Declare_label(mercury__export__produce_header_file_2_3_0_i8);
Declare_label(mercury__export__produce_header_file_2_3_0_i9);
Declare_label(mercury__export__produce_header_file_2_3_0_i3);

static const struct mercury_data_export__common_0_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_0;

static const struct mercury_data_export__common_1_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_1;

static const struct mercury_data_export__common_2_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_2;

static const struct mercury_data_export__common_3_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_3;

static const struct mercury_data_export__common_4_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_4;

static const struct mercury_data_export__common_5_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_5;

static const struct mercury_data_export__common_6_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_6;

static const struct mercury_data_export__common_7_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_7;

static const struct mercury_data_export__common_8_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_8;

static const struct mercury_data_export__common_9_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_9;

static const struct mercury_data_export__common_10_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_10;

static const struct mercury_data_export__common_11_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_11;

static const struct mercury_data_export__common_12_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_12;

static const struct mercury_data_export__common_13_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_13;

static const struct mercury_data_export__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_export__common_14;

static const struct mercury_data_export__common_15_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_export__common_15;

static const struct mercury_data_export__common_16_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_16;

static const struct mercury_data_export__common_17_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_17;

static const struct mercury_data_export__common_18_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_18;

static const struct mercury_data_export__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_export__common_19;

static const struct mercury_data_export__common_20_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_export__common_20;

static const struct mercury_data_export__common_21_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_21;

static const struct mercury_data_export__common_22_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_22;

static const struct mercury_data_export__common_23_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_23;

static const struct mercury_data_export__common_24_struct {
	String f1;
	Word * f2;
}  mercury_data_export__common_24;

static const struct mercury_data_export__common_0_struct mercury_data_export__common_0 = {
	MR_string_const(".  Do not edit.\n*/\n", 19),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_1_struct mercury_data_export__common_1 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_2_struct mercury_data_export__common_2 = {
	MR_string_const("#endif\n", 7),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_1)
};

static const struct mercury_data_export__common_3_struct mercury_data_export__common_3 = {
	MR_string_const("#include \"mercury_imp.h\"\n", 25),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_2)
};

static const struct mercury_data_export__common_4_struct mercury_data_export__common_4 = {
	MR_string_const("#ifndef MERCURY_HDR_EXCLUDE_IMP_H\n", 34),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_3)
};

static const struct mercury_data_export__common_5_struct mercury_data_export__common_5 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_4)
};

static const struct mercury_data_export__common_6_struct mercury_data_export__common_6 = {
	MR_string_const("#endif\n", 7),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_5)
};

static const struct mercury_data_export__common_7_struct mercury_data_export__common_7 = {
	MR_string_const("extern \"C\" {\n", 13),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_6)
};

static const struct mercury_data_export__common_8_struct mercury_data_export__common_8 = {
	MR_string_const("#ifdef __cplusplus\n", 19),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_7)
};

static const struct mercury_data_export__common_9_struct mercury_data_export__common_9 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_8)
};

static const struct mercury_data_export__common_10_struct mercury_data_export__common_10 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_9)
};

static const struct mercury_data_export__common_11_struct mercury_data_export__common_11 = {
	MR_string_const(" */\n", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_12_struct mercury_data_export__common_12 = {
	MR_string_const(")", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_13_struct mercury_data_export__common_13 = {
	MR_string_const("}\n\n", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_export__common_14_struct mercury_data_export__common_14 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
static const struct mercury_data_export__common_15_struct mercury_data_export__common_15 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_14)
};

static const struct mercury_data_export__common_16_struct mercury_data_export__common_16 = {
	MR_string_const(" return_value;\n", 15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_17_struct mercury_data_export__common_17 = {
	MR_string_const(";\n", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_18_struct mercury_data_export__common_18 = {
	MR_string_const("\treturn return_value;\n", 22),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_19_struct mercury_data_export__common_19 = {
	(Integer) 0,
	MR_string_const("export", 6),
	MR_string_const("export", 6),
	MR_string_const("include_arg", 11),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15)
};

static const struct mercury_data_export__common_20_struct mercury_data_export__common_20 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_19),
	STATIC(mercury__export__include_arg_1_0),
	(Integer) 0
};

static const struct mercury_data_export__common_21_struct mercury_data_export__common_21 = {
	MR_string_const("\t}\n", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_export__common_22_struct mercury_data_export__common_22 = {
	MR_string_const("\treturn FALSE;\n", 15),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_21)
};

static const struct mercury_data_export__common_23_struct mercury_data_export__common_23 = {
	MR_string_const("\t\trestore_regs_from_mem(c_regs);\n", 33),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_22)
};

static const struct mercury_data_export__common_24_struct mercury_data_export__common_24 = {
	MR_string_const("\tif (!r1) {\n", 12),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_23)
};

Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_module__predicate_table_get_preds_2_0);
Declare_entry(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0);

BEGIN_MODULE(export_module0)
	init_entry(mercury__export__get_c_export_decls_2_0);
	init_label(mercury__export__get_c_export_decls_2_0_i2);
	init_label(mercury__export__get_c_export_decls_2_0_i3);
	init_label(mercury__export__get_c_export_decls_2_0_i4);
BEGIN_CODE

/* code for predicate 'get_c_export_decls'/2 in mode 0 */
Define_entry(mercury__export__get_c_export_decls_2_0);
	MR_incr_sp_push_msg(2, "export:get_c_export_decls/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__export__get_c_export_decls_2_0_i2,
		ENTRY(mercury__export__get_c_export_decls_2_0));
Define_label(mercury__export__get_c_export_decls_2_0_i2);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_0));
	call_localret(ENTRY(mercury__hlds_module__predicate_table_get_preds_2_0),
		mercury__export__get_c_export_decls_2_0_i3,
		ENTRY(mercury__export__get_c_export_decls_2_0));
Define_label(mercury__export__get_c_export_decls_2_0_i3);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__export__get_c_export_decls_2_0_i4,
		ENTRY(mercury__export__get_c_export_decls_2_0));
Define_label(mercury__export__get_c_export_decls_2_0_i4);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__export__get_c_export_decls_2_3_0),
		ENTRY(mercury__export__get_c_export_decls_2_0));
END_MODULE


BEGIN_MODULE(export_module1)
	init_entry(mercury__export__get_c_export_defns_2_0);
	init_label(mercury__export__get_c_export_defns_2_0_i2);
	init_label(mercury__export__get_c_export_defns_2_0_i3);
	init_label(mercury__export__get_c_export_defns_2_0_i4);
BEGIN_CODE

/* code for predicate 'get_c_export_defns'/2 in mode 0 */
Define_entry(mercury__export__get_c_export_defns_2_0);
	MR_incr_sp_push_msg(3, "export:get_c_export_defns/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_pragma_exported_procs_2_0),
		mercury__export__get_c_export_defns_2_0_i2,
		ENTRY(mercury__export__get_c_export_defns_2_0));
Define_label(mercury__export__get_c_export_defns_2_0_i2);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_defns_2_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__export__get_c_export_defns_2_0_i3,
		ENTRY(mercury__export__get_c_export_defns_2_0));
Define_label(mercury__export__get_c_export_defns_2_0_i3);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_defns_2_0));
	call_localret(ENTRY(mercury__hlds_module__predicate_table_get_preds_2_0),
		mercury__export__get_c_export_defns_2_0_i4,
		ENTRY(mercury__export__get_c_export_defns_2_0));
Define_label(mercury__export__get_c_export_defns_2_0_i4);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_defns_2_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__export__to_c_4_0),
		ENTRY(mercury__export__get_c_export_defns_2_0));
END_MODULE

Declare_entry(mercury__modules__module_name_to_file_name_6_0);
Declare_entry(mercury__io__tell_4_0);
Declare_entry(mercury__library__version_1_0);
Declare_entry(mercury__io__write_strings_3_0);
Declare_entry(mercury__llds_out__sym_name_mangle_2_0);
Declare_entry(mercury__string__to_upper_2_0);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__told_2_0);
Declare_entry(mercury__io__progname_base_4_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(export_module2)
	init_entry(mercury__export__produce_header_file_4_0);
	init_label(mercury__export__produce_header_file_4_0_i3);
	init_label(mercury__export__produce_header_file_4_0_i4);
	init_label(mercury__export__produce_header_file_4_0_i5);
	init_label(mercury__export__produce_header_file_4_0_i8);
	init_label(mercury__export__produce_header_file_4_0_i9);
	init_label(mercury__export__produce_header_file_4_0_i10);
	init_label(mercury__export__produce_header_file_4_0_i11);
	init_label(mercury__export__produce_header_file_4_0_i12);
	init_label(mercury__export__produce_header_file_4_0_i13);
	init_label(mercury__export__produce_header_file_4_0_i14);
	init_label(mercury__export__produce_header_file_4_0_i15);
	init_label(mercury__export__produce_header_file_4_0_i16);
	init_label(mercury__export__produce_header_file_4_0_i17);
	init_label(mercury__export__produce_header_file_4_0_i18);
	init_label(mercury__export__produce_header_file_4_0_i19);
	init_label(mercury__export__produce_header_file_4_0_i20);
	init_label(mercury__export__produce_header_file_4_0_i21);
	init_label(mercury__export__produce_header_file_4_0_i22);
	init_label(mercury__export__produce_header_file_4_0_i6);
	init_label(mercury__export__produce_header_file_4_0_i24);
	init_label(mercury__export__produce_header_file_4_0_i25);
	init_label(mercury__export__produce_header_file_4_0_i26);
	init_label(mercury__export__produce_header_file_4_0_i27);
	init_label(mercury__export__produce_header_file_4_0_i28);
	init_label(mercury__export__produce_header_file_4_0_i29);
BEGIN_CODE

/* code for predicate 'produce_header_file'/4 in mode 0 */
Define_entry(mercury__export__produce_header_file_4_0);
	MR_incr_sp_push_msg(5, "export:produce_header_file/4");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__produce_header_file_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__export__produce_header_file_4_0_i3);
	MR_stackvar(1) = r1;
	r1 = r2;
	r4 = r3;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const(".h", 2);
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__modules__module_name_to_file_name_6_0),
		mercury__export__produce_header_file_4_0_i4,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i4);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__io__tell_4_0),
		mercury__export__produce_header_file_4_0_i5,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i5);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__produce_header_file_4_0_i6);
	r4 = r2;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const(".m", 2);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__modules__module_name_to_file_name_6_0),
		mercury__export__produce_header_file_4_0_i8,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i8);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__export__produce_header_file_4_0_i9,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("/*\n** Automatically generated from `", 36);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(".m' by the\n** Mercury compiler, version ", 40);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_0);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__export__produce_header_file_4_0_i10,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i10);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__export__produce_header_file_4_0_i11,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i11);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	call_localret(ENTRY(mercury__string__to_upper_2_0),
		mercury__export__produce_header_file_4_0_i12,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i12);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = (Word) MR_string_const("_H", 2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__produce_header_file_4_0_i13,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i13);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("#ifndef ", 8);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("#define ", 8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_10);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__export__produce_header_file_4_0_i14,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i14);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i15,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i15);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i16,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i16);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i17,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i17);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i18,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i18);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i19,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i19);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(");\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i20,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i20);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__export__produce_header_file_2_3_0),
		mercury__export__produce_header_file_4_0_i21,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i21);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("#ifdef __cplusplus\n", 19);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("}\n", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("#endif\n", 7);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("#endif /* ", 10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__produce_header_file_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_11);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__export__produce_header_file_4_0_i22,
		ENTRY(mercury__export__produce_header_file_4_0));
	}
Define_label(mercury__export__produce_header_file_4_0_i22);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__told_2_0),
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i6);
	r1 = (Word) MR_string_const("export.m", 8);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__export__produce_header_file_4_0_i24,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i24);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i25,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i25);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i26,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i26);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": can't open `", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i27,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i27);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i28,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i28);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' for output\n", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_4_0_i29,
		ENTRY(mercury__export__produce_header_file_4_0));
Define_label(mercury__export__produce_header_file_4_0_i29);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_4_0));
	r2 = r1;
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		ENTRY(mercury__export__produce_header_file_4_0));
END_MODULE


BEGIN_MODULE(export_module3)
	init_entry(mercury__export__type_to_type_string_2_0);
	init_label(mercury__export__type_to_type_string_2_0_i2);
	init_label(mercury__export__type_to_type_string_2_0_i7);
	init_label(mercury__export__type_to_type_string_2_0_i12);
	init_label(mercury__export__type_to_type_string_2_0_i17);
BEGIN_CODE

/* code for predicate 'type_to_type_string'/2 in mode 0 */
Define_entry(mercury__export__type_to_type_string_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i2);
	r1 = (Word) MR_string_const("Integer", 7);
	proceed();
Define_label(mercury__export__type_to_type_string_2_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i7);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i7);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i7);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i7);
	r1 = (Word) MR_string_const("Float", 5);
	proceed();
Define_label(mercury__export__type_to_type_string_2_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i12);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i12);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("string", 6)) != 0))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i12);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i12);
	r1 = (Word) MR_string_const("String", 6);
	proceed();
Define_label(mercury__export__type_to_type_string_2_0_i12);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i17);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i17);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("character", 9)) != 0))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i17);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__type_to_type_string_2_0_i17);
	r1 = (Word) MR_string_const("Char", 4);
	proceed();
Define_label(mercury__export__type_to_type_string_2_0_i17);
	r1 = (Word) MR_string_const("Word", 4);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(export_module4)
	init_entry(mercury__export__convert_type_to_mercury_3_0);
	init_label(mercury__export__convert_type_to_mercury_3_0_i2);
	init_label(mercury__export__convert_type_to_mercury_3_0_i8);
	init_label(mercury__export__convert_type_to_mercury_3_0_i1018);
BEGIN_CODE

/* code for predicate 'convert_type_to_mercury'/3 in mode 0 */
Define_entry(mercury__export__convert_type_to_mercury_3_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("string", 6)) != 0))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i2);
	r2 = r1;
	r1 = (Word) MR_string_const("(Word) ", 7);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__export__convert_type_to_mercury_3_0));
Define_label(mercury__export__convert_type_to_mercury_3_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i8);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i8);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i8);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i8);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__convert_type_to_mercury_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("float_to_word(", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__convert_type_to_mercury_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_12);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__export__convert_type_to_mercury_3_0));
Define_label(mercury__export__convert_type_to_mercury_3_0_i8);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i1018);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i1018);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("character", 9)) != 0))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i1018);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__convert_type_to_mercury_3_0_i1018);
	r2 = r1;
	r1 = (Word) MR_string_const("(UnsignedChar) ", 15);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__export__convert_type_to_mercury_3_0));
Define_label(mercury__export__convert_type_to_mercury_3_0_i1018);
	proceed();
END_MODULE


BEGIN_MODULE(export_module5)
	init_entry(mercury__export__convert_type_from_mercury_3_0);
	init_label(mercury__export__convert_type_from_mercury_3_0_i2);
	init_label(mercury__export__convert_type_from_mercury_3_0_i1012);
BEGIN_CODE

/* code for predicate 'convert_type_from_mercury'/3 in mode 0 */
Define_entry(mercury__export__convert_type_from_mercury_3_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("string", 6)) != 0))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i2);
	r2 = r1;
	r1 = (Word) MR_string_const("(String) ", 9);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__export__convert_type_from_mercury_3_0));
Define_label(mercury__export__convert_type_from_mercury_3_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i1012);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i1012);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i1012);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__convert_type_from_mercury_3_0_i1012);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__convert_type_from_mercury_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("word_to_float(", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__convert_type_from_mercury_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_12);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__export__convert_type_from_mercury_3_0));
Define_label(mercury__export__convert_type_from_mercury_3_0_i1012);
	proceed();
END_MODULE


BEGIN_MODULE(export_module6)
	init_entry(mercury__export__get_c_export_decls_2_3_0);
	init_label(mercury__export__get_c_export_decls_2_3_0_i4);
	init_label(mercury__export__get_c_export_decls_2_3_0_i6);
	init_label(mercury__export__get_c_export_decls_2_3_0_i7);
	init_label(mercury__export__get_c_export_decls_2_3_0_i11);
	init_label(mercury__export__get_c_export_decls_2_3_0_i12);
	init_label(mercury__export__get_c_export_decls_2_3_0_i15);
	init_label(mercury__export__get_c_export_decls_2_3_0_i16);
	init_label(mercury__export__get_c_export_decls_2_3_0_i18);
	init_label(mercury__export__get_c_export_decls_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'get_c_export_decls_2'/3 in mode 0 */
Define_static(mercury__export__get_c_export_decls_2_3_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_c_export_decls_2_3_0_i3);
	MR_incr_sp_push_msg(7, "export:get_c_export_decls_2/3");
	MR_stackvar(7) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__export__get_export_info_9_0),
		mercury__export__get_c_export_decls_2_3_0_i4,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
	}
Define_label(mercury__export__get_c_export_decls_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_c_export_decls_2_3_0_i6);
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__export__get_c_export_decls_2_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Word) MR_string_const("void", 4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	localcall(mercury__export__get_c_export_decls_2_3_0,
		LABEL(mercury__export__get_c_export_decls_2_3_0_i18),
		STATIC(mercury__export__get_c_export_decls_2_3_0));
Define_label(mercury__export__get_c_export_decls_2_3_0_i6);
	r3 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r6, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__export__type_to_type_string_2_0),
		mercury__export__get_c_export_decls_2_3_0_i7,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
Define_label(mercury__export__get_c_export_decls_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	if (((Integer) MR_stackvar(6) != (Integer) 1))
		GOTO_LABEL(mercury__export__get_c_export_decls_2_3_0_i11);
	r2 = (Word) MR_string_const(" *", 2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_c_export_decls_2_3_0_i11,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
Define_label(mercury__export__get_c_export_decls_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	if (((Integer) MR_stackvar(5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_c_export_decls_2_3_0_i12);
	r2 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_c_export_decls_2_3_0_i16,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
Define_label(mercury__export__get_c_export_decls_2_3_0_i12);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = MR_tempr1;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	call_localret(STATIC(mercury__export__get_argument_declarations_2_4_0),
		mercury__export__get_c_export_decls_2_3_0_i15,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
	}
Define_label(mercury__export__get_c_export_decls_2_3_0_i15);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_c_export_decls_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_c_export_decls_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("", 0);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__get_c_export_decls_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__get_c_export_decls_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_c_export_decls_2_3_0_i16,
		STATIC(mercury__export__get_c_export_decls_2_3_0));
	}
Define_label(mercury__export__get_c_export_decls_2_3_0_i16);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__export__get_c_export_decls_2_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	localcall(mercury__export__get_c_export_decls_2_3_0,
		LABEL(mercury__export__get_c_export_decls_2_3_0_i18),
		STATIC(mercury__export__get_c_export_decls_2_3_0));
	}
Define_label(mercury__export__get_c_export_decls_2_3_0_i18);
	update_prof_current_proc(LABEL(mercury__export__get_c_export_decls_2_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_c_export_decls_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__export__get_c_export_decls_2_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__code_util__make_proc_label_4_0);
Declare_entry(mercury__llds_out__get_proc_label_3_0);

BEGIN_MODULE(export_module7)
	init_entry(mercury__export__to_c_4_0);
	init_label(mercury__export__to_c_4_0_i4);
	init_label(mercury__export__to_c_4_0_i6);
	init_label(mercury__export__to_c_4_0_i7);
	init_label(mercury__export__to_c_4_0_i8);
	init_label(mercury__export__to_c_4_0_i9);
	init_label(mercury__export__to_c_4_0_i5);
	init_label(mercury__export__to_c_4_0_i10);
	init_label(mercury__export__to_c_4_0_i11);
	init_label(mercury__export__to_c_4_0_i12);
	init_label(mercury__export__to_c_4_0_i15);
	init_label(mercury__export__to_c_4_0_i16);
	init_label(mercury__export__to_c_4_0_i3);
BEGIN_CODE

/* code for predicate 'to_c'/4 in mode 0 */
Define_static(mercury__export__to_c_4_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__to_c_4_0_i3);
	MR_incr_sp_push_msg(14, "export:to_c/4");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = r2;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__export__get_export_info_9_0),
		mercury__export__to_c_4_0_i4,
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i4);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__to_c_4_0_i6);
	MR_stackvar(7) = r1;
	MR_stackvar(8) = r2;
	MR_stackvar(9) = r3;
	r2 = MR_stackvar(4);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	MR_stackvar(4) = (Word) MR_string_const("", 0);
	MR_stackvar(10) = r4;
	MR_stackvar(11) = r5;
	MR_stackvar(12) = (Word) MR_string_const("", 0);
	MR_stackvar(13) = (Word) MR_string_const("void", 4);
	GOTO_LABEL(mercury__export__to_c_4_0_i5);
Define_label(mercury__export__to_c_4_0_i6);
	MR_stackvar(7) = r1;
	MR_stackvar(8) = r2;
	MR_stackvar(9) = r3;
	r1 = r6;
	r2 = (Integer) 0;
	r3 = (Integer) 1;
	MR_stackvar(10) = r4;
	MR_stackvar(11) = r5;
	MR_stackvar(12) = r6;
	call_localret(STATIC(mercury__export__get_argument_declarations_2_4_0),
		mercury__export__to_c_4_0_i7,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(12);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__export__get_input_args_3_0),
		mercury__export__to_c_4_0_i8,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i8);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r3 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r3;
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__export__copy_output_args_3_0),
		mercury__export__to_c_4_0_i9,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(5);
Define_label(mercury__export__to_c_4_0_i5);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__code_util__make_proc_label_4_0),
		mercury__export__to_c_4_0_i10,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i10);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__llds_out__get_proc_label_3_0),
		mercury__export__to_c_4_0_i11,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i11);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	if (((Integer) MR_stackvar(7) != (Integer) 1))
		GOTO_LABEL(mercury__export__to_c_4_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("Declare_entry", 13);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(");\n", 3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = (Word) MR_string_const(")\n{\n", 4);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = (Word) MR_string_const("#if NUM_REAL_REGS > 0\n", 22);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = (Word) MR_string_const("\tWord c_regs[NUM_REAL_REGS];\n", 29);
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r16, (Integer) 0) = (Word) MR_string_const("#endif\n", 7);
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r18, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r19, (Integer) 0) = (Word) MR_string_const("\tsave_regs_to_mem(c_regs);\n", 27);
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r20, (Integer) 0) = (Word) MR_string_const("\trestore_registers();\n", 22);
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r22, (Integer) 0) = (Word) MR_string_const("\tsave_transient_registers();\n", 29);
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r23, (Integer) 0) = (Word) MR_string_const("\t(void) MR_call_engine(ENTRY(", 29);
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r24, (Integer) 0) = r2;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r25, (Integer) 0) = (Word) MR_string_const("), FALSE);\n", 11);
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r26, (Integer) 0) = (Word) MR_string_const("\trestore_transient_registers();\n", 32);
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r29, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r29, (Integer) 0) = (Word) MR_string_const("\trestore_regs_from_mem(c_regs);\n", 32);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r29, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = r29;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_13);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(11);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__to_c_4_0_i15,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("Declare_static", 14);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(");\n", 3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("(", 1);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = (Word) MR_string_const(")\n{\n", 4);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = (Word) MR_string_const("#if NUM_REAL_REGS > 0\n", 22);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = (Word) MR_string_const("\tWord c_regs[NUM_REAL_REGS];\n", 29);
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r16, (Integer) 0) = (Word) MR_string_const("#endif\n", 7);
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r18, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r19, (Integer) 0) = (Word) MR_string_const("\tsave_regs_to_mem(c_regs);\n", 27);
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r20, (Integer) 0) = (Word) MR_string_const("\trestore_registers();\n", 22);
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r22, (Integer) 0) = (Word) MR_string_const("\tsave_transient_registers();\n", 29);
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r23, (Integer) 0) = (Word) MR_string_const("\t(void) MR_call_engine(ENTRY(", 29);
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r24, (Integer) 0) = r2;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r25, (Integer) 0) = (Word) MR_string_const("), FALSE);\n", 11);
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r26, (Integer) 0) = (Word) MR_string_const("\trestore_transient_registers();\n", 32);
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r29, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r29, (Integer) 0) = (Word) MR_string_const("\trestore_regs_from_mem(c_regs);\n", 32);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r29, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = r29;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_13);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(11);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__to_c_4_0_i15,
		STATIC(mercury__export__to_c_4_0));
Define_label(mercury__export__to_c_4_0_i15);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	localcall(mercury__export__to_c_4_0,
		LABEL(mercury__export__to_c_4_0_i16),
		STATIC(mercury__export__to_c_4_0));
	}
Define_label(mercury__export__to_c_4_0_i16);
	update_prof_current_proc(LABEL(mercury__export__to_c_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__to_c_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__export__to_c_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__procedure_is_exported_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arg_types_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
Declare_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
Declare_entry(mercury__type_util__is_dummy_argument_type_1_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__list__filter_3_0);

BEGIN_MODULE(export_module8)
	init_entry(mercury__export__get_export_info_9_0);
	init_label(mercury__export__get_export_info_9_0_i2);
	init_label(mercury__export__get_export_info_9_0_i5);
	init_label(mercury__export__get_export_info_9_0_i3);
	init_label(mercury__export__get_export_info_9_0_i7);
	init_label(mercury__export__get_export_info_9_0_i8);
	init_label(mercury__export__get_export_info_9_0_i9);
	init_label(mercury__export__get_export_info_9_0_i10);
	init_label(mercury__export__get_export_info_9_0_i11);
	init_label(mercury__export__get_export_info_9_0_i12);
	init_label(mercury__export__get_export_info_9_0_i13);
	init_label(mercury__export__get_export_info_9_0_i14);
	init_label(mercury__export__get_export_info_9_0_i20);
	init_label(mercury__export__get_export_info_9_0_i24);
	init_label(mercury__export__get_export_info_9_0_i26);
	init_label(mercury__export__get_export_info_9_0_i27);
	init_label(mercury__export__get_export_info_9_0_i28);
	init_label(mercury__export__get_export_info_9_0_i30);
	init_label(mercury__export__get_export_info_9_0_i32);
	init_label(mercury__export__get_export_info_9_0_i33);
	init_label(mercury__export__get_export_info_9_0_i34);
	init_label(mercury__export__get_export_info_9_0_i35);
	init_label(mercury__export__get_export_info_9_0_i17);
	init_label(mercury__export__get_export_info_9_0_i18);
	init_label(mercury__export__get_export_info_9_0_i16);
	init_label(mercury__export__get_export_info_9_0_i38);
	init_label(mercury__export__get_export_info_9_0_i37);
	init_label(mercury__export__get_export_info_9_0_i39);
BEGIN_CODE

/* code for predicate 'get_export_info'/9 in mode 0 */
Define_static(mercury__export__get_export_info_9_0);
	MR_incr_sp_push_msg(9, "export:get_export_info/9");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = r1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__export__get_export_info_9_0_i2,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i2);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(7) = r1;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__procedure_is_exported_2_0),
		mercury__export__get_export_info_9_0_i5,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i5);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i3);
	MR_stackvar(2) = (Integer) 1;
	r1 = MR_stackvar(7);
	GOTO_LABEL(mercury__export__get_export_info_9_0_i7);
Define_label(mercury__export__get_export_info_9_0_i3);
	r1 = MR_stackvar(7);
	MR_stackvar(2) = (Integer) 0;
Define_label(mercury__export__get_export_info_9_0_i7);
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__export__get_export_info_9_0_i8,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i8);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__export__get_export_info_9_0_i9,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i9);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__export__get_export_info_9_0_i10,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i10);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__export__get_export_info_9_0_i11,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i11);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__export__get_export_info_9_0_i12,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i12);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__export__get_export_info_9_0_i13,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i13);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_14);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__export__get_export_info_9_0_i14,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i14);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i16);
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i18);
	MR_stackvar(8) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15);
	call_localret(ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0),
		mercury__export__get_export_info_9_0_i20,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i20);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i17);
	MR_stackvar(6) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__type_util__is_dummy_argument_type_1_0),
		mercury__export__get_export_info_9_0_i24,
		STATIC(mercury__export__get_export_info_9_0));
	}
Define_label(mercury__export__get_export_info_9_0_i24);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	if (r1)
		GOTO_LABEL(mercury__export__get_export_info_9_0_i17);
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__export__type_to_type_string_2_0),
		mercury__export__get_export_info_9_0_i26,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i26);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_export_info_9_0_i27,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i27);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	if (((Integer) MR_stackvar(4) <= (Integer) 32))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i28);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("r(", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_12);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_export_info_9_0_i30,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i28);
	r2 = r1;
	r1 = (Word) MR_string_const("r", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_export_info_9_0_i30,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i30);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__export__convert_type_from_mercury_3_0),
		mercury__export__get_export_info_9_0_i32,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i32);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(4) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_16);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_export_info_9_0_i33,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i33);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\treturn_value = ", 16);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_export_info_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_17);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_export_info_9_0_i34,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i34);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_18);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_export_info_9_0_i35,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i35);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_20);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__export__get_export_info_9_0_i39,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i17);
	r1 = MR_stackvar(8);
Define_label(mercury__export__get_export_info_9_0_i18);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_20);
	MR_stackvar(3) = (Word) MR_string_const("void", 4);
	MR_stackvar(4) = (Word) MR_string_const("", 0);
	MR_stackvar(5) = (Word) MR_string_const("", 0);
	MR_stackvar(6) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__export__get_export_info_9_0_i39,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i16);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__export__get_export_info_9_0_i37);
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_24);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_export_info_9_0_i38,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i38);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_20);
	r3 = MR_stackvar(8);
	MR_stackvar(3) = (Word) MR_string_const("bool", 4);
	MR_stackvar(4) = (Word) MR_string_const("", 0);
	MR_stackvar(6) = (Word) MR_string_const("\treturn TRUE;\n", 14);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__export__get_export_info_9_0_i39,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i37);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_export__common_20);
	MR_stackvar(3) = (Word) MR_string_const("\n#error \"cannot export nondet procedure\"\n", 41);
	MR_stackvar(4) = (Word) MR_string_const("", 0);
	MR_stackvar(5) = (Word) MR_string_const("", 0);
	MR_stackvar(6) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__export__get_export_info_9_0_i39,
		STATIC(mercury__export__get_export_info_9_0));
Define_label(mercury__export__get_export_info_9_0_i39);
	update_prof_current_proc(LABEL(mercury__export__get_export_info_9_0));
	r6 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(export_module9)
	init_entry(mercury__export__include_arg_1_0);
	init_label(mercury__export__include_arg_1_0_i6);
	init_label(mercury__export__include_arg_1_0_i1003);
	init_label(mercury__export__include_arg_1_0_i1);
BEGIN_CODE

/* code for predicate 'include_arg'/1 in mode 0 */
Define_static(mercury__export__include_arg_1_0);
	MR_incr_sp_push_msg(1, "export:include_arg/1");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) 2))
		GOTO_LABEL(mercury__export__include_arg_1_0_i1003);
	call_localret(ENTRY(mercury__type_util__is_dummy_argument_type_1_0),
		mercury__export__include_arg_1_0_i6,
		STATIC(mercury__export__include_arg_1_0));
Define_label(mercury__export__include_arg_1_0_i6);
	update_prof_current_proc(LABEL(mercury__export__include_arg_1_0));
	if (r1)
		GOTO_LABEL(mercury__export__include_arg_1_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__export__include_arg_1_0_i1003);
	r1 = FALSE;
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__export__include_arg_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(export_module10)
	init_entry(mercury__export__get_argument_declarations_2_4_0);
	init_label(mercury__export__get_argument_declarations_2_4_0_i3);
	init_label(mercury__export__get_argument_declarations_2_4_0_i6);
	init_label(mercury__export__get_argument_declarations_2_4_0_i7);
	init_label(mercury__export__get_argument_declarations_2_4_0_i4);
	init_label(mercury__export__get_argument_declarations_2_4_0_i9);
	init_label(mercury__export__get_argument_declarations_2_4_0_i10);
	init_label(mercury__export__get_argument_declarations_2_4_0_i14);
	init_label(mercury__export__get_argument_declarations_2_4_0_i17);
BEGIN_CODE

/* code for predicate 'get_argument_declarations_2'/4 in mode 0 */
Define_static(mercury__export__get_argument_declarations_2_4_0);
	MR_incr_sp_push_msg(6, "export:get_argument_declarations_2/4");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_4_0_i3);
	r1 = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__export__get_argument_declarations_2_4_0_i3);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r5 = ((Integer) r2 + (Integer) 1);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_4_0_i4);
	MR_stackvar(2) = r7;
	MR_stackvar(3) = r6;
	MR_stackvar(5) = r4;
	r1 = r5;
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_argument_declarations_2_4_0_i6,
		STATIC(mercury__export__get_argument_declarations_2_4_0));
	}
Define_label(mercury__export__get_argument_declarations_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" Mercury__argument", 18);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_argument_declarations_2_4_0_i7,
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__export__type_to_type_string_2_0),
		mercury__export__get_argument_declarations_2_4_0_i9,
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i4);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r7;
	r1 = r6;
	MR_stackvar(4) = r5;
	MR_stackvar(3) = (Word) MR_string_const("", 0);
	MR_stackvar(5) = r4;
	call_localret(STATIC(mercury__export__type_to_type_string_2_0),
		mercury__export__get_argument_declarations_2_4_0_i9,
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_4_0));
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_4_0_i10);
	r2 = (Word) MR_string_const(" *", 2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_argument_declarations_2_4_0_i10,
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_4_0));
	r2 = MR_stackvar(3);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_argument_declarations_2_4_0_i14);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i14);
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	localcall(mercury__export__get_argument_declarations_2_4_0,
		LABEL(mercury__export__get_argument_declarations_2_4_0_i17),
		STATIC(mercury__export__get_argument_declarations_2_4_0));
Define_label(mercury__export__get_argument_declarations_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__export__get_argument_declarations_2_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_argument_declarations_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_argument_declarations_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__get_argument_declarations_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__get_argument_declarations_2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__export__get_argument_declarations_2_4_0));
	}
END_MODULE


BEGIN_MODULE(export_module11)
	init_entry(mercury__export__get_input_args_3_0);
	init_label(mercury__export__get_input_args_3_0_i6);
	init_label(mercury__export__get_input_args_3_0_i7);
	init_label(mercury__export__get_input_args_3_0_i8);
	init_label(mercury__export__get_input_args_3_0_i9);
	init_label(mercury__export__get_input_args_3_0_i11);
	init_label(mercury__export__get_input_args_3_0_i10);
	init_label(mercury__export__get_input_args_3_0_i12);
	init_label(mercury__export__get_input_args_3_0_i14);
	init_label(mercury__export__get_input_args_3_0_i5);
	init_label(mercury__export__get_input_args_3_0_i16);
	init_label(mercury__export__get_input_args_3_0_i3);
BEGIN_CODE

/* code for predicate 'get_input_args'/3 in mode 0 */
Define_static(mercury__export__get_input_args_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i3);
	MR_incr_sp_push_msg(5, "export:get_input_args/3");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_input_args_3_0_i6,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i6);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Mercury__argument", 17);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_input_args_3_0_i7,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__export__convert_type_to_mercury_3_0),
		mercury__export__get_input_args_3_0_i8,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__get_input_args_3_0_i9,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i9);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	if (((Integer) MR_stackvar(3) <= (Integer) 32))
		GOTO_LABEL(mercury__export__get_input_args_3_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("r(", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_12);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i11,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i11);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(" = ", 3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_17);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i14,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("r", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__get_input_args_3_0_i12,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i12);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(" = ", 3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__export__get_input_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_17);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__get_input_args_3_0_i14,
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i14);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(4);
	localcall(mercury__export__get_input_args_3_0,
		LABEL(mercury__export__get_input_args_3_0_i16),
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("", 0);
	localcall(mercury__export__get_input_args_3_0,
		LABEL(mercury__export__get_input_args_3_0_i16),
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i16);
	update_prof_current_proc(LABEL(mercury__export__get_input_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__get_input_args_3_0));
Define_label(mercury__export__get_input_args_3_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(export_module12)
	init_entry(mercury__export__copy_output_args_3_0);
	init_label(mercury__export__copy_output_args_3_0_i1001);
	init_label(mercury__export__copy_output_args_3_0_i5);
	init_label(mercury__export__copy_output_args_3_0_i7);
	init_label(mercury__export__copy_output_args_3_0_i8);
	init_label(mercury__export__copy_output_args_3_0_i9);
	init_label(mercury__export__copy_output_args_3_0_i10);
	init_label(mercury__export__copy_output_args_3_0_i12);
	init_label(mercury__export__copy_output_args_3_0_i14);
	init_label(mercury__export__copy_output_args_3_0_i15);
	init_label(mercury__export__copy_output_args_3_0_i16);
	init_label(mercury__export__copy_output_args_3_0_i3);
BEGIN_CODE

/* code for predicate 'copy_output_args'/3 in mode 0 */
Define_static(mercury__export__copy_output_args_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i3);
	MR_incr_sp_push_msg(6, "export:copy_output_args/3");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i5);
Define_label(mercury__export__copy_output_args_3_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("", 0);
	localcall(mercury__export__copy_output_args_3_0,
		LABEL(mercury__export__copy_output_args_3_0_i16),
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i1001);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__copy_output_args_3_0_i7,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Mercury__argument", 17);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__copy_output_args_3_0_i8,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__export__copy_output_args_3_0_i9,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i9);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	if (((Integer) MR_stackvar(3) <= (Integer) 32))
		GOTO_LABEL(mercury__export__copy_output_args_3_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("r(", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_12);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__copy_output_args_3_0_i12,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("r", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__export__copy_output_args_3_0_i12,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i12);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__export__convert_type_from_mercury_3_0),
		mercury__export__copy_output_args_3_0_i14,
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i14);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t*", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(" = ", 3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__export__copy_output_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_export__common_17);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__export__copy_output_args_3_0_i15,
		STATIC(mercury__export__copy_output_args_3_0));
	}
Define_label(mercury__export__copy_output_args_3_0_i15);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(4);
	localcall(mercury__export__copy_output_args_3_0,
		LABEL(mercury__export__copy_output_args_3_0_i16),
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i16);
	update_prof_current_proc(LABEL(mercury__export__copy_output_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__export__copy_output_args_3_0));
Define_label(mercury__export__copy_output_args_3_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(export_module13)
	init_entry(mercury__export__produce_header_file_2_3_0);
	init_label(mercury__export__produce_header_file_2_3_0_i1001);
	init_label(mercury__export__produce_header_file_2_3_0_i4);
	init_label(mercury__export__produce_header_file_2_3_0_i5);
	init_label(mercury__export__produce_header_file_2_3_0_i6);
	init_label(mercury__export__produce_header_file_2_3_0_i7);
	init_label(mercury__export__produce_header_file_2_3_0_i8);
	init_label(mercury__export__produce_header_file_2_3_0_i9);
	init_label(mercury__export__produce_header_file_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'produce_header_file_2'/3 in mode 0 */
Define_static(mercury__export__produce_header_file_2_3_0);
	MR_incr_sp_push_msg(4, "export:produce_header_file_2/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__export__produce_header_file_2_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__export__produce_header_file_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i4,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i5,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i6,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i7,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i7);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i8,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i8);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(");\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__export__produce_header_file_2_3_0_i9,
		STATIC(mercury__export__produce_header_file_2_3_0));
Define_label(mercury__export__produce_header_file_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__export__produce_header_file_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__export__produce_header_file_2_3_0_i1001);
Define_label(mercury__export__produce_header_file_2_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__export_maybe_bunch_0(void)
{
	export_module0();
	export_module1();
	export_module2();
	export_module3();
	export_module4();
	export_module5();
	export_module6();
	export_module7();
	export_module8();
	export_module9();
	export_module10();
	export_module11();
	export_module12();
	export_module13();
}

#endif

void mercury__export__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__export__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__export_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
