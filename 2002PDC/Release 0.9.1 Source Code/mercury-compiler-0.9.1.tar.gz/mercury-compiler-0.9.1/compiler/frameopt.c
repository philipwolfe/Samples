/*
** Automatically generated from `frameopt.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__frameopt__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___frameopt__block_info_0__ua0_2_0);
Declare_static(mercury__frameopt__pick_last__ua0_3_0);
Declare_label(mercury__frameopt__pick_last__ua0_3_0_i3);
Declare_label(mercury__frameopt__pick_last__ua0_3_0_i5);
Declare_label(mercury__frameopt__pick_last__ua0_3_0_i7);
Define_extern_entry(mercury__frameopt__frameopt_main_4_0);
Declare_label(mercury__frameopt__frameopt_main_4_0_i2);
Declare_label(mercury__frameopt__frameopt_main_4_0_i5);
Declare_label(mercury__frameopt__frameopt_main_4_0_i7);
Declare_label(mercury__frameopt__frameopt_main_4_0_i8);
Declare_label(mercury__frameopt__frameopt_main_4_0_i9);
Declare_label(mercury__frameopt__frameopt_main_4_0_i10);
Declare_label(mercury__frameopt__frameopt_main_4_0_i11);
Declare_label(mercury__frameopt__frameopt_main_4_0_i15);
Declare_label(mercury__frameopt__frameopt_main_4_0_i17);
Declare_label(mercury__frameopt__frameopt_main_4_0_i18);
Declare_label(mercury__frameopt__frameopt_main_4_0_i19);
Declare_label(mercury__frameopt__frameopt_main_4_0_i20);
Declare_label(mercury__frameopt__frameopt_main_4_0_i13);
Declare_label(mercury__frameopt__frameopt_main_4_0_i22);
Declare_label(mercury__frameopt__frameopt_main_4_0_i23);
Declare_label(mercury__frameopt__frameopt_main_4_0_i24);
Declare_label(mercury__frameopt__frameopt_main_4_0_i25);
Declare_label(mercury__frameopt__frameopt_main_4_0_i26);
Declare_label(mercury__frameopt__frameopt_main_4_0_i4);
Declare_static(mercury__frameopt__flatten_block_seq_3_0);
Declare_label(mercury__frameopt__flatten_block_seq_3_0_i4);
Declare_label(mercury__frameopt__flatten_block_seq_3_0_i5);
Declare_label(mercury__frameopt__flatten_block_seq_3_0_i3);
Declare_static(mercury__frameopt__divide_into_basic_blocks_5_0);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i3);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i5);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i8);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i11);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i1019);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i4);
Declare_label(mercury__frameopt__divide_into_basic_blocks_5_0_i13);
Declare_static(mercury__frameopt__build_block_map_8_0);
Declare_label(mercury__frameopt__build_block_map_8_0_i3);
Declare_label(mercury__frameopt__build_block_map_8_0_i8);
Declare_label(mercury__frameopt__build_block_map_8_0_i10);
Declare_label(mercury__frameopt__build_block_map_8_0_i11);
Declare_label(mercury__frameopt__build_block_map_8_0_i15);
Declare_label(mercury__frameopt__build_block_map_8_0_i6);
Declare_label(mercury__frameopt__build_block_map_8_0_i19);
Declare_label(mercury__frameopt__build_block_map_8_0_i21);
Declare_label(mercury__frameopt__build_block_map_8_0_i22);
Declare_label(mercury__frameopt__build_block_map_8_0_i23);
Declare_label(mercury__frameopt__build_block_map_8_0_i1017);
Declare_label(mercury__frameopt__build_block_map_8_0_i26);
Declare_label(mercury__frameopt__build_block_map_8_0_i27);
Declare_label(mercury__frameopt__build_block_map_8_0_i24);
Declare_label(mercury__frameopt__build_block_map_8_0_i28);
Declare_label(mercury__frameopt__build_block_map_8_0_i29);
Declare_label(mercury__frameopt__build_block_map_8_0_i30);
Declare_label(mercury__frameopt__build_block_map_8_0_i31);
Declare_label(mercury__frameopt__build_block_map_8_0_i17);
Declare_label(mercury__frameopt__build_block_map_8_0_i33);
Declare_label(mercury__frameopt__build_block_map_8_0_i34);
Declare_label(mercury__frameopt__build_block_map_8_0_i35);
Declare_label(mercury__frameopt__build_block_map_8_0_i36);
Declare_label(mercury__frameopt__build_block_map_8_0_i4);
Declare_label(mercury__frameopt__build_block_map_8_0_i39);
Declare_static(mercury__frameopt__detstack_setup_6_0);
Declare_label(mercury__frameopt__detstack_setup_6_0_i2);
Declare_label(mercury__frameopt__detstack_setup_6_0_i5);
Declare_label(mercury__frameopt__detstack_setup_6_0_i1);
Declare_static(mercury__frameopt__detstack_setup_2_6_0);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i1009);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i5);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i11);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i3);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i18);
Declare_label(mercury__frameopt__detstack_setup_2_6_0_i1);
Declare_static(mercury__frameopt__detstack_teardown_8_0);
Declare_label(mercury__frameopt__detstack_teardown_8_0_i1001);
Declare_label(mercury__frameopt__detstack_teardown_8_0_i3);
Declare_label(mercury__frameopt__detstack_teardown_8_0_i6);
Declare_label(mercury__frameopt__detstack_teardown_8_0_i8);
Declare_label(mercury__frameopt__detstack_teardown_8_0_i11);
Declare_static(mercury__frameopt__detstack_teardown_2_12_0);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i1016);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i2);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i7);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i8);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i16);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i17);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i18);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i22);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i25);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i6);
Declare_label(mercury__frameopt__detstack_teardown_2_12_0_i1);
Declare_static(mercury__frameopt__block_needs_frame_2_0);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i2);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i1000);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i3);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i9);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i16);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i11);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i1020);
Declare_label(mercury__frameopt__block_needs_frame_2_0_i1024);
Declare_static(mercury__frameopt__analyze_block_map_4_0);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i6);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i8);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i11);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i12);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i1009);
Declare_label(mercury__frameopt__analyze_block_map_4_0_i3);
Declare_static(mercury__frameopt__analyze_block_map_2_6_0);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i1022);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i4);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i6);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i8);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i10);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i12);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i11);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i14);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i43);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i39);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i40);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i36);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i37);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i25);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i28);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i27);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i31);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i21);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i23);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i19);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i16);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i5);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i46);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i48);
Declare_label(mercury__frameopt__analyze_block_map_2_6_0_i3);
Declare_static(mercury__frameopt__can_clobber_succip_3_0);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i1004);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i3);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i4);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i9);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i1008);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i12);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i1027);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i1031);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i14);
Declare_label(mercury__frameopt__can_clobber_succip_3_0_i6);
Declare_static(mercury__frameopt__keep_frame_6_0);
Declare_label(mercury__frameopt__keep_frame_6_0_i1026);
Declare_label(mercury__frameopt__keep_frame_6_0_i4);
Declare_label(mercury__frameopt__keep_frame_6_0_i6);
Declare_label(mercury__frameopt__keep_frame_6_0_i38);
Declare_label(mercury__frameopt__keep_frame_6_0_i34);
Declare_label(mercury__frameopt__keep_frame_6_0_i35);
Declare_label(mercury__frameopt__keep_frame_6_0_i31);
Declare_label(mercury__frameopt__keep_frame_6_0_i32);
Declare_label(mercury__frameopt__keep_frame_6_0_i20);
Declare_label(mercury__frameopt__keep_frame_6_0_i23);
Declare_label(mercury__frameopt__keep_frame_6_0_i22);
Declare_label(mercury__frameopt__keep_frame_6_0_i26);
Declare_label(mercury__frameopt__keep_frame_6_0_i16);
Declare_label(mercury__frameopt__keep_frame_6_0_i18);
Declare_label(mercury__frameopt__keep_frame_6_0_i14);
Declare_label(mercury__frameopt__keep_frame_6_0_i40);
Declare_label(mercury__frameopt__keep_frame_6_0_i43);
Declare_label(mercury__frameopt__keep_frame_6_0_i45);
Declare_label(mercury__frameopt__keep_frame_6_0_i46);
Declare_label(mercury__frameopt__keep_frame_6_0_i49);
Declare_label(mercury__frameopt__keep_frame_6_0_i47);
Declare_label(mercury__frameopt__keep_frame_6_0_i51);
Declare_label(mercury__frameopt__keep_frame_6_0_i5);
Declare_label(mercury__frameopt__keep_frame_6_0_i3);
Declare_static(mercury__frameopt__can_delay_frame_3_0);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i1011);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i4);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i9);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i1005);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i5);
Declare_label(mercury__frameopt__can_delay_frame_3_0_i1);
Declare_static(mercury__frameopt__delay_frame_8_0);
Declare_label(mercury__frameopt__delay_frame_8_0_i2);
Declare_label(mercury__frameopt__delay_frame_8_0_i3);
Declare_label(mercury__frameopt__delay_frame_8_0_i4);
Declare_label(mercury__frameopt__delay_frame_8_0_i5);
Declare_label(mercury__frameopt__delay_frame_8_0_i6);
Declare_label(mercury__frameopt__delay_frame_8_0_i7);
Declare_label(mercury__frameopt__delay_frame_8_0_i8);
Declare_label(mercury__frameopt__delay_frame_8_0_i9);
Declare_static(mercury__frameopt__delay_frame_init_6_0);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i1007);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i4);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i7);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i1003);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i9);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i10);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i12);
Declare_label(mercury__frameopt__delay_frame_init_6_0_i3);
Declare_static(mercury__frameopt__rev_map_side_labels_4_0);
Declare_label(mercury__frameopt__rev_map_side_labels_4_0_i1002);
Declare_label(mercury__frameopt__rev_map_side_labels_4_0_i5);
Declare_label(mercury__frameopt__rev_map_side_labels_4_0_i4);
Declare_label(mercury__frameopt__rev_map_side_labels_4_0_i8);
Declare_label(mercury__frameopt__rev_map_side_labels_4_0_i3);
Declare_static(mercury__frameopt__propagate_framed_labels_5_0);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i1005);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i3);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i6);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i9);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i11);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i13);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i14);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i16);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i18);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i15);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i5);
Declare_label(mercury__frameopt__propagate_framed_labels_5_0_i2);
Declare_static(mercury__frameopt__process_frame_delay_13_0);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i3);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i4);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i7);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i1001);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i5);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i10);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i24);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i23);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i22);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i27);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i28);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i29);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i32);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i33);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i35);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i34);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i37);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i20);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i13);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i15);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i17);
Declare_label(mercury__frameopt__process_frame_delay_13_0_i14);
Declare_static(mercury__frameopt__transform_ordinary_block_15_0);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i2);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i3);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i4);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i5);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i6);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i8);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i9);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i21);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i18);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i19);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i20);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i12);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i14);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i16);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i13);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i7);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i22);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i23);
Declare_label(mercury__frameopt__transform_ordinary_block_15_0_i24);
Declare_static(mercury__frameopt__mark_parallels_for_teardown_9_0);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i4);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i14);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i8);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i10);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i1004);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i12);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i7);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i15);
Declare_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i3);
Declare_static(mercury__frameopt__mark_parallel_7_0);
Declare_label(mercury__frameopt__mark_parallel_7_0_i3);
Declare_label(mercury__frameopt__mark_parallel_7_0_i2);
Declare_label(mercury__frameopt__mark_parallel_7_0_i5);
Declare_static(mercury__frameopt__create_parallels_6_0);
Declare_label(mercury__frameopt__create_parallels_6_0_i4);
Declare_label(mercury__frameopt__create_parallels_6_0_i6);
Declare_label(mercury__frameopt__create_parallels_6_0_i8);
Declare_label(mercury__frameopt__create_parallels_6_0_i11);
Declare_label(mercury__frameopt__create_parallels_6_0_i14);
Declare_label(mercury__frameopt__create_parallels_6_0_i18);
Declare_label(mercury__frameopt__create_parallels_6_0_i21);
Declare_label(mercury__frameopt__create_parallels_6_0_i22);
Declare_label(mercury__frameopt__create_parallels_6_0_i24);
Declare_label(mercury__frameopt__create_parallels_6_0_i1027);
Declare_label(mercury__frameopt__create_parallels_6_0_i19);
Declare_label(mercury__frameopt__create_parallels_6_0_i27);
Declare_label(mercury__frameopt__create_parallels_6_0_i1029);
Declare_label(mercury__frameopt__create_parallels_6_0_i3);
Declare_static(mercury____Unify___frameopt__block_map_0_0);
Declare_static(mercury____Index___frameopt__block_map_0_0);
Declare_static(mercury____Compare___frameopt__block_map_0_0);
Declare_static(mercury____Unify___frameopt__block_info_0_0);
Declare_label(mercury____Unify___frameopt__block_info_0_0_i2);
Declare_label(mercury____Unify___frameopt__block_info_0_0_i4);
Declare_label(mercury____Unify___frameopt__block_info_0_0_i6);
Declare_label(mercury____Unify___frameopt__block_info_0_0_i8);
Declare_label(mercury____Unify___frameopt__block_info_0_0_i1);
Declare_static(mercury____Index___frameopt__block_info_0_0);
Declare_static(mercury____Compare___frameopt__block_info_0_0);
Declare_label(mercury____Compare___frameopt__block_info_0_0_i3);
Declare_label(mercury____Compare___frameopt__block_info_0_0_i7);
Declare_label(mercury____Compare___frameopt__block_info_0_0_i11);
Declare_label(mercury____Compare___frameopt__block_info_0_0_i15);
Declare_label(mercury____Compare___frameopt__block_info_0_0_i22);
Declare_static(mercury____Unify___frameopt__block_type_0_0);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i6);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i8);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i10);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i1009);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i1011);
Declare_label(mercury____Unify___frameopt__block_type_0_0_i1);
Declare_static(mercury____Index___frameopt__block_type_0_0);
Declare_label(mercury____Index___frameopt__block_type_0_0_i5);
Declare_label(mercury____Index___frameopt__block_type_0_0_i4);
Declare_static(mercury____Compare___frameopt__block_type_0_0);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i5);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i4);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i2);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i9);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i8);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i6);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i10);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i11);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i19);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i22);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i26);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i16);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i1021);
Declare_label(mercury____Compare___frameopt__block_type_0_0_i36);
Declare_static(mercury____Unify___frameopt__rev_map_0_0);
Declare_static(mercury____Index___frameopt__rev_map_0_0);
Declare_static(mercury____Compare___frameopt__rev_map_0_0);
Declare_static(mercury____Unify___frameopt__par_map_0_0);
Declare_static(mercury____Index___frameopt__par_map_0_0);
Declare_static(mercury____Compare___frameopt__par_map_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_par_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_rev_map_0;

static const struct mercury_data_frameopt__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_frameopt__common_0;

static const struct mercury_data_frameopt__common_1_struct {
	String f1;
}  mercury_data_frameopt__common_1;

static const struct mercury_data_frameopt__common_2_struct {
	Word * f1;
	String f2;
}  mercury_data_frameopt__common_2;

static const struct mercury_data_frameopt__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frameopt__common_3;

static const struct mercury_data_frameopt__common_4_struct {
	String f1;
}  mercury_data_frameopt__common_4;

static const struct mercury_data_frameopt__common_5_struct {
	Word * f1;
	String f2;
}  mercury_data_frameopt__common_5;

static const struct mercury_data_frameopt__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frameopt__common_6;

static const struct mercury_data_frameopt__common_7_struct {
	Integer f1;
}  mercury_data_frameopt__common_7;

static const struct mercury_data_frameopt__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frameopt__common_8;

static const struct mercury_data_frameopt__common_9_struct {
	Integer f1;
}  mercury_data_frameopt__common_9;

static const struct mercury_data_frameopt__common_10_struct {
	Word * f1;
}  mercury_data_frameopt__common_10;

static const struct mercury_data_frameopt__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_frameopt__common_11;

static const struct mercury_data_frameopt__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__common_12;

static const struct mercury_data_frameopt__common_13_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_frameopt__common_13;

static const struct mercury_data_frameopt__common_14_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__common_14;

static const struct mercury_data_frameopt__common_15_struct {
	Word * f1;
}  mercury_data_frameopt__common_15;

static const struct mercury_data_frameopt__common_16_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_frameopt__common_16;

static const struct mercury_data_frameopt__common_17_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_frameopt__common_17;

static const struct mercury_data_frameopt__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frameopt__common_18;

static const struct mercury_data_frameopt__common_19_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_frameopt__common_19;

static const struct mercury_data_frameopt__common_20_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_frameopt__common_20;

static const struct mercury_data_frameopt__common_21_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_frameopt__common_21;

static const struct mercury_data_frameopt__common_22_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__common_22;

static const struct mercury_data_frameopt__common_23_struct {
	Word * f1;
}  mercury_data_frameopt__common_23;

static const struct mercury_data_frameopt__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_frameopt__common_24;

static const struct mercury_data_frameopt__common_25_struct {
	Word * f1;
}  mercury_data_frameopt__common_25;

static const struct mercury_data_frameopt__common_26_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_frameopt__common_26;

static const struct mercury_data_frameopt__type_ctor_functors_rev_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__type_ctor_functors_rev_map_0;

static const struct mercury_data_frameopt__type_ctor_layout_rev_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frameopt__type_ctor_layout_rev_map_0;

static const struct mercury_data_frameopt__type_ctor_functors_par_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__type_ctor_functors_par_map_0;

static const struct mercury_data_frameopt__type_ctor_layout_par_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frameopt__type_ctor_layout_par_map_0;

static const struct mercury_data_frameopt__type_ctor_functors_block_type_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_frameopt__type_ctor_functors_block_type_0;

static const struct mercury_data_frameopt__type_ctor_layout_block_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frameopt__type_ctor_layout_block_type_0;

static const struct mercury_data_frameopt__type_ctor_functors_block_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_frameopt__type_ctor_functors_block_map_0;

static const struct mercury_data_frameopt__type_ctor_layout_block_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frameopt__type_ctor_layout_block_map_0;

static const struct mercury_data_frameopt__type_ctor_functors_block_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_frameopt__type_ctor_functors_block_info_0;

static const struct mercury_data_frameopt__type_ctor_layout_block_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_frameopt__type_ctor_layout_block_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___frameopt__block_info_0_0),
	STATIC(mercury____Index___frameopt__block_info_0_0),
	STATIC(mercury____Compare___frameopt__block_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_frameopt__type_ctor_functors_block_info_0,
	(Word *) &mercury_data_frameopt__type_ctor_layout_block_info_0,
	MR_string_const("frameopt", 8),
	MR_string_const("block_info", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___frameopt__block_map_0_0),
	STATIC(mercury____Index___frameopt__block_map_0_0),
	STATIC(mercury____Compare___frameopt__block_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_frameopt__type_ctor_functors_block_map_0,
	(Word *) &mercury_data_frameopt__type_ctor_layout_block_map_0,
	MR_string_const("frameopt", 8),
	MR_string_const("block_map", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_block_type_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___frameopt__block_type_0_0),
	STATIC(mercury____Index___frameopt__block_type_0_0),
	STATIC(mercury____Compare___frameopt__block_type_0_0),
	(Integer) 2,
	(Word *) &mercury_data_frameopt__type_ctor_functors_block_type_0,
	(Word *) &mercury_data_frameopt__type_ctor_layout_block_type_0,
	MR_string_const("frameopt", 8),
	MR_string_const("block_type", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_par_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___frameopt__par_map_0_0),
	STATIC(mercury____Index___frameopt__par_map_0_0),
	STATIC(mercury____Compare___frameopt__par_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_frameopt__type_ctor_functors_par_map_0,
	(Word *) &mercury_data_frameopt__type_ctor_layout_par_map_0,
	MR_string_const("frameopt", 8),
	MR_string_const("par_map", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_frameopt__type_ctor_info_rev_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___frameopt__rev_map_0_0),
	STATIC(mercury____Index___frameopt__rev_map_0_0),
	STATIC(mercury____Compare___frameopt__rev_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_frameopt__type_ctor_functors_rev_map_0,
	(Word *) &mercury_data_frameopt__type_ctor_layout_rev_map_0,
	MR_string_const("frameopt", 8),
	MR_string_const("rev_map", 7),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_frameopt__common_0_struct mercury_data_frameopt__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_frameopt__common_1_struct mercury_data_frameopt__common_1 = {
	MR_string_const("delaying stack frame", 20)
};

static const struct mercury_data_frameopt__common_2_struct mercury_data_frameopt__common_2 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_1),
	MR_string_const("", 0)
};

static const struct mercury_data_frameopt__common_3_struct mercury_data_frameopt__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_frameopt__common_4_struct mercury_data_frameopt__common_4 = {
	MR_string_const("keeping stack frame", 19)
};

static const struct mercury_data_frameopt__common_5_struct mercury_data_frameopt__common_5 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_4),
	MR_string_const("", 0)
};

static const struct mercury_data_frameopt__common_6_struct mercury_data_frameopt__common_6 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_frameopt__common_7_struct mercury_data_frameopt__common_7 = {
	(Integer) 1
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;
static const struct mercury_data_frameopt__common_8_struct mercury_data_frameopt__common_8 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

static const struct mercury_data_frameopt__common_9_struct mercury_data_frameopt__common_9 = {
	(Integer) 0
};

static const struct mercury_data_frameopt__common_10_struct mercury_data_frameopt__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_frameopt__common_11_struct mercury_data_frameopt__common_11 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_llds__type_ctor_info_label_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8)
};

static const struct mercury_data_frameopt__common_12_struct mercury_data_frameopt__common_12 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_11)
};

static const struct mercury_data_frameopt__common_13_struct mercury_data_frameopt__common_13 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_llds__type_ctor_info_label_0,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

static const struct mercury_data_frameopt__common_14_struct mercury_data_frameopt__common_14 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_13)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_frameopt__common_15_struct mercury_data_frameopt__common_15 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_frameopt__common_16_struct mercury_data_frameopt__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_15),
	MR_string_const("ordinary", 8),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_frameopt__common_17_struct mercury_data_frameopt__common_17 = {
	(Integer) 0,
	MR_string_const("setup", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_frameopt__common_18_struct mercury_data_frameopt__common_18 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0)
};

static const struct mercury_data_frameopt__common_19_struct mercury_data_frameopt__common_19 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0),
	MR_string_const("teardown", 8),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_frameopt__common_20_struct mercury_data_frameopt__common_20 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("setup", 5)
};

static const struct mercury_data_frameopt__common_21_struct mercury_data_frameopt__common_21 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_llds__type_ctor_info_label_0,
	(Word *) &mercury_data_frameopt__type_ctor_info_block_info_0
};

static const struct mercury_data_frameopt__common_22_struct mercury_data_frameopt__common_22 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_21)
};

static const struct mercury_data_frameopt__common_23_struct mercury_data_frameopt__common_23 = {
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_frameopt__common_24_struct mercury_data_frameopt__common_24 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

static const struct mercury_data_frameopt__common_25_struct mercury_data_frameopt__common_25 = {
	(Word *) &mercury_data_frameopt__type_ctor_info_block_type_0
};

static const struct mercury_data_frameopt__common_26_struct mercury_data_frameopt__common_26 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_25),
	MR_string_const("block_info", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_frameopt__type_ctor_functors_rev_map_0_struct mercury_data_frameopt__type_ctor_functors_rev_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_11)
};

static const struct mercury_data_frameopt__type_ctor_layout_rev_map_0_struct mercury_data_frameopt__type_ctor_layout_rev_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_12)
};

static const struct mercury_data_frameopt__type_ctor_functors_par_map_0_struct mercury_data_frameopt__type_ctor_functors_par_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_13)
};

static const struct mercury_data_frameopt__type_ctor_layout_par_map_0_struct mercury_data_frameopt__type_ctor_layout_par_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_14),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_14),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_14),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_14)
};

static const struct mercury_data_frameopt__type_ctor_functors_block_type_0_struct mercury_data_frameopt__type_ctor_functors_block_type_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_19)
};

static const struct mercury_data_frameopt__type_ctor_layout_block_type_0_struct mercury_data_frameopt__type_ctor_layout_block_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_20),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_16),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_19),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_frameopt__type_ctor_functors_block_map_0_struct mercury_data_frameopt__type_ctor_functors_block_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_21)
};

static const struct mercury_data_frameopt__type_ctor_layout_block_map_0_struct mercury_data_frameopt__type_ctor_layout_block_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_frameopt__common_22)
};

static const struct mercury_data_frameopt__type_ctor_functors_block_info_0_struct mercury_data_frameopt__type_ctor_functors_block_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_26)
};

static const struct mercury_data_frameopt__type_ctor_layout_block_info_0_struct mercury_data_frameopt__type_ctor_layout_block_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_26),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(frameopt_module0)
	init_entry(mercury____Index___frameopt__block_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___frameopt__block_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___frameopt__block_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(frameopt_module1)
	init_entry(mercury__frameopt__pick_last__ua0_3_0);
	init_label(mercury__frameopt__pick_last__ua0_3_0_i3);
	init_label(mercury__frameopt__pick_last__ua0_3_0_i5);
	init_label(mercury__frameopt__pick_last__ua0_3_0_i7);
BEGIN_CODE

/* code for predicate 'pick_last__ua0'/3 in mode 0 */
Define_static(mercury__frameopt__pick_last__ua0_3_0);
	MR_incr_sp_push_msg(2, "frameopt:pick_last__ua0/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__pick_last__ua0_3_0_i3);
	r1 = (Word) MR_string_const("empty list in pick_last", 23);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__pick_last__ua0_3_0));
Define_label(mercury__frameopt__pick_last__ua0_3_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__pick_last__ua0_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__frameopt__pick_last__ua0_3_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__frameopt__pick_last__ua0_3_0,
		LABEL(mercury__frameopt__pick_last__ua0_3_0_i7),
		STATIC(mercury__frameopt__pick_last__ua0_3_0));
Define_label(mercury__frameopt__pick_last__ua0_3_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__pick_last__ua0_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__pick_last__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__get_prologue_5_0);
Declare_entry(mercury__opt_util__new_label_no_3_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(frameopt_module2)
	init_entry(mercury__frameopt__frameopt_main_4_0);
	init_label(mercury__frameopt__frameopt_main_4_0_i2);
	init_label(mercury__frameopt__frameopt_main_4_0_i5);
	init_label(mercury__frameopt__frameopt_main_4_0_i7);
	init_label(mercury__frameopt__frameopt_main_4_0_i8);
	init_label(mercury__frameopt__frameopt_main_4_0_i9);
	init_label(mercury__frameopt__frameopt_main_4_0_i10);
	init_label(mercury__frameopt__frameopt_main_4_0_i11);
	init_label(mercury__frameopt__frameopt_main_4_0_i15);
	init_label(mercury__frameopt__frameopt_main_4_0_i17);
	init_label(mercury__frameopt__frameopt_main_4_0_i18);
	init_label(mercury__frameopt__frameopt_main_4_0_i19);
	init_label(mercury__frameopt__frameopt_main_4_0_i20);
	init_label(mercury__frameopt__frameopt_main_4_0_i13);
	init_label(mercury__frameopt__frameopt_main_4_0_i22);
	init_label(mercury__frameopt__frameopt_main_4_0_i23);
	init_label(mercury__frameopt__frameopt_main_4_0_i24);
	init_label(mercury__frameopt__frameopt_main_4_0_i25);
	init_label(mercury__frameopt__frameopt_main_4_0_i26);
	init_label(mercury__frameopt__frameopt_main_4_0_i4);
BEGIN_CODE

/* code for predicate 'frameopt_main'/4 in mode 0 */
Define_entry(mercury__frameopt__frameopt_main_4_0);
	MR_incr_sp_push_msg(9, "frameopt:frameopt_main/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__opt_util__get_prologue_5_0),
		mercury__frameopt__frameopt_main_4_0_i2,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	MR_stackvar(2) = r1;
	r1 = r4;
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r4;
	call_localret(STATIC(mercury__frameopt__detstack_setup_6_0),
		mercury__frameopt__frameopt_main_4_0_i5,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__frameopt_main_4_0_i4);
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(1);
	r2 = (Integer) 1000;
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__opt_util__new_label_no_3_0),
		mercury__frameopt__frameopt_main_4_0_i7,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__frameopt__frameopt_main_4_0_i8,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__frameopt_main_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	call_localret(STATIC(mercury__frameopt__divide_into_basic_blocks_5_0),
		mercury__frameopt__frameopt_main_4_0_i9,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
	}
Define_label(mercury__frameopt__frameopt_main_4_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r5 = r2;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__frameopt__build_block_map_8_0),
		mercury__frameopt__frameopt_main_4_0_i10,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	MR_stackvar(3) = r1;
	MR_stackvar(5) = r3;
	call_localret(STATIC(mercury__frameopt__analyze_block_map_4_0),
		mercury__frameopt__frameopt_main_4_0_i11,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__frameopt_main_4_0_i13);
	MR_stackvar(8) = r1;
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = (Integer) 1;
	call_localret(STATIC(mercury__frameopt__can_delay_frame_3_0),
		mercury__frameopt__frameopt_main_4_0_i15,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__frameopt_main_4_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(5);
	call_localret(STATIC(mercury__frameopt__delay_frame_8_0),
		mercury__frameopt__frameopt_main_4_0_i17,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(4);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_3);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__frameopt_main_4_0_i18,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__frameopt__flatten_block_seq_3_0),
		mercury__frameopt__frameopt_main_4_0_i19,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__frameopt_main_4_0_i20,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i20);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__frameopt__frameopt_main_4_0_i13);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r1;
	MR_stackvar(8) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__frameopt__can_clobber_succip_3_0),
		mercury__frameopt__frameopt_main_4_0_i22,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__frameopt__keep_frame_6_0),
		mercury__frameopt__frameopt_main_4_0_i23,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(4);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_6);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__frameopt_main_4_0_i24,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i24);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__frameopt__flatten_block_seq_3_0),
		mercury__frameopt__frameopt_main_4_0_i25,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i25);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__frameopt_main_4_0_i26,
		ENTRY(mercury__frameopt__frameopt_main_4_0));
Define_label(mercury__frameopt__frameopt_main_4_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__frameopt_main_4_0));
	r2 = (Integer) 1;
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__frameopt__frameopt_main_4_0_i4);
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);

BEGIN_MODULE(frameopt_module3)
	init_entry(mercury__frameopt__flatten_block_seq_3_0);
	init_label(mercury__frameopt__flatten_block_seq_3_0_i4);
	init_label(mercury__frameopt__flatten_block_seq_3_0_i5);
	init_label(mercury__frameopt__flatten_block_seq_3_0_i3);
BEGIN_CODE

/* code for predicate 'flatten_block_seq'/3 in mode 0 */
Define_static(mercury__frameopt__flatten_block_seq_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__flatten_block_seq_3_0_i3);
	MR_incr_sp_push_msg(3, "frameopt:flatten_block_seq/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__frameopt__flatten_block_seq_3_0,
		LABEL(mercury__frameopt__flatten_block_seq_3_0_i4),
		STATIC(mercury__frameopt__flatten_block_seq_3_0));
Define_label(mercury__frameopt__flatten_block_seq_3_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__flatten_block_seq_3_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__flatten_block_seq_3_0_i5,
		STATIC(mercury__frameopt__flatten_block_seq_3_0));
Define_label(mercury__frameopt__flatten_block_seq_3_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__flatten_block_seq_3_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__frameopt__flatten_block_seq_3_0));
Define_label(mercury__frameopt__flatten_block_seq_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__can_instr_branch_away_2_0);

BEGIN_MODULE(frameopt_module4)
	init_entry(mercury__frameopt__divide_into_basic_blocks_5_0);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i3);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i5);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i8);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i11);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i1019);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i4);
	init_label(mercury__frameopt__divide_into_basic_blocks_5_0_i13);
BEGIN_CODE

/* code for predicate 'divide_into_basic_blocks'/5 in mode 0 */
Define_static(mercury__frameopt__divide_into_basic_blocks_5_0);
	MR_incr_sp_push_msg(6, "frameopt:divide_into_basic_blocks/5");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__opt_util__can_instr_branch_away_2_0),
		mercury__frameopt__divide_into_basic_blocks_5_0_i5,
		STATIC(mercury__frameopt__divide_into_basic_blocks_5_0));
	}
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__divide_into_basic_blocks_5_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i4);
	if (((Integer) MR_stackvar(4) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i1019);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0), (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i8);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i8);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__frameopt__divide_into_basic_blocks_5_0,
		LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i13),
		STATIC(mercury__frameopt__divide_into_basic_blocks_5_0));
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i8);
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(0), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), MR_stackvar(5), (Integer) 1) = (Word) MR_string_const("", 0);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_tempr2, MR_mktag(0), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "origin_lost_in_value_number");
	r3 = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_stackvar(5), (Integer) 0) = r1;
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 0) = r2;
	r1 = MR_stackvar(4);
	localcall(mercury__frameopt__divide_into_basic_blocks_5_0,
		LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i11),
		STATIC(mercury__frameopt__divide_into_basic_blocks_5_0));
	}
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__divide_into_basic_blocks_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i1019);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i4);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__frameopt__divide_into_basic_blocks_5_0,
		LABEL(mercury__frameopt__divide_into_basic_blocks_5_0_i13),
		STATIC(mercury__frameopt__divide_into_basic_blocks_5_0));
Define_label(mercury__frameopt__divide_into_basic_blocks_5_0_i13);
	update_prof_current_proc(LABEL(mercury__frameopt__divide_into_basic_blocks_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__divide_into_basic_blocks_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__opt_util__skip_to_next_label_3_0);

BEGIN_MODULE(frameopt_module5)
	init_entry(mercury__frameopt__build_block_map_8_0);
	init_label(mercury__frameopt__build_block_map_8_0_i3);
	init_label(mercury__frameopt__build_block_map_8_0_i8);
	init_label(mercury__frameopt__build_block_map_8_0_i10);
	init_label(mercury__frameopt__build_block_map_8_0_i11);
	init_label(mercury__frameopt__build_block_map_8_0_i15);
	init_label(mercury__frameopt__build_block_map_8_0_i6);
	init_label(mercury__frameopt__build_block_map_8_0_i19);
	init_label(mercury__frameopt__build_block_map_8_0_i21);
	init_label(mercury__frameopt__build_block_map_8_0_i22);
	init_label(mercury__frameopt__build_block_map_8_0_i23);
	init_label(mercury__frameopt__build_block_map_8_0_i1017);
	init_label(mercury__frameopt__build_block_map_8_0_i26);
	init_label(mercury__frameopt__build_block_map_8_0_i27);
	init_label(mercury__frameopt__build_block_map_8_0_i24);
	init_label(mercury__frameopt__build_block_map_8_0_i28);
	init_label(mercury__frameopt__build_block_map_8_0_i29);
	init_label(mercury__frameopt__build_block_map_8_0_i30);
	init_label(mercury__frameopt__build_block_map_8_0_i31);
	init_label(mercury__frameopt__build_block_map_8_0_i17);
	init_label(mercury__frameopt__build_block_map_8_0_i33);
	init_label(mercury__frameopt__build_block_map_8_0_i34);
	init_label(mercury__frameopt__build_block_map_8_0_i35);
	init_label(mercury__frameopt__build_block_map_8_0_i36);
	init_label(mercury__frameopt__build_block_map_8_0_i4);
	init_label(mercury__frameopt__build_block_map_8_0_i39);
BEGIN_CODE

/* code for predicate 'build_block_map'/8 in mode 0 */
Define_static(mercury__frameopt__build_block_map_8_0);
	MR_incr_sp_push_msg(14, "frameopt:build_block_map/8");
	MR_stackvar(14) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i3);
	r2 = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__frameopt__build_block_map_8_0_i3);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i4);
	MR_stackvar(6) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	MR_stackvar(7) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__frameopt__detstack_setup_6_0),
		mercury__frameopt__build_block_map_8_0_i8,
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i6);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 5, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = r5;
	r3 = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__build_block_map_8_0_i10,
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i11);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i11);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	localcall(mercury__frameopt__build_block_map_8_0,
		LABEL(mercury__frameopt__build_block_map_8_0_i15),
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i11);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = ((Integer) MR_stackvar(4) + (Integer) 1);
	r6 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__frameopt__build_block_map_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__frameopt__build_block_map_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	localcall(mercury__frameopt__build_block_map_8_0,
		LABEL(mercury__frameopt__build_block_map_8_0_i15),
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r5 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	r3 = r2;
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__build_block_map_8_0_i27,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i6);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__frameopt__detstack_teardown_8_0),
		mercury__frameopt__build_block_map_8_0_i19,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i17);
	MR_stackvar(5) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = r5;
	MR_stackvar(9) = r3;
	MR_stackvar(10) = r4;
	MR_stackvar(11) = r5;
	MR_stackvar(12) = r6;
	MR_stackvar(13) = r7;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__build_block_map_8_0_i21,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i21);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__build_block_map_8_0_i22,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__build_block_map_8_0_i23,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	if (((Integer) MR_stackvar(5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i24);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	MR_stackvar(5) = r2;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = MR_stackvar(13);
	r3 = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(1);
	GOTO_LABEL(mercury__frameopt__build_block_map_8_0_i1017);
	}
Define_label(mercury__frameopt__build_block_map_8_0_i1017);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_tempr1;
	r3 = MR_stackvar(2);
	localcall(mercury__frameopt__build_block_map_8_0,
		LABEL(mercury__frameopt__build_block_map_8_0_i26),
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r5 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	r3 = r2;
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__build_block_map_8_0_i27,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(9);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__frameopt__build_block_map_8_0_i24);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__frameopt__block_needs_frame_2_0),
		mercury__frameopt__build_block_map_8_0_i28,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i28);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(8);
	MR_stackvar(9) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	r3 = MR_stackvar(10);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), MR_stackvar(9), (Integer) 4) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(3);
	MR_stackvar(10) = r5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 5, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r5;
	MR_stackvar(5) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__frameopt__build_block_map_8_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r3;
	MR_tempr2 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 1) = r7;
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), MR_stackvar(5), (Integer) 4) = MR_tempr1;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = ((Integer) MR_stackvar(4) + (Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	localcall(mercury__frameopt__build_block_map_8_0,
		LABEL(mercury__frameopt__build_block_map_8_0_i29),
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i29);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r5 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	r3 = r2;
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__build_block_map_8_0_i30,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i30);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(9);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__build_block_map_8_0_i31,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i31);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__frameopt__build_block_map_8_0_i17);
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__opt_util__skip_to_next_label_3_0),
		mercury__frameopt__build_block_map_8_0_i33,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i33);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	MR_stackvar(5) = r1;
	MR_stackvar(7) = r2;
	call_localret(STATIC(mercury__frameopt__block_needs_frame_2_0),
		mercury__frameopt__build_block_map_8_0_i34,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i34);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(8);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__frameopt__build_block_map_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 4) = MR_tempr1;
	r1 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	localcall(mercury__frameopt__build_block_map_8_0,
		LABEL(mercury__frameopt__build_block_map_8_0_i35),
		STATIC(mercury__frameopt__build_block_map_8_0));
	}
Define_label(mercury__frameopt__build_block_map_8_0_i35);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r5 = MR_stackvar(1);
	MR_stackvar(5) = r3;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__build_block_map_8_0_i36,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i36);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__build_block_map_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__frameopt__build_block_map_8_0_i4);
	r1 = (Word) MR_string_const("block does not start with label", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__build_block_map_8_0_i39,
		STATIC(mercury__frameopt__build_block_map_8_0));
Define_label(mercury__frameopt__build_block_map_8_0_i39);
	update_prof_current_proc(LABEL(mercury__frameopt__build_block_map_8_0));
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__gather_comments_3_0);

BEGIN_MODULE(frameopt_module6)
	init_entry(mercury__frameopt__detstack_setup_6_0);
	init_label(mercury__frameopt__detstack_setup_6_0_i2);
	init_label(mercury__frameopt__detstack_setup_6_0_i5);
	init_label(mercury__frameopt__detstack_setup_6_0_i1);
BEGIN_CODE

/* code for predicate 'detstack_setup'/6 in mode 0 */
Define_static(mercury__frameopt__detstack_setup_6_0);
	MR_incr_sp_push_msg(4, "frameopt:detstack_setup/6");
	MR_stackvar(4) = (Word) MR_succip;
	call_localret(ENTRY(mercury__opt_util__gather_comments_3_0),
		mercury__frameopt__detstack_setup_6_0_i2,
		STATIC(mercury__frameopt__detstack_setup_6_0));
Define_label(mercury__frameopt__detstack_setup_6_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_setup_6_0));
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_6_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(3) = MR_tempr2;
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 16))
		GOTO_LABEL(mercury__frameopt__detstack_setup_6_0_i1);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__frameopt__detstack_setup_2_6_0),
		mercury__frameopt__detstack_setup_6_0_i5,
		STATIC(mercury__frameopt__detstack_setup_6_0));
	}
Define_label(mercury__frameopt__detstack_setup_6_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_setup_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__detstack_setup_6_0_i1);
	r1 = r2;
	r2 = MR_stackvar(1);
	r5 = r3;
	r3 = MR_stackvar(2);
	r6 = r4;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_setup_6_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_setup_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__frameopt__detstack_setup_6_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module7)
	init_entry(mercury__frameopt__detstack_setup_2_6_0);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i1009);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i5);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i11);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i3);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i18);
	init_label(mercury__frameopt__detstack_setup_2_6_0_i1);
BEGIN_CODE

/* code for predicate 'detstack_setup_2'/6 in mode 0 */
Define_static(mercury__frameopt__detstack_setup_2_6_0);
	MR_incr_sp_push_msg(3, "frameopt:detstack_setup_2/6");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__frameopt__detstack_setup_2_6_0_i1009);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i1);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r6, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i3);
	r7 = MR_const_field(MR_mktag(3), r6, (Integer) 1);
	if ((MR_tag(r7) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r7, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i5);
	r8 = MR_const_field(MR_mktag(3), r7, (Integer) 1);
	if ((r2 != r8))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(3), r6, (Integer) 2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), r6, (Integer) 2), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i5);
	r2 = r5;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__frameopt__detstack_setup_2_6_0_i5);
	if (((Integer) r7 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i1);
	if ((MR_tag(r7) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), r7, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i11);
	if ((r2 == MR_const_field(MR_mktag(3), r7, (Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i1);
Define_label(mercury__frameopt__detstack_setup_2_6_0_i11);
	MR_stackvar(1) = r2;
	r2 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_setup_2_6_0, "origin_lost_in_value_number");
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	MR_stackvar(2) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_setup_2_6_0_i18,
		STATIC(mercury__frameopt__detstack_setup_2_6_0));
Define_label(mercury__frameopt__detstack_setup_2_6_0_i3);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i1);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = r3;
	MR_stackvar(2) = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_setup_2_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_setup_2_6_0_i18,
		STATIC(mercury__frameopt__detstack_setup_2_6_0));
Define_label(mercury__frameopt__detstack_setup_2_6_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_setup_2_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__frameopt__detstack_setup_2_6_0_i1009);
Define_label(mercury__frameopt__detstack_setup_2_6_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module8)
	init_entry(mercury__frameopt__detstack_teardown_8_0);
	init_label(mercury__frameopt__detstack_teardown_8_0_i1001);
	init_label(mercury__frameopt__detstack_teardown_8_0_i3);
	init_label(mercury__frameopt__detstack_teardown_8_0_i6);
	init_label(mercury__frameopt__detstack_teardown_8_0_i8);
	init_label(mercury__frameopt__detstack_teardown_8_0_i11);
BEGIN_CODE

/* code for predicate 'detstack_teardown'/8 in mode 0 */
Define_static(mercury__frameopt__detstack_teardown_8_0);
	MR_incr_sp_push_msg(4, "frameopt:detstack_teardown/8");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_8_0_i1001);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_8_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_8_0_i3);
Define_label(mercury__frameopt__detstack_teardown_8_0_i1001);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__detstack_teardown_8_0_i3);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__frameopt__detstack_teardown_2_12_0),
		mercury__frameopt__detstack_teardown_8_0_i6,
		STATIC(mercury__frameopt__detstack_teardown_8_0));
Define_label(mercury__frameopt__detstack_teardown_8_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_8_0));
	if (r1)
		GOTO_LABEL(mercury__frameopt__detstack_teardown_8_0_i11);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__frameopt__detstack_teardown_8_0,
		LABEL(mercury__frameopt__detstack_teardown_8_0_i8),
		STATIC(mercury__frameopt__detstack_teardown_8_0));
Define_label(mercury__frameopt__detstack_teardown_8_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_8_0_i1001);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_teardown_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
Define_label(mercury__frameopt__detstack_teardown_8_0_i11);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__skip_comments_2_0);
Declare_entry(mercury__opt_util__lval_refers_stackvars_2_0);
Declare_entry(mercury__opt_util__rval_refers_stackvars_2_0);

BEGIN_MODULE(frameopt_module9)
	init_entry(mercury__frameopt__detstack_teardown_2_12_0);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i1016);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i2);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i7);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i8);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i16);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i17);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i18);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i22);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i25);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i6);
	init_label(mercury__frameopt__detstack_teardown_2_12_0_i1);
BEGIN_CODE

/* code for predicate 'detstack_teardown_2'/12 in mode 0 */
Define_static(mercury__frameopt__detstack_teardown_2_12_0);
	MR_incr_sp_push_msg(9, "frameopt:detstack_teardown_2/12");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i1016);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__frameopt__detstack_teardown_2_12_0_i2,
		STATIC(mercury__frameopt__detstack_teardown_2_12_0));
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_12_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r3 = MR_tag(r2);
	if ((r3 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i6);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i7) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i22) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i25) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1) AND
		LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1));
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i7);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r4 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i8);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i8);
	r7 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r7) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i8);
	if (((Integer) MR_const_field(MR_mktag(3), r7, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i8);
	if ((MR_stackvar(1) != MR_const_field(MR_mktag(3), r7, (Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i8);
	if (((Integer) MR_stackvar(3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r1 = r5;
	r5 = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_teardown_2_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r6;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r6 = MR_stackvar(5);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1016);
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i8);
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r5;
	MR_stackvar(8) = r3;
	r1 = r4;
	call_localret(ENTRY(mercury__opt_util__lval_refers_stackvars_2_0),
		mercury__frameopt__detstack_teardown_2_12_0_i16,
		STATIC(mercury__frameopt__detstack_teardown_2_12_0));
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_12_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__opt_util__rval_refers_stackvars_2_0),
		mercury__frameopt__detstack_teardown_2_12_0_i17,
		STATIC(mercury__frameopt__detstack_teardown_2_12_0));
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_12_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_teardown_2_12_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__detstack_teardown_2_12_0_i18,
		STATIC(mercury__frameopt__detstack_teardown_2_12_0));
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__detstack_teardown_2_12_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1016);
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i22);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = TRUE;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_tempr1;
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i25);
	if ((MR_stackvar(1) != MR_const_field(MR_mktag(3), r2, (Integer) 1)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r2 = MR_stackvar(1);
	r6 = r1;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_teardown_2_12_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1016);
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i6);
	if ((r3 != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	if (((Integer) MR_stackvar(5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__frameopt__detstack_teardown_2_12_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_const_field(MR_mktag(1), r7, (Integer) 0);
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__frameopt__detstack_teardown_2_12_0_i1016);
Define_label(mercury__frameopt__detstack_teardown_2_12_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
Declare_entry(mercury__list__member_2_1);
Declare_entry(do_redo);

BEGIN_MODULE(frameopt_module10)
	init_entry(mercury__frameopt__block_needs_frame_2_0);
	init_label(mercury__frameopt__block_needs_frame_2_0_i2);
	init_label(mercury__frameopt__block_needs_frame_2_0_i1000);
	init_label(mercury__frameopt__block_needs_frame_2_0_i3);
	init_label(mercury__frameopt__block_needs_frame_2_0_i9);
	init_label(mercury__frameopt__block_needs_frame_2_0_i16);
	init_label(mercury__frameopt__block_needs_frame_2_0_i11);
	init_label(mercury__frameopt__block_needs_frame_2_0_i1020);
	init_label(mercury__frameopt__block_needs_frame_2_0_i1024);
BEGIN_CODE

/* code for predicate 'block_needs_frame'/2 in mode 0 */
Define_static(mercury__frameopt__block_needs_frame_2_0);
	MR_incr_sp_push_msg(5, "frameopt:block_needs_frame/2");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__frameopt__block_needs_frame_2_0_i2,
		STATIC(mercury__frameopt__block_needs_frame_2_0));
Define_label(mercury__frameopt__block_needs_frame_2_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__block_needs_frame_2_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i3);
Define_label(mercury__frameopt__block_needs_frame_2_0_i1000);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__frameopt__block_needs_frame_2_0_i3);
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__frameopt__block_needs_frame_2_0_i1024);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__frameopt__block_needs_frame_2_0_i9,
		STATIC(mercury__frameopt__block_needs_frame_2_0));
Define_label(mercury__frameopt__block_needs_frame_2_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__block_needs_frame_2_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i11);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i1020) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i1020) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i1020) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i16) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11) AND
		LABEL(mercury__frameopt__block_needs_frame_2_0_i11));
Define_label(mercury__frameopt__block_needs_frame_2_0_i16);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 6);
	if (((Integer) r3 == (Integer) 0))
		GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i1020);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i1020);
	if (((Integer) r1 != (Integer) 1))
		GOTO(ENTRY(do_redo));
	GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i1020);
Define_label(mercury__frameopt__block_needs_frame_2_0_i11);
	GOTO(ENTRY(do_redo));
Define_label(mercury__frameopt__block_needs_frame_2_0_i1020);
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	GOTO_LABEL(mercury__frameopt__block_needs_frame_2_0_i1000);
Define_label(mercury__frameopt__block_needs_frame_2_0_i1024);
	update_prof_current_proc(LABEL(mercury__frameopt__block_needs_frame_2_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury____Unify___llds__label_0_0);

BEGIN_MODULE(frameopt_module11)
	init_entry(mercury__frameopt__analyze_block_map_4_0);
	init_label(mercury__frameopt__analyze_block_map_4_0_i6);
	init_label(mercury__frameopt__analyze_block_map_4_0_i8);
	init_label(mercury__frameopt__analyze_block_map_4_0_i11);
	init_label(mercury__frameopt__analyze_block_map_4_0_i12);
	init_label(mercury__frameopt__analyze_block_map_4_0_i1009);
	init_label(mercury__frameopt__analyze_block_map_4_0_i3);
BEGIN_CODE

/* code for predicate 'analyze_block_map'/4 in mode 0 */
Define_static(mercury__frameopt__analyze_block_map_4_0);
	MR_incr_sp_push_msg(6, "frameopt:analyze_block_map/4");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i1009);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i1009);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__analyze_block_map_4_0_i6,
		STATIC(mercury__frameopt__analyze_block_map_4_0));
	}
Define_label(mercury__frameopt__analyze_block_map_4_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__analyze_block_map_4_0_i8,
		STATIC(mercury__frameopt__analyze_block_map_4_0));
Define_label(mercury__frameopt__analyze_block_map_4_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i3);
	if (((Integer) MR_stackvar(5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i3);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = (Integer) 0;
	call_localret(STATIC(mercury__frameopt__analyze_block_map_2_6_0),
		mercury__frameopt__analyze_block_map_4_0_i11,
		STATIC(mercury__frameopt__analyze_block_map_4_0));
Define_label(mercury__frameopt__analyze_block_map_4_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_4_0));
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_4_0_i12);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__frameopt__analyze_block_map_4_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__frameopt__analyze_block_map_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__analyze_block_map_4_0_i12);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__analyze_block_map_4_0_i1009);
	r1 = (Word) MR_string_const("bad data in analyze_block_map", 29);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__analyze_block_map_4_0));
Define_label(mercury__frameopt__analyze_block_map_4_0_i3);
	r1 = (Word) MR_string_const("bad data in analyze_block_map", 29);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__frameopt__analyze_block_map_4_0));
END_MODULE

Declare_entry(mercury__list__last_2_0);
Declare_entry(mercury__opt_util__possible_targets_2_0);
Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
Declare_entry(mercury____Unify___llds__proc_label_0_0);
Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(frameopt_module12)
	init_entry(mercury__frameopt__analyze_block_map_2_6_0);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i1022);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i4);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i6);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i8);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i10);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i12);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i11);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i14);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i43);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i39);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i40);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i36);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i37);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i25);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i28);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i27);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i31);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i21);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i23);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i19);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i16);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i5);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i46);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i48);
	init_label(mercury__frameopt__analyze_block_map_2_6_0_i3);
BEGIN_CODE

/* code for predicate 'analyze_block_map_2'/6 in mode 0 */
Define_static(mercury__frameopt__analyze_block_map_2_6_0);
	MR_incr_sp_push_msg(13, "frameopt:analyze_block_map_2/6");
	MR_stackvar(13) = (Word) MR_succip;
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i1022);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__analyze_block_map_2_6_0_i4,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i6,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__last_2_0),
		mercury__frameopt__analyze_block_map_2_6_0_i8,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i5);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__opt_util__possible_targets_2_0),
		mercury__frameopt__analyze_block_map_2_6_0_i10,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__frameopt__analyze_block_map_2_6_0_i12,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i11);
	r2 = MR_stackvar(5);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__frameopt__analyze_block_map_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(11) = r3;
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i14);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i11);
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i14);
	if ((MR_tag(MR_stackvar(9)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r1 = MR_stackvar(2);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i21);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i25);
	if ((r2 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1), (Integer) 0);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i36);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i39);
	if ((r3 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i43,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i43);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i19);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i39);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i40,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i40);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i19);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i36);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i37,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i37);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i19);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i25);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i27);
	r3 = MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i28,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i28);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i19);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i27);
	r3 = MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i31,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
	}
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i31);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i19);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i21);
	r3 = MR_const_field(MR_mktag(3), MR_stackvar(9), (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__analyze_block_map_2_6_0_i23,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
	}
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i19);
	MR_stackvar(12) = (Integer) 1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__analyze_block_map_2_6_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(8);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__analyze_block_map_2_6_0_i48,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i16);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	MR_stackvar(12) = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__analyze_block_map_2_6_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(8);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__analyze_block_map_2_6_0_i48,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i5);
	r1 = (Word) MR_string_const("bad data in analyze_block_map_2", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__analyze_block_map_2_6_0_i46,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i46);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	r5 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__analyze_block_map_2_6_0_i48,
		STATIC(mercury__frameopt__analyze_block_map_2_6_0));
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i48);
	update_prof_current_proc(LABEL(mercury__frameopt__analyze_block_map_2_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__frameopt__analyze_block_map_2_6_0_i1022);
Define_label(mercury__frameopt__analyze_block_map_2_6_0_i3);
	r1 = r2;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module13)
	init_entry(mercury__frameopt__can_clobber_succip_3_0);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i1004);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i3);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i4);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i9);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i1008);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i12);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i1027);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i1031);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i14);
	init_label(mercury__frameopt__can_clobber_succip_3_0_i6);
BEGIN_CODE

/* code for predicate 'can_clobber_succip'/3 in mode 0 */
Define_static(mercury__frameopt__can_clobber_succip_3_0);
	MR_incr_sp_push_msg(6, "frameopt:can_clobber_succip/3");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__frameopt__can_clobber_succip_3_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i3);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__can_clobber_succip_3_0_i3);
	r3 = r2;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__can_clobber_succip_3_0_i4,
		STATIC(mercury__frameopt__can_clobber_succip_3_0));
Define_label(mercury__frameopt__can_clobber_succip_3_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__can_clobber_succip_3_0));
	MR_stackvar(3) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__frameopt__can_clobber_succip_3_0_i1031);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__frameopt__can_clobber_succip_3_0_i9,
		STATIC(mercury__frameopt__can_clobber_succip_3_0));
Define_label(mercury__frameopt__can_clobber_succip_3_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__can_clobber_succip_3_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i1008);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 == (Integer) 2))
		GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i1027);
Define_label(mercury__frameopt__can_clobber_succip_3_0_i1008);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i12);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 18))
		GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i12);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3) != (Integer) 0))
		GOTO(ENTRY(do_redo));
	GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i1027);
Define_label(mercury__frameopt__can_clobber_succip_3_0_i12);
	GOTO(ENTRY(do_redo));
Define_label(mercury__frameopt__can_clobber_succip_3_0_i1027);
	MR_maxfr = (Word *) MR_stackvar(5);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(3);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i14);
Define_label(mercury__frameopt__can_clobber_succip_3_0_i1031);
	update_prof_current_proc(LABEL(mercury__frameopt__can_clobber_succip_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(3);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i6);
Define_label(mercury__frameopt__can_clobber_succip_3_0_i14);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__frameopt__can_clobber_succip_3_0_i6);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__frameopt__can_clobber_succip_3_0_i1004);
END_MODULE

Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(frameopt_module14)
	init_entry(mercury__frameopt__keep_frame_6_0);
	init_label(mercury__frameopt__keep_frame_6_0_i1026);
	init_label(mercury__frameopt__keep_frame_6_0_i4);
	init_label(mercury__frameopt__keep_frame_6_0_i6);
	init_label(mercury__frameopt__keep_frame_6_0_i38);
	init_label(mercury__frameopt__keep_frame_6_0_i34);
	init_label(mercury__frameopt__keep_frame_6_0_i35);
	init_label(mercury__frameopt__keep_frame_6_0_i31);
	init_label(mercury__frameopt__keep_frame_6_0_i32);
	init_label(mercury__frameopt__keep_frame_6_0_i20);
	init_label(mercury__frameopt__keep_frame_6_0_i23);
	init_label(mercury__frameopt__keep_frame_6_0_i22);
	init_label(mercury__frameopt__keep_frame_6_0_i26);
	init_label(mercury__frameopt__keep_frame_6_0_i16);
	init_label(mercury__frameopt__keep_frame_6_0_i18);
	init_label(mercury__frameopt__keep_frame_6_0_i14);
	init_label(mercury__frameopt__keep_frame_6_0_i40);
	init_label(mercury__frameopt__keep_frame_6_0_i43);
	init_label(mercury__frameopt__keep_frame_6_0_i45);
	init_label(mercury__frameopt__keep_frame_6_0_i46);
	init_label(mercury__frameopt__keep_frame_6_0_i49);
	init_label(mercury__frameopt__keep_frame_6_0_i47);
	init_label(mercury__frameopt__keep_frame_6_0_i51);
	init_label(mercury__frameopt__keep_frame_6_0_i5);
	init_label(mercury__frameopt__keep_frame_6_0_i3);
BEGIN_CODE

/* code for predicate 'keep_frame'/6 in mode 0 */
Define_static(mercury__frameopt__keep_frame_6_0);
	MR_incr_sp_push_msg(11, "frameopt:keep_frame/6");
	MR_stackvar(11) = (Word) MR_succip;
Define_label(mercury__frameopt__keep_frame_6_0_i1026);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__keep_frame_6_0_i4,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__keep_frame_6_0_i6,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if (((Integer) MR_stackvar(8) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_stackvar(8), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if (((Integer) MR_stackvar(9) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if ((MR_tag(MR_stackvar(10)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_stackvar(10), (Integer) 2), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_stackvar(10), (Integer) 2), (Integer) 0), (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_stackvar(10), (Integer) 2), (Integer) 0), (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(2);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i16);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i20);
	if ((r2 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_stackvar(10), (Integer) 2), (Integer) 0), (Integer) 1), (Integer) 0);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i31);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i34);
	if ((r3 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(10);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 2), (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i38,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i38);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i14);
Define_label(mercury__frameopt__keep_frame_6_0_i34);
	r3 = MR_stackvar(10);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r3, (Integer) 2), (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i35,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i35);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i14);
Define_label(mercury__frameopt__keep_frame_6_0_i31);
	r3 = MR_stackvar(10);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r3, (Integer) 2), (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i32,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i32);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i14);
Define_label(mercury__frameopt__keep_frame_6_0_i20);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), MR_stackvar(10), (Integer) 2), (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i22);
	r3 = MR_stackvar(10);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r3, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i23,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i14);
Define_label(mercury__frameopt__keep_frame_6_0_i22);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr2 = MR_stackvar(10);
	MR_tempr1 = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 2);
	r3 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1);
	MR_tempr3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), MR_tempr3, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i26,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i26);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i14);
Define_label(mercury__frameopt__keep_frame_6_0_i16);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr2 = MR_stackvar(10);
	MR_tempr1 = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 2);
	r3 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1);
	MR_tempr3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___llds__proc_label_0_0),
		mercury__frameopt__keep_frame_6_0_i18,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i5);
	r1 = MR_stackvar(10);
Define_label(mercury__frameopt__keep_frame_6_0_i14);
	if (((Integer) MR_stackvar(7) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i40);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_stackvar(7), (Integer) 0), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i40);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i40);
	r2 = MR_stackvar(7);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = r2;
	r2 = (Word) MR_string_const(" (keeping frame)", 16);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__frameopt__keep_frame_6_0_i45,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i40);
	MR_stackvar(10) = r1;
	r1 = (Word) MR_string_const("block does not begin with label", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__keep_frame_6_0_i43,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i43);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	r2 = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__frameopt__keep_frame_6_0_i45,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i45);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__keep_frame_6_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__frameopt__keep_frame_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__frameopt__keep_frame_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__frameopt__keep_frame_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__keep_frame_6_0_i46,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i46);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i47);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__keep_frame_6_0_i49,
		STATIC(mercury__frameopt__keep_frame_6_0));
Define_label(mercury__frameopt__keep_frame_6_0_i49);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__keep_frame_6_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__keep_frame_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__keep_frame_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_7);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__keep_frame_6_0_i51,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i47);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__keep_frame_6_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__keep_frame_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__keep_frame_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_7);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__keep_frame_6_0_i51,
		STATIC(mercury__frameopt__keep_frame_6_0));
	}
Define_label(mercury__frameopt__keep_frame_6_0_i51);
	update_prof_current_proc(LABEL(mercury__frameopt__keep_frame_6_0));
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i1026);
Define_label(mercury__frameopt__keep_frame_6_0_i5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__frameopt__keep_frame_6_0_i1026);
Define_label(mercury__frameopt__keep_frame_6_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module15)
	init_entry(mercury__frameopt__can_delay_frame_3_0);
	init_label(mercury__frameopt__can_delay_frame_3_0_i1011);
	init_label(mercury__frameopt__can_delay_frame_3_0_i4);
	init_label(mercury__frameopt__can_delay_frame_3_0_i9);
	init_label(mercury__frameopt__can_delay_frame_3_0_i1005);
	init_label(mercury__frameopt__can_delay_frame_3_0_i5);
	init_label(mercury__frameopt__can_delay_frame_3_0_i1);
BEGIN_CODE

/* code for predicate 'can_delay_frame'/3 in mode 0 */
Define_static(mercury__frameopt__can_delay_frame_3_0);
	MR_incr_sp_push_msg(4, "frameopt:can_delay_frame/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__frameopt__can_delay_frame_3_0_i1011);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1005);
	MR_stackvar(2) = r3;
	r3 = r2;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__can_delay_frame_3_0_i4,
		STATIC(mercury__frameopt__can_delay_frame_3_0));
Define_label(mercury__frameopt__can_delay_frame_3_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__can_delay_frame_3_0));
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i5);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1);
	r4 = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__can_delay_frame_3_0_i9,
		STATIC(mercury__frameopt__can_delay_frame_3_0));
	}
Define_label(mercury__frameopt__can_delay_frame_3_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__can_delay_frame_3_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1);
Define_label(mercury__frameopt__can_delay_frame_3_0_i1005);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__frameopt__can_delay_frame_3_0_i5);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__frameopt__can_delay_frame_3_0_i1011);
Define_label(mercury__frameopt__can_delay_frame_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__queue__init_1_0);
Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(frameopt_module16)
	init_entry(mercury__frameopt__delay_frame_8_0);
	init_label(mercury__frameopt__delay_frame_8_0_i2);
	init_label(mercury__frameopt__delay_frame_8_0_i3);
	init_label(mercury__frameopt__delay_frame_8_0_i4);
	init_label(mercury__frameopt__delay_frame_8_0_i5);
	init_label(mercury__frameopt__delay_frame_8_0_i6);
	init_label(mercury__frameopt__delay_frame_8_0_i7);
	init_label(mercury__frameopt__delay_frame_8_0_i8);
	init_label(mercury__frameopt__delay_frame_8_0_i9);
BEGIN_CODE

/* code for predicate 'delay_frame'/8 in mode 0 */
Define_static(mercury__frameopt__delay_frame_8_0);
	MR_incr_sp_push_msg(9, "frameopt:delay_frame/8");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__frameopt__delay_frame_8_0_i2,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__frameopt__delay_frame_8_0_i3,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i3);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	call_localret(STATIC(mercury__frameopt__delay_frame_init_6_0),
		mercury__frameopt__delay_frame_8_0_i4,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__frameopt__delay_frame_8_0_i5,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	r4 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	call_localret(STATIC(mercury__frameopt__propagate_framed_labels_5_0),
		mercury__frameopt__delay_frame_8_0_i6,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__frameopt__delay_frame_8_0_i7,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__frameopt__delay_frame_8_0_i8,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	r8 = MR_stackvar(5);
	r9 = MR_stackvar(6);
	call_localret(STATIC(mercury__frameopt__process_frame_delay_13_0),
		mercury__frameopt__delay_frame_8_0_i9,
		STATIC(mercury__frameopt__delay_frame_8_0));
Define_label(mercury__frameopt__delay_frame_8_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_8_0));
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__frameopt__create_parallels_6_0),
		STATIC(mercury__frameopt__delay_frame_8_0));
END_MODULE

Declare_entry(mercury__queue__put_3_0);

BEGIN_MODULE(frameopt_module17)
	init_entry(mercury__frameopt__delay_frame_init_6_0);
	init_label(mercury__frameopt__delay_frame_init_6_0_i1007);
	init_label(mercury__frameopt__delay_frame_init_6_0_i4);
	init_label(mercury__frameopt__delay_frame_init_6_0_i7);
	init_label(mercury__frameopt__delay_frame_init_6_0_i1003);
	init_label(mercury__frameopt__delay_frame_init_6_0_i9);
	init_label(mercury__frameopt__delay_frame_init_6_0_i10);
	init_label(mercury__frameopt__delay_frame_init_6_0_i12);
	init_label(mercury__frameopt__delay_frame_init_6_0_i3);
BEGIN_CODE

/* code for predicate 'delay_frame_init'/6 in mode 0 */
Define_static(mercury__frameopt__delay_frame_init_6_0);
	MR_incr_sp_push_msg(6, "frameopt:delay_frame_init/6");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__frameopt__delay_frame_init_6_0_i1007);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__delay_frame_init_6_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__delay_frame_init_6_0_i4,
		STATIC(mercury__frameopt__delay_frame_init_6_0));
Define_label(mercury__frameopt__delay_frame_init_6_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_init_6_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__delay_frame_init_6_0_i7);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__delay_frame_init_6_0_i1003);
	r3 = MR_stackvar(2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r2 = MR_stackvar(4);
	MR_stackvar(2) = MR_stackvar(3);
	call_localret(STATIC(mercury__frameopt__rev_map_side_labels_4_0),
		mercury__frameopt__delay_frame_init_6_0_i12,
		STATIC(mercury__frameopt__delay_frame_init_6_0));
Define_label(mercury__frameopt__delay_frame_init_6_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__frameopt__delay_frame_init_6_0_i9);
Define_label(mercury__frameopt__delay_frame_init_6_0_i1003);
	r3 = MR_stackvar(2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r2 = MR_stackvar(4);
	MR_stackvar(2) = MR_stackvar(3);
	call_localret(STATIC(mercury__frameopt__rev_map_side_labels_4_0),
		mercury__frameopt__delay_frame_init_6_0_i12,
		STATIC(mercury__frameopt__delay_frame_init_6_0));
Define_label(mercury__frameopt__delay_frame_init_6_0_i9);
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__frameopt__delay_frame_init_6_0_i10,
		STATIC(mercury__frameopt__delay_frame_init_6_0));
Define_label(mercury__frameopt__delay_frame_init_6_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_init_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__frameopt__rev_map_side_labels_4_0),
		mercury__frameopt__delay_frame_init_6_0_i12,
		STATIC(mercury__frameopt__delay_frame_init_6_0));
Define_label(mercury__frameopt__delay_frame_init_6_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__delay_frame_init_6_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__frameopt__delay_frame_init_6_0_i1007);
Define_label(mercury__frameopt__delay_frame_init_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module18)
	init_entry(mercury__frameopt__rev_map_side_labels_4_0);
	init_label(mercury__frameopt__rev_map_side_labels_4_0_i1002);
	init_label(mercury__frameopt__rev_map_side_labels_4_0_i5);
	init_label(mercury__frameopt__rev_map_side_labels_4_0_i4);
	init_label(mercury__frameopt__rev_map_side_labels_4_0_i8);
	init_label(mercury__frameopt__rev_map_side_labels_4_0_i3);
BEGIN_CODE

/* code for predicate 'rev_map_side_labels'/4 in mode 0 */
Define_static(mercury__frameopt__rev_map_side_labels_4_0);
	MR_incr_sp_push_msg(5, "frameopt:rev_map_side_labels/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__frameopt__rev_map_side_labels_4_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__rev_map_side_labels_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__rev_map_side_labels_4_0_i5,
		STATIC(mercury__frameopt__rev_map_side_labels_4_0));
Define_label(mercury__frameopt__rev_map_side_labels_4_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__rev_map_side_labels_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__rev_map_side_labels_4_0_i4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__frameopt__rev_map_side_labels_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__rev_map_side_labels_4_0_i8,
		STATIC(mercury__frameopt__rev_map_side_labels_4_0));
Define_label(mercury__frameopt__rev_map_side_labels_4_0_i4);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__frameopt__rev_map_side_labels_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__rev_map_side_labels_4_0_i8,
		STATIC(mercury__frameopt__rev_map_side_labels_4_0));
Define_label(mercury__frameopt__rev_map_side_labels_4_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__rev_map_side_labels_4_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__frameopt__rev_map_side_labels_4_0_i1002);
Define_label(mercury__frameopt__rev_map_side_labels_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__queue__get_3_0);
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__queue__put_list_3_0);

BEGIN_MODULE(frameopt_module19)
	init_entry(mercury__frameopt__propagate_framed_labels_5_0);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i1005);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i3);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i6);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i9);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i11);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i13);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i14);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i16);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i18);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i15);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i5);
	init_label(mercury__frameopt__propagate_framed_labels_5_0_i2);
BEGIN_CODE

/* code for predicate 'propagate_framed_labels'/5 in mode 0 */
Define_static(mercury__frameopt__propagate_framed_labels_5_0);
	MR_incr_sp_push_msg(8, "frameopt:propagate_framed_labels/5");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i1005);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__frameopt__propagate_framed_labels_5_0_i3,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i3);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i2);
	r4 = r2;
	MR_stackvar(4) = r2;
	MR_stackvar(5) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__propagate_framed_labels_5_0_i6,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 4)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__propagate_framed_labels_5_0_i9,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	if (r1)
		GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i5);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__frameopt__propagate_framed_labels_5_0_i11,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	if (((Integer) MR_stackvar(7) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i13);
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__frameopt__propagate_framed_labels_5_0_i14,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__propagate_framed_labels_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(6);
	MR_stackvar(6) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(7), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__frameopt__propagate_framed_labels_5_0_i14,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__propagate_framed_labels_5_0_i16,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i15);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = r2;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__queue__put_list_3_0),
		mercury__frameopt__propagate_framed_labels_5_0_i18,
		STATIC(mercury__frameopt__propagate_framed_labels_5_0));
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__propagate_framed_labels_5_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i1005);
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i15);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i1005);
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i5);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__frameopt__propagate_framed_labels_5_0_i1005);
Define_label(mercury__frameopt__propagate_framed_labels_5_0_i2);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module20)
	init_entry(mercury__frameopt__process_frame_delay_13_0);
	init_label(mercury__frameopt__process_frame_delay_13_0_i3);
	init_label(mercury__frameopt__process_frame_delay_13_0_i4);
	init_label(mercury__frameopt__process_frame_delay_13_0_i7);
	init_label(mercury__frameopt__process_frame_delay_13_0_i1001);
	init_label(mercury__frameopt__process_frame_delay_13_0_i5);
	init_label(mercury__frameopt__process_frame_delay_13_0_i10);
	init_label(mercury__frameopt__process_frame_delay_13_0_i24);
	init_label(mercury__frameopt__process_frame_delay_13_0_i23);
	init_label(mercury__frameopt__process_frame_delay_13_0_i22);
	init_label(mercury__frameopt__process_frame_delay_13_0_i27);
	init_label(mercury__frameopt__process_frame_delay_13_0_i28);
	init_label(mercury__frameopt__process_frame_delay_13_0_i29);
	init_label(mercury__frameopt__process_frame_delay_13_0_i32);
	init_label(mercury__frameopt__process_frame_delay_13_0_i33);
	init_label(mercury__frameopt__process_frame_delay_13_0_i35);
	init_label(mercury__frameopt__process_frame_delay_13_0_i34);
	init_label(mercury__frameopt__process_frame_delay_13_0_i37);
	init_label(mercury__frameopt__process_frame_delay_13_0_i20);
	init_label(mercury__frameopt__process_frame_delay_13_0_i13);
	init_label(mercury__frameopt__process_frame_delay_13_0_i15);
	init_label(mercury__frameopt__process_frame_delay_13_0_i17);
	init_label(mercury__frameopt__process_frame_delay_13_0_i14);
BEGIN_CODE

/* code for predicate 'process_frame_delay'/13 in mode 0 */
Define_static(mercury__frameopt__process_frame_delay_13_0);
	MR_incr_sp_push_msg(18, "frameopt:process_frame_delay/13");
	MR_stackvar(18) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__frameopt__process_frame_delay_13_0_i3);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(10) = r4;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(11) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r9;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__process_frame_delay_13_0_i4,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(12) = r1;
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__process_frame_delay_13_0_i7,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i7);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i5);
Define_label(mercury__frameopt__process_frame_delay_13_0_i1001);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r3 = MR_stackvar(5);
	r2 = MR_stackvar(10);
	GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i10);
Define_label(mercury__frameopt__process_frame_delay_13_0_i5);
	r1 = (Word) MR_string_const("label in block_info is not copy", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__process_frame_delay_13_0_i1001,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i10);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(MR_stackvar(16));
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i13);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i20);
	if (((Integer) MR_stackvar(15) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i23);
	r1 = (Word) MR_string_const("no fallthrough for setup block", 30);
	MR_stackvar(5) = r3;
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__process_frame_delay_13_0_i24,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
	}
Define_label(mercury__frameopt__process_frame_delay_13_0_i24);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r3 = MR_stackvar(5);
	r2 = MR_stackvar(17);
	GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i22);
Define_label(mercury__frameopt__process_frame_delay_13_0_i23);
	MR_stackvar(10) = r2;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(15), (Integer) 0);
Define_label(mercury__frameopt__process_frame_delay_13_0_i22);
	if (((Integer) MR_stackvar(14) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i28);
	MR_stackvar(5) = r3;
	MR_stackvar(17) = r2;
	r1 = (Word) MR_string_const("nonempty side labels for setup block", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__process_frame_delay_13_0_i27,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r3 = MR_stackvar(5);
	r2 = MR_stackvar(17);
Define_label(mercury__frameopt__process_frame_delay_13_0_i28);
	if (((Integer) MR_stackvar(13) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i29);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_stackvar(13), (Integer) 0), (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i29);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i29);
	MR_stackvar(17) = MR_const_field(MR_mktag(1), MR_stackvar(13), (Integer) 0);
	GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i33);
Define_label(mercury__frameopt__process_frame_delay_13_0_i29);
	MR_stackvar(5) = r3;
	MR_stackvar(17) = r2;
	r1 = (Word) MR_string_const("setup block does not begin with label", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__process_frame_delay_13_0_i32,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i32);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r3 = MR_stackvar(5);
	r2 = MR_stackvar(17);
Define_label(mercury__frameopt__process_frame_delay_13_0_i33);
	MR_stackvar(5) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__process_frame_delay_13_0_i35,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i35);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i34);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__frameopt__process_frame_delay_13_0_i34);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(10);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__process_frame_delay_13_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__process_frame_delay_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(17);
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_9);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(15);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(14);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__frameopt__process_frame_delay_13_0_i37,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
	}
Define_label(mercury__frameopt__process_frame_delay_13_0_i37);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r2 = r1;
	r1 = MR_stackvar(11);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	localcall(mercury__frameopt__process_frame_delay_13_0,
		LABEL(mercury__frameopt__process_frame_delay_13_0_i17),
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i20);
	r5 = r3;
	MR_stackvar(10) = r2;
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	localcall(mercury__frameopt__process_frame_delay_13_0,
		LABEL(mercury__frameopt__process_frame_delay_13_0_i17),
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i13);
	MR_stackvar(5) = r3;
	MR_stackvar(10) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__process_frame_delay_13_0_i15,
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__process_frame_delay_13_0_i14);
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	localcall(mercury__frameopt__process_frame_delay_13_0,
		LABEL(mercury__frameopt__process_frame_delay_13_0_i17),
		STATIC(mercury__frameopt__process_frame_delay_13_0));
Define_label(mercury__frameopt__process_frame_delay_13_0_i17);
	update_prof_current_proc(LABEL(mercury__frameopt__process_frame_delay_13_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__process_frame_delay_13_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__frameopt__process_frame_delay_13_0_i14);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(12);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(8);
	r11 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	tailcall(STATIC(mercury__frameopt__transform_ordinary_block_15_0),
		STATIC(mercury__frameopt__process_frame_delay_13_0));
END_MODULE

Declare_entry(mercury__map__from_assoc_list_2_0);
Declare_entry(mercury__opt_util__replace_labels_instruction_4_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(frameopt_module21)
	init_entry(mercury__frameopt__transform_ordinary_block_15_0);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i2);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i3);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i4);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i5);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i6);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i8);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i9);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i21);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i18);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i19);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i20);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i12);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i14);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i16);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i13);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i7);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i22);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i23);
	init_label(mercury__frameopt__transform_ordinary_block_15_0_i24);
BEGIN_CODE

/* code for predicate 'transform_ordinary_block'/15 in mode 0 */
Define_static(mercury__frameopt__transform_ordinary_block_15_0);
	MR_incr_sp_push_msg(17, "frameopt:transform_ordinary_block/15");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	r2 = r4;
	MR_stackvar(3) = r4;
	r3 = r10;
	r4 = r11;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r10;
	call_localret(STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0),
		mercury__frameopt__transform_ordinary_block_15_0_i2,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i2);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(12) = r2;
	MR_stackvar(13) = r3;
	MR_stackvar(14) = r4;
	call_localret(STATIC(mercury__frameopt__pick_last__ua0_3_0),
		mercury__frameopt__transform_ordinary_block_15_0_i3,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
	}
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i3);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r3 = MR_stackvar(12);
	MR_stackvar(12) = r1;
	MR_stackvar(15) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__frameopt__transform_ordinary_block_15_0_i4,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r2 = r1;
	r1 = MR_stackvar(15);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__opt_util__replace_labels_instruction_4_0),
		mercury__frameopt__transform_ordinary_block_15_0_i5,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(12);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__transform_ordinary_block_15_0_i6,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	if (((Integer) MR_stackvar(10) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i8);
	r4 = MR_stackvar(1);
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(16) = MR_stackvar(13);
	r3 = MR_stackvar(3);
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i7);
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i8);
	MR_stackvar(12) = r1;
	r4 = MR_const_field(MR_mktag(1), MR_stackvar(10), (Integer) 0);
	MR_stackvar(15) = r4;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__transform_ordinary_block_15_0_i9,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i9);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i12);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i18);
	r1 = (Word) MR_string_const("ordinary block falls through to setup", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__transform_ordinary_block_15_0_i21,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i21);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r5 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i7);
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i18);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(15);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__frameopt__transform_ordinary_block_15_0_i19,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i19);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(15);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(13);
	r4 = MR_stackvar(14);
	call_localret(STATIC(mercury__frameopt__mark_parallel_7_0),
		mercury__frameopt__transform_ordinary_block_15_0_i20,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i20);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	MR_stackvar(14) = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(16) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i7);
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i12);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(15);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__transform_ordinary_block_15_0_i14,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i13);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(8);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(13);
	MR_stackvar(16) = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	MR_stackvar(15) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__transform_ordinary_block_15_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("late setup label", 16);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 16;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("late setup", 10);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 3, mercury__frameopt__transform_ordinary_block_15_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), r10, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("late save", 9);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__transform_ordinary_block_15_0_i16,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
	}
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i16);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r4 = MR_stackvar(1);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(15);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i7);
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i13);
	r4 = MR_stackvar(1);
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(16) = MR_stackvar(13);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__transform_ordinary_block_15_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(0), r5, (Integer) 4) = MR_stackvar(11);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i7);
	MR_stackvar(1) = r4;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__frameopt__transform_ordinary_block_15_0_i22,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(14);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(16);
	call_localret(STATIC(mercury__frameopt__process_frame_delay_13_0),
		mercury__frameopt__transform_ordinary_block_15_0_i23,
		STATIC(mercury__frameopt__transform_ordinary_block_15_0));
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i23);
	update_prof_current_proc(LABEL(mercury__frameopt__transform_ordinary_block_15_0));
	if (((Integer) MR_stackvar(15) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__transform_ordinary_block_15_0_i24);
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(15), (Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
Define_label(mercury__frameopt__transform_ordinary_block_15_0_i24);
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__transform_ordinary_block_15_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module22)
	init_entry(mercury__frameopt__mark_parallels_for_teardown_9_0);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i4);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i14);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i8);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i10);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i1004);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i12);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i7);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i15);
	init_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i3);
BEGIN_CODE

/* code for predicate 'mark_parallels_for_teardown'/9 in mode 0 */
Define_static(mercury__frameopt__mark_parallels_for_teardown_9_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i3);
	MR_incr_sp_push_msg(9, "frameopt:mark_parallels_for_teardown/9");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__mark_parallels_for_teardown_9_0_i4,
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i7);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i8);
	r1 = (Word) MR_string_const("reached setup via jump from ordinary block", 42);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__mark_parallels_for_teardown_9_0_i14,
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0));
	r5 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	localcall(mercury__frameopt__mark_parallels_for_teardown_9_0,
		LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i15),
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i8);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__mark_parallels_for_teardown_9_0_i10,
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i10);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i1004);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "origin_lost_in_value_number");
	MR_stackvar(7) = r2;
	MR_stackvar(8) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	localcall(mercury__frameopt__mark_parallels_for_teardown_9_0,
		LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i15),
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
	}
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i1004);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "origin_lost_in_value_number");
	MR_stackvar(7) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	MR_stackvar(3) = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__mark_parallels_for_teardown_9_0_i12,
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
	}
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i12);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0));
	r5 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "origin_lost_in_value_number");
	MR_stackvar(8) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	localcall(mercury__frameopt__mark_parallels_for_teardown_9_0,
		LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i15),
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
	}
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(6);
	MR_stackvar(7) = MR_stackvar(5);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "origin_lost_in_value_number");
	MR_stackvar(8) = MR_tempr1;
	MR_tempr2 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_tempr2;
	localcall(mercury__frameopt__mark_parallels_for_teardown_9_0,
		LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0_i15),
		STATIC(mercury__frameopt__mark_parallels_for_teardown_9_0));
	}
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i15);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallels_for_teardown_9_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__mark_parallels_for_teardown_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__frameopt__mark_parallels_for_teardown_9_0_i3);
	r3 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r5;
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module23)
	init_entry(mercury__frameopt__mark_parallel_7_0);
	init_label(mercury__frameopt__mark_parallel_7_0_i3);
	init_label(mercury__frameopt__mark_parallel_7_0_i2);
	init_label(mercury__frameopt__mark_parallel_7_0_i5);
BEGIN_CODE

/* code for predicate 'mark_parallel'/7 in mode 0 */
Define_static(mercury__frameopt__mark_parallel_7_0);
	MR_incr_sp_push_msg(5, "frameopt:mark_parallel/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = r4;
	MR_stackvar(4) = r4;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__mark_parallel_7_0_i3,
		STATIC(mercury__frameopt__mark_parallel_7_0));
Define_label(mercury__frameopt__mark_parallel_7_0_i3);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallel_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__mark_parallel_7_0_i2);
	r1 = r2;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__frameopt__mark_parallel_7_0_i2);
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__frameopt__mark_parallel_7_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(4);
	MR_stackvar(2) = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__mark_parallel_7_0_i5,
		STATIC(mercury__frameopt__mark_parallel_7_0));
	}
Define_label(mercury__frameopt__mark_parallel_7_0_i5);
	update_prof_current_proc(LABEL(mercury__frameopt__mark_parallel_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module24)
	init_entry(mercury__frameopt__create_parallels_6_0);
	init_label(mercury__frameopt__create_parallels_6_0_i4);
	init_label(mercury__frameopt__create_parallels_6_0_i6);
	init_label(mercury__frameopt__create_parallels_6_0_i8);
	init_label(mercury__frameopt__create_parallels_6_0_i11);
	init_label(mercury__frameopt__create_parallels_6_0_i14);
	init_label(mercury__frameopt__create_parallels_6_0_i18);
	init_label(mercury__frameopt__create_parallels_6_0_i21);
	init_label(mercury__frameopt__create_parallels_6_0_i22);
	init_label(mercury__frameopt__create_parallels_6_0_i24);
	init_label(mercury__frameopt__create_parallels_6_0_i1027);
	init_label(mercury__frameopt__create_parallels_6_0_i19);
	init_label(mercury__frameopt__create_parallels_6_0_i27);
	init_label(mercury__frameopt__create_parallels_6_0_i1029);
	init_label(mercury__frameopt__create_parallels_6_0_i3);
BEGIN_CODE

/* code for predicate 'create_parallels'/6 in mode 0 */
Define_static(mercury__frameopt__create_parallels_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i3);
	MR_incr_sp_push_msg(10, "frameopt:create_parallels/6");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	localcall(mercury__frameopt__create_parallels_6_0,
		LABEL(mercury__frameopt__create_parallels_6_0_i4),
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i4);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__frameopt__create_parallels_6_0_i6,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i6);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i1029);
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__frameopt__create_parallels_6_0_i8,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i8);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__frameopt__create_parallels_6_0_i11,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i11);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	if (r1)
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i14);
	r1 = (Word) MR_string_const("label in block_info is not copy", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__create_parallels_6_0_i14,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i14);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	if (((Integer) MR_stackvar(8) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i18);
	r1 = (Word) MR_string_const("block with parallel has fall through", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__create_parallels_6_0_i18,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i18);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	if ((MR_tag(MR_stackvar(9)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i19);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__frameopt__create_parallels_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__frameopt__create_parallels_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = r1;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = (Word) MR_string_const("non-teardown parallel", 21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(9), (Integer) 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(2), MR_stackvar(9), (Integer) 2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__frameopt__create_parallels_6_0_i21,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i21);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 5, mercury__frameopt__create_parallels_6_0, "frameopt:block_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_frameopt__common_9);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__frameopt__create_parallels_6_0_i22,
		STATIC(mercury__frameopt__create_parallels_6_0));
	}
Define_label(mercury__frameopt__create_parallels_6_0_i22);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__frameopt__create_parallels_6_0_i24,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i24);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__frameopt__create_parallels_6_0_i1027);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__frameopt__create_parallels_6_0_i1027);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__frameopt__create_parallels_6_0_i19);
	r1 = (Word) MR_string_const("block with parallel is not teardown", 35);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__frameopt__create_parallels_6_0_i27,
		STATIC(mercury__frameopt__create_parallels_6_0));
Define_label(mercury__frameopt__create_parallels_6_0_i27);
	update_prof_current_proc(LABEL(mercury__frameopt__create_parallels_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__frameopt__create_parallels_6_0_i1029);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__frameopt__create_parallels_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__frameopt__create_parallels_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(frameopt_module25)
	init_entry(mercury____Unify___frameopt__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___frameopt__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___frameopt__block_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(frameopt_module26)
	init_entry(mercury____Index___frameopt__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___frameopt__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___frameopt__block_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(frameopt_module27)
	init_entry(mercury____Compare___frameopt__block_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___frameopt__block_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_frameopt__type_ctor_info_block_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___frameopt__block_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);

BEGIN_MODULE(frameopt_module28)
	init_entry(mercury____Unify___frameopt__block_info_0_0);
	init_label(mercury____Unify___frameopt__block_info_0_0_i2);
	init_label(mercury____Unify___frameopt__block_info_0_0_i4);
	init_label(mercury____Unify___frameopt__block_info_0_0_i6);
	init_label(mercury____Unify___frameopt__block_info_0_0_i8);
	init_label(mercury____Unify___frameopt__block_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___frameopt__block_info_0_0);
	MR_incr_sp_push_msg(9, "frameopt:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury____Unify___frameopt__block_info_0_0_i2,
		STATIC(mercury____Unify___frameopt__block_info_0_0));
Define_label(mercury____Unify___frameopt__block_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___frameopt__block_info_0_0_i4,
		STATIC(mercury____Unify___frameopt__block_info_0_0));
Define_label(mercury____Unify___frameopt__block_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___frameopt__block_info_0_0_i6,
		STATIC(mercury____Unify___frameopt__block_info_0_0));
Define_label(mercury____Unify___frameopt__block_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___frameopt__block_info_0_0_i8,
		STATIC(mercury____Unify___frameopt__block_info_0_0));
Define_label(mercury____Unify___frameopt__block_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_info_0_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury____Unify___frameopt__block_type_0_0),
		STATIC(mercury____Unify___frameopt__block_info_0_0));
Define_label(mercury____Unify___frameopt__block_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module29)
	init_entry(mercury____Index___frameopt__block_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___frameopt__block_info_0_0);
	tailcall(STATIC(mercury____Index___frameopt__block_info_0__ua0_2_0),
		STATIC(mercury____Index___frameopt__block_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___llds__label_0_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);

BEGIN_MODULE(frameopt_module30)
	init_entry(mercury____Compare___frameopt__block_info_0_0);
	init_label(mercury____Compare___frameopt__block_info_0_0_i3);
	init_label(mercury____Compare___frameopt__block_info_0_0_i7);
	init_label(mercury____Compare___frameopt__block_info_0_0_i11);
	init_label(mercury____Compare___frameopt__block_info_0_0_i15);
	init_label(mercury____Compare___frameopt__block_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___frameopt__block_info_0_0);
	MR_incr_sp_push_msg(9, "frameopt:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___llds__label_0_0),
		mercury____Compare___frameopt__block_info_0_0_i3,
		STATIC(mercury____Compare___frameopt__block_info_0_0));
Define_label(mercury____Compare___frameopt__block_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_info_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___frameopt__block_info_0_0_i7,
		STATIC(mercury____Compare___frameopt__block_info_0_0));
Define_label(mercury____Compare___frameopt__block_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___frameopt__block_info_0_0_i11,
		STATIC(mercury____Compare___frameopt__block_info_0_0));
Define_label(mercury____Compare___frameopt__block_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___frameopt__block_info_0_0_i15,
		STATIC(mercury____Compare___frameopt__block_info_0_0));
Define_label(mercury____Compare___frameopt__block_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_info_0_0_i22);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury____Compare___frameopt__block_type_0_0),
		STATIC(mercury____Compare___frameopt__block_info_0_0));
Define_label(mercury____Compare___frameopt__block_info_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(frameopt_module31)
	init_entry(mercury____Unify___frameopt__block_type_0_0);
	init_label(mercury____Unify___frameopt__block_type_0_0_i6);
	init_label(mercury____Unify___frameopt__block_type_0_0_i8);
	init_label(mercury____Unify___frameopt__block_type_0_0_i10);
	init_label(mercury____Unify___frameopt__block_type_0_0_i1009);
	init_label(mercury____Unify___frameopt__block_type_0_0_i1011);
	init_label(mercury____Unify___frameopt__block_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___frameopt__block_type_0_0);
	MR_incr_sp_push_msg(5, "frameopt:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1009);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i6);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1011);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___frameopt__block_type_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___frameopt__block_type_0_0_i8,
		STATIC(mercury____Unify___frameopt__block_type_0_0));
Define_label(mercury____Unify___frameopt__block_type_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_type_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___frameopt__block_type_0_0_i10,
		STATIC(mercury____Unify___frameopt__block_type_0_0));
Define_label(mercury____Unify___frameopt__block_type_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___frameopt__block_type_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_instr_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___frameopt__block_type_0_0));
Define_label(mercury____Unify___frameopt__block_type_0_0_i1009);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((r3 != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___frameopt__block_type_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___frameopt__block_type_0_0_i1011);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___frameopt__block_type_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module32)
	init_entry(mercury____Index___frameopt__block_type_0_0);
	init_label(mercury____Index___frameopt__block_type_0_0_i5);
	init_label(mercury____Index___frameopt__block_type_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___frameopt__block_type_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___frameopt__block_type_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___frameopt__block_type_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___frameopt__block_type_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___frameopt__block_type_0_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(frameopt_module33)
	init_entry(mercury____Compare___frameopt__block_type_0_0);
	init_label(mercury____Compare___frameopt__block_type_0_0_i5);
	init_label(mercury____Compare___frameopt__block_type_0_0_i4);
	init_label(mercury____Compare___frameopt__block_type_0_0_i2);
	init_label(mercury____Compare___frameopt__block_type_0_0_i9);
	init_label(mercury____Compare___frameopt__block_type_0_0_i8);
	init_label(mercury____Compare___frameopt__block_type_0_0_i6);
	init_label(mercury____Compare___frameopt__block_type_0_0_i10);
	init_label(mercury____Compare___frameopt__block_type_0_0_i11);
	init_label(mercury____Compare___frameopt__block_type_0_0_i19);
	init_label(mercury____Compare___frameopt__block_type_0_0_i22);
	init_label(mercury____Compare___frameopt__block_type_0_0_i26);
	init_label(mercury____Compare___frameopt__block_type_0_0_i16);
	init_label(mercury____Compare___frameopt__block_type_0_0_i1021);
	init_label(mercury____Compare___frameopt__block_type_0_0_i36);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___frameopt__block_type_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i5);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i2);
Define_label(mercury____Compare___frameopt__block_type_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i2);
Define_label(mercury____Compare___frameopt__block_type_0_0_i4);
	r3 = (Integer) 1;
Define_label(mercury____Compare___frameopt__block_type_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i9);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i6);
	}
Define_label(mercury____Compare___frameopt__block_type_0_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i6);
Define_label(mercury____Compare___frameopt__block_type_0_0_i8);
	r4 = (Integer) 1;
Define_label(mercury____Compare___frameopt__block_type_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___frameopt__block_type_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___frameopt__block_type_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i19);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i1021);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___frameopt__block_type_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i1021);
	MR_incr_sp_push_msg(5, "frameopt:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___frameopt__block_type_0_0_i22,
		STATIC(mercury____Compare___frameopt__block_type_0_0));
Define_label(mercury____Compare___frameopt__block_type_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_type_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i36);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___frameopt__block_type_0_0_i26,
		STATIC(mercury____Compare___frameopt__block_type_0_0));
Define_label(mercury____Compare___frameopt__block_type_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Compare___frameopt__block_type_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i36);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_instr_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___frameopt__block_type_0_0));
Define_label(mercury____Compare___frameopt__block_type_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___frameopt__block_type_0_0_i1021);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___frameopt__block_type_0_0));
Define_label(mercury____Compare___frameopt__block_type_0_0_i1021);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___frameopt__block_type_0_0));
Define_label(mercury____Compare___frameopt__block_type_0_0_i36);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(frameopt_module34)
	init_entry(mercury____Unify___frameopt__rev_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___frameopt__rev_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___frameopt__rev_map_0_0));
END_MODULE


BEGIN_MODULE(frameopt_module35)
	init_entry(mercury____Index___frameopt__rev_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___frameopt__rev_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___frameopt__rev_map_0_0));
END_MODULE


BEGIN_MODULE(frameopt_module36)
	init_entry(mercury____Compare___frameopt__rev_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___frameopt__rev_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_frameopt__common_8);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___frameopt__rev_map_0_0));
END_MODULE


BEGIN_MODULE(frameopt_module37)
	init_entry(mercury____Unify___frameopt__par_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___frameopt__par_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___frameopt__par_map_0_0));
END_MODULE


BEGIN_MODULE(frameopt_module38)
	init_entry(mercury____Index___frameopt__par_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___frameopt__par_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___frameopt__par_map_0_0));
END_MODULE


BEGIN_MODULE(frameopt_module39)
	init_entry(mercury____Compare___frameopt__par_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___frameopt__par_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___frameopt__par_map_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__frameopt_maybe_bunch_0(void)
{
	frameopt_module0();
	frameopt_module1();
	frameopt_module2();
	frameopt_module3();
	frameopt_module4();
	frameopt_module5();
	frameopt_module6();
	frameopt_module7();
	frameopt_module8();
	frameopt_module9();
	frameopt_module10();
	frameopt_module11();
	frameopt_module12();
	frameopt_module13();
	frameopt_module14();
	frameopt_module15();
	frameopt_module16();
	frameopt_module17();
	frameopt_module18();
	frameopt_module19();
	frameopt_module20();
	frameopt_module21();
	frameopt_module22();
	frameopt_module23();
	frameopt_module24();
	frameopt_module25();
	frameopt_module26();
	frameopt_module27();
	frameopt_module28();
	frameopt_module29();
	frameopt_module30();
	frameopt_module31();
	frameopt_module32();
	frameopt_module33();
	frameopt_module34();
	frameopt_module35();
	frameopt_module36();
	frameopt_module37();
	frameopt_module38();
	frameopt_module39();
}

#endif

void mercury__frameopt__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__frameopt__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__frameopt_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frameopt__type_ctor_info_block_info_0,
			frameopt__block_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frameopt__type_ctor_info_block_map_0,
			frameopt__block_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frameopt__type_ctor_info_block_type_0,
			frameopt__block_type_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frameopt__type_ctor_info_par_map_0,
			frameopt__par_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_frameopt__type_ctor_info_rev_map_0,
			frameopt__rev_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
