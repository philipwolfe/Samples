/*
** Automatically generated from `globals.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__globals__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___globals__globals_0__ua0_2_0);
Define_extern_entry(mercury__globals__convert_gc_method_2_0);
Declare_label(mercury__globals__convert_gc_method_2_0_i3);
Declare_label(mercury__globals__convert_gc_method_2_0_i4);
Declare_label(mercury__globals__convert_gc_method_2_0_i1);
Define_extern_entry(mercury__globals__convert_tags_method_2_0);
Declare_label(mercury__globals__convert_tags_method_2_0_i3);
Declare_label(mercury__globals__convert_tags_method_2_0_i4);
Declare_label(mercury__globals__convert_tags_method_2_0_i1);
Define_extern_entry(mercury__globals__convert_prolog_dialect_2_0);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i3);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i1002);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i1001);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i5);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i13);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i17);
Declare_label(mercury__globals__convert_prolog_dialect_2_0_i18);
Define_extern_entry(mercury__globals__convert_termination_norm_2_0);
Declare_label(mercury__globals__convert_termination_norm_2_0_i3);
Declare_label(mercury__globals__convert_termination_norm_2_0_i4);
Declare_label(mercury__globals__convert_termination_norm_2_0_i5);
Declare_label(mercury__globals__convert_termination_norm_2_0_i1);
Define_extern_entry(mercury__globals__convert_trace_level_3_0);
Declare_label(mercury__globals__convert_trace_level_3_0_i1000);
Declare_label(mercury__globals__convert_trace_level_3_0_i3);
Declare_label(mercury__globals__convert_trace_level_3_0_i4);
Declare_label(mercury__globals__convert_trace_level_3_0_i7);
Declare_label(mercury__globals__convert_trace_level_3_0_i1005);
Declare_label(mercury__globals__convert_trace_level_3_0_i1);
Define_extern_entry(mercury__globals__init_7_0);
Define_extern_entry(mercury__globals__get_options_2_0);
Define_extern_entry(mercury__globals__get_gc_method_2_0);
Define_extern_entry(mercury__globals__get_tags_method_2_0);
Define_extern_entry(mercury__globals__get_prolog_dialect_2_0);
Define_extern_entry(mercury__globals__get_termination_norm_2_0);
Define_extern_entry(mercury__globals__get_trace_level_2_0);
Define_extern_entry(mercury__globals__set_options_3_0);
Define_extern_entry(mercury__globals__set_trace_level_3_0);
Define_extern_entry(mercury__globals__lookup_option_3_0);
Define_extern_entry(mercury__globals__lookup_bool_option_3_0);
Declare_label(mercury__globals__lookup_bool_option_3_0_i2);
Declare_label(mercury__globals__lookup_bool_option_3_0_i3);
Define_extern_entry(mercury__globals__lookup_bool_option_3_1);
Declare_label(mercury__globals__lookup_bool_option_3_1_i2);
Declare_label(mercury__globals__lookup_bool_option_3_1_i1001);
Declare_label(mercury__globals__lookup_bool_option_3_1_i3);
Declare_label(mercury__globals__lookup_bool_option_3_1_i1);
Define_extern_entry(mercury__globals__lookup_int_option_3_0);
Declare_label(mercury__globals__lookup_int_option_3_0_i2);
Declare_label(mercury__globals__lookup_int_option_3_0_i3);
Define_extern_entry(mercury__globals__lookup_string_option_3_0);
Declare_label(mercury__globals__lookup_string_option_3_0_i2);
Declare_label(mercury__globals__lookup_string_option_3_0_i3);
Define_extern_entry(mercury__globals__lookup_accumulating_option_3_0);
Declare_label(mercury__globals__lookup_accumulating_option_3_0_i2);
Declare_label(mercury__globals__lookup_accumulating_option_3_0_i3);
Define_extern_entry(mercury__globals__have_static_code_addresses_2_0);
Declare_label(mercury__globals__have_static_code_addresses_2_0_i2);
Declare_label(mercury__globals__have_static_code_addresses_2_0_i3);
Define_extern_entry(mercury__globals__want_return_var_layouts_2_0);
Declare_label(mercury__globals__want_return_var_layouts_2_0_i7);
Declare_label(mercury__globals__want_return_var_layouts_2_0_i1003);
Declare_label(mercury__globals__want_return_var_layouts_2_0_i4);
Declare_label(mercury__globals__want_return_var_layouts_2_0_i3);
Define_extern_entry(mercury__globals__io_init_8_0);
Declare_label(mercury__globals__io_init_8_0_i2);
Declare_label(mercury__globals__io_init_8_0_i3);
Declare_label(mercury__globals__io_init_8_0_i4);
Declare_label(mercury__globals__io_init_8_0_i5);
Declare_label(mercury__globals__io_init_8_0_i6);
Declare_label(mercury__globals__io_init_8_0_i7);
Define_extern_entry(mercury__globals__io_get_gc_method_3_0);
Declare_label(mercury__globals__io_get_gc_method_3_0_i2);
Declare_label(mercury__globals__io_get_gc_method_3_0_i4);
Declare_label(mercury__globals__io_get_gc_method_3_0_i3);
Declare_label(mercury__globals__io_get_gc_method_3_0_i6);
Define_extern_entry(mercury__globals__io_get_tags_method_3_0);
Declare_label(mercury__globals__io_get_tags_method_3_0_i2);
Declare_label(mercury__globals__io_get_tags_method_3_0_i4);
Declare_label(mercury__globals__io_get_tags_method_3_0_i3);
Declare_label(mercury__globals__io_get_tags_method_3_0_i6);
Define_extern_entry(mercury__globals__io_get_prolog_dialect_3_0);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i4);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
Declare_label(mercury__globals__io_get_prolog_dialect_3_0_i6);
Define_extern_entry(mercury__globals__io_get_termination_norm_3_0);
Declare_label(mercury__globals__io_get_termination_norm_3_0_i2);
Declare_label(mercury__globals__io_get_termination_norm_3_0_i4);
Declare_label(mercury__globals__io_get_termination_norm_3_0_i3);
Declare_label(mercury__globals__io_get_termination_norm_3_0_i6);
Define_extern_entry(mercury__globals__io_get_trace_level_3_0);
Declare_label(mercury__globals__io_get_trace_level_3_0_i2);
Declare_label(mercury__globals__io_get_trace_level_3_0_i4);
Declare_label(mercury__globals__io_get_trace_level_3_0_i3);
Declare_label(mercury__globals__io_get_trace_level_3_0_i6);
Define_extern_entry(mercury__globals__io_get_globals_3_0);
Declare_label(mercury__globals__io_get_globals_3_0_i2);
Declare_label(mercury__globals__io_get_globals_3_0_i4);
Declare_label(mercury__globals__io_get_globals_3_0_i3);
Declare_label(mercury__globals__io_get_globals_3_0_i6);
Define_extern_entry(mercury__globals__io_set_globals_3_0);
Declare_label(mercury__globals__io_set_globals_3_0_i2);
Define_extern_entry(mercury__globals__io_set_option_4_0);
Declare_label(mercury__globals__io_set_option_4_0_i2);
Declare_label(mercury__globals__io_set_option_4_0_i4);
Declare_label(mercury__globals__io_set_option_4_0_i3);
Declare_label(mercury__globals__io_set_option_4_0_i6);
Declare_label(mercury__globals__io_set_option_4_0_i8);
Declare_label(mercury__globals__io_set_option_4_0_i9);
Define_extern_entry(mercury__globals__io_set_trace_level_3_0);
Declare_label(mercury__globals__io_set_trace_level_3_0_i2);
Declare_label(mercury__globals__io_set_trace_level_3_0_i4);
Declare_label(mercury__globals__io_set_trace_level_3_0_i3);
Declare_label(mercury__globals__io_set_trace_level_3_0_i6);
Declare_label(mercury__globals__io_set_trace_level_3_0_i8);
Define_extern_entry(mercury__globals__io_set_trace_level_none_2_0);
Define_extern_entry(mercury__globals__io_lookup_option_4_0);
Declare_label(mercury__globals__io_lookup_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_option_4_0_i4);
Declare_label(mercury__globals__io_lookup_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_option_4_0_i6);
Declare_label(mercury__globals__io_lookup_option_4_0_i8);
Define_extern_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i4);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i6);
Declare_label(mercury__globals__io_lookup_bool_option_4_0_i8);
Define_extern_entry(mercury__globals__io_lookup_bool_option_4_1);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i2);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i4);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i3);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i6);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i8);
Declare_label(mercury__globals__io_lookup_bool_option_4_1_i1);
Define_extern_entry(mercury__globals__io_lookup_int_option_4_0);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i4);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i6);
Declare_label(mercury__globals__io_lookup_int_option_4_0_i8);
Define_extern_entry(mercury__globals__io_lookup_string_option_4_0);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i4);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i6);
Declare_label(mercury__globals__io_lookup_string_option_4_0_i8);
Define_extern_entry(mercury__globals__io_lookup_accumulating_option_4_0);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i4);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i6);
Declare_label(mercury__globals__io_lookup_accumulating_option_4_0_i8);
Define_extern_entry(mercury____Unify___globals__globals_0_0);
Declare_label(mercury____Unify___globals__globals_0_0_i2);
Declare_label(mercury____Unify___globals__globals_0_0_i1);
Define_extern_entry(mercury____Index___globals__globals_0_0);
Define_extern_entry(mercury____Compare___globals__globals_0_0);
Declare_label(mercury____Compare___globals__globals_0_0_i3);
Declare_label(mercury____Compare___globals__globals_0_0_i7);
Declare_label(mercury____Compare___globals__globals_0_0_i11);
Declare_label(mercury____Compare___globals__globals_0_0_i15);
Declare_label(mercury____Compare___globals__globals_0_0_i19);
Declare_label(mercury____Compare___globals__globals_0_0_i27);
Define_extern_entry(mercury____Unify___globals__gc_method_0_0);
Declare_label(mercury____Unify___globals__gc_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__gc_method_0_0);
Define_extern_entry(mercury____Compare___globals__gc_method_0_0);
Define_extern_entry(mercury____Unify___globals__tags_method_0_0);
Declare_label(mercury____Unify___globals__tags_method_0_0_i1);
Define_extern_entry(mercury____Index___globals__tags_method_0_0);
Define_extern_entry(mercury____Compare___globals__tags_method_0_0);
Define_extern_entry(mercury____Unify___globals__prolog_dialect_0_0);
Declare_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
Define_extern_entry(mercury____Index___globals__prolog_dialect_0_0);
Define_extern_entry(mercury____Compare___globals__prolog_dialect_0_0);
Define_extern_entry(mercury____Unify___globals__termination_norm_0_0);
Declare_label(mercury____Unify___globals__termination_norm_0_0_i1);
Define_extern_entry(mercury____Index___globals__termination_norm_0_0);
Define_extern_entry(mercury____Compare___globals__termination_norm_0_0);
Define_extern_entry(mercury____Unify___globals__trace_level_0_0);
Declare_label(mercury____Unify___globals__trace_level_0_0_i1);
Define_extern_entry(mercury____Index___globals__trace_level_0_0);
Define_extern_entry(mercury____Compare___globals__trace_level_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_gc_method_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_globals_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_prolog_dialect_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_tags_method_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_termination_norm_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_trace_level_0;

static const struct mercury_data_globals__common_0_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	String f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	String f19;
	Integer f20;
	Integer f21;
	Integer f22;
	String f23;
	Integer f24;
	Integer f25;
	String f26;
	String f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	String f32;
}  mercury_data_globals__common_0;

static const struct mercury_data_globals__common_1_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_globals__common_1;

static const struct mercury_data_globals__common_2_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_globals__common_2;

static const struct mercury_data_globals__common_3_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_data_globals__common_3;

static const struct mercury_data_globals__common_4_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_globals__common_4;

static const struct mercury_data_globals__common_5_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_globals__common_5;

static const struct mercury_data_globals__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_globals__common_6;

static const struct mercury_data_globals__common_7_struct {
	Word * f1;
}  mercury_data_globals__common_7;

static const struct mercury_data_globals__common_8_struct {
	Word * f1;
}  mercury_data_globals__common_8;

static const struct mercury_data_globals__common_9_struct {
	Word * f1;
}  mercury_data_globals__common_9;

static const struct mercury_data_globals__common_10_struct {
	Word * f1;
}  mercury_data_globals__common_10;

static const struct mercury_data_globals__common_11_struct {
	Word * f1;
}  mercury_data_globals__common_11;

static const struct mercury_data_globals__common_12_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	String f8;
	Word * f9;
	Integer f10;
	Integer f11;
}  mercury_data_globals__common_12;

static const struct mercury_data_globals__common_13_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_globals__common_13;

static const struct mercury_data_globals__type_ctor_functors_trace_level_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_globals__type_ctor_functors_trace_level_0;

static const struct mercury_data_globals__type_ctor_layout_trace_level_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_trace_level_0;

static const struct mercury_data_globals__type_ctor_functors_termination_norm_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_globals__type_ctor_functors_termination_norm_0;

static const struct mercury_data_globals__type_ctor_layout_termination_norm_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_termination_norm_0;

static const struct mercury_data_globals__type_ctor_functors_tags_method_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_globals__type_ctor_functors_tags_method_0;

static const struct mercury_data_globals__type_ctor_layout_tags_method_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_tags_method_0;

static const struct mercury_data_globals__type_ctor_functors_prolog_dialect_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_globals__type_ctor_functors_prolog_dialect_0;

static const struct mercury_data_globals__type_ctor_layout_prolog_dialect_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_prolog_dialect_0;

static const struct mercury_data_globals__type_ctor_functors_globals_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_globals__type_ctor_functors_globals_0;

static const struct mercury_data_globals__type_ctor_layout_globals_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_globals_0;

static const struct mercury_data_globals__type_ctor_functors_gc_method_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_globals__type_ctor_functors_gc_method_0;

static const struct mercury_data_globals__type_ctor_layout_gc_method_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_globals__type_ctor_layout_gc_method_0;

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_gc_method_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__gc_method_0_0),
	ENTRY(mercury____Index___globals__gc_method_0_0),
	ENTRY(mercury____Compare___globals__gc_method_0_0),
	(Integer) 0,
	(Word *) &mercury_data_globals__type_ctor_functors_gc_method_0,
	(Word *) &mercury_data_globals__type_ctor_layout_gc_method_0,
	MR_string_const("globals", 7),
	MR_string_const("gc_method", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_globals_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__globals_0_0),
	ENTRY(mercury____Index___globals__globals_0_0),
	ENTRY(mercury____Compare___globals__globals_0_0),
	(Integer) 2,
	(Word *) &mercury_data_globals__type_ctor_functors_globals_0,
	(Word *) &mercury_data_globals__type_ctor_layout_globals_0,
	MR_string_const("globals", 7),
	MR_string_const("globals", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_prolog_dialect_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__prolog_dialect_0_0),
	ENTRY(mercury____Index___globals__prolog_dialect_0_0),
	ENTRY(mercury____Compare___globals__prolog_dialect_0_0),
	(Integer) 0,
	(Word *) &mercury_data_globals__type_ctor_functors_prolog_dialect_0,
	(Word *) &mercury_data_globals__type_ctor_layout_prolog_dialect_0,
	MR_string_const("globals", 7),
	MR_string_const("prolog_dialect", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_tags_method_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__tags_method_0_0),
	ENTRY(mercury____Index___globals__tags_method_0_0),
	ENTRY(mercury____Compare___globals__tags_method_0_0),
	(Integer) 0,
	(Word *) &mercury_data_globals__type_ctor_functors_tags_method_0,
	(Word *) &mercury_data_globals__type_ctor_layout_tags_method_0,
	MR_string_const("globals", 7),
	MR_string_const("tags_method", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_termination_norm_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__termination_norm_0_0),
	ENTRY(mercury____Index___globals__termination_norm_0_0),
	ENTRY(mercury____Compare___globals__termination_norm_0_0),
	(Integer) 0,
	(Word *) &mercury_data_globals__type_ctor_functors_termination_norm_0,
	(Word *) &mercury_data_globals__type_ctor_layout_termination_norm_0,
	MR_string_const("globals", 7),
	MR_string_const("termination_norm", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_globals__type_ctor_info_trace_level_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___globals__trace_level_0_0),
	ENTRY(mercury____Index___globals__trace_level_0_0),
	ENTRY(mercury____Compare___globals__trace_level_0_0),
	(Integer) 0,
	(Word *) &mercury_data_globals__type_ctor_functors_trace_level_0,
	(Word *) &mercury_data_globals__type_ctor_layout_trace_level_0,
	MR_string_const("globals", 7),
	MR_string_const("trace_level", 11),
	(Integer) 3
};

static const struct mercury_data_globals__common_0_struct mercury_data_globals__common_0 = {
	(Integer) 0,
	MR_string_const("Sicstus-Prolog", 14),
	MR_string_const("SICStus-Prolog", 14),
	MR_string_const("NU-Prolog", 9),
	MR_string_const("NU", 2),
	MR_string_const("NUprolog", 8),
	MR_string_const("Sicstus", 7),
	MR_string_const("SICStus", 7),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("default", 7),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("sicstus-prolog", 14),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("nu-prolog", 9),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("nu", 2),
	MR_string_const("nuprolog", 8),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("sicstus", 7)
};

static const struct mercury_data_globals__common_1_struct mercury_data_globals__common_1 = {
	(Integer) -2,
	(Integer) 2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) 7,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 3,
	(Integer) -2,
	(Integer) -2,
	(Integer) 4,
	(Integer) 5,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 6
};

static const struct mercury_data_globals__common_2_struct mercury_data_globals__common_2 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("none", 4),
	MR_string_const("shallow", 7),
	MR_string_const("deep", 4)
};

static const struct mercury_data_globals__common_3_struct mercury_data_globals__common_3 = {
	(Integer) 1,
	(Integer) 4,
	MR_string_const("simple", 6),
	MR_string_const("total", 5),
	MR_string_const("num_data_elems", 14),
	MR_string_const("size_data_elems", 15)
};

static const struct mercury_data_globals__common_4_struct mercury_data_globals__common_4 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("none", 4),
	MR_string_const("low", 3),
	MR_string_const("high", 4)
};

static const struct mercury_data_globals__common_5_struct mercury_data_globals__common_5 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("default", 7),
	MR_string_const("nu", 2),
	MR_string_const("sicstus", 7)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_options__type_ctor_info_option_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_getopt__type_ctor_info_option_data_0;
static const struct mercury_data_globals__common_6_struct mercury_data_globals__common_6 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_options__type_ctor_info_option_0,
	(Word *) &mercury_data_getopt__type_ctor_info_option_data_0
};

static const struct mercury_data_globals__common_7_struct mercury_data_globals__common_7 = {
	(Word *) &mercury_data_globals__type_ctor_info_gc_method_0
};

static const struct mercury_data_globals__common_8_struct mercury_data_globals__common_8 = {
	(Word *) &mercury_data_globals__type_ctor_info_tags_method_0
};

static const struct mercury_data_globals__common_9_struct mercury_data_globals__common_9 = {
	(Word *) &mercury_data_globals__type_ctor_info_prolog_dialect_0
};

static const struct mercury_data_globals__common_10_struct mercury_data_globals__common_10 = {
	(Word *) &mercury_data_globals__type_ctor_info_termination_norm_0
};

static const struct mercury_data_globals__common_11_struct mercury_data_globals__common_11 = {
	(Word *) &mercury_data_globals__type_ctor_info_trace_level_0
};

static const struct mercury_data_globals__common_12_struct mercury_data_globals__common_12 = {
	(Integer) 6,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_11),
	MR_string_const("globals", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_globals__common_13_struct mercury_data_globals__common_13 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("none", 4),
	MR_string_const("conservative", 12),
	MR_string_const("accurate", 8)
};

static const struct mercury_data_globals__type_ctor_functors_trace_level_0_struct mercury_data_globals__type_ctor_functors_trace_level_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_2)
};

static const struct mercury_data_globals__type_ctor_layout_trace_level_0_struct mercury_data_globals__type_ctor_layout_trace_level_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_2)
};

static const struct mercury_data_globals__type_ctor_functors_termination_norm_0_struct mercury_data_globals__type_ctor_functors_termination_norm_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_3)
};

static const struct mercury_data_globals__type_ctor_layout_termination_norm_0_struct mercury_data_globals__type_ctor_layout_termination_norm_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_3)
};

static const struct mercury_data_globals__type_ctor_functors_tags_method_0_struct mercury_data_globals__type_ctor_functors_tags_method_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_4)
};

static const struct mercury_data_globals__type_ctor_layout_tags_method_0_struct mercury_data_globals__type_ctor_layout_tags_method_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_4)
};

static const struct mercury_data_globals__type_ctor_functors_prolog_dialect_0_struct mercury_data_globals__type_ctor_functors_prolog_dialect_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_5)
};

static const struct mercury_data_globals__type_ctor_layout_prolog_dialect_0_struct mercury_data_globals__type_ctor_layout_prolog_dialect_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_5)
};

static const struct mercury_data_globals__type_ctor_functors_globals_0_struct mercury_data_globals__type_ctor_functors_globals_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_12)
};

static const struct mercury_data_globals__type_ctor_layout_globals_0_struct mercury_data_globals__type_ctor_layout_globals_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_globals__common_12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_globals__type_ctor_functors_gc_method_0_struct mercury_data_globals__type_ctor_functors_gc_method_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_13)
};

static const struct mercury_data_globals__type_ctor_layout_gc_method_0_struct mercury_data_globals__type_ctor_layout_gc_method_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_13)
};


BEGIN_MODULE(globals_module0)
	init_entry(mercury____Index___globals__globals_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___globals__globals_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___globals__globals_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module1)
	init_entry(mercury__globals__convert_gc_method_2_0);
	init_label(mercury__globals__convert_gc_method_2_0_i3);
	init_label(mercury__globals__convert_gc_method_2_0_i4);
	init_label(mercury__globals__convert_gc_method_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_gc_method'/2 in mode 0 */
Define_entry(mercury__globals__convert_gc_method_2_0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("accurate", 8)) != 0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i3);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("conservative", 12)) != 0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i4);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i4);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("none", 4)) != 0))
		GOTO_LABEL(mercury__globals__convert_gc_method_2_0_i1);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_gc_method_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module2)
	init_entry(mercury__globals__convert_tags_method_2_0);
	init_label(mercury__globals__convert_tags_method_2_0_i3);
	init_label(mercury__globals__convert_tags_method_2_0_i4);
	init_label(mercury__globals__convert_tags_method_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_tags_method'/2 in mode 0 */
Define_entry(mercury__globals__convert_tags_method_2_0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("high", 4)) != 0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i3);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("low", 3)) != 0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i4);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i4);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("none", 4)) != 0))
		GOTO_LABEL(mercury__globals__convert_tags_method_2_0_i1);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_tags_method_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module3)
	init_entry(mercury__globals__convert_prolog_dialect_2_0);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i3);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i1002);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i1001);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i5);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i13);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i17);
	init_label(mercury__globals__convert_prolog_dialect_2_0_i18);
BEGIN_CODE

/* code for predicate 'convert_prolog_dialect'/2 in mode 0 */
Define_entry(mercury__globals__convert_prolog_dialect_2_0);
	r2 = (hash_string(r1) & (Integer) 31);
Define_label(mercury__globals__convert_prolog_dialect_2_0_i3);
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_0))[(Integer) r2];
	if (!(r3))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i1002);
	if ((strcmp((char *)r3, (char *)r1) == 0))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i5);
Define_label(mercury__globals__convert_prolog_dialect_2_0_i1002);
	r2 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_globals__common_1))[(Integer) r2];
	if (((Integer) r2 >= (Integer) 0))
		GOTO_LABEL(mercury__globals__convert_prolog_dialect_2_0_i3);
Define_label(mercury__globals__convert_prolog_dialect_2_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i5);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i13) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i17) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i1001) AND
		LABEL(mercury__globals__convert_prolog_dialect_2_0_i18));
Define_label(mercury__globals__convert_prolog_dialect_2_0_i13);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i17);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_prolog_dialect_2_0_i18);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module4)
	init_entry(mercury__globals__convert_termination_norm_2_0);
	init_label(mercury__globals__convert_termination_norm_2_0_i3);
	init_label(mercury__globals__convert_termination_norm_2_0_i4);
	init_label(mercury__globals__convert_termination_norm_2_0_i5);
	init_label(mercury__globals__convert_termination_norm_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_termination_norm'/2 in mode 0 */
Define_entry(mercury__globals__convert_termination_norm_2_0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("num-data-elems", 14)) != 0))
		GOTO_LABEL(mercury__globals__convert_termination_norm_2_0_i3);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_termination_norm_2_0_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("simple", 6)) != 0))
		GOTO_LABEL(mercury__globals__convert_termination_norm_2_0_i4);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_termination_norm_2_0_i4);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("size-data-elems", 15)) != 0))
		GOTO_LABEL(mercury__globals__convert_termination_norm_2_0_i5);
	r2 = (Integer) 3;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_termination_norm_2_0_i5);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("total", 5)) != 0))
		GOTO_LABEL(mercury__globals__convert_termination_norm_2_0_i1);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_termination_norm_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module5)
	init_entry(mercury__globals__convert_trace_level_3_0);
	init_label(mercury__globals__convert_trace_level_3_0_i1000);
	init_label(mercury__globals__convert_trace_level_3_0_i3);
	init_label(mercury__globals__convert_trace_level_3_0_i4);
	init_label(mercury__globals__convert_trace_level_3_0_i7);
	init_label(mercury__globals__convert_trace_level_3_0_i1005);
	init_label(mercury__globals__convert_trace_level_3_0_i1);
BEGIN_CODE

/* code for predicate 'convert_trace_level'/3 in mode 0 */
Define_entry(mercury__globals__convert_trace_level_3_0);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("deep", 4)) != 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i3);
Define_label(mercury__globals__convert_trace_level_3_0_i1000);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_trace_level_3_0_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("default", 7)) != 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i4);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i1000);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_trace_level_3_0_i4);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("minimum", 7)) != 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i7);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i1005);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_trace_level_3_0_i7);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("shallow", 7)) != 0))
		GOTO_LABEL(mercury__globals__convert_trace_level_3_0_i1);
Define_label(mercury__globals__convert_trace_level_3_0_i1005);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__convert_trace_level_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module6)
	init_entry(mercury__globals__init_7_0);
BEGIN_CODE

/* code for predicate 'init'/7 in mode 0 */
Define_entry(mercury__globals__init_7_0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 6, mercury__globals__init_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	proceed();
	}
END_MODULE


BEGIN_MODULE(globals_module7)
	init_entry(mercury__globals__get_options_2_0);
BEGIN_CODE

/* code for predicate 'get_options'/2 in mode 0 */
Define_entry(mercury__globals__get_options_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module8)
	init_entry(mercury__globals__get_gc_method_2_0);
BEGIN_CODE

/* code for predicate 'get_gc_method'/2 in mode 0 */
Define_entry(mercury__globals__get_gc_method_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module9)
	init_entry(mercury__globals__get_tags_method_2_0);
BEGIN_CODE

/* code for predicate 'get_tags_method'/2 in mode 0 */
Define_entry(mercury__globals__get_tags_method_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module10)
	init_entry(mercury__globals__get_prolog_dialect_2_0);
BEGIN_CODE

/* code for predicate 'get_prolog_dialect'/2 in mode 0 */
Define_entry(mercury__globals__get_prolog_dialect_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module11)
	init_entry(mercury__globals__get_termination_norm_2_0);
BEGIN_CODE

/* code for predicate 'get_termination_norm'/2 in mode 0 */
Define_entry(mercury__globals__get_termination_norm_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module12)
	init_entry(mercury__globals__get_trace_level_2_0);
BEGIN_CODE

/* code for predicate 'get_trace_level'/2 in mode 0 */
Define_entry(mercury__globals__get_trace_level_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module13)
	init_entry(mercury__globals__set_options_3_0);
BEGIN_CODE

/* code for predicate 'set_options'/3 in mode 0 */
Define_entry(mercury__globals__set_options_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 6, mercury__globals__set_options_3_0, "globals:globals/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module14)
	init_entry(mercury__globals__set_trace_level_3_0);
BEGIN_CODE

/* code for predicate 'set_trace_level'/3 in mode 0 */
Define_entry(mercury__globals__set_trace_level_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 6, mercury__globals__set_trace_level_3_0, "globals:globals/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);

BEGIN_MODULE(globals_module15)
	init_entry(mercury__globals__lookup_option_3_0);
BEGIN_CODE

/* code for predicate 'lookup_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_option_3_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	tailcall(ENTRY(mercury__map__lookup_3_0),
		ENTRY(mercury__globals__lookup_option_3_0));
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(globals_module16)
	init_entry(mercury__globals__lookup_bool_option_3_0);
	init_label(mercury__globals__lookup_bool_option_3_0_i2);
	init_label(mercury__globals__lookup_bool_option_3_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_bool_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_bool_option_3_0);
	MR_incr_sp_push_msg(1, "globals:lookup_bool_option/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__lookup_bool_option_3_0_i2,
		ENTRY(mercury__globals__lookup_bool_option_3_0));
Define_label(mercury__globals__lookup_bool_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__globals__lookup_bool_option_3_0_i3);
	r1 = (Word) MR_string_const("globals__lookup_bool_option: invalid bool option", 48);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_bool_option_3_0));
END_MODULE


BEGIN_MODULE(globals_module17)
	init_entry(mercury__globals__lookup_bool_option_3_1);
	init_label(mercury__globals__lookup_bool_option_3_1_i2);
	init_label(mercury__globals__lookup_bool_option_3_1_i1001);
	init_label(mercury__globals__lookup_bool_option_3_1_i3);
	init_label(mercury__globals__lookup_bool_option_3_1_i1);
BEGIN_CODE

/* code for predicate 'lookup_bool_option'/3 in mode 1 */
Define_entry(mercury__globals__lookup_bool_option_3_1);
	MR_incr_sp_push_msg(2, "globals:lookup_bool_option/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__lookup_bool_option_3_1_i2,
		ENTRY(mercury__globals__lookup_bool_option_3_1));
Define_label(mercury__globals__lookup_bool_option_3_1_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_1));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_1_i3);
	if ((MR_stackvar(1) != MR_const_field(MR_mktag(1), r1, (Integer) 0)))
		GOTO_LABEL(mercury__globals__lookup_bool_option_3_1_i1);
Define_label(mercury__globals__lookup_bool_option_3_1_i1001);
	update_prof_current_proc(LABEL(mercury__globals__lookup_bool_option_3_1));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__lookup_bool_option_3_1_i3);
	r1 = (Word) MR_string_const("globals__lookup_bool_option: invalid bool option", 48);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__lookup_bool_option_3_1_i1001,
		ENTRY(mercury__globals__lookup_bool_option_3_1));
Define_label(mercury__globals__lookup_bool_option_3_1_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module18)
	init_entry(mercury__globals__lookup_int_option_3_0);
	init_label(mercury__globals__lookup_int_option_3_0_i2);
	init_label(mercury__globals__lookup_int_option_3_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_int_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_int_option_3_0);
	MR_incr_sp_push_msg(1, "globals:lookup_int_option/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__lookup_int_option_3_0_i2,
		ENTRY(mercury__globals__lookup_int_option_3_0));
Define_label(mercury__globals__lookup_int_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_int_option_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__globals__lookup_int_option_3_0_i3);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__globals__lookup_int_option_3_0_i3);
	r1 = (Word) MR_string_const("globals__lookup_int_option: invalid int option", 46);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_int_option_3_0));
END_MODULE


BEGIN_MODULE(globals_module19)
	init_entry(mercury__globals__lookup_string_option_3_0);
	init_label(mercury__globals__lookup_string_option_3_0_i2);
	init_label(mercury__globals__lookup_string_option_3_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_string_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_string_option_3_0);
	MR_incr_sp_push_msg(1, "globals:lookup_string_option/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__lookup_string_option_3_0_i2,
		ENTRY(mercury__globals__lookup_string_option_3_0));
Define_label(mercury__globals__lookup_string_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_string_option_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__globals__lookup_string_option_3_0_i3);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__globals__lookup_string_option_3_0_i3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__globals__lookup_string_option_3_0_i3);
	r1 = (Word) MR_string_const("globals__lookup_string_option: invalid string option", 52);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_string_option_3_0));
END_MODULE


BEGIN_MODULE(globals_module20)
	init_entry(mercury__globals__lookup_accumulating_option_3_0);
	init_label(mercury__globals__lookup_accumulating_option_3_0_i2);
	init_label(mercury__globals__lookup_accumulating_option_3_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_accumulating_option'/3 in mode 0 */
Define_entry(mercury__globals__lookup_accumulating_option_3_0);
	MR_incr_sp_push_msg(1, "globals:lookup_accumulating_option/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__lookup_accumulating_option_3_0_i2,
		ENTRY(mercury__globals__lookup_accumulating_option_3_0));
Define_label(mercury__globals__lookup_accumulating_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__lookup_accumulating_option_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__globals__lookup_accumulating_option_3_0_i3);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 3))
		GOTO_LABEL(mercury__globals__lookup_accumulating_option_3_0_i3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__globals__lookup_accumulating_option_3_0_i3);
	r1 = (Word) MR_string_const("globals__lookup_accumulating_option: invalid accumulating option", 64);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__globals__lookup_accumulating_option_3_0));
END_MODULE

Declare_entry(mercury__getopt__lookup_bool_option_3_0);
Declare_entry(mercury__exprn_aux__imported_is_constant_3_0);

BEGIN_MODULE(globals_module21)
	init_entry(mercury__globals__have_static_code_addresses_2_0);
	init_label(mercury__globals__have_static_code_addresses_2_0_i2);
	init_label(mercury__globals__have_static_code_addresses_2_0_i3);
BEGIN_CODE

/* code for predicate 'have_static_code_addresses'/2 in mode 0 */
Define_entry(mercury__globals__have_static_code_addresses_2_0);
	MR_incr_sp_push_msg(2, "globals:have_static_code_addresses/2");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r3 = (Integer) 76;
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__have_static_code_addresses_2_0_i2,
		ENTRY(mercury__globals__have_static_code_addresses_2_0));
Define_label(mercury__globals__have_static_code_addresses_2_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__have_static_code_addresses_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r3 = (Integer) 78;
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__globals__have_static_code_addresses_2_0_i3,
		ENTRY(mercury__globals__have_static_code_addresses_2_0));
Define_label(mercury__globals__have_static_code_addresses_2_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__have_static_code_addresses_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__exprn_aux__imported_is_constant_3_0),
		ENTRY(mercury__globals__have_static_code_addresses_2_0));
END_MODULE


BEGIN_MODULE(globals_module22)
	init_entry(mercury__globals__want_return_var_layouts_2_0);
	init_label(mercury__globals__want_return_var_layouts_2_0_i7);
	init_label(mercury__globals__want_return_var_layouts_2_0_i1003);
	init_label(mercury__globals__want_return_var_layouts_2_0_i4);
	init_label(mercury__globals__want_return_var_layouts_2_0_i3);
BEGIN_CODE

/* code for predicate 'want_return_var_layouts'/2 in mode 0 */
Define_entry(mercury__globals__want_return_var_layouts_2_0);
	MR_incr_sp_push_msg(2, "globals:want_return_var_layouts/2");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) 2))
		GOTO_LABEL(mercury__globals__want_return_var_layouts_2_0_i1003);
	MR_stackvar(1) = r1;
	r2 = (Integer) 47;
	call_localret(STATIC(mercury__globals__lookup_bool_option_3_0),
		mercury__globals__want_return_var_layouts_2_0_i7,
		ENTRY(mercury__globals__want_return_var_layouts_2_0));
Define_label(mercury__globals__want_return_var_layouts_2_0_i7);
	update_prof_current_proc(LABEL(mercury__globals__want_return_var_layouts_2_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__globals__want_return_var_layouts_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 5) == (Integer) 0))
		GOTO_LABEL(mercury__globals__want_return_var_layouts_2_0_i3);
	GOTO_LABEL(mercury__globals__want_return_var_layouts_2_0_i4);
Define_label(mercury__globals__want_return_var_layouts_2_0_i1003);
	r1 = (Integer) 1;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__want_return_var_layouts_2_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__want_return_var_layouts_2_0_i3);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__copy_2_1);
Declare_entry(mercury__std_util__type_to_univ_2_0);
Declare_entry(mercury__io__set_globals_3_0);

BEGIN_MODULE(globals_module23)
	init_entry(mercury__globals__io_init_8_0);
	init_label(mercury__globals__io_init_8_0_i2);
	init_label(mercury__globals__io_init_8_0_i3);
	init_label(mercury__globals__io_init_8_0_i4);
	init_label(mercury__globals__io_init_8_0_i5);
	init_label(mercury__globals__io_init_8_0_i6);
	init_label(mercury__globals__io_init_8_0_i7);
BEGIN_CODE

/* code for predicate 'io_init'/8 in mode 0 */
Define_entry(mercury__globals__io_init_8_0);
	MR_incr_sp_push_msg(7, "globals:io_init/8");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_gc_method_0;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i2,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_tags_method_0;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i3,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i3);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_prolog_dialect_0;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i4,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_termination_norm_0;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i5,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i5);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_trace_level_0;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__globals__io_init_8_0_i6,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__globals__io_init_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_init_8_0_i7,
		ENTRY(mercury__globals__io_init_8_0));
Define_label(mercury__globals__io_init_8_0_i7);
	update_prof_current_proc(LABEL(mercury__globals__io_init_8_0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__io__set_globals_3_0),
		ENTRY(mercury__globals__io_init_8_0));
END_MODULE

Declare_entry(mercury__io__get_globals_3_0);
Declare_entry(mercury__std_util__univ_to_type_2_0);

BEGIN_MODULE(globals_module24)
	init_entry(mercury__globals__io_get_gc_method_3_0);
	init_label(mercury__globals__io_get_gc_method_3_0_i2);
	init_label(mercury__globals__io_get_gc_method_3_0_i4);
	init_label(mercury__globals__io_get_gc_method_3_0_i3);
	init_label(mercury__globals__io_get_gc_method_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_gc_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_gc_method_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_gc_method/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_gc_method_3_0_i2,
		ENTRY(mercury__globals__io_get_gc_method_3_0));
Define_label(mercury__globals__io_get_gc_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_gc_method_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_gc_method_3_0_i4,
		ENTRY(mercury__globals__io_get_gc_method_3_0));
Define_label(mercury__globals__io_get_gc_method_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_gc_method_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_gc_method_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_gc_method_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_gc_method_3_0_i6,
		ENTRY(mercury__globals__io_get_gc_method_3_0));
Define_label(mercury__globals__io_get_gc_method_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_gc_method_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module25)
	init_entry(mercury__globals__io_get_tags_method_3_0);
	init_label(mercury__globals__io_get_tags_method_3_0_i2);
	init_label(mercury__globals__io_get_tags_method_3_0_i4);
	init_label(mercury__globals__io_get_tags_method_3_0_i3);
	init_label(mercury__globals__io_get_tags_method_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_tags_method'/3 in mode 0 */
Define_entry(mercury__globals__io_get_tags_method_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_tags_method/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_tags_method_3_0_i2,
		ENTRY(mercury__globals__io_get_tags_method_3_0));
Define_label(mercury__globals__io_get_tags_method_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_tags_method_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_tags_method_3_0_i4,
		ENTRY(mercury__globals__io_get_tags_method_3_0));
Define_label(mercury__globals__io_get_tags_method_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_tags_method_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_tags_method_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_tags_method_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_tags_method_3_0_i6,
		ENTRY(mercury__globals__io_get_tags_method_3_0));
Define_label(mercury__globals__io_get_tags_method_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_tags_method_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module26)
	init_entry(mercury__globals__io_get_prolog_dialect_3_0);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i4);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
	init_label(mercury__globals__io_get_prolog_dialect_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_prolog_dialect'/3 in mode 0 */
Define_entry(mercury__globals__io_get_prolog_dialect_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_prolog_dialect/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_prolog_dialect_3_0_i2,
		ENTRY(mercury__globals__io_get_prolog_dialect_3_0));
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_prolog_dialect_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_prolog_dialect_3_0_i4,
		ENTRY(mercury__globals__io_get_prolog_dialect_3_0));
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_prolog_dialect_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_prolog_dialect_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_prolog_dialect_3_0_i6,
		ENTRY(mercury__globals__io_get_prolog_dialect_3_0));
Define_label(mercury__globals__io_get_prolog_dialect_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_prolog_dialect_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module27)
	init_entry(mercury__globals__io_get_termination_norm_3_0);
	init_label(mercury__globals__io_get_termination_norm_3_0_i2);
	init_label(mercury__globals__io_get_termination_norm_3_0_i4);
	init_label(mercury__globals__io_get_termination_norm_3_0_i3);
	init_label(mercury__globals__io_get_termination_norm_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_termination_norm'/3 in mode 0 */
Define_entry(mercury__globals__io_get_termination_norm_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_termination_norm/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_termination_norm_3_0_i2,
		ENTRY(mercury__globals__io_get_termination_norm_3_0));
Define_label(mercury__globals__io_get_termination_norm_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_termination_norm_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_termination_norm_3_0_i4,
		ENTRY(mercury__globals__io_get_termination_norm_3_0));
Define_label(mercury__globals__io_get_termination_norm_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_termination_norm_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_termination_norm_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_termination_norm_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_termination_norm_3_0_i6,
		ENTRY(mercury__globals__io_get_termination_norm_3_0));
Define_label(mercury__globals__io_get_termination_norm_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_termination_norm_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module28)
	init_entry(mercury__globals__io_get_trace_level_3_0);
	init_label(mercury__globals__io_get_trace_level_3_0_i2);
	init_label(mercury__globals__io_get_trace_level_3_0_i4);
	init_label(mercury__globals__io_get_trace_level_3_0_i3);
	init_label(mercury__globals__io_get_trace_level_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_trace_level'/3 in mode 0 */
Define_entry(mercury__globals__io_get_trace_level_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_trace_level/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_trace_level_3_0_i2,
		ENTRY(mercury__globals__io_get_trace_level_3_0));
Define_label(mercury__globals__io_get_trace_level_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_trace_level_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_trace_level_3_0_i4,
		ENTRY(mercury__globals__io_get_trace_level_3_0));
Define_label(mercury__globals__io_get_trace_level_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_trace_level_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_trace_level_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_trace_level_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_trace_level_3_0_i6,
		ENTRY(mercury__globals__io_get_trace_level_3_0));
Define_label(mercury__globals__io_get_trace_level_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_trace_level_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module29)
	init_entry(mercury__globals__io_get_globals_3_0);
	init_label(mercury__globals__io_get_globals_3_0_i2);
	init_label(mercury__globals__io_get_globals_3_0_i4);
	init_label(mercury__globals__io_get_globals_3_0_i3);
	init_label(mercury__globals__io_get_globals_3_0_i6);
BEGIN_CODE

/* code for predicate 'io_get_globals'/3 in mode 0 */
Define_entry(mercury__globals__io_get_globals_3_0);
	MR_incr_sp_push_msg(2, "globals:io_get_globals/3");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_get_globals_3_0_i2,
		ENTRY(mercury__globals__io_get_globals_3_0));
Define_label(mercury__globals__io_get_globals_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_get_globals_3_0_i4,
		ENTRY(mercury__globals__io_get_globals_3_0));
Define_label(mercury__globals__io_get_globals_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_get_globals_3_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__globals__io_get_globals_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_get_globals_3_0_i6,
		ENTRY(mercury__globals__io_get_globals_3_0));
Define_label(mercury__globals__io_get_globals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_get_globals_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module30)
	init_entry(mercury__globals__io_set_globals_3_0);
	init_label(mercury__globals__io_set_globals_3_0_i2);
BEGIN_CODE

/* code for predicate 'io_set_globals'/3 in mode 0 */
Define_entry(mercury__globals__io_set_globals_3_0);
	MR_incr_sp_push_msg(2, "globals:io_set_globals/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_set_globals_3_0_i2,
		ENTRY(mercury__globals__io_set_globals_3_0));
Define_label(mercury__globals__io_set_globals_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_set_globals_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__set_globals_3_0),
		ENTRY(mercury__globals__io_set_globals_3_0));
END_MODULE

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(globals_module31)
	init_entry(mercury__globals__io_set_option_4_0);
	init_label(mercury__globals__io_set_option_4_0_i2);
	init_label(mercury__globals__io_set_option_4_0_i4);
	init_label(mercury__globals__io_set_option_4_0_i3);
	init_label(mercury__globals__io_set_option_4_0_i6);
	init_label(mercury__globals__io_set_option_4_0_i8);
	init_label(mercury__globals__io_set_option_4_0_i9);
BEGIN_CODE

/* code for predicate 'io_set_option'/4 in mode 0 */
Define_entry(mercury__globals__io_set_option_4_0);
	MR_incr_sp_push_msg(5, "globals:io_set_option/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_set_option_4_0_i2,
		ENTRY(mercury__globals__io_set_option_4_0));
Define_label(mercury__globals__io_set_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_set_option_4_0_i4,
		ENTRY(mercury__globals__io_set_option_4_0));
Define_label(mercury__globals__io_set_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_set_option_4_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__globals__io_set_option_4_0_i8,
		ENTRY(mercury__globals__io_set_option_4_0));
Define_label(mercury__globals__io_set_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_set_option_4_0_i6,
		ENTRY(mercury__globals__io_set_option_4_0));
Define_label(mercury__globals__io_set_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__globals__io_set_option_4_0_i8,
		ENTRY(mercury__globals__io_set_option_4_0));
	}
Define_label(mercury__globals__io_set_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__globals__io_set_option_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_set_option_4_0_i9,
		ENTRY(mercury__globals__io_set_option_4_0));
Define_label(mercury__globals__io_set_option_4_0_i9);
	update_prof_current_proc(LABEL(mercury__globals__io_set_option_4_0));
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__set_globals_3_0),
		ENTRY(mercury__globals__io_set_option_4_0));
END_MODULE


BEGIN_MODULE(globals_module32)
	init_entry(mercury__globals__io_set_trace_level_3_0);
	init_label(mercury__globals__io_set_trace_level_3_0_i2);
	init_label(mercury__globals__io_set_trace_level_3_0_i4);
	init_label(mercury__globals__io_set_trace_level_3_0_i3);
	init_label(mercury__globals__io_set_trace_level_3_0_i6);
	init_label(mercury__globals__io_set_trace_level_3_0_i8);
BEGIN_CODE

/* code for predicate 'io_set_trace_level'/3 in mode 0 */
Define_entry(mercury__globals__io_set_trace_level_3_0);
	MR_incr_sp_push_msg(3, "globals:io_set_trace_level/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_set_trace_level_3_0_i2,
		ENTRY(mercury__globals__io_set_trace_level_3_0));
Define_label(mercury__globals__io_set_trace_level_3_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_set_trace_level_3_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_set_trace_level_3_0_i4,
		ENTRY(mercury__globals__io_set_trace_level_3_0));
Define_label(mercury__globals__io_set_trace_level_3_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_set_trace_level_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_set_trace_level_3_0_i3);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__globals__io_set_trace_level_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(1);
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_set_trace_level_3_0_i8,
		ENTRY(mercury__globals__io_set_trace_level_3_0));
Define_label(mercury__globals__io_set_trace_level_3_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_set_trace_level_3_0_i6,
		ENTRY(mercury__globals__io_set_trace_level_3_0));
Define_label(mercury__globals__io_set_trace_level_3_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_set_trace_level_3_0));
	r3 = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__std_util__type_to_univ_2_0),
		mercury__globals__io_set_trace_level_3_0_i8,
		ENTRY(mercury__globals__io_set_trace_level_3_0));
Define_label(mercury__globals__io_set_trace_level_3_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_set_trace_level_3_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__set_globals_3_0),
		ENTRY(mercury__globals__io_set_trace_level_3_0));
END_MODULE


BEGIN_MODULE(globals_module33)
	init_entry(mercury__globals__io_set_trace_level_none_2_0);
BEGIN_CODE

/* code for predicate 'io_set_trace_level_none'/2 in mode 0 */
Define_entry(mercury__globals__io_set_trace_level_none_2_0);
	r2 = r1;
	r1 = (Integer) 0;
	tailcall(STATIC(mercury__globals__io_set_trace_level_3_0),
		ENTRY(mercury__globals__io_set_trace_level_none_2_0));
END_MODULE


BEGIN_MODULE(globals_module34)
	init_entry(mercury__globals__io_lookup_option_4_0);
	init_label(mercury__globals__io_lookup_option_4_0_i2);
	init_label(mercury__globals__io_lookup_option_4_0_i4);
	init_label(mercury__globals__io_lookup_option_4_0_i3);
	init_label(mercury__globals__io_lookup_option_4_0_i6);
	init_label(mercury__globals__io_lookup_option_4_0_i8);
BEGIN_CODE

/* code for predicate 'io_lookup_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_option_4_0);
	MR_incr_sp_push_msg(3, "globals:io_lookup_option/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_option_4_0));
Define_label(mercury__globals__io_lookup_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_option_4_0));
Define_label(mercury__globals__io_lookup_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_option_4_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__io_lookup_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_option_4_0));
Define_label(mercury__globals__io_lookup_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_option_4_0_i6,
		ENTRY(mercury__globals__io_lookup_option_4_0));
Define_label(mercury__globals__io_lookup_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__globals__io_lookup_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_option_4_0));
	}
Define_label(mercury__globals__io_lookup_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_option_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module35)
	init_entry(mercury__globals__io_lookup_bool_option_4_0);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i2);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i4);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i3);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i6);
	init_label(mercury__globals__io_lookup_bool_option_4_0_i8);
BEGIN_CODE

/* code for predicate 'io_lookup_bool_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_bool_option_4_0);
	MR_incr_sp_push_msg(3, "globals:io_lookup_bool_option/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_bool_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
Define_label(mercury__globals__io_lookup_bool_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_bool_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
Define_label(mercury__globals__io_lookup_bool_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_bool_option_4_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_bool_option_3_0),
		mercury__globals__io_lookup_bool_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
Define_label(mercury__globals__io_lookup_bool_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_bool_option_4_0_i6,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
Define_label(mercury__globals__io_lookup_bool_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_bool_option_3_0),
		mercury__globals__io_lookup_bool_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_bool_option_4_0));
Define_label(mercury__globals__io_lookup_bool_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module36)
	init_entry(mercury__globals__io_lookup_bool_option_4_1);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i2);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i4);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i3);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i6);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i8);
	init_label(mercury__globals__io_lookup_bool_option_4_1_i1);
BEGIN_CODE

/* code for predicate 'io_lookup_bool_option'/4 in mode 1 */
Define_entry(mercury__globals__io_lookup_bool_option_4_1);
	MR_incr_sp_push_msg(4, "globals:io_lookup_bool_option/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_bool_option_4_1_i2,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
Define_label(mercury__globals__io_lookup_bool_option_4_1_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_bool_option_4_1_i4,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
Define_label(mercury__globals__io_lookup_bool_option_4_1_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_bool_option_4_1_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__globals__lookup_bool_option_3_1),
		mercury__globals__io_lookup_bool_option_4_1_i8,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
Define_label(mercury__globals__io_lookup_bool_option_4_1_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_bool_option_4_1_i6,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
Define_label(mercury__globals__io_lookup_bool_option_4_1_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__globals__lookup_bool_option_3_1),
		mercury__globals__io_lookup_bool_option_4_1_i8,
		ENTRY(mercury__globals__io_lookup_bool_option_4_1));
Define_label(mercury__globals__io_lookup_bool_option_4_1_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_bool_option_4_1));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_bool_option_4_1_i1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__globals__io_lookup_bool_option_4_1_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module37)
	init_entry(mercury__globals__io_lookup_int_option_4_0);
	init_label(mercury__globals__io_lookup_int_option_4_0_i2);
	init_label(mercury__globals__io_lookup_int_option_4_0_i4);
	init_label(mercury__globals__io_lookup_int_option_4_0_i3);
	init_label(mercury__globals__io_lookup_int_option_4_0_i6);
	init_label(mercury__globals__io_lookup_int_option_4_0_i8);
BEGIN_CODE

/* code for predicate 'io_lookup_int_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_int_option_4_0);
	MR_incr_sp_push_msg(3, "globals:io_lookup_int_option/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_int_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
Define_label(mercury__globals__io_lookup_int_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_int_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
Define_label(mercury__globals__io_lookup_int_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_int_option_4_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_int_option_3_0),
		mercury__globals__io_lookup_int_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
Define_label(mercury__globals__io_lookup_int_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_int_option_4_0_i6,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
Define_label(mercury__globals__io_lookup_int_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_int_option_3_0),
		mercury__globals__io_lookup_int_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_int_option_4_0));
Define_label(mercury__globals__io_lookup_int_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_int_option_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module38)
	init_entry(mercury__globals__io_lookup_string_option_4_0);
	init_label(mercury__globals__io_lookup_string_option_4_0_i2);
	init_label(mercury__globals__io_lookup_string_option_4_0_i4);
	init_label(mercury__globals__io_lookup_string_option_4_0_i3);
	init_label(mercury__globals__io_lookup_string_option_4_0_i6);
	init_label(mercury__globals__io_lookup_string_option_4_0_i8);
BEGIN_CODE

/* code for predicate 'io_lookup_string_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_string_option_4_0);
	MR_incr_sp_push_msg(3, "globals:io_lookup_string_option/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_string_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
Define_label(mercury__globals__io_lookup_string_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_string_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
Define_label(mercury__globals__io_lookup_string_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_string_option_4_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_string_option_3_0),
		mercury__globals__io_lookup_string_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
Define_label(mercury__globals__io_lookup_string_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_string_option_4_0_i6,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
Define_label(mercury__globals__io_lookup_string_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_string_option_3_0),
		mercury__globals__io_lookup_string_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_string_option_4_0));
Define_label(mercury__globals__io_lookup_string_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_string_option_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module39)
	init_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i4);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i6);
	init_label(mercury__globals__io_lookup_accumulating_option_4_0_i8);
BEGIN_CODE

/* code for predicate 'io_lookup_accumulating_option'/4 in mode 0 */
Define_entry(mercury__globals__io_lookup_accumulating_option_4_0);
	MR_incr_sp_push_msg(3, "globals:io_lookup_accumulating_option/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__get_globals_3_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i2,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_globals__type_ctor_info_globals_0;
	call_localret(ENTRY(mercury__std_util__univ_to_type_2_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i4,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i4);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__globals__io_lookup_accumulating_option_4_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_accumulating_option_3_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i3);
	r1 = (Word) MR_string_const("globals__io_get_globals: univ_to_type failed", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i6,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i6);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__globals__lookup_accumulating_option_3_0),
		mercury__globals__io_lookup_accumulating_option_4_0_i8,
		ENTRY(mercury__globals__io_lookup_accumulating_option_4_0));
Define_label(mercury__globals__io_lookup_accumulating_option_4_0_i8);
	update_prof_current_proc(LABEL(mercury__globals__io_lookup_accumulating_option_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(globals_module40)
	init_entry(mercury____Unify___globals__globals_0_0);
	init_label(mercury____Unify___globals__globals_0_0_i2);
	init_label(mercury____Unify___globals__globals_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__globals_0_0);
	MR_incr_sp_push_msg(11, "globals:__Unify__/2");
	MR_stackvar(11) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___globals__globals_0_0_i2,
		ENTRY(mercury____Unify___globals__globals_0_0));
Define_label(mercury____Unify___globals__globals_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___globals__globals_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(6)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(7)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(8)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if ((MR_stackvar(4) != MR_stackvar(9)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(10)))
		GOTO_LABEL(mercury____Unify___globals__globals_0_0_i1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__globals_0_0_i1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module41)
	init_entry(mercury____Index___globals__globals_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__globals_0_0);
	tailcall(STATIC(mercury____Index___globals__globals_0__ua0_2_0),
		ENTRY(mercury____Index___globals__globals_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(globals_module42)
	init_entry(mercury____Compare___globals__globals_0_0);
	init_label(mercury____Compare___globals__globals_0_0_i3);
	init_label(mercury____Compare___globals__globals_0_0_i7);
	init_label(mercury____Compare___globals__globals_0_0_i11);
	init_label(mercury____Compare___globals__globals_0_0_i15);
	init_label(mercury____Compare___globals__globals_0_0_i19);
	init_label(mercury____Compare___globals__globals_0_0_i27);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__globals_0_0);
	MR_incr_sp_push_msg(11, "globals:__Compare__/3");
	MR_stackvar(11) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___globals__globals_0_0_i3,
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i27);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i7,
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i27);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i11,
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i27);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i15,
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i27);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___globals__globals_0_0_i19,
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___globals__globals_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___globals__globals_0_0_i27);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__globals_0_0));
Define_label(mercury____Compare___globals__globals_0_0_i27);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module43)
	init_entry(mercury____Unify___globals__gc_method_0_0);
	init_label(mercury____Unify___globals__gc_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__gc_method_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___globals__gc_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__gc_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module44)
	init_entry(mercury____Index___globals__gc_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__gc_method_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module45)
	init_entry(mercury____Compare___globals__gc_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__gc_method_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__gc_method_0_0));
END_MODULE


BEGIN_MODULE(globals_module46)
	init_entry(mercury____Unify___globals__tags_method_0_0);
	init_label(mercury____Unify___globals__tags_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__tags_method_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___globals__tags_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__tags_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module47)
	init_entry(mercury____Index___globals__tags_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__tags_method_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module48)
	init_entry(mercury____Compare___globals__tags_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__tags_method_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__tags_method_0_0));
END_MODULE


BEGIN_MODULE(globals_module49)
	init_entry(mercury____Unify___globals__prolog_dialect_0_0);
	init_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__prolog_dialect_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___globals__prolog_dialect_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__prolog_dialect_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module50)
	init_entry(mercury____Index___globals__prolog_dialect_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__prolog_dialect_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module51)
	init_entry(mercury____Compare___globals__prolog_dialect_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__prolog_dialect_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__prolog_dialect_0_0));
END_MODULE


BEGIN_MODULE(globals_module52)
	init_entry(mercury____Unify___globals__termination_norm_0_0);
	init_label(mercury____Unify___globals__termination_norm_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__termination_norm_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___globals__termination_norm_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__termination_norm_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module53)
	init_entry(mercury____Index___globals__termination_norm_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__termination_norm_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module54)
	init_entry(mercury____Compare___globals__termination_norm_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__termination_norm_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__termination_norm_0_0));
END_MODULE


BEGIN_MODULE(globals_module55)
	init_entry(mercury____Unify___globals__trace_level_0_0);
	init_label(mercury____Unify___globals__trace_level_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___globals__trace_level_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___globals__trace_level_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___globals__trace_level_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(globals_module56)
	init_entry(mercury____Index___globals__trace_level_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___globals__trace_level_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(globals_module57)
	init_entry(mercury____Compare___globals__trace_level_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___globals__trace_level_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___globals__trace_level_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__globals_maybe_bunch_0(void)
{
	globals_module0();
	globals_module1();
	globals_module2();
	globals_module3();
	globals_module4();
	globals_module5();
	globals_module6();
	globals_module7();
	globals_module8();
	globals_module9();
	globals_module10();
	globals_module11();
	globals_module12();
	globals_module13();
	globals_module14();
	globals_module15();
	globals_module16();
	globals_module17();
	globals_module18();
	globals_module19();
	globals_module20();
	globals_module21();
	globals_module22();
	globals_module23();
	globals_module24();
	globals_module25();
	globals_module26();
	globals_module27();
	globals_module28();
	globals_module29();
	globals_module30();
	globals_module31();
	globals_module32();
	globals_module33();
	globals_module34();
	globals_module35();
	globals_module36();
	globals_module37();
	globals_module38();
	globals_module39();
}

static void mercury__globals_maybe_bunch_1(void)
{
	globals_module40();
	globals_module41();
	globals_module42();
	globals_module43();
	globals_module44();
	globals_module45();
	globals_module46();
	globals_module47();
	globals_module48();
	globals_module49();
	globals_module50();
	globals_module51();
	globals_module52();
	globals_module53();
	globals_module54();
	globals_module55();
	globals_module56();
	globals_module57();
}

#endif

void mercury__globals__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__globals__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__globals_maybe_bunch_0();
		mercury__globals_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_gc_method_0,
			globals__gc_method_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_globals_0,
			globals__globals_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_prolog_dialect_0,
			globals__prolog_dialect_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_tags_method_0,
			globals__tags_method_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_termination_norm_0,
			globals__termination_norm_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_globals__type_ctor_info_trace_level_0,
			globals__trace_level_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
