/*
** Automatically generated from `handle_options.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__handle_options__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__handle_options__IntroducedFrom__pred__reset_grade_options__724__4_3_0);
Declare_static(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0);
Declare_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1);
Declare_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i6);
Declare_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1009);
Declare_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i4);
Declare_static(mercury__handle_options__IntroducedFrom__pred__add_option_list__604__2_3_0);
Declare_static(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0);
Declare_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i2);
Declare_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i5);
Declare_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i7);
Declare_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i8);
Declare_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i1);
Define_extern_entry(mercury__handle_options__handle_options_5_0);
Declare_label(mercury__handle_options__handle_options_5_0_i2);
Declare_label(mercury__handle_options__handle_options_5_0_i3);
Declare_label(mercury__handle_options__handle_options_5_0_i4);
Declare_label(mercury__handle_options__handle_options_5_0_i5);
Declare_label(mercury__handle_options__handle_options_5_0_i7);
Declare_label(mercury__handle_options__handle_options_5_0_i8);
Declare_label(mercury__handle_options__handle_options_5_0_i9);
Declare_label(mercury__handle_options__handle_options_5_0_i10);
Declare_label(mercury__handle_options__handle_options_5_0_i11);
Declare_label(mercury__handle_options__handle_options_5_0_i12);
Declare_label(mercury__handle_options__handle_options_5_0_i13);
Declare_label(mercury__handle_options__handle_options_5_0_i14);
Declare_label(mercury__handle_options__handle_options_5_0_i15);
Declare_label(mercury__handle_options__handle_options_5_0_i16);
Declare_label(mercury__handle_options__handle_options_5_0_i17);
Declare_label(mercury__handle_options__handle_options_5_0_i18);
Declare_label(mercury__handle_options__handle_options_5_0_i19);
Declare_label(mercury__handle_options__handle_options_5_0_i20);
Declare_label(mercury__handle_options__handle_options_5_0_i21);
Define_extern_entry(mercury__handle_options__usage_error_3_0);
Declare_label(mercury__handle_options__usage_error_3_0_i2);
Declare_label(mercury__handle_options__usage_error_3_0_i3);
Declare_label(mercury__handle_options__usage_error_3_0_i4);
Declare_label(mercury__handle_options__usage_error_3_0_i5);
Declare_label(mercury__handle_options__usage_error_3_0_i6);
Declare_label(mercury__handle_options__usage_error_3_0_i7);
Declare_label(mercury__handle_options__usage_error_3_0_i8);
Define_extern_entry(mercury__handle_options__usage_2_0);
Declare_label(mercury__handle_options__usage_2_0_i2);
Declare_label(mercury__handle_options__usage_2_0_i3);
Define_extern_entry(mercury__handle_options__long_usage_2_0);
Declare_label(mercury__handle_options__long_usage_2_0_i2);
Declare_label(mercury__handle_options__long_usage_2_0_i3);
Declare_label(mercury__handle_options__long_usage_2_0_i4);
Declare_label(mercury__handle_options__long_usage_2_0_i5);
Declare_label(mercury__handle_options__long_usage_2_0_i6);
Declare_label(mercury__handle_options__long_usage_2_0_i7);
Declare_label(mercury__handle_options__long_usage_2_0_i8);
Declare_label(mercury__handle_options__long_usage_2_0_i9);
Define_extern_entry(mercury__handle_options__compute_grade_2_0);
Declare_label(mercury__handle_options__compute_grade_2_0_i2);
Declare_label(mercury__handle_options__compute_grade_2_0_i3);
Declare_label(mercury__handle_options__compute_grade_2_0_i5);
Define_extern_entry(mercury__handle_options__convert_grade_option_3_0);
Declare_label(mercury__handle_options__convert_grade_option_3_0_i2);
Declare_label(mercury__handle_options__convert_grade_option_3_0_i3);
Declare_label(mercury__handle_options__convert_grade_option_3_0_i4);
Declare_label(mercury__handle_options__convert_grade_option_3_0_i6);
Declare_label(mercury__handle_options__convert_grade_option_3_0_i1);
Declare_static(mercury__handle_options__postprocess_options_4_0);
Declare_label(mercury__handle_options__postprocess_options_4_0_i4);
Declare_label(mercury__handle_options__postprocess_options_4_0_i8);
Declare_label(mercury__handle_options__postprocess_options_4_0_i10);
Declare_label(mercury__handle_options__postprocess_options_4_0_i14);
Declare_label(mercury__handle_options__postprocess_options_4_0_i16);
Declare_label(mercury__handle_options__postprocess_options_4_0_i20);
Declare_label(mercury__handle_options__postprocess_options_4_0_i22);
Declare_label(mercury__handle_options__postprocess_options_4_0_i25);
Declare_label(mercury__handle_options__postprocess_options_4_0_i29);
Declare_label(mercury__handle_options__postprocess_options_4_0_i31);
Declare_label(mercury__handle_options__postprocess_options_4_0_i32);
Declare_label(mercury__handle_options__postprocess_options_4_0_i37);
Declare_label(mercury__handle_options__postprocess_options_4_0_i39);
Declare_label(mercury__handle_options__postprocess_options_4_0_i40);
Declare_label(mercury__handle_options__postprocess_options_4_0_i47);
Declare_label(mercury__handle_options__postprocess_options_4_0_i48);
Declare_label(mercury__handle_options__postprocess_options_4_0_i49);
Declare_label(mercury__handle_options__postprocess_options_4_0_i50);
Declare_label(mercury__handle_options__postprocess_options_4_0_i51);
Declare_label(mercury__handle_options__postprocess_options_4_0_i46);
Declare_label(mercury__handle_options__postprocess_options_4_0_i53);
Declare_label(mercury__handle_options__postprocess_options_4_0_i44);
Declare_label(mercury__handle_options__postprocess_options_4_0_i34);
Declare_label(mercury__handle_options__postprocess_options_4_0_i27);
Declare_label(mercury__handle_options__postprocess_options_4_0_i23);
Declare_label(mercury__handle_options__postprocess_options_4_0_i18);
Declare_label(mercury__handle_options__postprocess_options_4_0_i12);
Declare_label(mercury__handle_options__postprocess_options_4_0_i6);
Declare_label(mercury__handle_options__postprocess_options_4_0_i3);
Declare_static(mercury__handle_options__postprocess_options_2_9_0);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i2);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i5);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i3);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i8);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i11);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i16);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i18);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i19);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i20);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i21);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i22);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i23);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i17);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i25);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i26);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i27);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i28);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i29);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i30);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i31);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i32);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i33);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i34);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i35);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i36);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i37);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i38);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i39);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i40);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i41);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i45);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i46);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i51);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i47);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i53);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i60);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i61);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i62);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i63);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i64);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i65);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i66);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i67);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i68);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i69);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i58);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i71);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i72);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i73);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i74);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i75);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i76);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i55);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i78);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i79);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i80);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i81);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i84);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i85);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i86);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i87);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i82);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i89);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i90);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i91);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i92);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i93);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i94);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i95);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i96);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i101);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i99);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i105);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i98);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i107);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i108);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i109);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i110);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i111);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i112);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i113);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i116);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i117);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i120);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i114);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i122);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i125);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i126);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i127);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i128);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i123);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i130);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i131);
Declare_label(mercury__handle_options__postprocess_options_2_9_0_i132);
Declare_static(mercury__handle_options__option_implies_5_0);
Declare_label(mercury__handle_options__option_implies_5_0_i2);
Declare_label(mercury__handle_options__option_implies_5_0_i3);
Declare_static(mercury__handle_options__option_neg_implies_5_0);
Declare_label(mercury__handle_options__option_neg_implies_5_0_i2);
Declare_label(mercury__handle_options__option_neg_implies_5_0_i3);
Declare_static(mercury__handle_options__construct_string_2_0);
Declare_label(mercury__handle_options__construct_string_2_0_i3);
Declare_label(mercury__handle_options__construct_string_2_0_i5);
Declare_label(mercury__handle_options__construct_string_2_0_i8);
Declare_label(mercury__handle_options__construct_string_2_0_i9);
Declare_label(mercury__handle_options__construct_string_2_0_i7);
Declare_static(mercury__handle_options__grade_component_table_3_0);
Declare_label(mercury__handle_options__grade_component_table_3_0_i3);
Declare_label(mercury__handle_options__grade_component_table_3_0_i1002);
Declare_label(mercury__handle_options__grade_component_table_3_0_i1001);
Declare_label(mercury__handle_options__grade_component_table_3_0_i5);
Declare_label(mercury__handle_options__grade_component_table_3_0_i6);
Declare_label(mercury__handle_options__grade_component_table_3_0_i7);
Declare_label(mercury__handle_options__grade_component_table_3_0_i8);
Declare_label(mercury__handle_options__grade_component_table_3_0_i9);
Declare_label(mercury__handle_options__grade_component_table_3_0_i10);
Declare_label(mercury__handle_options__grade_component_table_3_0_i11);
Declare_label(mercury__handle_options__grade_component_table_3_0_i12);
Declare_label(mercury__handle_options__grade_component_table_3_0_i13);
Declare_label(mercury__handle_options__grade_component_table_3_0_i14);
Declare_label(mercury__handle_options__grade_component_table_3_0_i15);
Declare_label(mercury__handle_options__grade_component_table_3_0_i16);
Declare_label(mercury__handle_options__grade_component_table_3_0_i17);
Declare_label(mercury__handle_options__grade_component_table_3_0_i18);
Declare_label(mercury__handle_options__grade_component_table_3_0_i19);
Declare_label(mercury__handle_options__grade_component_table_3_0_i20);
Declare_label(mercury__handle_options__grade_component_table_3_0_i21);
Declare_label(mercury__handle_options__grade_component_table_3_0_i22);
Declare_label(mercury__handle_options__grade_component_table_3_0_i23);
Declare_label(mercury__handle_options__grade_component_table_3_0_i24);
Declare_label(mercury__handle_options__grade_component_table_3_0_i25);
Declare_label(mercury__handle_options__grade_component_table_3_0_i26);
Declare_static(mercury__handle_options__grade_component_table_3_2);
Declare_label(mercury__handle_options__grade_component_table_3_2_i2);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1045);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1047);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1049);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1051);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1053);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1055);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1057);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1059);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1061);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1063);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1065);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1067);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1069);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1071);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1073);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1075);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1077);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1079);
Declare_label(mercury__handle_options__grade_component_table_3_2_i1081);
Declare_static(mercury__handle_options__grade_start_values_1_0);
Declare_label(mercury__handle_options__grade_start_values_1_0_i2);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1031);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1033);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1035);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1037);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1039);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1041);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1043);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1045);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1047);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1049);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1051);
Declare_label(mercury__handle_options__grade_start_values_1_0_i1053);
Declare_static(mercury__handle_options__split_grade_string_2_2_0);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i3);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i4);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i5);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i7);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i8);
Declare_label(mercury__handle_options__split_grade_string_2_2_0_i1);
Declare_static(mercury__handle_options__char_is_not_2_0);
Declare_label(mercury__handle_options__char_is_not_2_0_i1);
Declare_static(mercury____Unify___handle_options__grade_component_0_0);
Declare_label(mercury____Unify___handle_options__grade_component_0_0_i1);
Declare_static(mercury____Index___handle_options__grade_component_0_0);
Declare_static(mercury____Compare___handle_options__grade_component_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_handle_options__type_ctor_info_grade_component_0;

static const struct mercury_data_handle_options__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_handle_options__common_0;

static const struct mercury_data_handle_options__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_handle_options__common_1;

static const struct mercury_data_handle_options__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_handle_options__common_2;

static const struct mercury_data_handle_options__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_3;

static const struct mercury_data_handle_options__common_4_struct {
	Word * f1;
}  mercury_data_handle_options__common_4;

static const struct mercury_data_handle_options__common_5_struct {
	Word * f1;
}  mercury_data_handle_options__common_5;

static const struct mercury_data_handle_options__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_handle_options__common_6;

static const struct mercury_data_handle_options__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_7;

static const struct mercury_data_handle_options__common_8_struct {
	Word * f1;
}  mercury_data_handle_options__common_8;

static const struct mercury_data_handle_options__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_handle_options__common_9;

static const struct mercury_data_handle_options__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_10;

static const struct mercury_data_handle_options__common_11_struct {
	Word * f1;
}  mercury_data_handle_options__common_11;

static const struct mercury_data_handle_options__common_12_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_handle_options__common_12;

static const struct mercury_data_handle_options__common_13_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_13;

static const struct mercury_data_handle_options__common_14_struct {
	Word * f1;
}  mercury_data_handle_options__common_14;

static const struct mercury_data_handle_options__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_15;

static const struct mercury_data_handle_options__common_16_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_handle_options__common_16;

static const struct mercury_data_handle_options__common_17_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_17;

static const struct mercury_data_handle_options__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_handle_options__common_18;

static const struct mercury_data_handle_options__common_19_struct {
	String f1;
	Word * f2;
}  mercury_data_handle_options__common_19;

static const struct mercury_data_handle_options__common_20_struct {
	String f1;
	Word * f2;
}  mercury_data_handle_options__common_20;

static const struct mercury_data_handle_options__common_21_struct {
	String f1;
	Word * f2;
}  mercury_data_handle_options__common_21;

static const struct mercury_data_handle_options__common_22_struct {
	String f1;
	Word * f2;
}  mercury_data_handle_options__common_22;

static const struct mercury_data_handle_options__common_23_struct {
	String f1;
	Word * f2;
}  mercury_data_handle_options__common_23;

static const struct mercury_data_handle_options__common_24_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_handle_options__common_24;

static const struct mercury_data_handle_options__common_25_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_handle_options__common_25;

static const struct mercury_data_handle_options__common_26_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_handle_options__common_26;

static const struct mercury_data_handle_options__common_27_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_27;

static const struct mercury_data_handle_options__common_28_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_handle_options__common_28;

static const struct mercury_data_handle_options__common_29_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_29;

static const struct mercury_data_handle_options__common_30_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_30;

static const struct mercury_data_handle_options__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_handle_options__common_31;

static const struct mercury_data_handle_options__common_32_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_handle_options__common_32;

static const struct mercury_data_handle_options__common_33_struct {
	String f1;
}  mercury_data_handle_options__common_33;

static const struct mercury_data_handle_options__common_34_struct {
	String f1;
}  mercury_data_handle_options__common_34;

static const struct mercury_data_handle_options__common_35_struct {
	String f1;
}  mercury_data_handle_options__common_35;

static const struct mercury_data_handle_options__common_36_struct {
	String f1;
}  mercury_data_handle_options__common_36;

static const struct mercury_data_handle_options__common_37_struct {
	String f1;
}  mercury_data_handle_options__common_37;

static const struct mercury_data_handle_options__common_38_struct {
	String f1;
}  mercury_data_handle_options__common_38;

static const struct mercury_data_handle_options__common_39_struct {
	String f1;
}  mercury_data_handle_options__common_39;

static const struct mercury_data_handle_options__common_40_struct {
	Integer f1;
}  mercury_data_handle_options__common_40;

static const struct mercury_data_handle_options__common_41_struct {
	Integer f1;
}  mercury_data_handle_options__common_41;

static const struct mercury_data_handle_options__common_42_struct {
	String f1;
}  mercury_data_handle_options__common_42;

static const struct mercury_data_handle_options__common_43_struct {
	Integer f1;
	String f2;
}  mercury_data_handle_options__common_43;

static const struct mercury_data_handle_options__common_44_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	Integer f8;
	String f9;
	Integer f10;
	String f11;
	Integer f12;
	String f13;
	Integer f14;
	String f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	String f20;
	Integer f21;
	Integer f22;
	String f23;
	String f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
	Integer f33;
	Integer f34;
	String f35;
	Integer f36;
	String f37;
	Integer f38;
	String f39;
	Integer f40;
	Integer f41;
	String f42;
	Integer f43;
	Integer f44;
	Integer f45;
	String f46;
	Integer f47;
	String f48;
	Integer f49;
	Integer f50;
	Integer f51;
	Integer f52;
	String f53;
	Integer f54;
	Integer f55;
	Integer f56;
	Integer f57;
	Integer f58;
	Integer f59;
	Integer f60;
	Integer f61;
	Integer f62;
	Integer f63;
	Integer f64;
}  mercury_data_handle_options__common_44;

static const struct mercury_data_handle_options__common_45_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
	Integer f33;
	Integer f34;
	Integer f35;
	Integer f36;
	Integer f37;
	Integer f38;
	Integer f39;
	Integer f40;
	Integer f41;
	Integer f42;
	Integer f43;
	Integer f44;
	Integer f45;
	Integer f46;
	Integer f47;
	Integer f48;
	Integer f49;
	Integer f50;
	Integer f51;
	Integer f52;
	Integer f53;
	Integer f54;
	Integer f55;
	Integer f56;
	Integer f57;
	Integer f58;
	Integer f59;
	Integer f60;
	Integer f61;
	Integer f62;
	Integer f63;
	Integer f64;
}  mercury_data_handle_options__common_45;

static const struct mercury_data_handle_options__common_46_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_46;

static const struct mercury_data_handle_options__common_47_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_47;

static const struct mercury_data_handle_options__common_48_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_48;

static const struct mercury_data_handle_options__common_49_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_49;

static const struct mercury_data_handle_options__common_50_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_50;

static const struct mercury_data_handle_options__common_51_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_51;

static const struct mercury_data_handle_options__common_52_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_52;

static const struct mercury_data_handle_options__common_53_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_53;

static const struct mercury_data_handle_options__common_54_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_54;

static const struct mercury_data_handle_options__common_55_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_55;

static const struct mercury_data_handle_options__common_56_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_56;

static const struct mercury_data_handle_options__common_57_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_57;

static const struct mercury_data_handle_options__common_58_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_58;

static const struct mercury_data_handle_options__common_59_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_59;

static const struct mercury_data_handle_options__common_60_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_60;

static const struct mercury_data_handle_options__common_61_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_61;

static const struct mercury_data_handle_options__common_62_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_62;

static const struct mercury_data_handle_options__common_63_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_63;

static const struct mercury_data_handle_options__common_64_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_64;

static const struct mercury_data_handle_options__common_65_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_65;

static const struct mercury_data_handle_options__common_66_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_66;

static const struct mercury_data_handle_options__common_67_struct {
	Integer f1;
	String f2;
}  mercury_data_handle_options__common_67;

static const struct mercury_data_handle_options__common_68_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_68;

static const struct mercury_data_handle_options__common_69_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_69;

static const struct mercury_data_handle_options__common_70_struct {
	Integer f1;
	String f2;
}  mercury_data_handle_options__common_70;

static const struct mercury_data_handle_options__common_71_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_71;

static const struct mercury_data_handle_options__common_72_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_72;

static const struct mercury_data_handle_options__common_73_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_73;

static const struct mercury_data_handle_options__common_74_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_74;

static const struct mercury_data_handle_options__common_75_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_75;

static const struct mercury_data_handle_options__common_76_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_76;

static const struct mercury_data_handle_options__common_77_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_77;

static const struct mercury_data_handle_options__common_78_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_78;

static const struct mercury_data_handle_options__common_79_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_79;

static const struct mercury_data_handle_options__common_80_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_80;

static const struct mercury_data_handle_options__common_81_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_81;

static const struct mercury_data_handle_options__common_82_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_82;

static const struct mercury_data_handle_options__common_83_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_83;

static const struct mercury_data_handle_options__common_84_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_84;

static const struct mercury_data_handle_options__common_85_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_85;

static const struct mercury_data_handle_options__common_86_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_86;

static const struct mercury_data_handle_options__common_87_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_87;

static const struct mercury_data_handle_options__common_88_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_88;

static const struct mercury_data_handle_options__common_89_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_89;

static const struct mercury_data_handle_options__common_90_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_90;

static const struct mercury_data_handle_options__common_91_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_91;

static const struct mercury_data_handle_options__common_92_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_92;

static const struct mercury_data_handle_options__common_93_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_93;

static const struct mercury_data_handle_options__common_94_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_94;

static const struct mercury_data_handle_options__common_95_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_95;

static const struct mercury_data_handle_options__common_96_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_96;

static const struct mercury_data_handle_options__common_97_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_97;

static const struct mercury_data_handle_options__common_98_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_98;

static const struct mercury_data_handle_options__common_99_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_99;

static const struct mercury_data_handle_options__common_100_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_100;

static const struct mercury_data_handle_options__common_101_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_101;

static const struct mercury_data_handle_options__common_102_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_102;

static const struct mercury_data_handle_options__common_103_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_103;

static const struct mercury_data_handle_options__common_104_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_104;

static const struct mercury_data_handle_options__common_105_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_105;

static const struct mercury_data_handle_options__common_106_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_106;

static const struct mercury_data_handle_options__common_107_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_107;

static const struct mercury_data_handle_options__common_108_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_108;

static const struct mercury_data_handle_options__common_109_struct {
	Word * f1;
	Word * f2;
}  mercury_data_handle_options__common_109;

static const struct mercury_data_handle_options__common_110_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_110;

static const struct mercury_data_handle_options__common_111_struct {
	Integer f1;
	String f2;
}  mercury_data_handle_options__common_111;

static const struct mercury_data_handle_options__common_112_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_112;

static const struct mercury_data_handle_options__common_113_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_113;

static const struct mercury_data_handle_options__common_114_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_114;

static const struct mercury_data_handle_options__common_115_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__common_115;

static const struct mercury_data_handle_options__common_116_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_handle_options__common_116;

static const struct mercury_data_handle_options__common_117_struct {
	Word * f1;
	Code * f2;
	Integer f3;
	Integer f4;
}  mercury_data_handle_options__common_117;

static const struct mercury_data_handle_options__common_118_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
}  mercury_data_handle_options__common_118;

static const struct mercury_data_handle_options__type_ctor_functors_grade_component_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_handle_options__type_ctor_functors_grade_component_0;

static const struct mercury_data_handle_options__type_ctor_layout_grade_component_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_handle_options__type_ctor_layout_grade_component_0;

const struct MR_TypeCtorInfo_struct mercury_data_handle_options__type_ctor_info_grade_component_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___handle_options__grade_component_0_0),
	STATIC(mercury____Index___handle_options__grade_component_0_0),
	STATIC(mercury____Compare___handle_options__grade_component_0_0),
	(Integer) 0,
	(Word *) &mercury_data_handle_options__type_ctor_functors_grade_component_0,
	(Word *) &mercury_data_handle_options__type_ctor_layout_grade_component_0,
	MR_string_const("handle_options", 14),
	MR_string_const("grade_component", 15),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_options__type_ctor_info_option_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_getopt__type_ctor_info_option_data_0;
static const struct mercury_data_handle_options__common_0_struct mercury_data_handle_options__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_options__type_ctor_info_option_0,
	(Word *) &mercury_data_getopt__type_ctor_info_option_data_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_handle_options__common_1_struct mercury_data_handle_options__common_1 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_options__type_ctor_info_option_0,
	(Word *) &mercury_data_getopt__type_ctor_info_option_data_0
};

static const struct mercury_data_handle_options__common_2_struct mercury_data_handle_options__common_2 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("IntroducedFrom__pred__add_option_list__604__2", 45),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1)
};

static const struct mercury_data_handle_options__common_3_struct mercury_data_handle_options__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_2),
	STATIC(mercury__handle_options__IntroducedFrom__pred__add_option_list__604__2_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_handle_options__common_4_struct mercury_data_handle_options__common_4 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

static const struct mercury_data_handle_options__common_5_struct mercury_data_handle_options__common_5 = {
	(Word *) &mercury_data_options__type_ctor_info_option_0
};

static const struct mercury_data_handle_options__common_6_struct mercury_data_handle_options__common_6 = {
	(Integer) 0,
	MR_string_const("options", 7),
	MR_string_const("options", 7),
	MR_string_const("short_option", 12),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_5)
};

Declare_entry(mercury__options__short_option_2_0);
static const struct mercury_data_handle_options__common_7_struct mercury_data_handle_options__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_6),
	ENTRY(mercury__options__short_option_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_handle_options__common_8_struct mercury_data_handle_options__common_8 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_handle_options__common_9_struct mercury_data_handle_options__common_9 = {
	(Integer) 0,
	MR_string_const("options", 7),
	MR_string_const("options", 7),
	MR_string_const("long_option", 11),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_5)
};

Declare_entry(mercury__options__long_option_2_0);
static const struct mercury_data_handle_options__common_10_struct mercury_data_handle_options__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_9),
	ENTRY(mercury__options__long_option_2_0),
	(Integer) 0
};

static const struct mercury_data_handle_options__common_11_struct mercury_data_handle_options__common_11 = {
	(Word *) &mercury_data_getopt__type_ctor_info_option_data_0
};

static const struct mercury_data_handle_options__common_12_struct mercury_data_handle_options__common_12 = {
	(Integer) 0,
	MR_string_const("options", 7),
	MR_string_const("options", 7),
	MR_string_const("option_defaults", 15),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_11)
};

Declare_entry(mercury__options__option_defaults_2_0);
static const struct mercury_data_handle_options__common_13_struct mercury_data_handle_options__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_12),
	ENTRY(mercury__options__option_defaults_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_getopt__type_ctor_info_special_data_0;
static const struct mercury_data_handle_options__common_14_struct mercury_data_handle_options__common_14 = {
	(Word *) &mercury_data_getopt__type_ctor_info_special_data_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_getopt__type_ctor_info_maybe_option_table_1;
static const struct mercury_data_handle_options__common_15_struct mercury_data_handle_options__common_15 = {
	(Word *) &mercury_data_getopt__type_ctor_info_maybe_option_table_1,
	(Word *) &mercury_data_options__type_ctor_info_option_0
};

static const struct mercury_data_handle_options__common_16_struct mercury_data_handle_options__common_16 = {
	(Integer) 0,
	MR_string_const("options", 7),
	MR_string_const("options", 7),
	MR_string_const("special_handler", 15),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_15)
};

Declare_entry(mercury__options__special_handler_4_0);
static const struct mercury_data_handle_options__common_17_struct mercury_data_handle_options__common_17 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_16),
	ENTRY(mercury__options__special_handler_4_0),
	(Integer) 0
};

static const struct mercury_data_handle_options__common_18_struct mercury_data_handle_options__common_18 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_17)
};

static const struct mercury_data_handle_options__common_19_struct mercury_data_handle_options__common_19 = {
	MR_string_const("Use `mmc --help' for more information.\n", 39),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_20_struct mercury_data_handle_options__common_20 = {
	MR_string_const("Usage: mmc [<options>] <arguments>\n", 35),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_19)
};

static const struct mercury_data_handle_options__common_21_struct mercury_data_handle_options__common_21 = {
	MR_string_const("Copyright (C) 1993-1999 The University of Melbourne\n", 52),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_20)
};

static const struct mercury_data_handle_options__common_22_struct mercury_data_handle_options__common_22 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_21)
};

static const struct mercury_data_handle_options__common_23_struct mercury_data_handle_options__common_23 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_24_struct mercury_data_handle_options__common_24 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_handle_options__type_ctor_info_grade_component_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_handle_options__common_25_struct mercury_data_handle_options__common_25 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("IntroducedFrom__pred__compute_grade_components__639__3", 54),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_24)
};

static const struct mercury_data_handle_options__common_26_struct mercury_data_handle_options__common_26 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("grade_start_values", 18),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0)
};

static const struct mercury_data_handle_options__common_27_struct mercury_data_handle_options__common_27 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_26),
	STATIC(mercury__handle_options__grade_start_values_1_0),
	(Integer) 0
};

static const struct mercury_data_handle_options__common_28_struct mercury_data_handle_options__common_28 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("IntroducedFrom__pred__reset_grade_options__724__4", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1)
};

static const struct mercury_data_handle_options__common_29_struct mercury_data_handle_options__common_29 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_28),
	STATIC(mercury__handle_options__IntroducedFrom__pred__reset_grade_options__724__4_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_handle_options__common_30_struct mercury_data_handle_options__common_30 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_handle_options__type_ctor_info_grade_component_0
};

static const struct mercury_data_handle_options__common_31_struct mercury_data_handle_options__common_31 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("IntroducedFrom__pred__convert_grade_option__589__1", 50),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_30),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_30)
};

static const struct mercury_data_handle_options__common_32_struct mercury_data_handle_options__common_32 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_31),
	STATIC(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0),
	(Integer) 0
};

static const struct mercury_data_handle_options__common_33_struct mercury_data_handle_options__common_33 = {
	MR_string_const("Invalid argument to option `--hlds-dump-alias'.", 47)
};

static const struct mercury_data_handle_options__common_34_struct mercury_data_handle_options__common_34 = {
	MR_string_const("Invalid argument to option `--trace'\n\t(must be `minimum', `shallow', `deep', or `default').", 91)
};

static const struct mercury_data_handle_options__common_35_struct mercury_data_handle_options__common_35 = {
	MR_string_const("Invalid argument to option `--termination-norm'\n\t(must be `simple', `total' or  `num-data-elems').", 98)
};

static const struct mercury_data_handle_options__common_36_struct mercury_data_handle_options__common_36 = {
	MR_string_const("Invalid argument to option `--fact-table-hash-percent-full'\n\t(must be an integer between 1 and 100)", 99)
};

static const struct mercury_data_handle_options__common_37_struct mercury_data_handle_options__common_37 = {
	MR_string_const("Invalid prolog-dialect option (must be `sicstus', `nu', or `default')", 69)
};

static const struct mercury_data_handle_options__common_38_struct mercury_data_handle_options__common_38 = {
	MR_string_const("Invalid tags option (must be `none', `low' or `high')", 53)
};

static const struct mercury_data_handle_options__common_39_struct mercury_data_handle_options__common_39 = {
	MR_string_const("Invalid GC option (must be `none', `conservative' or `accurate')", 64)
};

static const struct mercury_data_handle_options__common_40_struct mercury_data_handle_options__common_40 = {
	(Integer) 0
};

static const struct mercury_data_handle_options__common_41_struct mercury_data_handle_options__common_41 = {
	(Integer) 1
};

static const struct mercury_data_handle_options__common_42_struct mercury_data_handle_options__common_42 = {
	MR_string_const("trailing and minimal model tabling are not compatible", 53)
};

static const struct mercury_data_handle_options__common_43_struct mercury_data_handle_options__common_43 = {
	(Integer) 0,
	MR_string_const("guest", 5)
};

static const struct mercury_data_handle_options__common_44_struct mercury_data_handle_options__common_44 = {
	MR_string_const("par", 3),
	MR_string_const("tr", 2),
	MR_string_const("profcalls", 9),
	MR_string_const("proftime", 8),
	MR_string_const("trace", 5),
	MR_string_const("gc", 2),
	MR_string_const("agc", 3),
	(Integer) 0,
	MR_string_const("asm_fast", 8),
	(Integer) 0,
	MR_string_const("asm_jump", 8),
	(Integer) 0,
	MR_string_const("picreg", 6),
	(Integer) 0,
	MR_string_const("none", 4),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("reg", 3),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("strce", 5),
	MR_string_const("profdeep", 8),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("mm", 2),
	(Integer) 0,
	MR_string_const("fast", 4),
	(Integer) 0,
	MR_string_const("jump", 4),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("memprof", 7),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("profall", 7),
	(Integer) 0,
	MR_string_const("prof", 4),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("debug", 5),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_handle_options__common_45_struct mercury_data_handle_options__common_45 = {
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) 1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 3,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) 5,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2
};

static const struct mercury_data_handle_options__common_46_struct mercury_data_handle_options__common_46 = {
	(Integer) 80,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_47_struct mercury_data_handle_options__common_47 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_46),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_48_struct mercury_data_handle_options__common_48 = {
	(Integer) 92,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_49_struct mercury_data_handle_options__common_49 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_48),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_50_struct mercury_data_handle_options__common_50 = {
	(Integer) 86,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_51_struct mercury_data_handle_options__common_51 = {
	(Integer) 88,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_52_struct mercury_data_handle_options__common_52 = {
	(Integer) 85,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_53_struct mercury_data_handle_options__common_53 = {
	(Integer) 87,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_54_struct mercury_data_handle_options__common_54 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_53),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_55_struct mercury_data_handle_options__common_55 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_52),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_54)
};

static const struct mercury_data_handle_options__common_56_struct mercury_data_handle_options__common_56 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_51),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_55)
};

static const struct mercury_data_handle_options__common_57_struct mercury_data_handle_options__common_57 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_50),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_56)
};

static const struct mercury_data_handle_options__common_58_struct mercury_data_handle_options__common_58 = {
	(Integer) 86,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_59_struct mercury_data_handle_options__common_59 = {
	(Integer) 85,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_60_struct mercury_data_handle_options__common_60 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_59),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_54)
};

static const struct mercury_data_handle_options__common_61_struct mercury_data_handle_options__common_61 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_51),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_60)
};

static const struct mercury_data_handle_options__common_62_struct mercury_data_handle_options__common_62 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_58),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_61)
};

static const struct mercury_data_handle_options__common_63_struct mercury_data_handle_options__common_63 = {
	(Integer) 90,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_64_struct mercury_data_handle_options__common_64 = {
	(Integer) 91,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_65_struct mercury_data_handle_options__common_65 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_64),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_66_struct mercury_data_handle_options__common_66 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_63),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_65)
};

static const struct mercury_data_handle_options__common_67_struct mercury_data_handle_options__common_67 = {
	(Integer) 0,
	MR_string_const("conservative", 12)
};

static const struct mercury_data_handle_options__common_68_struct mercury_data_handle_options__common_68 = {
	(Integer) 79,
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_handle_options__common_67)
};

static const struct mercury_data_handle_options__common_69_struct mercury_data_handle_options__common_69 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_68),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_70_struct mercury_data_handle_options__common_70 = {
	(Integer) 0,
	MR_string_const("accurate", 8)
};

static const struct mercury_data_handle_options__common_71_struct mercury_data_handle_options__common_71 = {
	(Integer) 79,
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_handle_options__common_70)
};

static const struct mercury_data_handle_options__common_72_struct mercury_data_handle_options__common_72 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_71),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_73_struct mercury_data_handle_options__common_73 = {
	(Integer) 78,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_74_struct mercury_data_handle_options__common_74 = {
	(Integer) 76,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_75_struct mercury_data_handle_options__common_75 = {
	(Integer) 77,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_76_struct mercury_data_handle_options__common_76 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_75),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_77_struct mercury_data_handle_options__common_77 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_74),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_76)
};

static const struct mercury_data_handle_options__common_78_struct mercury_data_handle_options__common_78 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_73),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_77)
};

static const struct mercury_data_handle_options__common_79_struct mercury_data_handle_options__common_79 = {
	(Integer) 77,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_80_struct mercury_data_handle_options__common_80 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_79),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_81_struct mercury_data_handle_options__common_81 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_74),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_80)
};

static const struct mercury_data_handle_options__common_82_struct mercury_data_handle_options__common_82 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_73),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_81)
};

static const struct mercury_data_handle_options__common_83_struct mercury_data_handle_options__common_83 = {
	(Integer) 94,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_84_struct mercury_data_handle_options__common_84 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_83),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_85_struct mercury_data_handle_options__common_85 = {
	(Integer) 78,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_86_struct mercury_data_handle_options__common_86 = {
	(Integer) 76,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_87_struct mercury_data_handle_options__common_87 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_86),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_80)
};

static const struct mercury_data_handle_options__common_88_struct mercury_data_handle_options__common_88 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_85),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_87)
};

static const struct mercury_data_handle_options__common_89_struct mercury_data_handle_options__common_89 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_86),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_76)
};

static const struct mercury_data_handle_options__common_90_struct mercury_data_handle_options__common_90 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_85),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_89)
};

static const struct mercury_data_handle_options__common_91_struct mercury_data_handle_options__common_91 = {
	(Integer) 90,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_92_struct mercury_data_handle_options__common_92 = {
	(Integer) 91,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_93_struct mercury_data_handle_options__common_93 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_92),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_94_struct mercury_data_handle_options__common_94 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_91),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_93)
};

static const struct mercury_data_handle_options__common_95_struct mercury_data_handle_options__common_95 = {
	(Integer) 88,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_96_struct mercury_data_handle_options__common_96 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_95),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_60)
};

static const struct mercury_data_handle_options__common_97_struct mercury_data_handle_options__common_97 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_58),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_96)
};

static const struct mercury_data_handle_options__common_98_struct mercury_data_handle_options__common_98 = {
	(Integer) 93,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_99_struct mercury_data_handle_options__common_99 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_98),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_100_struct mercury_data_handle_options__common_100 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_85),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_77)
};

static const struct mercury_data_handle_options__common_101_struct mercury_data_handle_options__common_101 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_85),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_81)
};

static const struct mercury_data_handle_options__common_102_struct mercury_data_handle_options__common_102 = {
	(Integer) 87,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41)
};

static const struct mercury_data_handle_options__common_103_struct mercury_data_handle_options__common_103 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_102),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_handle_options__common_104_struct mercury_data_handle_options__common_104 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_52),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_103)
};

static const struct mercury_data_handle_options__common_105_struct mercury_data_handle_options__common_105 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_51),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_104)
};

static const struct mercury_data_handle_options__common_106_struct mercury_data_handle_options__common_106 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_50),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_105)
};

static const struct mercury_data_handle_options__common_107_struct mercury_data_handle_options__common_107 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_58),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_105)
};

static const struct mercury_data_handle_options__common_108_struct mercury_data_handle_options__common_108 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_58),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_56)
};

static const struct mercury_data_handle_options__common_109_struct mercury_data_handle_options__common_109 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_91),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_65)
};

static const struct mercury_data_handle_options__common_110_struct mercury_data_handle_options__common_110 = {
	(Integer) 80,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_111_struct mercury_data_handle_options__common_111 = {
	(Integer) 0,
	MR_string_const("none", 4)
};

static const struct mercury_data_handle_options__common_112_struct mercury_data_handle_options__common_112 = {
	(Integer) 79,
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_handle_options__common_111)
};

static const struct mercury_data_handle_options__common_113_struct mercury_data_handle_options__common_113 = {
	(Integer) 92,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_114_struct mercury_data_handle_options__common_114 = {
	(Integer) 93,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_115_struct mercury_data_handle_options__common_115 = {
	(Integer) 94,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40)
};

static const struct mercury_data_handle_options__common_116_struct mercury_data_handle_options__common_116 = {
	(Integer) 0,
	MR_string_const("handle_options", 14),
	MR_string_const("handle_options", 14),
	MR_string_const("char_is_not", 11),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_4)
};

static const struct mercury_data_handle_options__common_117_struct mercury_data_handle_options__common_117 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_116),
	STATIC(mercury__handle_options__char_is_not_2_0),
	(Integer) 1,
	(Integer) 46
};

static const struct mercury_data_handle_options__common_118_struct mercury_data_handle_options__common_118 = {
	(Integer) 1,
	(Integer) 8,
	MR_string_const("gcc_ext", 7),
	MR_string_const("par", 3),
	MR_string_const("gc", 2),
	MR_string_const("prof", 4),
	MR_string_const("trail", 5),
	MR_string_const("minimal_model", 13),
	MR_string_const("pic", 3),
	MR_string_const("trace", 5)
};

static const struct mercury_data_handle_options__type_ctor_functors_grade_component_0_struct mercury_data_handle_options__type_ctor_functors_grade_component_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_118)
};

static const struct mercury_data_handle_options__type_ctor_layout_grade_component_0_struct mercury_data_handle_options__type_ctor_layout_grade_component_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_118),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_118),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_118),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_118)
};

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(handle_options_module0)
	init_entry(mercury__handle_options__IntroducedFrom__pred__reset_grade_options__724__4_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__reset_grade_options__724__4'/3 in mode 0 */
Define_static(mercury__handle_options__IntroducedFrom__pred__reset_grade_options__724__4_3_0);
	r3 = r2;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__handle_options__IntroducedFrom__pred__reset_grade_options__724__4_3_0));
END_MODULE

Declare_entry(do_fail);
Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__map__search_3_0);
Declare_entry(do_redo);

BEGIN_MODULE(handle_options_module1)
	init_entry(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0);
	init_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1);
	init_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i6);
	init_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1009);
	init_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i4);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__compute_grade_components__639__3'/2 in mode 0 */
Define_static(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0);
	MR_mkframe("handle_options:IntroducedFrom__pred__compute_grade_components__639__3/2", 6, ENTRY(do_fail));
	MR_framevar(1) = r1;
	call_localret(STATIC(mercury__handle_options__grade_component_table_3_2),
		mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1,
		STATIC(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
	MR_framevar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_framevar(5) = (Word) MR_redofr_slot(MR_maxfr);
	MR_framevar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i4);
	MR_framevar(2) = r1;
	MR_framevar(3) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0);
	r2 = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i6,
		STATIC(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_framevar(1);
	call_localret(ENTRY(mercury__map__search_3_0),
		mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1009,
		STATIC(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i1009);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_framevar(6);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_framevar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_framevar(5);
	GOTO(ENTRY(do_redo));
Define_label(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0));
	r1 = MR_framevar(2);
	r2 = MR_framevar(3);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_framevar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_framevar(5);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_succeed();
END_MODULE


BEGIN_MODULE(handle_options_module2)
	init_entry(mercury__handle_options__IntroducedFrom__pred__add_option_list__604__2_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__add_option_list__604__2'/3 in mode 0 */
Define_static(mercury__handle_options__IntroducedFrom__pred__add_option_list__604__2_3_0);
	r3 = r2;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__handle_options__IntroducedFrom__pred__add_option_list__604__2_3_0));
END_MODULE

Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(handle_options_module3)
	init_entry(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0);
	init_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i2);
	init_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i5);
	init_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i7);
	init_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i8);
	init_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__convert_grade_option__589__1'/5 in mode 0 */
Define_static(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0);
	MR_incr_sp_push_msg(5, "handle_options:IntroducedFrom__pred__convert_grade_option__589__1/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__handle_options__grade_component_table_3_0),
		mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i2,
		STATIC(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i1);
	MR_stackvar(2) = r3;
	r1 = (Word) (Word *) &mercury_data_handle_options__type_ctor_info_grade_component_0;
	r3 = MR_stackvar(3);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i5,
		STATIC(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
	if (r1)
		GOTO_LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i1);
	r1 = (Word) (Word *) &mercury_data_handle_options__type_ctor_info_grade_component_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i7,
		STATIC(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_3);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i8,
		STATIC(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
Define_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0));
	r2 = r1;
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__IntroducedFrom__pred__convert_grade_option__589__1_5_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__io__command_line_arguments_3_0);
Declare_entry(mercury__getopt__process_options_4_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__bool__or_list_2_0);
Declare_entry(mercury__bool__not_2_0);

BEGIN_MODULE(handle_options_module4)
	init_entry(mercury__handle_options__handle_options_5_0);
	init_label(mercury__handle_options__handle_options_5_0_i2);
	init_label(mercury__handle_options__handle_options_5_0_i3);
	init_label(mercury__handle_options__handle_options_5_0_i4);
	init_label(mercury__handle_options__handle_options_5_0_i5);
	init_label(mercury__handle_options__handle_options_5_0_i7);
	init_label(mercury__handle_options__handle_options_5_0_i8);
	init_label(mercury__handle_options__handle_options_5_0_i9);
	init_label(mercury__handle_options__handle_options_5_0_i10);
	init_label(mercury__handle_options__handle_options_5_0_i11);
	init_label(mercury__handle_options__handle_options_5_0_i12);
	init_label(mercury__handle_options__handle_options_5_0_i13);
	init_label(mercury__handle_options__handle_options_5_0_i14);
	init_label(mercury__handle_options__handle_options_5_0_i15);
	init_label(mercury__handle_options__handle_options_5_0_i16);
	init_label(mercury__handle_options__handle_options_5_0_i17);
	init_label(mercury__handle_options__handle_options_5_0_i18);
	init_label(mercury__handle_options__handle_options_5_0_i19);
	init_label(mercury__handle_options__handle_options_5_0_i20);
	init_label(mercury__handle_options__handle_options_5_0_i21);
BEGIN_CODE

/* code for predicate 'handle_options'/5 in mode 0 */
Define_entry(mercury__handle_options__handle_options_5_0);
	MR_incr_sp_push_msg(15, "handle_options:handle_options/5");
	MR_stackvar(15) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__command_line_arguments_3_0),
		mercury__handle_options__handle_options_5_0_i2,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_18);
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("-O2", 3);
	call_localret(ENTRY(mercury__getopt__process_options_4_0),
		mercury__handle_options__handle_options_5_0_i3,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__handle_options__postprocess_options_4_0),
		mercury__handle_options__handle_options_5_0_i4,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__handle_options_5_0_i5);
	r4 = r2;
	r2 = MR_stackvar(2);
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__handle_options__handle_options_5_0_i5);
	MR_stackvar(1) = r1;
	r1 = (Integer) 34;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i7,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(3) = r1;
	r1 = (Integer) 30;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i8,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(4) = r1;
	r1 = (Integer) 31;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i9,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(5) = r1;
	r1 = (Integer) 29;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i10,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(6) = r1;
	r1 = (Integer) 32;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i11,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i11);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(7) = r1;
	r1 = (Integer) 33;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i12,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i12);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(8) = r1;
	r1 = (Integer) 36;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i13,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i13);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(9) = r1;
	r1 = (Integer) 37;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i14,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i14);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(10) = r1;
	r1 = (Integer) 38;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i15,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i15);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(11) = r1;
	r1 = (Integer) 39;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i16,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i16);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(12) = r1;
	r1 = (Integer) 40;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i17,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i17);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(13) = r1;
	r1 = (Integer) 41;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i18,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i18);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	MR_stackvar(14) = r1;
	r1 = (Integer) 42;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__handle_options_5_0_i19,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i19);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_stackvar(14);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__handle_options__handle_options_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r15, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__bool__or_list_2_0),
		mercury__handle_options__handle_options_5_0_i20,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i20);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	call_localret(ENTRY(mercury__bool__not_2_0),
		mercury__handle_options__handle_options_5_0_i21,
		ENTRY(mercury__handle_options__handle_options_5_0));
Define_label(mercury__handle_options__handle_options_5_0_i21);
	update_prof_current_proc(LABEL(mercury__handle_options__handle_options_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__io__progname_base_4_0);
Declare_entry(mercury__io__stderr_stream_3_0);
Declare_entry(mercury__io__write_string_4_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(handle_options_module5)
	init_entry(mercury__handle_options__usage_error_3_0);
	init_label(mercury__handle_options__usage_error_3_0_i2);
	init_label(mercury__handle_options__usage_error_3_0_i3);
	init_label(mercury__handle_options__usage_error_3_0_i4);
	init_label(mercury__handle_options__usage_error_3_0_i5);
	init_label(mercury__handle_options__usage_error_3_0_i6);
	init_label(mercury__handle_options__usage_error_3_0_i7);
	init_label(mercury__handle_options__usage_error_3_0_i8);
BEGIN_CODE

/* code for predicate 'usage_error'/3 in mode 0 */
Define_entry(mercury__handle_options__usage_error_3_0);
	MR_incr_sp_push_msg(3, "handle_options:usage_error/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("mercury_compile", 15);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__usage_error_3_0_i2,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__usage_error_3_0_i3,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i4,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const(": ", 2);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i5,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i6,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__usage_error_3_0_i7,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	r2 = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__handle_options__usage_error_3_0_i8,
		ENTRY(mercury__handle_options__usage_error_3_0));
Define_label(mercury__handle_options__usage_error_3_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_error_3_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__handle_options__usage_2_0),
		ENTRY(mercury__handle_options__usage_error_3_0));
END_MODULE

Declare_entry(mercury__library__version_1_0);
Declare_entry(mercury__io__write_strings_4_0);

BEGIN_MODULE(handle_options_module6)
	init_entry(mercury__handle_options__usage_2_0);
	init_label(mercury__handle_options__usage_2_0_i2);
	init_label(mercury__handle_options__usage_2_0_i3);
BEGIN_CODE

/* code for predicate 'usage'/2 in mode 0 */
Define_entry(mercury__handle_options__usage_2_0);
	MR_incr_sp_push_msg(3, "handle_options:usage/2");
	MR_stackvar(3) = (Word) MR_succip;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__usage_2_0_i2,
		ENTRY(mercury__handle_options__usage_2_0));
Define_label(mercury__handle_options__usage_2_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__handle_options__usage_2_0_i3,
		ENTRY(mercury__handle_options__usage_2_0));
Define_label(mercury__handle_options__usage_2_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__usage_2_0));
	r3 = r1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__handle_options__usage_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_string_const("Mercury Compiler, version ", 26);
	r1 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__handle_options__usage_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_22);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_strings_4_0),
		ENTRY(mercury__handle_options__usage_2_0));
	}
END_MODULE

Declare_entry(mercury__io__write_strings_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__options__options_help_2_0);

BEGIN_MODULE(handle_options_module7)
	init_entry(mercury__handle_options__long_usage_2_0);
	init_label(mercury__handle_options__long_usage_2_0_i2);
	init_label(mercury__handle_options__long_usage_2_0_i3);
	init_label(mercury__handle_options__long_usage_2_0_i4);
	init_label(mercury__handle_options__long_usage_2_0_i5);
	init_label(mercury__handle_options__long_usage_2_0_i6);
	init_label(mercury__handle_options__long_usage_2_0_i7);
	init_label(mercury__handle_options__long_usage_2_0_i8);
	init_label(mercury__handle_options__long_usage_2_0_i9);
BEGIN_CODE

/* code for predicate 'long_usage'/2 in mode 0 */
Define_entry(mercury__handle_options__long_usage_2_0);
	MR_incr_sp_push_msg(2, "handle_options:long_usage/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__library__version_1_0),
		mercury__handle_options__long_usage_2_0_i2,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__handle_options__long_usage_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("Mercury Compiler, version ", 26);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__handle_options__long_usage_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_23);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__handle_options__long_usage_2_0_i3,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Copyright (C) 1993-1999 The University of Melbourne\n", 52);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i4,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Usage: mmc [<options>] <arguments>\n", 35);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i5,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Arguments:\n", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i6,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\tArguments ending in `.m' are assumed to be source file names.\n", 63);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i7,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i7);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\tArguments that do not end in `.m' are assumed to be module names.\n", 67);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i8,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Options:\n", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__handle_options__long_usage_2_0_i9,
		ENTRY(mercury__handle_options__long_usage_2_0));
Define_label(mercury__handle_options__long_usage_2_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__long_usage_2_0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__options__options_help_2_0),
		ENTRY(mercury__handle_options__long_usage_2_0));
END_MODULE

Declare_entry(mercury__globals__get_options_2_0);
Declare_entry(mercury__std_util__solutions_2_1);

BEGIN_MODULE(handle_options_module8)
	init_entry(mercury__handle_options__compute_grade_2_0);
	init_label(mercury__handle_options__compute_grade_2_0_i2);
	init_label(mercury__handle_options__compute_grade_2_0_i3);
	init_label(mercury__handle_options__compute_grade_2_0_i5);
BEGIN_CODE

/* code for predicate 'compute_grade'/2 in mode 0 */
Define_entry(mercury__handle_options__compute_grade_2_0);
	MR_incr_sp_push_msg(1, "handle_options:compute_grade/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__handle_options__compute_grade_2_0_i2,
		ENTRY(mercury__handle_options__compute_grade_2_0));
Define_label(mercury__handle_options__compute_grade_2_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__compute_grade_2_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__handle_options__compute_grade_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_24);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__handle_options__IntroducedFrom__pred__compute_grade_components__639__3_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_25);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__handle_options__compute_grade_2_0_i3,
		ENTRY(mercury__handle_options__compute_grade_2_0));
Define_label(mercury__handle_options__compute_grade_2_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__compute_grade_2_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__compute_grade_2_0_i5);
	r1 = (Word) MR_string_const("none", 4);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__handle_options__compute_grade_2_0_i5);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__handle_options__construct_string_2_0),
		ENTRY(mercury__handle_options__compute_grade_2_0));
END_MODULE

Declare_entry(mercury__std_util__aggregate_4_0);
Declare_entry(mercury__string__to_char_list_2_0);
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__list__foldl2_6_1);

BEGIN_MODULE(handle_options_module9)
	init_entry(mercury__handle_options__convert_grade_option_3_0);
	init_label(mercury__handle_options__convert_grade_option_3_0_i2);
	init_label(mercury__handle_options__convert_grade_option_3_0_i3);
	init_label(mercury__handle_options__convert_grade_option_3_0_i4);
	init_label(mercury__handle_options__convert_grade_option_3_0_i6);
	init_label(mercury__handle_options__convert_grade_option_3_0_i1);
BEGIN_CODE

/* code for predicate 'convert_grade_option'/3 in mode 0 */
Define_entry(mercury__handle_options__convert_grade_option_3_0);
	MR_incr_sp_push_msg(3, "handle_options:convert_grade_option/3");
	MR_stackvar(3) = (Word) MR_succip;
	r5 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_27);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_29);
	call_localret(ENTRY(mercury__std_util__aggregate_4_0),
		mercury__handle_options__convert_grade_option_3_0_i2,
		ENTRY(mercury__handle_options__convert_grade_option_3_0));
Define_label(mercury__handle_options__convert_grade_option_3_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__to_char_list_2_0),
		mercury__handle_options__convert_grade_option_3_0_i3,
		ENTRY(mercury__handle_options__convert_grade_option_3_0));
Define_label(mercury__handle_options__convert_grade_option_3_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_3_0));
	call_localret(STATIC(mercury__handle_options__split_grade_string_2_2_0),
		mercury__handle_options__convert_grade_option_3_0_i4,
		ENTRY(mercury__handle_options__convert_grade_option_3_0));
Define_label(mercury__handle_options__convert_grade_option_3_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__convert_grade_option_3_0_i1);
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_handle_options__type_ctor_info_grade_component_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__handle_options__convert_grade_option_3_0_i6,
		ENTRY(mercury__handle_options__convert_grade_option_3_0));
Define_label(mercury__handle_options__convert_grade_option_3_0_i6);
	update_prof_current_proc(LABEL(mercury__handle_options__convert_grade_option_3_0));
	r7 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_30);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_32);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__foldl2_6_1),
		ENTRY(mercury__handle_options__convert_grade_option_3_0));
Define_label(mercury__handle_options__convert_grade_option_3_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__globals__convert_gc_method_2_0);
Declare_entry(mercury__globals__convert_tags_method_2_0);
Declare_entry(mercury__globals__convert_prolog_dialect_2_0);
Declare_entry(mercury__globals__convert_termination_norm_2_0);
Declare_entry(mercury__globals__convert_trace_level_3_0);

BEGIN_MODULE(handle_options_module10)
	init_entry(mercury__handle_options__postprocess_options_4_0);
	init_label(mercury__handle_options__postprocess_options_4_0_i4);
	init_label(mercury__handle_options__postprocess_options_4_0_i8);
	init_label(mercury__handle_options__postprocess_options_4_0_i10);
	init_label(mercury__handle_options__postprocess_options_4_0_i14);
	init_label(mercury__handle_options__postprocess_options_4_0_i16);
	init_label(mercury__handle_options__postprocess_options_4_0_i20);
	init_label(mercury__handle_options__postprocess_options_4_0_i22);
	init_label(mercury__handle_options__postprocess_options_4_0_i25);
	init_label(mercury__handle_options__postprocess_options_4_0_i29);
	init_label(mercury__handle_options__postprocess_options_4_0_i31);
	init_label(mercury__handle_options__postprocess_options_4_0_i32);
	init_label(mercury__handle_options__postprocess_options_4_0_i37);
	init_label(mercury__handle_options__postprocess_options_4_0_i39);
	init_label(mercury__handle_options__postprocess_options_4_0_i40);
	init_label(mercury__handle_options__postprocess_options_4_0_i47);
	init_label(mercury__handle_options__postprocess_options_4_0_i48);
	init_label(mercury__handle_options__postprocess_options_4_0_i49);
	init_label(mercury__handle_options__postprocess_options_4_0_i50);
	init_label(mercury__handle_options__postprocess_options_4_0_i51);
	init_label(mercury__handle_options__postprocess_options_4_0_i46);
	init_label(mercury__handle_options__postprocess_options_4_0_i53);
	init_label(mercury__handle_options__postprocess_options_4_0_i44);
	init_label(mercury__handle_options__postprocess_options_4_0_i34);
	init_label(mercury__handle_options__postprocess_options_4_0_i27);
	init_label(mercury__handle_options__postprocess_options_4_0_i23);
	init_label(mercury__handle_options__postprocess_options_4_0_i18);
	init_label(mercury__handle_options__postprocess_options_4_0_i12);
	init_label(mercury__handle_options__postprocess_options_4_0_i6);
	init_label(mercury__handle_options__postprocess_options_4_0_i3);
BEGIN_CODE

/* code for predicate 'postprocess_options'/4 in mode 0 */
Define_static(mercury__handle_options__postprocess_options_4_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i3);
	MR_incr_sp_push_msg(8, "handle_options:postprocess_options/4");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r4 = (Integer) 79;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i4,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__globals__convert_gc_method_2_0),
		mercury__handle_options__postprocess_options_4_0_i8,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i6);
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 95;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i10,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i10);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i12);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i12);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__globals__convert_tags_method_2_0),
		mercury__handle_options__postprocess_options_4_0_i14,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i14);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i12);
	MR_stackvar(4) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 54;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i16,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i16);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i18);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i18);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__globals__convert_prolog_dialect_2_0),
		mercury__handle_options__postprocess_options_4_0_i20,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i20);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i18);
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 136;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i22,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i22);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i23);
	if (((Integer) MR_const_field(MR_mktag(2), r1, (Integer) 0) < (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i23);
	if (((Integer) MR_const_field(MR_mktag(2), r1, (Integer) 0) > (Integer) 100))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i23);
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 178;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i25,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i25);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i27);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i27);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__globals__convert_termination_norm_2_0),
		mercury__handle_options__postprocess_options_4_0_i29,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i29);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i27);
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 45;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i31,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i31);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 91;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i32,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i32);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r3 = MR_stackvar(7);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i34);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i34);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i34);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(ENTRY(mercury__globals__convert_trace_level_3_0),
		mercury__handle_options__postprocess_options_4_0_i37,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i37);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i34);
	MR_stackvar(7) = r2;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r3 = MR_stackvar(2);
	r4 = (Integer) 59;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__handle_options__postprocess_options_4_0_i39,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i39);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i40);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i40);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i40);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__handle_options__postprocess_options_2_9_0),
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i40);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i44);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i44);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("ALL", 3)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i47);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("abcdfgilmnprstuvCIMPTU", 22);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i46);
Define_label(mercury__handle_options__postprocess_options_4_0_i47);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("all", 3)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i48);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("abcdfgilmnprstuvCMPT", 20);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i46);
Define_label(mercury__handle_options__postprocess_options_4_0_i48);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("codegen", 7)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i49);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("dfnprsu", 7);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i46);
Define_label(mercury__handle_options__postprocess_options_4_0_i49);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("paths", 5)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i50);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("cP", 2);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i46);
Define_label(mercury__handle_options__postprocess_options_4_0_i50);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("petdr", 5)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i51);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("din", 3);
	GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i46);
Define_label(mercury__handle_options__postprocess_options_4_0_i51);
	if ((strcmp((char *)MR_const_field(MR_mktag(3), r1, (Integer) 1), (char *)(Word) MR_string_const("vanessa", 7)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_4_0_i44);
	r3 = MR_stackvar(2);
	r1 = (Word) MR_string_const("ltuCIU", 6);
Define_label(mercury__handle_options__postprocess_options_4_0_i46);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__handle_options__postprocess_options_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r2 = (Word) (Word *) &mercury_data_getopt__type_ctor_info_option_data_0;
	r4 = (Integer) 60;
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__handle_options__postprocess_options_4_0_i53,
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i53);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_4_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__handle_options__postprocess_options_2_9_0),
		STATIC(mercury__handle_options__postprocess_options_4_0));
Define_label(mercury__handle_options__postprocess_options_4_0_i44);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_33);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i34);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_34);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i27);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_35);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i23);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_36);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i18);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_37);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_38);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_39);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__handle_options__postprocess_options_4_0_i3);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__handle_options__postprocess_options_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	proceed();
END_MODULE

Declare_entry(mercury__globals__io_init_8_0);
Declare_entry(mercury__globals__io_set_option_4_0);
Declare_entry(mercury__globals__io_lookup_int_option_4_0);
Declare_entry(mercury__prog_io_util__report_warning_3_0);
Declare_entry(mercury__globals__io_lookup_accumulating_option_4_0);
Declare_entry(mercury__globals__io_lookup_string_option_4_0);
Declare_entry(mercury__io__get_environment_var_4_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(handle_options_module11)
	init_entry(mercury__handle_options__postprocess_options_2_9_0);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i2);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i5);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i3);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i8);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i11);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i16);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i18);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i19);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i20);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i21);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i22);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i23);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i17);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i25);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i26);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i27);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i28);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i29);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i30);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i31);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i32);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i33);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i34);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i35);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i36);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i37);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i38);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i39);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i40);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i41);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i45);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i46);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i51);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i47);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i53);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i60);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i61);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i62);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i63);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i64);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i65);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i66);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i67);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i68);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i69);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i58);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i71);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i72);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i73);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i74);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i75);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i76);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i55);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i78);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i79);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i80);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i81);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i84);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i85);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i86);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i87);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i82);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i89);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i90);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i91);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i92);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i93);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i94);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i95);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i96);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i101);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i99);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i105);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i98);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i107);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i108);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i109);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i110);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i111);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i112);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i113);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i116);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i117);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i120);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i114);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i122);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i125);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i126);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i127);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i128);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i123);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i130);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i131);
	init_label(mercury__handle_options__postprocess_options_2_9_0_i132);
BEGIN_CODE

/* code for predicate 'postprocess_options_2'/9 in mode 0 */
Define_static(mercury__handle_options__postprocess_options_2_9_0);
	MR_incr_sp_push_msg(6, "handle_options:postprocess_options_2/9");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r6;
	call_localret(ENTRY(mercury__globals__io_init_8_0),
		mercury__handle_options__postprocess_options_2_9_0_i2,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i3);
	r3 = r1;
	r1 = (Integer) 120;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i5,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 121;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i3,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i3);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i8);
	r1 = (Integer) 0;
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i11);
Define_label(mercury__handle_options__postprocess_options_2_9_0_i8);
	r1 = (Integer) 96;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i11,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i11);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i16);
	if (((Integer) r1 != (Integer) -1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i16);
	r1 = (Integer) 99;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i16,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i16);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) r1 >= (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i17);
	r1 = (Word) MR_string_const("mercury_compile", 15);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i18,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i18);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__handle_options__postprocess_options_2_9_0_i19,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i19);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_9_0_i20,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i20);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": warning: --num-tag-bits invalid or unspecified\n", 49);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_9_0_i21,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i21);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i22,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i22);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": using --num-tag-bits 0 (tags disabled)\n", 41);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__handle_options__postprocess_options_2_9_0_i23,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i23);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 96;
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i25,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i17);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__handle_options__postprocess_options_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r1;
	r1 = (Integer) 96;
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i25,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i25);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 101;
	r2 = (Integer) 76;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i26,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i26);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 101;
	r2 = (Integer) 77;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i27,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i27);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 101;
	r2 = (Integer) 78;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i28,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i28);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 176;
	r2 = (Integer) 175;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i29,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i29);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 175;
	r2 = (Integer) 174;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i30,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i30);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 175;
	r2 = (Integer) 10;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i31,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i31);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 33;
	r2 = (Integer) 143;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i32,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i32);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 143;
	r2 = (Integer) 140;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i33,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i33);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 142;
	r2 = (Integer) 141;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i34,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i34);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 140;
	r2 = (Integer) 141;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i35,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i35);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 143;
	r2 = (Integer) 142;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i36,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i36);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 18;
	r2 = (Integer) 17;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i37,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i37);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 144;
	r2 = (Integer) 217;
	r3 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i38,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i38);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Integer) 92;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i39,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i39);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 93;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i40,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i40);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i41);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i41);
	MR_stackvar(4) = r1;
	r1 = (Integer) 90;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_42);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i45,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i41);
	MR_stackvar(4) = r1;
	r1 = (Integer) 90;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i45,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i45);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(5) = r1;
	r1 = (Integer) 91;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i46,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i46);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i47);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i47);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i47);
	r1 = (Integer) 92;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i51,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i51);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Integer) 49;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i53,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i47);
	r1 = (Integer) 49;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i53,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i53);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(3) == (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i55);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i58);
	r1 = (Integer) 146;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i60,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i60);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 147;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i61,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i61);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 148;
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i62,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i62);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 155;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i63,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i63);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 157;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i64,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i64);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 158;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i65,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i65);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 159;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i66,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i66);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 170;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i67,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i67);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 163;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i68,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i68);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 162;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i69,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i69);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 165;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i71,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i58);
	r3 = r2;
	r1 = (Integer) 165;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i71,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i71);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 167;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i72,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i72);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 191;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i73,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i73);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 203;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i74,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i74);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 109;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i75,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i75);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 110;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i76,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i76);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 88;
	r2 = (Integer) 108;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i78,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i55);
	r4 = r2;
	r1 = (Integer) 88;
	r2 = (Integer) 108;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i78,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i78);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 65;
	r2 = (Integer) 170;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_neg_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i79,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i79);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 90;
	r2 = (Integer) 108;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i80,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i80);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 109;
	r2 = (Integer) 108;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i81,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i81);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i82);
	r3 = r1;
	r1 = (Integer) 107;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i84,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i84);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 110;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i85,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i85);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 194;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i86,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i86);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 204;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i87,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i87);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 108;
	r2 = (Integer) 106;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i89,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i82);
	r4 = r1;
	r1 = (Integer) 108;
	r2 = (Integer) 106;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i89,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i89);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 107;
	r2 = (Integer) 106;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i90,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i90);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 110;
	r2 = (Integer) 170;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i91,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i91);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 92;
	r2 = (Integer) 203;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i92,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i92);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 92;
	r2 = (Integer) 191;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i93,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i93);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 93;
	r2 = (Integer) 194;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i94,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i94);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Integer) 58;
	call_localret(ENTRY(mercury__globals__io_lookup_accumulating_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i95,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i95);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(3) = r1;
	r1 = (Integer) 20;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i96,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i96);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) MR_stackvar(3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i101);
	r3 = r2;
	GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i99);
Define_label(mercury__handle_options__postprocess_options_2_9_0_i101);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i98);
	r3 = r2;
Define_label(mercury__handle_options__postprocess_options_2_9_0_i99);
	r1 = (Integer) 117;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i105,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i105);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 158;
	r2 = (Integer) 159;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i107,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i98);
	r4 = r2;
	r1 = (Integer) 158;
	r2 = (Integer) 159;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i107,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i107);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 156;
	r2 = (Integer) 140;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i108,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i108);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 156;
	r2 = (Integer) 155;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i109,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i109);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 32;
	r2 = (Integer) 155;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i110,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i110);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 35;
	r2 = (Integer) 34;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i111,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i111);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 42;
	r2 = (Integer) 231;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i112,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i112);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Integer) 232;
	call_localret(ENTRY(mercury__globals__io_lookup_string_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i113,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i113);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i114);
	r1 = (Word) MR_string_const("USER", 4);
	call_localret(ENTRY(mercury__io__get_environment_var_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i116,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i116);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i117);
	r4 = r1;
	r1 = (Integer) 232;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__handle_options__postprocess_options_2_9_0, "getopt:option_data/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i120,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i117);
	r3 = r2;
	r1 = (Integer) 232;
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_handle_options__common_43);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i120,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i120);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = (Integer) 228;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i122,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i114);
	r1 = (Integer) 228;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i122,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i122);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__postprocess_options_2_9_0_i123);
	r1 = (Integer) 227;
	call_localret(ENTRY(mercury__globals__io_lookup_accumulating_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i125,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i125);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	MR_stackvar(3) = r1;
	r1 = (Integer) 226;
	call_localret(ENTRY(mercury__globals__io_lookup_accumulating_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i126,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i126);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__handle_options__postprocess_options_2_9_0_i127,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
	}
Define_label(mercury__handle_options__postprocess_options_2_9_0_i127);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r3 = r1;
	r1 = (Integer) 227;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__handle_options__postprocess_options_2_9_0, "getopt:option_data/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__globals__io_set_option_4_0),
		mercury__handle_options__postprocess_options_2_9_0_i128,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i128);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 141;
	r2 = (Integer) 9;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i130,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i123);
	r4 = r2;
	r1 = (Integer) 141;
	r2 = (Integer) 9;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_40);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i130,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i130);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 204;
	r2 = (Integer) 201;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i131,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i131);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r4 = r1;
	r1 = (Integer) 204;
	r2 = (Integer) 198;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_41);
	call_localret(STATIC(mercury__handle_options__option_implies_5_0),
		mercury__handle_options__postprocess_options_2_9_0_i132,
		STATIC(mercury__handle_options__postprocess_options_2_9_0));
Define_label(mercury__handle_options__postprocess_options_2_9_0_i132);
	update_prof_current_proc(LABEL(mercury__handle_options__postprocess_options_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module12)
	init_entry(mercury__handle_options__option_implies_5_0);
	init_label(mercury__handle_options__option_implies_5_0_i2);
	init_label(mercury__handle_options__option_implies_5_0_i3);
BEGIN_CODE

/* code for predicate 'option_implies'/5 in mode 0 */
Define_static(mercury__handle_options__option_implies_5_0);
	MR_incr_sp_push_msg(3, "handle_options:option_implies/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__option_implies_5_0_i2,
		STATIC(mercury__handle_options__option_implies_5_0));
Define_label(mercury__handle_options__option_implies_5_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__option_implies_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__handle_options__option_implies_5_0_i3);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__globals__io_set_option_4_0),
		STATIC(mercury__handle_options__option_implies_5_0));
Define_label(mercury__handle_options__option_implies_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module13)
	init_entry(mercury__handle_options__option_neg_implies_5_0);
	init_label(mercury__handle_options__option_neg_implies_5_0_i2);
	init_label(mercury__handle_options__option_neg_implies_5_0_i3);
BEGIN_CODE

/* code for predicate 'option_neg_implies'/5 in mode 0 */
Define_static(mercury__handle_options__option_neg_implies_5_0);
	MR_incr_sp_push_msg(3, "handle_options:option_neg_implies/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__handle_options__option_neg_implies_5_0_i2,
		STATIC(mercury__handle_options__option_neg_implies_5_0));
Define_label(mercury__handle_options__option_neg_implies_5_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__option_neg_implies_5_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__handle_options__option_neg_implies_5_0_i3);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__globals__io_set_option_4_0),
		STATIC(mercury__handle_options__option_neg_implies_5_0));
Define_label(mercury__handle_options__option_neg_implies_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(handle_options_module14)
	init_entry(mercury__handle_options__construct_string_2_0);
	init_label(mercury__handle_options__construct_string_2_0_i3);
	init_label(mercury__handle_options__construct_string_2_0_i5);
	init_label(mercury__handle_options__construct_string_2_0_i8);
	init_label(mercury__handle_options__construct_string_2_0_i9);
	init_label(mercury__handle_options__construct_string_2_0_i7);
BEGIN_CODE

/* code for predicate 'construct_string'/2 in mode 0 */
Define_static(mercury__handle_options__construct_string_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__construct_string_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
Define_label(mercury__handle_options__construct_string_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__construct_string_2_0_i5);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
Define_label(mercury__handle_options__construct_string_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__construct_string_2_0_i7);
	MR_incr_sp_push_msg(3, "handle_options:construct_string/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	localcall(mercury__handle_options__construct_string_2_0,
		LABEL(mercury__handle_options__construct_string_2_0_i8),
		STATIC(mercury__handle_options__construct_string_2_0));
Define_label(mercury__handle_options__construct_string_2_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__construct_string_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(".", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__handle_options__construct_string_2_0_i9,
		STATIC(mercury__handle_options__construct_string_2_0));
	}
Define_label(mercury__handle_options__construct_string_2_0_i9);
	update_prof_current_proc(LABEL(mercury__handle_options__construct_string_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(".", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__handle_options__construct_string_2_0));
	}
Define_label(mercury__handle_options__construct_string_2_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(".", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__handle_options__construct_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__handle_options__construct_string_2_0));
	}
END_MODULE


BEGIN_MODULE(handle_options_module15)
	init_entry(mercury__handle_options__grade_component_table_3_0);
	init_label(mercury__handle_options__grade_component_table_3_0_i3);
	init_label(mercury__handle_options__grade_component_table_3_0_i1002);
	init_label(mercury__handle_options__grade_component_table_3_0_i1001);
	init_label(mercury__handle_options__grade_component_table_3_0_i5);
	init_label(mercury__handle_options__grade_component_table_3_0_i6);
	init_label(mercury__handle_options__grade_component_table_3_0_i7);
	init_label(mercury__handle_options__grade_component_table_3_0_i8);
	init_label(mercury__handle_options__grade_component_table_3_0_i9);
	init_label(mercury__handle_options__grade_component_table_3_0_i10);
	init_label(mercury__handle_options__grade_component_table_3_0_i11);
	init_label(mercury__handle_options__grade_component_table_3_0_i12);
	init_label(mercury__handle_options__grade_component_table_3_0_i13);
	init_label(mercury__handle_options__grade_component_table_3_0_i14);
	init_label(mercury__handle_options__grade_component_table_3_0_i15);
	init_label(mercury__handle_options__grade_component_table_3_0_i16);
	init_label(mercury__handle_options__grade_component_table_3_0_i17);
	init_label(mercury__handle_options__grade_component_table_3_0_i18);
	init_label(mercury__handle_options__grade_component_table_3_0_i19);
	init_label(mercury__handle_options__grade_component_table_3_0_i20);
	init_label(mercury__handle_options__grade_component_table_3_0_i21);
	init_label(mercury__handle_options__grade_component_table_3_0_i22);
	init_label(mercury__handle_options__grade_component_table_3_0_i23);
	init_label(mercury__handle_options__grade_component_table_3_0_i24);
	init_label(mercury__handle_options__grade_component_table_3_0_i25);
	init_label(mercury__handle_options__grade_component_table_3_0_i26);
BEGIN_CODE

/* code for predicate 'grade_component_table'/3 in mode 0 */
Define_static(mercury__handle_options__grade_component_table_3_0);
	r2 = (hash_string(r1) & (Integer) 63);
Define_label(mercury__handle_options__grade_component_table_3_0_i3);
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_44))[(Integer) r2];
	if (!(r3))
		GOTO_LABEL(mercury__handle_options__grade_component_table_3_0_i1002);
	if ((strcmp((char *)r3, (char *)r1) == 0))
		GOTO_LABEL(mercury__handle_options__grade_component_table_3_0_i5);
Define_label(mercury__handle_options__grade_component_table_3_0_i1002);
	r2 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_45))[(Integer) r2];
	if (((Integer) r2 >= (Integer) 0))
		GOTO_LABEL(mercury__handle_options__grade_component_table_3_0_i3);
Define_label(mercury__handle_options__grade_component_table_3_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i5);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__handle_options__grade_component_table_3_0_i6) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i7) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i8) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i9) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i10) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i11) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i12) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i13) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i14) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i15) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i16) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i17) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i18) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i19) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i20) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i21) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i22) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i23) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i24) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i25) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i26) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001) AND
		LABEL(mercury__handle_options__grade_component_table_3_0_i1001));
Define_label(mercury__handle_options__grade_component_table_3_0_i6);
	r2 = (Integer) 1;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_47);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i7);
	r2 = (Integer) 4;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_49);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i8);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_57);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i9);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_62);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i10);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_66);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i11);
	r2 = (Integer) 2;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_69);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i12);
	r2 = (Integer) 2;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_72);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i13);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_78);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i14);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_82);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i15);
	r2 = (Integer) 6;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_84);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i16);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_88);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i17);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_90);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i18);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_94);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i19);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_97);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i20);
	r2 = (Integer) 5;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_99);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i21);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_100);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i22);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_101);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i23);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_106);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i24);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_107);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i25);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_108);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__grade_component_table_3_0_i26);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_109);
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module16)
	init_entry(mercury__handle_options__grade_component_table_3_2);
	init_label(mercury__handle_options__grade_component_table_3_2_i2);
	init_label(mercury__handle_options__grade_component_table_3_2_i1045);
	init_label(mercury__handle_options__grade_component_table_3_2_i1047);
	init_label(mercury__handle_options__grade_component_table_3_2_i1049);
	init_label(mercury__handle_options__grade_component_table_3_2_i1051);
	init_label(mercury__handle_options__grade_component_table_3_2_i1053);
	init_label(mercury__handle_options__grade_component_table_3_2_i1055);
	init_label(mercury__handle_options__grade_component_table_3_2_i1057);
	init_label(mercury__handle_options__grade_component_table_3_2_i1059);
	init_label(mercury__handle_options__grade_component_table_3_2_i1061);
	init_label(mercury__handle_options__grade_component_table_3_2_i1063);
	init_label(mercury__handle_options__grade_component_table_3_2_i1065);
	init_label(mercury__handle_options__grade_component_table_3_2_i1067);
	init_label(mercury__handle_options__grade_component_table_3_2_i1069);
	init_label(mercury__handle_options__grade_component_table_3_2_i1071);
	init_label(mercury__handle_options__grade_component_table_3_2_i1073);
	init_label(mercury__handle_options__grade_component_table_3_2_i1075);
	init_label(mercury__handle_options__grade_component_table_3_2_i1077);
	init_label(mercury__handle_options__grade_component_table_3_2_i1079);
	init_label(mercury__handle_options__grade_component_table_3_2_i1081);
BEGIN_CODE

/* code for predicate 'grade_component_table'/3 in mode 2 */
Define_static(mercury__handle_options__grade_component_table_3_2);
	MR_mkframe("handle_options:grade_component_table/3", 0, LABEL(mercury__handle_options__grade_component_table_3_2_i2));
	r1 = (Word) MR_string_const("none", 4);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_88);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1045);
	r1 = (Word) MR_string_const("reg", 3);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_90);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1045);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1047);
	r1 = (Word) MR_string_const("jump", 4);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_101);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1047);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1049);
	r1 = (Word) MR_string_const("asm_jump", 8);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_82);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1049);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1051);
	r1 = (Word) MR_string_const("fast", 4);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_100);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1051);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1053);
	r1 = (Word) MR_string_const("asm_fast", 8);
	r2 = (Integer) 0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_78);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1053);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1055);
	r1 = (Word) MR_string_const("par", 3);
	r2 = (Integer) 1;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_47);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1055);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1057);
	r1 = (Word) MR_string_const("gc", 2);
	r2 = (Integer) 2;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_69);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1057);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1059);
	r1 = (Word) MR_string_const("agc", 3);
	r2 = (Integer) 2;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_72);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1059);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1061);
	r1 = (Word) MR_string_const("prof", 4);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_108);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1061);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1063);
	r1 = (Word) MR_string_const("profdeep", 8);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_97);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1063);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1065);
	r1 = (Word) MR_string_const("proftime", 8);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_62);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1065);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1067);
	r1 = (Word) MR_string_const("profcalls", 9);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_57);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1067);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1069);
	r1 = (Word) MR_string_const("memprof", 7);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_106);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1069);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1071);
	r1 = (Word) MR_string_const("profall", 7);
	r2 = (Integer) 3;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_107);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1071);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1073);
	r1 = (Word) MR_string_const("tr", 2);
	r2 = (Integer) 4;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_49);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1073);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1075);
	r1 = (Word) MR_string_const("mm", 2);
	r2 = (Integer) 5;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_99);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1075);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1077);
	r1 = (Word) MR_string_const("picreg", 6);
	r2 = (Integer) 6;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_84);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1077);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1079);
	r1 = (Word) MR_string_const("debug", 5);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_109);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1079);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_component_table_3_2_i1081);
	r1 = (Word) MR_string_const("trace", 5);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_66);
	MR_succeed();
Define_label(mercury__handle_options__grade_component_table_3_2_i1081);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_component_table_3_2));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = (Word) MR_string_const("strce", 5);
	r2 = (Integer) 7;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_handle_options__common_94);
	MR_succeed();
END_MODULE


BEGIN_MODULE(handle_options_module17)
	init_entry(mercury__handle_options__grade_start_values_1_0);
	init_label(mercury__handle_options__grade_start_values_1_0_i2);
	init_label(mercury__handle_options__grade_start_values_1_0_i1031);
	init_label(mercury__handle_options__grade_start_values_1_0_i1033);
	init_label(mercury__handle_options__grade_start_values_1_0_i1035);
	init_label(mercury__handle_options__grade_start_values_1_0_i1037);
	init_label(mercury__handle_options__grade_start_values_1_0_i1039);
	init_label(mercury__handle_options__grade_start_values_1_0_i1041);
	init_label(mercury__handle_options__grade_start_values_1_0_i1043);
	init_label(mercury__handle_options__grade_start_values_1_0_i1045);
	init_label(mercury__handle_options__grade_start_values_1_0_i1047);
	init_label(mercury__handle_options__grade_start_values_1_0_i1049);
	init_label(mercury__handle_options__grade_start_values_1_0_i1051);
	init_label(mercury__handle_options__grade_start_values_1_0_i1053);
BEGIN_CODE

/* code for predicate 'grade_start_values'/1 in mode 0 */
Define_static(mercury__handle_options__grade_start_values_1_0);
	MR_mkframe("handle_options:grade_start_values/1", 0, LABEL(mercury__handle_options__grade_start_values_1_0_i2));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_85);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i2);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1031);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_86);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1031);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1033);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_79);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1033);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1035);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_110);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1035);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1037);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_112);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1037);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1039);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_51);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1039);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1041);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_50);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1041);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1043);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_59);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1043);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1045);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_53);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1045);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1047);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_113);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1047);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1049);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_114);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1049);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1051);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_115);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1051);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__handle_options__grade_start_values_1_0_i1053);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_63);
	MR_succeed();
Define_label(mercury__handle_options__grade_start_values_1_0_i1053);
	update_prof_current_proc(LABEL(mercury__handle_options__grade_start_values_1_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_92);
	MR_succeed();
END_MODULE

Declare_entry(mercury__list__takewhile_4_0);
Declare_entry(mercury__string__from_char_list_2_0);

BEGIN_MODULE(handle_options_module18)
	init_entry(mercury__handle_options__split_grade_string_2_2_0);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i3);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i4);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i5);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i7);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i8);
	init_label(mercury__handle_options__split_grade_string_2_2_0_i1);
BEGIN_CODE

/* code for predicate 'split_grade_string_2'/2 in mode 0 */
Define_static(mercury__handle_options__split_grade_string_2_2_0);
	MR_incr_sp_push_msg(2, "handle_options:split_grade_string_2/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__split_grade_string_2_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__handle_options__split_grade_string_2_2_0_i3);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_character_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_handle_options__common_117);
	call_localret(ENTRY(mercury__list__takewhile_4_0),
		mercury__handle_options__split_grade_string_2_2_0_i4,
		STATIC(mercury__handle_options__split_grade_string_2_2_0));
Define_label(mercury__handle_options__split_grade_string_2_2_0_i4);
	update_prof_current_proc(LABEL(mercury__handle_options__split_grade_string_2_2_0));
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__from_char_list_2_0),
		mercury__handle_options__split_grade_string_2_2_0_i5,
		STATIC(mercury__handle_options__split_grade_string_2_2_0));
Define_label(mercury__handle_options__split_grade_string_2_2_0_i5);
	update_prof_current_proc(LABEL(mercury__handle_options__split_grade_string_2_2_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__handle_options__split_grade_string_2_2_0_i7);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__handle_options__split_grade_string_2_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__handle_options__split_grade_string_2_2_0_i7);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	localcall(mercury__handle_options__split_grade_string_2_2_0,
		LABEL(mercury__handle_options__split_grade_string_2_2_0_i8),
		STATIC(mercury__handle_options__split_grade_string_2_2_0));
Define_label(mercury__handle_options__split_grade_string_2_2_0_i8);
	update_prof_current_proc(LABEL(mercury__handle_options__split_grade_string_2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__handle_options__split_grade_string_2_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__handle_options__split_grade_string_2_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__handle_options__split_grade_string_2_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module19)
	init_entry(mercury__handle_options__char_is_not_2_0);
	init_label(mercury__handle_options__char_is_not_2_0_i1);
BEGIN_CODE

/* code for predicate 'char_is_not'/2 in mode 0 */
Define_static(mercury__handle_options__char_is_not_2_0);
	if ((r1 == r2))
		GOTO_LABEL(mercury__handle_options__char_is_not_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__handle_options__char_is_not_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module20)
	init_entry(mercury____Unify___handle_options__grade_component_0_0);
	init_label(mercury____Unify___handle_options__grade_component_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___handle_options__grade_component_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___handle_options__grade_component_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___handle_options__grade_component_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(handle_options_module21)
	init_entry(mercury____Index___handle_options__grade_component_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___handle_options__grade_component_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(handle_options_module22)
	init_entry(mercury____Compare___handle_options__grade_component_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___handle_options__grade_component_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___handle_options__grade_component_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__handle_options_maybe_bunch_0(void)
{
	handle_options_module0();
	handle_options_module1();
	handle_options_module2();
	handle_options_module3();
	handle_options_module4();
	handle_options_module5();
	handle_options_module6();
	handle_options_module7();
	handle_options_module8();
	handle_options_module9();
	handle_options_module10();
	handle_options_module11();
	handle_options_module12();
	handle_options_module13();
	handle_options_module14();
	handle_options_module15();
	handle_options_module16();
	handle_options_module17();
	handle_options_module18();
	handle_options_module19();
	handle_options_module20();
	handle_options_module21();
	handle_options_module22();
}

#endif

void mercury__handle_options__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__handle_options__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__handle_options_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_handle_options__type_ctor_info_grade_component_0,
			handle_options__grade_component_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
