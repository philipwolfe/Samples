/*
** Automatically generated from `inst.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__inst__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___inst__bound_inst_0__ua0_2_0);
Declare_static(mercury____Index___inst__pred_inst_info_0__ua0_2_0);
Define_extern_entry(mercury____Unify___inst__inst_0_0);
Declare_label(mercury____Unify___inst__inst_0_0_i1020);
Declare_label(mercury____Unify___inst__inst_0_0_i5);
Declare_label(mercury____Unify___inst__inst_0_0_i1021);
Declare_label(mercury____Unify___inst__inst_0_0_i1022);
Declare_label(mercury____Unify___inst__inst_0_0_i14);
Declare_label(mercury____Unify___inst__inst_0_0_i15);
Declare_label(mercury____Unify___inst__inst_0_0_i19);
Declare_label(mercury____Unify___inst__inst_0_0_i23);
Declare_label(mercury____Unify___inst__inst_0_0_i27);
Declare_label(mercury____Unify___inst__inst_0_0_i31);
Declare_label(mercury____Unify___inst__inst_0_0_i33);
Declare_label(mercury____Unify___inst__inst_0_0_i1);
Define_extern_entry(mercury____Index___inst__inst_0_0);
Declare_label(mercury____Index___inst__inst_0_0_i4);
Declare_label(mercury____Index___inst__inst_0_0_i5);
Declare_label(mercury____Index___inst__inst_0_0_i6);
Declare_label(mercury____Index___inst__inst_0_0_i7);
Declare_label(mercury____Index___inst__inst_0_0_i8);
Declare_label(mercury____Index___inst__inst_0_0_i9);
Declare_label(mercury____Index___inst__inst_0_0_i10);
Declare_label(mercury____Index___inst__inst_0_0_i11);
Declare_label(mercury____Index___inst__inst_0_0_i12);
Declare_label(mercury____Index___inst__inst_0_0_i13);
Define_extern_entry(mercury____Compare___inst__inst_0_0);
Declare_label(mercury____Compare___inst__inst_0_0_i2);
Declare_label(mercury____Compare___inst__inst_0_0_i3);
Declare_label(mercury____Compare___inst__inst_0_0_i4);
Declare_label(mercury____Compare___inst__inst_0_0_i5);
Declare_label(mercury____Compare___inst__inst_0_0_i10);
Declare_label(mercury____Compare___inst__inst_0_0_i11);
Declare_label(mercury____Compare___inst__inst_0_0_i14);
Declare_label(mercury____Compare___inst__inst_0_0_i17);
Declare_label(mercury____Compare___inst__inst_0_0_i20);
Declare_label(mercury____Compare___inst__inst_0_0_i21);
Declare_label(mercury____Compare___inst__inst_0_0_i24);
Declare_label(mercury____Compare___inst__inst_0_0_i29);
Declare_label(mercury____Compare___inst__inst_0_0_i32);
Declare_label(mercury____Compare___inst__inst_0_0_i37);
Declare_label(mercury____Compare___inst__inst_0_0_i40);
Declare_label(mercury____Compare___inst__inst_0_0_i43);
Declare_label(mercury____Compare___inst__inst_0_0_i46);
Declare_label(mercury____Compare___inst__inst_0_0_i7);
Declare_label(mercury____Compare___inst__inst_0_0_i54);
Define_extern_entry(mercury____Unify___inst__uniqueness_0_0);
Declare_label(mercury____Unify___inst__uniqueness_0_0_i1);
Define_extern_entry(mercury____Index___inst__uniqueness_0_0);
Define_extern_entry(mercury____Compare___inst__uniqueness_0_0);
Define_extern_entry(mercury____Unify___inst__pred_inst_info_0_0);
Declare_label(mercury____Unify___inst__pred_inst_info_0_0_i2);
Declare_label(mercury____Unify___inst__pred_inst_info_0_0_i1004);
Declare_label(mercury____Unify___inst__pred_inst_info_0_0_i1);
Define_extern_entry(mercury____Index___inst__pred_inst_info_0_0);
Define_extern_entry(mercury____Compare___inst__pred_inst_info_0_0);
Declare_label(mercury____Compare___inst__pred_inst_info_0_0_i3);
Declare_label(mercury____Compare___inst__pred_inst_info_0_0_i7);
Declare_label(mercury____Compare___inst__pred_inst_info_0_0_i12);
Define_extern_entry(mercury____Unify___inst__bound_inst_0_0);
Declare_label(mercury____Unify___inst__bound_inst_0_0_i2);
Declare_label(mercury____Unify___inst__bound_inst_0_0_i1);
Define_extern_entry(mercury____Index___inst__bound_inst_0_0);
Define_extern_entry(mercury____Compare___inst__bound_inst_0_0);
Declare_label(mercury____Compare___inst__bound_inst_0_0_i3);
Declare_label(mercury____Compare___inst__bound_inst_0_0_i7);

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_bound_inst_0;

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_inst_0;

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_pred_inst_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_uniqueness_0;

static const struct mercury_data_inst__common_0_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
}  mercury_data_inst__common_0;

static const struct mercury_data_inst__common_1_struct {
	Word * f1;
}  mercury_data_inst__common_1;

static const struct mercury_data_inst__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_2;

static const struct mercury_data_inst__common_3_struct {
	Word * f1;
}  mercury_data_inst__common_3;

static const struct mercury_data_inst__common_4_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_inst__common_4;

static const struct mercury_data_inst__common_5_struct {
	Word * f1;
}  mercury_data_inst__common_5;

static const struct mercury_data_inst__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_6;

static const struct mercury_data_inst__common_7_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_inst__common_7;

static const struct mercury_data_inst__common_8_struct {
	Word * f1;
}  mercury_data_inst__common_8;

static const struct mercury_data_inst__common_9_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_inst__common_9;

static const struct mercury_data_inst__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_10;

static const struct mercury_data_inst__common_11_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_inst__common_11;

static const struct mercury_data_inst__common_12_struct {
	Word * f1;
}  mercury_data_inst__common_12;

static const struct mercury_data_inst__common_13_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_inst__common_13;

static const struct mercury_data_inst__common_14_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_inst__common_14;

static const struct mercury_data_inst__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_15;

static const struct mercury_data_inst__common_16_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_inst__common_16;

static const struct mercury_data_inst__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_17;

static const struct mercury_data_inst__common_18_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_inst__common_18;

static const struct mercury_data_inst__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_inst__common_19;

static const struct mercury_data_inst__common_20_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_inst__common_20;

static const struct mercury_data_inst__common_21_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_inst__common_21;

static const struct mercury_data_inst__common_22_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_inst__common_22;

static const struct mercury_data_inst__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_inst__common_23;

static const struct mercury_data_inst__common_24_struct {
	Word * f1;
}  mercury_data_inst__common_24;

static const struct mercury_data_inst__common_25_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_inst__common_25;

static const struct mercury_data_inst__type_ctor_functors_uniqueness_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_inst__type_ctor_functors_uniqueness_0;

static const struct mercury_data_inst__type_ctor_layout_uniqueness_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_inst__type_ctor_layout_uniqueness_0;

static const struct mercury_data_inst__type_ctor_functors_pred_inst_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_inst__type_ctor_functors_pred_inst_info_0;

static const struct mercury_data_inst__type_ctor_layout_pred_inst_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_inst__type_ctor_layout_pred_inst_info_0;

static const struct mercury_data_inst__type_ctor_functors_inst_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_inst__type_ctor_functors_inst_0;

static const struct mercury_data_inst__type_ctor_layout_inst_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_inst__type_ctor_layout_inst_0;

static const struct mercury_data_inst__type_ctor_functors_bound_inst_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_inst__type_ctor_functors_bound_inst_0;

static const struct mercury_data_inst__type_ctor_layout_bound_inst_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_inst__type_ctor_layout_bound_inst_0;

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_bound_inst_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___inst__bound_inst_0_0),
	ENTRY(mercury____Index___inst__bound_inst_0_0),
	ENTRY(mercury____Compare___inst__bound_inst_0_0),
	(Integer) 2,
	(Word *) &mercury_data_inst__type_ctor_functors_bound_inst_0,
	(Word *) &mercury_data_inst__type_ctor_layout_bound_inst_0,
	MR_string_const("inst", 4),
	MR_string_const("bound_inst", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_inst_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___inst__inst_0_0),
	ENTRY(mercury____Index___inst__inst_0_0),
	ENTRY(mercury____Compare___inst__inst_0_0),
	(Integer) 2,
	(Word *) &mercury_data_inst__type_ctor_functors_inst_0,
	(Word *) &mercury_data_inst__type_ctor_layout_inst_0,
	MR_string_const("inst", 4),
	MR_string_const("inst", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_pred_inst_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___inst__pred_inst_info_0_0),
	ENTRY(mercury____Index___inst__pred_inst_info_0_0),
	ENTRY(mercury____Compare___inst__pred_inst_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_inst__type_ctor_functors_pred_inst_info_0,
	(Word *) &mercury_data_inst__type_ctor_layout_pred_inst_info_0,
	MR_string_const("inst", 4),
	MR_string_const("pred_inst_info", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_inst__type_ctor_info_uniqueness_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___inst__uniqueness_0_0),
	ENTRY(mercury____Index___inst__uniqueness_0_0),
	ENTRY(mercury____Compare___inst__uniqueness_0_0),
	(Integer) 0,
	(Word *) &mercury_data_inst__type_ctor_functors_uniqueness_0,
	(Word *) &mercury_data_inst__type_ctor_layout_uniqueness_0,
	MR_string_const("inst", 4),
	MR_string_const("uniqueness", 10),
	(Integer) 3
};

static const struct mercury_data_inst__common_0_struct mercury_data_inst__common_0 = {
	(Integer) 1,
	(Integer) 5,
	MR_string_const("shared", 6),
	MR_string_const("unique", 6),
	MR_string_const("mostly_unique", 13),
	MR_string_const("clobbered", 9),
	MR_string_const("mostly_clobbered", 16)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_pred_or_func_0;
static const struct mercury_data_inst__common_1_struct mercury_data_inst__common_1 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_pred_or_func_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
static const struct mercury_data_inst__common_2_struct mercury_data_inst__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_mode_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_determinism_0;
static const struct mercury_data_inst__common_3_struct mercury_data_inst__common_3 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_determinism_0
};

static const struct mercury_data_inst__common_4_struct mercury_data_inst__common_4 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_3),
	MR_string_const("pred_inst_info", 14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_inst__common_5_struct mercury_data_inst__common_5 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0
};

static const struct mercury_data_inst__common_6_struct mercury_data_inst__common_6 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_inst__type_ctor_info_inst_0
};

static const struct mercury_data_inst__common_7_struct mercury_data_inst__common_7 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_6),
	MR_string_const("abstract_inst", 13),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__common_8_struct mercury_data_inst__common_8 = {
	(Word *) &mercury_data_inst__type_ctor_info_uniqueness_0
};

static const struct mercury_data_inst__common_9_struct mercury_data_inst__common_9 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_8),
	MR_string_const("any", 3),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__common_10_struct mercury_data_inst__common_10 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_inst__type_ctor_info_bound_inst_0
};

static const struct mercury_data_inst__common_11_struct mercury_data_inst__common_11 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_10),
	MR_string_const("bound", 5),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_inst_name_0;
static const struct mercury_data_inst__common_12_struct mercury_data_inst__common_12 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_inst_name_0
};

static const struct mercury_data_inst__common_13_struct mercury_data_inst__common_13 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_12),
	MR_string_const("defined_inst", 12),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__common_14_struct mercury_data_inst__common_14 = {
	(Integer) 0,
	MR_string_const("free", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_inst__common_15_struct mercury_data_inst__common_15 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_inst__common_16_struct mercury_data_inst__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_15),
	MR_string_const("free", 4),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_inst__common_17_struct mercury_data_inst__common_17 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_inst__type_ctor_info_pred_inst_info_0
};

static const struct mercury_data_inst__common_18_struct mercury_data_inst__common_18 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_17),
	MR_string_const("ground", 6),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_inst_var_type_0;
static const struct mercury_data_inst__common_19_struct mercury_data_inst__common_19 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0
};

static const struct mercury_data_inst__common_20_struct mercury_data_inst__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_19),
	MR_string_const("inst_var", 8),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__common_21_struct mercury_data_inst__common_21 = {
	(Integer) 0,
	MR_string_const("not_reached", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__common_22_struct mercury_data_inst__common_22 = {
	(Integer) 0,
	(Integer) 2,
	MR_string_const("free", 4),
	MR_string_const("not_reached", 11)
};

static const struct mercury_data_inst__common_23_struct mercury_data_inst__common_23 = {
	(Integer) 5,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_11),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_18),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_20),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_13),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_7)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_inst__common_24_struct mercury_data_inst__common_24 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

static const struct mercury_data_inst__common_25_struct mercury_data_inst__common_25 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_6),
	MR_string_const("functor", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_inst__type_ctor_functors_uniqueness_0_struct mercury_data_inst__type_ctor_functors_uniqueness_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_0)
};

static const struct mercury_data_inst__type_ctor_layout_uniqueness_0_struct mercury_data_inst__type_ctor_layout_uniqueness_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_0)
};

static const struct mercury_data_inst__type_ctor_functors_pred_inst_info_0_struct mercury_data_inst__type_ctor_functors_pred_inst_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_4)
};

static const struct mercury_data_inst__type_ctor_layout_pred_inst_info_0_struct mercury_data_inst__type_ctor_layout_pred_inst_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_inst__type_ctor_functors_inst_0_struct mercury_data_inst__type_ctor_functors_inst_0 = {
	(Integer) 0,
	(Integer) 9,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_21)
};

static const struct mercury_data_inst__type_ctor_layout_inst_0_struct mercury_data_inst__type_ctor_layout_inst_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_22),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_9),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_16),
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_inst__common_23)
};

static const struct mercury_data_inst__type_ctor_functors_bound_inst_0_struct mercury_data_inst__type_ctor_functors_bound_inst_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_inst__common_25)
};

static const struct mercury_data_inst__type_ctor_layout_bound_inst_0_struct mercury_data_inst__type_ctor_layout_bound_inst_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_inst__common_25),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(inst_module0)
	init_entry(mercury____Index___inst__bound_inst_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___inst__bound_inst_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___inst__bound_inst_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(inst_module1)
	init_entry(mercury____Index___inst__pred_inst_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___inst__pred_inst_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___inst__pred_inst_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__term_1_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);
Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury____Unify___prog_data__inst_name_0_0);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);

BEGIN_MODULE(inst_module2)
	init_entry(mercury____Unify___inst__inst_0_0);
	init_label(mercury____Unify___inst__inst_0_0_i1020);
	init_label(mercury____Unify___inst__inst_0_0_i5);
	init_label(mercury____Unify___inst__inst_0_0_i1021);
	init_label(mercury____Unify___inst__inst_0_0_i1022);
	init_label(mercury____Unify___inst__inst_0_0_i14);
	init_label(mercury____Unify___inst__inst_0_0_i15);
	init_label(mercury____Unify___inst__inst_0_0_i19);
	init_label(mercury____Unify___inst__inst_0_0_i23);
	init_label(mercury____Unify___inst__inst_0_0_i27);
	init_label(mercury____Unify___inst__inst_0_0_i31);
	init_label(mercury____Unify___inst__inst_0_0_i33);
	init_label(mercury____Unify___inst__inst_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___inst__inst_0_0);
	MR_incr_sp_push_msg(3, "inst:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___inst__inst_0_0_i1020) AND
		LABEL(mercury____Unify___inst__inst_0_0_i1021) AND
		LABEL(mercury____Unify___inst__inst_0_0_i1022) AND
		LABEL(mercury____Unify___inst__inst_0_0_i14));
Define_label(mercury____Unify___inst__inst_0_0_i1020);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___inst__inst_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___inst__inst_0_0_i1021);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((r3 != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___inst__inst_0_0_i1022);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___term__term_1_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Unify___inst__inst_0_0_i15) AND
		LABEL(mercury____Unify___inst__inst_0_0_i19) AND
		LABEL(mercury____Unify___inst__inst_0_0_i23) AND
		LABEL(mercury____Unify___inst__inst_0_0_i27) AND
		LABEL(mercury____Unify___inst__inst_0_0_i31));
Define_label(mercury____Unify___inst__inst_0_0_i15);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	if ((MR_const_field(MR_mktag(3), r1, (Integer) 1) != MR_const_field(MR_mktag(3), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_bound_inst_0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	if ((MR_const_field(MR_mktag(3), r1, (Integer) 1) != MR_const_field(MR_mktag(3), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_pred_inst_info_0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i23);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___term__var_1_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i27);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___prog_data__inst_name_0_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i31);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury____Unify___inst__inst_0_0_i33,
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i33);
	update_prof_current_proc(LABEL(mercury____Unify___inst__inst_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___inst__inst_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___inst__inst_0_0));
Define_label(mercury____Unify___inst__inst_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(inst_module3)
	init_entry(mercury____Index___inst__inst_0_0);
	init_label(mercury____Index___inst__inst_0_0_i4);
	init_label(mercury____Index___inst__inst_0_0_i5);
	init_label(mercury____Index___inst__inst_0_0_i6);
	init_label(mercury____Index___inst__inst_0_0_i7);
	init_label(mercury____Index___inst__inst_0_0_i8);
	init_label(mercury____Index___inst__inst_0_0_i9);
	init_label(mercury____Index___inst__inst_0_0_i10);
	init_label(mercury____Index___inst__inst_0_0_i11);
	init_label(mercury____Index___inst__inst_0_0_i12);
	init_label(mercury____Index___inst__inst_0_0_i13);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___inst__inst_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___inst__inst_0_0_i4) AND
		LABEL(mercury____Index___inst__inst_0_0_i6) AND
		LABEL(mercury____Index___inst__inst_0_0_i7) AND
		LABEL(mercury____Index___inst__inst_0_0_i8));
Define_label(mercury____Index___inst__inst_0_0_i4);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Index___inst__inst_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i5);
	r1 = (Integer) 5;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i6);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Index___inst__inst_0_0_i9) AND
		LABEL(mercury____Index___inst__inst_0_0_i10) AND
		LABEL(mercury____Index___inst__inst_0_0_i11) AND
		LABEL(mercury____Index___inst__inst_0_0_i12) AND
		LABEL(mercury____Index___inst__inst_0_0_i13));
Define_label(mercury____Index___inst__inst_0_0_i9);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i10);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i11);
	r1 = (Integer) 6;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i12);
	r1 = (Integer) 7;
	proceed();
Define_label(mercury____Index___inst__inst_0_0_i13);
	r1 = (Integer) 8;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___term__term_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);
Declare_entry(mercury____Compare___term__var_1_0);
Declare_entry(mercury____Compare___prog_data__inst_name_0_0);
Declare_entry(mercury____Compare___prog_data__sym_name_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(inst_module4)
	init_entry(mercury____Compare___inst__inst_0_0);
	init_label(mercury____Compare___inst__inst_0_0_i2);
	init_label(mercury____Compare___inst__inst_0_0_i3);
	init_label(mercury____Compare___inst__inst_0_0_i4);
	init_label(mercury____Compare___inst__inst_0_0_i5);
	init_label(mercury____Compare___inst__inst_0_0_i10);
	init_label(mercury____Compare___inst__inst_0_0_i11);
	init_label(mercury____Compare___inst__inst_0_0_i14);
	init_label(mercury____Compare___inst__inst_0_0_i17);
	init_label(mercury____Compare___inst__inst_0_0_i20);
	init_label(mercury____Compare___inst__inst_0_0_i21);
	init_label(mercury____Compare___inst__inst_0_0_i24);
	init_label(mercury____Compare___inst__inst_0_0_i29);
	init_label(mercury____Compare___inst__inst_0_0_i32);
	init_label(mercury____Compare___inst__inst_0_0_i37);
	init_label(mercury____Compare___inst__inst_0_0_i40);
	init_label(mercury____Compare___inst__inst_0_0_i43);
	init_label(mercury____Compare___inst__inst_0_0_i46);
	init_label(mercury____Compare___inst__inst_0_0_i7);
	init_label(mercury____Compare___inst__inst_0_0_i54);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___inst__inst_0_0);
	MR_incr_sp_push_msg(4, "inst:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury____Index___inst__inst_0_0),
		mercury____Compare___inst__inst_0_0_i2,
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___inst__inst_0_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury____Index___inst__inst_0_0),
		mercury____Compare___inst__inst_0_0_i3,
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___inst__inst_0_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___inst__inst_0_0_i4);
	if (((Integer) MR_stackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i5);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___inst__inst_0_0_i5);
	r1 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___inst__inst_0_0_i10) AND
		LABEL(mercury____Compare___inst__inst_0_0_i14) AND
		LABEL(mercury____Compare___inst__inst_0_0_i17) AND
		LABEL(mercury____Compare___inst__inst_0_0_i20));
Define_label(mercury____Compare___inst__inst_0_0_i10);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___inst__inst_0_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___inst__inst_0_0_i14);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i17);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___term__term_1_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
	}
Define_label(mercury____Compare___inst__inst_0_0_i20);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Compare___inst__inst_0_0_i21) AND
		LABEL(mercury____Compare___inst__inst_0_0_i29) AND
		LABEL(mercury____Compare___inst__inst_0_0_i37) AND
		LABEL(mercury____Compare___inst__inst_0_0_i40) AND
		LABEL(mercury____Compare___inst__inst_0_0_i43));
Define_label(mercury____Compare___inst__inst_0_0_i21);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___inst__inst_0_0_i24,
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i24);
	update_prof_current_proc(LABEL(mercury____Compare___inst__inst_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i54);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_bound_inst_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i29);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___inst__inst_0_0_i32,
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i32);
	update_prof_current_proc(LABEL(mercury____Compare___inst__inst_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i54);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_pred_inst_info_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i37);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___term__var_1_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
	}
Define_label(mercury____Compare___inst__inst_0_0_i40);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___prog_data__inst_name_0_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i43);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury____Compare___prog_data__sym_name_0_0),
		mercury____Compare___inst__inst_0_0_i46,
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Compare___inst__inst_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__inst_0_0_i54);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i7);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___inst__inst_0_0));
Define_label(mercury____Compare___inst__inst_0_0_i54);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(inst_module5)
	init_entry(mercury____Unify___inst__uniqueness_0_0);
	init_label(mercury____Unify___inst__uniqueness_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___inst__uniqueness_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___inst__uniqueness_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___inst__uniqueness_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(inst_module6)
	init_entry(mercury____Index___inst__uniqueness_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___inst__uniqueness_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(inst_module7)
	init_entry(mercury____Compare___inst__uniqueness_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___inst__uniqueness_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___inst__uniqueness_0_0));
END_MODULE


BEGIN_MODULE(inst_module8)
	init_entry(mercury____Unify___inst__pred_inst_info_0_0);
	init_label(mercury____Unify___inst__pred_inst_info_0_0_i2);
	init_label(mercury____Unify___inst__pred_inst_info_0_0_i1004);
	init_label(mercury____Unify___inst__pred_inst_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___inst__pred_inst_info_0_0);
	MR_incr_sp_push_msg(3, "inst:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___inst__pred_inst_info_0_0_i1004);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___inst__pred_inst_info_0_0_i2,
		ENTRY(mercury____Unify___inst__pred_inst_info_0_0));
Define_label(mercury____Unify___inst__pred_inst_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___inst__pred_inst_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___inst__pred_inst_info_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___inst__pred_inst_info_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___inst__pred_inst_info_0_0_i1004);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___inst__pred_inst_info_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(inst_module9)
	init_entry(mercury____Index___inst__pred_inst_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___inst__pred_inst_info_0_0);
	tailcall(STATIC(mercury____Index___inst__pred_inst_info_0__ua0_2_0),
		ENTRY(mercury____Index___inst__pred_inst_info_0_0));
END_MODULE


BEGIN_MODULE(inst_module10)
	init_entry(mercury____Compare___inst__pred_inst_info_0_0);
	init_label(mercury____Compare___inst__pred_inst_info_0_0_i3);
	init_label(mercury____Compare___inst__pred_inst_info_0_0_i7);
	init_label(mercury____Compare___inst__pred_inst_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___inst__pred_inst_info_0_0);
	MR_incr_sp_push_msg(5, "inst:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___inst__pred_inst_info_0_0_i3,
		ENTRY(mercury____Compare___inst__pred_inst_info_0_0));
Define_label(mercury____Compare___inst__pred_inst_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___inst__pred_inst_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__pred_inst_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___inst__pred_inst_info_0_0_i7,
		ENTRY(mercury____Compare___inst__pred_inst_info_0_0));
Define_label(mercury____Compare___inst__pred_inst_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___inst__pred_inst_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__pred_inst_info_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___inst__pred_inst_info_0_0));
Define_label(mercury____Compare___inst__pred_inst_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);

BEGIN_MODULE(inst_module11)
	init_entry(mercury____Unify___inst__bound_inst_0_0);
	init_label(mercury____Unify___inst__bound_inst_0_0_i2);
	init_label(mercury____Unify___inst__bound_inst_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___inst__bound_inst_0_0);
	MR_incr_sp_push_msg(3, "inst:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___inst__bound_inst_0_0_i2,
		ENTRY(mercury____Unify___inst__bound_inst_0_0));
Define_label(mercury____Unify___inst__bound_inst_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___inst__bound_inst_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___inst__bound_inst_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___inst__bound_inst_0_0));
Define_label(mercury____Unify___inst__bound_inst_0_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(inst_module12)
	init_entry(mercury____Index___inst__bound_inst_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___inst__bound_inst_0_0);
	tailcall(STATIC(mercury____Index___inst__bound_inst_0__ua0_2_0),
		ENTRY(mercury____Index___inst__bound_inst_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);

BEGIN_MODULE(inst_module13)
	init_entry(mercury____Compare___inst__bound_inst_0_0);
	init_label(mercury____Compare___inst__bound_inst_0_0_i3);
	init_label(mercury____Compare___inst__bound_inst_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___inst__bound_inst_0_0);
	MR_incr_sp_push_msg(3, "inst:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___inst__bound_inst_0_0_i3,
		ENTRY(mercury____Compare___inst__bound_inst_0_0));
Define_label(mercury____Compare___inst__bound_inst_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___inst__bound_inst_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___inst__bound_inst_0_0_i7);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___inst__bound_inst_0_0));
Define_label(mercury____Compare___inst__bound_inst_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__inst_maybe_bunch_0(void)
{
	inst_module0();
	inst_module1();
	inst_module2();
	inst_module3();
	inst_module4();
	inst_module5();
	inst_module6();
	inst_module7();
	inst_module8();
	inst_module9();
	inst_module10();
	inst_module11();
	inst_module12();
	inst_module13();
}

#endif

void mercury__inst__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__inst__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__inst_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_inst__type_ctor_info_bound_inst_0,
			inst__bound_inst_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_inst__type_ctor_info_inst_0,
			inst__inst_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_inst__type_ctor_info_pred_inst_info_0,
			inst__pred_inst_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_inst__type_ctor_info_uniqueness_0,
			inst__uniqueness_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
