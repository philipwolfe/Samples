/*
** Automatically generated from `instmap.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__instmap__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__instmap__unify_instmapping_delta_2__ua0_8_0);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i5);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i8);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i11);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i10);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i14);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i7);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i4);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i19);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i21);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i18);
Declare_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i3);
Declare_static(mercury__instmap__unify_instmap_delta__ua0_7_0);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i3);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i5);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i6);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i7);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i8);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i9);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i10);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i11);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i12);
Declare_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i13);
Declare_static(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i4);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i5);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i6);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i9);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i3);
Declare_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i10);
Declare_static(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i4);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i7);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i5);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i3);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i11);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i2);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i12);
Declare_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i13);
Define_extern_entry(mercury__instmap__init_reachable_1_0);
Declare_label(mercury__instmap__init_reachable_1_0_i2);
Define_extern_entry(mercury__instmap__init_unreachable_1_0);
Define_extern_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
Declare_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
Define_extern_entry(mercury__instmap__is_reachable_1_0);
Declare_label(mercury__instmap__is_reachable_1_0_i1);
Define_extern_entry(mercury__instmap__is_unreachable_1_0);
Declare_label(mercury__instmap__is_unreachable_1_0_i1);
Define_extern_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
Declare_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
Define_extern_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
Declare_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
Define_extern_entry(mercury__instmap__from_assoc_list_2_0);
Declare_label(mercury__instmap__from_assoc_list_2_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
Declare_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_from_mode_list_4_0);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_4_0_i2);
Define_extern_entry(mercury__instmap__vars_2_0);
Declare_label(mercury__instmap__vars_2_0_i2);
Define_extern_entry(mercury__instmap__vars_list_2_0);
Declare_label(mercury__instmap__vars_list_2_0_i3);
Define_extern_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
Declare_label(mercury__instmap__instmap_delta_changed_vars_2_0_i3);
Declare_label(mercury__instmap__instmap_delta_changed_vars_2_0_i5);
Define_extern_entry(mercury__instmap__instmap_changed_vars_4_0);
Declare_label(mercury__instmap__instmap_changed_vars_4_0_i2);
Define_extern_entry(mercury__instmap__lookup_var_3_0);
Declare_label(mercury__instmap__lookup_var_3_0_i3);
Declare_label(mercury__instmap__lookup_var_3_0_i5);
Declare_label(mercury__instmap__lookup_var_3_0_i4);
Define_extern_entry(mercury__instmap__instmap_delta_search_var_3_0);
Declare_label(mercury__instmap__instmap_delta_search_var_3_0_i3);
Define_extern_entry(mercury__instmap__lookup_vars_3_0);
Declare_label(mercury__instmap__lookup_vars_3_0_i4);
Declare_label(mercury__instmap__lookup_vars_3_0_i5);
Declare_label(mercury__instmap__lookup_vars_3_0_i3);
Define_extern_entry(mercury__instmap__instmap_delta_insert_4_0);
Declare_label(mercury__instmap__instmap_delta_insert_4_0_i1003);
Declare_label(mercury__instmap__instmap_delta_insert_4_0_i4);
Declare_label(mercury__instmap__instmap_delta_insert_4_0_i6);
Define_extern_entry(mercury__instmap__set_4_0);
Declare_label(mercury__instmap__set_4_0_i3);
Declare_label(mercury__instmap__set_4_0_i4);
Define_extern_entry(mercury__instmap__set_vars_4_0);
Declare_label(mercury__instmap__set_vars_4_0_i1004);
Declare_label(mercury__instmap__set_vars_4_0_i1001);
Declare_label(mercury__instmap__set_vars_4_0_i3);
Declare_label(mercury__instmap__set_vars_4_0_i9);
Declare_label(mercury__instmap__set_vars_4_0_i2);
Define_extern_entry(mercury__instmap__instmap_delta_set_4_0);
Declare_label(mercury__instmap__instmap_delta_set_4_0_i1003);
Declare_label(mercury__instmap__instmap_delta_set_4_0_i4);
Declare_label(mercury__instmap__instmap_delta_set_4_0_i6);
Define_extern_entry(mercury__instmap__instmap_delta_bind_var_to_functor_8_0);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i3);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i4);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i6);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i5);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i8);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i9);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i10);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i11);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i13);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i12);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i15);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i16);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i21);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i23);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i25);
Declare_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i18);
Define_extern_entry(mercury__instmap__bind_var_to_functor_7_0);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i2);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i3);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i4);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i5);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i7);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i6);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i9);
Declare_label(mercury__instmap__bind_var_to_functor_7_0_i11);
Define_extern_entry(mercury__instmap__pre_lambda_update_5_0);
Declare_label(mercury__instmap__pre_lambda_update_5_0_i2);
Declare_label(mercury__instmap__pre_lambda_update_5_0_i3);
Declare_label(mercury__instmap__pre_lambda_update_5_0_i4);
Define_extern_entry(mercury__instmap__compute_instmap_delta_4_0);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i3);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i5);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i6);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i7);
Declare_label(mercury__instmap__compute_instmap_delta_4_0_i8);
Define_extern_entry(mercury__instmap__apply_instmap_delta_3_0);
Declare_label(mercury__instmap__apply_instmap_delta_3_0_i3);
Declare_label(mercury__instmap__apply_instmap_delta_3_0_i5);
Declare_label(mercury__instmap__apply_instmap_delta_3_0_i6);
Define_extern_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
Declare_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i3);
Declare_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i5);
Declare_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
Define_extern_entry(mercury__instmap__merge_5_0);
Declare_label(mercury__instmap__merge_5_0_i2);
Declare_label(mercury__instmap__merge_5_0_i3);
Declare_label(mercury__instmap__merge_5_0_i4);
Declare_label(mercury__instmap__merge_5_0_i1000);
Declare_label(mercury__instmap__merge_5_0_i5);
Declare_label(mercury__instmap__merge_5_0_i9);
Declare_label(mercury__instmap__merge_5_0_i10);
Declare_label(mercury__instmap__merge_5_0_i11);
Declare_label(mercury__instmap__merge_5_0_i14);
Declare_label(mercury__instmap__merge_5_0_i12);
Define_extern_entry(mercury__instmap__unify_4_0);
Declare_label(mercury__instmap__unify_4_0_i6);
Declare_label(mercury__instmap__unify_4_0_i1020);
Declare_label(mercury__instmap__unify_4_0_i4);
Declare_label(mercury__instmap__unify_4_0_i9);
Declare_label(mercury__instmap__unify_4_0_i3);
Declare_label(mercury__instmap__unify_4_0_i11);
Declare_label(mercury__instmap__unify_4_0_i18);
Declare_label(mercury__instmap__unify_4_0_i19);
Declare_label(mercury__instmap__unify_4_0_i20);
Declare_label(mercury__instmap__unify_4_0_i21);
Declare_label(mercury__instmap__unify_4_0_i1033);
Declare_label(mercury__instmap__unify_4_0_i22);
Declare_label(mercury__instmap__unify_4_0_i15);
Define_extern_entry(mercury__instmap__restrict_3_0);
Declare_label(mercury__instmap__restrict_3_0_i3);
Declare_label(mercury__instmap__restrict_3_0_i4);
Define_extern_entry(mercury__instmap__instmap_delta_restrict_3_0);
Declare_label(mercury__instmap__instmap_delta_restrict_3_0_i3);
Declare_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
Define_extern_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
Declare_label(mercury__instmap__instmap_delta_delete_vars_3_0_i3);
Declare_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
Define_extern_entry(mercury__instmap__no_output_vars_4_0);
Declare_label(mercury__instmap__no_output_vars_4_0_i4);
Declare_label(mercury__instmap__no_output_vars_4_0_i2);
Define_extern_entry(mercury__instmap__merge_instmap_delta_7_0);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i3);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i5);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i6);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i7);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i8);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i9);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i10);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i11);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i12);
Declare_label(mercury__instmap__merge_instmap_delta_7_0_i13);
Define_extern_entry(mercury__instmap__merge_instmap_deltas_6_0);
Declare_label(mercury__instmap__merge_instmap_deltas_6_0_i3);
Define_extern_entry(mercury__instmap__unify_instmap_delta_7_0);
Define_extern_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i3);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
Declare_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
Define_extern_entry(mercury__instmap__apply_sub_4_0);
Define_extern_entry(mercury__instmap__to_assoc_list_2_0);
Declare_label(mercury__instmap__to_assoc_list_2_0_i3);
Define_extern_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
Declare_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i3);
Declare_static(mercury__instmap__instmap_delta_from_mode_list_2_5_0);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i1004);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i3);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i9);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i12);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i10);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i15);
Declare_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i8);
Declare_static(mercury__instmap__changed_vars_2_5_0);
Declare_label(mercury__instmap__changed_vars_2_5_0_i3);
Declare_label(mercury__instmap__changed_vars_2_5_0_i5);
Declare_label(mercury__instmap__changed_vars_2_5_0_i8);
Declare_label(mercury__instmap__changed_vars_2_5_0_i6);
Declare_static(mercury__instmap__get_reachable_instmaps_2_0);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i1002);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i6);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i4);
Declare_label(mercury__instmap__get_reachable_instmaps_2_0_i3);
Declare_static(mercury__instmap__merge_2_7_0);
Declare_label(mercury__instmap__merge_2_7_0_i4);
Declare_label(mercury__instmap__merge_2_7_0_i5);
Declare_label(mercury__instmap__merge_2_7_0_i6);
Declare_label(mercury__instmap__merge_2_7_0_i9);
Declare_label(mercury__instmap__merge_2_7_0_i3);
Declare_static(mercury__instmap__merge_var_7_0);
Declare_label(mercury__instmap__merge_var_7_0_i4);
Declare_label(mercury__instmap__merge_var_7_0_i5);
Declare_label(mercury__instmap__merge_var_7_0_i8);
Declare_label(mercury__instmap__merge_var_7_0_i6);
Declare_label(mercury__instmap__merge_var_7_0_i3);
Declare_static(mercury__instmap__merge_instmap_deltas_7_0);
Declare_label(mercury__instmap__merge_instmap_deltas_7_0_i1001);
Declare_label(mercury__instmap__merge_instmap_deltas_7_0_i4);
Declare_label(mercury__instmap__merge_instmap_deltas_7_0_i3);
Declare_static(mercury__instmap__unify_2_8_0);
Declare_label(mercury__instmap__unify_2_8_0_i3);
Declare_label(mercury__instmap__unify_2_8_0_i4);
Declare_label(mercury__instmap__unify_2_8_0_i5);
Declare_label(mercury__instmap__unify_2_8_0_i6);
Declare_label(mercury__instmap__unify_2_8_0_i9);
Declare_static(mercury__instmap__unify_var_10_0);
Declare_label(mercury__instmap__unify_var_10_0_i1003);
Declare_label(mercury__instmap__unify_var_10_0_i5);
Declare_label(mercury__instmap__unify_var_10_0_i7);
Declare_label(mercury__instmap__unify_var_10_0_i9);
Declare_label(mercury__instmap__unify_var_10_0_i8);
Declare_label(mercury__instmap__unify_var_10_0_i4);
Declare_label(mercury__instmap__unify_var_10_0_i3);
Declare_static(mercury__instmap__compute_instmap_delta_2_4_0);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i7);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i12);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i15);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i13);
Declare_label(mercury__instmap__compute_instmap_delta_2_4_0_i3);
Declare_static(mercury__instmap__no_output_vars_2_4_0);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i1003);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i4);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i6);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i5);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i8);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i9);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i2);
Declare_label(mercury__instmap__no_output_vars_2_4_0_i1);
Declare_static(mercury__instmap__merge_instmapping_delta_2_8_0);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i1004);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i5);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i4);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i7);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i8);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i10);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i9);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i12);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i16);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i15);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i19);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i20);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i21);
Declare_label(mercury__instmap__merge_instmapping_delta_2_8_0_i3);
Declare_static(mercury__instmap__instmap_delta_apply_sub_2_5_0);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1003);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i4);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i8);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
Declare_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i3);
Define_extern_entry(mercury____Unify___instmap__instmap_0_0);
Declare_label(mercury____Unify___instmap__instmap_0_0_i3);
Declare_label(mercury____Unify___instmap__instmap_0_0_i1);
Define_extern_entry(mercury____Index___instmap__instmap_0_0);
Declare_label(mercury____Index___instmap__instmap_0_0_i3);
Define_extern_entry(mercury____Compare___instmap__instmap_0_0);
Declare_label(mercury____Compare___instmap__instmap_0_0_i3);
Declare_label(mercury____Compare___instmap__instmap_0_0_i2);
Declare_label(mercury____Compare___instmap__instmap_0_0_i5);
Declare_label(mercury____Compare___instmap__instmap_0_0_i4);
Declare_label(mercury____Compare___instmap__instmap_0_0_i6);
Declare_label(mercury____Compare___instmap__instmap_0_0_i7);
Declare_label(mercury____Compare___instmap__instmap_0_0_i11);
Declare_label(mercury____Compare___instmap__instmap_0_0_i1014);
Define_extern_entry(mercury____Unify___instmap__instmap_delta_0_0);
Define_extern_entry(mercury____Index___instmap__instmap_delta_0_0);
Declare_label(mercury____Index___instmap__instmap_delta_0_0_i3);
Define_extern_entry(mercury____Compare___instmap__instmap_delta_0_0);
Declare_static(mercury____Unify___instmap__instmapping_0_0);
Declare_static(mercury____Index___instmap__instmapping_0_0);
Declare_static(mercury____Compare___instmap__instmapping_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmap_0;

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmap_delta_0;

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmapping_0;

static const struct mercury_data_instmap__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_instmap__common_0;

static const struct mercury_data_instmap__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_instmap__common_1;

static const struct mercury_data_instmap__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_instmap__common_2;

static const struct mercury_data_instmap__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_instmap__common_3;

static const struct mercury_data_instmap__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_instmap__common_4;

static const struct mercury_data_instmap__common_5_struct {
	Word * f1;
}  mercury_data_instmap__common_5;

static const struct mercury_data_instmap__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_instmap__common_6;

static const struct mercury_data_instmap__common_7_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_instmap__common_7;

static const struct mercury_data_instmap__common_8_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_instmap__common_8;

static const struct mercury_data_instmap__common_9_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_instmap__common_9;

static const struct mercury_data_instmap__type_ctor_functors_instmapping_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_instmap__type_ctor_functors_instmapping_0;

static const struct mercury_data_instmap__type_ctor_layout_instmapping_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_instmap__type_ctor_layout_instmapping_0;

static const struct mercury_data_instmap__type_ctor_functors_instmap_delta_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_instmap__type_ctor_functors_instmap_delta_0;

static const struct mercury_data_instmap__type_ctor_layout_instmap_delta_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_instmap__type_ctor_layout_instmap_delta_0;

static const struct mercury_data_instmap__type_ctor_functors_instmap_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_instmap__type_ctor_functors_instmap_0;

static const struct mercury_data_instmap__type_ctor_layout_instmap_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_instmap__type_ctor_layout_instmap_0;

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmap_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___instmap__instmap_0_0),
	ENTRY(mercury____Index___instmap__instmap_0_0),
	ENTRY(mercury____Compare___instmap__instmap_0_0),
	(Integer) 2,
	(Word *) &mercury_data_instmap__type_ctor_functors_instmap_0,
	(Word *) &mercury_data_instmap__type_ctor_layout_instmap_0,
	MR_string_const("instmap", 7),
	MR_string_const("instmap", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmap_delta_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___instmap__instmap_delta_0_0),
	ENTRY(mercury____Index___instmap__instmap_delta_0_0),
	ENTRY(mercury____Compare___instmap__instmap_delta_0_0),
	(Integer) 6,
	(Word *) &mercury_data_instmap__type_ctor_functors_instmap_delta_0,
	(Word *) &mercury_data_instmap__type_ctor_layout_instmap_delta_0,
	MR_string_const("instmap", 7),
	MR_string_const("instmap_delta", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_instmap__type_ctor_info_instmapping_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___instmap__instmapping_0_0),
	STATIC(mercury____Index___instmap__instmapping_0_0),
	STATIC(mercury____Compare___instmap__instmapping_0_0),
	(Integer) 6,
	(Word *) &mercury_data_instmap__type_ctor_functors_instmapping_0,
	(Word *) &mercury_data_instmap__type_ctor_layout_instmapping_0,
	MR_string_const("instmap", 7),
	MR_string_const("instmapping", 11),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_instmap__common_0_struct mercury_data_instmap__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_instmap__common_1_struct mercury_data_instmap__common_1 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_instmap__common_2_struct mercury_data_instmap__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_inst__type_ctor_info_inst_0;
static const struct mercury_data_instmap__common_3_struct mercury_data_instmap__common_3 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0),
	(Word *) &mercury_data_inst__type_ctor_info_inst_0
};

static const struct mercury_data_instmap__common_4_struct mercury_data_instmap__common_4 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_3)
};

static const struct mercury_data_instmap__common_5_struct mercury_data_instmap__common_5 = {
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0
};

static const struct mercury_data_instmap__common_6_struct mercury_data_instmap__common_6 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_5)
};

static const struct mercury_data_instmap__common_7_struct mercury_data_instmap__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_3),
	MR_string_const("reachable", 9),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_instmap__common_8_struct mercury_data_instmap__common_8 = {
	(Integer) 0,
	MR_string_const("unreachable", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_instmap__common_9_struct mercury_data_instmap__common_9 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("unreachable", 11)
};

static const struct mercury_data_instmap__type_ctor_functors_instmapping_0_struct mercury_data_instmap__type_ctor_functors_instmapping_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_3)
};

static const struct mercury_data_instmap__type_ctor_layout_instmapping_0_struct mercury_data_instmap__type_ctor_layout_instmapping_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_4),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_4),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_4),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_4)
};

static const struct mercury_data_instmap__type_ctor_functors_instmap_delta_0_struct mercury_data_instmap__type_ctor_functors_instmap_delta_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_5)
};

static const struct mercury_data_instmap__type_ctor_layout_instmap_delta_0_struct mercury_data_instmap__type_ctor_layout_instmap_delta_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_6),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_instmap__common_6)
};

static const struct mercury_data_instmap__type_ctor_functors_instmap_0_struct mercury_data_instmap__type_ctor_functors_instmap_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_8)
};

static const struct mercury_data_instmap__type_ctor_layout_instmap_0_struct mercury_data_instmap__type_ctor_layout_instmap_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_9),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_instmap__common_7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__inst_util__abstractly_unify_inst_8_0);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(instmap_module0)
	init_entry(mercury__instmap__unify_instmapping_delta_2__ua0_8_0);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i5);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i8);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i11);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i10);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i14);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i7);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i4);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i19);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i21);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i18);
	init_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'unify_instmapping_delta_2__ua0'/8 in mode 0 */
Define_static(mercury__instmap__unify_instmapping_delta_2__ua0_8_0);
	MR_incr_sp_push_msg(9, "instmap:unify_instmapping_delta_2__ua0/8");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i5,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i4);
	MR_stackvar(7) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i8,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i7);
	r1 = (Integer) 0;
	r3 = r2;
	r2 = MR_stackvar(7);
	r4 = (Integer) 1;
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__inst_util__abstractly_unify_inst_8_0),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i11,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i10);
	r5 = r2;
	MR_stackvar(8) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i14,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i10);
	r1 = (Word) MR_string_const("unify_instmapping_delta_2: unexpected error", 43);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i14,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i14);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = r1;
	r1 = MR_stackvar(6);
	r5 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i7);
	MR_stackvar(8) = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i21,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i19,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i19);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i18);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	MR_stackvar(8) = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i21,
		STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i21);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = r1;
	r1 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i18);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i1005);
Define_label(mercury__instmap__unify_instmapping_delta_2__ua0_8_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__set__sorted_list_to_set_2_0);
Declare_entry(mercury__set__insert_list_3_0);
Declare_entry(mercury__set__intersect_3_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(instmap_module1)
	init_entry(mercury__instmap__unify_instmap_delta__ua0_7_0);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i3);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i5);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i6);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i7);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i8);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i9);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i10);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i11);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i12);
	init_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i13);
BEGIN_CODE

/* code for predicate 'unify_instmap_delta__ua0'/7 in mode 0 */
Define_static(mercury__instmap__unify_instmap_delta__ua0_7_0);
	MR_incr_sp_push_msg(6, "instmap:unify_instmap_delta__ua0/7");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0_i5);
	r1 = r2;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i5);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r3;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i6,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i7,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__sorted_list_to_set_2_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i8,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i9,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i10,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i11,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i12,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__instmap__unify_instmapping_delta_2__ua0_8_0),
		mercury__instmap__unify_instmap_delta__ua0_7_0_i13,
		STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0));
Define_label(mercury__instmap__unify_instmap_delta__ua0_7_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__unify_instmap_delta__ua0_7_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__unify_instmap_delta__ua0_7_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(instmap_module2)
	init_entry(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i4);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i5);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i6);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i9);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i3);
	init_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i10);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__unify_2__782__3'/10 in mode 0 */
Define_static(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0);
	MR_incr_sp_push_msg(6, "instmap:DeforestationIn__pred__unify_2__782__3/10");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i3);
	MR_stackvar(3) = r5;
	r5 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_stackvar(4) = r5;
	r6 = MR_const_field(MR_mktag(1), r6, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	localcall(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0,
		LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i4),
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r3;
	r2 = MR_stackvar(4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__instmap__unify_var_10_0),
		mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i5,
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	if (((Integer) r4 != (Integer) 1))
		GOTO_LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i6);
	r5 = MR_stackvar(4);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(1), (Integer) 2, mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0, "origin_lost_in_value_number");
	r4 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r5;
	r5 = r2;
	MR_field(MR_mktag(1), MR_stackvar(4), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_field(MR_mktag(1), MR_stackvar(4), (Integer) 1) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i9,
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	}
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	r4 = MR_stackvar(4);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(4) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i9,
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	}
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i10,
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i3);
	r2 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(1) = r4;
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i10,
		STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
Define_label(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__inst_match__inst_matches_final_3_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(instmap_module3)
	init_entry(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i4);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i7);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i5);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i3);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i11);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i2);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i12);
	init_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i13);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__changed_vars_2__406__1'/8 in mode 0 */
Define_static(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0);
	MR_incr_sp_push_msg(8, "instmap:DeforestationIn__pred__changed_vars_2__406__1/8");
	MR_stackvar(8) = (Word) MR_succip;
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i3);
	MR_stackvar(4) = r4;
	r4 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(6) = r4;
	r5 = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	localcall(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0,
		LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i4),
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__inst_match__inst_matches_final_3_0),
		mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i7,
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_stackvar(3) = MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i2);
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i11,
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i3);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i11,
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i2);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i12,
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i13,
		STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
Define_label(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module4)
	init_entry(mercury__instmap__init_reachable_1_0);
	init_label(mercury__instmap__init_reachable_1_0_i2);
BEGIN_CODE

/* code for predicate 'init_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__init_reachable_1_0);
	MR_incr_sp_push_msg(1, "instmap:init_reachable/1");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__init_reachable_1_0_i2,
		ENTRY(mercury__instmap__init_reachable_1_0));
Define_label(mercury__instmap__init_reachable_1_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__init_reachable_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__init_reachable_1_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module5)
	init_entry(mercury__instmap__init_unreachable_1_0);
BEGIN_CODE

/* code for predicate 'init_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__init_unreachable_1_0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module6)
	init_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
	init_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_delta_init_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_init_reachable_1_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_init_reachable/1");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__instmap_delta_init_reachable_1_0_i2,
		ENTRY(mercury__instmap__instmap_delta_init_reachable_1_0));
Define_label(mercury__instmap__instmap_delta_init_reachable_1_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_init_reachable_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_init_reachable_1_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module7)
	init_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
BEGIN_CODE

/* code for predicate 'instmap_delta_init_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_init_unreachable_1_0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module8)
	init_entry(mercury__instmap__is_reachable_1_0);
	init_label(mercury__instmap__is_reachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'is_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__is_reachable_1_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__is_reachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__is_reachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module9)
	init_entry(mercury__instmap__is_unreachable_1_0);
	init_label(mercury__instmap__is_unreachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'is_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__is_unreachable_1_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__is_unreachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__is_unreachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module10)
	init_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
	init_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap_delta_is_reachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__instmap_delta_is_reachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module11)
	init_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	init_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
BEGIN_CODE

/* code for predicate 'instmap_delta_is_unreachable'/1 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__instmap_delta_is_unreachable_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__map__from_assoc_list_2_0);

BEGIN_MODULE(instmap_module12)
	init_entry(mercury__instmap__from_assoc_list_2_0);
	init_label(mercury__instmap__from_assoc_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'from_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__from_assoc_list_2_0);
	MR_incr_sp_push_msg(1, "instmap:from_assoc_list/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__instmap__from_assoc_list_2_0_i2,
		ENTRY(mercury__instmap__from_assoc_list_2_0));
Define_label(mercury__instmap__from_assoc_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__from_assoc_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__from_assoc_list_2_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module13)
	init_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
	init_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_delta_from_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_from_assoc_list_2_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_from_assoc_list/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__instmap__instmap_delta_from_assoc_list_2_0_i2,
		ENTRY(mercury__instmap__instmap_delta_from_assoc_list_2_0));
Define_label(mercury__instmap__instmap_delta_from_assoc_list_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_assoc_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_from_assoc_list_2_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module14)
	init_entry(mercury__instmap__instmap_delta_from_mode_list_4_0);
	init_label(mercury__instmap__instmap_delta_from_mode_list_4_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_delta_from_mode_list'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_from_mode_list_4_0);
	MR_incr_sp_push_msg(4, "instmap:instmap_delta_from_mode_list/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__instmap_delta_from_mode_list_4_0_i2,
		ENTRY(mercury__instmap__instmap_delta_from_mode_list_4_0));
Define_label(mercury__instmap__instmap_delta_from_mode_list_4_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_mode_list_4_0));
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_from_mode_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__instmap__instmap_delta_from_mode_list_2_5_0),
		ENTRY(mercury__instmap__instmap_delta_from_mode_list_4_0));
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);

BEGIN_MODULE(instmap_module15)
	init_entry(mercury__instmap__vars_2_0);
	init_label(mercury__instmap__vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'vars'/2 in mode 0 */
Define_entry(mercury__instmap__vars_2_0);
	MR_incr_sp_push_msg(1, "instmap:vars/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__instmap__vars_list_2_0),
		mercury__instmap__vars_2_0_i2,
		ENTRY(mercury__instmap__vars_2_0));
Define_label(mercury__instmap__vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__vars_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		ENTRY(mercury__instmap__vars_2_0));
END_MODULE


BEGIN_MODULE(instmap_module16)
	init_entry(mercury__instmap__vars_list_2_0);
	init_label(mercury__instmap__vars_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'vars_list'/2 in mode 0 */
Define_entry(mercury__instmap__vars_list_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__vars_list_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__instmap__vars_list_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__instmap__vars_list_2_0));
END_MODULE


BEGIN_MODULE(instmap_module17)
	init_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
	init_label(mercury__instmap__instmap_delta_changed_vars_2_0_i3);
	init_label(mercury__instmap__instmap_delta_changed_vars_2_0_i5);
BEGIN_CODE

/* code for predicate 'instmap_delta_changed_vars'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_changed_vars/2");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_changed_vars_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__set__init_1_0),
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
Define_label(mercury__instmap__instmap_delta_changed_vars_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__instmap_delta_changed_vars_2_0_i5,
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
Define_label(mercury__instmap__instmap_delta_changed_vars_2_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_changed_vars_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__set__sorted_list_to_set_2_0),
		ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0));
END_MODULE


BEGIN_MODULE(instmap_module18)
	init_entry(mercury__instmap__instmap_changed_vars_4_0);
	init_label(mercury__instmap__instmap_changed_vars_4_0_i2);
BEGIN_CODE

/* code for predicate 'instmap_changed_vars'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_changed_vars_4_0);
	MR_incr_sp_push_msg(4, "instmap:instmap_changed_vars/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__instmap__vars_list_2_0),
		mercury__instmap__instmap_changed_vars_4_0_i2,
		ENTRY(mercury__instmap__instmap_changed_vars_4_0));
Define_label(mercury__instmap__instmap_changed_vars_4_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_changed_vars_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__instmap__changed_vars_2_5_0),
		ENTRY(mercury__instmap__instmap_changed_vars_4_0));
END_MODULE


BEGIN_MODULE(instmap_module19)
	init_entry(mercury__instmap__lookup_var_3_0);
	init_label(mercury__instmap__lookup_var_3_0_i3);
	init_label(mercury__instmap__lookup_var_3_0_i5);
	init_label(mercury__instmap__lookup_var_3_0_i4);
BEGIN_CODE

/* code for predicate 'lookup_var'/3 in mode 0 */
Define_entry(mercury__instmap__lookup_var_3_0);
	MR_incr_sp_push_msg(1, "instmap:lookup_var/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__lookup_var_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__lookup_var_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__lookup_var_3_0_i5,
		ENTRY(mercury__instmap__lookup_var_3_0));
Define_label(mercury__instmap__lookup_var_3_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__lookup_var_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__lookup_var_3_0_i4);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__lookup_var_3_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module20)
	init_entry(mercury__instmap__instmap_delta_search_var_3_0);
	init_label(mercury__instmap__instmap_delta_search_var_3_0_i3);
BEGIN_CODE

/* code for predicate 'instmap_delta_search_var'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_search_var_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_search_var_3_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r1 = TRUE;
	proceed();
Define_label(mercury__instmap__instmap_delta_search_var_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__instmap__instmap_delta_search_var_3_0));
END_MODULE


BEGIN_MODULE(instmap_module21)
	init_entry(mercury__instmap__lookup_vars_3_0);
	init_label(mercury__instmap__lookup_vars_3_0_i4);
	init_label(mercury__instmap__lookup_vars_3_0_i5);
	init_label(mercury__instmap__lookup_vars_3_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_vars'/3 in mode 0 */
Define_entry(mercury__instmap__lookup_vars_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__lookup_vars_3_0_i3);
	MR_incr_sp_push_msg(3, "instmap:lookup_vars/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r3 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__lookup_vars_3_0_i4,
		ENTRY(mercury__instmap__lookup_vars_3_0));
Define_label(mercury__instmap__lookup_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__lookup_vars_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__instmap__lookup_vars_3_0,
		LABEL(mercury__instmap__lookup_vars_3_0_i5),
		ENTRY(mercury__instmap__lookup_vars_3_0));
Define_label(mercury__instmap__lookup_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__lookup_vars_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__instmap__lookup_vars_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__lookup_vars_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module22)
	init_entry(mercury__instmap__instmap_delta_insert_4_0);
	init_label(mercury__instmap__instmap_delta_insert_4_0_i1003);
	init_label(mercury__instmap__instmap_delta_insert_4_0_i4);
	init_label(mercury__instmap__instmap_delta_insert_4_0_i6);
BEGIN_CODE

/* code for predicate 'instmap_delta_insert'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_insert_4_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_insert/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_insert_4_0_i1003);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_insert_4_0_i1003);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__instmap__instmap_delta_insert_4_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_insert_4_0_i4);
	r5 = r3;
	r3 = r4;
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__instmap_delta_insert_4_0_i6,
		ENTRY(mercury__instmap__instmap_delta_insert_4_0));
Define_label(mercury__instmap__instmap_delta_insert_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_insert_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_insert_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module23)
	init_entry(mercury__instmap__set_4_0);
	init_label(mercury__instmap__set_4_0_i3);
	init_label(mercury__instmap__set_4_0_i4);
BEGIN_CODE

/* code for predicate 'set'/4 in mode 0 */
Define_entry(mercury__instmap__set_4_0);
	MR_incr_sp_push_msg(1, "instmap:set/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__set_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__set_4_0_i3);
	r5 = r3;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__set_4_0_i4,
		ENTRY(mercury__instmap__set_4_0));
Define_label(mercury__instmap__set_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__set_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__set_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module24)
	init_entry(mercury__instmap__set_vars_4_0);
	init_label(mercury__instmap__set_vars_4_0_i1004);
	init_label(mercury__instmap__set_vars_4_0_i1001);
	init_label(mercury__instmap__set_vars_4_0_i3);
	init_label(mercury__instmap__set_vars_4_0_i9);
	init_label(mercury__instmap__set_vars_4_0_i2);
BEGIN_CODE

/* code for predicate 'set_vars'/4 in mode 0 */
Define_entry(mercury__instmap__set_vars_4_0);
	MR_incr_sp_push_msg(3, "instmap:set_vars/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__instmap__set_vars_4_0_i1004);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__set_vars_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__set_vars_4_0_i2);
Define_label(mercury__instmap__set_vars_4_0_i1001);
	r1 = (Word) MR_string_const("instmap__set_vars", 17);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__instmap__set_vars_4_0));
Define_label(mercury__instmap__set_vars_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__set_vars_4_0_i1001);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__instmap__set_4_0),
		mercury__instmap__set_vars_4_0_i9,
		ENTRY(mercury__instmap__set_vars_4_0));
Define_label(mercury__instmap__set_vars_4_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__set_vars_4_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__instmap__set_vars_4_0_i1004);
Define_label(mercury__instmap__set_vars_4_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module25)
	init_entry(mercury__instmap__instmap_delta_set_4_0);
	init_label(mercury__instmap__instmap_delta_set_4_0_i1003);
	init_label(mercury__instmap__instmap_delta_set_4_0_i4);
	init_label(mercury__instmap__instmap_delta_set_4_0_i6);
BEGIN_CODE

/* code for predicate 'instmap_delta_set'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_set_4_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_set/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_set_4_0_i1003);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_set_4_0_i1003);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__instmap__instmap_delta_set_4_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_set_4_0_i4);
	r5 = r3;
	r3 = r4;
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_set_4_0_i6,
		ENTRY(mercury__instmap__instmap_delta_set_4_0));
Define_label(mercury__instmap__instmap_delta_set_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_set_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_set_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__fn__type_util__cons_id_adjusted_arity_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_is_live_0;
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__inst_util__abstractly_unify_inst_functor_10_0);
Declare_entry(mercury____Unify___inst__inst_0_0);

BEGIN_MODULE(instmap_module26)
	init_entry(mercury__instmap__instmap_delta_bind_var_to_functor_8_0);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i3);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i4);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i6);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i5);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i8);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i9);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i10);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i11);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i13);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i12);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i15);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i16);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i21);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i23);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i25);
	init_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i18);
BEGIN_CODE

/* code for predicate 'instmap_delta_bind_var_to_functor'/8 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_bind_var_to_functor_8_0);
	MR_incr_sp_push_msg(9, "instmap:instmap_delta_bind_var_to_functor/8");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r6;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i3);
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r1 = r4;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i4,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i6,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i5);
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i8);
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	MR_stackvar(6) = MR_stackvar(7);
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i8);
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i9,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	MR_stackvar(8) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_is_live_0;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i10,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	r2 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i11,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	r4 = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(8);
	r6 = (Integer) 0;
	r7 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_util__abstractly_unify_inst_functor_10_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i13,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i12);
	MR_stackvar(6) = r4;
	r1 = r2;
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i16);
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i12);
	r1 = (Word) MR_string_const("bind_inst_to_functor: mode error", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i15,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i15);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	r2 = MR_stackvar(7);
	r1 = MR_stackvar(8);
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i16);
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury____Unify___inst__inst_0_0),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i21,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i21);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	if (r1)
		GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i18);
	r1 = MR_stackvar(8);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i23);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i23);
	r3 = r2;
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i25,
		ENTRY(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i25);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_bind_var_to_functor_8_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_bind_var_to_functor_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = r3;
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__instmap__instmap_delta_bind_var_to_functor_8_0_i18);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module27)
	init_entry(mercury__instmap__bind_var_to_functor_7_0);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i2);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i3);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i4);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i5);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i7);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i6);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i9);
	init_label(mercury__instmap__bind_var_to_functor_7_0_i11);
BEGIN_CODE

/* code for predicate 'bind_var_to_functor'/7 in mode 0 */
Define_entry(mercury__instmap__bind_var_to_functor_7_0);
	MR_incr_sp_push_msg(7, "instmap:bind_var_to_functor/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__bind_var_to_functor_7_0_i2,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0),
		mercury__instmap__bind_var_to_functor_7_0_i3,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i3);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_is_live_0;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__instmap__bind_var_to_functor_7_0_i4,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__instmap__bind_var_to_functor_7_0_i5,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	r4 = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(6);
	r6 = (Integer) 0;
	r7 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_util__abstractly_unify_inst_functor_10_0),
		mercury__instmap__bind_var_to_functor_7_0_i7,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__bind_var_to_functor_7_0_i6);
	r3 = r2;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_stackvar(2) = r4;
	call_localret(STATIC(mercury__instmap__set_4_0),
		mercury__instmap__bind_var_to_functor_7_0_i11,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i6);
	r1 = (Word) MR_string_const("bind_inst_to_functor: mode error", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__bind_var_to_functor_7_0_i9,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__instmap__set_4_0),
		mercury__instmap__bind_var_to_functor_7_0_i11,
		ENTRY(mercury__instmap__bind_var_to_functor_7_0));
Define_label(mercury__instmap__bind_var_to_functor_7_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__bind_var_to_functor_7_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);

BEGIN_MODULE(instmap_module28)
	init_entry(mercury__instmap__pre_lambda_update_5_0);
	init_label(mercury__instmap__pre_lambda_update_5_0_i2);
	init_label(mercury__instmap__pre_lambda_update_5_0_i3);
	init_label(mercury__instmap__pre_lambda_update_5_0_i4);
BEGIN_CODE

/* code for predicate 'pre_lambda_update'/5 in mode 0 */
Define_entry(mercury__instmap__pre_lambda_update_5_0);
	MR_incr_sp_push_msg(3, "instmap:pre_lambda_update/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__instmap__pre_lambda_update_5_0_i2,
		ENTRY(mercury__instmap__pre_lambda_update_5_0));
Define_label(mercury__instmap__pre_lambda_update_5_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__pre_lambda_update_5_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__instmap__pre_lambda_update_5_0_i3,
		ENTRY(mercury__instmap__pre_lambda_update_5_0));
Define_label(mercury__instmap__pre_lambda_update_5_0_i3);
	update_prof_current_proc(LABEL(mercury__instmap__pre_lambda_update_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__instmap__pre_lambda_update_5_0_i4,
		ENTRY(mercury__instmap__pre_lambda_update_5_0));
Define_label(mercury__instmap__pre_lambda_update_5_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__pre_lambda_update_5_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__instmap__pre_lambda_update_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__instmap__apply_instmap_delta_3_0),
		ENTRY(mercury__instmap__pre_lambda_update_5_0));
END_MODULE

Declare_entry(mercury__map__from_sorted_assoc_list_2_0);

BEGIN_MODULE(instmap_module29)
	init_entry(mercury__instmap__compute_instmap_delta_4_0);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i3);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i5);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i6);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i7);
	init_label(mercury__instmap__compute_instmap_delta_4_0_i8);
BEGIN_CODE

/* code for predicate 'compute_instmap_delta'/4 in mode 0 */
Define_entry(mercury__instmap__compute_instmap_delta_4_0);
	MR_incr_sp_push_msg(3, "instmap:compute_instmap_delta/4");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_4_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_4_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = r3;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__compute_instmap_delta_4_0_i6,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
Define_label(mercury__instmap__compute_instmap_delta_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__instmap__compute_instmap_delta_2_4_0),
		mercury__instmap__compute_instmap_delta_4_0_i7,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
Define_label(mercury__instmap__compute_instmap_delta_4_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__from_sorted_assoc_list_2_0),
		mercury__instmap__compute_instmap_delta_4_0_i8,
		ENTRY(mercury__instmap__compute_instmap_delta_4_0));
Define_label(mercury__instmap__compute_instmap_delta_4_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__compute_instmap_delta_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__map__overlay_3_0);

BEGIN_MODULE(instmap_module30)
	init_entry(mercury__instmap__apply_instmap_delta_3_0);
	init_label(mercury__instmap__apply_instmap_delta_3_0_i3);
	init_label(mercury__instmap__apply_instmap_delta_3_0_i5);
	init_label(mercury__instmap__apply_instmap_delta_3_0_i6);
BEGIN_CODE

/* code for predicate 'apply_instmap_delta'/3 in mode 0 */
Define_entry(mercury__instmap__apply_instmap_delta_3_0);
	MR_incr_sp_push_msg(1, "instmap:apply_instmap_delta/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__apply_instmap_delta_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__apply_instmap_delta_3_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__apply_instmap_delta_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__apply_instmap_delta_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__instmap__apply_instmap_delta_3_0_i6,
		ENTRY(mercury__instmap__apply_instmap_delta_3_0));
Define_label(mercury__instmap__apply_instmap_delta_3_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__apply_instmap_delta_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__apply_instmap_delta_3_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module31)
	init_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
	init_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i3);
	init_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i5);
	init_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_instmap_delta'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_apply_instmap_delta_3_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_apply_instmap_delta/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6,
		ENTRY(mercury__instmap__instmap_delta_apply_instmap_delta_3_0));
Define_label(mercury__instmap__instmap_delta_apply_instmap_delta_3_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_instmap_delta_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_apply_instmap_delta_3_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);
Declare_entry(mercury__mode_info__mode_info_set_module_info_3_0);
Declare_entry(mercury__set__singleton_set_2_1);
Declare_entry(mercury__mode_info__mode_info_error_4_0);

BEGIN_MODULE(instmap_module32)
	init_entry(mercury__instmap__merge_5_0);
	init_label(mercury__instmap__merge_5_0_i2);
	init_label(mercury__instmap__merge_5_0_i3);
	init_label(mercury__instmap__merge_5_0_i4);
	init_label(mercury__instmap__merge_5_0_i1000);
	init_label(mercury__instmap__merge_5_0_i5);
	init_label(mercury__instmap__merge_5_0_i9);
	init_label(mercury__instmap__merge_5_0_i10);
	init_label(mercury__instmap__merge_5_0_i11);
	init_label(mercury__instmap__merge_5_0_i14);
	init_label(mercury__instmap__merge_5_0_i12);
BEGIN_CODE

/* code for predicate 'merge'/5 in mode 0 */
Define_entry(mercury__instmap__merge_5_0);
	MR_incr_sp_push_msg(7, "instmap:merge/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__instmap__merge_5_0_i2,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i2);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__instmap__merge_5_0_i3,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i3);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__instmap__get_reachable_instmaps_2_0),
		mercury__instmap__merge_5_0_i4,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i5);
Define_label(mercury__instmap__merge_5_0_i1000);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i5);
	r3 = MR_stackvar(5);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i1000);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__merge_5_0_i9,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__instmap__merge_2_7_0),
		mercury__instmap__merge_5_0_i10,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__instmap__merge_5_0_i11,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_5_0_i12);
	MR_stackvar(4) = r1;
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__instmap__merge_5_0_i14,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i14);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__instmap__merge_5_0, "mode_errors:mode_error/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__instmap__merge_5_0_i12,
		ENTRY(mercury__instmap__merge_5_0));
Define_label(mercury__instmap__merge_5_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__merge_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__merge_5_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__merge_5_0));
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__unify_2_0);
Declare_entry(do_redo);

BEGIN_MODULE(instmap_module33)
	init_entry(mercury__instmap__unify_4_0);
	init_label(mercury__instmap__unify_4_0_i6);
	init_label(mercury__instmap__unify_4_0_i1020);
	init_label(mercury__instmap__unify_4_0_i4);
	init_label(mercury__instmap__unify_4_0_i9);
	init_label(mercury__instmap__unify_4_0_i3);
	init_label(mercury__instmap__unify_4_0_i11);
	init_label(mercury__instmap__unify_4_0_i18);
	init_label(mercury__instmap__unify_4_0_i19);
	init_label(mercury__instmap__unify_4_0_i20);
	init_label(mercury__instmap__unify_4_0_i21);
	init_label(mercury__instmap__unify_4_0_i1033);
	init_label(mercury__instmap__unify_4_0_i22);
	init_label(mercury__instmap__unify_4_0_i15);
BEGIN_CODE

/* code for predicate 'unify'/4 in mode 0 */
Define_entry(mercury__instmap__unify_4_0);
	MR_incr_sp_push_msg(9, "instmap:unify/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(6) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__instmap__unify_4_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__instmap__unify_4_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_2);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__instmap__unify_4_0_i6,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_instmap__type_ctor_info_instmap_0;
	call_localret(ENTRY(mercury__unify_2_0),
		mercury__instmap__unify_4_0_i1020,
		ENTRY(mercury__instmap__unify_4_0));
	}
Define_label(mercury__instmap__unify_4_0_i1020);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(8);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__unify_4_0_i9);
Define_label(mercury__instmap__unify_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__unify_4_0_i3);
Define_label(mercury__instmap__unify_4_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_4_0_i11);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_4_0_i11);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_4_0_i15);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_4_0_i15);
	MR_stackvar(1) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = r3;
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__instmap__unify_4_0_i18,
		ENTRY(mercury__instmap__unify_4_0));
	}
Define_label(mercury__instmap__unify_4_0_i18);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__unify_4_0_i19,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i19);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	call_localret(STATIC(mercury__instmap__unify_2_8_0),
		mercury__instmap__unify_4_0_i20,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i20);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__instmap__unify_4_0_i21,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i21);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_4_0_i22);
	MR_stackvar(3) = r1;
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__instmap__unify_4_0_i1033,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i1033);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__instmap__unify_4_0, "mode_errors:mode_error/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__mode_info__mode_info_error_4_0),
		mercury__instmap__unify_4_0_i22,
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i22);
	update_prof_current_proc(LABEL(mercury__instmap__unify_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__unify_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		ENTRY(mercury__instmap__unify_4_0));
Define_label(mercury__instmap__unify_4_0_i15);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__select_3_0);

BEGIN_MODULE(instmap_module34)
	init_entry(mercury__instmap__restrict_3_0);
	init_label(mercury__instmap__restrict_3_0_i3);
	init_label(mercury__instmap__restrict_3_0_i4);
BEGIN_CODE

/* code for predicate 'restrict'/3 in mode 0 */
Define_entry(mercury__instmap__restrict_3_0);
	MR_incr_sp_push_msg(1, "instmap:restrict/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__restrict_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__restrict_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__select_3_0),
		mercury__instmap__restrict_3_0_i4,
		ENTRY(mercury__instmap__restrict_3_0));
Define_label(mercury__instmap__restrict_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__restrict_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__restrict_3_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module35)
	init_entry(mercury__instmap__instmap_delta_restrict_3_0);
	init_label(mercury__instmap__instmap_delta_restrict_3_0_i3);
	init_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
BEGIN_CODE

/* code for predicate 'instmap_delta_restrict'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_restrict_3_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_restrict/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_restrict_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_restrict_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__select_3_0),
		mercury__instmap__instmap_delta_restrict_3_0_i4,
		ENTRY(mercury__instmap__instmap_delta_restrict_3_0));
Define_label(mercury__instmap__instmap_delta_restrict_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_restrict_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_restrict_3_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__map__delete_list_3_1);

BEGIN_MODULE(instmap_module36)
	init_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
	init_label(mercury__instmap__instmap_delta_delete_vars_3_0_i3);
	init_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
BEGIN_CODE

/* code for predicate 'instmap_delta_delete_vars'/3 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_delete_vars_3_0);
	MR_incr_sp_push_msg(1, "instmap:instmap_delta_delete_vars/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_delete_vars_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__instmap__instmap_delta_delete_vars_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__delete_list_3_1),
		mercury__instmap__instmap_delta_delete_vars_3_0_i4,
		ENTRY(mercury__instmap__instmap_delta_delete_vars_3_0));
Define_label(mercury__instmap__instmap_delta_delete_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_delete_vars_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_delete_vars_3_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module37)
	init_entry(mercury__instmap__no_output_vars_4_0);
	init_label(mercury__instmap__no_output_vars_4_0_i4);
	init_label(mercury__instmap__no_output_vars_4_0_i2);
BEGIN_CODE

/* code for predicate 'no_output_vars'/4 in mode 0 */
Define_entry(mercury__instmap__no_output_vars_4_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__no_output_vars_4_0_i2);
	MR_incr_sp_push_msg(4, "instmap:no_output_vars/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__no_output_vars_4_0_i4,
		ENTRY(mercury__instmap__no_output_vars_4_0));
Define_label(mercury__instmap__no_output_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__instmap__no_output_vars_2_4_0),
		ENTRY(mercury__instmap__no_output_vars_4_0));
Define_label(mercury__instmap__no_output_vars_4_0_i2);
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module38)
	init_entry(mercury__instmap__merge_instmap_delta_7_0);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i3);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i5);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i6);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i7);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i8);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i9);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i10);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i11);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i12);
	init_label(mercury__instmap__merge_instmap_delta_7_0_i13);
BEGIN_CODE

/* code for predicate 'merge_instmap_delta'/7 in mode 0 */
Define_entry(mercury__instmap__merge_instmap_delta_7_0);
	MR_incr_sp_push_msg(7, "instmap:merge_instmap_delta/7");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_instmap_delta_7_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__instmap__merge_instmap_delta_7_0_i3);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_instmap_delta_7_0_i5);
	r1 = r3;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__instmap__merge_instmap_delta_7_0_i5);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(5) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__merge_instmap_delta_7_0_i6,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__instmap__merge_instmap_delta_7_0_i7,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__sorted_list_to_set_2_0),
		mercury__instmap__merge_instmap_delta_7_0_i8,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__instmap__merge_instmap_delta_7_0_i9,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__instmap__merge_instmap_delta_7_0_i10,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__merge_instmap_delta_7_0_i11,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__instmap__merge_instmap_delta_7_0_i12,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	call_localret(STATIC(mercury__instmap__merge_instmapping_delta_2_8_0),
		mercury__instmap__merge_instmap_delta_7_0_i13,
		ENTRY(mercury__instmap__merge_instmap_delta_7_0));
Define_label(mercury__instmap__merge_instmap_delta_7_0_i13);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_delta_7_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__merge_instmap_delta_7_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module39)
	init_entry(mercury__instmap__merge_instmap_deltas_6_0);
	init_label(mercury__instmap__merge_instmap_deltas_6_0_i3);
BEGIN_CODE

/* code for predicate 'merge_instmap_deltas'/6 in mode 0 */
Define_entry(mercury__instmap__merge_instmap_deltas_6_0);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_instmap_deltas_6_0_i3);
	r1 = (Word) MR_string_const("merge_instmap_deltas: empty instmap_delta list.", 47);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__instmap__merge_instmap_deltas_6_0));
Define_label(mercury__instmap__merge_instmap_deltas_6_0_i3);
	r5 = r4;
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	tailcall(STATIC(mercury__instmap__merge_instmap_deltas_7_0),
		ENTRY(mercury__instmap__merge_instmap_deltas_6_0));
END_MODULE


BEGIN_MODULE(instmap_module40)
	init_entry(mercury__instmap__unify_instmap_delta_7_0);
BEGIN_CODE

/* code for predicate 'unify_instmap_delta'/7 in mode 0 */
Define_entry(mercury__instmap__unify_instmap_delta_7_0);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	tailcall(STATIC(mercury__instmap__unify_instmap_delta__ua0_7_0),
		ENTRY(mercury__instmap__unify_instmap_delta_7_0));
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(instmap_module41)
	init_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i3);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
	init_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_sub'/4 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_apply_sub_4_0);
	MR_incr_sp_push_msg(4, "instmap:instmap_delta_apply_sub/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i3);
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i4,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i5,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0),
		mercury__instmap__instmap_delta_apply_sub_4_0_i6,
		ENTRY(mercury__instmap__instmap_delta_apply_sub_4_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__instmap__instmap_delta_apply_sub_4_0, "instmap:instmap/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module42)
	init_entry(mercury__instmap__apply_sub_4_0);
BEGIN_CODE

/* code for predicate 'apply_sub'/4 in mode 0 */
Define_entry(mercury__instmap__apply_sub_4_0);
	tailcall(STATIC(mercury__instmap__instmap_delta_apply_sub_4_0),
		ENTRY(mercury__instmap__apply_sub_4_0));
END_MODULE


BEGIN_MODULE(instmap_module43)
	init_entry(mercury__instmap__to_assoc_list_2_0);
	init_label(mercury__instmap__to_assoc_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'to_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__to_assoc_list_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__to_assoc_list_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__instmap__to_assoc_list_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__instmap__to_assoc_list_2_0));
END_MODULE


BEGIN_MODULE(instmap_module44)
	init_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
	init_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'instmap_delta_to_assoc_list'/2 in mode 0 */
Define_entry(mercury__instmap__instmap_delta_to_assoc_list_2_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_to_assoc_list_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__instmap__instmap_delta_to_assoc_list_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__instmap__instmap_delta_to_assoc_list_2_0));
END_MODULE

Declare_entry(mercury__mode_util__mode_get_insts_4_0);

BEGIN_MODULE(instmap_module45)
	init_entry(mercury__instmap__instmap_delta_from_mode_list_2_5_0);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i1004);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i3);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i9);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i12);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i10);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i15);
	init_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i8);
BEGIN_CODE

/* code for predicate 'instmap_delta_from_mode_list_2'/5 in mode 0 */
Define_static(mercury__instmap__instmap_delta_from_mode_list_2_5_0);
	MR_incr_sp_push_msg(7, "instmap:instmap_delta_from_mode_list_2/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i8);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i8);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = r3;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__mode_util__mode_get_insts_4_0),
		mercury__instmap__instmap_delta_from_mode_list_2_5_0_i9,
		STATIC(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury____Unify___inst__inst_0_0),
		mercury__instmap__instmap_delta_from_mode_list_2_5_0_i12,
		STATIC(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i10);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i1004);
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i10);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__instmap__instmap_delta_set_4_0),
		mercury__instmap__instmap_delta_from_mode_list_2_5_0_i15,
		STATIC(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i1004);
Define_label(mercury__instmap__instmap_delta_from_mode_list_2_5_0_i8);
	r1 = (Word) MR_string_const("instmap_delta_from_mode_list_2", 30);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__instmap__instmap_delta_from_mode_list_2_5_0));
END_MODULE


BEGIN_MODULE(instmap_module46)
	init_entry(mercury__instmap__changed_vars_2_5_0);
	init_label(mercury__instmap__changed_vars_2_5_0_i3);
	init_label(mercury__instmap__changed_vars_2_5_0_i5);
	init_label(mercury__instmap__changed_vars_2_5_0_i8);
	init_label(mercury__instmap__changed_vars_2_5_0_i6);
BEGIN_CODE

/* code for predicate 'changed_vars_2'/5 in mode 0 */
Define_static(mercury__instmap__changed_vars_2_5_0);
	MR_incr_sp_push_msg(3, "instmap:changed_vars_2/5");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__changed_vars_2_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__set__init_1_0),
		STATIC(mercury__instmap__changed_vars_2_5_0));
Define_label(mercury__instmap__changed_vars_2_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r4;
	MR_stackvar(2) = MR_tempr1;
	r1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = MR_tempr1;
	call_localret(STATIC(mercury__instmap__DeforestationIn__pred__changed_vars_2__406__1_8_0),
		mercury__instmap__changed_vars_2_5_0_i5,
		STATIC(mercury__instmap__changed_vars_2_5_0));
	}
Define_label(mercury__instmap__changed_vars_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__changed_vars_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	call_localret(ENTRY(mercury__inst_match__inst_matches_final_3_0),
		mercury__instmap__changed_vars_2_5_0_i8,
		STATIC(mercury__instmap__changed_vars_2_5_0));
	}
Define_label(mercury__instmap__changed_vars_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__changed_vars_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__changed_vars_2_5_0_i6);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__instmap__changed_vars_2_5_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__set__insert_3_1),
		STATIC(mercury__instmap__changed_vars_2_5_0));
END_MODULE


BEGIN_MODULE(instmap_module47)
	init_entry(mercury__instmap__get_reachable_instmaps_2_0);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i1002);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i6);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i4);
	init_label(mercury__instmap__get_reachable_instmaps_2_0_i3);
BEGIN_CODE

/* code for predicate 'get_reachable_instmaps'/2 in mode 0 */
Define_static(mercury__instmap__get_reachable_instmaps_2_0);
	MR_incr_sp_push_msg(2, "instmap:get_reachable_instmaps/2");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__get_reachable_instmaps_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__get_reachable_instmaps_2_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = r2;
	localcall(mercury__instmap__get_reachable_instmaps_2_0,
		LABEL(mercury__instmap__get_reachable_instmaps_2_0_i6),
		STATIC(mercury__instmap__get_reachable_instmaps_2_0));
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__get_reachable_instmaps_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__instmap__get_reachable_instmaps_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i4);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__instmap__get_reachable_instmaps_2_0_i1002);
Define_label(mercury__instmap__get_reachable_instmaps_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module48)
	init_entry(mercury__instmap__merge_2_7_0);
	init_label(mercury__instmap__merge_2_7_0_i4);
	init_label(mercury__instmap__merge_2_7_0_i5);
	init_label(mercury__instmap__merge_2_7_0_i6);
	init_label(mercury__instmap__merge_2_7_0_i9);
	init_label(mercury__instmap__merge_2_7_0_i3);
BEGIN_CODE

/* code for predicate 'merge_2'/7 in mode 0 */
Define_static(mercury__instmap__merge_2_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_2_7_0_i3);
	MR_incr_sp_push_msg(4, "instmap:merge_2/7");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__instmap__merge_2_7_0,
		LABEL(mercury__instmap__merge_2_7_0_i4),
		STATIC(mercury__instmap__merge_2_7_0));
Define_label(mercury__instmap__merge_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	MR_stackvar(3) = r3;
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__instmap__merge_var_7_0),
		mercury__instmap__merge_2_7_0_i5,
		STATIC(mercury__instmap__merge_2_7_0));
Define_label(mercury__instmap__merge_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	if (((Integer) r4 != (Integer) 1))
		GOTO_LABEL(mercury__instmap__merge_2_7_0_i6);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r4 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 2, mercury__instmap__merge_2_7_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__instmap__merge_2_7_0, "origin_lost_in_value_number");
	r3 = r2;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__merge_2_7_0_i9,
		STATIC(mercury__instmap__merge_2_7_0));
	}
Define_label(mercury__instmap__merge_2_7_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = MR_stackvar(2);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(2) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__merge_2_7_0_i9,
		STATIC(mercury__instmap__merge_2_7_0));
	}
Define_label(mercury__instmap__merge_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__merge_2_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__merge_2_7_0_i3);
	r1 = r3;
	r2 = r4;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__inst_util__inst_merge_5_0);

BEGIN_MODULE(instmap_module49)
	init_entry(mercury__instmap__merge_var_7_0);
	init_label(mercury__instmap__merge_var_7_0_i4);
	init_label(mercury__instmap__merge_var_7_0_i5);
	init_label(mercury__instmap__merge_var_7_0_i8);
	init_label(mercury__instmap__merge_var_7_0_i6);
	init_label(mercury__instmap__merge_var_7_0_i3);
BEGIN_CODE

/* code for predicate 'merge_var'/7 in mode 0 */
Define_static(mercury__instmap__merge_var_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_var_7_0_i3);
	MR_incr_sp_push_msg(5, "instmap:merge_var/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__instmap__merge_var_7_0,
		LABEL(mercury__instmap__merge_var_7_0_i4),
		STATIC(mercury__instmap__merge_var_7_0));
Define_label(mercury__instmap__merge_var_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__merge_var_7_0_i5,
		STATIC(mercury__instmap__merge_var_7_0));
	}
Define_label(mercury__instmap__merge_var_7_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__instmap__merge_var_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	r2 = r1;
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__inst_util__inst_merge_5_0),
		mercury__instmap__merge_var_7_0_i8,
		STATIC(mercury__instmap__merge_var_7_0));
	}
Define_label(mercury__instmap__merge_var_7_0_i8);
	update_prof_current_proc(LABEL(mercury__instmap__merge_var_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__merge_var_7_0_i6);
	r1 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__instmap__merge_var_7_0_i6);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r3 = MR_stackvar(3);
	r4 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__instmap__merge_var_7_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r4 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module50)
	init_entry(mercury__instmap__merge_instmap_deltas_7_0);
	init_label(mercury__instmap__merge_instmap_deltas_7_0_i1001);
	init_label(mercury__instmap__merge_instmap_deltas_7_0_i4);
	init_label(mercury__instmap__merge_instmap_deltas_7_0_i3);
BEGIN_CODE

/* code for predicate 'merge_instmap_deltas'/7 in mode 0 */
Define_static(mercury__instmap__merge_instmap_deltas_7_0);
	MR_incr_sp_push_msg(4, "instmap:merge_instmap_deltas/7");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__instmap__merge_instmap_deltas_7_0_i1001);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_instmap_deltas_7_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__instmap__merge_instmap_delta_7_0),
		mercury__instmap__merge_instmap_deltas_7_0_i4,
		STATIC(mercury__instmap__merge_instmap_deltas_7_0));
Define_label(mercury__instmap__merge_instmap_deltas_7_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmap_deltas_7_0));
	r3 = r1;
	r5 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__instmap__merge_instmap_deltas_7_0_i1001);
Define_label(mercury__instmap__merge_instmap_deltas_7_0_i3);
	r1 = r3;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module51)
	init_entry(mercury__instmap__unify_2_8_0);
	init_label(mercury__instmap__unify_2_8_0_i3);
	init_label(mercury__instmap__unify_2_8_0_i4);
	init_label(mercury__instmap__unify_2_8_0_i5);
	init_label(mercury__instmap__unify_2_8_0_i6);
	init_label(mercury__instmap__unify_2_8_0_i9);
BEGIN_CODE

/* code for predicate 'unify_2'/8 in mode 0 */
Define_static(mercury__instmap__unify_2_8_0);
	MR_incr_sp_push_msg(4, "instmap:unify_2/8");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_2_8_0_i3);
	r1 = r4;
	r2 = r5;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__instmap__unify_2_8_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_tempr1;
	r1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r5 = MR_tempr1;
	call_localret(STATIC(mercury__instmap__DeforestationIn__pred__unify_2__782__3_10_0),
		mercury__instmap__unify_2_8_0_i4,
		STATIC(mercury__instmap__unify_2_8_0));
	}
Define_label(mercury__instmap__unify_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__unify_2_8_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__instmap__unify_var_10_0),
		mercury__instmap__unify_2_8_0_i5,
		STATIC(mercury__instmap__unify_2_8_0));
Define_label(mercury__instmap__unify_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__unify_2_8_0));
	if (((Integer) r4 != (Integer) 1))
		GOTO_LABEL(mercury__instmap__unify_2_8_0_i6);
	r5 = MR_stackvar(2);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 2, mercury__instmap__unify_2_8_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__instmap__unify_2_8_0, "origin_lost_in_value_number");
	r4 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r5;
	r5 = r2;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__unify_2_8_0_i9,
		STATIC(mercury__instmap__unify_2_8_0));
	}
Define_label(mercury__instmap__unify_2_8_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = MR_stackvar(2);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(2) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__unify_2_8_0_i9,
		STATIC(mercury__instmap__unify_2_8_0));
	}
Define_label(mercury__instmap__unify_2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__unify_2_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__set__member_2_0);

BEGIN_MODULE(instmap_module52)
	init_entry(mercury__instmap__unify_var_10_0);
	init_label(mercury__instmap__unify_var_10_0_i1003);
	init_label(mercury__instmap__unify_var_10_0_i5);
	init_label(mercury__instmap__unify_var_10_0_i7);
	init_label(mercury__instmap__unify_var_10_0_i9);
	init_label(mercury__instmap__unify_var_10_0_i8);
	init_label(mercury__instmap__unify_var_10_0_i4);
	init_label(mercury__instmap__unify_var_10_0_i3);
BEGIN_CODE

/* code for predicate 'unify_var'/10 in mode 0 */
Define_static(mercury__instmap__unify_var_10_0);
	MR_incr_sp_push_msg(8, "instmap:unify_var/10");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__instmap__unify_var_10_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__unify_var_10_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__instmap__unify_var_10_0_i5,
		STATIC(mercury__instmap__unify_var_10_0));
	}
Define_label(mercury__instmap__unify_var_10_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__unify_var_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_var_10_0_i4);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__unify_var_10_0_i7,
		STATIC(mercury__instmap__unify_var_10_0));
Define_label(mercury__instmap__unify_var_10_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__unify_var_10_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(3);
	r4 = (Integer) 1;
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__inst_util__abstractly_unify_inst_8_0),
		mercury__instmap__unify_var_10_0_i9,
		STATIC(mercury__instmap__unify_var_10_0));
Define_label(mercury__instmap__unify_var_10_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__unify_var_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__unify_var_10_0_i8);
	r5 = r4;
	r4 = r2;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__instmap__unify_var_10_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r6 = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__instmap__unify_var_10_0_i1003);
Define_label(mercury__instmap__unify_var_10_0_i8);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(7);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r5 = MR_stackvar(4);
	r6 = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__instmap__unify_var_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__instmap__unify_var_10_0_i1003);
Define_label(mercury__instmap__unify_var_10_0_i4);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(7);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__instmap__unify_var_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__instmap__unify_var_10_0_i1003);
Define_label(mercury__instmap__unify_var_10_0_i3);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	r4 = r6;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module53)
	init_entry(mercury__instmap__compute_instmap_delta_2_4_0);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i7);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i12);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i15);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i13);
	init_label(mercury__instmap__compute_instmap_delta_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'compute_instmap_delta_2'/4 in mode 0 */
Define_static(mercury__instmap__compute_instmap_delta_2_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i3);
	MR_incr_sp_push_msg(8, "instmap:compute_instmap_delta_2/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__compute_instmap_delta_2_4_0_i5,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_stackvar(5) = r2;
	GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i7);
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i7);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__compute_instmap_delta_2_4_0_i9,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__instmap__compute_instmap_delta_2_4_0,
		LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i12),
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i8);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(4);
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__instmap__compute_instmap_delta_2_4_0,
		LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i12),
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___inst__inst_0_0),
		mercury__instmap__compute_instmap_delta_2_4_0_i15,
		STATIC(mercury__instmap__compute_instmap_delta_2_4_0));
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__instmap__compute_instmap_delta_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__compute_instmap_delta_2_4_0_i13);
	r1 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i13);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__instmap__compute_instmap_delta_2_4_0, "origin_lost_in_value_number");
	r2 = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__instmap__compute_instmap_delta_2_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__instmap__compute_instmap_delta_2_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__inst_match__inst_matches_binding_3_0);

BEGIN_MODULE(instmap_module54)
	init_entry(mercury__instmap__no_output_vars_2_4_0);
	init_label(mercury__instmap__no_output_vars_2_4_0_i1003);
	init_label(mercury__instmap__no_output_vars_2_4_0_i4);
	init_label(mercury__instmap__no_output_vars_2_4_0_i6);
	init_label(mercury__instmap__no_output_vars_2_4_0_i5);
	init_label(mercury__instmap__no_output_vars_2_4_0_i8);
	init_label(mercury__instmap__no_output_vars_2_4_0_i9);
	init_label(mercury__instmap__no_output_vars_2_4_0_i2);
	init_label(mercury__instmap__no_output_vars_2_4_0_i1);
BEGIN_CODE

/* code for predicate 'no_output_vars_2'/4 in mode 0 */
Define_static(mercury__instmap__no_output_vars_2_4_0);
	MR_incr_sp_push_msg(6, "instmap:no_output_vars_2/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__instmap__no_output_vars_2_4_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_tempr1;
	r1 = r2;
	r2 = MR_tempr1;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__no_output_vars_2_4_0_i4,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
	}
Define_label(mercury__instmap__no_output_vars_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__no_output_vars_2_4_0_i6,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
Define_label(mercury__instmap__no_output_vars_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i5);
	r3 = MR_stackvar(3);
	r1 = r2;
	r2 = MR_stackvar(4);
	GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i8);
Define_label(mercury__instmap__no_output_vars_2_4_0_i5);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r1 = r2;
Define_label(mercury__instmap__no_output_vars_2_4_0_i8);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__inst_match__inst_matches_binding_3_0),
		mercury__instmap__no_output_vars_2_4_0_i9,
		STATIC(mercury__instmap__no_output_vars_2_4_0));
Define_label(mercury__instmap__no_output_vars_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__no_output_vars_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__instmap__no_output_vars_2_4_0_i1003);
Define_label(mercury__instmap__no_output_vars_2_4_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__instmap__no_output_vars_2_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__term__var_to_int_2_0);
Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(instmap_module55)
	init_entry(mercury__instmap__merge_instmapping_delta_2_8_0);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i1004);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i5);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i4);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i7);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i8);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i10);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i9);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i12);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i16);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i15);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i19);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i20);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i21);
	init_label(mercury__instmap__merge_instmapping_delta_2_8_0_i3);
BEGIN_CODE

/* code for predicate 'merge_instmapping_delta_2'/8 in mode 0 */
Define_static(mercury__instmap__merge_instmapping_delta_2_8_0);
	MR_incr_sp_push_msg(10, "instmap:merge_instmapping_delta_2/8");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i1004);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i3);
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__merge_instmapping_delta_2_8_0_i5,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i4);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_stackvar(8) = r2;
	GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i8);
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i7,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i7);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_stackvar(8) = r1;
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i8);
	MR_stackvar(3) = r3;
	MR_stackvar(6) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__merge_instmapping_delta_2_8_0_i10,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i9);
	r3 = MR_stackvar(5);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__inst_util__inst_merge_5_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i16,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i9);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__instmap__lookup_var_3_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i12,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i12);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	r3 = MR_stackvar(5);
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__inst_util__inst_merge_5_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i16,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i16);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i15);
	r5 = r2;
	MR_stackvar(9) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i21,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i15);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__term__var_to_int_2_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i19,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i19);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__instmap__merge_instmapping_delta_2_8_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_string_const("merge_instmapping_delta_2: error merging var %i", 47);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__instmap__merge_instmapping_delta_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i20,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
	}
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i20);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__merge_instmapping_delta_2_8_0_i21,
		STATIC(mercury__instmap__merge_instmapping_delta_2_8_0));
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i21);
	update_prof_current_proc(LABEL(mercury__instmap__merge_instmapping_delta_2_8_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = r1;
	r1 = MR_stackvar(7);
	r6 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__instmap__merge_instmapping_delta_2_8_0_i1004);
Define_label(mercury__instmap__merge_instmapping_delta_2_8_0_i3);
	r1 = r5;
	r2 = r6;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module56)
	init_entry(mercury__instmap__instmap_delta_apply_sub_2_5_0);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1003);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i4);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i8);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
	init_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'instmap_delta_apply_sub_2'/5 in mode 0 */
Define_static(mercury__instmap__instmap_delta_apply_sub_2_5_0);
	MR_incr_sp_push_msg(7, "instmap:instmap_delta_apply_sub_2/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i3);
	MR_stackvar(3) = r4;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i5,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	}
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i4);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i11,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i4);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i8);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i11,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i8);
	r1 = (Word) MR_string_const("instmap_delta_apply_sub_2: no substitute", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i9,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	r4 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__instmap__instmap_delta_apply_sub_2_5_0_i11,
		STATIC(mercury__instmap__instmap_delta_apply_sub_2_5_0));
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__instmap__instmap_delta_apply_sub_2_5_0_i1003);
Define_label(mercury__instmap__instmap_delta_apply_sub_2_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(instmap_module57)
	init_entry(mercury____Unify___instmap__instmap_0_0);
	init_label(mercury____Unify___instmap__instmap_0_0_i3);
	init_label(mercury____Unify___instmap__instmap_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___instmap__instmap_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___instmap__instmap_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___instmap__instmap_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___instmap__instmap_0_0));
Define_label(mercury____Unify___instmap__instmap_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module58)
	init_entry(mercury____Index___instmap__instmap_0_0);
	init_label(mercury____Index___instmap__instmap_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___instmap__instmap_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___instmap__instmap_0_0_i3);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___instmap__instmap_0_0_i3);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(instmap_module59)
	init_entry(mercury____Compare___instmap__instmap_0_0);
	init_label(mercury____Compare___instmap__instmap_0_0_i3);
	init_label(mercury____Compare___instmap__instmap_0_0_i2);
	init_label(mercury____Compare___instmap__instmap_0_0_i5);
	init_label(mercury____Compare___instmap__instmap_0_0_i4);
	init_label(mercury____Compare___instmap__instmap_0_0_i6);
	init_label(mercury____Compare___instmap__instmap_0_0_i7);
	init_label(mercury____Compare___instmap__instmap_0_0_i11);
	init_label(mercury____Compare___instmap__instmap_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___instmap__instmap_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i3);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i2);
Define_label(mercury____Compare___instmap__instmap_0_0_i3);
	r3 = (Integer) 0;
Define_label(mercury____Compare___instmap__instmap_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i5);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i4);
Define_label(mercury____Compare___instmap__instmap_0_0_i5);
	r4 = (Integer) 0;
Define_label(mercury____Compare___instmap__instmap_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___instmap__instmap_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___instmap__instmap_0_0_i1014);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___instmap__instmap_0_0));
Define_label(mercury____Compare___instmap__instmap_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___instmap__instmap_0_0));
END_MODULE


BEGIN_MODULE(instmap_module60)
	init_entry(mercury____Unify___instmap__instmap_delta_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___instmap__instmap_delta_0_0);
	tailcall(STATIC(mercury____Unify___instmap__instmap_0_0),
		ENTRY(mercury____Unify___instmap__instmap_delta_0_0));
END_MODULE


BEGIN_MODULE(instmap_module61)
	init_entry(mercury____Index___instmap__instmap_delta_0_0);
	init_label(mercury____Index___instmap__instmap_delta_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___instmap__instmap_delta_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___instmap__instmap_delta_0_0_i3);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___instmap__instmap_delta_0_0_i3);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(instmap_module62)
	init_entry(mercury____Compare___instmap__instmap_delta_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___instmap__instmap_delta_0_0);
	tailcall(STATIC(mercury____Compare___instmap__instmap_0_0),
		ENTRY(mercury____Compare___instmap__instmap_delta_0_0));
END_MODULE


BEGIN_MODULE(instmap_module63)
	init_entry(mercury____Unify___instmap__instmapping_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___instmap__instmapping_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___instmap__instmapping_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(instmap_module64)
	init_entry(mercury____Index___instmap__instmapping_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___instmap__instmapping_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___instmap__instmapping_0_0));
END_MODULE


BEGIN_MODULE(instmap_module65)
	init_entry(mercury____Compare___instmap__instmapping_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___instmap__instmapping_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_instmap__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_inst__type_ctor_info_inst_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___instmap__instmapping_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__instmap_maybe_bunch_0(void)
{
	instmap_module0();
	instmap_module1();
	instmap_module2();
	instmap_module3();
	instmap_module4();
	instmap_module5();
	instmap_module6();
	instmap_module7();
	instmap_module8();
	instmap_module9();
	instmap_module10();
	instmap_module11();
	instmap_module12();
	instmap_module13();
	instmap_module14();
	instmap_module15();
	instmap_module16();
	instmap_module17();
	instmap_module18();
	instmap_module19();
	instmap_module20();
	instmap_module21();
	instmap_module22();
	instmap_module23();
	instmap_module24();
	instmap_module25();
	instmap_module26();
	instmap_module27();
	instmap_module28();
	instmap_module29();
	instmap_module30();
	instmap_module31();
	instmap_module32();
	instmap_module33();
	instmap_module34();
	instmap_module35();
	instmap_module36();
	instmap_module37();
	instmap_module38();
	instmap_module39();
}

static void mercury__instmap_maybe_bunch_1(void)
{
	instmap_module40();
	instmap_module41();
	instmap_module42();
	instmap_module43();
	instmap_module44();
	instmap_module45();
	instmap_module46();
	instmap_module47();
	instmap_module48();
	instmap_module49();
	instmap_module50();
	instmap_module51();
	instmap_module52();
	instmap_module53();
	instmap_module54();
	instmap_module55();
	instmap_module56();
	instmap_module57();
	instmap_module58();
	instmap_module59();
	instmap_module60();
	instmap_module61();
	instmap_module62();
	instmap_module63();
	instmap_module64();
	instmap_module65();
}

#endif

void mercury__instmap__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__instmap__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__instmap_maybe_bunch_0();
		mercury__instmap_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_instmap__type_ctor_info_instmap_0,
			instmap__instmap_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_instmap__type_ctor_info_instmap_delta_0,
			instmap__instmap_delta_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_instmap__type_ctor_info_instmapping_0,
			instmap__instmapping_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
