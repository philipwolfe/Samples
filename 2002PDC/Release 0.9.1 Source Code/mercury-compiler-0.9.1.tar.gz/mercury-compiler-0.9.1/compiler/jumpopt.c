/*
** Automatically generated from `jumpopt.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__jumpopt__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__jumpopt__jumpopt_main_8_0);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i2);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i3);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i4);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i5);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i6);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i7);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i8);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i9);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i10);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i13);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i14);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i11);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i15);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i16);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i17);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i19);
Declare_label(mercury__jumpopt__jumpopt_main_8_0_i18);
Declare_static(mercury__jumpopt__build_maps_15_0);
Declare_label(mercury__jumpopt__build_maps_15_0_i1010);
Declare_label(mercury__jumpopt__build_maps_15_0_i6);
Declare_label(mercury__jumpopt__build_maps_15_0_i7);
Declare_label(mercury__jumpopt__build_maps_15_0_i11);
Declare_label(mercury__jumpopt__build_maps_15_0_i13);
Declare_label(mercury__jumpopt__build_maps_15_0_i16);
Declare_label(mercury__jumpopt__build_maps_15_0_i14);
Declare_label(mercury__jumpopt__build_maps_15_0_i17);
Declare_label(mercury__jumpopt__build_maps_15_0_i20);
Declare_label(mercury__jumpopt__build_maps_15_0_i22);
Declare_label(mercury__jumpopt__build_maps_15_0_i18);
Declare_label(mercury__jumpopt__build_maps_15_0_i23);
Declare_label(mercury__jumpopt__build_maps_15_0_i26);
Declare_label(mercury__jumpopt__build_maps_15_0_i28);
Declare_label(mercury__jumpopt__build_maps_15_0_i24);
Declare_label(mercury__jumpopt__build_maps_15_0_i29);
Declare_label(mercury__jumpopt__build_maps_15_0_i32);
Declare_label(mercury__jumpopt__build_maps_15_0_i34);
Declare_label(mercury__jumpopt__build_maps_15_0_i30);
Declare_label(mercury__jumpopt__build_maps_15_0_i35);
Declare_label(mercury__jumpopt__build_maps_15_0_i39);
Declare_label(mercury__jumpopt__build_maps_15_0_i43);
Declare_label(mercury__jumpopt__build_maps_15_0_i44);
Declare_label(mercury__jumpopt__build_maps_15_0_i37);
Declare_label(mercury__jumpopt__build_maps_15_0_i4);
Declare_label(mercury__jumpopt__build_maps_15_0_i3);
Declare_static(mercury__jumpopt__build_forkmap_4_0);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i1003);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i7);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i9);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i4);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i5);
Declare_label(mercury__jumpopt__build_forkmap_4_0_i3);
Declare_static(mercury__jumpopt__instr_list_14_0);
Declare_label(mercury__jumpopt__instr_list_14_0_i4);
Declare_label(mercury__jumpopt__instr_list_14_0_i11);
Declare_label(mercury__jumpopt__instr_list_14_0_i10);
Declare_label(mercury__jumpopt__instr_list_14_0_i13);
Declare_label(mercury__jumpopt__instr_list_14_0_i18);
Declare_label(mercury__jumpopt__instr_list_14_0_i20);
Declare_label(mercury__jumpopt__instr_list_14_0_i8);
Declare_label(mercury__jumpopt__instr_list_14_0_i9);
Declare_label(mercury__jumpopt__instr_list_14_0_i25);
Declare_label(mercury__jumpopt__instr_list_14_0_i30);
Declare_label(mercury__jumpopt__instr_list_14_0_i22);
Declare_label(mercury__jumpopt__instr_list_14_0_i23);
Declare_label(mercury__jumpopt__instr_list_14_0_i37);
Declare_label(mercury__jumpopt__instr_list_14_0_i47);
Declare_label(mercury__jumpopt__instr_list_14_0_i33);
Declare_label(mercury__jumpopt__instr_list_14_0_i34);
Declare_label(mercury__jumpopt__instr_list_14_0_i54);
Declare_label(mercury__jumpopt__instr_list_14_0_i64);
Declare_label(mercury__jumpopt__instr_list_14_0_i49);
Declare_label(mercury__jumpopt__instr_list_14_0_i50);
Declare_label(mercury__jumpopt__instr_list_14_0_i67);
Declare_label(mercury__jumpopt__instr_list_14_0_i71);
Declare_label(mercury__jumpopt__instr_list_14_0_i73);
Declare_label(mercury__jumpopt__instr_list_14_0_i76);
Declare_label(mercury__jumpopt__instr_list_14_0_i74);
Declare_label(mercury__jumpopt__instr_list_14_0_i5);
Declare_label(mercury__jumpopt__instr_list_14_0_i89);
Declare_label(mercury__jumpopt__instr_list_14_0_i87);
Declare_label(mercury__jumpopt__instr_list_14_0_i95);
Declare_label(mercury__jumpopt__instr_list_14_0_i91);
Declare_label(mercury__jumpopt__instr_list_14_0_i92);
Declare_label(mercury__jumpopt__instr_list_14_0_i98);
Declare_label(mercury__jumpopt__instr_list_14_0_i100);
Declare_label(mercury__jumpopt__instr_list_14_0_i97);
Declare_label(mercury__jumpopt__instr_list_14_0_i103);
Declare_label(mercury__jumpopt__instr_list_14_0_i105);
Declare_label(mercury__jumpopt__instr_list_14_0_i102);
Declare_label(mercury__jumpopt__instr_list_14_0_i108);
Declare_label(mercury__jumpopt__instr_list_14_0_i107);
Declare_label(mercury__jumpopt__instr_list_14_0_i112);
Declare_label(mercury__jumpopt__instr_list_14_0_i114);
Declare_label(mercury__jumpopt__instr_list_14_0_i115);
Declare_label(mercury__jumpopt__instr_list_14_0_i117);
Declare_label(mercury__jumpopt__instr_list_14_0_i118);
Declare_label(mercury__jumpopt__instr_list_14_0_i119);
Declare_label(mercury__jumpopt__instr_list_14_0_i120);
Declare_label(mercury__jumpopt__instr_list_14_0_i111);
Declare_label(mercury__jumpopt__instr_list_14_0_i122);
Declare_label(mercury__jumpopt__instr_list_14_0_i124);
Declare_label(mercury__jumpopt__instr_list_14_0_i125);
Declare_label(mercury__jumpopt__instr_list_14_0_i126);
Declare_label(mercury__jumpopt__instr_list_14_0_i127);
Declare_label(mercury__jumpopt__instr_list_14_0_i131);
Declare_label(mercury__jumpopt__instr_list_14_0_i130);
Declare_label(mercury__jumpopt__instr_list_14_0_i134);
Declare_label(mercury__jumpopt__instr_list_14_0_i136);
Declare_label(mercury__jumpopt__instr_list_14_0_i139);
Declare_label(mercury__jumpopt__instr_list_14_0_i135);
Declare_label(mercury__jumpopt__instr_list_14_0_i84);
Declare_label(mercury__jumpopt__instr_list_14_0_i150);
Declare_label(mercury__jumpopt__instr_list_14_0_i152);
Declare_label(mercury__jumpopt__instr_list_14_0_i151);
Declare_label(mercury__jumpopt__instr_list_14_0_i154);
Declare_label(mercury__jumpopt__instr_list_14_0_i1264);
Declare_label(mercury__jumpopt__instr_list_14_0_i1265);
Declare_label(mercury__jumpopt__instr_list_14_0_i160);
Declare_label(mercury__jumpopt__instr_list_14_0_i164);
Declare_label(mercury__jumpopt__instr_list_14_0_i162);
Declare_label(mercury__jumpopt__instr_list_14_0_i166);
Declare_label(mercury__jumpopt__instr_list_14_0_i168);
Declare_label(mercury__jumpopt__instr_list_14_0_i172);
Declare_label(mercury__jumpopt__instr_list_14_0_i175);
Declare_label(mercury__jumpopt__instr_list_14_0_i177);
Declare_label(mercury__jumpopt__instr_list_14_0_i159);
Declare_label(mercury__jumpopt__instr_list_14_0_i179);
Declare_label(mercury__jumpopt__instr_list_14_0_i181);
Declare_label(mercury__jumpopt__instr_list_14_0_i183);
Declare_label(mercury__jumpopt__instr_list_14_0_i185);
Declare_label(mercury__jumpopt__instr_list_14_0_i187);
Declare_label(mercury__jumpopt__instr_list_14_0_i189);
Declare_label(mercury__jumpopt__instr_list_14_0_i191);
Declare_label(mercury__jumpopt__instr_list_14_0_i192);
Declare_label(mercury__jumpopt__instr_list_14_0_i198);
Declare_label(mercury__jumpopt__instr_list_14_0_i196);
Declare_label(mercury__jumpopt__instr_list_14_0_i195);
Declare_label(mercury__jumpopt__instr_list_14_0_i202);
Declare_label(mercury__jumpopt__instr_list_14_0_i1427);
Declare_label(mercury__jumpopt__instr_list_14_0_i210);
Declare_label(mercury__jumpopt__instr_list_14_0_i182);
Declare_label(mercury__jumpopt__instr_list_14_0_i215);
Declare_label(mercury__jumpopt__instr_list_14_0_i217);
Declare_label(mercury__jumpopt__instr_list_14_0_i156);
Declare_label(mercury__jumpopt__instr_list_14_0_i224);
Declare_label(mercury__jumpopt__instr_list_14_0_i227);
Declare_label(mercury__jumpopt__instr_list_14_0_i1088);
Declare_label(mercury__jumpopt__instr_list_14_0_i225);
Declare_label(mercury__jumpopt__instr_list_14_0_i229);
Declare_label(mercury__jumpopt__instr_list_14_0_i235);
Declare_label(mercury__jumpopt__instr_list_14_0_i237);
Declare_label(mercury__jumpopt__instr_list_14_0_i242);
Declare_label(mercury__jumpopt__instr_list_14_0_i243);
Declare_label(mercury__jumpopt__instr_list_14_0_i244);
Declare_label(mercury__jumpopt__instr_list_14_0_i3);
Declare_static(mercury__jumpopt__needs_workaround_2_0);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i3);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i10);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i9);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i16);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i19);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i13);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i14);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i30);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i1029);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i33);
Declare_label(mercury__jumpopt__needs_workaround_2_0_i1);
Declare_static(mercury__jumpopt__adjust_livevals_3_0);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i5);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i9);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i8);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i2);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
Declare_label(mercury__jumpopt__adjust_livevals_3_0_i3);
Declare_static(mercury__jumpopt__short_labels_3_0);
Declare_label(mercury__jumpopt__short_labels_3_0_i5);
Declare_label(mercury__jumpopt__short_labels_3_0_i7);
Declare_label(mercury__jumpopt__short_labels_3_0_i4);
Declare_label(mercury__jumpopt__short_labels_3_0_i9);
Declare_label(mercury__jumpopt__short_labels_3_0_i3);
Declare_static(mercury__jumpopt__final_dest_5_0);
Declare_static(mercury__jumpopt__final_dest_2_6_0);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i1005);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i5);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i4);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i8);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i11);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i2);
Declare_label(mercury__jumpopt__final_dest_2_6_0_i14);
Declare_static(mercury__jumpopt__short_labels_rval_3_0);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i4);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i5);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i1015);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i8);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i9);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i10);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i11);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i12);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i13);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i16);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i17);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i20);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i23);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i27);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i29);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i33);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i35);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i37);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i34);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i39);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i40);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i41);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i42);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i43);
Declare_label(mercury__jumpopt__short_labels_rval_3_0_i2);
Declare_static(mercury__jumpopt__short_labels_maybe_rvals_3_0);
Declare_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i5);
Declare_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i6);
Declare_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i7);
Declare_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i3);
Declare_static(mercury__jumpopt__short_labels_lval_3_0);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i4);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i5);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i6);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i7);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i8);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i9);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i12);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i15);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i16);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i17);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i18);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i19);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i20);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i21);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i22);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i23);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i24);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i25);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i26);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i27);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i28);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i29);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i30);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i1009);
Declare_label(mercury__jumpopt__short_labels_lval_3_0_i2);

static const struct mercury_data_jumpopt__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_jumpopt__common_0;

static const struct mercury_data_jumpopt__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_jumpopt__common_1;

static const struct mercury_data_jumpopt__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_jumpopt__common_2;

static const struct mercury_data_jumpopt__common_3_struct {
	String f1;
}  mercury_data_jumpopt__common_3;

static const struct mercury_data_jumpopt__common_4_struct {
	Word * f1;
}  mercury_data_jumpopt__common_4;

static const struct mercury_data_jumpopt__common_5_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_5;

static const struct mercury_data_jumpopt__common_6_struct {
	Word * f1;
}  mercury_data_jumpopt__common_6;

static const struct mercury_data_jumpopt__common_7_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_jumpopt__common_7;

static const struct mercury_data_jumpopt__common_8_struct {
	Word * f1;
	String f2;
}  mercury_data_jumpopt__common_8;

static const struct mercury_data_jumpopt__common_9_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_9;

static const struct mercury_data_jumpopt__common_10_struct {
	Word * f1;
}  mercury_data_jumpopt__common_10;

static const struct mercury_data_jumpopt__common_11_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_jumpopt__common_11;

static const struct mercury_data_jumpopt__common_12_struct {
	Word * f1;
	String f2;
}  mercury_data_jumpopt__common_12;

static const struct mercury_data_jumpopt__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_13;

static const struct mercury_data_jumpopt__common_14_struct {
	Word * f1;
}  mercury_data_jumpopt__common_14;

static const struct mercury_data_jumpopt__common_15_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_jumpopt__common_15;

static const struct mercury_data_jumpopt__common_16_struct {
	Word * f1;
	String f2;
}  mercury_data_jumpopt__common_16;

static const struct mercury_data_jumpopt__common_17_struct {
	Word * f1;
}  mercury_data_jumpopt__common_17;

static const struct mercury_data_jumpopt__common_18_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_jumpopt__common_18;

static const struct mercury_data_jumpopt__common_19_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_19;

static const struct mercury_data_jumpopt__common_20_struct {
	Word * f1;
	String f2;
}  mercury_data_jumpopt__common_20;

static const struct mercury_data_jumpopt__common_21_struct {
	Word * f1;
	Word * f2;
}  mercury_data_jumpopt__common_21;

static const struct mercury_data_jumpopt__common_22_struct {
	Integer f1;
	Integer f2;
}  mercury_data_jumpopt__common_22;

static const struct mercury_data_jumpopt__common_23_struct {
	String f1;
}  mercury_data_jumpopt__common_23;

static const struct mercury_data_jumpopt__common_24_struct {
	Word * f1;
	String f2;
}  mercury_data_jumpopt__common_24;

static const struct mercury_data_jumpopt__common_25_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_25;

static const struct mercury_data_jumpopt__common_26_struct {
	Integer f1;
	Word * f2;
}  mercury_data_jumpopt__common_26;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_jumpopt__common_0_struct mercury_data_jumpopt__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_jumpopt__common_1_struct mercury_data_jumpopt__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_jumpopt__common_2_struct mercury_data_jumpopt__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0)
};

static const struct mercury_data_jumpopt__common_3_struct mercury_data_jumpopt__common_3 = {
	MR_string_const("", 0)
};

static const struct mercury_data_jumpopt__common_4_struct mercury_data_jumpopt__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))
};

static const struct mercury_data_jumpopt__common_5_struct mercury_data_jumpopt__common_5 = {
	(Integer) 6,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_4)
};

static const struct mercury_data_jumpopt__common_6_struct mercury_data_jumpopt__common_6 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_5)
};

static const struct mercury_data_jumpopt__common_7_struct mercury_data_jumpopt__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_6)
};

static const struct mercury_data_jumpopt__common_8_struct mercury_data_jumpopt__common_8 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_7),
	MR_string_const("discard this frame", 18)
};

static const struct mercury_data_jumpopt__common_9_struct mercury_data_jumpopt__common_9 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_4)
};

static const struct mercury_data_jumpopt__common_10_struct mercury_data_jumpopt__common_10 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_9)
};

static const struct mercury_data_jumpopt__common_11_struct mercury_data_jumpopt__common_11 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_10)
};

static const struct mercury_data_jumpopt__common_12_struct mercury_data_jumpopt__common_12 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_11),
	MR_string_const("setup PC on return from tailcall", 32)
};

static const struct mercury_data_jumpopt__common_13_struct mercury_data_jumpopt__common_13 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_4)
};

static const struct mercury_data_jumpopt__common_14_struct mercury_data_jumpopt__common_14 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_13)
};

static const struct mercury_data_jumpopt__common_15_struct mercury_data_jumpopt__common_15 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_14)
};

static const struct mercury_data_jumpopt__common_16_struct mercury_data_jumpopt__common_16 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_15),
	MR_string_const("setup curfr on return from tailcall", 35)
};

static const struct mercury_data_jumpopt__common_17_struct mercury_data_jumpopt__common_17 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_jumpopt__common_18_struct mercury_data_jumpopt__common_18 = {
	(Integer) 3,
	(Integer) 13,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_17)
};

static const struct mercury_data_jumpopt__common_19_struct mercury_data_jumpopt__common_19 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_jumpopt__common_20_struct mercury_data_jumpopt__common_20 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_19),
	MR_string_const("shortcircuit", 12)
};

static const struct mercury_data_jumpopt__common_21_struct mercury_data_jumpopt__common_21 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_jumpopt__common_22_struct mercury_data_jumpopt__common_22 = {
	(Integer) 0,
	(Integer) 1
};

static const struct mercury_data_jumpopt__common_23_struct mercury_data_jumpopt__common_23 = {
	MR_string_const("r1 = old r1", 11)
};

static const struct mercury_data_jumpopt__common_24_struct mercury_data_jumpopt__common_24 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_23),
	MR_string_const("", 0)
};

static const struct mercury_data_jumpopt__common_25_struct mercury_data_jumpopt__common_25 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_jumpopt__common_26_struct mercury_data_jumpopt__common_26 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__opt_util__get_prologue_5_0);
Declare_entry(mercury__opt_util__new_label_no_3_0);
Declare_entry(mercury__opt_util__filter_out_bad_livevals_2_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(jumpopt_module0)
	init_entry(mercury__jumpopt__jumpopt_main_8_0);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i2);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i3);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i4);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i5);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i6);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i7);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i8);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i9);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i10);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i13);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i14);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i11);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i15);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i16);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i17);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i19);
	init_label(mercury__jumpopt__jumpopt_main_8_0_i18);
BEGIN_CODE

/* code for predicate 'jumpopt_main'/8 in mode 0 */
Define_entry(mercury__jumpopt__jumpopt_main_8_0);
	MR_incr_sp_push_msg(12, "jumpopt:jumpopt_main/8");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i2,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i2);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_1);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i3,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i3);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i4,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i4);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i5,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i6,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i6);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i7,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	r8 = MR_stackvar(10);
	r9 = MR_stackvar(11);
	call_localret(STATIC(mercury__jumpopt__build_maps_15_0),
		mercury__jumpopt__jumpopt_main_8_0_i8,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i8);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	MR_stackvar(7) = r3;
	MR_stackvar(8) = r4;
	MR_stackvar(9) = r5;
	MR_stackvar(10) = r6;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i9,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	call_localret(STATIC(mercury__jumpopt__build_forkmap_4_0),
		mercury__jumpopt__jumpopt_main_8_0_i10,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i10);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	if (((Integer) MR_stackvar(6) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__jumpopt_main_8_0_i11);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_util__get_prologue_5_0),
		mercury__jumpopt__jumpopt_main_8_0_i13,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i13);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 500;
	call_localret(ENTRY(mercury__opt_util__new_label_no_3_0),
		mercury__jumpopt__jumpopt_main_8_0_i14,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i14);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r10 = MR_stackvar(2);
	r11 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	r9 = MR_stackvar(10);
	r8 = MR_stackvar(6);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 1, mercury__jumpopt__jumpopt_main_8_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__jumpopt_main_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(11);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_3);
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__jumpopt_main_8_0_i15);
	}
Define_label(mercury__jumpopt__jumpopt_main_8_0_i11);
	r8 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	r9 = MR_stackvar(10);
	r10 = MR_stackvar(2);
	r11 = MR_stackvar(3);
	r12 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i15);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__jumpopt__instr_list_14_0),
		mercury__jumpopt__jumpopt_main_8_0_i16,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__filter_out_bad_livevals_2_0),
		mercury__jumpopt__jumpopt_main_8_0_i17,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i17);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	r3 = MR_stackvar(1);
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__jumpopt__jumpopt_main_8_0_i19,
		ENTRY(mercury__jumpopt__jumpopt_main_8_0));
Define_label(mercury__jumpopt__jumpopt_main_8_0_i19);
	update_prof_current_proc(LABEL(mercury__jumpopt__jumpopt_main_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__jumpopt_main_8_0_i18);
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__jumpopt__jumpopt_main_8_0_i18);
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__skip_comments_2_0);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__opt_util__skip_comments_livevals_2_0);
Declare_entry(mercury__opt_util__is_proceed_next_2_0);
Declare_entry(mercury__opt_util__is_sdproceed_next_2_0);
Declare_entry(mercury__opt_util__is_succeed_next_2_0);
Declare_entry(mercury__opt_util__find_no_fallthrough_2_0);

BEGIN_MODULE(jumpopt_module1)
	init_entry(mercury__jumpopt__build_maps_15_0);
	init_label(mercury__jumpopt__build_maps_15_0_i1010);
	init_label(mercury__jumpopt__build_maps_15_0_i6);
	init_label(mercury__jumpopt__build_maps_15_0_i7);
	init_label(mercury__jumpopt__build_maps_15_0_i11);
	init_label(mercury__jumpopt__build_maps_15_0_i13);
	init_label(mercury__jumpopt__build_maps_15_0_i16);
	init_label(mercury__jumpopt__build_maps_15_0_i14);
	init_label(mercury__jumpopt__build_maps_15_0_i17);
	init_label(mercury__jumpopt__build_maps_15_0_i20);
	init_label(mercury__jumpopt__build_maps_15_0_i22);
	init_label(mercury__jumpopt__build_maps_15_0_i18);
	init_label(mercury__jumpopt__build_maps_15_0_i23);
	init_label(mercury__jumpopt__build_maps_15_0_i26);
	init_label(mercury__jumpopt__build_maps_15_0_i28);
	init_label(mercury__jumpopt__build_maps_15_0_i24);
	init_label(mercury__jumpopt__build_maps_15_0_i29);
	init_label(mercury__jumpopt__build_maps_15_0_i32);
	init_label(mercury__jumpopt__build_maps_15_0_i34);
	init_label(mercury__jumpopt__build_maps_15_0_i30);
	init_label(mercury__jumpopt__build_maps_15_0_i35);
	init_label(mercury__jumpopt__build_maps_15_0_i39);
	init_label(mercury__jumpopt__build_maps_15_0_i43);
	init_label(mercury__jumpopt__build_maps_15_0_i44);
	init_label(mercury__jumpopt__build_maps_15_0_i37);
	init_label(mercury__jumpopt__build_maps_15_0_i4);
	init_label(mercury__jumpopt__build_maps_15_0_i3);
BEGIN_CODE

/* code for predicate 'build_maps'/15 in mode 0 */
Define_static(mercury__jumpopt__build_maps_15_0);
	MR_incr_sp_push_msg(15, "jumpopt:build_maps/15");
	MR_stackvar(15) = (Word) MR_succip;
Define_label(mercury__jumpopt__build_maps_15_0_i1010);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i3);
	r10 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i4);
	MR_stackvar(10) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	r1 = r10;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__build_maps_15_0_i6,
		STATIC(mercury__jumpopt__build_maps_15_0));
	}
Define_label(mercury__jumpopt__build_maps_15_0_i6);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i7);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__jumpopt__build_maps_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_1);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i11,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i7);
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_1);
	r4 = MR_stackvar(10);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i11,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i11);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__opt_util__skip_comments_livevals_2_0),
		mercury__jumpopt__build_maps_15_0_i13,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i13);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i14);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i16,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i17);
Define_label(mercury__jumpopt__build_maps_15_0_i14);
	r1 = MR_stackvar(5);
Define_label(mercury__jumpopt__build_maps_15_0_i17);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__opt_util__is_proceed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i20,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i20);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i18);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i22,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i22);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i23);
Define_label(mercury__jumpopt__build_maps_15_0_i18);
	r1 = MR_stackvar(5);
	MR_stackvar(12) = MR_stackvar(6);
Define_label(mercury__jumpopt__build_maps_15_0_i23);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i26,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i26);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i24);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i28,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i28);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i29);
Define_label(mercury__jumpopt__build_maps_15_0_i24);
	r1 = MR_stackvar(5);
	MR_stackvar(13) = MR_stackvar(7);
Define_label(mercury__jumpopt__build_maps_15_0_i29);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__opt_util__is_succeed_next_2_0),
		mercury__jumpopt__build_maps_15_0_i32,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i32);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i30);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i34,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i34);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i35);
Define_label(mercury__jumpopt__build_maps_15_0_i30);
	r1 = MR_stackvar(5);
	MR_stackvar(14) = MR_stackvar(8);
Define_label(mercury__jumpopt__build_maps_15_0_i35);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i37);
	if ((MR_tag(MR_stackvar(10)) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i39);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i37);
Define_label(mercury__jumpopt__build_maps_15_0_i39);
	call_localret(ENTRY(mercury__opt_util__find_no_fallthrough_2_0),
		mercury__jumpopt__build_maps_15_0_i43,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i43);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_maps_15_0_i44,
		STATIC(mercury__jumpopt__build_maps_15_0));
Define_label(mercury__jumpopt__build_maps_15_0_i44);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_maps_15_0));
	r5 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(11);
	r7 = MR_stackvar(12);
	r8 = MR_stackvar(13);
	r9 = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(15);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1010);
Define_label(mercury__jumpopt__build_maps_15_0_i37);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(9);
	r6 = MR_stackvar(11);
	r4 = MR_stackvar(3);
	r7 = MR_stackvar(12);
	r8 = MR_stackvar(13);
	r9 = MR_stackvar(14);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(15);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1010);
Define_label(mercury__jumpopt__build_maps_15_0_i4);
	r1 = r10;
	MR_succip = (Code *) MR_stackvar(15);
	GOTO_LABEL(mercury__jumpopt__build_maps_15_0_i1010);
Define_label(mercury__jumpopt__build_maps_15_0_i3);
	r1 = r4;
	r2 = r5;
	r3 = r6;
	r4 = r7;
	r5 = r8;
	r6 = r9;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__is_forkproceed_next_3_0);

BEGIN_MODULE(jumpopt_module2)
	init_entry(mercury__jumpopt__build_forkmap_4_0);
	init_label(mercury__jumpopt__build_forkmap_4_0_i1003);
	init_label(mercury__jumpopt__build_forkmap_4_0_i7);
	init_label(mercury__jumpopt__build_forkmap_4_0_i9);
	init_label(mercury__jumpopt__build_forkmap_4_0_i4);
	init_label(mercury__jumpopt__build_forkmap_4_0_i5);
	init_label(mercury__jumpopt__build_forkmap_4_0_i3);
BEGIN_CODE

/* code for predicate 'build_forkmap'/4 in mode 0 */
Define_static(mercury__jumpopt__build_forkmap_4_0);
	MR_incr_sp_push_msg(5, "jumpopt:build_forkmap/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__jumpopt__build_forkmap_4_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i5);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__opt_util__is_forkproceed_next_3_0),
		mercury__jumpopt__build_forkmap_4_0_i7,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
	}
Define_label(mercury__jumpopt__build_forkmap_4_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_forkmap_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i4);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__jumpopt__build_forkmap_4_0_i9,
		STATIC(mercury__jumpopt__build_forkmap_4_0));
Define_label(mercury__jumpopt__build_forkmap_4_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__build_forkmap_4_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i1003);
Define_label(mercury__jumpopt__build_forkmap_4_0_i4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
Define_label(mercury__jumpopt__build_forkmap_4_0_i5);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__jumpopt__build_forkmap_4_0_i1003);
Define_label(mercury__jumpopt__build_forkmap_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__opt_util__filter_out_livevals_2_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury____Unify___llds__label_0_0);
Declare_entry(mercury__opt_util__is_this_label_next_3_0);
Declare_entry(mercury__opt_util__filter_out_labels_2_0);
Declare_entry(mercury__map__delete_3_1);
Declare_entry(mercury__opt_util__can_instr_fall_through_2_0);
Declare_entry(mercury__code_util__neg_rval_2_0);
Declare_entry(mercury__opt_util__filter_out_r1_3_0);
Declare_entry(mercury____Unify___llds__rval_0_0);

BEGIN_MODULE(jumpopt_module3)
	init_entry(mercury__jumpopt__instr_list_14_0);
	init_label(mercury__jumpopt__instr_list_14_0_i4);
	init_label(mercury__jumpopt__instr_list_14_0_i11);
	init_label(mercury__jumpopt__instr_list_14_0_i10);
	init_label(mercury__jumpopt__instr_list_14_0_i13);
	init_label(mercury__jumpopt__instr_list_14_0_i18);
	init_label(mercury__jumpopt__instr_list_14_0_i20);
	init_label(mercury__jumpopt__instr_list_14_0_i8);
	init_label(mercury__jumpopt__instr_list_14_0_i9);
	init_label(mercury__jumpopt__instr_list_14_0_i25);
	init_label(mercury__jumpopt__instr_list_14_0_i30);
	init_label(mercury__jumpopt__instr_list_14_0_i22);
	init_label(mercury__jumpopt__instr_list_14_0_i23);
	init_label(mercury__jumpopt__instr_list_14_0_i37);
	init_label(mercury__jumpopt__instr_list_14_0_i47);
	init_label(mercury__jumpopt__instr_list_14_0_i33);
	init_label(mercury__jumpopt__instr_list_14_0_i34);
	init_label(mercury__jumpopt__instr_list_14_0_i54);
	init_label(mercury__jumpopt__instr_list_14_0_i64);
	init_label(mercury__jumpopt__instr_list_14_0_i49);
	init_label(mercury__jumpopt__instr_list_14_0_i50);
	init_label(mercury__jumpopt__instr_list_14_0_i67);
	init_label(mercury__jumpopt__instr_list_14_0_i71);
	init_label(mercury__jumpopt__instr_list_14_0_i73);
	init_label(mercury__jumpopt__instr_list_14_0_i76);
	init_label(mercury__jumpopt__instr_list_14_0_i74);
	init_label(mercury__jumpopt__instr_list_14_0_i5);
	init_label(mercury__jumpopt__instr_list_14_0_i89);
	init_label(mercury__jumpopt__instr_list_14_0_i87);
	init_label(mercury__jumpopt__instr_list_14_0_i95);
	init_label(mercury__jumpopt__instr_list_14_0_i91);
	init_label(mercury__jumpopt__instr_list_14_0_i92);
	init_label(mercury__jumpopt__instr_list_14_0_i98);
	init_label(mercury__jumpopt__instr_list_14_0_i100);
	init_label(mercury__jumpopt__instr_list_14_0_i97);
	init_label(mercury__jumpopt__instr_list_14_0_i103);
	init_label(mercury__jumpopt__instr_list_14_0_i105);
	init_label(mercury__jumpopt__instr_list_14_0_i102);
	init_label(mercury__jumpopt__instr_list_14_0_i108);
	init_label(mercury__jumpopt__instr_list_14_0_i107);
	init_label(mercury__jumpopt__instr_list_14_0_i112);
	init_label(mercury__jumpopt__instr_list_14_0_i114);
	init_label(mercury__jumpopt__instr_list_14_0_i115);
	init_label(mercury__jumpopt__instr_list_14_0_i117);
	init_label(mercury__jumpopt__instr_list_14_0_i118);
	init_label(mercury__jumpopt__instr_list_14_0_i119);
	init_label(mercury__jumpopt__instr_list_14_0_i120);
	init_label(mercury__jumpopt__instr_list_14_0_i111);
	init_label(mercury__jumpopt__instr_list_14_0_i122);
	init_label(mercury__jumpopt__instr_list_14_0_i124);
	init_label(mercury__jumpopt__instr_list_14_0_i125);
	init_label(mercury__jumpopt__instr_list_14_0_i126);
	init_label(mercury__jumpopt__instr_list_14_0_i127);
	init_label(mercury__jumpopt__instr_list_14_0_i131);
	init_label(mercury__jumpopt__instr_list_14_0_i130);
	init_label(mercury__jumpopt__instr_list_14_0_i134);
	init_label(mercury__jumpopt__instr_list_14_0_i136);
	init_label(mercury__jumpopt__instr_list_14_0_i139);
	init_label(mercury__jumpopt__instr_list_14_0_i135);
	init_label(mercury__jumpopt__instr_list_14_0_i84);
	init_label(mercury__jumpopt__instr_list_14_0_i150);
	init_label(mercury__jumpopt__instr_list_14_0_i152);
	init_label(mercury__jumpopt__instr_list_14_0_i151);
	init_label(mercury__jumpopt__instr_list_14_0_i154);
	init_label(mercury__jumpopt__instr_list_14_0_i1264);
	init_label(mercury__jumpopt__instr_list_14_0_i1265);
	init_label(mercury__jumpopt__instr_list_14_0_i160);
	init_label(mercury__jumpopt__instr_list_14_0_i164);
	init_label(mercury__jumpopt__instr_list_14_0_i162);
	init_label(mercury__jumpopt__instr_list_14_0_i166);
	init_label(mercury__jumpopt__instr_list_14_0_i168);
	init_label(mercury__jumpopt__instr_list_14_0_i172);
	init_label(mercury__jumpopt__instr_list_14_0_i175);
	init_label(mercury__jumpopt__instr_list_14_0_i177);
	init_label(mercury__jumpopt__instr_list_14_0_i159);
	init_label(mercury__jumpopt__instr_list_14_0_i179);
	init_label(mercury__jumpopt__instr_list_14_0_i181);
	init_label(mercury__jumpopt__instr_list_14_0_i183);
	init_label(mercury__jumpopt__instr_list_14_0_i185);
	init_label(mercury__jumpopt__instr_list_14_0_i187);
	init_label(mercury__jumpopt__instr_list_14_0_i189);
	init_label(mercury__jumpopt__instr_list_14_0_i191);
	init_label(mercury__jumpopt__instr_list_14_0_i192);
	init_label(mercury__jumpopt__instr_list_14_0_i198);
	init_label(mercury__jumpopt__instr_list_14_0_i196);
	init_label(mercury__jumpopt__instr_list_14_0_i195);
	init_label(mercury__jumpopt__instr_list_14_0_i202);
	init_label(mercury__jumpopt__instr_list_14_0_i1427);
	init_label(mercury__jumpopt__instr_list_14_0_i210);
	init_label(mercury__jumpopt__instr_list_14_0_i182);
	init_label(mercury__jumpopt__instr_list_14_0_i215);
	init_label(mercury__jumpopt__instr_list_14_0_i217);
	init_label(mercury__jumpopt__instr_list_14_0_i156);
	init_label(mercury__jumpopt__instr_list_14_0_i224);
	init_label(mercury__jumpopt__instr_list_14_0_i227);
	init_label(mercury__jumpopt__instr_list_14_0_i1088);
	init_label(mercury__jumpopt__instr_list_14_0_i225);
	init_label(mercury__jumpopt__instr_list_14_0_i229);
	init_label(mercury__jumpopt__instr_list_14_0_i235);
	init_label(mercury__jumpopt__instr_list_14_0_i237);
	init_label(mercury__jumpopt__instr_list_14_0_i242);
	init_label(mercury__jumpopt__instr_list_14_0_i243);
	init_label(mercury__jumpopt__instr_list_14_0_i244);
	init_label(mercury__jumpopt__instr_list_14_0_i3);
BEGIN_CODE

/* code for predicate 'instr_list'/14 in mode 0 */
Define_static(mercury__jumpopt__instr_list_14_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i3);
	MR_incr_sp_push_msg(38, "jumpopt:instr_list/14");
	MR_stackvar(38) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(13) = MR_tempr1;
	MR_stackvar(14) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(16) = r1;
	MR_stackvar(15) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = (Word) MR_string_const(" (redirected return)", 20);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r12;
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_14_0_i4,
		STATIC(mercury__jumpopt__instr_list_14_0));
	}
Define_label(mercury__jumpopt__instr_list_14_0_i4);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if ((MR_tag(MR_stackvar(15)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i5);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 2);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i5);
	r3 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 5);
	r4 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 4);
	r5 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 3);
	r6 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r7 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i11);
	MR_stackvar(17) = r1;
	MR_stackvar(21) = r4;
	MR_stackvar(22) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(5);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(20) = r5;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i10);
Define_label(mercury__jumpopt__instr_list_14_0_i11);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i9);
	MR_stackvar(17) = r1;
	MR_stackvar(21) = r4;
	MR_stackvar(22) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(5);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(20) = r5;
Define_label(mercury__jumpopt__instr_list_14_0_i10);
	MR_stackvar(5) = r3;
	MR_stackvar(19) = r4;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i13,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i13);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i8);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i8);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i8);
	MR_stackvar(12) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(19);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__jumpopt__instr_list_14_0_i18,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i18);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i8);
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__opt_util__filter_out_livevals_2_0),
		mercury__jumpopt__instr_list_14_0_i20,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i20);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(18);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(17);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
	}
Define_label(mercury__jumpopt__instr_list_14_0_i8);
	r1 = MR_stackvar(17);
	r7 = MR_stackvar(18);
	r6 = MR_stackvar(19);
	r5 = MR_stackvar(20);
	r4 = MR_stackvar(21);
	r3 = MR_stackvar(22);
Define_label(mercury__jumpopt__instr_list_14_0_i9);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i23);
	MR_stackvar(21) = r4;
	MR_stackvar(17) = r1;
	MR_stackvar(22) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(7);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(19) = r6;
	MR_stackvar(20) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i25,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i25);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i22);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i22);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i22);
	MR_stackvar(12) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(19);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__jumpopt__instr_list_14_0_i30,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i30);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r2 = MR_stackvar(12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(18);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(17);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
	}
Define_label(mercury__jumpopt__instr_list_14_0_i22);
	r1 = MR_stackvar(17);
	r7 = MR_stackvar(18);
	r6 = MR_stackvar(19);
	r5 = MR_stackvar(20);
	r4 = MR_stackvar(21);
	r3 = MR_stackvar(22);
Define_label(mercury__jumpopt__instr_list_14_0_i23);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i34);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i34);
	MR_stackvar(21) = r4;
	MR_stackvar(17) = r1;
	MR_stackvar(22) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(8);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(19) = r6;
	MR_stackvar(20) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i37,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i37);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(19);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__jumpopt__instr_list_14_0_i47,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i47);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i33);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_8);
	MR_stackvar(23) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_12);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_16);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r15, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(18);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), r14, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r15, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 0) = r15;
	MR_field(MR_mktag(0), r15, (Integer) 0) = MR_tempr1;
	r1 = MR_stackvar(14);
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i33);
	r1 = MR_stackvar(17);
	r7 = MR_stackvar(18);
	r6 = MR_stackvar(19);
	r5 = MR_stackvar(20);
	r4 = MR_stackvar(21);
	r3 = MR_stackvar(22);
Define_label(mercury__jumpopt__instr_list_14_0_i34);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i50);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i50);
	if (((Integer) MR_stackvar(11) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i50);
	MR_stackvar(21) = r4;
	MR_stackvar(17) = r1;
	MR_stackvar(22) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_stackvar(11), (Integer) 0);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(8);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(19) = r6;
	MR_stackvar(20) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i54,
		STATIC(mercury__jumpopt__instr_list_14_0));
	}
Define_label(mercury__jumpopt__instr_list_14_0_i54);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(19);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__jumpopt__instr_list_14_0_i64,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i64);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i49);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(MR_stackvar(23), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r12, (Integer) 1) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_18);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 1, mercury__jumpopt__instr_list_14_0, "llds:code_addr/0");
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) MR_string_const("branch around if cannot tail call", 33);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(16);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r12, (Integer) 2) = r13;
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 0) = r1;
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r12;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_8);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_12);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_16);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r16, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(18);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(0), r16, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r15, (Integer) 0) = r16;
	MR_field(MR_mktag(0), r16, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r17, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r18, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r18, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r17, (Integer) 1) = (Word) MR_string_const("non tail call", 13);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(16);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r18, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r16, (Integer) 0) = r17;
	MR_field(MR_mktag(0), r17, (Integer) 0) = r18;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = MR_tempr1;
	r1 = MR_stackvar(14);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 1, mercury__jumpopt__instr_list_14_0, "std_util:maybe/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = ((Integer) MR_stackvar(16) + (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i49);
	r1 = MR_stackvar(17);
	r7 = MR_stackvar(18);
	r6 = MR_stackvar(19);
	r5 = MR_stackvar(20);
	r4 = MR_stackvar(21);
	r3 = MR_stackvar(22);
Define_label(mercury__jumpopt__instr_list_14_0_i50);
	MR_stackvar(21) = r4;
	MR_stackvar(17) = r1;
	MR_stackvar(22) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = MR_stackvar(2);
	r4 = r6;
	MR_stackvar(18) = r7;
	MR_stackvar(19) = r6;
	MR_stackvar(20) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i67,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i67);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	MR_stackvar(12) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(19);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__jumpopt__instr_list_14_0_i71,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i71);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	r1 = MR_stackvar(19);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_14_0_i73,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i73);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	MR_stackvar(26) = r1;
	r1 = MR_stackvar(19);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_14_0_i76,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i76);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i74);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r1 = MR_stackvar(14);
	r12 = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_stackvar(23) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i74);
	r1 = MR_stackvar(26);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(MR_stackvar(23), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r13, MR_mktag(3), (Integer) 6, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r13, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r13, (Integer) 1) = MR_stackvar(18);
	MR_field(MR_mktag(3), r13, (Integer) 5) = MR_stackvar(22);
	MR_field(MR_mktag(3), r13, (Integer) 4) = MR_stackvar(21);
	MR_field(MR_mktag(3), r13, (Integer) 3) = MR_stackvar(20);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r12, (Integer) 1) = MR_stackvar(17);
	r1 = MR_stackvar(14);
	MR_field(MR_mktag(3), r13, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = r13;
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i5);
	if ((MR_tag(MR_stackvar(15)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i84);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i84);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 1);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i84);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(27) = r2;
	r3 = r1;
	r1 = r2;
	r4 = r2;
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury__opt_util__is_this_label_next_3_0),
		mercury__jumpopt__instr_list_14_0_i89,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i89);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i87);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	MR_stackvar(23) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
Define_label(mercury__jumpopt__instr_list_14_0_i87);
	r2 = MR_stackvar(27);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i92);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i92);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 2);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i92);
	MR_stackvar(27) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury__opt_util__is_this_label_next_3_0),
		mercury__jumpopt__instr_list_14_0_i95,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i95);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i91);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_stackvar(23) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i91);
	r2 = MR_stackvar(27);
Define_label(mercury__jumpopt__instr_list_14_0_i92);
	r4 = r2;
	MR_stackvar(27) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i98,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i98);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i97);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_14_0_i100,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i100);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_21);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i97);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(27);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i103,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i103);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i102);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_14_0_i105,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i105);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_21);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i102);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(27);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i108,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i108);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i107);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i107);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(27);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i112,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i112);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i111);
	r1 = MR_stackvar(27);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_14_0_i114,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i114);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r4 = r1;
	MR_stackvar(12) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i115,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i115);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i111);
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__filter_out_labels_2_0),
		mercury__jumpopt__instr_list_14_0_i117,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i117);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_14_0_i118,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i118);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r4 = MR_stackvar(12);
	MR_stackvar(12) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__jumpopt__instr_list_14_0_i119,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i119);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r4 = r1;
	r1 = MR_stackvar(12);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_3);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	localcall(mercury__jumpopt__instr_list_14_0,
		LABEL(mercury__jumpopt__instr_list_14_0_i120),
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i120);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r12 = r1;
	MR_stackvar(23) = r2;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
Define_label(mercury__jumpopt__instr_list_14_0_i111);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(27);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i122,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i122);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	r1 = MR_stackvar(27);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_14_0_i124,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i124);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(35) = r1;
	r1 = (Word) MR_string_const("shortcircuited jump: ", 21);
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_14_0_i125,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i125);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(28) = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__opt_util__can_instr_fall_through_2_0),
		mercury__jumpopt__instr_list_14_0_i126,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i126);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i127);
	r3 = MR_stackvar(4);
	MR_stackvar(24) = MR_stackvar(14);
	tag_incr_hp_msg(MR_stackvar(29), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(28);
	MR_field(MR_mktag(1), MR_stackvar(29), (Integer) 0) = r1;
	MR_field(MR_mktag(1), MR_stackvar(29), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(35);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i134);
Define_label(mercury__jumpopt__instr_list_14_0_i127);
	r1 = MR_stackvar(27);
	r2 = MR_stackvar(35);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_14_0_i131,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i131);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i130);
	r3 = MR_stackvar(4);
	MR_stackvar(24) = MR_stackvar(14);
	r4 = MR_stackvar(35);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(13);
	MR_stackvar(29) = r1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i134);
Define_label(mercury__jumpopt__instr_list_14_0_i130);
	r3 = MR_stackvar(4);
	MR_stackvar(24) = MR_stackvar(14);
	tag_incr_hp_msg(MR_stackvar(29), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), MR_stackvar(29), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(28);
	r4 = MR_stackvar(35);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(29), (Integer) 0) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	}
Define_label(mercury__jumpopt__instr_list_14_0_i134);
	MR_stackvar(4) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i136,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i136);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i135);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i135);
	r1 = MR_stackvar(1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(29);
	call_localret(STATIC(mercury__jumpopt__adjust_livevals_3_0),
		mercury__jumpopt__instr_list_14_0_i139,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i139);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(23) = r1;
	r1 = MR_stackvar(24);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
Define_label(mercury__jumpopt__instr_list_14_0_i135);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	MR_stackvar(23) = MR_stackvar(29);
	r1 = MR_stackvar(24);
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
Define_label(mercury__jumpopt__instr_list_14_0_i84);
	r3 = MR_stackvar(15);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1264);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1265);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(12) = r1;
	MR_stackvar(30) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__short_labels_3_0),
		mercury__jumpopt__instr_list_14_0_i150,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i150);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(24) = MR_stackvar(14);
	MR_stackvar(25) = MR_stackvar(11);
	MR_stackvar(31) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__jumpopt__instr_list_14_0_i152,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i152);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i151);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r1 = MR_stackvar(14);
	r12 = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_stackvar(23) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i151);
	r1 = MR_stackvar(16);
	r2 = (Word) MR_string_const(" (some shortcircuits)", 21);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_14_0_i154,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i154);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(MR_stackvar(23), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(31);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(30);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r12, (Integer) 1) = r1;
	r1 = MR_stackvar(24);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = MR_tempr1;
	r12 = MR_stackvar(25);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i1264);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r2 != (Integer) 8))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	MR_stackvar(32) = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 1);
	MR_stackvar(37) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__instr_list_14_0_i160,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i1265);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r2 != (Integer) 8))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i156);
	MR_stackvar(32) = MR_const_field(MR_mktag(3), MR_stackvar(15), (Integer) 1);
	MR_stackvar(37) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__instr_list_14_0_i160,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i160);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i162);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i162);
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__instr_list_14_0_i164,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i164);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i166);
Define_label(mercury__jumpopt__instr_list_14_0_i162);
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 0;
Define_label(mercury__jumpopt__instr_list_14_0_i166);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	MR_tempr3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(17) = MR_tempr3;
	if (((Integer) r3 == (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i168);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i168);
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__instr_list_14_0_i172,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i172);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	r1 = MR_stackvar(37);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_14_0_i175,
		STATIC(mercury__jumpopt__instr_list_14_0));
	}
Define_label(mercury__jumpopt__instr_list_14_0_i175);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i159);
	r1 = MR_stackvar(32);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__jumpopt__instr_list_14_0_i177,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i177);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	MR_stackvar(23) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r12 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(17);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r12;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r13, (Integer) 1) = MR_stackvar(18);
	r12 = MR_stackvar(11);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i159);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(37);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i179,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i179);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	r1 = MR_stackvar(37);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__final_dest_5_0),
		mercury__jumpopt__instr_list_14_0_i181,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i181);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(36) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__instr_list_14_0_i183,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i183);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	MR_stackvar(12) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(36);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__instr_list_14_0_i185,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i185);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__is_sdproceed_next_2_0),
		mercury__jumpopt__instr_list_14_0_i187,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i187);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__opt_util__filter_out_r1_3_0),
		mercury__jumpopt__instr_list_14_0_i189,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i189);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	r3 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(18) = r2;
	call_localret(ENTRY(mercury__opt_util__filter_out_r1_3_0),
		mercury__jumpopt__instr_list_14_0_i191,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i191);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r3 = r2;
	MR_stackvar(17) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r2 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__jumpopt__instr_list_14_0_i192,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i192);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	if (((Integer) MR_stackvar(17) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	if (((Integer) MR_stackvar(12) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i196);
	if (((Integer) MR_const_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	r1 = MR_stackvar(32);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__jumpopt__instr_list_14_0_i198,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i198);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i195);
Define_label(mercury__jumpopt__instr_list_14_0_i196);
	if (((Integer) MR_stackvar(12) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	if (((Integer) MR_const_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	r2 = MR_stackvar(32);
Define_label(mercury__jumpopt__instr_list_14_0_i195);
	MR_stackvar(12) = r2;
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_22);
	call_localret(STATIC(mercury__jumpopt__needs_workaround_2_0),
		mercury__jumpopt__instr_list_14_0_i202,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i202);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i182);
	if ((MR_tag(MR_stackvar(12)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1427);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(12), (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1427);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1427);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1427);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_24);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(18);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i1427);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_22);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) MR_string_const("shortcircuit bool computation", 29);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(18);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_jumpopt__common_21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i210,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i210);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(23) = r1;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
Define_label(mercury__jumpopt__instr_list_14_0_i182);
	r1 = MR_stackvar(37);
	r2 = MR_stackvar(36);
	call_localret(ENTRY(mercury____Unify___llds__label_0_0),
		mercury__jumpopt__instr_list_14_0_i215,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i215);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	r1 = (Word) MR_string_const("shortcircuited jump: ", 21);
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_14_0_i217,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i217);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(MR_stackvar(23), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r13, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r13, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r13, (Integer) 1) = MR_stackvar(32);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(36);
	MR_field(MR_mktag(0), r12, (Integer) 1) = r1;
	r1 = MR_stackvar(14);
	MR_field(MR_mktag(3), r13, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = r13;
	r12 = MR_stackvar(11);
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i156);
	r3 = MR_stackvar(15);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i1088);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(12) = r1;
	MR_stackvar(33) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__instr_list_14_0_i224,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i224);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	MR_stackvar(24) = MR_stackvar(14);
	MR_stackvar(25) = MR_stackvar(11);
	MR_stackvar(34) = r1;
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___llds__rval_0_0),
		mercury__jumpopt__instr_list_14_0_i227,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i227);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i225);
Define_label(mercury__jumpopt__instr_list_14_0_i1088);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r1 = MR_stackvar(14);
	r12 = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_stackvar(23) = MR_tempr1;
	GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i235);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i225);
	r1 = MR_stackvar(16);
	r2 = (Word) MR_string_const(" (some shortcircuits)", 21);
	MR_stackvar(11) = MR_stackvar(25);
	MR_stackvar(14) = MR_stackvar(24);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__jumpopt__instr_list_14_0_i229,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i229);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	tag_incr_hp_msg(MR_stackvar(23), MR_mktag(1), (Integer) 2, mercury__jumpopt__instr_list_14_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__jumpopt__instr_list_14_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__jumpopt__instr_list_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(34);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(33);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r12, (Integer) 1) = r1;
	r1 = MR_stackvar(14);
	MR_field(MR_mktag(1), MR_stackvar(23), (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = MR_tempr1;
	r12 = MR_stackvar(11);
	}
Define_label(mercury__jumpopt__instr_list_14_0_i235);
	if ((MR_tag(MR_stackvar(15)) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i242);
	if (((Integer) MR_stackvar(23) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__instr_list_14_0_i237);
	localcall(mercury__jumpopt__instr_list_14_0,
		LABEL(mercury__jumpopt__instr_list_14_0_i243),
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i237);
	r2 = MR_stackvar(15);
Define_label(mercury__jumpopt__instr_list_14_0_i242);
	localcall(mercury__jumpopt__instr_list_14_0,
		LABEL(mercury__jumpopt__instr_list_14_0_i243),
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i243);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r3 = r2;
	MR_stackvar(12) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	r2 = MR_stackvar(23);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__jumpopt__instr_list_14_0_i244,
		STATIC(mercury__jumpopt__instr_list_14_0));
Define_label(mercury__jumpopt__instr_list_14_0_i244);
	update_prof_current_proc(LABEL(mercury__jumpopt__instr_list_14_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(38);
	MR_decr_sp_pop_msg(38);
	proceed();
Define_label(mercury__jumpopt__instr_list_14_0_i3);
	r1 = r12;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___llds__lval_0_0);

BEGIN_MODULE(jumpopt_module4)
	init_entry(mercury__jumpopt__needs_workaround_2_0);
	init_label(mercury__jumpopt__needs_workaround_2_0_i3);
	init_label(mercury__jumpopt__needs_workaround_2_0_i10);
	init_label(mercury__jumpopt__needs_workaround_2_0_i9);
	init_label(mercury__jumpopt__needs_workaround_2_0_i16);
	init_label(mercury__jumpopt__needs_workaround_2_0_i19);
	init_label(mercury__jumpopt__needs_workaround_2_0_i13);
	init_label(mercury__jumpopt__needs_workaround_2_0_i14);
	init_label(mercury__jumpopt__needs_workaround_2_0_i30);
	init_label(mercury__jumpopt__needs_workaround_2_0_i1029);
	init_label(mercury__jumpopt__needs_workaround_2_0_i33);
	init_label(mercury__jumpopt__needs_workaround_2_0_i1);
BEGIN_CODE

/* code for predicate 'needs_workaround'/2 in mode 0 */
Define_static(mercury__jumpopt__needs_workaround_2_0);
	MR_incr_sp_push_msg(4, "jumpopt:needs_workaround/2");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i3);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	if (((Integer) r3 != (Integer) 9))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Unify___llds__lval_0_0),
		STATIC(mercury__jumpopt__needs_workaround_2_0));
	}
Define_label(mercury__jumpopt__needs_workaround_2_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 1) != (Integer) 12))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i10);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i9);
Define_label(mercury__jumpopt__needs_workaround_2_0_i10);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 1) != (Integer) 13))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
Define_label(mercury__jumpopt__needs_workaround_2_0_i9);
	r3 = MR_stackvar(3);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i14);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__jumpopt__needs_workaround_2_0_i16,
		STATIC(mercury__jumpopt__needs_workaround_2_0));
Define_label(mercury__jumpopt__needs_workaround_2_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__needs_workaround_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i19);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i19);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(2), (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(2), (Integer) 2);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 3))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if ((MR_tag(MR_const_field(MR_mktag(3), r1, (Integer) 2)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), r1, (Integer) 2), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), r1, (Integer) 2), (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), r1, (Integer) 2), (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i19);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(2), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(2), (Integer) 1);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1029);
Define_label(mercury__jumpopt__needs_workaround_2_0_i13);
	r1 = MR_stackvar(1);
Define_label(mercury__jumpopt__needs_workaround_2_0_i14);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__jumpopt__needs_workaround_2_0_i30,
		STATIC(mercury__jumpopt__needs_workaround_2_0));
Define_label(mercury__jumpopt__needs_workaround_2_0_i30);
	update_prof_current_proc(LABEL(mercury__jumpopt__needs_workaround_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i33);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i33);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 1) != (Integer) 3))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 2)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 2), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 2), (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 2), (Integer) 2), (Integer) 1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
Define_label(mercury__jumpopt__needs_workaround_2_0_i1029);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__needs_workaround_2_0_i33);
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 1), (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__needs_workaround_2_0_i1029);
Define_label(mercury__jumpopt__needs_workaround_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury____Unify___set__set_1_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(jumpopt_module5)
	init_entry(mercury__jumpopt__adjust_livevals_3_0);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i5);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i9);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i8);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i2);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
	init_label(mercury__jumpopt__adjust_livevals_3_0_i3);
BEGIN_CODE

/* code for predicate 'adjust_livevals'/3 in mode 0 */
Define_static(mercury__jumpopt__adjust_livevals_3_0);
	MR_incr_sp_push_msg(3, "jumpopt:adjust_livevals/3");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i1005);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__jumpopt__adjust_livevals_3_0_i5,
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
Define_label(mercury__jumpopt__adjust_livevals_3_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__adjust_livevals_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i2);
	r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury__jumpopt__adjust_livevals_3_0_i9,
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
	}
Define_label(mercury__jumpopt__adjust_livevals_3_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__adjust_livevals_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i8);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__jumpopt__adjust_livevals_3_0_i8);
	r1 = (Word) MR_string_const("betweenLivevals and prevLivevals differ in jumpopt", 50);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__jumpopt__adjust_livevals_3_0));
Define_label(mercury__jumpopt__adjust_livevals_3_0_i2);
	r2 = MR_stackvar(1);
	GOTO_LABEL(mercury__jumpopt__adjust_livevals_3_0_i3);
Define_label(mercury__jumpopt__adjust_livevals_3_0_i1005);
	r1 = r2;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__jumpopt__adjust_livevals_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(jumpopt_module6)
	init_entry(mercury__jumpopt__short_labels_3_0);
	init_label(mercury__jumpopt__short_labels_3_0_i5);
	init_label(mercury__jumpopt__short_labels_3_0_i7);
	init_label(mercury__jumpopt__short_labels_3_0_i4);
	init_label(mercury__jumpopt__short_labels_3_0_i9);
	init_label(mercury__jumpopt__short_labels_3_0_i3);
BEGIN_CODE

/* code for predicate 'short_labels'/3 in mode 0 */
Define_static(mercury__jumpopt__short_labels_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__short_labels_3_0_i3);
	MR_incr_sp_push_msg(5, "jumpopt:short_labels/3");
	MR_stackvar(5) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__short_labels_3_0_i5,
		STATIC(mercury__jumpopt__short_labels_3_0));
Define_label(mercury__jumpopt__short_labels_3_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__short_labels_3_0_i4);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__jumpopt__final_dest_2_6_0),
		mercury__jumpopt__short_labels_3_0_i7,
		STATIC(mercury__jumpopt__short_labels_3_0));
Define_label(mercury__jumpopt__short_labels_3_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_3_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__jumpopt__short_labels_3_0,
		LABEL(mercury__jumpopt__short_labels_3_0_i9),
		STATIC(mercury__jumpopt__short_labels_3_0));
Define_label(mercury__jumpopt__short_labels_3_0_i4);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	MR_stackvar(4) = MR_stackvar(2);
	localcall(mercury__jumpopt__short_labels_3_0,
		LABEL(mercury__jumpopt__short_labels_3_0_i9),
		STATIC(mercury__jumpopt__short_labels_3_0));
Define_label(mercury__jumpopt__short_labels_3_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__short_labels_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__jumpopt__short_labels_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(jumpopt_module7)
	init_entry(mercury__jumpopt__final_dest_5_0);
BEGIN_CODE

/* code for predicate 'final_dest'/5 in mode 0 */
Define_static(mercury__jumpopt__final_dest_5_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__jumpopt__final_dest_2_6_0),
		STATIC(mercury__jumpopt__final_dest_5_0));
END_MODULE

Declare_entry(mercury__list__member_2_0);

BEGIN_MODULE(jumpopt_module8)
	init_entry(mercury__jumpopt__final_dest_2_6_0);
	init_label(mercury__jumpopt__final_dest_2_6_0_i1005);
	init_label(mercury__jumpopt__final_dest_2_6_0_i5);
	init_label(mercury__jumpopt__final_dest_2_6_0_i4);
	init_label(mercury__jumpopt__final_dest_2_6_0_i8);
	init_label(mercury__jumpopt__final_dest_2_6_0_i11);
	init_label(mercury__jumpopt__final_dest_2_6_0_i2);
	init_label(mercury__jumpopt__final_dest_2_6_0_i14);
BEGIN_CODE

/* code for predicate 'final_dest_2'/6 in mode 0 */
Define_static(mercury__jumpopt__final_dest_2_6_0);
	MR_incr_sp_push_msg(7, "jumpopt:final_dest_2/6");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__jumpopt__final_dest_2_6_0_i1005);
	r5 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i5);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r4 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i4);
Define_label(mercury__jumpopt__final_dest_2_6_0_i5);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i14);
	if ((MR_tag(MR_const_field(MR_mktag(3), r5, (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i14);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r5, (Integer) 1), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
Define_label(mercury__jumpopt__final_dest_2_6_0_i4);
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__final_dest_2_6_0_i8,
		STATIC(mercury__jumpopt__final_dest_2_6_0));
Define_label(mercury__jumpopt__final_dest_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__jumpopt__final_dest_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i2);
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__jumpopt__final_dest_2_6_0_i11,
		STATIC(mercury__jumpopt__final_dest_2_6_0));
Define_label(mercury__jumpopt__final_dest_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__jumpopt__final_dest_2_6_0));
	if (r1)
		GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i2);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__jumpopt__final_dest_2_6_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__jumpopt__final_dest_2_6_0_i1005);
Define_label(mercury__jumpopt__final_dest_2_6_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
Define_label(mercury__jumpopt__final_dest_2_6_0_i14);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(jumpopt_module9)
	init_entry(mercury__jumpopt__short_labels_rval_3_0);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i4);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i5);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i1015);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i8);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i9);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i10);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i11);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i12);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i13);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i16);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i17);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i20);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i23);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i27);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i29);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i33);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i35);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i37);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i34);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i39);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i40);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i41);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i42);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i43);
	init_label(mercury__jumpopt__short_labels_rval_3_0_i2);
BEGIN_CODE

/* code for predicate 'short_labels_rval'/3 in mode 0 */
Define_static(mercury__jumpopt__short_labels_rval_3_0);
	MR_incr_sp_push_msg(6, "jumpopt:short_labels_rval/3");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i4) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i1015) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i8) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i10));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__jumpopt__short_labels_lval_3_0),
		mercury__jumpopt__short_labels_rval_3_0_i5,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i5);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i1015);
	r1 = (Word) MR_string_const("var rval in jumpopt__short_labels_rval", 38);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_maybe_rvals_3_0),
		mercury__jumpopt__short_labels_rval_3_0_i9,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i9);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 6, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(2), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(2), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(2), r1, (Integer) 5) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i11) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i13) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i39) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i41) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__jumpopt__short_labels_rval_3_0,
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i12),
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i12);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i13);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i16) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i20));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i16);
	if (((Integer) MR_unmkbody(r3) != (Integer) 0))
		GOTO_LABEL(mercury__jumpopt__short_labels_rval_3_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_25);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_jumpopt__common_26);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i20);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r3, (Integer) 0),
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i23) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i33));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i23);
	if ((MR_tag(MR_const_field(MR_mktag(3), r3, (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__jumpopt__short_labels_rval_3_0_i2);
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r3, (Integer) 1), (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__short_labels_rval_3_0_i27,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i27);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__short_labels_rval_3_0_i34);
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__jumpopt__final_dest_2_6_0),
		mercury__jumpopt__short_labels_rval_3_0_i29,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i29);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_rval_3_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__jumpopt__short_labels_rval_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i33);
	r4 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_jumpopt__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__jumpopt__short_labels_rval_3_0_i35,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i35);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__jumpopt__short_labels_rval_3_0_i34);
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__jumpopt__final_dest_2_6_0),
		mercury__jumpopt__short_labels_rval_3_0_i37,
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i37);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_rval_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i34);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i39);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__jumpopt__short_labels_rval_3_0,
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i40),
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i40);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i41);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = r2;
	localcall(mercury__jumpopt__short_labels_rval_3_0,
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i42),
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i42);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	localcall(mercury__jumpopt__short_labels_rval_3_0,
		LABEL(mercury__jumpopt__short_labels_rval_3_0_i43),
		STATIC(mercury__jumpopt__short_labels_rval_3_0));
Define_label(mercury__jumpopt__short_labels_rval_3_0_i43);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_rval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__jumpopt__short_labels_rval_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__jumpopt__short_labels_rval_3_0_i2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(jumpopt_module10)
	init_entry(mercury__jumpopt__short_labels_maybe_rvals_3_0);
	init_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i5);
	init_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i6);
	init_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i7);
	init_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i3);
BEGIN_CODE

/* code for predicate 'short_labels_maybe_rvals'/3 in mode 0 */
Define_static(mercury__jumpopt__short_labels_maybe_rvals_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0_i3);
	MR_incr_sp_push_msg(3, "jumpopt:short_labels_maybe_rvals/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__jumpopt__short_labels_maybe_rvals_3_0,
		LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0_i7),
		STATIC(mercury__jumpopt__short_labels_maybe_rvals_3_0));
Define_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i5);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_maybe_rvals_3_0_i6,
		STATIC(mercury__jumpopt__short_labels_maybe_rvals_3_0));
Define_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__jumpopt__short_labels_maybe_rvals_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__jumpopt__short_labels_maybe_rvals_3_0,
		LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0_i7),
		STATIC(mercury__jumpopt__short_labels_maybe_rvals_3_0));
Define_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i7);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_maybe_rvals_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__jumpopt__short_labels_maybe_rvals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__jumpopt__short_labels_maybe_rvals_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(jumpopt_module11)
	init_entry(mercury__jumpopt__short_labels_lval_3_0);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i4);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i5);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i6);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i7);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i8);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i9);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i12);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i15);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i16);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i17);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i18);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i19);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i20);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i21);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i22);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i23);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i24);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i25);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i26);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i27);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i28);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i29);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i30);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i1009);
	init_label(mercury__jumpopt__short_labels_lval_3_0_i2);
BEGIN_CODE

/* code for predicate 'short_labels_lval'/3 in mode 0 */
Define_static(mercury__jumpopt__short_labels_lval_3_0);
	MR_incr_sp_push_msg(4, "jumpopt:short_labels_lval/3");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i4) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i1009) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i1009) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i12));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i5) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i6) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i7) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i8) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i9));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i2) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i15) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i17) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i19) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i21) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i23) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i25) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i28) AND
		LABEL(mercury__jumpopt__short_labels_lval_3_0_i30));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i16,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i16);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i17);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i18,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i18);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i19);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i20,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i20);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i21);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i22,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i22);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i23);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i24,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i24);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i25);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i26,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i26);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i27,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i27);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i28);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__jumpopt__short_labels_rval_3_0),
		mercury__jumpopt__short_labels_lval_3_0_i29,
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i29);
	update_prof_current_proc(LABEL(mercury__jumpopt__short_labels_lval_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__jumpopt__short_labels_lval_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i30);
	r1 = (Word) MR_string_const("lvar lval in jumpopt__short_labels_lval", 39);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__jumpopt__short_labels_lval_3_0));
Define_label(mercury__jumpopt__short_labels_lval_3_0_i1009);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__jumpopt__short_labels_lval_3_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__jumpopt_maybe_bunch_0(void)
{
	jumpopt_module0();
	jumpopt_module1();
	jumpopt_module2();
	jumpopt_module3();
	jumpopt_module4();
	jumpopt_module5();
	jumpopt_module6();
	jumpopt_module7();
	jumpopt_module8();
	jumpopt_module9();
	jumpopt_module10();
	jumpopt_module11();
}

#endif

void mercury__jumpopt__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__jumpopt__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__jumpopt_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
