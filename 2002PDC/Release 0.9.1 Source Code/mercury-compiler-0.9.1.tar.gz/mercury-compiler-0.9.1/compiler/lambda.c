/*
** Automatically generated from `lambda.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__lambda__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___lambda__lambda_info_0__ua0_2_0);
Declare_static(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0);
Declare_label(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0_i1);
Define_extern_entry(mercury__lambda__process_module_2_0);
Declare_label(mercury__lambda__process_module_2_0_i2);
Declare_label(mercury__lambda__process_module_2_0_i3);
Define_extern_entry(mercury__lambda__process_pred_3_0);
Declare_label(mercury__lambda__process_pred_3_0_i2);
Declare_label(mercury__lambda__process_pred_3_0_i3);
Declare_static(mercury__lambda__process_preds_3_0);
Declare_label(mercury__lambda__process_preds_3_0_i1001);
Declare_label(mercury__lambda__process_preds_3_0_i4);
Declare_label(mercury__lambda__process_preds_3_0_i5);
Declare_label(mercury__lambda__process_preds_3_0_i6);
Declare_label(mercury__lambda__process_preds_3_0_i3);
Declare_static(mercury__lambda__process_procs_4_0);
Declare_label(mercury__lambda__process_procs_4_0_i1001);
Declare_label(mercury__lambda__process_procs_4_0_i4);
Declare_label(mercury__lambda__process_procs_4_0_i5);
Declare_label(mercury__lambda__process_procs_4_0_i6);
Declare_label(mercury__lambda__process_procs_4_0_i7);
Declare_label(mercury__lambda__process_procs_4_0_i8);
Declare_label(mercury__lambda__process_procs_4_0_i9);
Declare_label(mercury__lambda__process_procs_4_0_i10);
Declare_label(mercury__lambda__process_procs_4_0_i11);
Declare_label(mercury__lambda__process_procs_4_0_i12);
Declare_label(mercury__lambda__process_procs_4_0_i13);
Declare_label(mercury__lambda__process_procs_4_0_i14);
Declare_label(mercury__lambda__process_procs_4_0_i15);
Declare_label(mercury__lambda__process_procs_4_0_i16);
Declare_label(mercury__lambda__process_procs_4_0_i17);
Declare_label(mercury__lambda__process_procs_4_0_i18);
Declare_label(mercury__lambda__process_procs_4_0_i19);
Declare_label(mercury__lambda__process_procs_4_0_i20);
Declare_label(mercury__lambda__process_procs_4_0_i21);
Declare_label(mercury__lambda__process_procs_4_0_i22);
Declare_label(mercury__lambda__process_procs_4_0_i23);
Declare_label(mercury__lambda__process_procs_4_0_i24);
Declare_label(mercury__lambda__process_procs_4_0_i25);
Declare_label(mercury__lambda__process_procs_4_0_i26);
Declare_label(mercury__lambda__process_procs_4_0_i27);
Declare_label(mercury__lambda__process_procs_4_0_i28);
Declare_label(mercury__lambda__process_procs_4_0_i29);
Declare_label(mercury__lambda__process_procs_4_0_i30);
Declare_label(mercury__lambda__process_procs_4_0_i31);
Declare_label(mercury__lambda__process_procs_4_0_i32);
Declare_label(mercury__lambda__process_procs_4_0_i3);
Declare_static(mercury__lambda__process_goal_4_0);
Declare_static(mercury__lambda__process_goal_2_5_0);
Declare_label(mercury__lambda__process_goal_2_5_0_i4);
Declare_label(mercury__lambda__process_goal_2_5_0_i5);
Declare_label(mercury__lambda__process_goal_2_5_0_i8);
Declare_label(mercury__lambda__process_goal_2_5_0_i9);
Declare_label(mercury__lambda__process_goal_2_5_0_i10);
Declare_label(mercury__lambda__process_goal_2_5_0_i11);
Declare_label(mercury__lambda__process_goal_2_5_0_i14);
Declare_label(mercury__lambda__process_goal_2_5_0_i15);
Declare_label(mercury__lambda__process_goal_2_5_0_i17);
Declare_label(mercury__lambda__process_goal_2_5_0_i18);
Declare_label(mercury__lambda__process_goal_2_5_0_i19);
Declare_label(mercury__lambda__process_goal_2_5_0_i20);
Declare_label(mercury__lambda__process_goal_2_5_0_i21);
Declare_label(mercury__lambda__process_goal_2_5_0_i22);
Declare_label(mercury__lambda__process_goal_2_5_0_i23);
Declare_label(mercury__lambda__process_goal_2_5_0_i24);
Declare_label(mercury__lambda__process_goal_2_5_0_i25);
Declare_label(mercury__lambda__process_goal_2_5_0_i26);
Declare_label(mercury__lambda__process_goal_2_5_0_i27);
Declare_label(mercury__lambda__process_goal_2_5_0_i28);
Declare_label(mercury__lambda__process_goal_2_5_0_i29);
Declare_label(mercury__lambda__process_goal_2_5_0_i30);
Declare_label(mercury__lambda__process_goal_2_5_0_i31);
Declare_static(mercury__lambda__process_goal_list_4_0);
Declare_label(mercury__lambda__process_goal_list_4_0_i4);
Declare_label(mercury__lambda__process_goal_list_4_0_i5);
Declare_label(mercury__lambda__process_goal_list_4_0_i3);
Declare_static(mercury__lambda__process_cases_4_0);
Declare_label(mercury__lambda__process_cases_4_0_i4);
Declare_label(mercury__lambda__process_cases_4_0_i5);
Declare_label(mercury__lambda__process_cases_4_0_i3);
Declare_static(mercury__lambda__process_lambda_12_0);
Declare_label(mercury__lambda__process_lambda_12_0_i2);
Declare_label(mercury__lambda__process_lambda_12_0_i3);
Declare_label(mercury__lambda__process_lambda_12_0_i4);
Declare_label(mercury__lambda__process_lambda_12_0_i5);
Declare_label(mercury__lambda__process_lambda_12_0_i1025);
Declare_label(mercury__lambda__process_lambda_12_0_i7);
Declare_label(mercury__lambda__process_lambda_12_0_i8);
Declare_label(mercury__lambda__process_lambda_12_0_i9);
Declare_label(mercury__lambda__process_lambda_12_0_i10);
Declare_label(mercury__lambda__process_lambda_12_0_i12);
Declare_label(mercury__lambda__process_lambda_12_0_i13);
Declare_label(mercury__lambda__process_lambda_12_0_i14);
Declare_label(mercury__lambda__process_lambda_12_0_i15);
Declare_label(mercury__lambda__process_lambda_12_0_i16);
Declare_label(mercury__lambda__process_lambda_12_0_i20);
Declare_label(mercury__lambda__process_lambda_12_0_i22);
Declare_label(mercury__lambda__process_lambda_12_0_i24);
Declare_label(mercury__lambda__process_lambda_12_0_i25);
Declare_label(mercury__lambda__process_lambda_12_0_i23);
Declare_label(mercury__lambda__process_lambda_12_0_i27);
Declare_label(mercury__lambda__process_lambda_12_0_i28);
Declare_label(mercury__lambda__process_lambda_12_0_i21);
Declare_label(mercury__lambda__process_lambda_12_0_i30);
Declare_label(mercury__lambda__process_lambda_12_0_i36);
Declare_label(mercury__lambda__process_lambda_12_0_i1035);
Declare_label(mercury__lambda__process_lambda_12_0_i34);
Declare_label(mercury__lambda__process_lambda_12_0_i40);
Declare_label(mercury__lambda__process_lambda_12_0_i41);
Declare_label(mercury__lambda__process_lambda_12_0_i43);
Declare_label(mercury__lambda__process_lambda_12_0_i46);
Declare_label(mercury__lambda__process_lambda_12_0_i47);
Declare_label(mercury__lambda__process_lambda_12_0_i48);
Declare_label(mercury__lambda__process_lambda_12_0_i54);
Declare_label(mercury__lambda__process_lambda_12_0_i1049);
Declare_label(mercury__lambda__process_lambda_12_0_i52);
Declare_label(mercury__lambda__process_lambda_12_0_i60);
Declare_label(mercury__lambda__process_lambda_12_0_i17);
Declare_label(mercury__lambda__process_lambda_12_0_i18);
Declare_label(mercury__lambda__process_lambda_12_0_i61);
Declare_label(mercury__lambda__process_lambda_12_0_i62);
Declare_label(mercury__lambda__process_lambda_12_0_i63);
Declare_label(mercury__lambda__process_lambda_12_0_i64);
Declare_label(mercury__lambda__process_lambda_12_0_i65);
Declare_label(mercury__lambda__process_lambda_12_0_i66);
Declare_label(mercury__lambda__process_lambda_12_0_i67);
Declare_label(mercury__lambda__process_lambda_12_0_i68);
Declare_label(mercury__lambda__process_lambda_12_0_i69);
Declare_label(mercury__lambda__process_lambda_12_0_i70);
Declare_label(mercury__lambda__process_lambda_12_0_i71);
Declare_label(mercury__lambda__process_lambda_12_0_i72);
Declare_label(mercury__lambda__process_lambda_12_0_i73);
Declare_label(mercury__lambda__process_lambda_12_0_i74);
Declare_label(mercury__lambda__process_lambda_12_0_i75);
Declare_label(mercury__lambda__process_lambda_12_0_i76);
Declare_label(mercury__lambda__process_lambda_12_0_i77);
Declare_label(mercury__lambda__process_lambda_12_0_i78);
Declare_label(mercury__lambda__process_lambda_12_0_i80);
Declare_label(mercury__lambda__process_lambda_12_0_i81);
Declare_label(mercury__lambda__process_lambda_12_0_i83);
Declare_label(mercury__lambda__process_lambda_12_0_i84);
Declare_label(mercury__lambda__process_lambda_12_0_i79);
Declare_label(mercury__lambda__process_lambda_12_0_i86);
Declare_label(mercury__lambda__process_lambda_12_0_i89);
Declare_label(mercury__lambda__process_lambda_12_0_i92);
Declare_label(mercury__lambda__process_lambda_12_0_i96);
Declare_label(mercury__lambda__process_lambda_12_0_i97);
Declare_label(mercury__lambda__process_lambda_12_0_i98);
Declare_label(mercury__lambda__process_lambda_12_0_i99);
Declare_label(mercury__lambda__process_lambda_12_0_i100);
Declare_label(mercury__lambda__process_lambda_12_0_i101);
Declare_static(mercury__lambda__constraint_contains_vars_2_0);
Declare_label(mercury__lambda__constraint_contains_vars_2_0_i2);
Declare_label(mercury__lambda__constraint_contains_vars_2_0_i3);
Declare_label(mercury__lambda__constraint_contains_vars_2_0_i4);
Declare_label(mercury__lambda__constraint_contains_vars_2_0_i5);
Declare_static(mercury__lambda__uni_modes_to_modes_2_0);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i5);
Declare_label(mercury__lambda__uni_modes_to_modes_2_0_i2);
Declare_static(mercury____Unify___lambda__lambda_info_0_0);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i2);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i4);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i6);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i8);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i10);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i12);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i14);
Declare_label(mercury____Unify___lambda__lambda_info_0_0_i1);
Declare_static(mercury____Index___lambda__lambda_info_0_0);
Declare_static(mercury____Compare___lambda__lambda_info_0_0);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i3);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i7);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i11);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i15);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i19);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i23);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i27);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i31);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i35);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i39);
Declare_label(mercury____Compare___lambda__lambda_info_0_0_i52);

const struct MR_TypeCtorInfo_struct mercury_data_lambda__type_ctor_info_lambda_info_0;

static const struct mercury_data_lambda__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_0;

static const struct mercury_data_lambda__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_1;

static const struct mercury_data_lambda__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_2;

static const struct mercury_data_lambda__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_3;

static const struct mercury_data_lambda__common_4_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lambda__common_4;

static const struct mercury_data_lambda__common_5_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lambda__common_5;

static const struct mercury_data_lambda__common_6_struct {
	Word * f1;
}  mercury_data_lambda__common_6;

static const struct mercury_data_lambda__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lambda__common_7;

static const struct mercury_data_lambda__common_8_struct {
	Word * f1;
}  mercury_data_lambda__common_8;

static const struct mercury_data_lambda__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_lambda__common_9;

static const struct mercury_data_lambda__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lambda__common_10;

static const struct mercury_data_lambda__common_11_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lambda__common_11;

static const struct mercury_data_lambda__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lambda__common_12;

static const struct mercury_data_lambda__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_13;

static const struct mercury_data_lambda__common_14_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lambda__common_14;

static const struct mercury_data_lambda__common_15_struct {
	Word * f1;
}  mercury_data_lambda__common_15;

static const struct mercury_data_lambda__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lambda__common_16;

static const struct mercury_data_lambda__common_17_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lambda__common_17;

static const struct mercury_data_lambda__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lambda__common_18;

static const struct mercury_data_lambda__common_19_struct {
	Word * f1;
}  mercury_data_lambda__common_19;

static const struct mercury_data_lambda__common_20_struct {
	Word * f1;
}  mercury_data_lambda__common_20;

static const struct mercury_data_lambda__common_21_struct {
	Word * f1;
}  mercury_data_lambda__common_21;

static const struct mercury_data_lambda__common_22_struct {
	Word * f1;
}  mercury_data_lambda__common_22;

static const struct mercury_data_lambda__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	String f13;
	Word * f14;
	Integer f15;
	Integer f16;
}  mercury_data_lambda__common_23;

static const struct mercury_data_lambda__type_ctor_functors_lambda_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_lambda__type_ctor_functors_lambda_info_0;

static const struct mercury_data_lambda__type_ctor_layout_lambda_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lambda__type_ctor_layout_lambda_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_lambda__type_ctor_info_lambda_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___lambda__lambda_info_0_0),
	STATIC(mercury____Index___lambda__lambda_info_0_0),
	STATIC(mercury____Compare___lambda__lambda_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lambda__type_ctor_functors_lambda_info_0,
	(Word *) &mercury_data_lambda__type_ctor_layout_lambda_info_0,
	MR_string_const("lambda", 6),
	MR_string_const("lambda_info", 11),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_lambda__common_0_struct mercury_data_lambda__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_lambda__common_1_struct mercury_data_lambda__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_lambda__common_2_struct mercury_data_lambda__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_lambda__common_3_struct mercury_data_lambda__common_3 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2)
};

static const struct mercury_data_lambda__common_4_struct mercury_data_lambda__common_4 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("vars", 4),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_3)
};

Declare_entry(mercury__type_util__vars_2_0);
static const struct mercury_data_lambda__common_5_struct mercury_data_lambda__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_4),
	ENTRY(mercury__type_util__vars_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;
static const struct mercury_data_lambda__common_6_struct mercury_data_lambda__common_6 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0
};

static const struct mercury_data_lambda__common_7_struct mercury_data_lambda__common_7 = {
	(Integer) 0,
	MR_string_const("lambda", 6),
	MR_string_const("lambda", 6),
	MR_string_const("constraint_contains_vars", 24),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_6)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_marker_0;
static const struct mercury_data_lambda__common_8_struct mercury_data_lambda__common_8 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_marker_0
};

static const struct mercury_data_lambda__common_9_struct mercury_data_lambda__common_9 = {
	(Integer) 0,
	MR_string_const("lambda", 6),
	MR_string_const("lambda", 6),
	MR_string_const("IntroducedFrom__pred__process_lambda__468__1", 44),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_8)
};

static const struct mercury_data_lambda__common_10_struct mercury_data_lambda__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_9),
	STATIC(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0),
	(Integer) 0
};

static const struct mercury_data_lambda__common_11_struct mercury_data_lambda__common_11 = {
	(Integer) 6,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_lambda__common_12_struct mercury_data_lambda__common_12 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_lambda__common_13_struct mercury_data_lambda__common_13 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_lambda__common_14_struct mercury_data_lambda__common_14 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraints_0;
static const struct mercury_data_lambda__common_15_struct mercury_data_lambda__common_15 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraints_0
};

static const struct mercury_data_lambda__common_16_struct mercury_data_lambda__common_16 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
static const struct mercury_data_lambda__common_17_struct mercury_data_lambda__common_17 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2),
	(Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0
};

static const struct mercury_data_lambda__common_18_struct mercury_data_lambda__common_18 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_markers_0;
static const struct mercury_data_lambda__common_19_struct mercury_data_lambda__common_19 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_markers_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_pred_or_func_0;
static const struct mercury_data_lambda__common_20_struct mercury_data_lambda__common_20 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_pred_or_func_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_lambda__common_21_struct mercury_data_lambda__common_21 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_lambda__common_22_struct mercury_data_lambda__common_22 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_lambda__common_23_struct mercury_data_lambda__common_23 = {
	(Integer) 11,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_22),
	MR_string_const("lambda_info", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lambda__type_ctor_functors_lambda_info_0_struct mercury_data_lambda__type_ctor_functors_lambda_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_23)
};

static const struct mercury_data_lambda__type_ctor_layout_lambda_info_0_struct mercury_data_lambda__type_ctor_layout_lambda_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lambda__common_23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(lambda_module0)
	init_entry(mercury____Index___lambda__lambda_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___lambda__lambda_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___lambda__lambda_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(lambda_module1)
	init_entry(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0);
	init_label(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__process_lambda__468__1'/1 in mode 0 */
Define_static(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0);
	if (!((((Integer) 1 << (Unsigned)(r1)) & (Integer) 15968)))
		GOTO_LABEL(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__lambda__IntroducedFrom__pred__process_lambda__468__1_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__hlds_module__module_info_clobber_dependency_info_2_0);

BEGIN_MODULE(lambda_module2)
	init_entry(mercury__lambda__process_module_2_0);
	init_label(mercury__lambda__process_module_2_0_i2);
	init_label(mercury__lambda__process_module_2_0_i3);
BEGIN_CODE

/* code for predicate 'process_module'/2 in mode 0 */
Define_entry(mercury__lambda__process_module_2_0);
	MR_incr_sp_push_msg(2, "lambda:process_module/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__lambda__process_module_2_0_i2,
		ENTRY(mercury__lambda__process_module_2_0));
Define_label(mercury__lambda__process_module_2_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__process_module_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__lambda__process_preds_3_0),
		mercury__lambda__process_module_2_0_i3,
		ENTRY(mercury__lambda__process_module_2_0));
Define_label(mercury__lambda__process_module_2_0_i3);
	update_prof_current_proc(LABEL(mercury__lambda__process_module_2_0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__hlds_module__module_info_clobber_dependency_info_2_0),
		ENTRY(mercury__lambda__process_module_2_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procids_2_0);

BEGIN_MODULE(lambda_module3)
	init_entry(mercury__lambda__process_pred_3_0);
	init_label(mercury__lambda__process_pred_3_0_i2);
	init_label(mercury__lambda__process_pred_3_0_i3);
BEGIN_CODE

/* code for predicate 'process_pred'/3 in mode 0 */
Define_entry(mercury__lambda__process_pred_3_0);
	MR_incr_sp_push_msg(3, "lambda:process_pred/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__lambda__process_pred_3_0_i2,
		ENTRY(mercury__lambda__process_pred_3_0));
Define_label(mercury__lambda__process_pred_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__process_pred_3_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__lambda__process_pred_3_0_i3,
		ENTRY(mercury__lambda__process_pred_3_0));
Define_label(mercury__lambda__process_pred_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lambda__process_pred_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__lambda__process_procs_4_0),
		ENTRY(mercury__lambda__process_pred_3_0));
END_MODULE


BEGIN_MODULE(lambda_module4)
	init_entry(mercury__lambda__process_preds_3_0);
	init_label(mercury__lambda__process_preds_3_0_i1001);
	init_label(mercury__lambda__process_preds_3_0_i4);
	init_label(mercury__lambda__process_preds_3_0_i5);
	init_label(mercury__lambda__process_preds_3_0_i6);
	init_label(mercury__lambda__process_preds_3_0_i3);
BEGIN_CODE

/* code for predicate 'process_preds'/3 in mode 0 */
Define_static(mercury__lambda__process_preds_3_0);
	MR_incr_sp_push_msg(4, "lambda:process_preds/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__lambda__process_preds_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lambda__process_preds_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__lambda__process_preds_3_0_i4,
		STATIC(mercury__lambda__process_preds_3_0));
Define_label(mercury__lambda__process_preds_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_preds_3_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procids_2_0),
		mercury__lambda__process_preds_3_0_i5,
		STATIC(mercury__lambda__process_preds_3_0));
Define_label(mercury__lambda__process_preds_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_preds_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__lambda__process_procs_4_0),
		mercury__lambda__process_preds_3_0_i6,
		STATIC(mercury__lambda__process_preds_3_0));
Define_label(mercury__lambda__process_preds_3_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__process_preds_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lambda__process_preds_3_0_i1001);
Define_label(mercury__lambda__process_preds_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_markers_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_class_context_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_aditi_owner_2_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_varset_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_vartypes_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_typeclass_info_varmap_3_0);
Declare_entry(mercury__hlds_pred__pred_info_set_typevarset_3_0);
Declare_entry(mercury__hlds_pred__pred_info_set_class_context_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(lambda_module5)
	init_entry(mercury__lambda__process_procs_4_0);
	init_label(mercury__lambda__process_procs_4_0_i1001);
	init_label(mercury__lambda__process_procs_4_0_i4);
	init_label(mercury__lambda__process_procs_4_0_i5);
	init_label(mercury__lambda__process_procs_4_0_i6);
	init_label(mercury__lambda__process_procs_4_0_i7);
	init_label(mercury__lambda__process_procs_4_0_i8);
	init_label(mercury__lambda__process_procs_4_0_i9);
	init_label(mercury__lambda__process_procs_4_0_i10);
	init_label(mercury__lambda__process_procs_4_0_i11);
	init_label(mercury__lambda__process_procs_4_0_i12);
	init_label(mercury__lambda__process_procs_4_0_i13);
	init_label(mercury__lambda__process_procs_4_0_i14);
	init_label(mercury__lambda__process_procs_4_0_i15);
	init_label(mercury__lambda__process_procs_4_0_i16);
	init_label(mercury__lambda__process_procs_4_0_i17);
	init_label(mercury__lambda__process_procs_4_0_i18);
	init_label(mercury__lambda__process_procs_4_0_i19);
	init_label(mercury__lambda__process_procs_4_0_i20);
	init_label(mercury__lambda__process_procs_4_0_i21);
	init_label(mercury__lambda__process_procs_4_0_i22);
	init_label(mercury__lambda__process_procs_4_0_i23);
	init_label(mercury__lambda__process_procs_4_0_i24);
	init_label(mercury__lambda__process_procs_4_0_i25);
	init_label(mercury__lambda__process_procs_4_0_i26);
	init_label(mercury__lambda__process_procs_4_0_i27);
	init_label(mercury__lambda__process_procs_4_0_i28);
	init_label(mercury__lambda__process_procs_4_0_i29);
	init_label(mercury__lambda__process_procs_4_0_i30);
	init_label(mercury__lambda__process_procs_4_0_i31);
	init_label(mercury__lambda__process_procs_4_0_i32);
	init_label(mercury__lambda__process_procs_4_0_i3);
BEGIN_CODE

/* code for predicate 'process_procs'/4 in mode 0 */
Define_static(mercury__lambda__process_procs_4_0);
	MR_incr_sp_push_msg(17, "lambda:process_procs/4");
	MR_stackvar(17) = (Word) MR_succip;
Define_label(mercury__lambda__process_procs_4_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lambda__process_procs_4_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = r3;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__lambda__process_procs_4_0_i4,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lambda__process_procs_4_0_i5,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__lambda__process_procs_4_0_i6,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lambda__process_procs_4_0_i7,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__lambda__process_procs_4_0_i8,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__lambda__process_procs_4_0_i9,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__lambda__process_procs_4_0_i10,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__lambda__process_procs_4_0_i11,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_class_context_2_0),
		mercury__lambda__process_procs_4_0_i12,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i12);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_aditi_owner_2_0),
		mercury__lambda__process_procs_4_0_i13,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i13);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__lambda__process_procs_4_0_i14,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i14);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__lambda__process_procs_4_0_i15,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__lambda__process_procs_4_0_i16,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i16);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0),
		mercury__lambda__process_procs_4_0_i17,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i17);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0),
		mercury__lambda__process_procs_4_0_i18,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i18);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 11, mercury__lambda__process_procs_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(15);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(16);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(13);
	call_localret(STATIC(mercury__lambda__process_goal_2_5_0),
		mercury__lambda__process_procs_4_0_i19,
		STATIC(mercury__lambda__process_procs_4_0));
	}
Define_label(mercury__lambda__process_procs_4_0_i19);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__lambda__process_procs_4_0_i20,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i20);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_varset_3_0),
		mercury__lambda__process_procs_4_0_i21,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i21);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_vartypes_3_0),
		mercury__lambda__process_procs_4_0_i22,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i22);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_typeinfo_varmap_3_0),
		mercury__lambda__process_procs_4_0_i23,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i23);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_typeclass_info_varmap_3_0),
		mercury__lambda__process_procs_4_0_i24,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i24);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_typevarset_3_0),
		mercury__lambda__process_procs_4_0_i25,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i25);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_class_context_3_0),
		mercury__lambda__process_procs_4_0_i26,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i26);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__lambda__process_procs_4_0_i27,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i27);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__lambda__process_procs_4_0_i28,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i28);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__lambda__process_procs_4_0_i29,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i29);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__lambda__process_procs_4_0_i30,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i30);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__lambda__process_procs_4_0_i31,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i31);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__lambda__process_procs_4_0_i32,
		STATIC(mercury__lambda__process_procs_4_0));
Define_label(mercury__lambda__process_procs_4_0_i32);
	update_prof_current_proc(LABEL(mercury__lambda__process_procs_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(17);
	GOTO_LABEL(mercury__lambda__process_procs_4_0_i1001);
Define_label(mercury__lambda__process_procs_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE


BEGIN_MODULE(lambda_module6)
	init_entry(mercury__lambda__process_goal_4_0);
BEGIN_CODE

/* code for predicate 'process_goal'/4 in mode 0 */
Define_static(mercury__lambda__process_goal_4_0);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__lambda__process_goal_2_5_0),
		STATIC(mercury__lambda__process_goal_4_0));
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(lambda_module7)
	init_entry(mercury__lambda__process_goal_2_5_0);
	init_label(mercury__lambda__process_goal_2_5_0_i4);
	init_label(mercury__lambda__process_goal_2_5_0_i5);
	init_label(mercury__lambda__process_goal_2_5_0_i8);
	init_label(mercury__lambda__process_goal_2_5_0_i9);
	init_label(mercury__lambda__process_goal_2_5_0_i10);
	init_label(mercury__lambda__process_goal_2_5_0_i11);
	init_label(mercury__lambda__process_goal_2_5_0_i14);
	init_label(mercury__lambda__process_goal_2_5_0_i15);
	init_label(mercury__lambda__process_goal_2_5_0_i17);
	init_label(mercury__lambda__process_goal_2_5_0_i18);
	init_label(mercury__lambda__process_goal_2_5_0_i19);
	init_label(mercury__lambda__process_goal_2_5_0_i20);
	init_label(mercury__lambda__process_goal_2_5_0_i21);
	init_label(mercury__lambda__process_goal_2_5_0_i22);
	init_label(mercury__lambda__process_goal_2_5_0_i23);
	init_label(mercury__lambda__process_goal_2_5_0_i24);
	init_label(mercury__lambda__process_goal_2_5_0_i25);
	init_label(mercury__lambda__process_goal_2_5_0_i26);
	init_label(mercury__lambda__process_goal_2_5_0_i27);
	init_label(mercury__lambda__process_goal_2_5_0_i28);
	init_label(mercury__lambda__process_goal_2_5_0_i29);
	init_label(mercury__lambda__process_goal_2_5_0_i30);
	init_label(mercury__lambda__process_goal_2_5_0_i31);
BEGIN_CODE

/* code for predicate 'process_goal_2'/5 in mode 0 */
Define_static(mercury__lambda__process_goal_2_5_0);
	MR_incr_sp_push_msg(12, "lambda:process_goal_2/5");
	MR_stackvar(12) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__lambda__process_goal_2_5_0_i4) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i27) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i27) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i8));
Define_label(mercury__lambda__process_goal_2_5_0_i4);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_list_4_0),
		mercury__lambda__process_goal_2_5_0_i5,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__lambda__process_goal_2_5_0_i9) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i11) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i17) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i19) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i21) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i23) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i27) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i28) AND
		LABEL(mercury__lambda__process_goal_2_5_0_i30));
Define_label(mercury__lambda__process_goal_2_5_0_i9);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_cases_4_0),
		mercury__lambda__process_goal_2_5_0_i10,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i11);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__lambda__process_goal_2_5_0_i27);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(2), r4, (Integer) 7);
	MR_stackvar(11) = MR_const_field(MR_mktag(2), r4, (Integer) 6);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(2), r4, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r4, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r4, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r4, (Integer) 1);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i14,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r7 = r1;
	r9 = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(11);
	r6 = MR_stackvar(8);
	r8 = MR_stackvar(4);
	call_localret(STATIC(mercury__lambda__process_lambda_12_0),
		mercury__lambda__process_goal_2_5_0_i15,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i17);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_list_4_0),
		mercury__lambda__process_goal_2_5_0_i18,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i19);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i20,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i21);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i22,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i23);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i24,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i25,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i25);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	call_localret(STATIC(mercury__lambda__process_goal_4_0),
		mercury__lambda__process_goal_2_5_0_i26,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i27);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	r2 = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__lambda__process_goal_2_5_0_i28);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = r3;
	call_localret(STATIC(mercury__lambda__process_goal_list_4_0),
		mercury__lambda__process_goal_2_5_0_i29,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lambda__process_goal_2_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__lambda__process_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__lambda__process_goal_2_5_0_i30);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("lambda__process_goal_2: unexpected bi_implication", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lambda__process_goal_2_5_0_i31,
		STATIC(mercury__lambda__process_goal_2_5_0));
Define_label(mercury__lambda__process_goal_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_2_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(lambda_module8)
	init_entry(mercury__lambda__process_goal_list_4_0);
	init_label(mercury__lambda__process_goal_list_4_0_i4);
	init_label(mercury__lambda__process_goal_list_4_0_i5);
	init_label(mercury__lambda__process_goal_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'process_goal_list'/4 in mode 0 */
Define_static(mercury__lambda__process_goal_list_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lambda__process_goal_list_4_0_i3);
	MR_incr_sp_push_msg(2, "lambda:process_goal_list/4");
	MR_stackvar(2) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(STATIC(mercury__lambda__process_goal_2_5_0),
		mercury__lambda__process_goal_list_4_0_i4,
		STATIC(mercury__lambda__process_goal_list_4_0));
	}
Define_label(mercury__lambda__process_goal_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_list_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__lambda__process_goal_list_4_0,
		LABEL(mercury__lambda__process_goal_list_4_0_i5),
		STATIC(mercury__lambda__process_goal_list_4_0));
Define_label(mercury__lambda__process_goal_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_goal_list_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lambda__process_goal_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__lambda__process_goal_list_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(lambda_module9)
	init_entry(mercury__lambda__process_cases_4_0);
	init_label(mercury__lambda__process_cases_4_0_i4);
	init_label(mercury__lambda__process_cases_4_0_i5);
	init_label(mercury__lambda__process_cases_4_0_i3);
BEGIN_CODE

/* code for predicate 'process_cases'/4 in mode 0 */
Define_static(mercury__lambda__process_cases_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lambda__process_cases_4_0_i3);
	MR_incr_sp_push_msg(3, "lambda:process_cases/4");
	MR_stackvar(3) = (Word) MR_succip;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__lambda__process_goal_2_5_0),
		mercury__lambda__process_cases_4_0_i4,
		STATIC(mercury__lambda__process_cases_4_0));
	}
Define_label(mercury__lambda__process_cases_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_cases_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lambda__process_cases_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__lambda__process_cases_4_0,
		LABEL(mercury__lambda__process_cases_4_0_i5),
		STATIC(mercury__lambda__process_cases_4_0));
Define_label(mercury__lambda__process_cases_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_cases_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lambda__process_cases_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lambda__process_cases_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__map__apply_to_list_3_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__list__filter_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__insert_list_3_0);
Declare_entry(mercury__goal_util__extra_nonlocal_typeinfos_6_0);
Declare_entry(mercury__set__delete_list_3_0);
Declare_entry(mercury__set__union_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__check_marker_2_0);
Declare_entry(mercury__list__remove_suffix_3_0);
Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__list__member_2_0);
Declare_entry(do_redo);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__list__length_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
Declare_entry(mercury__list__take_3_0);
Declare_entry(mercury__mode_util__mode_is_input_2_0);
Declare_entry(mercury__mode_util__modes_to_uni_modes_4_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__hlds_module__module_info_next_lambda_count_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__term__context_line_2_0);
Declare_entry(mercury__prog_util__make_pred_name_with_context_7_0);
Declare_entry(mercury__mode_util__in_mode_1_0);
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__map__from_corresponding_lists_3_0);
Declare_entry(mercury__map__overlay_3_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);
Declare_entry(mercury__hlds_pred__markers_to_marker_list_2_0);
Declare_entry(mercury__hlds_pred__marker_list_to_markers_2_0);
Declare_entry(mercury__hlds_pred__init_markers_1_0);
Declare_entry(mercury__hlds_pred__proc_info_create_11_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_assert_id_0;
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__hlds_pred__pred_info_create_16_0);
Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_module__predicate_table_insert_4_0);
Declare_entry(mercury__hlds_module__module_info_set_predicate_table_3_0);

BEGIN_MODULE(lambda_module10)
	init_entry(mercury__lambda__process_lambda_12_0);
	init_label(mercury__lambda__process_lambda_12_0_i2);
	init_label(mercury__lambda__process_lambda_12_0_i3);
	init_label(mercury__lambda__process_lambda_12_0_i4);
	init_label(mercury__lambda__process_lambda_12_0_i5);
	init_label(mercury__lambda__process_lambda_12_0_i1025);
	init_label(mercury__lambda__process_lambda_12_0_i7);
	init_label(mercury__lambda__process_lambda_12_0_i8);
	init_label(mercury__lambda__process_lambda_12_0_i9);
	init_label(mercury__lambda__process_lambda_12_0_i10);
	init_label(mercury__lambda__process_lambda_12_0_i12);
	init_label(mercury__lambda__process_lambda_12_0_i13);
	init_label(mercury__lambda__process_lambda_12_0_i14);
	init_label(mercury__lambda__process_lambda_12_0_i15);
	init_label(mercury__lambda__process_lambda_12_0_i16);
	init_label(mercury__lambda__process_lambda_12_0_i20);
	init_label(mercury__lambda__process_lambda_12_0_i22);
	init_label(mercury__lambda__process_lambda_12_0_i24);
	init_label(mercury__lambda__process_lambda_12_0_i25);
	init_label(mercury__lambda__process_lambda_12_0_i23);
	init_label(mercury__lambda__process_lambda_12_0_i27);
	init_label(mercury__lambda__process_lambda_12_0_i28);
	init_label(mercury__lambda__process_lambda_12_0_i21);
	init_label(mercury__lambda__process_lambda_12_0_i30);
	init_label(mercury__lambda__process_lambda_12_0_i36);
	init_label(mercury__lambda__process_lambda_12_0_i1035);
	init_label(mercury__lambda__process_lambda_12_0_i34);
	init_label(mercury__lambda__process_lambda_12_0_i40);
	init_label(mercury__lambda__process_lambda_12_0_i41);
	init_label(mercury__lambda__process_lambda_12_0_i43);
	init_label(mercury__lambda__process_lambda_12_0_i46);
	init_label(mercury__lambda__process_lambda_12_0_i47);
	init_label(mercury__lambda__process_lambda_12_0_i48);
	init_label(mercury__lambda__process_lambda_12_0_i54);
	init_label(mercury__lambda__process_lambda_12_0_i1049);
	init_label(mercury__lambda__process_lambda_12_0_i52);
	init_label(mercury__lambda__process_lambda_12_0_i60);
	init_label(mercury__lambda__process_lambda_12_0_i17);
	init_label(mercury__lambda__process_lambda_12_0_i18);
	init_label(mercury__lambda__process_lambda_12_0_i61);
	init_label(mercury__lambda__process_lambda_12_0_i62);
	init_label(mercury__lambda__process_lambda_12_0_i63);
	init_label(mercury__lambda__process_lambda_12_0_i64);
	init_label(mercury__lambda__process_lambda_12_0_i65);
	init_label(mercury__lambda__process_lambda_12_0_i66);
	init_label(mercury__lambda__process_lambda_12_0_i67);
	init_label(mercury__lambda__process_lambda_12_0_i68);
	init_label(mercury__lambda__process_lambda_12_0_i69);
	init_label(mercury__lambda__process_lambda_12_0_i70);
	init_label(mercury__lambda__process_lambda_12_0_i71);
	init_label(mercury__lambda__process_lambda_12_0_i72);
	init_label(mercury__lambda__process_lambda_12_0_i73);
	init_label(mercury__lambda__process_lambda_12_0_i74);
	init_label(mercury__lambda__process_lambda_12_0_i75);
	init_label(mercury__lambda__process_lambda_12_0_i76);
	init_label(mercury__lambda__process_lambda_12_0_i77);
	init_label(mercury__lambda__process_lambda_12_0_i78);
	init_label(mercury__lambda__process_lambda_12_0_i80);
	init_label(mercury__lambda__process_lambda_12_0_i81);
	init_label(mercury__lambda__process_lambda_12_0_i83);
	init_label(mercury__lambda__process_lambda_12_0_i84);
	init_label(mercury__lambda__process_lambda_12_0_i79);
	init_label(mercury__lambda__process_lambda_12_0_i86);
	init_label(mercury__lambda__process_lambda_12_0_i89);
	init_label(mercury__lambda__process_lambda_12_0_i92);
	init_label(mercury__lambda__process_lambda_12_0_i96);
	init_label(mercury__lambda__process_lambda_12_0_i97);
	init_label(mercury__lambda__process_lambda_12_0_i98);
	init_label(mercury__lambda__process_lambda_12_0_i99);
	init_label(mercury__lambda__process_lambda_12_0_i100);
	init_label(mercury__lambda__process_lambda_12_0_i101);
BEGIN_CODE

/* code for predicate 'process_lambda'/12 in mode 0 */
Define_static(mercury__lambda__process_lambda_12_0);
	MR_incr_sp_push_msg(35, "lambda:process_lambda/12");
	MR_stackvar(35) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r9, (Integer) 5);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r9, (Integer) 10);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r9, (Integer) 9);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r9, (Integer) 8);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r9, (Integer) 7);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r9, (Integer) 6);
	MR_stackvar(13) = r3;
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r9, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r9, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r9, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r9, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__lambda__process_lambda_12_0_i2,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(19) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__lambda__process_lambda_12_0_i3,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i3);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_5);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lambda__process_lambda_12_0_i4,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__lambda__process_lambda_12_0_i5,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__lambda__process_lambda_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r3 = MR_stackvar(19);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lambda__constraint_contains_vars_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_7);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__lambda__process_lambda_12_0_i1025,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i1025);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lambda__process_lambda_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_stackvar(19) = r2;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(7), (Integer) 1);
	MR_stackvar(20) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__lambda__process_lambda_12_0_i7,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i7);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(21) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__lambda__process_lambda_12_0_i8,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i8);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r5 = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(13);
	r3 = MR_stackvar(10);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__goal_util__extra_nonlocal_typeinfos_6_0),
		mercury__lambda__process_lambda_12_0_i9,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i9);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if ((MR_tag(MR_stackvar(8)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i10);
	r2 = MR_stackvar(21);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(8);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__lambda__process_lambda_12_0_i13);
	}
Define_label(mercury__lambda__process_lambda_12_0_i10);
	MR_stackvar(8) = r1;
	r1 = (Word) MR_string_const("lambda__transform_lambda: weird unification", 43);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lambda__process_lambda_12_0_i12,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i12);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(21);
Define_label(mercury__lambda__process_lambda_12_0_i13);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__set__delete_list_3_0),
		mercury__lambda__process_lambda_12_0_i14,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i14);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__lambda__process_lambda_12_0_i15,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i15);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__lambda__process_lambda_12_0_i16,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i16);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(7), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i18);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(24) = r3;
	MR_stackvar(25) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(26) = MR_const_field(MR_mktag(1), r2, (Integer) 5);
	MR_stackvar(8) = r1;
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(23) = r2;
	r1 = MR_stackvar(18);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__lambda__process_lambda_12_0_i20,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i20);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i22);
	MR_stackvar(27) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = MR_stackvar(25);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__lambda__process_lambda_12_0_i21);
Define_label(mercury__lambda__process_lambda_12_0_i22);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i23);
	MR_stackvar(27) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__lambda__process_lambda_12_0_i24,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i24);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = (Integer) 7;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__lambda__process_lambda_12_0_i25,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i25);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(25);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	GOTO_LABEL(mercury__lambda__process_lambda_12_0_i21);
Define_label(mercury__lambda__process_lambda_12_0_i23);
	MR_stackvar(27) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__lambda__process_lambda_12_0_i27,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i27);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = (Integer) 6;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__lambda__process_lambda_12_0_i28,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i28);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(25);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
Define_label(mercury__lambda__process_lambda_12_0_i21);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__list__remove_suffix_3_0),
		mercury__lambda__process_lambda_12_0_i30,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i30);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	MR_stackvar(29) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(30) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(31) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__lambda__process_lambda_12_0_i34);
	MR_stackvar(25) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lambda__process_lambda_12_0_i36,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i36);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lambda__process_lambda_12_0_i1035,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i1035);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(31);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(29);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(30);
	GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
Define_label(mercury__lambda__process_lambda_12_0_i34);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = MR_stackvar(25);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(29);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(30);
	MR_stackvar(25) = r2;
	r1 = MR_stackvar(27);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__lambda__process_lambda_12_0_i40,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i40);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(28) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__lambda__process_lambda_12_0_i41,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i41);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if ((r1 != MR_stackvar(28)))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i43);
	r1 = MR_stackvar(27);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__lambda__process_lambda_12_0_i46,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i43);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	if (((Integer) MR_stackvar(28) != (Integer) 0))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	r1 = MR_stackvar(27);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__lambda__process_lambda_12_0_i46,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i46);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(27) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lambda__process_lambda_12_0_i47,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i47);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r3 = MR_stackvar(27);
	r2 = r1;
	MR_stackvar(27) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury__list__take_3_0),
		mercury__lambda__process_lambda_12_0_i48,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i48);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
	MR_stackvar(32) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(33) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(34) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__lambda__process_lambda_12_0_i52);
	MR_stackvar(28) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lambda__process_lambda_12_0_i54,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i54);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = MR_stackvar(18);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__lambda__process_lambda_12_0_i1049,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i1049);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(34);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(32);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(33);
	GOTO_LABEL(mercury__lambda__process_lambda_12_0_i17);
Define_label(mercury__lambda__process_lambda_12_0_i52);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = MR_stackvar(28);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(32);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(33);
	r1 = r2;
	r3 = MR_stackvar(18);
	call_localret(ENTRY(mercury__mode_util__modes_to_uni_modes_4_0),
		mercury__lambda__process_lambda_12_0_i60,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i60);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lambda__process_lambda_12_0, "hlds_goal:unify_rhs/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lambda__process_lambda_12_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(26);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(27);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(25);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__lambda__process_lambda_12_0, "hlds_goal:unification/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(21);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__lambda__process_lambda_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(24);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(0), r2, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 5) = (Integer) 0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(25);
	MR_field(MR_mktag(0), r2, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 11, mercury__lambda__process_lambda_12_0, "lambda:lambda_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(19);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(15);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(16);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_stackvar(17);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_stackvar(18);
	MR_succip = (Code *) MR_stackvar(35);
	MR_decr_sp_pop_msg(35);
	proceed();
	}
Define_label(mercury__lambda__process_lambda_12_0_i17);
	r1 = MR_stackvar(8);
Define_label(mercury__lambda__process_lambda_12_0_i18);
	MR_stackvar(8) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__process_lambda_12_0_i61,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i61);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(18);
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__lambda__process_lambda_12_0_i62,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i62);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	r1 = MR_stackvar(18);
	MR_stackvar(18) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_next_lambda_count_3_0),
		mercury__lambda__process_lambda_12_0_i63,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i63);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(23) = r1;
	r1 = MR_stackvar(20);
	MR_stackvar(24) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__lambda__process_lambda_12_0_i64,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i64);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__lambda__process_lambda_12_0_i65,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i65);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r5 = r1;
	r1 = MR_stackvar(18);
	r2 = (Word) MR_string_const("IntroducedFrom", 14);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(16);
	r6 = MR_stackvar(23);
	call_localret(ENTRY(mercury__prog_util__make_pred_name_with_context_7_0),
		mercury__lambda__process_lambda_12_0_i66,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i66);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(25) = r1;
	r1 = MR_stackvar(20);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__lambda__process_lambda_12_0_i67,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i67);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(20) = r1;
	r1 = MR_stackvar(22);
	call_localret(STATIC(mercury__lambda__uni_modes_to_modes_2_0),
		mercury__lambda__process_lambda_12_0_i68,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i68);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(22) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lambda__process_lambda_12_0_i69,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i69);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(26) = r1;
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__lambda__process_lambda_12_0_i70,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i70);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(26);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__lambda__process_lambda_12_0_i71,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i71);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__lambda__process_lambda_12_0_i72,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i72);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r4 = MR_stackvar(22);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__lambda__process_lambda_12_0_i73,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i73);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__overlay_3_0),
		mercury__lambda__process_lambda_12_0_i74,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i74);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__lambda__process_lambda_12_0_i75,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i75);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r3 = MR_stackvar(24);
	call_localret(ENTRY(mercury__mode_util__modes_to_uni_modes_4_0),
		mercury__lambda__process_lambda_12_0_i76,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i76);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(27) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lambda__process_lambda_12_0_i77,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i77);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__lambda__process_lambda_12_0_i78,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i78);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__lambda__process_lambda_12_0_i80,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i80);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (((Integer) 3 != (Integer) r2))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i79);
	r1 = MR_stackvar(14);
	r2 = (Integer) 6;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__lambda__process_lambda_12_0_i81,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i81);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i79);
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__hlds_pred__markers_to_marker_list_2_0),
		mercury__lambda__process_lambda_12_0_i83,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i83);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_marker_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_10);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__lambda__process_lambda_12_0_i84,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i84);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	call_localret(ENTRY(mercury__hlds_pred__marker_list_to_markers_2_0),
		mercury__lambda__process_lambda_12_0_i92,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i79);
	if (((Integer) MR_stackvar(2) != (Integer) 2))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i86);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lambda__common_11);
	call_localret(ENTRY(mercury__hlds_pred__marker_list_to_markers_2_0),
		mercury__lambda__process_lambda_12_0_i92,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i86);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__lambda__process_lambda_12_0_i89);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lambda__common_12);
	call_localret(ENTRY(mercury__hlds_pred__marker_list_to_markers_2_0),
		mercury__lambda__process_lambda_12_0_i92,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i89);
	call_localret(ENTRY(mercury__hlds_pred__init_markers_1_0),
		mercury__lambda__process_lambda_12_0_i92,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i92);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(22) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(20);
	r8 = MR_stackvar(12);
	r9 = MR_stackvar(13);
	r10 = (Integer) 0;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_create_11_0),
		mercury__lambda__process_lambda_12_0_i96,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i96);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(23) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_assert_id_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__lambda__process_lambda_12_0_i97,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i97);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r13 = r1;
	r1 = MR_stackvar(18);
	r2 = MR_stackvar(25);
	r3 = MR_stackvar(11);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = MR_stackvar(6);
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r7 = MR_stackvar(20);
	r8 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 7));
	r9 = MR_stackvar(22);
	r10 = MR_stackvar(1);
	r11 = MR_stackvar(19);
	r12 = MR_stackvar(17);
	r14 = MR_stackvar(23);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_create_16_0),
		mercury__lambda__process_lambda_12_0_i98,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i98);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(23) = r1;
	r1 = MR_stackvar(24);
	MR_stackvar(22) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__lambda__process_lambda_12_0_i99,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i99);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = MR_stackvar(22);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_insert_4_0),
		mercury__lambda__process_lambda_12_0_i100,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i100);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	MR_stackvar(22) = r1;
	r1 = MR_stackvar(24);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_predicate_table_3_0),
		mercury__lambda__process_lambda_12_0_i101,
		STATIC(mercury__lambda__process_lambda_12_0));
Define_label(mercury__lambda__process_lambda_12_0_i101);
	update_prof_current_proc(LABEL(mercury__lambda__process_lambda_12_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lambda__process_lambda_12_0, "hlds_goal:unify_rhs/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lambda__process_lambda_12_0, "hlds_data:cons_id/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(25);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(26);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(8);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__lambda__process_lambda_12_0, "hlds_goal:unification/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(21);
	r4 = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__lambda__process_lambda_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(23);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(0), r2, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 5) = (Integer) 0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(27);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 11, mercury__lambda__process_lambda_12_0, "lambda:lambda_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(19);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(15);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(16);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_stackvar(17);
	MR_field(MR_mktag(0), r3, (Integer) 10) = r4;
	MR_succip = (Code *) MR_stackvar(35);
	MR_decr_sp_pop_msg(35);
	proceed();
	}
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__set__subset_2_0);

BEGIN_MODULE(lambda_module11)
	init_entry(mercury__lambda__constraint_contains_vars_2_0);
	init_label(mercury__lambda__constraint_contains_vars_2_0_i2);
	init_label(mercury__lambda__constraint_contains_vars_2_0_i3);
	init_label(mercury__lambda__constraint_contains_vars_2_0_i4);
	init_label(mercury__lambda__constraint_contains_vars_2_0_i5);
BEGIN_CODE

/* code for predicate 'constraint_contains_vars'/2 in mode 0 */
Define_static(mercury__lambda__constraint_contains_vars_2_0);
	MR_incr_sp_push_msg(2, "lambda:constraint_contains_vars/2");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_5);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lambda__constraint_contains_vars_2_0_i2,
		STATIC(mercury__lambda__constraint_contains_vars_2_0));
Define_label(mercury__lambda__constraint_contains_vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__lambda__constraint_contains_vars_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__lambda__constraint_contains_vars_2_0_i3,
		STATIC(mercury__lambda__constraint_contains_vars_2_0));
Define_label(mercury__lambda__constraint_contains_vars_2_0_i3);
	update_prof_current_proc(LABEL(mercury__lambda__constraint_contains_vars_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__lambda__constraint_contains_vars_2_0_i4,
		STATIC(mercury__lambda__constraint_contains_vars_2_0));
Define_label(mercury__lambda__constraint_contains_vars_2_0_i4);
	update_prof_current_proc(LABEL(mercury__lambda__constraint_contains_vars_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__lambda__constraint_contains_vars_2_0_i5,
		STATIC(mercury__lambda__constraint_contains_vars_2_0));
Define_label(mercury__lambda__constraint_contains_vars_2_0_i5);
	update_prof_current_proc(LABEL(mercury__lambda__constraint_contains_vars_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__set__subset_2_0),
		STATIC(mercury__lambda__constraint_contains_vars_2_0));
END_MODULE


BEGIN_MODULE(lambda_module12)
	init_entry(mercury__lambda__uni_modes_to_modes_2_0);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i5);
	init_label(mercury__lambda__uni_modes_to_modes_2_0_i2);
BEGIN_CODE

/* code for predicate 'uni_modes_to_modes'/2 in mode 0 */
Define_static(mercury__lambda__uni_modes_to_modes_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lambda__uni_modes_to_modes_2_0_i2);
	r3 = (Word) MR_sp;
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "lambda:uni_modes_to_modes");
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__lambda__uni_modes_to_modes_2_0, "prog_data:mode/0");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lambda__uni_modes_to_modes_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lambda__uni_modes_to_modes_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___prog_data__class_constraints_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_markers_0_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);

BEGIN_MODULE(lambda_module13)
	init_entry(mercury____Unify___lambda__lambda_info_0_0);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i2);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i4);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i6);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i8);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i10);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i12);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i14);
	init_label(mercury____Unify___lambda__lambda_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___lambda__lambda_info_0_0);
	MR_incr_sp_push_msg(21, "lambda:__Unify__/2");
	MR_stackvar(21) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___lambda__lambda_info_0_0_i2,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lambda__lambda_info_0_0_i4,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___prog_data__class_constraints_0_0),
		mercury____Unify___lambda__lambda_info_0_0_i6,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___lambda__lambda_info_0_0_i8,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lambda__lambda_info_0_0_i10,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lambda__lambda_info_0_0_i12,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_markers_0_0),
		mercury____Unify___lambda__lambda_info_0_0_i14,
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___lambda__lambda_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	if ((MR_stackvar(7) != MR_stackvar(17)))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	if ((strcmp((char *)MR_stackvar(8), (char *)MR_stackvar(18)) != 0))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	if ((strcmp((char *)MR_stackvar(9), (char *)MR_stackvar(19)) != 0))
		GOTO_LABEL(mercury____Unify___lambda__lambda_info_0_0_i1);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(20);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		STATIC(mercury____Unify___lambda__lambda_info_0_0));
Define_label(mercury____Unify___lambda__lambda_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lambda_module14)
	init_entry(mercury____Index___lambda__lambda_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___lambda__lambda_info_0_0);
	tailcall(STATIC(mercury____Index___lambda__lambda_info_0__ua0_2_0),
		STATIC(mercury____Index___lambda__lambda_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___prog_data__class_constraints_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_markers_0_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);

BEGIN_MODULE(lambda_module15)
	init_entry(mercury____Compare___lambda__lambda_info_0_0);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i3);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i7);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i11);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i15);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i19);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i23);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i27);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i31);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i35);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i39);
	init_label(mercury____Compare___lambda__lambda_info_0_0_i52);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___lambda__lambda_info_0_0);
	MR_incr_sp_push_msg(21, "lambda:__Compare__/3");
	MR_stackvar(21) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___lambda__lambda_info_0_0_i3,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lambda__lambda_info_0_0_i7,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Compare___prog_data__class_constraints_0_0),
		mercury____Compare___lambda__lambda_info_0_0_i11,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___lambda__lambda_info_0_0_i15,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lambda__lambda_info_0_0_i19,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lambda__common_0);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lambda__lambda_info_0_0_i23,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_markers_0_0),
		mercury____Compare___lambda__lambda_info_0_0_i27,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(17);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___lambda__lambda_info_0_0_i31,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(18);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___lambda__lambda_info_0_0_i35,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___lambda__lambda_info_0_0_i39,
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___lambda__lambda_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lambda__lambda_info_0_0_i52);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(20);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		STATIC(mercury____Compare___lambda__lambda_info_0_0));
Define_label(mercury____Compare___lambda__lambda_info_0_0_i52);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__lambda_maybe_bunch_0(void)
{
	lambda_module0();
	lambda_module1();
	lambda_module2();
	lambda_module3();
	lambda_module4();
	lambda_module5();
	lambda_module6();
	lambda_module7();
	lambda_module8();
	lambda_module9();
	lambda_module10();
	lambda_module11();
	lambda_module12();
	lambda_module13();
	lambda_module14();
	lambda_module15();
}

#endif

void mercury__lambda__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__lambda__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__lambda_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lambda__type_ctor_info_lambda_info_0,
			lambda__lambda_info_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
