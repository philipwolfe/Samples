/*
** Automatically generated from `lco.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__lco__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__lco__lco_in_conj__ua0_4_0);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i1004);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i3);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i4);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i10);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i11);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i8);
Declare_label(mercury__lco__lco_in_conj__ua0_4_0_i13);
Declare_static(mercury__lco__lco_in_cases__ua0_3_0);
Declare_label(mercury__lco__lco_in_cases__ua0_3_0_i4);
Declare_label(mercury__lco__lco_in_cases__ua0_3_0_i5);
Declare_label(mercury__lco__lco_in_cases__ua0_3_0_i3);
Declare_static(mercury__lco__lco_in_disj__ua0_3_0);
Declare_label(mercury__lco__lco_in_disj__ua0_3_0_i4);
Declare_label(mercury__lco__lco_in_disj__ua0_3_0_i5);
Declare_label(mercury__lco__lco_in_disj__ua0_3_0_i3);
Declare_static(mercury__lco__lco_in_goal_2__ua0_3_0);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i4);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i5);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i6);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i9);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i10);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i11);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i13);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i14);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i16);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i17);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i18);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i19);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i20);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1019);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i24);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i25);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1011);
Declare_label(mercury__lco__lco_in_goal_2__ua0_3_0_i2);
Define_extern_entry(mercury__lco__lco_modulo_constructors_7_0);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i2);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i3);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i5);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i4);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i7);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i8);
Declare_label(mercury__lco__lco_modulo_constructors_7_0_i9);

static const struct mercury_data_lco__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lco__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_lco__common_0_struct mercury_data_lco__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(lco_module0)
	init_entry(mercury__lco__lco_in_conj__ua0_4_0);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i1004);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i3);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i4);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i10);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i11);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i8);
	init_label(mercury__lco__lco_in_conj__ua0_4_0_i13);
BEGIN_CODE

/* code for predicate 'lco_in_conj__ua0'/4 in mode 0 */
Define_static(mercury__lco__lco_in_conj__ua0_4_0);
	MR_incr_sp_push_msg(2, "lco:lco_in_conj__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i4);
	r6 = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lco__lco_in_conj__ua0_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	r1 = r5;
	r2 = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i1004);
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i4);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__lco__lco_in_conj__ua0_4_0_i8);
	MR_stackvar(1) = r5;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lco__lco_in_conj__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__lco__lco_in_conj__ua0_4_0_i10,
		STATIC(mercury__lco__lco_in_conj__ua0_4_0));
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i10);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_conj__ua0_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__lco__lco_in_conj__ua0_4_0_i11,
		STATIC(mercury__lco__lco_in_conj__ua0_4_0));
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i11);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_conj__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__lco__lco_in_conj__ua0_4_0));
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i8);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__lco__lco_in_conj__ua0_4_0_i13,
		STATIC(mercury__lco__lco_in_conj__ua0_4_0));
Define_label(mercury__lco__lco_in_conj__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_conj__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__lco__lco_in_conj__ua0_4_0));
END_MODULE


BEGIN_MODULE(lco_module1)
	init_entry(mercury__lco__lco_in_cases__ua0_3_0);
	init_label(mercury__lco__lco_in_cases__ua0_3_0_i4);
	init_label(mercury__lco__lco_in_cases__ua0_3_0_i5);
	init_label(mercury__lco__lco_in_cases__ua0_3_0_i3);
BEGIN_CODE

/* code for predicate 'lco_in_cases__ua0'/3 in mode 0 */
Define_static(mercury__lco__lco_in_cases__ua0_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lco__lco_in_cases__ua0_3_0_i3);
	MR_incr_sp_push_msg(4, "lco:lco_in_cases__ua0/3");
	MR_stackvar(4) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__lco__lco_in_goal_2__ua0_3_0),
		mercury__lco__lco_in_cases__ua0_3_0_i4,
		STATIC(mercury__lco__lco_in_cases__ua0_3_0));
Define_label(mercury__lco__lco_in_cases__ua0_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_cases__ua0_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_cases__ua0_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_cases__ua0_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	localcall(mercury__lco__lco_in_cases__ua0_3_0,
		LABEL(mercury__lco__lco_in_cases__ua0_3_0_i5),
		STATIC(mercury__lco__lco_in_cases__ua0_3_0));
Define_label(mercury__lco__lco_in_cases__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_cases__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lco__lco_in_cases__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lco__lco_in_cases__ua0_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(lco_module2)
	init_entry(mercury__lco__lco_in_disj__ua0_3_0);
	init_label(mercury__lco__lco_in_disj__ua0_3_0_i4);
	init_label(mercury__lco__lco_in_disj__ua0_3_0_i5);
	init_label(mercury__lco__lco_in_disj__ua0_3_0_i3);
BEGIN_CODE

/* code for predicate 'lco_in_disj__ua0'/3 in mode 0 */
Define_static(mercury__lco__lco_in_disj__ua0_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lco__lco_in_disj__ua0_3_0_i3);
	MR_incr_sp_push_msg(3, "lco:lco_in_disj__ua0/3");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__lco__lco_in_goal_2__ua0_3_0),
		mercury__lco__lco_in_disj__ua0_3_0_i4,
		STATIC(mercury__lco__lco_in_disj__ua0_3_0));
Define_label(mercury__lco__lco_in_disj__ua0_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_disj__ua0_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_disj__ua0_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	localcall(mercury__lco__lco_in_disj__ua0_3_0,
		LABEL(mercury__lco__lco_in_disj__ua0_3_0_i5),
		STATIC(mercury__lco__lco_in_disj__ua0_3_0));
Define_label(mercury__lco__lco_in_disj__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_disj__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lco__lco_in_disj__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lco__lco_in_disj__ua0_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(lco_module3)
	init_entry(mercury__lco__lco_in_goal_2__ua0_3_0);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i4);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i5);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i6);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i9);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i10);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i11);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i13);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i14);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i16);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i17);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i18);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i19);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i20);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1019);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i24);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i25);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1011);
	init_label(mercury__lco__lco_in_goal_2__ua0_3_0_i2);
BEGIN_CODE

/* code for predicate 'lco_in_goal_2__ua0'/3 in mode 0 */
Define_static(mercury__lco__lco_in_goal_2__ua0_3_0);
	MR_incr_sp_push_msg(6, "lco:lco_in_goal_2__ua0/3");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i4) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i1011) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i1011) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i9));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lco__common_0);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i5,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__lco__lco_in_conj__ua0_4_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i6,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i6);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__lco__lco_in_goal_2__ua0_3_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i10) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i2) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i13) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i2) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i16) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i18) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i2) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i1019) AND
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i24));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	call_localret(STATIC(mercury__lco__lco_in_cases__ua0_3_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i11,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i11);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__lco__lco_in_goal_2__ua0_3_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i13);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__lco__lco_in_disj__ua0_3_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i14,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i14);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__lco__lco_in_goal_2__ua0_3_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i16);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	localcall(mercury__lco__lco_in_goal_2__ua0_3_0,
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i17),
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i17);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__lco__lco_in_goal_2__ua0_3_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_goal_2__ua0_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i18);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	localcall(mercury__lco__lco_in_goal_2__ua0_3_0,
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i19),
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i19);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_goal_2__ua0_3_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__lco__lco_in_goal_2__ua0_3_0,
		LABEL(mercury__lco__lco_in_goal_2__ua0_3_0_i20),
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i20);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 6, mercury__lco__lco_in_goal_2__ua0_3_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lco__lco_in_goal_2__ua0_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1019);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__lco__lco_in_goal_2__ua0_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Word) MR_string_const("sorry: lco of parallel conjunction not implemented", 50);
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i25,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i24);
	r1 = (Word) MR_string_const("lco_in_goal_2: unexpected bi_implication", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lco__lco_in_goal_2__ua0_3_0_i25,
		STATIC(mercury__lco__lco_in_goal_2__ua0_3_0));
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i25);
	update_prof_current_proc(LABEL(mercury__lco__lco_in_goal_2__ua0_3_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i1011);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lco__lco_in_goal_2__ua0_3_0_i2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury____Unify___std_util__pair_2_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);

BEGIN_MODULE(lco_module4)
	init_entry(mercury__lco__lco_modulo_constructors_7_0);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i2);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i3);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i5);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i4);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i7);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i8);
	init_label(mercury__lco__lco_modulo_constructors_7_0_i9);
BEGIN_CODE

/* code for predicate 'lco_modulo_constructors'/7 in mode 0 */
Define_entry(mercury__lco__lco_modulo_constructors_7_0);
	MR_incr_sp_push_msg(8, "lco:lco_modulo_constructors/7");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__lco__lco_modulo_constructors_7_0_i2,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i2);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	MR_stackvar(6) = r1;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__lco__lco_in_goal_2__ua0_3_0),
		mercury__lco__lco_modulo_constructors_7_0_i3,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i3);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lco__lco_modulo_constructors_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__lco__lco_modulo_constructors_7_0_i5,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i5);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__lco__lco_modulo_constructors_7_0_i4);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lco__lco_modulo_constructors_7_0_i4);
	r1 = (Word) MR_string_const("% Can introduce LCO in ", 23);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__lco__lco_modulo_constructors_7_0_i7,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__lco__lco_modulo_constructors_7_0_i8,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__lco__lco_modulo_constructors_7_0_i9,
		ENTRY(mercury__lco__lco_modulo_constructors_7_0));
Define_label(mercury__lco__lco_modulo_constructors_7_0_i9);
	update_prof_current_proc(LABEL(mercury__lco__lco_modulo_constructors_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__lco_maybe_bunch_0(void)
{
	lco_module0();
	lco_module1();
	lco_module2();
	lco_module3();
	lco_module4();
}

#endif

void mercury__lco__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__lco__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__lco_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
