/*
** Automatically generated from `live_vars.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__live_vars__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__live_vars__allocate_stack_slots_in_proc_4_0);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i2);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i3);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i4);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i5);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i6);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i7);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i12);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i13);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i9);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i14);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i15);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i16);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i17);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i18);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i19);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i20);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i21);
Declare_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i22);
Declare_static(mercury__live_vars__build_live_sets_in_goal_10_0);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i2);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i3);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i7);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i12);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i8);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i13);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i14);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i1001);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i16);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i19);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i20);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i22);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i23);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i25);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i26);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i27);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i15);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i28);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i31);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i29);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i33);
Declare_label(mercury__live_vars__build_live_sets_in_goal_10_0_i35);
Declare_static(mercury__live_vars__build_live_sets_in_goal_2_11_0);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1017);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i7);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i9);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i11);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i12);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i13);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i14);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i19);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i20);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i21);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i22);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i23);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i24);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i25);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i26);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i27);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i28);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i29);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i33);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i34);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i36);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i39);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i37);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i42);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i44);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i45);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i46);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i47);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i48);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i52);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i53);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i54);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i55);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i56);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i57);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i58);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i63);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i59);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i60);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i64);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i65);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i66);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i67);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i68);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1007);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i69);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i73);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i74);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i75);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i76);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i78);
Declare_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i79);
Declare_static(mercury__live_vars__build_live_sets_in_conj_10_0);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i1002);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i3);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_conj_10_0_i9);
Declare_static(mercury__live_vars__build_live_sets_in_disj_11_0);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i9);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i10);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i1002);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i12);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i13);
Declare_label(mercury__live_vars__build_live_sets_in_disj_11_0_i3);
Declare_static(mercury__live_vars__build_live_sets_in_cases_10_0);
Declare_label(mercury__live_vars__build_live_sets_in_cases_10_0_i4);
Declare_label(mercury__live_vars__build_live_sets_in_cases_10_0_i5);
Declare_label(mercury__live_vars__build_live_sets_in_cases_10_0_i6);
Declare_label(mercury__live_vars__build_live_sets_in_cases_10_0_i3);
Declare_static(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0);
Declare_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i4);
Declare_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i5);
Declare_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i6);
Declare_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i2);
Declare_static(mercury__live_vars__find_output_vars_5_0);
Declare_label(mercury__live_vars__find_output_vars_5_0_i2);
Declare_label(mercury__live_vars__find_output_vars_5_0_i3);
Declare_label(mercury__live_vars__find_output_vars_5_0_i4);
Declare_label(mercury__live_vars__find_output_vars_5_0_i5);
Declare_label(mercury__live_vars__find_output_vars_5_0_i6);
Declare_label(mercury__live_vars__find_output_vars_5_0_i7);
Declare_label(mercury__live_vars__find_output_vars_5_0_i8);
Declare_static(mercury__live_vars__find_output_vars_from_arg_info_3_0);
Declare_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
Declare_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
Declare_static(mercury__live_vars__find_output_vars_2_3_0);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i1002);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i6);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i4);
Declare_label(mercury__live_vars__find_output_vars_2_3_0_i3);
Declare_static(mercury__live_vars__allocate_stack_slots_2_5_0);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1002);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
Declare_label(mercury__live_vars__allocate_stack_slots_2_5_0_i3);
Declare_static(mercury__live_vars__allocate_same_stack_slot_4_0);
Declare_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1001);
Declare_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
Declare_label(mercury__live_vars__allocate_same_stack_slot_4_0_i3);

static const struct mercury_data_live_vars__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_live_vars__common_0;

static const struct mercury_data_live_vars__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_live_vars__common_1;

static const struct mercury_data_live_vars__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_live_vars__common_2;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_live_vars__common_0_struct mercury_data_live_vars__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_live_vars__common_1_struct mercury_data_live_vars__common_1 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_live_vars__common_2_struct mercury_data_live_vars__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__liveness__initial_liveness_4_0);
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__hlds_module__module_info_globals_2_0);
Declare_entry(mercury__globals__get_trace_level_2_0);
Declare_entry(mercury__trace__fail_vars_3_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__trace__reserved_slots_3_0);
Declare_entry(mercury__hlds_pred__body_should_use_typeinfo_liveness_2_0);
Declare_entry(mercury__graph_colour__group_elements_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__hlds_pred__proc_info_set_stack_slots_3_0);

BEGIN_MODULE(live_vars_module0)
	init_entry(mercury__live_vars__allocate_stack_slots_in_proc_4_0);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i2);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i3);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i4);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i5);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i6);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i7);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i12);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i13);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i9);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i14);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i15);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i16);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i17);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i18);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i19);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i20);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i21);
	init_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i22);
BEGIN_CODE

/* code for predicate 'allocate_stack_slots_in_proc'/4 in mode 0 */
Define_entry(mercury__live_vars__allocate_stack_slots_in_proc_4_0);
	MR_incr_sp_push_msg(11, "live_vars:allocate_stack_slots_in_proc/4");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i2,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i3,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__liveness__initial_liveness_4_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i4,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i5,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i6,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__globals__get_trace_level_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i7,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	if (((Integer) r1 == (Integer) 0))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i9);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__trace__fail_vars_3_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i12,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i13,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	GOTO_LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i15);
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i14,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i14);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	MR_stackvar(9) = MR_stackvar(6);
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i15);
	MR_stackvar(1) = r1;
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__trace__reserved_slots_3_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i16,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i16);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__body_should_use_typeinfo_liveness_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i17,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i17);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r7 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(9);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i18,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i18);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = r3;
	call_localret(ENTRY(mercury__graph_colour__group_elements_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i19,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i19);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i20,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i20);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i21,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i21);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r4 = r1;
	r1 = MR_stackvar(8);
	r2 = ((Integer) 1 + (Integer) MR_stackvar(10));
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__live_vars__allocate_stack_slots_2_5_0),
		mercury__live_vars__allocate_stack_slots_in_proc_4_0_i22,
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
Define_label(mercury__live_vars__allocate_stack_slots_in_proc_4_0_i22);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_set_stack_slots_3_0),
		ENTRY(mercury__live_vars__allocate_stack_slots_in_proc_4_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_pre_births_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_post_deaths_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_post_births_2_0);
Declare_entry(mercury__set__difference_3_0);
Declare_entry(mercury__set__union_3_0);
Declare_entry(mercury__hlds_goal__goal_is_atomic_1_0);
Declare_entry(mercury__hlds_goal__goal_info_get_resume_point_2_0);

BEGIN_MODULE(live_vars_module1)
	init_entry(mercury__live_vars__build_live_sets_in_goal_10_0);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i2);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i3);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i7);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i12);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i8);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i13);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i14);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i1001);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i16);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i19);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i20);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i22);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i23);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i25);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i26);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i27);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i15);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i28);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i31);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i29);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i33);
	init_label(mercury__live_vars__build_live_sets_in_goal_10_0_i35);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_goal'/10 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_goal_10_0);
	MR_incr_sp_push_msg(14, "live_vars:build_live_sets_in_goal/10");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(9) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i2,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_births_2_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i3,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_deaths_2_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_post_births_2_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i5,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(12) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i7,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i12,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i12);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(9);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i13);
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i8);
	r1 = MR_stackvar(9);
	MR_stackvar(1) = MR_stackvar(10);
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i13);
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i14,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i14);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i16);
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i1001);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r1 = MR_stackvar(8);
	r5 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i15);
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(1), r1, (Integer) 1),
		LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i1001) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i19) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i22) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i25));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i19);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i20,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i20);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r3 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_10_0_i27,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i22);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i23,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i23);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r3 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_10_0_i27,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i25);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i26,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i26);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r3 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_10_0_i27,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i27);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r4 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i15);
	MR_stackvar(8) = r1;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i28,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i28);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(1) = r2;
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_is_atomic_1_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i31,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i31);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_10_0_i29);
	r3 = MR_stackvar(12);
	r2 = MR_stackvar(13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i35,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i29);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(13);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i33,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i33);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_10_0_i35,
		STATIC(mercury__live_vars__build_live_sets_in_goal_10_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_10_0_i35);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_10_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__map__apply_to_list_3_0);
Declare_entry(mercury__arg_info__make_arg_infos_5_0);
Declare_entry(mercury__prog_data__may_call_mercury_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(live_vars_module2)
	init_entry(mercury__live_vars__build_live_sets_in_goal_2_11_0);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1017);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i7);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i9);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i11);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i12);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i13);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i14);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i19);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i20);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i21);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i22);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i23);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i24);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i25);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i26);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i27);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i28);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i29);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i33);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i34);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i36);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i39);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i37);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i42);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i44);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i45);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i46);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i47);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i48);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i52);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i53);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i54);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i55);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i56);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i57);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i58);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i63);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i59);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i60);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i64);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i65);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i66);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i67);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i68);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1007);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i69);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i73);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i74);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i75);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i76);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i78);
	init_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i79);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_goal_2'/11 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_goal_2_11_0);
	MR_incr_sp_push_msg(12, "live_vars:build_live_sets_in_goal_2/11");
	MR_stackvar(12) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1017) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i6) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i19) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i33));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1017);
	r5 = r6;
	r6 = r7;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r7 = r8;
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_conj_10_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i6);
	r9 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r10 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r11 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r12 = r2;
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i7);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i7);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = r11;
	r2 = r10;
	r3 = r9;
	r4 = r6;
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r12;
	call_localret(STATIC(mercury__live_vars__find_output_vars_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i9,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i11,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i11);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i12,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i12);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i13,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i13);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i14,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i14);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i19);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i20,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i20);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i21,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i21);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_2);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i22,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i22);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(11);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__arg_info__make_arg_infos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i23,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i23);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i24,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i24);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i25,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i25);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i26,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i26);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i27,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i27);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i28,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i28);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i29,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i29);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i33);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i34) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i36) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i42) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i44) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i46) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i52) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i57) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i73) AND
		LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i78));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i34);
	r5 = r6;
	r6 = r7;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r7 = r8;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_cases_10_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i36);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r5 = r3;
	r6 = r2;
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i37);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i37);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i39,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i39);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i1007,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i37);
	r1 = r6;
	r2 = r5;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i42);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_disj_11_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i44);
	r5 = r6;
	r6 = r7;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r7 = r8;
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i45,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i45);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i46);
	MR_stackvar(4) = r5;
	r5 = r6;
	r6 = r7;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r7 = r8;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i47,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i47);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i48,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i48);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i49);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i52);
	r5 = r6;
	MR_stackvar(5) = r6;
	r6 = r7;
	MR_stackvar(6) = r7;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r7 = r8;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(7) = r8;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i53,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i53);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i54,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i54);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r3;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i55,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i55);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r3 = MR_tempr1;
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i56,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i56);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i57);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i58,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i58);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) r1 == (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i60);
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__prog_data__may_call_mercury_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i63,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i63);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i59);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i59);
	r1 = MR_stackvar(4);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i60);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(11);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__live_vars__find_output_vars_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i64,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i64);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i65,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i65);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i66,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i66);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i67,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i67);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r3 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i68,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i68);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	if (((Integer) MR_stackvar(4) != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0_i69);
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i1007);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r3 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i69);
	r3 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i73);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i74,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i74);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i75,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i75);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i76,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i76);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r4 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_disj_11_0),
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i78);
	r1 = (Word) MR_string_const("build_live_sets_in_goal_2: unexpected bi_implication", 52);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__live_vars__build_live_sets_in_goal_2_11_0_i79,
		STATIC(mercury__live_vars__build_live_sets_in_goal_2_11_0));
Define_label(mercury__live_vars__build_live_sets_in_goal_2_11_0_i79);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_goal_2_11_0));
	r3 = MR_stackvar(1);
	r1 = MR_stackvar(8);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);

BEGIN_MODULE(live_vars_module3)
	init_entry(mercury__live_vars__build_live_sets_in_conj_10_0);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i1002);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i3);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_conj_10_0_i9);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_conj'/10 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_conj_10_0);
	MR_incr_sp_push_msg(9, "live_vars:build_live_sets_in_conj/10");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i1002);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_conj_10_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = MR_tempr1;
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__live_vars__build_live_sets_in_conj_10_0_i5,
		STATIC(mercury__live_vars__build_live_sets_in_conj_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_10_0));
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__live_vars__build_live_sets_in_conj_10_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_conj_10_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_conj_10_0_i4);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		STATIC(mercury__live_vars__build_live_sets_in_conj_10_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i4);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_conj_10_0_i9,
		STATIC(mercury__live_vars__build_live_sets_in_conj_10_0));
Define_label(mercury__live_vars__build_live_sets_in_conj_10_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_conj_10_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(8);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__live_vars__build_live_sets_in_conj_10_0_i1002);
END_MODULE


BEGIN_MODULE(live_vars_module4)
	init_entry(mercury__live_vars__build_live_sets_in_disj_11_0);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i9);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i10);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i1002);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i12);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i13);
	init_label(mercury__live_vars__build_live_sets_in_disj_11_0_i3);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_disj'/11 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_disj_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_11_0_i3);
	MR_incr_sp_push_msg(8, "live_vars:build_live_sets_in_disj/11");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(3) = r5;
	r5 = r6;
	MR_stackvar(4) = r6;
	r6 = r7;
	MR_stackvar(5) = r7;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r7 = r8;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(6) = r8;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_disj_11_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	r7 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	r2 = MR_stackvar(1);
	r4 = r3;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r8 = MR_stackvar(6);
	localcall(mercury__live_vars__build_live_sets_in_disj_11_0,
		LABEL(mercury__live_vars__build_live_sets_in_disj_11_0_i5),
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	r1 = MR_stackvar(3);
	MR_stackvar(4) = r3;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__live_vars__build_live_sets_in_disj_11_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_11_0_i1002);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_disj_11_0_i9,
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i9);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_resume_point_2_0),
		mercury__live_vars__build_live_sets_in_disj_11_0_i10,
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i10);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_disj_11_0_i12);
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i1002);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i12);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_disj_11_0_i13,
		STATIC(mercury__live_vars__build_live_sets_in_disj_11_0));
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i13);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_disj_11_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_disj_11_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	proceed();
END_MODULE


BEGIN_MODULE(live_vars_module5)
	init_entry(mercury__live_vars__build_live_sets_in_cases_10_0);
	init_label(mercury__live_vars__build_live_sets_in_cases_10_0_i4);
	init_label(mercury__live_vars__build_live_sets_in_cases_10_0_i5);
	init_label(mercury__live_vars__build_live_sets_in_cases_10_0_i6);
	init_label(mercury__live_vars__build_live_sets_in_cases_10_0_i3);
BEGIN_CODE

/* code for predicate 'build_live_sets_in_cases'/10 in mode 0 */
Define_static(mercury__live_vars__build_live_sets_in_cases_10_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__build_live_sets_in_cases_10_0_i3);
	MR_incr_sp_push_msg(7, "live_vars:build_live_sets_in_cases/10");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	call_localret(STATIC(mercury__live_vars__build_live_sets_in_goal_10_0),
		mercury__live_vars__build_live_sets_in_cases_10_0_i4,
		STATIC(mercury__live_vars__build_live_sets_in_cases_10_0));
Define_label(mercury__live_vars__build_live_sets_in_cases_10_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_10_0));
	r4 = r3;
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	localcall(mercury__live_vars__build_live_sets_in_cases_10_0,
		LABEL(mercury__live_vars__build_live_sets_in_cases_10_0_i5),
		STATIC(mercury__live_vars__build_live_sets_in_cases_10_0));
Define_label(mercury__live_vars__build_live_sets_in_cases_10_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_10_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r3 = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__build_live_sets_in_cases_10_0_i6,
		STATIC(mercury__live_vars__build_live_sets_in_cases_10_0));
	}
Define_label(mercury__live_vars__build_live_sets_in_cases_10_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__build_live_sets_in_cases_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__live_vars__build_live_sets_in_cases_10_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_get_typeinfo_vars_setwise_3_0);

BEGIN_MODULE(live_vars_module6)
	init_entry(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0);
	init_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i4);
	init_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i5);
	init_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i6);
	init_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i2);
BEGIN_CODE

/* code for predicate 'maybe_add_alternate_liveness_typeinfos'/5 in mode 0 */
Define_static(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i2);
	MR_incr_sp_push_msg(4, "live_vars:maybe_add_alternate_liveness_typeinfos/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r2 = r4;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_typeinfo_vars_setwise_3_0),
		mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i4,
		STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
Define_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_typeinfo_vars_setwise_3_0),
		mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i5,
		STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
Define_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i6,
		STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
Define_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__set__union_3_0),
		STATIC(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0));
Define_label(mercury__live_vars__maybe_add_alternate_liveness_typeinfos_5_0_i2);
	r1 = r4;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);

BEGIN_MODULE(live_vars_module7)
	init_entry(mercury__live_vars__find_output_vars_5_0);
	init_label(mercury__live_vars__find_output_vars_5_0_i2);
	init_label(mercury__live_vars__find_output_vars_5_0_i3);
	init_label(mercury__live_vars__find_output_vars_5_0_i4);
	init_label(mercury__live_vars__find_output_vars_5_0_i5);
	init_label(mercury__live_vars__find_output_vars_5_0_i6);
	init_label(mercury__live_vars__find_output_vars_5_0_i7);
	init_label(mercury__live_vars__find_output_vars_5_0_i8);
BEGIN_CODE

/* code for predicate 'find_output_vars'/5 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_5_0);
	MR_incr_sp_push_msg(4, "live_vars:find_output_vars/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__live_vars__find_output_vars_5_0_i2,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__live_vars__find_output_vars_5_0_i3,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__live_vars__find_output_vars_5_0_i4,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__live_vars__find_output_vars_5_0_i5,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i5);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__live_vars__find_output_vars_5_0_i6,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__live_vars__find_output_vars_5_0_i7,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__find_output_vars_5_0_i8,
		STATIC(mercury__live_vars__find_output_vars_5_0));
Define_label(mercury__live_vars__find_output_vars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__live_vars__find_output_vars_2_3_0),
		STATIC(mercury__live_vars__find_output_vars_5_0));
END_MODULE


BEGIN_MODULE(live_vars_module8)
	init_entry(mercury__live_vars__find_output_vars_from_arg_info_3_0);
	init_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
	init_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_output_vars_from_arg_info'/3 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_from_arg_info_3_0);
	MR_incr_sp_push_msg(2, "live_vars:find_output_vars_from_arg_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__live_vars__find_output_vars_from_arg_info_3_0_i2,
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
Define_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i2);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__live_vars__find_output_vars_from_arg_info_3_0_i3,
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
Define_label(mercury__live_vars__find_output_vars_from_arg_info_3_0_i3);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_from_arg_info_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__live_vars__find_output_vars_2_3_0),
		STATIC(mercury__live_vars__find_output_vars_from_arg_info_3_0));
END_MODULE


BEGIN_MODULE(live_vars_module9)
	init_entry(mercury__live_vars__find_output_vars_2_3_0);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i1002);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i6);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i4);
	init_label(mercury__live_vars__find_output_vars_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_output_vars_2'/3 in mode 0 */
Define_static(mercury__live_vars__find_output_vars_2_3_0);
	MR_incr_sp_push_msg(2, "live_vars:find_output_vars_2/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__live_vars__find_output_vars_2_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i4);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__live_vars__find_output_vars_2_3_0_i6,
		STATIC(mercury__live_vars__find_output_vars_2_3_0));
Define_label(mercury__live_vars__find_output_vars_2_3_0_i6);
	update_prof_current_proc(LABEL(mercury__live_vars__find_output_vars_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i1002);
Define_label(mercury__live_vars__find_output_vars_2_3_0_i4);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__live_vars__find_output_vars_2_3_0_i1002);
Define_label(mercury__live_vars__find_output_vars_2_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(live_vars_module10)
	init_entry(mercury__live_vars__allocate_stack_slots_2_5_0);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1002);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
	init_label(mercury__live_vars__allocate_stack_slots_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'allocate_stack_slots_2'/5 in mode 0 */
Define_static(mercury__live_vars__allocate_stack_slots_2_5_0);
	MR_incr_sp_push_msg(5, "live_vars:allocate_stack_slots_2/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i3);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__live_vars__allocate_stack_slots_2_5_0_i4,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_2_5_0));
	if (((Integer) MR_stackvar(2) != (Integer) 2))
		GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__live_vars__allocate_stack_slots_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__allocate_same_stack_slot_4_0),
		mercury__live_vars__allocate_stack_slots_2_5_0_i8,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i5);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__live_vars__allocate_stack_slots_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	call_localret(STATIC(mercury__live_vars__allocate_same_stack_slot_4_0),
		mercury__live_vars__allocate_stack_slots_2_5_0_i8,
		STATIC(mercury__live_vars__allocate_stack_slots_2_5_0));
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_stack_slots_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__live_vars__allocate_stack_slots_2_5_0_i1002);
Define_label(mercury__live_vars__allocate_stack_slots_2_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(live_vars_module11)
	init_entry(mercury__live_vars__allocate_same_stack_slot_4_0);
	init_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1001);
	init_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
	init_label(mercury__live_vars__allocate_same_stack_slot_4_0_i3);
BEGIN_CODE

/* code for predicate 'allocate_same_stack_slot'/4 in mode 0 */
Define_static(mercury__live_vars__allocate_same_stack_slot_4_0);
	MR_incr_sp_push_msg(3, "live_vars:allocate_same_stack_slot/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__live_vars__allocate_same_stack_slot_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__live_vars__allocate_same_stack_slot_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_live_vars__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__live_vars__allocate_same_stack_slot_4_0_i4,
		STATIC(mercury__live_vars__allocate_same_stack_slot_4_0));
Define_label(mercury__live_vars__allocate_same_stack_slot_4_0_i4);
	update_prof_current_proc(LABEL(mercury__live_vars__allocate_same_stack_slot_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__live_vars__allocate_same_stack_slot_4_0_i1001);
Define_label(mercury__live_vars__allocate_same_stack_slot_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__live_vars_maybe_bunch_0(void)
{
	live_vars_module0();
	live_vars_module1();
	live_vars_module2();
	live_vars_module3();
	live_vars_module4();
	live_vars_module5();
	live_vars_module6();
	live_vars_module7();
	live_vars_module8();
	live_vars_module9();
	live_vars_module10();
	live_vars_module11();
}

#endif

void mercury__live_vars__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__live_vars__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__live_vars_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
