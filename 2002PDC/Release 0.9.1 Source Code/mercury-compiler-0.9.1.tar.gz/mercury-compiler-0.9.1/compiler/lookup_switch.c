/*
** Automatically generated from `lookup_switch.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__lookup_switch__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__lookup_switch__generate_bitvec_test__ua0_7_0);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i2);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i3);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i4);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i5);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i6);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i7);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i8);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i9);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i10);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i11);
Declare_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
Declare_static(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0);
Declare_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1);
Declare_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i2);
Declare_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i3);
Declare_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1007);
Define_extern_entry(mercury__lookup_switch__is_lookup_switch_15_0);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i12);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i15);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i16);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i25);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i31);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
Declare_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
Define_extern_entry(mercury__lookup_switch__generate_14_0);
Declare_label(mercury__lookup_switch__generate_14_0_i2);
Declare_label(mercury__lookup_switch__generate_14_0_i3);
Declare_label(mercury__lookup_switch__generate_14_0_i5);
Declare_label(mercury__lookup_switch__generate_14_0_i8);
Declare_label(mercury__lookup_switch__generate_14_0_i7);
Declare_label(mercury__lookup_switch__generate_14_0_i6);
Declare_label(mercury__lookup_switch__generate_14_0_i11);
Declare_label(mercury__lookup_switch__generate_14_0_i10);
Declare_label(mercury__lookup_switch__generate_14_0_i12);
Declare_label(mercury__lookup_switch__generate_14_0_i13);
Declare_label(mercury__lookup_switch__generate_14_0_i14);
Declare_label(mercury__lookup_switch__generate_14_0_i16);
Declare_label(mercury__lookup_switch__generate_14_0_i18);
Declare_label(mercury__lookup_switch__generate_14_0_i19);
Declare_static(mercury__lookup_switch__generate_constants_7_0);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i3);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i5);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i6);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i7);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i8);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i10);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i12);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i13);
Declare_label(mercury__lookup_switch__generate_constants_7_0_i1);
Declare_static(mercury__lookup_switch__get_case_rvals_4_0);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i3);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
Declare_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
Declare_static(mercury__lookup_switch__rval_is_constant_2_0);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1017);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i14);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i4);
Declare_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
Declare_static(mercury__lookup_switch__rvals_are_constant_2_0);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i1003);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i2);
Declare_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
Declare_static(mercury__lookup_switch__generate_bit_vec_2_5_0);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1002);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i4);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i11);
Declare_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i3);
Declare_static(mercury__lookup_switch__generate_bit_vec_args_3_0);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i3);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
Declare_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
Declare_static(mercury__lookup_switch__generate_terms_2_5_0);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i1001);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
Declare_label(mercury__lookup_switch__generate_terms_2_5_0_i3);
Declare_static(mercury__lookup_switch__construct_args_3_0);
Declare_label(mercury__lookup_switch__construct_args_3_0_i6);
Declare_label(mercury__lookup_switch__construct_args_3_0_i3);
Declare_label(mercury__lookup_switch__construct_args_3_0_i4);
Declare_label(mercury__lookup_switch__construct_args_3_0_i7);
Declare_label(mercury__lookup_switch__construct_args_3_0_i2);
Declare_static(mercury__lookup_switch__rearrange_vals_5_0);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i1001);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
Declare_label(mercury__lookup_switch__rearrange_vals_5_0_i3);
Declare_static(mercury__lookup_switch__rearrange_vals_2_4_0);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1002);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i4);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
Declare_label(mercury__lookup_switch__rearrange_vals_2_4_0_i3);
Define_extern_entry(mercury____Unify___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Index___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Compare___lookup_switch__case_consts_0_0);
Define_extern_entry(mercury____Unify___lookup_switch__rval_map_0_0);
Define_extern_entry(mercury____Index___lookup_switch__rval_map_0_0);
Define_extern_entry(mercury____Compare___lookup_switch__rval_map_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_lookup_switch__type_ctor_info_case_consts_0;

const struct MR_TypeCtorInfo_struct mercury_data_lookup_switch__type_ctor_info_rval_map_0;

static const struct mercury_data_lookup_switch__common_0_struct {
	Word * f1;
}  mercury_data_lookup_switch__common_0;

static const struct mercury_data_lookup_switch__common_1_struct {
	Integer f1;
}  mercury_data_lookup_switch__common_1;

static const struct mercury_data_lookup_switch__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__common_2;

static const struct mercury_data_lookup_switch__common_3_struct {
	Integer f1;
}  mercury_data_lookup_switch__common_3;

static const struct mercury_data_lookup_switch__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_4;

static const struct mercury_data_lookup_switch__common_5_struct {
	Word * f1;
}  mercury_data_lookup_switch__common_5;

static const struct mercury_data_lookup_switch__common_6_struct {
	Word * f1;
}  mercury_data_lookup_switch__common_6;

static const struct mercury_data_lookup_switch__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_7;

static const struct mercury_data_lookup_switch__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_lookup_switch__common_8;

static const struct mercury_data_lookup_switch__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lookup_switch__common_9;

static const struct mercury_data_lookup_switch__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_10;

static const struct mercury_data_lookup_switch__common_11_struct {
	String f1;
}  mercury_data_lookup_switch__common_11;

static const struct mercury_data_lookup_switch__common_12_struct {
	Word * f1;
	String f2;
}  mercury_data_lookup_switch__common_12;

static const struct mercury_data_lookup_switch__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_13;

static const struct mercury_data_lookup_switch__common_14_struct {
	Word * f1;
}  mercury_data_lookup_switch__common_14;

static const struct mercury_data_lookup_switch__common_15_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lookup_switch__common_15;

static const struct mercury_data_lookup_switch__common_16_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__common_16;

static const struct mercury_data_lookup_switch__common_17_struct {
	Word * f1;
}  mercury_data_lookup_switch__common_17;

static const struct mercury_data_lookup_switch__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_18;

static const struct mercury_data_lookup_switch__common_19_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lookup_switch__common_19;

static const struct mercury_data_lookup_switch__common_20_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lookup_switch__common_20;

static const struct mercury_data_lookup_switch__common_21_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__common_21;

static const struct mercury_data_lookup_switch__common_22_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lookup_switch__common_22;

static const struct mercury_data_lookup_switch__common_23_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__common_23;

static const struct mercury_data_lookup_switch__type_ctor_functors_rval_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__type_ctor_functors_rval_map_0;

static const struct mercury_data_lookup_switch__type_ctor_layout_rval_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lookup_switch__type_ctor_layout_rval_map_0;

static const struct mercury_data_lookup_switch__type_ctor_functors_case_consts_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lookup_switch__type_ctor_functors_case_consts_0;

static const struct mercury_data_lookup_switch__type_ctor_layout_case_consts_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lookup_switch__type_ctor_layout_case_consts_0;

const struct MR_TypeCtorInfo_struct mercury_data_lookup_switch__type_ctor_info_case_consts_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lookup_switch__case_consts_0_0),
	ENTRY(mercury____Index___lookup_switch__case_consts_0_0),
	ENTRY(mercury____Compare___lookup_switch__case_consts_0_0),
	(Integer) 6,
	(Word *) &mercury_data_lookup_switch__type_ctor_functors_case_consts_0,
	(Word *) &mercury_data_lookup_switch__type_ctor_layout_case_consts_0,
	MR_string_const("lookup_switch", 13),
	MR_string_const("case_consts", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lookup_switch__type_ctor_info_rval_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lookup_switch__rval_map_0_0),
	ENTRY(mercury____Index___lookup_switch__rval_map_0_0),
	ENTRY(mercury____Compare___lookup_switch__rval_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_lookup_switch__type_ctor_functors_rval_map_0,
	(Word *) &mercury_data_lookup_switch__type_ctor_layout_rval_map_0,
	MR_string_const("lookup_switch", 13),
	MR_string_const("rval_map", 8),
	(Integer) 3
};

static const struct mercury_data_lookup_switch__common_0_struct mercury_data_lookup_switch__common_0 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_lookup_switch__common_1_struct mercury_data_lookup_switch__common_1 = {
	(Integer) 1
};

static const struct mercury_data_lookup_switch__common_2_struct mercury_data_lookup_switch__common_2 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_1)
};

static const struct mercury_data_lookup_switch__common_3_struct mercury_data_lookup_switch__common_3 = {
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_lookup_switch__common_4_struct mercury_data_lookup_switch__common_4 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_instmap__type_ctor_info_instmap_0;
static const struct mercury_data_lookup_switch__common_5_struct mercury_data_lookup_switch__common_5 = {
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_lookup_switch__common_6_struct mercury_data_lookup_switch__common_6 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_lookup_switch__common_7_struct mercury_data_lookup_switch__common_7 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4)
};

static const struct mercury_data_lookup_switch__common_8_struct mercury_data_lookup_switch__common_8 = {
	(Integer) 0,
	MR_string_const("lookup_switch", 13),
	MR_string_const("lookup_switch", 13),
	MR_string_const("IntroducedFrom__pred__figure_out_output_vars__179__1", 52),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_rval_0;
static const struct mercury_data_lookup_switch__common_9_struct mercury_data_lookup_switch__common_9 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_llds__type_ctor_info_rval_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_lookup_switch__common_10_struct mercury_data_lookup_switch__common_10 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_9)
};

static const struct mercury_data_lookup_switch__common_11_struct mercury_data_lookup_switch__common_11 = {
	MR_string_const("lookup switch", 13)
};

static const struct mercury_data_lookup_switch__common_12_struct mercury_data_lookup_switch__common_12 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_11),
	MR_string_const("", 0)
};

static const struct mercury_data_lookup_switch__common_13_struct mercury_data_lookup_switch__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_lookup_switch__common_14_struct mercury_data_lookup_switch__common_14 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_13)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_lookup_switch__common_15_struct mercury_data_lookup_switch__common_15 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_lookup_switch__common_16_struct mercury_data_lookup_switch__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_3)
};

static const struct mercury_data_lookup_switch__common_17_struct mercury_data_lookup_switch__common_17 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_16)
};

static const struct mercury_data_lookup_switch__common_18_struct mercury_data_lookup_switch__common_18 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_llds__type_ctor_info_rval_0
};

static const struct mercury_data_lookup_switch__common_19_struct mercury_data_lookup_switch__common_19 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_18)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_lookup_switch__common_20_struct mercury_data_lookup_switch__common_20 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10)
};

static const struct mercury_data_lookup_switch__common_21_struct mercury_data_lookup_switch__common_21 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_20)
};

static const struct mercury_data_lookup_switch__common_22_struct mercury_data_lookup_switch__common_22 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_19)
};

static const struct mercury_data_lookup_switch__common_23_struct mercury_data_lookup_switch__common_23 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_22)
};

static const struct mercury_data_lookup_switch__type_ctor_functors_rval_map_0_struct mercury_data_lookup_switch__type_ctor_functors_rval_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_20)
};

static const struct mercury_data_lookup_switch__type_ctor_layout_rval_map_0_struct mercury_data_lookup_switch__type_ctor_layout_rval_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_21)
};

static const struct mercury_data_lookup_switch__type_ctor_functors_case_consts_0_struct mercury_data_lookup_switch__type_ctor_functors_case_consts_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_22)
};

static const struct mercury_data_lookup_switch__type_ctor_layout_case_consts_0_struct mercury_data_lookup_switch__type_ctor_layout_case_consts_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_23)
};

Declare_entry(mercury__int__bits_per_int_1_0);
Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__globals__get_options_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_options__type_ctor_info_option_0;
Declare_entry(mercury__getopt__lookup_int_option_3_0);
Declare_entry(mercury__int__min_3_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__code_info__get_next_cell_number_3_0);
Declare_entry(mercury__code_info__fail_if_rval_is_false_4_0);

BEGIN_MODULE(lookup_switch_module0)
	init_entry(mercury__lookup_switch__generate_bitvec_test__ua0_7_0);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i2);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i3);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i4);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i5);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i6);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i7);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i8);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i9);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i10);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i11);
	init_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
BEGIN_CODE

/* code for predicate 'generate_bitvec_test__ua0'/7 in mode 0 */
Define_static(mercury__lookup_switch__generate_bitvec_test__ua0_7_0);
	MR_incr_sp_push_msg(6, "lookup_switch:generate_bitvec_test__ua0/7");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__int__bits_per_int_1_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i2,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i3,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i4,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r3 = (Integer) 97;
	call_localret(ENTRY(mercury__getopt__lookup_int_option_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i5,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__int__min_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i6,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i7,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i8,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i9,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lookup_switch__generate_bit_vec_args_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i10,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i11,
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i11);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 6;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 6, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(2), r4, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(2), r4, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), r4, (Integer) 2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_0);
	MR_field(MR_mktag(2), r4, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(2), r4, (Integer) 4) = r1;
	MR_field(MR_mktag(2), r4, (Integer) 5) = (Word) MR_string_const("lookup_switch_bit_vector", 24);
	r5 = r4;
	if ((MR_tag(r5) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
	r7 = r4;
	r6 = MR_const_field(MR_mktag(2), r7, (Integer) 1);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
	if (((Integer) MR_const_field(MR_mktag(1), r6, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
	if (((Integer) MR_const_field(MR_mktag(1), r6, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 7;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r6, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	}
Define_label(mercury__lookup_switch__generate_bitvec_test__ua0_7_0_i1015);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 7;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_lookup_switch__common_2);
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 4;
	MR_field(MR_mktag(3), r6, (Integer) 2) = r3;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 3) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 1, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:lval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_3);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r4;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Integer) 3;
	MR_field(MR_mktag(3), r7, (Integer) 2) = r3;
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_bitvec_test__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = r5;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 3) = r8;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0));
	}
END_MODULE

Declare_entry(do_fail);
Declare_entry(mercury__set__member_2_1);
Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__mode_util__mode_is_output_2_0);
Declare_entry(do_redo);

BEGIN_MODULE(lookup_switch_module1)
	init_entry(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0);
	init_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1);
	init_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i2);
	init_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i3);
	init_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1007);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__figure_out_output_vars__179__1'/5 in mode 0 */
Define_static(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0);
	MR_mkframe("lookup_switch:IntroducedFrom__pred__figure_out_output_vars__179__1/5", 5, ENTRY(do_fail));
	MR_framevar(1) = r1;
	MR_framevar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = r3;
	MR_framevar(3) = r4;
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1,
		STATIC(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
Define_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1);
	update_prof_current_proc(LABEL(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
	MR_framevar(5) = r1;
	r2 = r1;
	r1 = MR_framevar(1);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i2,
		STATIC(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
Define_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
	MR_framevar(4) = r1;
	r1 = MR_framevar(3);
	r2 = MR_framevar(5);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i3,
		STATIC(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
Define_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
	r3 = r1;
	r1 = MR_framevar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0, "prog_data:mode/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_framevar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1007,
		STATIC(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
Define_label(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0_i1007);
	update_prof_current_proc(LABEL(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(5);
	MR_succeed();
END_MODULE

Declare_entry(mercury__getopt__lookup_bool_option_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_switch_gen__type_ctor_info_extended_case_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__index1_det_3_0);
Declare_entry(mercury__dense_switch__calc_density_3_0);
Declare_entry(mercury__code_info__variable_type_4_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__type_util__classify_type_3_0);
Declare_entry(mercury__dense_switch__type_range_5_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__instmap_delta_is_unreachable_1_0);
Declare_entry(mercury__code_info__get_instmap_3_0);
Declare_entry(mercury__instmap__instmap_delta_changed_vars_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
Declare_entry(mercury__std_util__solutions_2_1);

BEGIN_MODULE(lookup_switch_module2)
	init_entry(mercury__lookup_switch__is_lookup_switch_15_0);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i12);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i15);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i16);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i25);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i31);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
	init_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
BEGIN_CODE

/* code for predicate 'is_lookup_switch'/15 in mode 0 */
Define_entry(mercury__lookup_switch__is_lookup_switch_15_0);
	MR_incr_sp_push_msg(17, "lookup_switch:is_lookup_switch/15");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r7;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i2,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i3,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i3);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_options__type_ctor_info_option_0;
	r3 = (Integer) 190;
	call_localret(ENTRY(mercury__getopt__lookup_bool_option_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i4,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i5,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(2);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0), (Integer) 1);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r3 = r1;
	MR_stackvar(7) = r1;
	MR_stackvar(10) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_tempr1;
	call_localret(ENTRY(mercury__list__index1_det_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i8,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = (((Integer) MR_tempr2 - (Integer) MR_stackvar(10)) + (Integer) 1);
	MR_stackvar(11) = MR_tempr2;
	MR_stackvar(8) = r2;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__dense_switch__calc_density_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i10,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
	}
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (((Integer) r1 <= (Integer) MR_stackvar(5)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r1 = MR_stackvar(8);
	if ((MR_stackvar(7) != r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	r1 = MR_stackvar(1);
	MR_stackvar(12) = (Integer) 1;
	r2 = MR_stackvar(9);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i12);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i11);
	r1 = MR_stackvar(1);
	MR_stackvar(12) = (Integer) 0;
	r2 = MR_stackvar(9);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i12);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i13);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i15,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i15);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i16,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i16);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(13) = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i17,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i17);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(13);
	call_localret(ENTRY(mercury__dense_switch__type_range_5_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i19,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i19);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__dense_switch__calc_density_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i21,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i21);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (((Integer) r1 <= (Integer) MR_stackvar(5)))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = (Integer) 0;
	MR_stackvar(5) = ((Integer) r2 - (Integer) 1);
	r3 = MR_stackvar(7);
	MR_stackvar(7) = (Integer) 1;
	MR_stackvar(8) = (Integer) 0;
	MR_stackvar(14) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i24,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i18);
	r1 = MR_stackvar(3);
	MR_stackvar(1) = MR_stackvar(10);
	MR_stackvar(5) = MR_stackvar(11);
	MR_stackvar(7) = MR_stackvar(4);
	MR_stackvar(8) = MR_stackvar(12);
	MR_stackvar(14) = MR_stackvar(13);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i24,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i13);
	r1 = MR_stackvar(3);
	MR_stackvar(1) = MR_stackvar(10);
	MR_stackvar(5) = MR_stackvar(11);
	MR_stackvar(7) = MR_stackvar(4);
	MR_stackvar(8) = MR_stackvar(12);
	MR_stackvar(14) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i24,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i24);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(15) = r1;
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_unreachable_1_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i27,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i27);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i25);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(14);
	GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i34);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i25);
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i29,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i29);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(14) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i30,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i30);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(15);
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__instmap__instmap_delta_changed_vars_2_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i31,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i31);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = MR_stackvar(15);
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i32,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i32);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__lookup_switch__is_lookup_switch_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(15);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(16);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lookup_switch__IntroducedFrom__pred__figure_out_output_vars__179__1_5_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_8);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lookup_switch__is_lookup_switch_15_0_i33,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i33);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(9);
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i34);
	MR_stackvar(9) = r2;
	call_localret(STATIC(mercury__lookup_switch__generate_constants_7_0),
		mercury__lookup_switch__is_lookup_switch_15_0_i35,
		ENTRY(mercury__lookup_switch__is_lookup_switch_15_0));
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i35);
	update_prof_current_proc(LABEL(mercury__lookup_switch__is_lookup_switch_15_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	r7 = r2;
	r8 = r3;
	r9 = r4;
	r1 = TRUE;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(8);
	r6 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__lookup_switch__is_lookup_switch_15_0_i1);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__produce_variable_5_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__code_info__set_forward_live_vars_3_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);

BEGIN_MODULE(lookup_switch_module3)
	init_entry(mercury__lookup_switch__generate_14_0);
	init_label(mercury__lookup_switch__generate_14_0_i2);
	init_label(mercury__lookup_switch__generate_14_0_i3);
	init_label(mercury__lookup_switch__generate_14_0_i5);
	init_label(mercury__lookup_switch__generate_14_0_i8);
	init_label(mercury__lookup_switch__generate_14_0_i7);
	init_label(mercury__lookup_switch__generate_14_0_i6);
	init_label(mercury__lookup_switch__generate_14_0_i11);
	init_label(mercury__lookup_switch__generate_14_0_i10);
	init_label(mercury__lookup_switch__generate_14_0_i12);
	init_label(mercury__lookup_switch__generate_14_0_i13);
	init_label(mercury__lookup_switch__generate_14_0_i14);
	init_label(mercury__lookup_switch__generate_14_0_i16);
	init_label(mercury__lookup_switch__generate_14_0_i18);
	init_label(mercury__lookup_switch__generate_14_0_i19);
BEGIN_CODE

/* code for predicate 'generate'/14 in mode 0 */
Define_entry(mercury__lookup_switch__generate_14_0);
	MR_incr_sp_push_msg(12, "lookup_switch:generate/14");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r11;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__lookup_switch__generate_14_0_i2,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i2);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__generate_14_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_tempr1;
	GOTO_LABEL(mercury__lookup_switch__generate_14_0_i5);
	}
Define_label(mercury__lookup_switch__generate_14_0_i3);
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r2;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__lookup_switch__generate_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	r2 = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r3, (Integer) 3) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	}
Define_label(mercury__lookup_switch__generate_14_0_i5);
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__generate_14_0_i7);
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 23;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__lookup_switch__generate_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__lookup_switch__generate_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = r6;
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) r4 - (Integer) MR_stackvar(3));
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__lookup_switch__generate_14_0_i8,
		ENTRY(mercury__lookup_switch__generate_14_0));
	}
Define_label(mercury__lookup_switch__generate_14_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	r4 = r2;
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__lookup_switch__generate_14_0_i6);
Define_label(mercury__lookup_switch__generate_14_0_i7);
	r4 = r2;
	MR_stackvar(4) = r1;
	r1 = r3;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__lookup_switch__generate_14_0_i6);
	if (((Integer) MR_stackvar(6) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__generate_14_0_i10);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r1;
	MR_stackvar(6) = r5;
	call_localret(STATIC(mercury__lookup_switch__generate_bitvec_test__ua0_7_0),
		mercury__lookup_switch__generate_14_0_i11,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i11);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	MR_stackvar(10) = r1;
	MR_stackvar(11) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lookup_switch__generate_14_0_i12,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i10);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	MR_stackvar(3) = r3;
	MR_stackvar(6) = r5;
	MR_stackvar(10) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(11) = r4;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lookup_switch__generate_14_0_i12,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__lookup_switch__rearrange_vals_5_0),
		mercury__lookup_switch__generate_14_0_i13,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i13);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(11);
	call_localret(STATIC(mercury__lookup_switch__generate_terms_2_5_0),
		mercury__lookup_switch__generate_14_0_i14,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i14);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	if (((Integer) MR_stackvar(7) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_14_0_i16);
	r1 = (Word) MR_string_const("lookup_switch__generate: no liveness!", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lookup_switch__generate_14_0_i18,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i16);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(7), (Integer) 0);
	call_localret(ENTRY(mercury__code_info__set_forward_live_vars_3_0),
		mercury__lookup_switch__generate_14_0_i18,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i18);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	r3 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__lookup_switch__generate_14_0_i19,
		ENTRY(mercury__lookup_switch__generate_14_0));
Define_label(mercury__lookup_switch__generate_14_0_i19);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__lookup_switch__generate_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_14);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__lookup_switch__generate_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__lookup_switch__generate_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__lookup_switch__generate_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__get_forward_live_vars_3_0);
Declare_entry(mercury__tree__tree_of_lists_is_empty_1_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);

BEGIN_MODULE(lookup_switch_module4)
	init_entry(mercury__lookup_switch__generate_constants_7_0);
	init_label(mercury__lookup_switch__generate_constants_7_0_i3);
	init_label(mercury__lookup_switch__generate_constants_7_0_i5);
	init_label(mercury__lookup_switch__generate_constants_7_0_i6);
	init_label(mercury__lookup_switch__generate_constants_7_0_i7);
	init_label(mercury__lookup_switch__generate_constants_7_0_i8);
	init_label(mercury__lookup_switch__generate_constants_7_0_i10);
	init_label(mercury__lookup_switch__generate_constants_7_0_i12);
	init_label(mercury__lookup_switch__generate_constants_7_0_i13);
	init_label(mercury__lookup_switch__generate_constants_7_0_i1);
BEGIN_CODE

/* code for predicate 'generate_constants'/7 in mode 0 */
Define_static(mercury__lookup_switch__generate_constants_7_0);
	MR_incr_sp_push_msg(8, "lookup_switch:generate_constants/7");
	MR_stackvar(8) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lookup_switch__generate_constants_7_0_i3);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__lookup_switch__generate_constants_7_0_i5,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	r3 = r2;
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__lookup_switch__generate_constants_7_0_i6,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_forward_live_vars_3_0),
		mercury__lookup_switch__generate_constants_7_0_i7,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	MR_stackvar(7) = r2;
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_constants_7_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_15);
	call_localret(ENTRY(mercury__tree__tree_of_lists_is_empty_1_0),
		mercury__lookup_switch__generate_constants_7_0_i8,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__lookup_switch__get_case_rvals_4_0),
		mercury__lookup_switch__generate_constants_7_0_i10,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__lookup_switch__generate_constants_7_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(6);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__lookup_switch__generate_constants_7_0_i12,
		STATIC(mercury__lookup_switch__generate_constants_7_0));
	}
Define_label(mercury__lookup_switch__generate_constants_7_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__lookup_switch__generate_constants_7_0,
		LABEL(mercury__lookup_switch__generate_constants_7_0_i13),
		STATIC(mercury__lookup_switch__generate_constants_7_0));
Define_label(mercury__lookup_switch__generate_constants_7_0_i13);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_constants_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__lookup_switch__generate_constants_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lookup_switch__generate_constants_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__exprn_aux__init_exprn_opts_2_0);

BEGIN_MODULE(lookup_switch_module5)
	init_entry(mercury__lookup_switch__get_case_rvals_4_0);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i3);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
	init_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
BEGIN_CODE

/* code for predicate 'get_case_rvals'/4 in mode 0 */
Define_static(mercury__lookup_switch__get_case_rvals_4_0);
	MR_incr_sp_push_msg(4, "lookup_switch:get_case_rvals/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i3);
	r3 = r2;
	r1 = TRUE;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__lookup_switch__get_case_rvals_4_0_i4,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_15);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__tree__tree_of_lists_is_empty_1_0),
		mercury__lookup_switch__get_case_rvals_4_0_i5,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__lookup_switch__get_case_rvals_4_0_i7,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__globals__get_options_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i8,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	call_localret(ENTRY(mercury__exprn_aux__init_exprn_opts_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i9,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__lookup_switch__rval_is_constant_2_0),
		mercury__lookup_switch__get_case_rvals_4_0_i10,
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i10);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	localcall(mercury__lookup_switch__get_case_rvals_4_0,
		LABEL(mercury__lookup_switch__get_case_rvals_4_0_i12),
		STATIC(mercury__lookup_switch__get_case_rvals_4_0));
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i12);
	update_prof_current_proc(LABEL(mercury__lookup_switch__get_case_rvals_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__lookup_switch__get_case_rvals_4_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lookup_switch__get_case_rvals_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__exprn_aux__const_is_constant_3_0);

BEGIN_MODULE(lookup_switch_module6)
	init_entry(mercury__lookup_switch__rval_is_constant_2_0);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1017);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i14);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i4);
	init_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
BEGIN_CODE

/* code for predicate 'rval_is_constant'/2 in mode 0 */
Define_static(mercury__lookup_switch__rval_is_constant_2_0);
	MR_incr_sp_push_msg(3, "lookup_switch:rval_is_constant/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1017);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i10) AND
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i8) AND
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i10) AND
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i13) AND
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i8);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__exprn_aux__const_is_constant_3_0),
		mercury__lookup_switch__rval_is_constant_2_0_i9,
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rval_is_constant_2_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i10);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1017);
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i13);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__lookup_switch__rval_is_constant_2_0,
		LABEL(mercury__lookup_switch__rval_is_constant_2_0_i14),
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i14);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rval_is_constant_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1017);
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i4);
	if ((r3 != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) 0))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1011);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 2) != (Integer) 1))
		GOTO_LABEL(mercury__lookup_switch__rval_is_constant_2_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__lookup_switch__rvals_are_constant_2_0),
		STATIC(mercury__lookup_switch__rval_is_constant_2_0));
	}
Define_label(mercury__lookup_switch__rval_is_constant_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(lookup_switch_module7)
	init_entry(mercury__lookup_switch__rvals_are_constant_2_0);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i1003);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i2);
	init_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
BEGIN_CODE

/* code for predicate 'rvals_are_constant'/2 in mode 0 */
Define_static(mercury__lookup_switch__rvals_are_constant_2_0);
	MR_incr_sp_push_msg(3, "lookup_switch:rvals_are_constant/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i2);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lookup_switch__rval_is_constant_2_0),
		mercury__lookup_switch__rvals_are_constant_2_0_i5,
		STATIC(mercury__lookup_switch__rvals_are_constant_2_0));
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rvals_are_constant_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__lookup_switch__rvals_are_constant_2_0_i1003);
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lookup_switch__rvals_are_constant_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__fn__int__mod_2_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__fn__f_105_110_116_95_95_60_60_2_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(lookup_switch_module8)
	init_entry(mercury__lookup_switch__generate_bit_vec_2_5_0);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1002);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i4);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i11);
	init_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'generate_bit_vec_2'/5 in mode 0 */
Define_static(mercury__lookup_switch__generate_bit_vec_2_5_0);
	MR_incr_sp_push_msg(8, "lookup_switch:generate_bit_vec_2/5");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = ((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0) - (Integer) r2);
	MR_stackvar(1) = r2;
	r2 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = ((Integer) r1 / (Integer) r3);
	call_localret(ENTRY(mercury__fn__int__mod_2_0),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i4,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i6,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	MR_stackvar(7) = r2;
	r1 = (Integer) 1;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_60_60_2_0),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i8,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	r5 = ((Integer) MR_stackvar(7) | (Integer) r1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i11,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i5);
	r1 = (Integer) 1;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__fn__f_105_110_116_95_95_60_60_2_0),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i9,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__generate_bit_vec_2_5_0_i11,
		STATIC(mercury__lookup_switch__generate_bit_vec_2_5_0));
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_2_5_0_i1002);
Define_label(mercury__lookup_switch__generate_bit_vec_2_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(lookup_switch_module9)
	init_entry(mercury__lookup_switch__generate_bit_vec_args_3_0);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i3);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
	init_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
BEGIN_CODE

/* code for predicate 'generate_bit_vec_args'/3 in mode 0 */
Define_static(mercury__lookup_switch__generate_bit_vec_args_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
	r8 = (Word) MR_sp;
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	MR_incr_sp_push_msg(1, "lookup_switch:generate_bit_vec_args");
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if (((Integer) r2 >= (Integer) r5))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i3);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_17);
	GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i3);
	r1 = r3;
	r2 = ((Integer) r2 + (Integer) 1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_bit_vec_args_3_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__lookup_switch__generate_bit_vec_args_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__lookup_switch__generate_bit_vec_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(3), r6, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r6;
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i4);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_bit_vec_args_3_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i7);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lookup_switch__generate_bit_vec_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r8))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lookup_switch__generate_bit_vec_args_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__list__sort_2_0);
Declare_entry(mercury__code_info__cache_expression_4_0);

BEGIN_MODULE(lookup_switch_module10)
	init_entry(mercury__lookup_switch__generate_terms_2_5_0);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i1001);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
	init_label(mercury__lookup_switch__generate_terms_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'generate_terms_2'/5 in mode 0 */
Define_static(mercury__lookup_switch__generate_terms_2_5_0);
	MR_incr_sp_push_msg(6, "lookup_switch:generate_terms_2/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__generate_terms_2_5_0_i3);
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lookup_switch__generate_terms_2_5_0_i4,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_9);
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__lookup_switch__generate_terms_2_5_0_i5,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lookup_switch__construct_args_3_0),
		mercury__lookup_switch__generate_terms_2_5_0_i6,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__lookup_switch__generate_terms_2_5_0_i7,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__lookup_switch__generate_terms_2_5_0, "llds:rval/0");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__lookup_switch__generate_terms_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 6, mercury__lookup_switch__generate_terms_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 4) = r3;
	r3 = r4;
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 5) = (Word) MR_string_const("lookup_switch_data", 18);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_0);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__lookup_switch__generate_terms_2_5_0_i8,
		STATIC(mercury__lookup_switch__generate_terms_2_5_0));
	}
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__generate_terms_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lookup_switch__generate_terms_2_5_0_i1001);
Define_label(mercury__lookup_switch__generate_terms_2_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(lookup_switch_module11)
	init_entry(mercury__lookup_switch__construct_args_3_0);
	init_label(mercury__lookup_switch__construct_args_3_0_i6);
	init_label(mercury__lookup_switch__construct_args_3_0_i3);
	init_label(mercury__lookup_switch__construct_args_3_0_i4);
	init_label(mercury__lookup_switch__construct_args_3_0_i7);
	init_label(mercury__lookup_switch__construct_args_3_0_i2);
BEGIN_CODE

/* code for predicate 'construct_args'/3 in mode 0 */
Define_static(mercury__lookup_switch__construct_args_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i2);
	r6 = (Word) MR_sp;
Define_label(mercury__lookup_switch__construct_args_3_0_i6);
	MR_incr_sp_push_msg(1, "lookup_switch:construct_args");
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if (((Integer) r2 >= (Integer) r5))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i3);
	r2 = ((Integer) r2 + (Integer) 1);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_lookup_switch__common_17);
	GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i4);
Define_label(mercury__lookup_switch__construct_args_3_0_i3);
	r1 = r3;
	r2 = ((Integer) r2 + (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__lookup_switch__construct_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	MR_stackvar(1) = MR_tempr1;
	}
Define_label(mercury__lookup_switch__construct_args_3_0_i4);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__construct_args_3_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__lookup_switch__construct_args_3_0_i7);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lookup_switch__construct_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r6))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lookup_switch__construct_args_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);

BEGIN_MODULE(lookup_switch_module12)
	init_entry(mercury__lookup_switch__rearrange_vals_5_0);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i1001);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
	init_label(mercury__lookup_switch__rearrange_vals_5_0_i3);
BEGIN_CODE

/* code for predicate 'rearrange_vals'/5 in mode 0 */
Define_static(mercury__lookup_switch__rearrange_vals_5_0);
	MR_incr_sp_push_msg(6, "lookup_switch:rearrange_vals/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_5_0_i3);
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__lookup_switch__rearrange_vals_5_0_i4,
		STATIC(mercury__lookup_switch__rearrange_vals_5_0));
	}
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_5_0));
	r2 = ((Integer) MR_stackvar(4) - (Integer) MR_stackvar(2));
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__lookup_switch__rearrange_vals_2_4_0),
		mercury__lookup_switch__rearrange_vals_5_0_i5,
		STATIC(mercury__lookup_switch__rearrange_vals_5_0));
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lookup_switch__rearrange_vals_5_0_i1001);
Define_label(mercury__lookup_switch__rearrange_vals_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(lookup_switch_module13)
	init_entry(mercury__lookup_switch__rearrange_vals_2_4_0);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1002);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i4);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
	init_label(mercury__lookup_switch__rearrange_vals_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'rearrange_vals_2'/4 in mode 0 */
Define_static(mercury__lookup_switch__rearrange_vals_2_4_0);
	MR_incr_sp_push_msg(6, "lookup_switch:rearrange_vals_2/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lookup_switch__rearrange_vals_2_4_0_i5,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
	}
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_2_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__lookup_switch__rearrange_vals_2_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__lookup_switch__rearrange_vals_2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__rearrange_vals_2_4_0_i8,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
	}
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__lookup_switch__rearrange_vals_2_4_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lookup_switch__rearrange_vals_2_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lookup_switch__rearrange_vals_2_4_0_i8,
		STATIC(mercury__lookup_switch__rearrange_vals_2_4_0));
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lookup_switch__rearrange_vals_2_4_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lookup_switch__rearrange_vals_2_4_0_i1002);
Define_label(mercury__lookup_switch__rearrange_vals_2_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(lookup_switch_module14)
	init_entry(mercury____Unify___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lookup_switch__case_consts_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_19);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___lookup_switch__case_consts_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(lookup_switch_module15)
	init_entry(mercury____Index___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lookup_switch__case_consts_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_19);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___lookup_switch__case_consts_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(lookup_switch_module16)
	init_entry(mercury____Compare___lookup_switch__case_consts_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lookup_switch__case_consts_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_19);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___lookup_switch__case_consts_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(lookup_switch_module17)
	init_entry(mercury____Unify___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lookup_switch__rval_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___lookup_switch__rval_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(lookup_switch_module18)
	init_entry(mercury____Index___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lookup_switch__rval_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___lookup_switch__rval_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(lookup_switch_module19)
	init_entry(mercury____Compare___lookup_switch__rval_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lookup_switch__rval_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_4);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lookup_switch__common_10);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___lookup_switch__rval_map_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__lookup_switch_maybe_bunch_0(void)
{
	lookup_switch_module0();
	lookup_switch_module1();
	lookup_switch_module2();
	lookup_switch_module3();
	lookup_switch_module4();
	lookup_switch_module5();
	lookup_switch_module6();
	lookup_switch_module7();
	lookup_switch_module8();
	lookup_switch_module9();
	lookup_switch_module10();
	lookup_switch_module11();
	lookup_switch_module12();
	lookup_switch_module13();
	lookup_switch_module14();
	lookup_switch_module15();
	lookup_switch_module16();
	lookup_switch_module17();
	lookup_switch_module18();
	lookup_switch_module19();
}

#endif

void mercury__lookup_switch__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__lookup_switch__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__lookup_switch_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lookup_switch__type_ctor_info_case_consts_0,
			lookup_switch__case_consts_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lookup_switch__type_ctor_info_rval_map_0,
			lookup_switch__rval_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
