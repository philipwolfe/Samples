/*
** Automatically generated from `lp.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__lp__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___lp__tableau_0__ua0_2_0);
Declare_static(mercury____Index___lp__cell_0__ua0_2_0);
Declare_static(mercury____Index___lp__lp_info_0__ua0_2_0);
Declare_static(mercury____Index___lp__equation_0__ua0_2_0);
Declare_static(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0);
Declare_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i3);
Declare_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i4);
Declare_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i5);
Declare_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i6);
Declare_static(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i2);
Declare_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i4);
Declare_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1005);
Declare_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1007);
Declare_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1007);
Declare_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1009);
Declare_static(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0);
Declare_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i2);
Declare_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i3);
Declare_static(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0_i2);
Declare_static(mercury__lp__IntroducedFrom__pred__pivot__646__15_3_0);
Declare_static(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1005);
Declare_static(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i2);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i4);
Declare_static(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1009);
Declare_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1013);
Declare_static(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0);
Declare_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1007);
Declare_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1009);
Declare_static(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0);
Declare_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i2);
Declare_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i3);
Declare_static(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1007);
Declare_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1009);
Declare_static(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i4);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i6);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i5);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i8);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i9);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i10);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i11);
Declare_static(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i4);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i5);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i7);
Declare_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i8);
Declare_static(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1);
Declare_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1007);
Declare_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1009);
Declare_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i6);
Declare_static(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i2);
Declare_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i5);
Declare_static(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0);
Declare_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i3);
Declare_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i2);
Declare_static(mercury__lp__IntroducedFrom__pred__negate_equation__303__3_2_0);
Declare_static(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0);
Declare_label(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0_i1);
Declare_static(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0);
Declare_label(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0_i1);
Define_extern_entry(mercury__lp__lp_solve_8_0);
Declare_label(mercury__lp__lp_solve_8_0_i2);
Declare_label(mercury__lp__lp_solve_8_0_i3);
Declare_static(mercury__lp__lp_solve2_8_0);
Declare_label(mercury__lp__lp_solve2_8_0_i2);
Declare_label(mercury__lp__lp_solve2_8_0_i4);
Declare_label(mercury__lp__lp_solve2_8_0_i3);
Declare_label(mercury__lp__lp_solve2_8_0_i6);
Declare_label(mercury__lp__lp_solve2_8_0_i7);
Declare_label(mercury__lp__lp_solve2_8_0_i8);
Declare_label(mercury__lp__lp_solve2_8_0_i9);
Declare_label(mercury__lp__lp_solve2_8_0_i10);
Declare_label(mercury__lp__lp_solve2_8_0_i11);
Declare_label(mercury__lp__lp_solve2_8_0_i12);
Declare_label(mercury__lp__lp_solve2_8_0_i13);
Declare_label(mercury__lp__lp_solve2_8_0_i14);
Declare_label(mercury__lp__lp_solve2_8_0_i15);
Declare_label(mercury__lp__lp_solve2_8_0_i16);
Declare_label(mercury__lp__lp_solve2_8_0_i17);
Declare_label(mercury__lp__lp_solve2_8_0_i19);
Declare_label(mercury__lp__lp_solve2_8_0_i21);
Declare_label(mercury__lp__lp_solve2_8_0_i22);
Declare_static(mercury__lp__one_phase_7_0);
Declare_label(mercury__lp__one_phase_7_0_i2);
Declare_label(mercury__lp__one_phase_7_0_i3);
Declare_label(mercury__lp__one_phase_7_0_i4);
Declare_label(mercury__lp__one_phase_7_0_i6);
Declare_label(mercury__lp__one_phase_7_0_i7);
Declare_label(mercury__lp__one_phase_7_0_i8);
Declare_label(mercury__lp__one_phase_7_0_i9);
Declare_static(mercury__lp__two_phase_8_0);
Declare_label(mercury__lp__two_phase_8_0_i2);
Declare_label(mercury__lp__two_phase_8_0_i3);
Declare_label(mercury__lp__two_phase_8_0_i4);
Declare_label(mercury__lp__two_phase_8_0_i6);
Declare_label(mercury__lp__two_phase_8_0_i7);
Declare_label(mercury__lp__two_phase_8_0_i8);
Declare_label(mercury__lp__two_phase_8_0_i9);
Declare_label(mercury__lp__two_phase_8_0_i11);
Declare_label(mercury__lp__two_phase_8_0_i14);
Declare_label(mercury__lp__two_phase_8_0_i15);
Declare_label(mercury__lp__two_phase_8_0_i16);
Declare_label(mercury__lp__two_phase_8_0_i17);
Declare_label(mercury__lp__two_phase_8_0_i18);
Declare_label(mercury__lp__two_phase_8_0_i19);
Declare_static(mercury__lp__construct_art_objective_2_0);
Declare_label(mercury__lp__construct_art_objective_2_0_i4);
Declare_label(mercury__lp__construct_art_objective_2_0_i5);
Declare_label(mercury__lp__construct_art_objective_2_0_i2);
Declare_static(mercury__lp__standardize_equation_4_0);
Declare_label(mercury__lp__standardize_equation_4_0_i1007);
Declare_label(mercury__lp__standardize_equation_4_0_i4);
Declare_label(mercury__lp__standardize_equation_4_0_i7);
Declare_label(mercury__lp__standardize_equation_4_0_i8);
Declare_label(mercury__lp__standardize_equation_4_0_i9);
Declare_label(mercury__lp__standardize_equation_4_0_i3);
Declare_label(mercury__lp__standardize_equation_4_0_i15);
Declare_label(mercury__lp__standardize_equation_4_0_i16);
Declare_label(mercury__lp__standardize_equation_4_0_i17);
Declare_label(mercury__lp__standardize_equation_4_0_i13);
Declare_label(mercury__lp__standardize_equation_4_0_i19);
Declare_label(mercury__lp__standardize_equation_4_0_i20);
Declare_label(mercury__lp__standardize_equation_4_0_i21);
Declare_label(mercury__lp__standardize_equation_4_0_i12);
Declare_label(mercury__lp__standardize_equation_4_0_i25);
Declare_label(mercury__lp__standardize_equation_4_0_i24);
Declare_label(mercury__lp__standardize_equation_4_0_i27);
Declare_label(mercury__lp__standardize_equation_4_0_i28);
Declare_label(mercury__lp__standardize_equation_4_0_i29);
Declare_label(mercury__lp__standardize_equation_4_0_i30);
Declare_label(mercury__lp__standardize_equation_4_0_i31);
Declare_static(mercury__lp__negate_equation_2_0);
Declare_label(mercury__lp__negate_equation_2_0_i3);
Declare_label(mercury__lp__negate_equation_2_0_i4);
Declare_label(mercury__lp__negate_equation_2_0_i5);
Declare_static(mercury__lp__simplify_2_0);
Declare_label(mercury__lp__simplify_2_0_i2);
Declare_label(mercury__lp__simplify_2_0_i3);
Declare_label(mercury__lp__simplify_2_0_i4);
Declare_static(mercury__lp__simplify_coeffs_2_0);
Declare_label(mercury__lp__simplify_coeffs_2_0_i2);
Declare_label(mercury__lp__simplify_coeffs_2_0_i3);
Declare_static(mercury__lp__expand_urs_vars_e_3_0);
Declare_label(mercury__lp__expand_urs_vars_e_3_0_i2);
Declare_label(mercury__lp__expand_urs_vars_e_3_0_i3);
Declare_static(mercury__lp__expand_urs_vars_3_0);
Declare_label(mercury__lp__expand_urs_vars_3_0_i2);
Declare_static(mercury__lp__expand_urs_vars_4_0);
Declare_label(mercury__lp__expand_urs_vars_4_0_i1002);
Declare_label(mercury__lp__expand_urs_vars_4_0_i5);
Declare_label(mercury__lp__expand_urs_vars_4_0_i4);
Declare_label(mercury__lp__expand_urs_vars_4_0_i3);
Declare_static(mercury__lp__collect_vars_3_0);
Declare_label(mercury__lp__collect_vars_3_0_i2);
Declare_static(mercury__lp__number_vars_4_0);
Declare_label(mercury__lp__number_vars_4_0_i1001);
Declare_label(mercury__lp__number_vars_4_0_i4);
Declare_label(mercury__lp__number_vars_4_0_i3);
Declare_static(mercury__lp__insert_equations_6_0);
Declare_label(mercury__lp__insert_equations_6_0_i1001);
Declare_label(mercury__lp__insert_equations_6_0_i4);
Declare_label(mercury__lp__insert_equations_6_0_i5);
Declare_label(mercury__lp__insert_equations_6_0_i3);
Declare_static(mercury__lp__insert_coeffs_5_0);
Declare_label(mercury__lp__insert_coeffs_5_0_i1001);
Declare_label(mercury__lp__insert_coeffs_5_0_i4);
Declare_label(mercury__lp__insert_coeffs_5_0_i5);
Declare_label(mercury__lp__insert_coeffs_5_0_i3);
Declare_static(mercury__lp__optimize_6_0);
Declare_label(mercury__lp__optimize_6_0_i2);
Declare_label(mercury__lp__optimize_6_0_i4);
Declare_label(mercury__lp__optimize_6_0_i5);
Declare_label(mercury__lp__optimize_6_0_i6);
Declare_label(mercury__lp__optimize_6_0_i7);
Declare_static(mercury__lp__extract_obj_var_4_0);
Declare_label(mercury__lp__extract_obj_var_4_0_i3);
Declare_label(mercury__lp__extract_obj_var_4_0_i5);
Declare_label(mercury__lp__extract_obj_var_4_0_i6);
Declare_label(mercury__lp__extract_obj_var_4_0_i7);
Declare_label(mercury__lp__extract_obj_var_4_0_i11);
Declare_label(mercury__lp__extract_obj_var_4_0_i2);
Declare_label(mercury__lp__extract_obj_var_4_0_i12);
Declare_static(mercury__lp__extract_obj_var2_3_0);
Declare_label(mercury__lp__extract_obj_var2_3_0_i2);
Declare_label(mercury__lp__extract_obj_var2_3_0_i3);
Declare_label(mercury__lp__extract_obj_var2_3_0_i4);
Declare_static(mercury__lp__simplex_5_0);
Declare_label(mercury__lp__simplex_5_0_i1002);
Declare_label(mercury__lp__simplex_5_0_i2);
Declare_label(mercury__lp__simplex_5_0_i4);
Declare_label(mercury__lp__simplex_5_0_i5);
Declare_label(mercury__lp__simplex_5_0_i8);
Declare_label(mercury__lp__simplex_5_0_i7);
Declare_static(mercury__lp__ensure_zero_obj_coeffs_3_0);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i1003);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i3);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i4);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i5);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i6);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i9);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i12);
Declare_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i11);
Declare_static(mercury__lp__fix_basis_and_rem_cols_3_0);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i1005);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i4);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i5);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i10);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i12);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i13);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i15);
Declare_label(mercury__lp__fix_basis_and_rem_cols_3_0_i3);
Declare_static(mercury__lp__pivot_4_0);
Declare_label(mercury__lp__pivot_4_0_i2);
Declare_label(mercury__lp__pivot_4_0_i3);
Declare_label(mercury__lp__pivot_4_0_i4);
Declare_label(mercury__lp__pivot_4_0_i5);
Declare_static(mercury__lp__init_tableau_5_0);
Declare_label(mercury__lp__init_tableau_5_0_i2);
Declare_static(mercury__lp__index_4_0);
Declare_label(mercury__lp__index_4_0_i6);
Declare_label(mercury__lp__index_4_0_i8);
Declare_label(mercury__lp__index_4_0_i4);
Declare_label(mercury__lp__index_4_0_i2);
Declare_label(mercury__lp__index_4_0_i13);
Declare_label(mercury__lp__index_4_0_i12);
Declare_static(mercury__lp__set_index_5_0);
Declare_label(mercury__lp__set_index_5_0_i6);
Declare_label(mercury__lp__set_index_5_0_i8);
Declare_label(mercury__lp__set_index_5_0_i4);
Declare_label(mercury__lp__set_index_5_0_i2);
Declare_label(mercury__lp__set_index_5_0_i12);
Declare_label(mercury__lp__set_index_5_0_i15);
Declare_static(mercury__lp__rhs_col_2_0);
Declare_static(mercury__lp__all_rows_2_0);
Declare_label(mercury__lp__all_rows_2_0_i1);
Declare_label(mercury__lp__all_rows_2_0_i1005);
Declare_static(mercury__lp__all_cols0_2_0);
Declare_label(mercury__lp__all_cols0_2_0_i1);
Declare_label(mercury__lp__all_cols0_2_0_i1005);
Declare_static(mercury__lp__all_cols_2_0);
Declare_label(mercury__lp__all_cols_2_0_i1);
Declare_label(mercury__lp__all_cols_2_0_i1005);
Declare_static(mercury__lp__remove_col_3_0);
Declare_static(mercury__lp__get_basis_vars_2_0);
Declare_label(mercury__lp__get_basis_vars_2_0_i2);
Declare_static(mercury__lp__new_slack_var_3_0);
Declare_label(mercury__lp__new_slack_var_3_0_i2);
Declare_static(mercury__lp__new_art_var_3_0);
Declare_label(mercury__lp__new_art_var_3_0_i2);
Declare_static(mercury__lp__get_urs_vars_3_0);
Declare_static(mercury__lp__get_art_vars_3_0);
Declare_static(mercury__lp__between_3_0);
Declare_label(mercury__lp__between_3_0_i2);
Define_extern_entry(mercury____Unify___lp__coeff_0_0);
Define_extern_entry(mercury____Index___lp__coeff_0_0);
Define_extern_entry(mercury____Compare___lp__coeff_0_0);
Define_extern_entry(mercury____Unify___lp__equation_0_0);
Declare_label(mercury____Unify___lp__equation_0_0_i2);
Declare_label(mercury____Unify___lp__equation_0_0_i1);
Define_extern_entry(mercury____Index___lp__equation_0_0);
Define_extern_entry(mercury____Compare___lp__equation_0_0);
Declare_label(mercury____Compare___lp__equation_0_0_i3);
Declare_label(mercury____Compare___lp__equation_0_0_i7);
Declare_label(mercury____Compare___lp__equation_0_0_i12);
Define_extern_entry(mercury____Unify___lp__operator_0_0);
Declare_label(mercury____Unify___lp__operator_0_0_i1);
Define_extern_entry(mercury____Index___lp__operator_0_0);
Define_extern_entry(mercury____Compare___lp__operator_0_0);
Define_extern_entry(mercury____Unify___lp__equations_0_0);
Define_extern_entry(mercury____Index___lp__equations_0_0);
Define_extern_entry(mercury____Compare___lp__equations_0_0);
Define_extern_entry(mercury____Unify___lp__objective_0_0);
Define_extern_entry(mercury____Index___lp__objective_0_0);
Define_extern_entry(mercury____Compare___lp__objective_0_0);
Define_extern_entry(mercury____Unify___lp__direction_0_0);
Declare_label(mercury____Unify___lp__direction_0_0_i1);
Define_extern_entry(mercury____Index___lp__direction_0_0);
Define_extern_entry(mercury____Compare___lp__direction_0_0);
Define_extern_entry(mercury____Unify___lp__result_0_0);
Declare_label(mercury____Unify___lp__result_0_0_i3);
Declare_label(mercury____Unify___lp__result_0_0_i1);
Define_extern_entry(mercury____Index___lp__result_0_0);
Declare_label(mercury____Index___lp__result_0_0_i3);
Define_extern_entry(mercury____Compare___lp__result_0_0);
Declare_label(mercury____Compare___lp__result_0_0_i3);
Declare_label(mercury____Compare___lp__result_0_0_i2);
Declare_label(mercury____Compare___lp__result_0_0_i5);
Declare_label(mercury____Compare___lp__result_0_0_i4);
Declare_label(mercury____Compare___lp__result_0_0_i6);
Declare_label(mercury____Compare___lp__result_0_0_i7);
Declare_label(mercury____Compare___lp__result_0_0_i11);
Declare_label(mercury____Compare___lp__result_0_0_i15);
Declare_label(mercury____Compare___lp__result_0_0_i1015);
Declare_label(mercury____Compare___lp__result_0_0_i23);
Declare_static(mercury____Unify___lp__lp_info_0_0);
Declare_label(mercury____Unify___lp__lp_info_0_0_i2);
Declare_label(mercury____Unify___lp__lp_info_0_0_i4);
Declare_label(mercury____Unify___lp__lp_info_0_0_i6);
Declare_label(mercury____Unify___lp__lp_info_0_0_i1);
Declare_static(mercury____Index___lp__lp_info_0_0);
Declare_static(mercury____Compare___lp__lp_info_0_0);
Declare_label(mercury____Compare___lp__lp_info_0_0_i3);
Declare_label(mercury____Compare___lp__lp_info_0_0_i7);
Declare_label(mercury____Compare___lp__lp_info_0_0_i11);
Declare_label(mercury____Compare___lp__lp_info_0_0_i17);
Declare_static(mercury____Unify___lp__cell_0_0);
Declare_label(mercury____Unify___lp__cell_0_0_i1);
Declare_static(mercury____Index___lp__cell_0_0);
Declare_static(mercury____Compare___lp__cell_0_0);
Declare_label(mercury____Compare___lp__cell_0_0_i3);
Declare_label(mercury____Compare___lp__cell_0_0_i7);
Declare_static(mercury____Unify___lp__tableau_0_0);
Declare_label(mercury____Unify___lp__tableau_0_0_i2);
Declare_label(mercury____Unify___lp__tableau_0_0_i4);
Declare_label(mercury____Unify___lp__tableau_0_0_i6);
Declare_label(mercury____Unify___lp__tableau_0_0_i8);
Declare_label(mercury____Unify___lp__tableau_0_0_i1008);
Declare_label(mercury____Unify___lp__tableau_0_0_i1);
Declare_static(mercury____Index___lp__tableau_0_0);
Declare_static(mercury____Compare___lp__tableau_0_0);
Declare_label(mercury____Compare___lp__tableau_0_0_i3);
Declare_label(mercury____Compare___lp__tableau_0_0_i7);
Declare_label(mercury____Compare___lp__tableau_0_0_i11);
Declare_label(mercury____Compare___lp__tableau_0_0_i15);
Declare_label(mercury____Compare___lp__tableau_0_0_i19);
Declare_label(mercury____Compare___lp__tableau_0_0_i23);
Declare_label(mercury____Compare___lp__tableau_0_0_i32);

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_cell_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_coeff_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_direction_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_equation_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_equations_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_lp_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_objective_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_operator_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_result_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_tableau_0;

static const struct mercury_data_lp__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_0;

static const struct mercury_data_lp__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_1;

static const struct mercury_data_lp__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_2;

static const struct mercury_data_lp__common_3_struct {
	Word * f1;
}  mercury_data_lp__common_3;

static const struct mercury_data_lp__common_4_struct {
	Word * f1;
}  mercury_data_lp__common_4;

static const struct mercury_data_lp__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_5;

static const struct mercury_data_lp__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_6;

static const struct mercury_data_lp__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_7;

static const struct mercury_data_lp__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_8;

static const struct mercury_data_lp__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_9;

static const struct mercury_data_lp__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_10;

static const struct mercury_data_lp__common_11_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lp__common_11;

static const struct mercury_data_lp__common_12_struct {
	Word * f1;
}  mercury_data_lp__common_12;

static const struct mercury_data_lp__common_13_struct {
	Word * f1;
}  mercury_data_lp__common_13;

static const struct mercury_data_lp__common_14_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_lp__common_14;

static const struct mercury_data_lp__common_15_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lp__common_15;

static const struct mercury_data_lp__common_16_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_16;

static const struct mercury_data_lp__common_17_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lp__common_17;

static const struct mercury_data_lp__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_18;

static const struct mercury_data_lp__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_19;

static const struct mercury_data_lp__common_20_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_20;

static const struct mercury_data_lp__common_21_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_lp__common_21;

static const struct mercury_data_lp__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_22;

static const struct mercury_data_lp__common_23_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_23;

static const struct mercury_data_lp__common_24_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lp__common_24;

static const struct mercury_data_lp__common_25_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_25;

static const struct mercury_data_lp__common_26_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_26;

static const struct mercury_data_lp__common_27_struct {
	Word * f1;
}  mercury_data_lp__common_27;

static const struct mercury_data_lp__common_28_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_28;

static const struct mercury_data_lp__common_29_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_29;

static const struct mercury_data_lp__common_30_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_30;

static const struct mercury_data_lp__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_lp__common_31;

static const struct mercury_data_lp__common_32_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_32;

static const struct mercury_data_lp__common_33_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_lp__common_33;

static const struct mercury_data_lp__common_34_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_34;

static const struct mercury_data_lp__common_35_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_35;

static const struct mercury_data_lp__common_36_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_lp__common_36;

static const struct mercury_data_lp__common_37_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_37;

static const struct mercury_data_lp__common_38_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_38;

static const struct mercury_data_lp__common_39_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_lp__common_39;

static const struct mercury_data_lp__common_40_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_lp__common_40;

static const struct mercury_data_lp__common_41_struct {
	Word * f1;
}  mercury_data_lp__common_41;

static const struct mercury_data_lp__common_42_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_lp__common_42;

static const struct mercury_data_lp__common_43_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_lp__common_43;

static const struct mercury_data_lp__common_44_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_44;

static const struct mercury_data_lp__common_45_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_45;

static const struct mercury_data_lp__common_46_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_lp__common_46;

static const struct mercury_data_lp__common_47_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_lp__common_47;

static const struct mercury_data_lp__common_48_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_48;

static const struct mercury_data_lp__common_49_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_lp__common_49;

static const struct mercury_data_lp__common_50_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_50;

static const struct mercury_data_lp__common_51_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_lp__common_51;

static const struct mercury_data_lp__common_52_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_52;

static const struct mercury_data_lp__common_53_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_lp__common_53;

static const struct mercury_data_lp__common_54_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	String f9;
	Word * f10;
	Integer f11;
	Integer f12;
}  mercury_data_lp__common_54;

static const struct mercury_data_lp__common_55_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_lp__common_55;

static const struct mercury_data_lp__common_56_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_lp__common_56;

static const struct mercury_data_lp__common_57_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_lp__common_57;

static const struct mercury_data_lp__common_58_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_lp__common_58;

static const struct mercury_data_lp__common_59_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__common_59;

static const struct mercury_data_lp__common_60_struct {
	Word * f1;
	Word * f2;
}  mercury_data_lp__common_60;

static const struct mercury_data_lp__common_61_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_lp__common_61;

static const struct mercury_data_lp__common_62_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__common_62;

static const struct mercury_data_lp__common_63_struct {
	Word * f1;
}  mercury_data_lp__common_63;

static const struct mercury_data_lp__common_64_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_lp__common_64;

static const struct mercury_data_lp__common_65_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_lp__common_65;

static const struct mercury_data_lp__common_66_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__common_66;

static const struct mercury_data_lp__common_67_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_lp__common_67;

static const struct mercury_data_lp__type_ctor_functors_tableau_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_lp__type_ctor_functors_tableau_0;

static const struct mercury_data_lp__type_ctor_layout_tableau_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_tableau_0;

static const struct mercury_data_lp__type_ctor_functors_result_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_functors_result_0;

static const struct mercury_data_lp__type_ctor_layout_result_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_result_0;

static const struct mercury_data_lp__type_ctor_functors_operator_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__type_ctor_functors_operator_0;

static const struct mercury_data_lp__type_ctor_layout_operator_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_operator_0;

static const struct mercury_data_lp__type_ctor_functors_objective_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__type_ctor_functors_objective_0;

static const struct mercury_data_lp__type_ctor_layout_objective_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_objective_0;

static const struct mercury_data_lp__type_ctor_functors_lp_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_lp__type_ctor_functors_lp_info_0;

static const struct mercury_data_lp__type_ctor_layout_lp_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_lp_info_0;

static const struct mercury_data_lp__type_ctor_functors_equations_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__type_ctor_functors_equations_0;

static const struct mercury_data_lp__type_ctor_layout_equations_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_equations_0;

static const struct mercury_data_lp__type_ctor_functors_equation_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_lp__type_ctor_functors_equation_0;

static const struct mercury_data_lp__type_ctor_layout_equation_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_equation_0;

static const struct mercury_data_lp__type_ctor_functors_direction_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__type_ctor_functors_direction_0;

static const struct mercury_data_lp__type_ctor_layout_direction_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_direction_0;

static const struct mercury_data_lp__type_ctor_functors_coeff_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_lp__type_ctor_functors_coeff_0;

static const struct mercury_data_lp__type_ctor_layout_coeff_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_coeff_0;

static const struct mercury_data_lp__type_ctor_functors_cell_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_lp__type_ctor_functors_cell_0;

static const struct mercury_data_lp__type_ctor_layout_cell_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_lp__type_ctor_layout_cell_0;

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_cell_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___lp__cell_0_0),
	STATIC(mercury____Index___lp__cell_0_0),
	STATIC(mercury____Compare___lp__cell_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lp__type_ctor_functors_cell_0,
	(Word *) &mercury_data_lp__type_ctor_layout_cell_0,
	MR_string_const("lp", 2),
	MR_string_const("cell", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_coeff_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__coeff_0_0),
	ENTRY(mercury____Index___lp__coeff_0_0),
	ENTRY(mercury____Compare___lp__coeff_0_0),
	(Integer) 6,
	(Word *) &mercury_data_lp__type_ctor_functors_coeff_0,
	(Word *) &mercury_data_lp__type_ctor_layout_coeff_0,
	MR_string_const("lp", 2),
	MR_string_const("coeff", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_direction_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__direction_0_0),
	ENTRY(mercury____Index___lp__direction_0_0),
	ENTRY(mercury____Compare___lp__direction_0_0),
	(Integer) 0,
	(Word *) &mercury_data_lp__type_ctor_functors_direction_0,
	(Word *) &mercury_data_lp__type_ctor_layout_direction_0,
	MR_string_const("lp", 2),
	MR_string_const("direction", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_equation_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__equation_0_0),
	ENTRY(mercury____Index___lp__equation_0_0),
	ENTRY(mercury____Compare___lp__equation_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lp__type_ctor_functors_equation_0,
	(Word *) &mercury_data_lp__type_ctor_layout_equation_0,
	MR_string_const("lp", 2),
	MR_string_const("equation", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_equations_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__equations_0_0),
	ENTRY(mercury____Index___lp__equations_0_0),
	ENTRY(mercury____Compare___lp__equations_0_0),
	(Integer) 6,
	(Word *) &mercury_data_lp__type_ctor_functors_equations_0,
	(Word *) &mercury_data_lp__type_ctor_layout_equations_0,
	MR_string_const("lp", 2),
	MR_string_const("equations", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_lp_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___lp__lp_info_0_0),
	STATIC(mercury____Index___lp__lp_info_0_0),
	STATIC(mercury____Compare___lp__lp_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lp__type_ctor_functors_lp_info_0,
	(Word *) &mercury_data_lp__type_ctor_layout_lp_info_0,
	MR_string_const("lp", 2),
	MR_string_const("lp_info", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_objective_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__objective_0_0),
	ENTRY(mercury____Index___lp__objective_0_0),
	ENTRY(mercury____Compare___lp__objective_0_0),
	(Integer) 6,
	(Word *) &mercury_data_lp__type_ctor_functors_objective_0,
	(Word *) &mercury_data_lp__type_ctor_layout_objective_0,
	MR_string_const("lp", 2),
	MR_string_const("objective", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_operator_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__operator_0_0),
	ENTRY(mercury____Index___lp__operator_0_0),
	ENTRY(mercury____Compare___lp__operator_0_0),
	(Integer) 0,
	(Word *) &mercury_data_lp__type_ctor_functors_operator_0,
	(Word *) &mercury_data_lp__type_ctor_layout_operator_0,
	MR_string_const("lp", 2),
	MR_string_const("operator", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_result_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___lp__result_0_0),
	ENTRY(mercury____Index___lp__result_0_0),
	ENTRY(mercury____Compare___lp__result_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lp__type_ctor_functors_result_0,
	(Word *) &mercury_data_lp__type_ctor_layout_result_0,
	MR_string_const("lp", 2),
	MR_string_const("result", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_lp__type_ctor_info_tableau_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___lp__tableau_0_0),
	STATIC(mercury____Index___lp__tableau_0_0),
	STATIC(mercury____Compare___lp__tableau_0_0),
	(Integer) 2,
	(Word *) &mercury_data_lp__type_ctor_functors_tableau_0,
	(Word *) &mercury_data_lp__type_ctor_layout_tableau_0,
	MR_string_const("lp", 2),
	MR_string_const("tableau", 7),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_lp__common_0_struct mercury_data_lp__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_lp__common_1_struct mercury_data_lp__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_float_0;
static const struct mercury_data_lp__common_2_struct mercury_data_lp__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_lp__common_3_struct mercury_data_lp__common_3 = {
	(Word *) &mercury_data_lp__type_ctor_info_tableau_0
};

static const struct mercury_data_lp__common_4_struct mercury_data_lp__common_4 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_lp__common_5_struct mercury_data_lp__common_5 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__get_basis_vars__807__18", 45),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_2)
};

static const struct mercury_data_lp__common_6_struct mercury_data_lp__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	(Word *) &mercury_data___type_ctor_info_float_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_lp__common_7_struct mercury_data_lp__common_7 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_lp__common_8_struct mercury_data_lp__common_8 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1)
};

static const struct mercury_data_lp__common_9_struct mercury_data_lp__common_9 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_8)
};

static const struct mercury_data_lp__common_10_struct mercury_data_lp__common_10 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__lp_info_init__858__21", 43),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_9)
};

static const struct mercury_data_lp__common_11_struct mercury_data_lp__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_10),
	STATIC(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0),
	(Integer) 0
};

static const struct mercury_data_lp__common_12_struct mercury_data_lp__common_12 = {
	(Word *) &mercury_data_lp__type_ctor_info_equation_0
};

static const struct mercury_data_lp__common_13_struct mercury_data_lp__common_13 = {
	(Word *) &mercury_data_lp__type_ctor_info_lp_info_0
};

static const struct mercury_data_lp__common_14_struct mercury_data_lp__common_14 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("standardize_equation", 20),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_13)
};

static const struct mercury_data_lp__common_15_struct mercury_data_lp__common_15 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_14),
	STATIC(mercury__lp__standardize_equation_4_0),
	(Integer) 0
};

static const struct mercury_data_lp__common_16_struct mercury_data_lp__common_16 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__negate_equation__303__3", 45),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6)
};

static const struct mercury_data_lp__common_17_struct mercury_data_lp__common_17 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_16),
	STATIC(mercury__lp__IntroducedFrom__pred__negate_equation__303__3_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_lp__common_18_struct mercury_data_lp__common_18 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6)
};

static const struct mercury_data_lp__common_19_struct mercury_data_lp__common_19 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__one_phase__175__1", 39),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

static const struct mercury_data_lp__common_20_struct mercury_data_lp__common_20 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_lp__common_21_struct mercury_data_lp__common_21 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("extract_obj_var", 15),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20)
};

static const struct mercury_data_lp__common_22_struct mercury_data_lp__common_22 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__two_phase__216__2", 39),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

static const struct mercury_data_lp__common_23_struct mercury_data_lp__common_23 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__simplify_coeffs__322__4", 45),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20)
};

static const struct mercury_data_lp__common_24_struct mercury_data_lp__common_24 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_23),
	STATIC(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0),
	(Integer) 0
};

static const struct mercury_data_lp__common_25_struct mercury_data_lp__common_25 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_lp__type_ctor_info_equation_0
};

static const struct mercury_data_lp__common_26_struct mercury_data_lp__common_26 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__collect_vars__380__5", 42),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_25),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

static const struct mercury_data_lp__common_27_struct mercury_data_lp__common_27 = {
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_lp__common_28_struct mercury_data_lp__common_28 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__extract_obj_var2__463__6", 46),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27)
};

static const struct mercury_data_lp__common_29_struct mercury_data_lp__common_29 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("all_cols", 8),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_lp__common_30_struct mercury_data_lp__common_30 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_2)
};

static const struct mercury_data_lp__common_31_struct mercury_data_lp__common_31 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__simplex__490__7", 37),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30)
};

static const struct mercury_data_lp__common_32_struct mercury_data_lp__common_32 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("all_rows", 8),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4)
};

static const struct mercury_data_lp__common_33_struct mercury_data_lp__common_33 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__simplex__521__8", 37),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30)
};

static const struct mercury_data_lp__common_34_struct mercury_data_lp__common_34 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9", 52),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_2)
};

static const struct mercury_data_lp__common_35_struct mercury_data_lp__common_35 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("all_cols0", 9),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4)
};

static const struct mercury_data_lp__common_36_struct mercury_data_lp__common_36 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__row_op__665__17", 37),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3)
};

static const struct mercury_data_lp__common_37_struct mercury_data_lp__common_37 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_float_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_lp__common_38_struct mercury_data_lp__common_38 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_37)
};

static const struct mercury_data_lp__common_39_struct mercury_data_lp__common_39 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__fix_basis_and_rem_cols__583__10", 53),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_38),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_38)
};

static const struct mercury_data_lp__common_40_struct mercury_data_lp__common_40 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__fix_basis_and_rem_cols__595__11", 53),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4)
};

static const struct mercury_data_lp__common_41_struct mercury_data_lp__common_41 = {
	(Word *) &mercury_data_lp__type_ctor_info_cell_0
};

static const struct mercury_data_lp__common_42_struct mercury_data_lp__common_42 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__pivot__626__12", 36),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_41)
};

static const struct mercury_data_lp__common_43_struct mercury_data_lp__common_43 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__pivot__633__13", 36),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_41),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3)
};

static const struct mercury_data_lp__common_44_struct mercury_data_lp__common_44 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__pivot__642__14", 36),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_41)
};

static const struct mercury_data_lp__common_45_struct mercury_data_lp__common_45 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__pivot__646__15", 36),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_41),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3)
};

static const struct mercury_data_lp__common_46_struct mercury_data_lp__common_46 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_45),
	STATIC(mercury__lp__IntroducedFrom__pred__pivot__646__15_3_0),
	(Integer) 0
};

static const struct mercury_data_lp__common_47_struct mercury_data_lp__common_47 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__pivot__652__16", 36),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3)
};

static const struct mercury_data_lp__common_48_struct mercury_data_lp__common_48 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_lp__common_49_struct mercury_data_lp__common_49 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__get_basis_vars__805__19", 45),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4)
};

static const struct mercury_data_lp__common_50_struct mercury_data_lp__common_50 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_lp__common_51_struct mercury_data_lp__common_51 = {
	(Integer) 0,
	MR_string_const("lp", 2),
	MR_string_const("lp", 2),
	MR_string_const("IntroducedFrom__pred__get_basis_vars__817__20", 45),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_50),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

static const struct mercury_data_lp__common_52_struct mercury_data_lp__common_52 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0),
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_lp__common_53_struct mercury_data_lp__common_53 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48),
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_lp__common_54_struct mercury_data_lp__common_54 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_50),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_50),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_53),
	MR_string_const("tableau", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__common_55_struct mercury_data_lp__common_55 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20),
	MR_string_const("satisfiable", 11),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__common_56_struct mercury_data_lp__common_56 = {
	(Integer) 0,
	MR_string_const("unsatisfiable", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__common_57_struct mercury_data_lp__common_57 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("unsatisfiable", 13)
};

static const struct mercury_data_lp__common_58_struct mercury_data_lp__common_58 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("=<", 2),
	MR_string_const("=", 1),
	MR_string_const(">=", 2)
};

static const struct mercury_data_lp__common_59_struct mercury_data_lp__common_59 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18)
};

static const struct mercury_data_lp__common_60_struct mercury_data_lp__common_60 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0)
};

static const struct mercury_data_lp__common_61_struct mercury_data_lp__common_61 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_60),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_60),
	MR_string_const("lp", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__common_62_struct mercury_data_lp__common_62 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_25)
};

static const struct mercury_data_lp__common_63_struct mercury_data_lp__common_63 = {
	(Word *) &mercury_data_lp__type_ctor_info_operator_0
};

static const struct mercury_data_lp__common_64_struct mercury_data_lp__common_64 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_63),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_27),
	MR_string_const("eqn", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__common_65_struct mercury_data_lp__common_65 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("max", 3),
	MR_string_const("min", 3)
};

static const struct mercury_data_lp__common_66_struct mercury_data_lp__common_66 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6)
};

static const struct mercury_data_lp__common_67_struct mercury_data_lp__common_67 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_4),
	MR_string_const("cell", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_lp__type_ctor_functors_tableau_0_struct mercury_data_lp__type_ctor_functors_tableau_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_54)
};

static const struct mercury_data_lp__type_ctor_layout_tableau_0_struct mercury_data_lp__type_ctor_layout_tableau_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lp__common_54),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_lp__type_ctor_functors_result_0_struct mercury_data_lp__type_ctor_functors_result_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_56)
};

static const struct mercury_data_lp__type_ctor_layout_result_0_struct mercury_data_lp__type_ctor_layout_result_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_57),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lp__common_55),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_lp__type_ctor_functors_operator_0_struct mercury_data_lp__type_ctor_functors_operator_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_58)
};

static const struct mercury_data_lp__type_ctor_layout_operator_0_struct mercury_data_lp__type_ctor_layout_operator_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_58)
};

static const struct mercury_data_lp__type_ctor_functors_objective_0_struct mercury_data_lp__type_ctor_functors_objective_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_18)
};

static const struct mercury_data_lp__type_ctor_layout_objective_0_struct mercury_data_lp__type_ctor_layout_objective_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_59),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_59),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_59),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_59)
};

static const struct mercury_data_lp__type_ctor_functors_lp_info_0_struct mercury_data_lp__type_ctor_functors_lp_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_61)
};

static const struct mercury_data_lp__type_ctor_layout_lp_info_0_struct mercury_data_lp__type_ctor_layout_lp_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lp__common_61),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_lp__type_ctor_functors_equations_0_struct mercury_data_lp__type_ctor_functors_equations_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_25)
};

static const struct mercury_data_lp__type_ctor_layout_equations_0_struct mercury_data_lp__type_ctor_layout_equations_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_62)
};

static const struct mercury_data_lp__type_ctor_functors_equation_0_struct mercury_data_lp__type_ctor_functors_equation_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_64)
};

static const struct mercury_data_lp__type_ctor_layout_equation_0_struct mercury_data_lp__type_ctor_layout_equation_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lp__common_64),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_lp__type_ctor_functors_direction_0_struct mercury_data_lp__type_ctor_functors_direction_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_65)
};

static const struct mercury_data_lp__type_ctor_layout_direction_0_struct mercury_data_lp__type_ctor_layout_direction_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_65),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_65),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_65),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_65)
};

static const struct mercury_data_lp__type_ctor_functors_coeff_0_struct mercury_data_lp__type_ctor_functors_coeff_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6)
};

static const struct mercury_data_lp__type_ctor_layout_coeff_0_struct mercury_data_lp__type_ctor_layout_coeff_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_66),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_lp__common_66)
};

static const struct mercury_data_lp__type_ctor_functors_cell_0_struct mercury_data_lp__type_ctor_functors_cell_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_67)
};

static const struct mercury_data_lp__type_ctor_layout_cell_0_struct mercury_data_lp__type_ctor_layout_cell_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_lp__common_67),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(lp_module0)
	init_entry(mercury____Index___lp__tableau_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___lp__tableau_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___lp__tableau_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module1)
	init_entry(mercury____Index___lp__cell_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___lp__cell_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___lp__cell_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module2)
	init_entry(mercury____Index___lp__lp_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___lp__lp_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___lp__lp_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module3)
	init_entry(mercury____Index___lp__equation_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___lp__equation_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___lp__equation_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
static const Float mercury_float_const_1pt00000000000000 = 1.00000000000000;

BEGIN_MODULE(lp_module4)
	init_entry(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0);
	init_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i3);
	init_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i4);
	init_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i5);
	init_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i6);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__two_phase__230__0'/5 in mode 0 */
Define_static(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0);
	MR_incr_sp_push_msg(5, "lp:DeforestationIn__pred__two_phase__230__0/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__lp__construct_art_objective_2_0),
		mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i4,
		STATIC(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
Define_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i5,
		STATIC(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
Define_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r4 = (Word) &mercury_float_const_1pt00000000000000;
	call_localret(STATIC(mercury__lp__set_index_5_0),
		mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i6,
		STATIC(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
Define_label(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__lp__insert_coeffs_5_0),
		STATIC(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0));
END_MODULE

Declare_entry(mercury__varset__new_var_3_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(lp_module5)
	init_entry(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i2);
	init_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i4);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__lp_info_init__858__21'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0);
	MR_incr_sp_push_msg(4, "lp:IntroducedFrom__pred__lp_info_init__858__21/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = r1;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i2,
		STATIC(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i3,
		STATIC(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
	r3 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i4,
		STATIC(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__lp_info_init__858__21_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(do_fail);
Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__map__member_3_0);
Declare_entry(do_redo);

BEGIN_MODULE(lp_module6)
	init_entry(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1005);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_basis_vars__817__20'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__get_basis_vars__817__20/3", 2, ENTRY(do_fail));
	MR_framevar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0));
	MR_framevar(2) = r1;
	r3 = MR_const_field(MR_mktag(0), MR_framevar(1), (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__member_3_0),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1005,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0_i1005);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0));
	if ((MR_framevar(2) != r2))
		GOTO(ENTRY(do_redo));
	MR_succeed();
END_MODULE

Declare_entry(mercury__std_util__solutions_2_1);

BEGIN_MODULE(lp_module7)
	init_entry(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1007);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_basis_vars__805__19'/2 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0);
	MR_mkframe("lp:IntroducedFrom__pred__get_basis_vars__805__19/2", 2, ENTRY(do_fail));
	MR_framevar(1) = r1;
	call_localret(STATIC(mercury__lp__all_cols_2_0),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0));
	r3 = r1;
	MR_framevar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_framevar(1);
	MR_field(MR_mktag(0), r2, (Integer) 4) = r3;
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1007,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0_i1007);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	if ((word_to_float(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1)) != (Float) 1.00000000000000))
		GOTO(ENTRY(do_redo));
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(2);
	MR_succeed();
END_MODULE

Declare_entry(mercury__list__member_2_0);
static const Float mercury_float_const_0pt00000000000000 = 0.00000000000000;

BEGIN_MODULE(lp_module8)
	init_entry(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1007);
	init_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1009);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_basis_vars__807__18'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__get_basis_vars__807__18/3", 4, ENTRY(do_fail));
	MR_framevar(3) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(1) = r1;
	MR_framevar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Integer) 1;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
	MR_framevar(2) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1007,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1007);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	r2 = MR_framevar(2);
	r3 = MR_framevar(3);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1009,
		STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0_i1009);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0));
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO(ENTRY(do_redo));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__get_basis_vars__807__18_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module9)
	init_entry(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0);
	init_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i2);
	init_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i3);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__row_op__665__17'/6 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0);
	MR_incr_sp_push_msg(6, "lp:IntroducedFrom__pred__row_op__665__17/6");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	r1 = r5;
	r3 = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r4;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i2,
		STATIC(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0));
Define_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i3,
		STATIC(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0));
Define_label(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0));
	r4 = float_to_word((word_to_float(r1) + (word_to_float(MR_stackvar(1)) * word_to_float(MR_stackvar(3)))));
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__lp__set_index_5_0),
		STATIC(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0));
END_MODULE


BEGIN_MODULE(lp_module10)
	init_entry(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pivot__652__16'/5 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0);
	MR_incr_sp_push_msg(5, "lp:IntroducedFrom__pred__pivot__652__16/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0_i2,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0));
	r4 = float_to_word((word_to_float(r1) / word_to_float(MR_stackvar(2))));
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__lp__set_index_5_0),
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0));
END_MODULE


BEGIN_MODULE(lp_module11)
	init_entry(mercury__lp__IntroducedFrom__pred__pivot__646__15_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pivot__646__15'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__pivot__646__15_3_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = (Word) &mercury_float_const_0pt00000000000000;
	tailcall(STATIC(mercury__lp__set_index_5_0),
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__646__15_3_0));
	}
END_MODULE


BEGIN_MODULE(lp_module12)
	init_entry(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1005);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pivot__642__14'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__pivot__642__14/3", 3, ENTRY(do_fail));
	MR_framevar(1) = r1;
	MR_framevar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0));
	MR_framevar(2) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1005,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0_i1005);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0, "lp:cell/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_framevar(1);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module13)
	init_entry(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i2);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i4);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pivot__633__13'/6 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0);
	MR_incr_sp_push_msg(7, "lp:IntroducedFrom__pred__pivot__633__13/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(6) = r3;
	MR_stackvar(5) = r2;
	r1 = r5;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i2,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i3,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i4,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
	r4 = float_to_word((word_to_float(MR_stackvar(2)) - ((word_to_float(r1) * word_to_float(MR_stackvar(1))) / word_to_float(MR_stackvar(3)))));
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__lp__set_index_5_0),
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0));
END_MODULE


BEGIN_MODULE(lp_module14)
	init_entry(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1009);
	init_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1013);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__pivot__626__12'/4 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0);
	MR_mkframe("lp:IntroducedFrom__pred__pivot__626__12/4", 5, ENTRY(do_fail));
	MR_framevar(1) = r1;
	MR_framevar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_framevar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	r1 = (Integer) 0;
	MR_framevar(3) = r3;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
	MR_framevar(4) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(5);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1009,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1009);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	if ((MR_framevar(4) == MR_framevar(1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(3);
	call_localret(STATIC(mercury__lp__all_cols0_2_0),
		mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1013,
		STATIC(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0_i1013);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0));
	if ((r1 == MR_framevar(2)))
		GOTO(ENTRY(do_redo));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0, "lp:cell/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module15)
	init_entry(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0);
	init_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1007);
	init_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1009);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__fix_basis_and_rem_cols__595__11'/4 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0);
	MR_mkframe("lp:IntroducedFrom__pred__fix_basis_and_rem_cols__595__11/4", 4, ENTRY(do_fail));
	MR_framevar(1) = r1;
	MR_framevar(2) = r2;
	MR_framevar(3) = r3;
	call_localret(STATIC(mercury__lp__all_cols_2_0),
		mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1007,
		STATIC(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1007);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0));
	if ((MR_framevar(2) == r1))
		GOTO(ENTRY(do_redo));
	r3 = r1;
	MR_framevar(4) = r1;
	r1 = MR_framevar(1);
	r2 = MR_framevar(3);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1009,
		STATIC(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0_i1009);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0));
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(4);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module16)
	init_entry(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0);
	init_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i2);
	init_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i3);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__fix_basis_and_rem_cols__583__10'/5 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0);
	MR_incr_sp_push_msg(3, "lp:IntroducedFrom__pred__fix_basis_and_rem_cols__583__10/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = r4;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i2,
		STATIC(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0));
	}
Define_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0));
	if ((word_to_float(r1) != (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i3);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0_i3);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module17)
	init_entry(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1007);
	init_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1009);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9/3", 4, ENTRY(do_fail));
	MR_framevar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(1) = r1;
	MR_framevar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Integer) 1;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
	MR_framevar(3) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1007,
		STATIC(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1007);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	r2 = MR_framevar(3);
	r3 = MR_framevar(2);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1009,
		STATIC(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0_i1009);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0));
	if ((word_to_float(r1) == (Float) 0.00000000000000))
		GOTO(ENTRY(do_redo));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_framevar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module18)
	init_entry(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i4);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i6);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i5);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i8);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i9);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i10);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i11);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__simplex__521__8'/5 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0);
	MR_incr_sp_push_msg(6, "lp:IntroducedFrom__pred__simplex__521__8/5");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i3);
	MR_stackvar(4) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i4,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	}
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	if ((word_to_float(r1) <= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = MR_tempr1;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i6,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	}
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = float_to_word((word_to_float(r2) / word_to_float(MR_stackvar(1))));
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i3);
	MR_stackvar(4) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_tempr1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i8,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	}
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__rhs_col_2_0),
		mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i9,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i10,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i10);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0));
	r3 = MR_stackvar(5);
	if ((word_to_float(r3) <= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i11);
	r2 = float_to_word((word_to_float(r1) / word_to_float(r3)));
	if ((word_to_float(r2) > word_to_float(MR_stackvar(2))))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i11);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0_i11);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module19)
	init_entry(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i4);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i5);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i7);
	init_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i8);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__simplex__490__7'/4 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0);
	MR_incr_sp_push_msg(4, "lp:IntroducedFrom__pred__simplex__490__7/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i3);
	MR_stackvar(3) = r2;
	r3 = r2;
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i4,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0));
	if ((word_to_float(r1) >= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 1);
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(3) = r2;
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i7,
		STATIC(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0));
	if ((word_to_float(r1) >= word_to_float(MR_stackvar(1))))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i8);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0_i8);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module20)
	init_entry(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1);
	init_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1007);
	init_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1009);
	init_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i6);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__extract_obj_var2__463__6'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__extract_obj_var2__463__6/3", 4, ENTRY(do_fail));
	MR_framevar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(1) = r1;
	MR_framevar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Integer) 1;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
	MR_framevar(3) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1007,
		STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1007);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	r2 = MR_framevar(3);
	r3 = MR_framevar(2);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1009,
		STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i1009);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
	if (((Float) 1.00000000000000 != word_to_float(r1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	r2 = MR_framevar(3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i6,
		STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0));
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module21)
	init_entry(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i2);
	init_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i5);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__collect_vars__380__5'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0);
	MR_mkframe("lp:IntroducedFrom__pred__collect_vars__380__5/3", 1, LABEL(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i2));
	MR_framevar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i3,
		STATIC(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i5,
		STATIC(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = MR_framevar(1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i5,
		STATIC(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succeed();
END_MODULE

Declare_entry(mercury__map__search_3_1);

BEGIN_MODULE(lp_module22)
	init_entry(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0);
	init_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i3);
	init_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__simplify_coeffs__322__4'/3 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0);
	MR_incr_sp_push_msg(4, "lp:IntroducedFrom__pred__simplify_coeffs__322__4/3");
	MR_stackvar(4) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r4;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i3,
		STATIC(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i2);
	r5 = float_to_word((word_to_float(r2) + word_to_float(MR_stackvar(2))));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0));
Define_label(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0_i2);
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r5 = float_to_word(((Float) 0.00000000000000 + word_to_float(MR_stackvar(2))));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__lp__IntroducedFrom__pred__simplify_coeffs__322__4_3_0));
END_MODULE


BEGIN_MODULE(lp_module23)
	init_entry(mercury__lp__IntroducedFrom__pred__negate_equation__303__3_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__negate_equation__303__3'/2 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__negate_equation__303__3_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__lp__IntroducedFrom__pred__negate_equation__303__3_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_const_field(MR_mktag(0), r2, (Integer) 1))));
	proceed();
END_MODULE


BEGIN_MODULE(lp_module24)
	init_entry(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0);
	init_label(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__two_phase__216__2'/2 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0);
	MR_mkframe("lp:IntroducedFrom__pred__two_phase__216__2/2", 0, ENTRY(do_fail));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0));
Define_label(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module25)
	init_entry(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0);
	init_label(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__one_phase__175__1'/2 in mode 0 */
Define_static(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0);
	MR_mkframe("lp:IntroducedFrom__pred__one_phase__175__1/2", 0, ENTRY(do_fail));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0_i1,
		STATIC(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0));
Define_label(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succeed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(lp_module26)
	init_entry(mercury__lp__lp_solve_8_0);
	init_label(mercury__lp__lp_solve_8_0_i2);
	init_label(mercury__lp__lp_solve_8_0_i3);
BEGIN_CODE

/* code for predicate 'lp_solve'/8 in mode 0 */
Define_entry(mercury__lp__lp_solve_8_0);
	MR_incr_sp_push_msg(7, "lp:lp_solve/8");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__lp_solve_8_0_i2,
		ENTRY(mercury__lp__lp_solve_8_0));
Define_label(mercury__lp__lp_solve_8_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve_8_0));
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__lp__lp_solve_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_9);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_11);
	r4 = MR_stackvar(5);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__lp_solve_8_0_i3,
		ENTRY(mercury__lp__lp_solve_8_0));
Define_label(mercury__lp__lp_solve_8_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve_8_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 4, mercury__lp__lp_solve_8_0, "lp:lp_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_const_field(MR_mktag(0), r6, (Integer) 0);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_const_field(MR_mktag(0), r6, (Integer) 1);
	MR_field(MR_mktag(0), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__lp__lp_solve2_8_0),
		ENTRY(mercury__lp__lp_solve_8_0));
END_MODULE

Declare_entry(mercury__list__map_foldl_5_1);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(lp_module27)
	init_entry(mercury__lp__lp_solve2_8_0);
	init_label(mercury__lp__lp_solve2_8_0_i2);
	init_label(mercury__lp__lp_solve2_8_0_i4);
	init_label(mercury__lp__lp_solve2_8_0_i3);
	init_label(mercury__lp__lp_solve2_8_0_i6);
	init_label(mercury__lp__lp_solve2_8_0_i7);
	init_label(mercury__lp__lp_solve2_8_0_i8);
	init_label(mercury__lp__lp_solve2_8_0_i9);
	init_label(mercury__lp__lp_solve2_8_0_i10);
	init_label(mercury__lp__lp_solve2_8_0_i11);
	init_label(mercury__lp__lp_solve2_8_0_i12);
	init_label(mercury__lp__lp_solve2_8_0_i13);
	init_label(mercury__lp__lp_solve2_8_0_i14);
	init_label(mercury__lp__lp_solve2_8_0_i15);
	init_label(mercury__lp__lp_solve2_8_0_i16);
	init_label(mercury__lp__lp_solve2_8_0_i17);
	init_label(mercury__lp__lp_solve2_8_0_i19);
	init_label(mercury__lp__lp_solve2_8_0_i21);
	init_label(mercury__lp__lp_solve2_8_0_i22);
BEGIN_CODE

/* code for predicate 'lp_solve2'/8 in mode 0 */
Define_static(mercury__lp__lp_solve2_8_0);
	MR_incr_sp_push_msg(11, "lp:lp_solve2/8");
	MR_stackvar(11) = (Word) MR_succip;
	r6 = r5;
	r5 = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	r2 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	r3 = (Word) (Word *) &mercury_data_lp__type_ctor_info_lp_info_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_15);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__lp__lp_solve2_8_0_i2,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__lp__lp_solve2_8_0_i4);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__lp_solve2_8_0_i3,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i4);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(4) = r2;
Define_label(mercury__lp__lp_solve2_8_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	call_localret(STATIC(mercury__lp__simplify_coeffs_2_0),
		mercury__lp__lp_solve2_8_0_i6,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__lp__get_urs_vars_3_0),
		mercury__lp__lp_solve2_8_0_i7,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(STATIC(mercury__lp__expand_urs_vars_3_0),
		mercury__lp__lp_solve2_8_0_i8,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lp__lp_solve2_8_0_i9,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__lp__collect_vars_3_0),
		mercury__lp__lp_solve2_8_0_i10,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__lp__lp_solve2_8_0_i11,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i11);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(9) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__lp__lp_solve2_8_0_i12,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i12);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(10) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__lp_solve2_8_0_i13,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i13);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r3 = r1;
	r1 = MR_stackvar(9);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lp__number_vars_4_0),
		mercury__lp__lp_solve2_8_0_i14,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i14);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__lp__get_art_vars_3_0),
		mercury__lp__lp_solve2_8_0_i15,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i15);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r4 = MR_stackvar(6);
	MR_stackvar(4) = r2;
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(9);
	call_localret(STATIC(mercury__lp__init_tableau_5_0),
		mercury__lp__lp_solve2_8_0_i16,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i16);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = (Integer) 1;
	r3 = MR_stackvar(10);
	r4 = MR_stackvar(9);
	call_localret(STATIC(mercury__lp__insert_equations_6_0),
		mercury__lp__lp_solve2_8_0_i17,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i17);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	if (((Integer) MR_stackvar(6) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__lp_solve2_8_0_i19);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(9);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__lp__one_phase_7_0),
		mercury__lp__lp_solve2_8_0_i21,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i19);
	r5 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(9);
	r6 = MR_stackvar(3);
	call_localret(STATIC(mercury__lp__two_phase_8_0),
		mercury__lp__lp_solve2_8_0_i21,
		STATIC(mercury__lp__lp_solve2_8_0));
Define_label(mercury__lp__lp_solve2_8_0_i21);
	update_prof_current_proc(LABEL(mercury__lp__lp_solve2_8_0));
	r3 = MR_stackvar(4);
	if (((Integer) MR_stackvar(1) == (Integer) 0))
		GOTO_LABEL(mercury__lp__lp_solve2_8_0_i22);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__lp_solve2_8_0_i22);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lp__lp_solve2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0))));
	}
Define_label(mercury__lp__lp_solve2_8_0_i22);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module28)
	init_entry(mercury__lp__one_phase_7_0);
	init_label(mercury__lp__one_phase_7_0_i2);
	init_label(mercury__lp__one_phase_7_0_i3);
	init_label(mercury__lp__one_phase_7_0_i4);
	init_label(mercury__lp__one_phase_7_0_i6);
	init_label(mercury__lp__one_phase_7_0_i7);
	init_label(mercury__lp__one_phase_7_0_i8);
	init_label(mercury__lp__one_phase_7_0_i9);
BEGIN_CODE

/* code for predicate 'one_phase'/7 in mode 0 */
Define_static(mercury__lp__one_phase_7_0);
	MR_incr_sp_push_msg(5, "lp:one_phase/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = (Integer) 0;
	MR_stackvar(2) = r5;
	call_localret(STATIC(mercury__lp__insert_coeffs_5_0),
		mercury__lp__one_phase_7_0_i2,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__lp__one_phase_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__one_phase__175__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_19);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__one_phase_7_0_i3,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__simplex_5_0),
		mercury__lp__one_phase_7_0_i4,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__lp__one_phase_7_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__lp__one_phase_7_0_i6);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = (Integer) 0;
	MR_stackvar(3) = r1;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__one_phase_7_0_i7,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__one_phase_7_0_i8,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__one_phase_7_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_21);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__extract_obj_var_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(3);
	r5 = r4;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__one_phase_7_0_i9,
		STATIC(mercury__lp__one_phase_7_0));
Define_label(mercury__lp__one_phase_7_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__one_phase_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lp__one_phase_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module29)
	init_entry(mercury__lp__two_phase_8_0);
	init_label(mercury__lp__two_phase_8_0_i2);
	init_label(mercury__lp__two_phase_8_0_i3);
	init_label(mercury__lp__two_phase_8_0_i4);
	init_label(mercury__lp__two_phase_8_0_i6);
	init_label(mercury__lp__two_phase_8_0_i7);
	init_label(mercury__lp__two_phase_8_0_i8);
	init_label(mercury__lp__two_phase_8_0_i9);
	init_label(mercury__lp__two_phase_8_0_i11);
	init_label(mercury__lp__two_phase_8_0_i14);
	init_label(mercury__lp__two_phase_8_0_i15);
	init_label(mercury__lp__two_phase_8_0_i16);
	init_label(mercury__lp__two_phase_8_0_i17);
	init_label(mercury__lp__two_phase_8_0_i18);
	init_label(mercury__lp__two_phase_8_0_i19);
BEGIN_CODE

/* code for predicate 'two_phase'/8 in mode 0 */
Define_static(mercury__lp__two_phase_8_0);
	MR_incr_sp_push_msg(8, "lp:two_phase/8");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r3;
	r2 = r4;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	r3 = r5;
	r4 = (Integer) 0;
	MR_stackvar(5) = r6;
	call_localret(STATIC(mercury__lp__DeforestationIn__pred__two_phase__230__0_5_0),
		mercury__lp__two_phase_8_0_i2,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0),
		mercury__lp__two_phase_8_0_i3,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__simplex_5_0),
		mercury__lp__two_phase_8_0_i4,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__lp__two_phase_8_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lp__two_phase_8_0_i6);
	MR_stackvar(6) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = (Integer) 0;
	MR_stackvar(5) = r1;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__two_phase_8_0_i7,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__two_phase_8_0_i8,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__two_phase_8_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__extract_obj_var_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_21);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__two_phase_8_0_i9,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	if ((word_to_float(MR_stackvar(7)) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__two_phase_8_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__lp__two_phase_8_0_i11);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__fix_basis_and_rem_cols_3_0),
		mercury__lp__two_phase_8_0_i14,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i14);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = (Integer) 0;
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__lp__insert_coeffs_5_0),
		mercury__lp__two_phase_8_0_i15,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i15);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	MR_stackvar(2) = r1;
	call_localret(STATIC(mercury__lp__get_basis_vars_2_0),
		mercury__lp__two_phase_8_0_i16,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i16);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0),
		mercury__lp__two_phase_8_0_i17,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i17);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__lp__two_phase_8_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_22);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__two_phase__216__2_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r4;
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__two_phase_8_0_i18,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i18);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__lp__optimize_6_0),
		mercury__lp__two_phase_8_0_i19,
		STATIC(mercury__lp__two_phase_8_0));
Define_label(mercury__lp__two_phase_8_0_i19);
	update_prof_current_proc(LABEL(mercury__lp__two_phase_8_0));
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module30)
	init_entry(mercury__lp__construct_art_objective_2_0);
	init_label(mercury__lp__construct_art_objective_2_0_i4);
	init_label(mercury__lp__construct_art_objective_2_0_i5);
	init_label(mercury__lp__construct_art_objective_2_0_i2);
BEGIN_CODE

/* code for predicate 'construct_art_objective'/2 in mode 0 */
Define_static(mercury__lp__construct_art_objective_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__construct_art_objective_2_0_i2);
	r3 = (Word) MR_sp;
Define_label(mercury__lp__construct_art_objective_2_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "lp:construct_art_objective");
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__lp__construct_art_objective_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__lp__construct_art_objective_2_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__lp__construct_art_objective_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__lp__construct_art_objective_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

static const Float mercury_float_const_neg1pt00000000000000 = -1.00000000000000;

BEGIN_MODULE(lp_module31)
	init_entry(mercury__lp__standardize_equation_4_0);
	init_label(mercury__lp__standardize_equation_4_0_i1007);
	init_label(mercury__lp__standardize_equation_4_0_i4);
	init_label(mercury__lp__standardize_equation_4_0_i7);
	init_label(mercury__lp__standardize_equation_4_0_i8);
	init_label(mercury__lp__standardize_equation_4_0_i9);
	init_label(mercury__lp__standardize_equation_4_0_i3);
	init_label(mercury__lp__standardize_equation_4_0_i15);
	init_label(mercury__lp__standardize_equation_4_0_i16);
	init_label(mercury__lp__standardize_equation_4_0_i17);
	init_label(mercury__lp__standardize_equation_4_0_i13);
	init_label(mercury__lp__standardize_equation_4_0_i19);
	init_label(mercury__lp__standardize_equation_4_0_i20);
	init_label(mercury__lp__standardize_equation_4_0_i21);
	init_label(mercury__lp__standardize_equation_4_0_i12);
	init_label(mercury__lp__standardize_equation_4_0_i25);
	init_label(mercury__lp__standardize_equation_4_0_i24);
	init_label(mercury__lp__standardize_equation_4_0_i27);
	init_label(mercury__lp__standardize_equation_4_0_i28);
	init_label(mercury__lp__standardize_equation_4_0_i29);
	init_label(mercury__lp__standardize_equation_4_0_i30);
	init_label(mercury__lp__standardize_equation_4_0_i31);
BEGIN_CODE

/* code for predicate 'standardize_equation'/4 in mode 0 */
Define_static(mercury__lp__standardize_equation_4_0);
	MR_incr_sp_push_msg(4, "lp:standardize_equation/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__lp__standardize_equation_4_0_i1007);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	if ((word_to_float(r4) >= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i4);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__negate_equation_2_0),
		mercury__lp__standardize_equation_4_0_i25,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i4);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	r1 = r2;
	call_localret(STATIC(mercury__lp__new_slack_var_3_0),
		mercury__lp__standardize_equation_4_0_i7,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	MR_stackvar(1) = r2;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__standardize_equation_4_0, "lp:equation/0");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__lp__standardize_equation_4_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lp__standardize_equation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	call_localret(STATIC(mercury__lp__simplify_2_0),
		mercury__lp__standardize_equation_4_0_i8,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__get_urs_vars_3_0),
		mercury__lp__standardize_equation_4_0_i9,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__lp__expand_urs_vars_e_3_0),
		mercury__lp__standardize_equation_4_0_i31,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i3);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i12);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	if ((word_to_float(r4) >= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i13);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i15);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(3) = (Integer) 2;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__standardize_equation_4_0_i17,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i15);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i16);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(3) = (Integer) 1;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__standardize_equation_4_0_i17,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i16);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(3) = (Integer) 0;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__standardize_equation_4_0_i17,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i17);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__standardize_equation_4_0, "lp:equation/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_stackvar(2))));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lp__standardize_equation_4_0_i1007);
Define_label(mercury__lp__standardize_equation_4_0_i13);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	r1 = r2;
	call_localret(STATIC(mercury__lp__new_art_var_3_0),
		mercury__lp__standardize_equation_4_0_i19,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i19);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	MR_stackvar(1) = r2;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__standardize_equation_4_0, "lp:equation/0");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__lp__standardize_equation_4_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lp__standardize_equation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	call_localret(STATIC(mercury__lp__simplify_2_0),
		mercury__lp__standardize_equation_4_0_i20,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i20);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__get_urs_vars_3_0),
		mercury__lp__standardize_equation_4_0_i21,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i21);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__lp__expand_urs_vars_e_3_0),
		mercury__lp__standardize_equation_4_0_i31,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i12);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	if ((word_to_float(r4) >= (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__standardize_equation_4_0_i24);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__negate_equation_2_0),
		mercury__lp__standardize_equation_4_0_i25,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i25);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lp__standardize_equation_4_0_i1007);
Define_label(mercury__lp__standardize_equation_4_0_i24);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	r1 = r2;
	call_localret(STATIC(mercury__lp__new_slack_var_3_0),
		mercury__lp__standardize_equation_4_0_i27,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i27);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__lp__new_art_var_3_0),
		mercury__lp__standardize_equation_4_0_i28,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i28);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__standardize_equation_4_0, "lp:equation/0");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__lp__standardize_equation_4_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lp__standardize_equation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) &mercury_float_const_neg1pt00000000000000;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__lp__standardize_equation_4_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__lp__standardize_equation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r4;
	call_localret(STATIC(mercury__lp__simplify_2_0),
		mercury__lp__standardize_equation_4_0_i29,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i29);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__get_urs_vars_3_0),
		mercury__lp__standardize_equation_4_0_i30,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i30);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__lp__expand_urs_vars_e_3_0),
		mercury__lp__standardize_equation_4_0_i31,
		STATIC(mercury__lp__standardize_equation_4_0));
Define_label(mercury__lp__standardize_equation_4_0_i31);
	update_prof_current_proc(LABEL(mercury__lp__standardize_equation_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module32)
	init_entry(mercury__lp__negate_equation_2_0);
	init_label(mercury__lp__negate_equation_2_0_i3);
	init_label(mercury__lp__negate_equation_2_0_i4);
	init_label(mercury__lp__negate_equation_2_0_i5);
BEGIN_CODE

/* code for predicate 'negate_equation'/2 in mode 0 */
Define_static(mercury__lp__negate_equation_2_0);
	MR_incr_sp_push_msg(3, "lp:negate_equation/2");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__lp__negate_equation_2_0_i3);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(2) = (Integer) 2;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__negate_equation_2_0_i5,
		STATIC(mercury__lp__negate_equation_2_0));
Define_label(mercury__lp__negate_equation_2_0_i3);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__lp__negate_equation_2_0_i4);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(2) = (Integer) 1;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__negate_equation_2_0_i5,
		STATIC(mercury__lp__negate_equation_2_0));
Define_label(mercury__lp__negate_equation_2_0_i4);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_17);
	MR_stackvar(2) = (Integer) 0;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__lp__negate_equation_2_0_i5,
		STATIC(mercury__lp__negate_equation_2_0));
Define_label(mercury__lp__negate_equation_2_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__negate_equation_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__negate_equation_2_0, "lp:equation/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_stackvar(1))));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(lp_module33)
	init_entry(mercury__lp__simplify_2_0);
	init_label(mercury__lp__simplify_2_0_i2);
	init_label(mercury__lp__simplify_2_0_i3);
	init_label(mercury__lp__simplify_2_0_i4);
BEGIN_CODE

/* code for predicate 'simplify'/2 in mode 0 */
Define_static(mercury__lp__simplify_2_0);
	MR_incr_sp_push_msg(4, "lp:simplify/2");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__simplify_2_0_i2,
		STATIC(mercury__lp__simplify_2_0));
Define_label(mercury__lp__simplify_2_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__simplify_2_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_24);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__simplify_2_0_i3,
		STATIC(mercury__lp__simplify_2_0));
Define_label(mercury__lp__simplify_2_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__simplify_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__lp__simplify_2_0_i4,
		STATIC(mercury__lp__simplify_2_0));
Define_label(mercury__lp__simplify_2_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__simplify_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__simplify_2_0, "lp:equation/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module34)
	init_entry(mercury__lp__simplify_coeffs_2_0);
	init_label(mercury__lp__simplify_coeffs_2_0_i2);
	init_label(mercury__lp__simplify_coeffs_2_0_i3);
BEGIN_CODE

/* code for predicate 'simplify_coeffs'/2 in mode 0 */
Define_static(mercury__lp__simplify_coeffs_2_0);
	MR_incr_sp_push_msg(2, "lp:simplify_coeffs/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__simplify_coeffs_2_0_i2,
		STATIC(mercury__lp__simplify_coeffs_2_0));
Define_label(mercury__lp__simplify_coeffs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__simplify_coeffs_2_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_24);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__simplify_coeffs_2_0_i3,
		STATIC(mercury__lp__simplify_coeffs_2_0));
Define_label(mercury__lp__simplify_coeffs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__simplify_coeffs_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		STATIC(mercury__lp__simplify_coeffs_2_0));
END_MODULE

Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(lp_module35)
	init_entry(mercury__lp__expand_urs_vars_e_3_0);
	init_label(mercury__lp__expand_urs_vars_e_3_0_i2);
	init_label(mercury__lp__expand_urs_vars_e_3_0_i3);
BEGIN_CODE

/* code for predicate 'expand_urs_vars_e'/3 in mode 0 */
Define_static(mercury__lp__expand_urs_vars_e_3_0);
	MR_incr_sp_push_msg(3, "lp:expand_urs_vars_e/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__lp__expand_urs_vars_4_0),
		mercury__lp__expand_urs_vars_e_3_0_i2,
		STATIC(mercury__lp__expand_urs_vars_e_3_0));
Define_label(mercury__lp__expand_urs_vars_e_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__expand_urs_vars_e_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__lp__expand_urs_vars_e_3_0_i3,
		STATIC(mercury__lp__expand_urs_vars_e_3_0));
Define_label(mercury__lp__expand_urs_vars_e_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__expand_urs_vars_e_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__lp__expand_urs_vars_e_3_0, "lp:equation/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module36)
	init_entry(mercury__lp__expand_urs_vars_3_0);
	init_label(mercury__lp__expand_urs_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'expand_urs_vars'/3 in mode 0 */
Define_static(mercury__lp__expand_urs_vars_3_0);
	MR_incr_sp_push_msg(1, "lp:expand_urs_vars/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__lp__expand_urs_vars_4_0),
		mercury__lp__expand_urs_vars_3_0_i2,
		STATIC(mercury__lp__expand_urs_vars_3_0));
Define_label(mercury__lp__expand_urs_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__expand_urs_vars_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__list__reverse_2_0),
		STATIC(mercury__lp__expand_urs_vars_3_0));
END_MODULE


BEGIN_MODULE(lp_module37)
	init_entry(mercury__lp__expand_urs_vars_4_0);
	init_label(mercury__lp__expand_urs_vars_4_0_i1002);
	init_label(mercury__lp__expand_urs_vars_4_0_i5);
	init_label(mercury__lp__expand_urs_vars_4_0_i4);
	init_label(mercury__lp__expand_urs_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'expand_urs_vars'/4 in mode 0 */
Define_static(mercury__lp__expand_urs_vars_4_0);
	MR_incr_sp_push_msg(6, "lp:expand_urs_vars/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lp__expand_urs_vars_4_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__expand_urs_vars_4_0_i3);
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lp__expand_urs_vars_4_0_i5,
		STATIC(mercury__lp__expand_urs_vars_4_0));
	}
Define_label(mercury__lp__expand_urs_vars_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__expand_urs_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__expand_urs_vars_4_0_i4);
	r4 = r2;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__expand_urs_vars_4_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__lp__expand_urs_vars_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_stackvar(3))));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__lp__expand_urs_vars_4_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__lp__expand_urs_vars_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lp__expand_urs_vars_4_0_i1002);
	}
Define_label(mercury__lp__expand_urs_vars_4_0_i4);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__expand_urs_vars_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lp__expand_urs_vars_4_0_i1002);
Define_label(mercury__lp__expand_urs_vars_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);

BEGIN_MODULE(lp_module38)
	init_entry(mercury__lp__collect_vars_3_0);
	init_label(mercury__lp__collect_vars_3_0_i2);
BEGIN_CODE

/* code for predicate 'collect_vars'/3 in mode 0 */
Define_static(mercury__lp__collect_vars_3_0);
	MR_incr_sp_push_msg(1, "lp:collect_vars/3");
	MR_stackvar(1) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__lp__collect_vars_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r2;
	r2 = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__collect_vars__380__5_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_26);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__collect_vars_3_0_i2,
		STATIC(mercury__lp__collect_vars_3_0));
Define_label(mercury__lp__collect_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__collect_vars_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		STATIC(mercury__lp__collect_vars_3_0));
END_MODULE

Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(lp_module39)
	init_entry(mercury__lp__number_vars_4_0);
	init_label(mercury__lp__number_vars_4_0_i1001);
	init_label(mercury__lp__number_vars_4_0_i4);
	init_label(mercury__lp__number_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'number_vars'/4 in mode 0 */
Define_static(mercury__lp__number_vars_4_0);
	MR_incr_sp_push_msg(3, "lp:number_vars/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__lp__number_vars_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__number_vars_4_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__lp__number_vars_4_0_i4,
		STATIC(mercury__lp__number_vars_4_0));
Define_label(mercury__lp__number_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__number_vars_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = ((Integer) MR_stackvar(1) + (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__lp__number_vars_4_0_i1001);
Define_label(mercury__lp__number_vars_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module40)
	init_entry(mercury__lp__insert_equations_6_0);
	init_label(mercury__lp__insert_equations_6_0_i1001);
	init_label(mercury__lp__insert_equations_6_0_i4);
	init_label(mercury__lp__insert_equations_6_0_i5);
	init_label(mercury__lp__insert_equations_6_0_i3);
BEGIN_CODE

/* code for predicate 'insert_equations'/6 in mode 0 */
Define_static(mercury__lp__insert_equations_6_0);
	MR_incr_sp_push_msg(6, "lp:insert_equations/6");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lp__insert_equations_6_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__insert_equations_6_0_i3);
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r4;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r4 = r5;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__lp__insert_coeffs_5_0),
		mercury__lp__insert_equations_6_0_i4,
		STATIC(mercury__lp__insert_equations_6_0));
	}
Define_label(mercury__lp__insert_equations_6_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__insert_equations_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__set_index_5_0),
		mercury__lp__insert_equations_6_0_i5,
		STATIC(mercury__lp__insert_equations_6_0));
Define_label(mercury__lp__insert_equations_6_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__insert_equations_6_0));
	r5 = r1;
	r1 = MR_stackvar(4);
	r2 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lp__insert_equations_6_0_i1001);
Define_label(mercury__lp__insert_equations_6_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module41)
	init_entry(mercury__lp__insert_coeffs_5_0);
	init_label(mercury__lp__insert_coeffs_5_0_i1001);
	init_label(mercury__lp__insert_coeffs_5_0_i4);
	init_label(mercury__lp__insert_coeffs_5_0_i5);
	init_label(mercury__lp__insert_coeffs_5_0_i3);
BEGIN_CODE

/* code for predicate 'insert_coeffs'/5 in mode 0 */
Define_static(mercury__lp__insert_coeffs_5_0);
	MR_incr_sp_push_msg(6, "lp:insert_coeffs/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__lp__insert_coeffs_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__insert_coeffs_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__insert_coeffs_5_0_i4,
		STATIC(mercury__lp__insert_coeffs_5_0));
	}
Define_label(mercury__lp__insert_coeffs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__insert_coeffs_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__lp__set_index_5_0),
		mercury__lp__insert_coeffs_5_0_i5,
		STATIC(mercury__lp__insert_coeffs_5_0));
Define_label(mercury__lp__insert_coeffs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__insert_coeffs_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__lp__insert_coeffs_5_0_i1001);
Define_label(mercury__lp__insert_coeffs_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module42)
	init_entry(mercury__lp__optimize_6_0);
	init_label(mercury__lp__optimize_6_0_i2);
	init_label(mercury__lp__optimize_6_0_i4);
	init_label(mercury__lp__optimize_6_0_i5);
	init_label(mercury__lp__optimize_6_0_i6);
	init_label(mercury__lp__optimize_6_0_i7);
BEGIN_CODE

/* code for predicate 'optimize'/6 in mode 0 */
Define_static(mercury__lp__optimize_6_0);
	MR_incr_sp_push_msg(5, "lp:optimize/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(STATIC(mercury__lp__simplex_5_0),
		mercury__lp__optimize_6_0_i2,
		STATIC(mercury__lp__optimize_6_0));
Define_label(mercury__lp__optimize_6_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__optimize_6_0));
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__lp__optimize_6_0_i4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__lp__optimize_6_0_i4);
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = (Integer) 0;
	MR_stackvar(2) = r1;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__optimize_6_0_i5,
		STATIC(mercury__lp__optimize_6_0));
Define_label(mercury__lp__optimize_6_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__optimize_6_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__optimize_6_0_i6,
		STATIC(mercury__lp__optimize_6_0));
Define_label(mercury__lp__optimize_6_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__optimize_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__optimize_6_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_20);
	r4 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__extract_obj_var_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_21);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__lp__optimize_6_0_i7,
		STATIC(mercury__lp__optimize_6_0));
Define_label(mercury__lp__optimize_6_0_i7);
	update_prof_current_proc(LABEL(mercury__lp__optimize_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__lp__optimize_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module43)
	init_entry(mercury__lp__extract_obj_var_4_0);
	init_label(mercury__lp__extract_obj_var_4_0_i3);
	init_label(mercury__lp__extract_obj_var_4_0_i5);
	init_label(mercury__lp__extract_obj_var_4_0_i6);
	init_label(mercury__lp__extract_obj_var_4_0_i7);
	init_label(mercury__lp__extract_obj_var_4_0_i11);
	init_label(mercury__lp__extract_obj_var_4_0_i2);
	init_label(mercury__lp__extract_obj_var_4_0_i12);
BEGIN_CODE

/* code for predicate 'extract_obj_var'/4 in mode 0 */
Define_static(mercury__lp__extract_obj_var_4_0);
	MR_incr_sp_push_msg(5, "lp:extract_obj_var/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lp__extract_obj_var_4_0_i3,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__extract_obj_var_4_0_i2);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__extract_obj_var_4_0_i5,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__lp__extract_obj_var_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_28);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__extract_obj_var_4_0_i6,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__extract_obj_var_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__extract_obj_var_4_0_i7);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__extract_obj_var2_3_0),
		mercury__lp__extract_obj_var_4_0_i11,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i7);
	r2 = MR_stackvar(4);
	r1 = MR_stackvar(1);
	MR_stackvar(4) = (Word) &mercury_float_const_0pt00000000000000;
	call_localret(STATIC(mercury__lp__extract_obj_var2_3_0),
		mercury__lp__extract_obj_var_4_0_i11,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i11);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var_4_0));
	r5 = float_to_word((word_to_float(MR_stackvar(4)) - word_to_float(r1)));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__lp__extract_obj_var2_3_0),
		mercury__lp__extract_obj_var_4_0_i12,
		STATIC(mercury__lp__extract_obj_var_4_0));
Define_label(mercury__lp__extract_obj_var_4_0_i12);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var_4_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__lp__extract_obj_var_4_0));
END_MODULE


BEGIN_MODULE(lp_module44)
	init_entry(mercury__lp__extract_obj_var2_3_0);
	init_label(mercury__lp__extract_obj_var2_3_0_i2);
	init_label(mercury__lp__extract_obj_var2_3_0_i3);
	init_label(mercury__lp__extract_obj_var2_3_0_i4);
BEGIN_CODE

/* code for predicate 'extract_obj_var2'/3 in mode 0 */
Define_static(mercury__lp__extract_obj_var2_3_0);
	MR_incr_sp_push_msg(2, "lp:extract_obj_var2/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r4 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__extract_obj_var2_3_0_i2,
		STATIC(mercury__lp__extract_obj_var2_3_0));
Define_label(mercury__lp__extract_obj_var2_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var2_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__lp__extract_obj_var2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__extract_obj_var2__463__6_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_28);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__extract_obj_var2_3_0_i3,
		STATIC(mercury__lp__extract_obj_var2_3_0));
Define_label(mercury__lp__extract_obj_var2_3_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__extract_obj_var2_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__extract_obj_var2_3_0_i4);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__extract_obj_var2_3_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__lp__extract_obj_var2_3_0_i4);
	r1 = (Word) &mercury_float_const_0pt00000000000000;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__std_util__aggregate_4_3);

BEGIN_MODULE(lp_module45)
	init_entry(mercury__lp__simplex_5_0);
	init_label(mercury__lp__simplex_5_0_i1002);
	init_label(mercury__lp__simplex_5_0_i2);
	init_label(mercury__lp__simplex_5_0_i4);
	init_label(mercury__lp__simplex_5_0_i5);
	init_label(mercury__lp__simplex_5_0_i8);
	init_label(mercury__lp__simplex_5_0_i7);
BEGIN_CODE

/* code for predicate 'simplex'/5 in mode 0 */
Define_static(mercury__lp__simplex_5_0);
	MR_incr_sp_push_msg(4, "lp:simplex/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__lp__simplex_5_0_i1002);
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__simplex_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__all_cols_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_29);
	r5 = r1;
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__lp__simplex_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 3) = r5;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__simplex__490__7_4_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_31);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__simplex_5_0_i2,
		STATIC(mercury__lp__simplex_5_0));
Define_label(mercury__lp__simplex_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__simplex_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__simplex_5_0_i4);
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lp__simplex_5_0_i4);
	r4 = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_30);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__simplex_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__all_rows_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_32);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__lp__simplex_5_0, "origin_lost_in_value_number");
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__simplex__521__8_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_33);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__simplex_5_0_i5,
		STATIC(mercury__lp__simplex_5_0));
Define_label(mercury__lp__simplex_5_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__simplex_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__simplex_5_0_i7);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__pivot_4_0),
		mercury__lp__simplex_5_0_i8,
		STATIC(mercury__lp__simplex_5_0));
Define_label(mercury__lp__simplex_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__simplex_5_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lp__simplex_5_0_i1002);
Define_label(mercury__lp__simplex_5_0_i7);
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(lp_module46)
	init_entry(mercury__lp__ensure_zero_obj_coeffs_3_0);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i1003);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i3);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i4);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i5);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i6);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i9);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i12);
	init_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i11);
BEGIN_CODE

/* code for predicate 'ensure_zero_obj_coeffs'/3 in mode 0 */
Define_static(mercury__lp__ensure_zero_obj_coeffs_3_0);
	MR_incr_sp_push_msg(4, "lp:ensure_zero_obj_coeffs/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i1003);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__ensure_zero_obj_coeffs_3_0_i4,
		STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0));
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0));
	r3 = r1;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__ensure_zero_obj_coeffs_3_0_i5,
		STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0));
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0));
	if ((word_to_float(r1) != (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0_i6);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0_i1003);
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i6);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__lp__ensure_zero_obj_coeffs_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_2);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__ensure_zero_obj_coeffs__559__9_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_34);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__ensure_zero_obj_coeffs_3_0_i9,
		STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0));
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i9);
	update_prof_current_proc(LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0_i11);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_lp__type_ctor_info_tableau_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__ensure_zero_obj_coeffs_3_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_35);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__all_cols0_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = r4;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 6, mercury__lp__ensure_zero_obj_coeffs_3_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r5 = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 5) = (Integer) 0;
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r4, (Integer) 3) = float_to_word((((Float) 0.00000000000000 - word_to_float(MR_stackvar(3))) / word_to_float(MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1))));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__row_op__665__17_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_36);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__ensure_zero_obj_coeffs_3_0_i12,
		STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0));
	}
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i12);
	update_prof_current_proc(LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__lp__ensure_zero_obj_coeffs_3_0_i1003);
Define_label(mercury__lp__ensure_zero_obj_coeffs_3_0_i11);
	r1 = (Word) MR_string_const("problem with artificial variable", 32);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__lp__ensure_zero_obj_coeffs_3_0));
END_MODULE


BEGIN_MODULE(lp_module47)
	init_entry(mercury__lp__fix_basis_and_rem_cols_3_0);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i1005);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i4);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i5);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i10);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i12);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i13);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i15);
	init_label(mercury__lp__fix_basis_and_rem_cols_3_0_i3);
BEGIN_CODE

/* code for predicate 'fix_basis_and_rem_cols'/3 in mode 0 */
Define_static(mercury__lp__fix_basis_and_rem_cols_3_0);
	MR_incr_sp_push_msg(5, "lp:fix_basis_and_rem_cols/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__lp__fix_basis_and_rem_cols_3_0_i4,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__fix_basis_and_rem_cols_3_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_38);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__fix_basis_and_rem_cols_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__all_rows_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_32);
	r5 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__lp__fix_basis_and_rem_cols_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 4) = r5;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__583__10_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_39);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__fix_basis_and_rem_cols_3_0_i5,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__fix_basis_and_rem_cols_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((word_to_float(r3) != (Float) 1.00000000000000))
		GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 6, mercury__lp__fix_basis_and_rem_cols_3_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_40);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__fix_basis_and_rem_cols__595__11_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(4);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__fix_basis_and_rem_cols_3_0_i10,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i10);
	update_prof_current_proc(LABEL(mercury__lp__fix_basis_and_rem_cols_3_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i12);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__lp__fix_basis_and_rem_cols_3_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__fix_basis_and_rem_cols_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 4) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__fix_basis_and_rem_cols_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	call_localret(STATIC(mercury__lp__remove_col_3_0),
		mercury__lp__fix_basis_and_rem_cols_3_0_i15,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
	}
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i12);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__pivot_4_0),
		mercury__lp__fix_basis_and_rem_cols_3_0_i13,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i13);
	update_prof_current_proc(LABEL(mercury__lp__fix_basis_and_rem_cols_3_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__lp__fix_basis_and_rem_cols_3_0, "lp:tableau/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__lp__fix_basis_and_rem_cols_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	call_localret(STATIC(mercury__lp__remove_col_3_0),
		mercury__lp__fix_basis_and_rem_cols_3_0_i15,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
	}
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i6);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__remove_col_3_0),
		mercury__lp__fix_basis_and_rem_cols_3_0_i15,
		STATIC(mercury__lp__fix_basis_and_rem_cols_3_0));
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i15);
	update_prof_current_proc(LABEL(mercury__lp__fix_basis_and_rem_cols_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__lp__fix_basis_and_rem_cols_3_0_i1005);
Define_label(mercury__lp__fix_basis_and_rem_cols_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module48)
	init_entry(mercury__lp__pivot_4_0);
	init_label(mercury__lp__pivot_4_0_i2);
	init_label(mercury__lp__pivot_4_0_i3);
	init_label(mercury__lp__pivot_4_0_i4);
	init_label(mercury__lp__pivot_4_0_i5);
BEGIN_CODE

/* code for predicate 'pivot'/4 in mode 0 */
Define_static(mercury__lp__pivot_4_0);
	MR_incr_sp_push_msg(4, "lp:pivot/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	r1 = r3;
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__lp__index_4_0),
		mercury__lp__pivot_4_0_i2,
		STATIC(mercury__lp__pivot_4_0));
Define_label(mercury__lp__pivot_4_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__pivot_4_0));
	r2 = (Word) (Word *) &mercury_data_lp__type_ctor_info_tableau_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__lp__pivot_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__pivot__626__12_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_42);
	r6 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 5) = r6;
	r5 = r1;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_cell_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 6, mercury__lp__pivot_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 5) = r5;
	r5 = r6;
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__pivot__633__13_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_43);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__pivot_4_0_i3,
		STATIC(mercury__lp__pivot_4_0));
Define_label(mercury__lp__pivot_4_0_i3);
	update_prof_current_proc(LABEL(mercury__lp__pivot_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_cell_0;
	r2 = (Word) (Word *) &mercury_data_lp__type_ctor_info_tableau_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__lp__pivot_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_44);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__pivot__642__14_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 4) = r4;
	r5 = r4;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_46);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__pivot_4_0_i4,
		STATIC(mercury__lp__pivot_4_0));
Define_label(mercury__lp__pivot_4_0_i4);
	update_prof_current_proc(LABEL(mercury__lp__pivot_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_lp__type_ctor_info_tableau_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__pivot_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_35);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__lp__all_cols0_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r4;
	r5 = r4;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__lp__pivot_4_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_47);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__pivot__652__16_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(3);
	call_localret(ENTRY(mercury__std_util__aggregate_4_3),
		mercury__lp__pivot_4_0_i5,
		STATIC(mercury__lp__pivot_4_0));
Define_label(mercury__lp__pivot_4_0_i5);
	update_prof_current_proc(LABEL(mercury__lp__pivot_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = (Word) &mercury_float_const_1pt00000000000000;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__lp__set_index_5_0),
		STATIC(mercury__lp__pivot_4_0));
END_MODULE


BEGIN_MODULE(lp_module49)
	init_entry(mercury__lp__init_tableau_5_0);
	init_label(mercury__lp__init_tableau_5_0_i2);
BEGIN_CODE

/* code for predicate 'init_tableau'/5 in mode 0 */
Define_static(mercury__lp__init_tableau_5_0);
	MR_incr_sp_push_msg(5, "lp:init_tableau/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__lp__init_tableau_5_0_i2,
		STATIC(mercury__lp__init_tableau_5_0));
Define_label(mercury__lp__init_tableau_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__init_tableau_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__lp__init_tableau_5_0, "lp:tableau/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 6) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module50)
	init_entry(mercury__lp__index_4_0);
	init_label(mercury__lp__index_4_0_i6);
	init_label(mercury__lp__index_4_0_i8);
	init_label(mercury__lp__index_4_0_i4);
	init_label(mercury__lp__index_4_0_i2);
	init_label(mercury__lp__index_4_0_i13);
	init_label(mercury__lp__index_4_0_i12);
BEGIN_CODE

/* code for predicate 'index'/4 in mode 0 */
Define_static(mercury__lp__index_4_0);
	MR_incr_sp_push_msg(5, "lp:index/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__index_4_0_i6,
		STATIC(mercury__lp__index_4_0));
Define_label(mercury__lp__index_4_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__index_4_0));
	if (r1)
		GOTO_LABEL(mercury__lp__index_4_0_i4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__index_4_0_i8,
		STATIC(mercury__lp__index_4_0));
Define_label(mercury__lp__index_4_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__index_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__index_4_0_i2);
Define_label(mercury__lp__index_4_0_i4);
	r1 = (Word) MR_string_const("attempt to address shunned row/col", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lp__index_4_0_i2,
		STATIC(mercury__lp__index_4_0));
Define_label(mercury__lp__index_4_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__index_4_0));
	r3 = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__lp__index_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__lp__index_4_0_i13,
		STATIC(mercury__lp__index_4_0));
Define_label(mercury__lp__index_4_0_i13);
	update_prof_current_proc(LABEL(mercury__lp__index_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__index_4_0_i12);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__lp__index_4_0_i12);
	r1 = (Word) &mercury_float_const_0pt00000000000000;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__delete_3_1);

BEGIN_MODULE(lp_module51)
	init_entry(mercury__lp__set_index_5_0);
	init_label(mercury__lp__set_index_5_0_i6);
	init_label(mercury__lp__set_index_5_0_i8);
	init_label(mercury__lp__set_index_5_0_i4);
	init_label(mercury__lp__set_index_5_0_i2);
	init_label(mercury__lp__set_index_5_0_i12);
	init_label(mercury__lp__set_index_5_0_i15);
BEGIN_CODE

/* code for predicate 'set_index'/5 in mode 0 */
Define_static(mercury__lp__set_index_5_0);
	MR_incr_sp_push_msg(11, "lp:set_index/5");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(8) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__set_index_5_0_i6,
		STATIC(mercury__lp__set_index_5_0));
Define_label(mercury__lp__set_index_5_0_i6);
	update_prof_current_proc(LABEL(mercury__lp__set_index_5_0));
	if (r1)
		GOTO_LABEL(mercury__lp__set_index_5_0_i4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__set_index_5_0_i8,
		STATIC(mercury__lp__set_index_5_0));
Define_label(mercury__lp__set_index_5_0_i8);
	update_prof_current_proc(LABEL(mercury__lp__set_index_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__lp__set_index_5_0_i2);
Define_label(mercury__lp__set_index_5_0_i4);
	r1 = (Word) MR_string_const("attempt to write shunned row/col", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__lp__set_index_5_0_i2,
		STATIC(mercury__lp__set_index_5_0));
Define_label(mercury__lp__set_index_5_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__set_index_5_0));
	r3 = MR_stackvar(10);
	if ((word_to_float(MR_stackvar(3)) != (Float) 0.00000000000000))
		GOTO_LABEL(mercury__lp__set_index_5_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__lp__set_index_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__lp__set_index_5_0_i15,
		STATIC(mercury__lp__set_index_5_0));
Define_label(mercury__lp__set_index_5_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__lp__set_index_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__lp__set_index_5_0_i15,
		STATIC(mercury__lp__set_index_5_0));
Define_label(mercury__lp__set_index_5_0_i15);
	update_prof_current_proc(LABEL(mercury__lp__set_index_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__lp__set_index_5_0, "lp:tableau/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r2;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module52)
	init_entry(mercury__lp__rhs_col_2_0);
BEGIN_CODE

/* code for predicate 'rhs_col'/2 in mode 0 */
Define_static(mercury__lp__rhs_col_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module53)
	init_entry(mercury__lp__all_rows_2_0);
	init_label(mercury__lp__all_rows_2_0_i1);
	init_label(mercury__lp__all_rows_2_0_i1005);
BEGIN_CODE

/* code for predicate 'all_rows'/2 in mode 0 */
Define_static(mercury__lp__all_rows_2_0);
	MR_mkframe("lp:all_rows/2", 2, ENTRY(do_fail));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_framevar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Integer) 1;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__all_rows_2_0_i1,
		STATIC(mercury__lp__all_rows_2_0));
Define_label(mercury__lp__all_rows_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__all_rows_2_0));
	MR_framevar(1) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__all_rows_2_0_i1005,
		STATIC(mercury__lp__all_rows_2_0));
Define_label(mercury__lp__all_rows_2_0_i1005);
	update_prof_current_proc(LABEL(mercury__lp__all_rows_2_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module54)
	init_entry(mercury__lp__all_cols0_2_0);
	init_label(mercury__lp__all_cols0_2_0_i1);
	init_label(mercury__lp__all_cols0_2_0_i1005);
BEGIN_CODE

/* code for predicate 'all_cols0'/2 in mode 0 */
Define_static(mercury__lp__all_cols0_2_0);
	MR_mkframe("lp:all_cols0/2", 2, ENTRY(do_fail));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_framevar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__all_cols0_2_0_i1,
		STATIC(mercury__lp__all_cols0_2_0));
Define_label(mercury__lp__all_cols0_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__all_cols0_2_0));
	MR_framevar(1) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__all_cols0_2_0_i1005,
		STATIC(mercury__lp__all_cols0_2_0));
Define_label(mercury__lp__all_cols0_2_0_i1005);
	update_prof_current_proc(LABEL(mercury__lp__all_cols0_2_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module55)
	init_entry(mercury__lp__all_cols_2_0);
	init_label(mercury__lp__all_cols_2_0_i1);
	init_label(mercury__lp__all_cols_2_0_i1005);
BEGIN_CODE

/* code for predicate 'all_cols'/2 in mode 0 */
Define_static(mercury__lp__all_cols_2_0);
	MR_mkframe("lp:all_cols/2", 2, ENTRY(do_fail));
	r2 = ((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) + (Integer) -1);
	MR_framevar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__lp__between_3_0),
		mercury__lp__all_cols_2_0_i1,
		STATIC(mercury__lp__all_cols_2_0));
Define_label(mercury__lp__all_cols_2_0_i1);
	update_prof_current_proc(LABEL(mercury__lp__all_cols_2_0));
	MR_framevar(1) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_framevar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__lp__all_cols_2_0_i1005,
		STATIC(mercury__lp__all_cols_2_0));
Define_label(mercury__lp__all_cols_2_0_i1005);
	update_prof_current_proc(LABEL(mercury__lp__all_cols_2_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	r1 = MR_framevar(1);
	MR_succeed();
END_MODULE


BEGIN_MODULE(lp_module56)
	init_entry(mercury__lp__remove_col_3_0);
BEGIN_CODE

/* code for predicate 'remove_col'/3 in mode 0 */
Define_static(mercury__lp__remove_col_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__lp__remove_col_3_0, "lp:tableau/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__lp__remove_col_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE


BEGIN_MODULE(lp_module57)
	init_entry(mercury__lp__get_basis_vars_2_0);
	init_label(mercury__lp__get_basis_vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'get_basis_vars'/2 in mode 0 */
Define_static(mercury__lp__get_basis_vars_2_0);
	MR_incr_sp_push_msg(2, "lp:get_basis_vars/2");
	MR_stackvar(2) = (Word) MR_succip;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__lp__get_basis_vars_2_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__805__19_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_49);
	call_localret(ENTRY(mercury__std_util__solutions_2_1),
		mercury__lp__get_basis_vars_2_0_i2,
		STATIC(mercury__lp__get_basis_vars_2_0));
Define_label(mercury__lp__get_basis_vars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__get_basis_vars_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__lp__get_basis_vars_2_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_51);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__lp__IntroducedFrom__pred__get_basis_vars__817__20_3_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 4) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__std_util__solutions_2_1),
		STATIC(mercury__lp__get_basis_vars_2_0));
END_MODULE


BEGIN_MODULE(lp_module58)
	init_entry(mercury__lp__new_slack_var_3_0);
	init_label(mercury__lp__new_slack_var_3_0_i2);
BEGIN_CODE

/* code for predicate 'new_slack_var'/3 in mode 0 */
Define_static(mercury__lp__new_slack_var_3_0);
	MR_incr_sp_push_msg(2, "lp:new_slack_var/3");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__lp__new_slack_var_3_0_i2,
		STATIC(mercury__lp__new_slack_var_3_0));
Define_label(mercury__lp__new_slack_var_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__new_slack_var_3_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__lp__new_slack_var_3_0, "lp:lp_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__new_slack_var_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE


BEGIN_MODULE(lp_module59)
	init_entry(mercury__lp__new_art_var_3_0);
	init_label(mercury__lp__new_art_var_3_0_i2);
BEGIN_CODE

/* code for predicate 'new_art_var'/3 in mode 0 */
Define_static(mercury__lp__new_art_var_3_0);
	MR_incr_sp_push_msg(2, "lp:new_art_var/3");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__lp__new_art_var_3_0_i2,
		STATIC(mercury__lp__new_art_var_3_0));
Define_label(mercury__lp__new_art_var_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__new_art_var_3_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__lp__new_art_var_3_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r2 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__lp__new_art_var_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 3);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE


BEGIN_MODULE(lp_module60)
	init_entry(mercury__lp__get_urs_vars_3_0);
BEGIN_CODE

/* code for predicate 'get_urs_vars'/3 in mode 0 */
Define_static(mercury__lp__get_urs_vars_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module61)
	init_entry(mercury__lp__get_art_vars_3_0);
BEGIN_CODE

/* code for predicate 'get_art_vars'/3 in mode 0 */
Define_static(mercury__lp__get_art_vars_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module62)
	init_entry(mercury__lp__between_3_0);
	init_label(mercury__lp__between_3_0_i2);
BEGIN_CODE

/* code for predicate 'between'/3 in mode 0 */
Define_static(mercury__lp__between_3_0);
	if (((Integer) r1 > (Integer) r2))
		GOTO(ENTRY(do_redo));
	MR_mkframe("lp:between/3", 2, LABEL(mercury__lp__between_3_0_i2));
	MR_framevar(1) = r1;
	MR_framevar(2) = r2;
	MR_succeed();
Define_label(mercury__lp__between_3_0_i2);
	update_prof_current_proc(LABEL(mercury__lp__between_3_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = ((Integer) MR_framevar(1) + (Integer) 1);
	r2 = MR_framevar(2);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	localtailcall(mercury__lp__between_3_0,
		STATIC(mercury__lp__between_3_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(lp_module63)
	init_entry(mercury____Unify___lp__coeff_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__coeff_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___lp__coeff_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(lp_module64)
	init_entry(mercury____Index___lp__coeff_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__coeff_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___lp__coeff_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(lp_module65)
	init_entry(mercury____Compare___lp__coeff_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__coeff_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___lp__coeff_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(lp_module66)
	init_entry(mercury____Unify___lp__equation_0_0);
	init_label(mercury____Unify___lp__equation_0_0_i2);
	init_label(mercury____Unify___lp__equation_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__equation_0_0);
	MR_incr_sp_push_msg(5, "lp:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___lp__equation_0_0_i2,
		ENTRY(mercury____Unify___lp__equation_0_0));
Define_label(mercury____Unify___lp__equation_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___lp__equation_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__equation_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(3)))
		GOTO_LABEL(mercury____Unify___lp__equation_0_0_i1);
	if ((word_to_float(MR_stackvar(2)) != word_to_float(MR_stackvar(4))))
		GOTO_LABEL(mercury____Unify___lp__equation_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___lp__equation_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module67)
	init_entry(mercury____Index___lp__equation_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__equation_0_0);
	tailcall(STATIC(mercury____Index___lp__equation_0__ua0_2_0),
		ENTRY(mercury____Index___lp__equation_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__builtin_compare_float_3_0);

BEGIN_MODULE(lp_module68)
	init_entry(mercury____Compare___lp__equation_0_0);
	init_label(mercury____Compare___lp__equation_0_0_i3);
	init_label(mercury____Compare___lp__equation_0_0_i7);
	init_label(mercury____Compare___lp__equation_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__equation_0_0);
	MR_incr_sp_push_msg(5, "lp:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___lp__equation_0_0_i3,
		ENTRY(mercury____Compare___lp__equation_0_0));
Define_label(mercury____Compare___lp__equation_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___lp__equation_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__equation_0_0_i12);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___lp__equation_0_0_i7,
		ENTRY(mercury____Compare___lp__equation_0_0));
Define_label(mercury____Compare___lp__equation_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___lp__equation_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__equation_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_float_3_0),
		ENTRY(mercury____Compare___lp__equation_0_0));
Define_label(mercury____Compare___lp__equation_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module69)
	init_entry(mercury____Unify___lp__operator_0_0);
	init_label(mercury____Unify___lp__operator_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__operator_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___lp__operator_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___lp__operator_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module70)
	init_entry(mercury____Index___lp__operator_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__operator_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module71)
	init_entry(mercury____Compare___lp__operator_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__operator_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___lp__operator_0_0));
END_MODULE


BEGIN_MODULE(lp_module72)
	init_entry(mercury____Unify___lp__equations_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__equations_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___lp__equations_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(lp_module73)
	init_entry(mercury____Index___lp__equations_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__equations_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___lp__equations_0_0));
END_MODULE


BEGIN_MODULE(lp_module74)
	init_entry(mercury____Compare___lp__equations_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__equations_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___lp__equations_0_0));
END_MODULE


BEGIN_MODULE(lp_module75)
	init_entry(mercury____Unify___lp__objective_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__objective_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___lp__objective_0_0));
END_MODULE


BEGIN_MODULE(lp_module76)
	init_entry(mercury____Index___lp__objective_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__objective_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___lp__objective_0_0));
END_MODULE


BEGIN_MODULE(lp_module77)
	init_entry(mercury____Compare___lp__objective_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__objective_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_6);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___lp__objective_0_0));
END_MODULE


BEGIN_MODULE(lp_module78)
	init_entry(mercury____Unify___lp__direction_0_0);
	init_label(mercury____Unify___lp__direction_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__direction_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___lp__direction_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___lp__direction_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module79)
	init_entry(mercury____Index___lp__direction_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__direction_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module80)
	init_entry(mercury____Compare___lp__direction_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__direction_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___lp__direction_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(lp_module81)
	init_entry(mercury____Unify___lp__result_0_0);
	init_label(mercury____Unify___lp__result_0_0_i3);
	init_label(mercury____Unify___lp__result_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___lp__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___lp__result_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___lp__result_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___lp__result_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___lp__result_0_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != word_to_float(MR_const_field(MR_mktag(1), r2, (Integer) 0))))
		GOTO_LABEL(mercury____Unify___lp__result_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___lp__result_0_0));
Define_label(mercury____Unify___lp__result_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module82)
	init_entry(mercury____Index___lp__result_0_0);
	init_label(mercury____Index___lp__result_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___lp__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___lp__result_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___lp__result_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(lp_module83)
	init_entry(mercury____Compare___lp__result_0_0);
	init_label(mercury____Compare___lp__result_0_0_i3);
	init_label(mercury____Compare___lp__result_0_0_i2);
	init_label(mercury____Compare___lp__result_0_0_i5);
	init_label(mercury____Compare___lp__result_0_0_i4);
	init_label(mercury____Compare___lp__result_0_0_i6);
	init_label(mercury____Compare___lp__result_0_0_i7);
	init_label(mercury____Compare___lp__result_0_0_i11);
	init_label(mercury____Compare___lp__result_0_0_i15);
	init_label(mercury____Compare___lp__result_0_0_i1015);
	init_label(mercury____Compare___lp__result_0_0_i23);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___lp__result_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___lp__result_0_0_i2);
Define_label(mercury____Compare___lp__result_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___lp__result_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___lp__result_0_0_i4);
Define_label(mercury____Compare___lp__result_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___lp__result_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___lp__result_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___lp__result_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i1015);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___lp__result_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i1015);
	MR_incr_sp_push_msg(3, "lp:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_float_3_0),
		mercury____Compare___lp__result_0_0_i15,
		ENTRY(mercury____Compare___lp__result_0_0));
Define_label(mercury____Compare___lp__result_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___lp__result_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__result_0_0_i23);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___lp__result_0_0));
Define_label(mercury____Compare___lp__result_0_0_i1015);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___lp__result_0_0));
Define_label(mercury____Compare___lp__result_0_0_i23);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);

BEGIN_MODULE(lp_module84)
	init_entry(mercury____Unify___lp__lp_info_0_0);
	init_label(mercury____Unify___lp__lp_info_0_0_i2);
	init_label(mercury____Unify___lp__lp_info_0_0_i4);
	init_label(mercury____Unify___lp__lp_info_0_0_i6);
	init_label(mercury____Unify___lp__lp_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___lp__lp_info_0_0);
	MR_incr_sp_push_msg(7, "lp:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___lp__lp_info_0_0_i2,
		STATIC(mercury____Unify___lp__lp_info_0_0));
Define_label(mercury____Unify___lp__lp_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___lp__lp_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__lp_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lp__lp_info_0_0_i4,
		STATIC(mercury____Unify___lp__lp_info_0_0));
Define_label(mercury____Unify___lp__lp_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___lp__lp_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__lp_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___lp__lp_info_0_0_i6,
		STATIC(mercury____Unify___lp__lp_info_0_0));
Define_label(mercury____Unify___lp__lp_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___lp__lp_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__lp_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___lp__lp_info_0_0));
Define_label(mercury____Unify___lp__lp_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module85)
	init_entry(mercury____Index___lp__lp_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___lp__lp_info_0_0);
	tailcall(STATIC(mercury____Index___lp__lp_info_0__ua0_2_0),
		STATIC(mercury____Index___lp__lp_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);

BEGIN_MODULE(lp_module86)
	init_entry(mercury____Compare___lp__lp_info_0_0);
	init_label(mercury____Compare___lp__lp_info_0_0_i3);
	init_label(mercury____Compare___lp__lp_info_0_0_i7);
	init_label(mercury____Compare___lp__lp_info_0_0_i11);
	init_label(mercury____Compare___lp__lp_info_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___lp__lp_info_0_0);
	MR_incr_sp_push_msg(7, "lp:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___lp__lp_info_0_0_i3,
		STATIC(mercury____Compare___lp__lp_info_0_0));
Define_label(mercury____Compare___lp__lp_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___lp__lp_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__lp_info_0_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lp__lp_info_0_0_i7,
		STATIC(mercury____Compare___lp__lp_info_0_0));
Define_label(mercury____Compare___lp__lp_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___lp__lp_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__lp_info_0_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___lp__lp_info_0_0_i11,
		STATIC(mercury____Compare___lp__lp_info_0_0));
Define_label(mercury____Compare___lp__lp_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___lp__lp_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__lp_info_0_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___lp__lp_info_0_0));
Define_label(mercury____Compare___lp__lp_info_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module87)
	init_entry(mercury____Unify___lp__cell_0_0);
	init_label(mercury____Unify___lp__cell_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___lp__cell_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___lp__cell_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___lp__cell_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___lp__cell_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(lp_module88)
	init_entry(mercury____Index___lp__cell_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___lp__cell_0_0);
	tailcall(STATIC(mercury____Index___lp__cell_0__ua0_2_0),
		STATIC(mercury____Index___lp__cell_0_0));
END_MODULE


BEGIN_MODULE(lp_module89)
	init_entry(mercury____Compare___lp__cell_0_0);
	init_label(mercury____Compare___lp__cell_0_0_i3);
	init_label(mercury____Compare___lp__cell_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___lp__cell_0_0);
	MR_incr_sp_push_msg(3, "lp:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___lp__cell_0_0_i3,
		STATIC(mercury____Compare___lp__cell_0_0));
Define_label(mercury____Compare___lp__cell_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___lp__cell_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__cell_0_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___lp__cell_0_0));
Define_label(mercury____Compare___lp__cell_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module90)
	init_entry(mercury____Unify___lp__tableau_0_0);
	init_label(mercury____Unify___lp__tableau_0_0_i2);
	init_label(mercury____Unify___lp__tableau_0_0_i4);
	init_label(mercury____Unify___lp__tableau_0_0_i6);
	init_label(mercury____Unify___lp__tableau_0_0_i8);
	init_label(mercury____Unify___lp__tableau_0_0_i1008);
	init_label(mercury____Unify___lp__tableau_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___lp__tableau_0_0);
	MR_incr_sp_push_msg(9, "lp:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1008);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1008);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lp__tableau_0_0_i2,
		STATIC(mercury____Unify___lp__tableau_0_0));
Define_label(mercury____Unify___lp__tableau_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___lp__tableau_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___lp__tableau_0_0_i4,
		STATIC(mercury____Unify___lp__tableau_0_0));
Define_label(mercury____Unify___lp__tableau_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___lp__tableau_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___lp__tableau_0_0_i6,
		STATIC(mercury____Unify___lp__tableau_0_0));
Define_label(mercury____Unify___lp__tableau_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___lp__tableau_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___lp__tableau_0_0_i8,
		STATIC(mercury____Unify___lp__tableau_0_0));
Define_label(mercury____Unify___lp__tableau_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___lp__tableau_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___lp__tableau_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___lp__tableau_0_0));
Define_label(mercury____Unify___lp__tableau_0_0_i1008);
	r1 = FALSE;
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___lp__tableau_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(lp_module91)
	init_entry(mercury____Index___lp__tableau_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___lp__tableau_0_0);
	tailcall(STATIC(mercury____Index___lp__tableau_0__ua0_2_0),
		STATIC(mercury____Index___lp__tableau_0_0));
END_MODULE


BEGIN_MODULE(lp_module92)
	init_entry(mercury____Compare___lp__tableau_0_0);
	init_label(mercury____Compare___lp__tableau_0_0_i3);
	init_label(mercury____Compare___lp__tableau_0_0_i7);
	init_label(mercury____Compare___lp__tableau_0_0_i11);
	init_label(mercury____Compare___lp__tableau_0_0_i15);
	init_label(mercury____Compare___lp__tableau_0_0_i19);
	init_label(mercury____Compare___lp__tableau_0_0_i23);
	init_label(mercury____Compare___lp__tableau_0_0_i32);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___lp__tableau_0_0);
	MR_incr_sp_push_msg(13, "lp:__Compare__/3");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___lp__tableau_0_0_i3,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___lp__tableau_0_0_i7,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lp__tableau_0_0_i11,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___lp__tableau_0_0_i15,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___lp__tableau_0_0_i19,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___lp__tableau_0_0_i23,
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___lp__tableau_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___lp__tableau_0_0_i32);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_lp__common_48);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___lp__tableau_0_0));
Define_label(mercury____Compare___lp__tableau_0_0_i32);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__lp_maybe_bunch_0(void)
{
	lp_module0();
	lp_module1();
	lp_module2();
	lp_module3();
	lp_module4();
	lp_module5();
	lp_module6();
	lp_module7();
	lp_module8();
	lp_module9();
	lp_module10();
	lp_module11();
	lp_module12();
	lp_module13();
	lp_module14();
	lp_module15();
	lp_module16();
	lp_module17();
	lp_module18();
	lp_module19();
	lp_module20();
	lp_module21();
	lp_module22();
	lp_module23();
	lp_module24();
	lp_module25();
	lp_module26();
	lp_module27();
	lp_module28();
	lp_module29();
	lp_module30();
	lp_module31();
	lp_module32();
	lp_module33();
	lp_module34();
	lp_module35();
	lp_module36();
	lp_module37();
	lp_module38();
	lp_module39();
}

static void mercury__lp_maybe_bunch_1(void)
{
	lp_module40();
	lp_module41();
	lp_module42();
	lp_module43();
	lp_module44();
	lp_module45();
	lp_module46();
	lp_module47();
	lp_module48();
	lp_module49();
	lp_module50();
	lp_module51();
	lp_module52();
	lp_module53();
	lp_module54();
	lp_module55();
	lp_module56();
	lp_module57();
	lp_module58();
	lp_module59();
	lp_module60();
	lp_module61();
	lp_module62();
	lp_module63();
	lp_module64();
	lp_module65();
	lp_module66();
	lp_module67();
	lp_module68();
	lp_module69();
	lp_module70();
	lp_module71();
	lp_module72();
	lp_module73();
	lp_module74();
	lp_module75();
	lp_module76();
	lp_module77();
	lp_module78();
	lp_module79();
}

static void mercury__lp_maybe_bunch_2(void)
{
	lp_module80();
	lp_module81();
	lp_module82();
	lp_module83();
	lp_module84();
	lp_module85();
	lp_module86();
	lp_module87();
	lp_module88();
	lp_module89();
	lp_module90();
	lp_module91();
	lp_module92();
}

#endif

void mercury__lp__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__lp__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__lp_maybe_bunch_0();
		mercury__lp_maybe_bunch_1();
		mercury__lp_maybe_bunch_2();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_cell_0,
			lp__cell_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_coeff_0,
			lp__coeff_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_direction_0,
			lp__direction_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_equation_0,
			lp__equation_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_equations_0,
			lp__equations_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_lp_info_0,
			lp__lp_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_objective_0,
			lp__objective_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_operator_0,
			lp__operator_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_result_0,
			lp__result_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_lp__type_ctor_info_tableau_0,
			lp__tableau_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
