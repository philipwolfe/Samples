/*
** Automatically generated from `middle_rec.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__middle_rec__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__middle_rec__match_and_generate_4_0);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i9);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i11);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i8);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i15);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i17);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i3);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i24);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i26);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i28);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i30);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i34);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i23);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i38);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i40);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i42);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i44);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i48);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i46);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i50);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1030);
Declare_label(mercury__middle_rec__match_and_generate_4_0_i1);
Declare_static(mercury__middle_rec__generate_switch_9_0);
Declare_label(mercury__middle_rec__generate_switch_9_0_i2);
Declare_label(mercury__middle_rec__generate_switch_9_0_i3);
Declare_label(mercury__middle_rec__generate_switch_9_0_i4);
Declare_label(mercury__middle_rec__generate_switch_9_0_i5);
Declare_label(mercury__middle_rec__generate_switch_9_0_i6);
Declare_label(mercury__middle_rec__generate_switch_9_0_i7);
Declare_label(mercury__middle_rec__generate_switch_9_0_i8);
Declare_label(mercury__middle_rec__generate_switch_9_0_i9);
Declare_label(mercury__middle_rec__generate_switch_9_0_i10);
Declare_label(mercury__middle_rec__generate_switch_9_0_i11);
Declare_label(mercury__middle_rec__generate_switch_9_0_i12);
Declare_label(mercury__middle_rec__generate_switch_9_0_i13);
Declare_label(mercury__middle_rec__generate_switch_9_0_i14);
Declare_label(mercury__middle_rec__generate_switch_9_0_i15);
Declare_label(mercury__middle_rec__generate_switch_9_0_i16);
Declare_label(mercury__middle_rec__generate_switch_9_0_i17);
Declare_label(mercury__middle_rec__generate_switch_9_0_i18);
Declare_label(mercury__middle_rec__generate_switch_9_0_i19);
Declare_label(mercury__middle_rec__generate_switch_9_0_i20);
Declare_label(mercury__middle_rec__generate_switch_9_0_i21);
Declare_label(mercury__middle_rec__generate_switch_9_0_i22);
Declare_label(mercury__middle_rec__generate_switch_9_0_i23);
Declare_label(mercury__middle_rec__generate_switch_9_0_i24);
Declare_label(mercury__middle_rec__generate_switch_9_0_i25);
Declare_label(mercury__middle_rec__generate_switch_9_0_i26);
Declare_label(mercury__middle_rec__generate_switch_9_0_i27);
Declare_label(mercury__middle_rec__generate_switch_9_0_i28);
Declare_label(mercury__middle_rec__generate_switch_9_0_i29);
Declare_label(mercury__middle_rec__generate_switch_9_0_i30);
Declare_label(mercury__middle_rec__generate_switch_9_0_i31);
Declare_label(mercury__middle_rec__generate_switch_9_0_i32);
Declare_label(mercury__middle_rec__generate_switch_9_0_i33);
Declare_label(mercury__middle_rec__generate_switch_9_0_i34);
Declare_label(mercury__middle_rec__generate_switch_9_0_i35);
Declare_label(mercury__middle_rec__generate_switch_9_0_i36);
Declare_label(mercury__middle_rec__generate_switch_9_0_i37);
Declare_label(mercury__middle_rec__generate_switch_9_0_i38);
Declare_label(mercury__middle_rec__generate_switch_9_0_i39);
Declare_label(mercury__middle_rec__generate_switch_9_0_i41);
Declare_label(mercury__middle_rec__generate_switch_9_0_i42);
Declare_label(mercury__middle_rec__generate_switch_9_0_i43);
Declare_label(mercury__middle_rec__generate_switch_9_0_i44);
Declare_label(mercury__middle_rec__generate_switch_9_0_i45);
Declare_label(mercury__middle_rec__generate_switch_9_0_i46);
Declare_label(mercury__middle_rec__generate_switch_9_0_i49);
Declare_label(mercury__middle_rec__generate_switch_9_0_i1203);
Declare_label(mercury__middle_rec__generate_switch_9_0_i1);
Declare_static(mercury__middle_rec__generate_downloop_test_3_0);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i3);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i7);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i9);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i5);
Declare_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
Declare_static(mercury__middle_rec__split_rec_code_3_0);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i1007);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i8);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i7);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i5);
Declare_label(mercury__middle_rec__split_rec_code_3_0_i13);
Declare_static(mercury__middle_rec__add_counter_to_livevals_3_0);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i6);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
Declare_label(mercury__middle_rec__add_counter_to_livevals_3_0_i3);
Declare_static(mercury__middle_rec__find_unused_register_2_0);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i2);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i3);
Declare_label(mercury__middle_rec__find_unused_register_2_0_i4);
Declare_static(mercury__middle_rec__find_unused_register_2_3_0);
Declare_label(mercury__middle_rec__find_unused_register_2_3_0_i1002);
Declare_label(mercury__middle_rec__find_unused_register_2_3_0_i3);
Declare_label(mercury__middle_rec__find_unused_register_2_3_0_i4);
Declare_static(mercury__middle_rec__find_used_registers_3_0);
Declare_label(mercury__middle_rec__find_used_registers_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_3_0_i4);
Declare_label(mercury__middle_rec__find_used_registers_3_0_i3);
Declare_static(mercury__middle_rec__find_used_registers_instr_3_0);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i6);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i9);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i10);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i12);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i24);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i25);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i41);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i45);
Declare_label(mercury__middle_rec__find_used_registers_instr_3_0_i48);
Declare_static(mercury__middle_rec__find_used_registers_components_3_0);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i1005);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i7);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i9);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i10);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i1004);
Declare_label(mercury__middle_rec__find_used_registers_components_3_0_i3);
Declare_static(mercury__middle_rec__find_used_registers_lvals_3_0);
Declare_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
Declare_label(mercury__middle_rec__find_used_registers_lvals_3_0_i3);
Declare_static(mercury__middle_rec__find_used_registers_lval_3_0);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i5);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i9);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i7);
Declare_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
Declare_static(mercury__middle_rec__find_used_registers_rval_3_0);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i4);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i6);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i13);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i14);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i16);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i17);
Declare_label(mercury__middle_rec__find_used_registers_rval_3_0_i19);
Declare_static(mercury__middle_rec__find_used_registers_mem_ref_3_0);
Declare_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i1001);
Declare_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i5);
Declare_static(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1002);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i5);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
Declare_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i3);
Declare_static(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
Declare_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1001);
Declare_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
Declare_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i3);
Declare_static(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
Declare_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1001);
Declare_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
Declare_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i3);
Declare_static(mercury__middle_rec__find_labels_2_0);
Declare_static(mercury__middle_rec__find_labels_2_3_0);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i1003);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i4);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i8);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i6);
Declare_label(mercury__middle_rec__find_labels_2_3_0_i3);
Declare_static(mercury____Unify___middle_rec__ite_rec_0_0);
Declare_label(mercury____Unify___middle_rec__ite_rec_0_0_i1);
Declare_static(mercury____Index___middle_rec__ite_rec_0_0);
Declare_static(mercury____Compare___middle_rec__ite_rec_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_middle_rec__type_ctor_info_ite_rec_0;

static const struct mercury_data_middle_rec__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_middle_rec__common_0;

static const struct mercury_data_middle_rec__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_middle_rec__common_1;

static const struct mercury_data_middle_rec__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_middle_rec__common_2;

static const struct mercury_data_middle_rec__common_3_struct {
	Integer f1;
}  mercury_data_middle_rec__common_3;

static const struct mercury_data_middle_rec__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_middle_rec__common_4;

static const struct mercury_data_middle_rec__common_5_struct {
	Integer f1;
}  mercury_data_middle_rec__common_5;

static const struct mercury_data_middle_rec__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_middle_rec__common_6;

static const struct mercury_data_middle_rec__common_7_struct {
	Word * f1;
}  mercury_data_middle_rec__common_7;

static const struct mercury_data_middle_rec__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_middle_rec__common_8;

static const struct mercury_data_middle_rec__common_9_struct {
	Word * f1;
	String f2;
}  mercury_data_middle_rec__common_9;

static const struct mercury_data_middle_rec__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_middle_rec__common_10;

static const struct mercury_data_middle_rec__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_middle_rec__common_11;

static const struct mercury_data_middle_rec__common_12_struct {
	Word * f1;
	String f2;
}  mercury_data_middle_rec__common_12;

static const struct mercury_data_middle_rec__common_13_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_middle_rec__common_13;

static const struct mercury_data_middle_rec__type_ctor_functors_ite_rec_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_middle_rec__type_ctor_functors_ite_rec_0;

static const struct mercury_data_middle_rec__type_ctor_layout_ite_rec_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_middle_rec__type_ctor_layout_ite_rec_0;

const struct MR_TypeCtorInfo_struct mercury_data_middle_rec__type_ctor_info_ite_rec_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___middle_rec__ite_rec_0_0),
	STATIC(mercury____Index___middle_rec__ite_rec_0_0),
	STATIC(mercury____Compare___middle_rec__ite_rec_0_0),
	(Integer) 0,
	(Word *) &mercury_data_middle_rec__type_ctor_functors_ite_rec_0,
	(Word *) &mercury_data_middle_rec__type_ctor_layout_ite_rec_0,
	MR_string_const("middle_rec", 10),
	MR_string_const("ite_rec", 7),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_middle_rec__common_0_struct mercury_data_middle_rec__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_middle_rec__common_1_struct mercury_data_middle_rec__common_1 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_middle_rec__common_2_struct mercury_data_middle_rec__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_middle_rec__common_3_struct mercury_data_middle_rec__common_3 = {
	(Integer) 0
};

static const struct mercury_data_middle_rec__common_4_struct mercury_data_middle_rec__common_4 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_middle_rec__common_3)
};

static const struct mercury_data_middle_rec__common_5_struct mercury_data_middle_rec__common_5 = {
	(Integer) 1
};

static const struct mercury_data_middle_rec__common_6_struct mercury_data_middle_rec__common_6 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_middle_rec__common_5)
};

static const struct mercury_data_middle_rec__common_7_struct mercury_data_middle_rec__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))
};

static const struct mercury_data_middle_rec__common_8_struct mercury_data_middle_rec__common_8 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_middle_rec__common_9_struct mercury_data_middle_rec__common_9 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_8),
	MR_string_const("exit from base case", 19)
};

static const struct mercury_data_middle_rec__common_10_struct mercury_data_middle_rec__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_middle_rec__common_11_struct mercury_data_middle_rec__common_11 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_middle_rec__common_10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_middle_rec__common_12_struct mercury_data_middle_rec__common_12 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_8),
	MR_string_const("exit from recursive case", 24)
};

static const struct mercury_data_middle_rec__common_13_struct mercury_data_middle_rec__common_13 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("in_then", 7),
	MR_string_const("in_else", 7)
};

static const struct mercury_data_middle_rec__type_ctor_functors_ite_rec_0_struct mercury_data_middle_rec__type_ctor_functors_ite_rec_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_13)
};

static const struct mercury_data_middle_rec__type_ctor_layout_ite_rec_0_struct mercury_data_middle_rec__type_ctor_layout_ite_rec_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_13)
};

Declare_entry(mercury__code_aux__contains_only_builtins_1_0);
Declare_entry(mercury__code_aux__contains_simple_recursive_call_3_0);
Declare_entry(mercury__std_util__semidet_fail_0_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(middle_rec_module0)
	init_entry(mercury__middle_rec__match_and_generate_4_0);
	init_label(mercury__middle_rec__match_and_generate_4_0_i9);
	init_label(mercury__middle_rec__match_and_generate_4_0_i11);
	init_label(mercury__middle_rec__match_and_generate_4_0_i8);
	init_label(mercury__middle_rec__match_and_generate_4_0_i15);
	init_label(mercury__middle_rec__match_and_generate_4_0_i17);
	init_label(mercury__middle_rec__match_and_generate_4_0_i3);
	init_label(mercury__middle_rec__match_and_generate_4_0_i24);
	init_label(mercury__middle_rec__match_and_generate_4_0_i26);
	init_label(mercury__middle_rec__match_and_generate_4_0_i28);
	init_label(mercury__middle_rec__match_and_generate_4_0_i30);
	init_label(mercury__middle_rec__match_and_generate_4_0_i34);
	init_label(mercury__middle_rec__match_and_generate_4_0_i23);
	init_label(mercury__middle_rec__match_and_generate_4_0_i38);
	init_label(mercury__middle_rec__match_and_generate_4_0_i40);
	init_label(mercury__middle_rec__match_and_generate_4_0_i42);
	init_label(mercury__middle_rec__match_and_generate_4_0_i44);
	init_label(mercury__middle_rec__match_and_generate_4_0_i48);
	init_label(mercury__middle_rec__match_and_generate_4_0_i46);
	init_label(mercury__middle_rec__match_and_generate_4_0_i50);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1030);
	init_label(mercury__middle_rec__match_and_generate_4_0_i1);
BEGIN_CODE

/* code for predicate 'match_and_generate'/4 in mode 0 */
Define_entry(mercury__middle_rec__match_and_generate_4_0);
	MR_incr_sp_push_msg(9, "middle_rec:match_and_generate/4");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 2) != (Integer) 1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1030);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1030);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1030);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1030);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 1), (Integer) 0), (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 1), (Integer) 0), (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 0), (Integer) 1);
	r6 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 4);
	r7 = MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1);
	r8 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r7;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 3), (Integer) 0), (Integer) 0);
	MR_stackvar(6) = r5;
	MR_stackvar(7) = r4;
	MR_stackvar(8) = r3;
	r9 = r1;
	r1 = r5;
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i9,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i8);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i11,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i11);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i8);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__middle_rec__generate_switch_9_0),
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i8);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i15,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i15);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i17,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i17);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__middle_rec__generate_switch_9_0),
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(3) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i24,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i24);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i23);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i26,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i26);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i23);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i28,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i28);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i23);
	if (((Integer) 0 != (Integer) r2))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i23);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i30,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i30);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	MR_stackvar(2) = MR_stackvar(1);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i34,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i34);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i46);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i23);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i38,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i38);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_aux__contains_simple_recursive_call_3_0),
		mercury__middle_rec__match_and_generate_4_0_i40,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i40);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	if (((Integer) 0 != (Integer) r2))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_aux__contains_only_builtins_1_0),
		mercury__middle_rec__match_and_generate_4_0_i42,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i42);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i44,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i44);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i1);
	MR_stackvar(2) = MR_stackvar(1);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__middle_rec__match_and_generate_4_0_i48,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i48);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__middle_rec__match_and_generate_4_0_i46);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i46);
	r1 = (Word) MR_string_const("middle_rec__generate_ite reached", 32);
	MR_stackvar(1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__middle_rec__match_and_generate_4_0_i50,
		ENTRY(mercury__middle_rec__match_and_generate_4_0));
Define_label(mercury__middle_rec__match_and_generate_4_0_i50);
	update_prof_current_proc(LABEL(mercury__middle_rec__match_and_generate_4_0));
	r2 = r1;
	r3 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i1030);
	r1 = FALSE;
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__middle_rec__match_and_generate_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_stack_slots_3_0);
Declare_entry(mercury__code_info__get_varset_3_0);
Declare_entry(mercury__code_aux__explain_stack_slots_3_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__code_info__get_pred_id_3_0);
Declare_entry(mercury__code_info__get_proc_id_3_0);
Declare_entry(mercury__code_util__make_local_entry_label_5_0);
Declare_entry(mercury__code_info__pre_goal_update_4_0);
Declare_entry(mercury__unify_gen__generate_tag_test_7_0);
Declare_entry(mercury__tree__flatten_2_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);
Declare_entry(mercury__code_info__post_goal_update_3_0);
Declare_entry(mercury__code_info__after_all_branches_4_0);
Declare_entry(mercury__code_info__get_arginfo_3_0);
Declare_entry(mercury__code_info__get_headvars_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);
Declare_entry(mercury__code_info__setup_call_5_0);
Declare_entry(mercury__code_util__output_args_2_0);
Declare_entry(mercury__opt_util__block_refers_stackvars_2_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);
Declare_entry(mercury__hlds_module__predicate_module_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(middle_rec_module1)
	init_entry(mercury__middle_rec__generate_switch_9_0);
	init_label(mercury__middle_rec__generate_switch_9_0_i2);
	init_label(mercury__middle_rec__generate_switch_9_0_i3);
	init_label(mercury__middle_rec__generate_switch_9_0_i4);
	init_label(mercury__middle_rec__generate_switch_9_0_i5);
	init_label(mercury__middle_rec__generate_switch_9_0_i6);
	init_label(mercury__middle_rec__generate_switch_9_0_i7);
	init_label(mercury__middle_rec__generate_switch_9_0_i8);
	init_label(mercury__middle_rec__generate_switch_9_0_i9);
	init_label(mercury__middle_rec__generate_switch_9_0_i10);
	init_label(mercury__middle_rec__generate_switch_9_0_i11);
	init_label(mercury__middle_rec__generate_switch_9_0_i12);
	init_label(mercury__middle_rec__generate_switch_9_0_i13);
	init_label(mercury__middle_rec__generate_switch_9_0_i14);
	init_label(mercury__middle_rec__generate_switch_9_0_i15);
	init_label(mercury__middle_rec__generate_switch_9_0_i16);
	init_label(mercury__middle_rec__generate_switch_9_0_i17);
	init_label(mercury__middle_rec__generate_switch_9_0_i18);
	init_label(mercury__middle_rec__generate_switch_9_0_i19);
	init_label(mercury__middle_rec__generate_switch_9_0_i20);
	init_label(mercury__middle_rec__generate_switch_9_0_i21);
	init_label(mercury__middle_rec__generate_switch_9_0_i22);
	init_label(mercury__middle_rec__generate_switch_9_0_i23);
	init_label(mercury__middle_rec__generate_switch_9_0_i24);
	init_label(mercury__middle_rec__generate_switch_9_0_i25);
	init_label(mercury__middle_rec__generate_switch_9_0_i26);
	init_label(mercury__middle_rec__generate_switch_9_0_i27);
	init_label(mercury__middle_rec__generate_switch_9_0_i28);
	init_label(mercury__middle_rec__generate_switch_9_0_i29);
	init_label(mercury__middle_rec__generate_switch_9_0_i30);
	init_label(mercury__middle_rec__generate_switch_9_0_i31);
	init_label(mercury__middle_rec__generate_switch_9_0_i32);
	init_label(mercury__middle_rec__generate_switch_9_0_i33);
	init_label(mercury__middle_rec__generate_switch_9_0_i34);
	init_label(mercury__middle_rec__generate_switch_9_0_i35);
	init_label(mercury__middle_rec__generate_switch_9_0_i36);
	init_label(mercury__middle_rec__generate_switch_9_0_i37);
	init_label(mercury__middle_rec__generate_switch_9_0_i38);
	init_label(mercury__middle_rec__generate_switch_9_0_i39);
	init_label(mercury__middle_rec__generate_switch_9_0_i41);
	init_label(mercury__middle_rec__generate_switch_9_0_i42);
	init_label(mercury__middle_rec__generate_switch_9_0_i43);
	init_label(mercury__middle_rec__generate_switch_9_0_i44);
	init_label(mercury__middle_rec__generate_switch_9_0_i45);
	init_label(mercury__middle_rec__generate_switch_9_0_i46);
	init_label(mercury__middle_rec__generate_switch_9_0_i49);
	init_label(mercury__middle_rec__generate_switch_9_0_i1203);
	init_label(mercury__middle_rec__generate_switch_9_0_i1);
BEGIN_CODE

/* code for predicate 'generate_switch'/9 in mode 0 */
Define_static(mercury__middle_rec__generate_switch_9_0);
	MR_incr_sp_push_msg(19, "middle_rec:generate_switch/9");
	MR_stackvar(19) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r7;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__middle_rec__generate_switch_9_0_i2,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i2);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__middle_rec__generate_switch_9_0_i3,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i3);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_aux__explain_stack_slots_3_0),
		mercury__middle_rec__generate_switch_9_0_i4,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__middle_rec__generate_switch_9_0_i5,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i5);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__middle_rec__generate_switch_9_0_i6,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__middle_rec__generate_switch_9_0_i7,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i7);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	MR_stackvar(10) = r2;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(9);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_util__make_local_entry_label_5_0),
		mercury__middle_rec__generate_switch_9_0_i8,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = MR_stackvar(10);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(6);
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__pre_goal_update_4_0),
		mercury__middle_rec__generate_switch_9_0_i9,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__unify_gen__generate_tag_test_7_0),
		mercury__middle_rec__generate_switch_9_0_i10,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i11,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i11);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i12,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i12);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__middle_rec__generate_switch_9_0_i13,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i13);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__middle_rec__generate_switch_9_0_i14,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i14);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r2;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__middle_rec__generate_switch_9_0_i15,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i15);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(12) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__middle_rec__generate_switch_9_0_i16,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i16);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__middle_rec__generate_switch_9_0_i17,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i17);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__middle_rec__generate_switch_9_0_i18,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i18);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__post_goal_update_3_0),
		mercury__middle_rec__generate_switch_9_0_i19,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i19);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__after_all_branches_4_0),
		mercury__middle_rec__generate_switch_9_0_i20,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i20);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	call_localret(ENTRY(mercury__code_info__get_arginfo_3_0),
		mercury__middle_rec__generate_switch_9_0_i21,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i21);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_headvars_3_0),
		mercury__middle_rec__generate_switch_9_0_i22,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i22);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r4 = MR_stackvar(4);
	r3 = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0;
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__middle_rec__generate_switch_9_0_i23,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i23);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = MR_stackvar(4);
	r2 = (Integer) 1;
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__code_info__setup_call_5_0),
		mercury__middle_rec__generate_switch_9_0_i24,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i24);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(13) = r2;
	call_localret(ENTRY(mercury__code_util__output_args_2_0),
		mercury__middle_rec__generate_switch_9_0_i25,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i25);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 0) = r2;
	MR_stackvar(1) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(MR_stackvar(3), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), MR_stackvar(3), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_1);
	MR_field(MR_mktag(1), MR_stackvar(3), (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(12);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i26,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i26);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i27,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i27);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_1);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__tree__flatten_2_0),
		mercury__middle_rec__generate_switch_9_0_i28,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i28);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i29,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i29);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__opt_util__block_refers_stackvars_2_0),
		mercury__middle_rec__generate_switch_9_0_i30,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i30);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__middle_rec__generate_switch_9_0_i31,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i31);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	call_localret(STATIC(mercury__middle_rec__find_unused_register_2_0),
		mercury__middle_rec__generate_switch_9_0_i32,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i32);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__middle_rec__split_rec_code_3_0),
		mercury__middle_rec__generate_switch_9_0_i33,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i33);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(6) = r2;
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__middle_rec__add_counter_to_livevals_3_0),
		mercury__middle_rec__generate_switch_9_0_i34,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i34);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__middle_rec__generate_switch_9_0_i35,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i35);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(13) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__middle_rec__generate_switch_9_0_i36,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i36);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(14) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__middle_rec__generate_switch_9_0_i37,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i37);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	MR_stackvar(1) = r2;
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(13);
	call_localret(STATIC(mercury__middle_rec__generate_downloop_test_3_0),
		mercury__middle_rec__generate_switch_9_0_i38,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i38);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	if (((Integer) MR_stackvar(15) != (Integer) 0))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i39);
	MR_stackvar(16) = r1;
	r2 = MR_stackvar(5);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(8) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_4);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("initialize counter register", 27);
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	tag_incr_hp_msg(MR_stackvar(15), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__middle_rec__generate_switch_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_6);
	MR_field(MR_mktag(1), MR_stackvar(15), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("increment loop counter", 22);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r1;
	MR_field(MR_mktag(1), MR_stackvar(15), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	tag_incr_hp_msg(MR_stackvar(17), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__middle_rec__generate_switch_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_6);
	MR_field(MR_mktag(1), MR_stackvar(17), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("decrement loop counter", 22);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r1;
	MR_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	tag_incr_hp_msg(MR_stackvar(18), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__middle_rec__generate_switch_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 22;
	MR_field(MR_mktag(3), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_middle_rec__common_4);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("test on upward loop", 19);
	MR_field(MR_mktag(3), r4, (Integer) 2) = r1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i45);
Define_label(mercury__middle_rec__generate_switch_9_0_i39);
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_module__predicate_module_3_0),
		mercury__middle_rec__generate_switch_9_0_i41,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i41);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__middle_rec__generate_switch_9_0_i42,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i42);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r3 = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(8) = r3;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__middle_rec__generate_switch_9_0_i43,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i43);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(":", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__middle_rec__generate_switch_9_0_i44,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i44);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 16;
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(8), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 17;
	MR_field(MR_mktag(1), MR_stackvar(8), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), MR_stackvar(8), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(17) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_7);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("initialize counter register", 27);
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	tag_incr_hp_msg(MR_stackvar(18), MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_switch_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__middle_rec__generate_switch_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 22;
	MR_field(MR_mktag(3), r6, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_7);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("test on upward loop", 19);
	MR_field(MR_mktag(3), r5, (Integer) 2) = r1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i45);
	if (((Integer) MR_stackvar(6) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i46);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Procedure entry point", 21);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("start of the down loop", 22);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("start of base case", 18);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r9, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_middle_rec__common_11);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i1203,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i46);
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__middle_rec__find_labels_2_0),
		mercury__middle_rec__generate_switch_9_0_i49,
		STATIC(mercury__middle_rec__generate_switch_9_0));
Define_label(mercury__middle_rec__generate_switch_9_0_i49);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__generate_switch_9_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_0);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Procedure entry point", 21);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("start of the down loop", 22);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r12, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_stackvar(17);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r16, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r18, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_middle_rec__common_12);
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	tag_incr_hp_msg(r20, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r19, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r20, (Integer) 1) = (Word) MR_string_const("start of base case", 18);
	MR_field(MR_mktag(1), r17, (Integer) 0) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 0) = r20;
	MR_field(MR_mktag(0), r20, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "list:list/1");
	MR_field(MR_mktag(1), r18, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_switch_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r18, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_middle_rec__common_11);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__middle_rec__generate_switch_9_0_i1203,
		STATIC(mercury__middle_rec__generate_switch_9_0));
	}
Define_label(mercury__middle_rec__generate_switch_9_0_i1203);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_switch_9_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_switch_9_0, "tree:tree/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	r1 = TRUE;
	proceed();
Define_label(mercury__middle_rec__generate_switch_9_0_i1);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__code_util__neg_rval_2_0);

BEGIN_MODULE(middle_rec_module2)
	init_entry(mercury__middle_rec__generate_downloop_test_3_0);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i3);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i7);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i9);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i5);
	init_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
BEGIN_CODE

/* code for predicate 'generate_downloop_test'/3 in mode 0 */
Define_static(mercury__middle_rec__generate_downloop_test_3_0);
	MR_incr_sp_push_msg(3, "middle_rec:generate_downloop_test/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i3);
	r1 = (Word) MR_string_const("middle_rec__generate_downloop_test on empty list", 48);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i5);
	r4 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__generate_downloop_test_3_0_i7);
	MR_stackvar(1) = r2;
	r1 = r4;
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__middle_rec__generate_downloop_test_3_0_i11,
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i7);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	r1 = (Word) MR_string_const("middle_rec__generate_downloop_test: if_val followed by other instructions", 73);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__middle_rec__generate_downloop_test_3_0_i9,
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__middle_rec__generate_downloop_test_3_0_i11,
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i11);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_downloop_test_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__middle_rec__generate_downloop_test_3_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__middle_rec__generate_downloop_test_3_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__middle_rec__generate_downloop_test_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 2) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("test on downward loop", 21);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i5);
	MR_stackvar(1) = r4;
	r1 = r3;
	localcall(mercury__middle_rec__generate_downloop_test_3_0,
		LABEL(mercury__middle_rec__generate_downloop_test_3_0_i12),
		STATIC(mercury__middle_rec__generate_downloop_test_3_0));
Define_label(mercury__middle_rec__generate_downloop_test_3_0_i12);
	update_prof_current_proc(LABEL(mercury__middle_rec__generate_downloop_test_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__generate_downloop_test_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__skip_comments_2_0);

BEGIN_MODULE(middle_rec_module3)
	init_entry(mercury__middle_rec__split_rec_code_3_0);
	init_label(mercury__middle_rec__split_rec_code_3_0_i1007);
	init_label(mercury__middle_rec__split_rec_code_3_0_i8);
	init_label(mercury__middle_rec__split_rec_code_3_0_i7);
	init_label(mercury__middle_rec__split_rec_code_3_0_i5);
	init_label(mercury__middle_rec__split_rec_code_3_0_i13);
BEGIN_CODE

/* code for predicate 'split_rec_code'/3 in mode 0 */
Define_static(mercury__middle_rec__split_rec_code_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:split_rec_code/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i1007);
	r1 = (Word) MR_string_const("did not find call in middle_rec__split_rec_code", 47);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
Define_label(mercury__middle_rec__split_rec_code_3_0_i1007);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i5);
	r1 = r2;
	call_localret(ENTRY(mercury__opt_util__skip_comments_2_0),
		mercury__middle_rec__split_rec_code_3_0_i8,
		STATIC(mercury__middle_rec__split_rec_code_3_0));
	}
Define_label(mercury__middle_rec__split_rec_code_3_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__split_rec_code_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i7);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__middle_rec__split_rec_code_3_0_i7);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__split_rec_code_3_0_i7);
	r1 = (Word) MR_string_const("call not followed by label in middle_rec__split_rec_code", 56);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
Define_label(mercury__middle_rec__split_rec_code_3_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__middle_rec__split_rec_code_3_0,
		LABEL(mercury__middle_rec__split_rec_code_3_0_i13),
		STATIC(mercury__middle_rec__split_rec_code_3_0));
Define_label(mercury__middle_rec__split_rec_code_3_0_i13);
	update_prof_current_proc(LABEL(mercury__middle_rec__split_rec_code_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__split_rec_code_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__set__insert_3_1);

BEGIN_MODULE(middle_rec_module4)
	init_entry(mercury__middle_rec__add_counter_to_livevals_3_0);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i6);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
	init_label(mercury__middle_rec__add_counter_to_livevals_3_0_i3);
BEGIN_CODE

/* code for predicate 'add_counter_to_livevals'/3 in mode 0 */
Define_static(mercury__middle_rec__add_counter_to_livevals_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i3);
	MR_incr_sp_push_msg(4, "middle_rec:add_counter_to_livevals/3");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__middle_rec__add_counter_to_livevals_3_0_i6,
		STATIC(mercury__middle_rec__add_counter_to_livevals_3_0));
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__add_counter_to_livevals_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__middle_rec__add_counter_to_livevals_3_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__middle_rec__add_counter_to_livevals_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = MR_stackvar(3);
	localcall(mercury__middle_rec__add_counter_to_livevals_3_0,
		LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i8),
		STATIC(mercury__middle_rec__add_counter_to_livevals_3_0));
	}
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i4);
	r1 = r3;
	MR_stackvar(1) = r4;
	localcall(mercury__middle_rec__add_counter_to_livevals_3_0,
		LABEL(mercury__middle_rec__add_counter_to_livevals_3_0_i8),
		STATIC(mercury__middle_rec__add_counter_to_livevals_3_0));
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__add_counter_to_livevals_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__add_counter_to_livevals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__middle_rec__add_counter_to_livevals_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(middle_rec_module5)
	init_entry(mercury__middle_rec__find_unused_register_2_0);
	init_label(mercury__middle_rec__find_unused_register_2_0_i2);
	init_label(mercury__middle_rec__find_unused_register_2_0_i3);
	init_label(mercury__middle_rec__find_unused_register_2_0_i4);
BEGIN_CODE

/* code for predicate 'find_unused_register'/2 in mode 0 */
Define_static(mercury__middle_rec__find_unused_register_2_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_unused_register/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__middle_rec__find_unused_register_2_0_i2,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
Define_label(mercury__middle_rec__find_unused_register_2_0_i2);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_3_0),
		mercury__middle_rec__find_unused_register_2_0_i3,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
Define_label(mercury__middle_rec__find_unused_register_2_0_i3);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__middle_rec__find_unused_register_2_0_i4,
		STATIC(mercury__middle_rec__find_unused_register_2_0));
Define_label(mercury__middle_rec__find_unused_register_2_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_unused_register_2_0));
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_unused_register_2_3_0),
		STATIC(mercury__middle_rec__find_unused_register_2_0));
END_MODULE


BEGIN_MODULE(middle_rec_module6)
	init_entry(mercury__middle_rec__find_unused_register_2_3_0);
	init_label(mercury__middle_rec__find_unused_register_2_3_0_i1002);
	init_label(mercury__middle_rec__find_unused_register_2_3_0_i3);
	init_label(mercury__middle_rec__find_unused_register_2_3_0_i4);
BEGIN_CODE

/* code for predicate 'find_unused_register_2'/3 in mode 0 */
Define_static(mercury__middle_rec__find_unused_register_2_3_0);
	MR_incr_sp_push_msg(1, "middle_rec:find_unused_register_2/3");
	MR_stackvar(1) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_unused_register_2_3_0_i1002);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_unused_register_2_3_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__find_unused_register_2_3_0, "llds:lval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__middle_rec__find_unused_register_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 >= (Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0)))
		GOTO_LABEL(mercury__middle_rec__find_unused_register_2_3_0_i4);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__middle_rec__find_unused_register_2_3_0, "llds:lval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__middle_rec__find_unused_register_2_3_0_i4);
	r1 = r3;
	r2 = ((Integer) r2 + (Integer) 1);
	GOTO_LABEL(mercury__middle_rec__find_unused_register_2_3_0_i1002);
END_MODULE


BEGIN_MODULE(middle_rec_module7)
	init_entry(mercury__middle_rec__find_used_registers_3_0);
	init_label(mercury__middle_rec__find_used_registers_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_3_0_i4);
	init_label(mercury__middle_rec__find_used_registers_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_used_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_used_registers_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_instr_3_0),
		mercury__middle_rec__find_used_registers_3_0_i4,
		STATIC(mercury__middle_rec__find_used_registers_3_0));
Define_label(mercury__middle_rec__find_used_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_used_registers_3_0_i1001);
Define_label(mercury__middle_rec__find_used_registers_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module8)
	init_entry(mercury__middle_rec__find_used_registers_instr_3_0);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i6);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i9);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i10);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i12);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i24);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i25);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i41);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i45);
	init_label(mercury__middle_rec__find_used_registers_instr_3_0_i48);
BEGIN_CODE

/* code for predicate 'find_used_registers_instr'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_instr_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_instr/3");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i1002) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i6) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i9));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i6);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i7,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i7);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_instr_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lvals_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i10) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i12) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i24) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i37) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i41) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i45) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48) AND
		LABEL(mercury__middle_rec__find_used_registers_instr_3_0_i48));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i10);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i12);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i25,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i24);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_instr_3_0_i25,
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i25);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_instr_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i41);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_components_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i1002);
	r1 = r2;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i45);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_instr_3_0_i48);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_instr_3_0));
END_MODULE


BEGIN_MODULE(middle_rec_module9)
	init_entry(mercury__middle_rec__find_used_registers_components_3_0);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i1005);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i7);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i9);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i10);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i1004);
	init_label(mercury__middle_rec__find_used_registers_components_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_used_registers_components'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_components_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_components/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_components_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__middle_rec__find_used_registers_components_3_0_i1004) AND
		LABEL(mercury__middle_rec__find_used_registers_components_3_0_i7) AND
		LABEL(mercury__middle_rec__find_used_registers_components_3_0_i9) AND
		LABEL(mercury__middle_rec__find_used_registers_components_3_0_i1004));
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__insert_pragma_c_input_registers_3_0),
		mercury__middle_rec__find_used_registers_components_3_0_i10,
		STATIC(mercury__middle_rec__find_used_registers_components_3_0));
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__insert_pragma_c_output_registers_3_0),
		mercury__middle_rec__find_used_registers_components_3_0_i10,
		STATIC(mercury__middle_rec__find_used_registers_components_3_0));
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i10);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_components_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_used_registers_components_3_0_i1005);
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i1004);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_used_registers_components_3_0_i1005);
Define_label(mercury__middle_rec__find_used_registers_components_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module10)
	init_entry(mercury__middle_rec__find_used_registers_lvals_3_0);
	init_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
	init_label(mercury__middle_rec__find_used_registers_lvals_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_used_registers_lvals'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_lvals_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_lvals/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_used_registers_lvals_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lvals_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__find_used_registers_lvals_3_0_i4,
		STATIC(mercury__middle_rec__find_used_registers_lvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_lvals_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lvals_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_used_registers_lvals_3_0_i1001);
Define_label(mercury__middle_rec__find_used_registers_lvals_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__copy_2_1);
Declare_entry(mercury__set__insert_3_0);

BEGIN_MODULE(middle_rec_module11)
	init_entry(mercury__middle_rec__find_used_registers_lval_3_0);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i5);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i9);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i7);
	init_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
BEGIN_CODE

/* code for predicate 'find_used_registers_lval'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_lval_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_lval/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__copy_2_1),
		mercury__middle_rec__find_used_registers_lval_3_0_i5,
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i5);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lval_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__set__insert_3_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i7);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_lval/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__find_used_registers_lval_3_0_i9,
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i9);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_lval_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 9))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_lval_3_0_i11);
	r1 = (Word) MR_string_const("lvar found in middle_rec__find_used_registers_lval", 50);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__find_used_registers_lval_3_0));
Define_label(mercury__middle_rec__find_used_registers_lval_3_0_i11);
	r1 = r2;
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module12)
	init_entry(mercury__middle_rec__find_used_registers_rval_3_0);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i4);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i6);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i13);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i14);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i16);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i17);
	init_label(mercury__middle_rec__find_used_registers_rval_3_0_i19);
BEGIN_CODE

/* code for predicate 'find_used_registers_rval'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_rval_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_rval/3");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i4) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i6) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i8) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i10));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i6);
	r1 = (Word) MR_string_const("var found in middle_rec__find_used_registers_rval", 49);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i8);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i14) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i13) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i14) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i16) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i19));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i13);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i14);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i4) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i6) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i8) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i10));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i16);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__middle_rec__find_used_registers_rval_3_0,
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i17),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i17);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_rval_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i4) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i6) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i8) AND
		LABEL(mercury__middle_rec__find_used_registers_rval_3_0_i10));
Define_label(mercury__middle_rec__find_used_registers_rval_3_0_i19);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_mem_ref_3_0),
		STATIC(mercury__middle_rec__find_used_registers_rval_3_0));
END_MODULE


BEGIN_MODULE(middle_rec_module13)
	init_entry(mercury__middle_rec__find_used_registers_mem_ref_3_0);
	init_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i1001);
	init_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i5);
BEGIN_CODE

/* code for predicate 'find_used_registers_mem_ref'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_mem_ref_3_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_mem_ref_3_0_i1001);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_mem_ref_3_0_i5);
Define_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i1001);
	r1 = r2;
	proceed();
Define_label(mercury__middle_rec__find_used_registers_mem_ref_3_0_i5);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	tailcall(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		STATIC(mercury__middle_rec__find_used_registers_mem_ref_3_0));
END_MODULE


BEGIN_MODULE(middle_rec_module14)
	init_entry(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1002);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i5);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
	init_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_used_registers_maybe_rvals'/3 in mode 0 */
Define_static(mercury__middle_rec__find_used_registers_maybe_rvals_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_used_registers_maybe_rvals/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1002);
	while (1) {
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	/* continue */ } /* end while */
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6,
		STATIC(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i1002);
Define_label(mercury__middle_rec__find_used_registers_maybe_rvals_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module15)
	init_entry(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
	init_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1001);
	init_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
	init_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i3);
BEGIN_CODE

/* code for predicate 'insert_pragma_c_input_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__insert_pragma_c_input_registers_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:insert_pragma_c_input_registers/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_rval_3_0),
		mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4,
		STATIC(mercury__middle_rec__insert_pragma_c_input_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__insert_pragma_c_input_registers_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i1001);
Define_label(mercury__middle_rec__insert_pragma_c_input_registers_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module16)
	init_entry(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
	init_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1001);
	init_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
	init_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i3);
BEGIN_CODE

/* code for predicate 'insert_pragma_c_output_registers'/3 in mode 0 */
Define_static(mercury__middle_rec__insert_pragma_c_output_registers_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:insert_pragma_c_output_registers/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__middle_rec__find_used_registers_lval_3_0),
		mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4,
		STATIC(mercury__middle_rec__insert_pragma_c_output_registers_3_0));
Define_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__middle_rec__insert_pragma_c_output_registers_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i1001);
Define_label(mercury__middle_rec__insert_pragma_c_output_registers_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module17)
	init_entry(mercury__middle_rec__find_labels_2_0);
BEGIN_CODE

/* code for predicate 'find_labels'/2 in mode 0 */
Define_static(mercury__middle_rec__find_labels_2_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__middle_rec__find_labels_2_3_0),
		STATIC(mercury__middle_rec__find_labels_2_0));
END_MODULE


BEGIN_MODULE(middle_rec_module18)
	init_entry(mercury__middle_rec__find_labels_2_3_0);
	init_label(mercury__middle_rec__find_labels_2_3_0_i1003);
	init_label(mercury__middle_rec__find_labels_2_3_0_i4);
	init_label(mercury__middle_rec__find_labels_2_3_0_i8);
	init_label(mercury__middle_rec__find_labels_2_3_0_i6);
	init_label(mercury__middle_rec__find_labels_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_labels_2'/3 in mode 0 */
Define_static(mercury__middle_rec__find_labels_2_3_0);
	MR_incr_sp_push_msg(2, "middle_rec:find_labels_2/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__middle_rec__find_labels_2_3_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__middle_rec__find_labels_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r1 = r3;
	r2 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i1003);
	}
Define_label(mercury__middle_rec__find_labels_2_3_0_i4);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i6);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i6);
	MR_stackvar(1) = r3;
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	localcall(mercury__middle_rec__find_labels_2_3_0,
		LABEL(mercury__middle_rec__find_labels_2_3_0_i8),
		STATIC(mercury__middle_rec__find_labels_2_3_0));
Define_label(mercury__middle_rec__find_labels_2_3_0_i8);
	update_prof_current_proc(LABEL(mercury__middle_rec__find_labels_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i1003);
Define_label(mercury__middle_rec__find_labels_2_3_0_i6);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__middle_rec__find_labels_2_3_0_i1003);
Define_label(mercury__middle_rec__find_labels_2_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module19)
	init_entry(mercury____Unify___middle_rec__ite_rec_0_0);
	init_label(mercury____Unify___middle_rec__ite_rec_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___middle_rec__ite_rec_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___middle_rec__ite_rec_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___middle_rec__ite_rec_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(middle_rec_module20)
	init_entry(mercury____Index___middle_rec__ite_rec_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___middle_rec__ite_rec_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(middle_rec_module21)
	init_entry(mercury____Compare___middle_rec__ite_rec_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___middle_rec__ite_rec_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___middle_rec__ite_rec_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__middle_rec_maybe_bunch_0(void)
{
	middle_rec_module0();
	middle_rec_module1();
	middle_rec_module2();
	middle_rec_module3();
	middle_rec_module4();
	middle_rec_module5();
	middle_rec_module6();
	middle_rec_module7();
	middle_rec_module8();
	middle_rec_module9();
	middle_rec_module10();
	middle_rec_module11();
	middle_rec_module12();
	middle_rec_module13();
	middle_rec_module14();
	middle_rec_module15();
	middle_rec_module16();
	middle_rec_module17();
	middle_rec_module18();
	middle_rec_module19();
	middle_rec_module20();
	middle_rec_module21();
}

#endif

void mercury__middle_rec__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__middle_rec__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__middle_rec_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_middle_rec__type_ctor_info_ite_rec_0,
			middle_rec__ite_rec_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
