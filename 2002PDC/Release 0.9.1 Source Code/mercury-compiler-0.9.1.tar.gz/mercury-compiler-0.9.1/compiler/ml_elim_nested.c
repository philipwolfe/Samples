/*
** Automatically generated from `ml_elim_nested.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__ml_elim_nested__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___ml_elim_nested__elim_info_0__ua0_2_0);
Define_extern_entry(mercury__ml_elim_nested__ml_elim_nested_4_0);
Declare_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i2);
Declare_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i3);
Declare_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i4);
Declare_static(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i5);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i6);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i7);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i8);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i9);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i11);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i12);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i13);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i14);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i15);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
Declare_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1053);
Declare_static(mercury__ml_elim_nested__ml_maybe_add_args_6_0);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1006);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1032);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1034);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i14);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1036);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1038);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i8);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i19);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i20);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
Declare_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i3);
Declare_static(mercury__ml_elim_nested__ml_maybe_copy_args_6_0);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i4);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1025);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1027);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i15);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1029);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1031);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i9);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i20);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i21);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i3);
Declare_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i2);
Declare_static(mercury__ml_elim_nested__ml_create_env_7_0);
Declare_label(mercury__ml_elim_nested__ml_create_env_7_0_i2);
Declare_label(mercury__ml_elim_nested__ml_create_env_7_0_i3);
Declare_label(mercury__ml_elim_nested__ml_create_env_7_0_i4);
Declare_static(mercury__ml_elim_nested__ml_insert_init_env_4_0);
Declare_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i6);
Declare_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i8);
Declare_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i2);
Declare_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i1026);
Declare_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i3);
Declare_static(mercury__fn__ml_elim_nested__ml_env_name_1_0);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i6);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i10);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i9);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i13);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i11);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i8);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i19);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i17);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i21);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i23);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i24);
Declare_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i4);
Declare_static(mercury__ml_elim_nested__flatten_maybe_statement_4_0);
Declare_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i3);
Declare_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i4);
Declare_static(mercury__ml_elim_nested__flatten_statement_4_0);
Declare_label(mercury__ml_elim_nested__flatten_statement_4_0_i2);
Declare_static(mercury__ml_elim_nested__flatten_stmt_4_0);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i4);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i5);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i6);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i7);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i8);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i9);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i10);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i11);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i12);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i13);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i14);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i17);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i18);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i19);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i20);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i22);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i23);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i24);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i25);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i26);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i27);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i28);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i29);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i30);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i31);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i32);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i33);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i34);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i35);
Declare_label(mercury__ml_elim_nested__flatten_stmt_4_0_i2);
Declare_static(mercury__ml_elim_nested__flatten_nested_defns_5_0);
Declare_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i4);
Declare_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i5);
Declare_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i6);
Declare_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i3);
Declare_static(mercury__ml_elim_nested__flatten_nested_defn_6_0);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1025);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1027);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i19);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1029);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1031);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i13);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i24);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i4);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i6);
Declare_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i7);
Declare_static(mercury__ml_elim_nested__fixup_atomic_stmt_4_0);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i5);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i6);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i7);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i8);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i9);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i10);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i11);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i19);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i20);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i21);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i22);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i23);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i24);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i26);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i25);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i27);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i14);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i15);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i12);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i13);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i1016);
Declare_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i2);
Declare_static(mercury__ml_elim_nested__fixup_rvals_4_0);
Declare_label(mercury__ml_elim_nested__fixup_rvals_4_0_i4);
Declare_label(mercury__ml_elim_nested__fixup_rvals_4_0_i5);
Declare_label(mercury__ml_elim_nested__fixup_rvals_4_0_i3);
Declare_static(mercury__ml_elim_nested__fixup_rval_4_0);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i4);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i5);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i6);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i7);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i9);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i11);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i10);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i13);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i14);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i12);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i15);
Declare_label(mercury__ml_elim_nested__fixup_rval_4_0_i1009);
Declare_static(mercury__ml_elim_nested__fixup_lvals_4_0);
Declare_label(mercury__ml_elim_nested__fixup_lvals_4_0_i4);
Declare_label(mercury__ml_elim_nested__fixup_lvals_4_0_i5);
Declare_label(mercury__ml_elim_nested__fixup_lvals_4_0_i3);
Declare_static(mercury__ml_elim_nested__fixup_lval_4_0);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i18);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i6);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i11);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i1023);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i9);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i1035);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i4);
Declare_label(mercury__ml_elim_nested__fixup_lval_4_0_i5);
Declare_static(mercury__ml_elim_nested__defn_contains_defn_2_0);
Declare_label(mercury__ml_elim_nested__defn_contains_defn_2_0_i2);
Declare_static(mercury__ml_elim_nested__defn_body_contains_defn_2_0);
Declare_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i2);
Declare_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i5);
Declare_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i4);
Declare_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i1);
Declare_static(mercury__ml_elim_nested__maybe_statement_contains_defn_2_0);
Declare_static(mercury__ml_elim_nested__statement_contains_defn_2_0);
Declare_static(mercury__ml_elim_nested__stmt_contains_defn_2_0);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i3);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i6);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1027);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i8);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i10);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i12);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1035);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i18);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i19);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1045);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2);
Declare_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1);
Declare_static(mercury__ml_elim_nested__defn_contains_var_2_0);
Declare_static(mercury__ml_elim_nested__defn_body_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i15);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1029);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i7);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i9);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1037);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1043);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i4);
Declare_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1023);
Declare_static(mercury__ml_elim_nested__maybe_statement_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__maybe_statement_contains_var_2_0_i1);
Declare_static(mercury__ml_elim_nested__statement_contains_var_2_0);
Declare_static(mercury__ml_elim_nested__stmt_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i4);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i10);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1122);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i8);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i15);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1132);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i19);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i23);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i27);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i31);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i34);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i39);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i43);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i47);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i52);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i50);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i58);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1147);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i56);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i63);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1159);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i69);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1161);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i66);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1163);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i75);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i77);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1167);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i81);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i93);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i90);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i91);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i87);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i88);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i83);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i96);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i100);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i103);
Declare_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1);
Declare_static(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i78);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i75);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i76);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i72);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i73);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i68);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i81);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1120);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1126);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i50);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i62);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i59);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i60);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1081);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i56);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i57);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i52);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i4);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1087);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i36);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i22);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1092);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i29);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i26);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i5);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1094);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i11);
Declare_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
Declare_static(mercury__ml_elim_nested__rval_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1017);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i18);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i4);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i5);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i12);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i8);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1010);
Declare_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1);
Declare_static(mercury__ml_elim_nested__lval_contains_var_2_0);
Declare_label(mercury__ml_elim_nested__lval_contains_var_2_0_i7);
Declare_label(mercury__ml_elim_nested__lval_contains_var_2_0_i4);
Declare_static(mercury____Unify___ml_elim_nested__elim_info_0_0);
Declare_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i2);
Declare_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i4);
Declare_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i6);
Declare_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
Declare_static(mercury____Index___ml_elim_nested__elim_info_0_0);
Declare_static(mercury____Compare___ml_elim_nested__elim_info_0_0);
Declare_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i3);
Declare_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i7);
Declare_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i11);
Declare_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
Declare_static(mercury____Unify___ml_elim_nested__outervars_0_0);
Declare_static(mercury____Index___ml_elim_nested__outervars_0_0);
Declare_static(mercury____Compare___ml_elim_nested__outervars_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_ml_elim_nested__type_ctor_info_elim_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_ml_elim_nested__type_ctor_info_outervars_0;

static const struct mercury_data_ml_elim_nested__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_ml_elim_nested__common_0;

static const struct mercury_data_ml_elim_nested__common_1_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_1;

static const struct mercury_data_ml_elim_nested__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_ml_elim_nested__common_2;

static const struct mercury_data_ml_elim_nested__common_3_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_3;

static const struct mercury_data_ml_elim_nested__common_4_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_ml_elim_nested__common_4;

static const struct mercury_data_ml_elim_nested__common_5_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_5;

static const struct mercury_data_ml_elim_nested__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_ml_elim_nested__common_6;

static const struct mercury_data_ml_elim_nested__common_7_struct {
	Integer f1;
}  mercury_data_ml_elim_nested__common_7;

static const struct mercury_data_ml_elim_nested__common_8_struct {
	String f1;
}  mercury_data_ml_elim_nested__common_8;

static const struct mercury_data_ml_elim_nested__common_9_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_9;

static const struct mercury_data_ml_elim_nested__common_10_struct {
	String f1;
}  mercury_data_ml_elim_nested__common_10;

static const struct mercury_data_ml_elim_nested__common_11_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_11;

static const struct mercury_data_ml_elim_nested__common_12_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_12;

static const struct mercury_data_ml_elim_nested__common_13_struct {
	Word * f1;
}  mercury_data_ml_elim_nested__common_13;

static const struct mercury_data_ml_elim_nested__common_14_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_ml_elim_nested__common_14;

static const struct mercury_data_ml_elim_nested__common_15_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_ml_elim_nested__common_15;

static const struct mercury_data_ml_elim_nested__common_16_struct {
	Integer f1;
	Word * f2;
}  mercury_data_ml_elim_nested__common_16;

static const struct mercury_data_ml_elim_nested__common_17_struct {
	Integer f1;
	Word * f2;
}  mercury_data_ml_elim_nested__common_17;

static const struct mercury_data_ml_elim_nested__common_18_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_ml_elim_nested__common_18;

static const struct mercury_data_ml_elim_nested__type_ctor_functors_outervars_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_ml_elim_nested__type_ctor_functors_outervars_0;

static const struct mercury_data_ml_elim_nested__type_ctor_layout_outervars_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_ml_elim_nested__type_ctor_layout_outervars_0;

static const struct mercury_data_ml_elim_nested__type_ctor_functors_elim_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_ml_elim_nested__type_ctor_functors_elim_info_0;

static const struct mercury_data_ml_elim_nested__type_ctor_layout_elim_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_ml_elim_nested__type_ctor_layout_elim_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_ml_elim_nested__type_ctor_info_elim_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___ml_elim_nested__elim_info_0_0),
	STATIC(mercury____Index___ml_elim_nested__elim_info_0_0),
	STATIC(mercury____Compare___ml_elim_nested__elim_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_ml_elim_nested__type_ctor_functors_elim_info_0,
	(Word *) &mercury_data_ml_elim_nested__type_ctor_layout_elim_info_0,
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("elim_info", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_ml_elim_nested__type_ctor_info_outervars_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___ml_elim_nested__outervars_0_0),
	STATIC(mercury____Index___ml_elim_nested__outervars_0_0),
	STATIC(mercury____Compare___ml_elim_nested__outervars_0_0),
	(Integer) 6,
	(Word *) &mercury_data_ml_elim_nested__type_ctor_functors_outervars_0,
	(Word *) &mercury_data_ml_elim_nested__type_ctor_layout_outervars_0,
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("outervars", 9),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_mlds__type_ctor_info_defn_0;
static const struct mercury_data_ml_elim_nested__common_0_struct mercury_data_ml_elim_nested__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_mlds__type_ctor_info_defn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_mlds__type_ctor_info_mlds_module_name_0;
static const struct mercury_data_ml_elim_nested__common_1_struct mercury_data_ml_elim_nested__common_1 = {
	(Word *) &mercury_data_mlds__type_ctor_info_mlds_module_name_0
};

static const struct mercury_data_ml_elim_nested__common_2_struct mercury_data_ml_elim_nested__common_2 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0)
};

static const struct mercury_data_ml_elim_nested__common_3_struct mercury_data_ml_elim_nested__common_3 = {
	(Word *) &mercury_data_mlds__type_ctor_info_defn_0
};

static const struct mercury_data_ml_elim_nested__common_4_struct mercury_data_ml_elim_nested__common_4 = {
	(Integer) 1,
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("ml_elim_nested_defns", 20),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_ml_elim_nested__common_5_struct mercury_data_ml_elim_nested__common_5 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_ml_elim_nested__common_6_struct mercury_data_ml_elim_nested__common_6 = {
	(Integer) 0,
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("ml_insert_init_env", 18),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_3)
};

static const struct mercury_data_ml_elim_nested__common_7_struct mercury_data_ml_elim_nested__common_7 = {
	(Integer) 0
};

static const struct mercury_data_ml_elim_nested__common_8_struct mercury_data_ml_elim_nested__common_8 = {
	MR_string_const("env", 3)
};

static const struct mercury_data_ml_elim_nested__common_9_struct mercury_data_ml_elim_nested__common_9 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_8)
};

static const struct mercury_data_ml_elim_nested__common_10_struct mercury_data_ml_elim_nested__common_10 = {
	MR_string_const("env_ptr", 7)
};

static const struct mercury_data_ml_elim_nested__common_11_struct mercury_data_ml_elim_nested__common_11 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_10)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_mlds__type_ctor_info_statement_0;
static const struct mercury_data_ml_elim_nested__common_12_struct mercury_data_ml_elim_nested__common_12 = {
	(Word *) &mercury_data_mlds__type_ctor_info_statement_0
};

static const struct mercury_data_ml_elim_nested__common_13_struct mercury_data_ml_elim_nested__common_13 = {
	(Word *) &mercury_data_ml_elim_nested__type_ctor_info_elim_info_0
};

static const struct mercury_data_ml_elim_nested__common_14_struct mercury_data_ml_elim_nested__common_14 = {
	(Integer) 0,
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("ml_elim_nested", 14),
	MR_string_const("flatten_statement", 17),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_13)
};

static const struct mercury_data_ml_elim_nested__common_15_struct mercury_data_ml_elim_nested__common_15 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_14),
	STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
	(Integer) 0
};

static const struct mercury_data_ml_elim_nested__common_16_struct mercury_data_ml_elim_nested__common_16 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_ml_elim_nested__common_17_struct mercury_data_ml_elim_nested__common_17 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_2)
};

static const struct mercury_data_ml_elim_nested__common_18_struct mercury_data_ml_elim_nested__common_18 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0),
	MR_string_const("elim_info", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_ml_elim_nested__type_ctor_functors_outervars_0_struct mercury_data_ml_elim_nested__type_ctor_functors_outervars_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_2)
};

static const struct mercury_data_ml_elim_nested__type_ctor_layout_outervars_0_struct mercury_data_ml_elim_nested__type_ctor_layout_outervars_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_ml_elim_nested__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_ml_elim_nested__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_ml_elim_nested__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_ml_elim_nested__common_17)
};

static const struct mercury_data_ml_elim_nested__type_ctor_functors_elim_info_0_struct mercury_data_ml_elim_nested__type_ctor_functors_elim_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_18)
};

static const struct mercury_data_ml_elim_nested__type_ctor_layout_elim_info_0_struct mercury_data_ml_elim_nested__type_ctor_layout_elim_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_18),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(ml_elim_nested_module0)
	init_entry(mercury____Index___ml_elim_nested__elim_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___ml_elim_nested__elim_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___ml_elim_nested__elim_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__fn__mlds__mercury_module_name_to_mlds_1_0);
Declare_entry(mercury__fn__list__map_2_0);
Declare_entry(mercury__fn__list__condense_1_0);

BEGIN_MODULE(ml_elim_nested_module1)
	init_entry(mercury__ml_elim_nested__ml_elim_nested_4_0);
	init_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i2);
	init_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i3);
	init_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i4);
BEGIN_CODE

/* code for predicate 'ml_elim_nested'/4 in mode 0 */
Define_entry(mercury__ml_elim_nested__ml_elim_nested_4_0);
	MR_incr_sp_push_msg(6, "ml_elim_nested:ml_elim_nested/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__fn__mlds__mercury_module_name_to_mlds_1_0),
		mercury__ml_elim_nested__ml_elim_nested_4_0_i2,
		ENTRY(mercury__ml_elim_nested__ml_elim_nested_4_0));
Define_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_elim_nested_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__ml_elim_nested__ml_elim_nested_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	r4 = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_4);
	call_localret(ENTRY(mercury__fn__list__map_2_0),
		mercury__ml_elim_nested__ml_elim_nested_4_0_i3,
		ENTRY(mercury__ml_elim_nested__ml_elim_nested_4_0));
Define_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i3);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_elim_nested_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__fn__list__condense_1_0),
		mercury__ml_elim_nested__ml_elim_nested_4_0_i4,
		ENTRY(mercury__ml_elim_nested__ml_elim_nested_4_0));
Define_label(mercury__ml_elim_nested__ml_elim_nested_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_elim_nested_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_elim_nested_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__fn__list__reverse_1_0);
Declare_entry(mercury__fn__list__append_2_0);
Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(ml_elim_nested_module2)
	init_entry(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i5);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i6);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i7);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i8);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i9);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i11);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i12);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i13);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i14);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i15);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
	init_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1053);
BEGIN_CODE

/* code for predicate 'ml_elim_nested_defns'/4 in mode 0 */
Define_static(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1053);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1053);
	MR_incr_sp_push_msg(11, "ml_elim_nested:ml_elim_nested_defns/4");
	MR_stackvar(11) = (Word) MR_succip;
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 2), (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_tempr4 = r4;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 4, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr4, (Integer) 0);
	MR_stackvar(6) = MR_tempr2;
	r2 = MR_tempr1;
	MR_stackvar(7) = MR_tempr1;
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r1;
	MR_stackvar(3) = r4;
	MR_stackvar(8) = MR_tempr3;
	r1 = MR_tempr3;
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r5, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i5,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i5);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r2 = r1;
	r3 = MR_stackvar(7);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_stmt_4_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i6,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i6);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r3 = MR_stackvar(9);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__fn__list__reverse_1_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i7,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i7);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r2 = MR_stackvar(10);
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__fn__list__reverse_1_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i8,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i8);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	if (((Integer) MR_stackvar(10) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i9);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 4, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 3, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:entity_defn/0");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(11);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r4, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r4;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__fn__list__append_2_0),
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i9);
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i11,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i11);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r1 = MR_stackvar(2);
	MR_stackvar(8) = r2;
	call_localret(STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i12,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i12);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__ml_create_env_7_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i13,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i13);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(10);
	MR_stackvar(1) = r1;
	MR_stackvar(7) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_stackvar(10) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_6);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__ml_elim_nested__ml_insert_init_env_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 4) = r4;
	r4 = r6;
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i14,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i14);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	r4 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__fn__list__append_2_0),
		mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i15,
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i15);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	if (((Integer) MR_stackvar(7) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 3, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:entity_defn/0");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 3) = r5;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__fn__list__append_2_0),
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1046);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 3, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:entity_defn/0");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(6);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "mlds:statement/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r4, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r7, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury__fn__list__append_2_0),
		STATIC(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0_i1053);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_elim_nested_defns_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(do_redo);
Declare_entry(mercury__fn__mlds__init_decl_flags_6_0);

BEGIN_MODULE(ml_elim_nested_module3)
	init_entry(mercury__ml_elim_nested__ml_maybe_add_args_6_0);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1006);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1032);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1034);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i14);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1036);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1038);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i8);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i19);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i20);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
	init_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i3);
BEGIN_CODE

/* code for predicate 'ml_maybe_add_args'/6 in mode 0 */
Define_static(mercury__ml_elim_nested__ml_maybe_add_args_6_0);
	MR_incr_sp_push_msg(14, "ml_elim_nested:ml_maybe_add_args/6");
	MR_stackvar(14) = (Word) MR_succip;
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1006);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i3);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r7 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(r7) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(1), r7, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
	MR_stackvar(9) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(10) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(11) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i8);
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "mlds:fully_qualified_name/1");
	MR_field(MR_mktag(0), r8, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r7, (Integer) 0), (Integer) 0);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r10 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(12) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(13) = (Word) MR_redofr_slot(MR_maxfr);
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1034);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r10;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1032,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1032);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1038,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1034);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(12);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(13);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i14,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i14);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	call_localret(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1036,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1036);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1038,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1038);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(11);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i19);
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i8);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i19);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Integer) 0;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_maybe_add_args_6_0_i20,
		STATIC(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	}
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i20);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0));
	r6 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r8, (Integer) 1) = r4;
	MR_field(MR_mktag(0), r8, (Integer) 2) = r6;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_add_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 3);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r5, (Integer) 3) = r7;
	MR_field(MR_mktag(0), r8, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(14);
	GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1006);
	}
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i5);
	r1 = r6;
	MR_succip = (Code *) MR_stackvar(14);
	GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i1006);
Define_label(mercury__ml_elim_nested__ml_maybe_add_args_6_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module4)
	init_entry(mercury__ml_elim_nested__ml_maybe_copy_args_6_0);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i4);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1025);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1027);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i15);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1029);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1031);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i9);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i20);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i21);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i3);
	init_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i2);
BEGIN_CODE

/* code for predicate 'ml_maybe_copy_args'/6 in mode 0 */
Define_static(mercury__ml_elim_nested__ml_maybe_copy_args_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i3);
	MR_incr_sp_push_msg(14, "ml_elim_nested:ml_maybe_copy_args/6");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	localcall(mercury__ml_elim_nested__ml_maybe_copy_args_6_0,
		LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i4),
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(1), r3, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i2);
	MR_stackvar(9) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(10) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(11) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i9);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:fully_qualified_name/1");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	MR_stackvar(12) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(13) = (Word) MR_redofr_slot(MR_maxfr);
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1027);
	MR_stackvar(1) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r5;
	MR_stackvar(8) = r4;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1025,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1025);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1031,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1027);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(12);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(13);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i15,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i15);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	call_localret(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1029,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1029);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1031,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i1031);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(11);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	GOTO_LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i20);
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i9);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i20);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Integer) 0;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i21,
		STATIC(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	}
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i21);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_maybe_copy_args_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:statement/0");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 7;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:atomic_statement/0");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 3, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:lval/0");
	MR_field(MR_mktag(0), r7, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_7);
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 1, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:rval/0");
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:lval/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("env_ptr", 7);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(2), r9, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:field_id/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r7, (Integer) 2) = r8;
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 1, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:rval/0");
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "mlds:lval/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_maybe_copy_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r8, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__ml_elim_nested__ml_maybe_copy_args_6_0_i2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module5)
	init_entry(mercury__ml_elim_nested__ml_create_env_7_0);
	init_label(mercury__ml_elim_nested__ml_create_env_7_0_i2);
	init_label(mercury__ml_elim_nested__ml_create_env_7_0_i3);
	init_label(mercury__ml_elim_nested__ml_create_env_7_0_i4);
BEGIN_CODE

/* code for predicate 'ml_create_env'/7 in mode 0 */
Define_static(mercury__ml_elim_nested__ml_create_env_7_0);
	MR_incr_sp_push_msg(8, "ml_elim_nested:ml_create_env/7");
	MR_stackvar(8) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = (Integer) 0;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Integer) 0;
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_create_env_7_0_i2,
		STATIC(mercury__ml_elim_nested__ml_create_env_7_0));
	}
Define_label(mercury__ml_elim_nested__ml_create_env_7_0_i2);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_create_env_7_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:entity_defn/0");
	r1 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_9);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 5, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Integer) 1;
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(2), (Integer) 3) = r3;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_create_env_7_0_i3,
		STATIC(mercury__ml_elim_nested__ml_create_env_7_0));
	}
Define_label(mercury__ml_elim_nested__ml_create_env_7_0_i3);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_create_env_7_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_9);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:entity_defn/0");
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:type/0");
	MR_field(MR_mktag(2), r4, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 3) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:lval/0");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("env", 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_stackvar(5), (Integer) 1) = r3;
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(2), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:type/0");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_stackvar(6), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	r1 = (Integer) 0;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_11);
	MR_field(MR_mktag(2), MR_stackvar(6), (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_create_env_7_0_i4,
		STATIC(mercury__ml_elim_nested__ml_create_env_7_0));
	}
Define_label(mercury__ml_elim_nested__ml_create_env_7_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_create_env_7_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_11);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 2) = r3;
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:entity_defn/0");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 3) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:statement/0");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 7;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:atomic_statement/0");
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_create_env_7_0, "mlds:lval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_create_env_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("env_ptr", 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE


BEGIN_MODULE(ml_elim_nested_module6)
	init_entry(mercury__ml_elim_nested__ml_insert_init_env_4_0);
	init_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i6);
	init_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i8);
	init_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i2);
	init_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i1026);
	init_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i3);
BEGIN_CODE

/* code for predicate 'ml_insert_init_env'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__ml_insert_init_env_4_0);
	MR_incr_sp_push_msg(12, "ml_elim_nested:ml_insert_init_env/4");
	MR_stackvar(12) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0_i1026);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0_i1026);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 2), (Integer) 0);
	r5 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 0);
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:fully_qualified_name/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) MR_string_const("env_ptr", 7);
	call_localret(STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0),
		mercury__ml_elim_nested__ml_insert_init_env_4_0_i6,
		STATIC(mercury__ml_elim_nested__ml_insert_init_env_4_0));
Define_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i6);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0_i2);
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 1, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:rval/0");
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:lval/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:fully_qualified_name/1");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("env_ptr_arg", 11);
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = r2;
	tag_incr_hp_msg(MR_stackvar(10), MR_mktag(2), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:type/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_stackvar(10), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Integer) 0;
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = (Integer) 0;
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_11);
	MR_field(MR_mktag(2), MR_stackvar(10), (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__fn__mlds__init_decl_flags_6_0),
		mercury__ml_elim_nested__ml_insert_init_env_4_0_i8,
		STATIC(mercury__ml_elim_nested__ml_insert_init_env_4_0));
	}
Define_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i8);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:entity_defn/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(8);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__ml_insert_init_env_4_0, "std_util:maybe/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:statement/0");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:stmt/0");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r8, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_11);
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r8, (Integer) 2) = r2;
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:entity_defn/0");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r8, (Integer) 3) = r9;
	MR_field(MR_mktag(0), r9, (Integer) 0) = r2;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:statement/0");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 7;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:atomic_statement/0");
	tag_incr_hp_msg(r11, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__ml_insert_init_env_4_0, "mlds:lval/0");
	MR_field(MR_mktag(1), r10, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) MR_string_const("env_ptr", 7);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(3), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(2), r11, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__ml_insert_init_env_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 1) = r7;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i2);
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__ml_elim_nested__ml_insert_init_env_4_0_i3);
Define_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i1026);
	r1 = r3;
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__ml_elim_nested__ml_insert_init_env_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__prog_out__sym_name_to_string_3_0);
Declare_entry(mercury__string__format_3_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);

BEGIN_MODULE(ml_elim_nested_module7)
	init_entry(mercury__fn__ml_elim_nested__ml_env_name_1_0);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i6);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i10);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i9);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i13);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i11);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i8);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i19);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i17);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i21);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i23);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i24);
	init_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i4);
BEGIN_CODE

/* code for predicate 'ml_env_name'/2 in mode 0 */
Define_static(mercury__fn__ml_elim_nested__ml_env_name_1_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i4);
	MR_incr_sp_push_msg(6, "ml_elim_nested:ml_env_name/2");
	MR_stackvar(6) = (Word) MR_succip;
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i6);
	r1 = (Word) MR_string_const("ml_env_name: expected function, got type", 40);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i6);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i8);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i10);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = (Word) MR_string_const("p", 1);
	GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i9);
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i10);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = (Word) MR_string_const("f", 1);
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i9);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i11);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const("__", 2);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i13,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i13);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_string_const("%s_%d_%s_in__%s", 15);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i21,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i11);
	r1 = (Word) MR_string_const("%s_%d_%s", 8);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "string:poly_type/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i21,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i8);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 3);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 2);
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0);
	r5 = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r6 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i17);
	MR_stackvar(5) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 1), (Integer) 0);
	r2 = (Word) MR_string_const("__", 2);
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i19,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i19);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	r3 = r1;
	r1 = (Word) MR_string_const("%s__%s__%s_%d", 13);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i21,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i17);
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	r1 = (Word) MR_string_const("%s__%s_%d", 9);
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i21,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i21);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__fn__ml_elim_nested__ml_env_name_1_0_i23,
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i23);
	update_prof_current_proc(LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__fn__ml_elim_nested__ml_env_name_1_0_i24);
	r3 = r1;
	r1 = (Word) MR_string_const("%s_%d_%d_env", 12);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__string__format_3_0),
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i24);
	r3 = r1;
	r1 = (Word) MR_string_const("%s_%d_env", 9);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__fn__ml_elim_nested__ml_env_name_1_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__fn__ml_elim_nested__ml_env_name_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__string__format_3_0),
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
	}
Define_label(mercury__fn__ml_elim_nested__ml_env_name_1_0_i4);
	r1 = (Word) MR_string_const("ml_env_name: expected function, got data", 40);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__fn__ml_elim_nested__ml_env_name_1_0));
END_MODULE


BEGIN_MODULE(ml_elim_nested_module8)
	init_entry(mercury__ml_elim_nested__flatten_maybe_statement_4_0);
	init_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i3);
	init_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i4);
BEGIN_CODE

/* code for predicate 'flatten_maybe_statement'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__flatten_maybe_statement_4_0);
	MR_incr_sp_push_msg(1, "ml_elim_nested:flatten_maybe_statement/4");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
		mercury__ml_elim_nested__flatten_maybe_statement_4_0_i4,
		STATIC(mercury__ml_elim_nested__flatten_maybe_statement_4_0));
Define_label(mercury__ml_elim_nested__flatten_maybe_statement_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_maybe_statement_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__flatten_maybe_statement_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module9)
	init_entry(mercury__ml_elim_nested__flatten_statement_4_0);
	init_label(mercury__ml_elim_nested__flatten_statement_4_0_i2);
BEGIN_CODE

/* code for predicate 'flatten_statement'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__flatten_statement_4_0);
	MR_incr_sp_push_msg(2, "ml_elim_nested:flatten_statement/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_stmt_4_0),
		mercury__ml_elim_nested__flatten_statement_4_0_i2,
		STATIC(mercury__ml_elim_nested__flatten_statement_4_0));
Define_label(mercury__ml_elim_nested__flatten_statement_4_0_i2);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_statement_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__flatten_statement_4_0, "mlds:statement/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__map_foldl_5_1);

BEGIN_MODULE(ml_elim_nested_module10)
	init_entry(mercury__ml_elim_nested__flatten_stmt_4_0);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i4);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i5);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i6);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i7);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i8);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i9);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i10);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i11);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i12);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i13);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i14);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i17);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i18);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i19);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i20);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i22);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i23);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i24);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i25);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i26);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i27);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i28);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i29);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i30);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i31);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i32);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i33);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i34);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i35);
	init_label(mercury__ml_elim_nested__flatten_stmt_4_0_i2);
BEGIN_CODE

/* code for predicate 'flatten_stmt'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__flatten_stmt_4_0);
	MR_incr_sp_push_msg(6, "ml_elim_nested:flatten_stmt/4");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i4) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i7) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i10) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i14));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i4);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_nested_defns_5_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i5,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r5 = MR_stackvar(1);
	r6 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r3 = (Word) (Word *) &mercury_data_ml_elim_nested__type_ctor_info_elim_info_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_15);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__ml_elim_nested__flatten_stmt_4_0_i6,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i6);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i8,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i8);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i9,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i9);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 3, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i11,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i11);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	localcall(mercury__ml_elim_nested__flatten_stmt_4_0,
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i12),
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i12);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__flatten_stmt_4_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_maybe_statement_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i13,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
	}
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i13);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 3, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), r1, (Integer) 2) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i2) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i2) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i17) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i19) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i26) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i28) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i32) AND
		LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i34));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i17);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i18,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i18);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i19);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i20,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i20);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_stmt_4_0_i22);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rvals_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i24,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i22);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i23,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i23);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__flatten_stmt_4_0, "origin_lost_in_value_number");
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rvals_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i24,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
	}
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i24);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lvals_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i25,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i25);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 7, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), r1, (Integer) 5) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 6) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i26);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rvals_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i27,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i27);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i28);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i29,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i29);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i30,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i30);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i31,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i31);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i32);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i33,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i33);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i34);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0),
		mercury__ml_elim_nested__flatten_stmt_4_0_i35,
		STATIC(mercury__ml_elim_nested__flatten_stmt_4_0));
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i35);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__flatten_stmt_4_0, "mlds:stmt/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_stmt_4_0_i2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module11)
	init_entry(mercury__ml_elim_nested__flatten_nested_defns_5_0);
	init_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i4);
	init_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i5);
	init_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i6);
	init_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i3);
BEGIN_CODE

/* code for predicate 'flatten_nested_defns'/5 in mode 0 */
Define_static(mercury__ml_elim_nested__flatten_nested_defns_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defns_5_0_i3);
	MR_incr_sp_push_msg(3, "ml_elim_nested:flatten_nested_defns/5");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0),
		mercury__ml_elim_nested__flatten_nested_defns_5_0_i4,
		STATIC(mercury__ml_elim_nested__flatten_nested_defns_5_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defns_5_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__ml_elim_nested__flatten_nested_defns_5_0,
		LABEL(mercury__ml_elim_nested__flatten_nested_defns_5_0_i5),
		STATIC(mercury__ml_elim_nested__flatten_nested_defns_5_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defns_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__fn__list__append_2_0),
		mercury__ml_elim_nested__flatten_nested_defns_5_0_i6,
		STATIC(mercury__ml_elim_nested__flatten_nested_defns_5_0));
	}
Define_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i6);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defns_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_nested_defns_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module12)
	init_entry(mercury__ml_elim_nested__flatten_nested_defn_6_0);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1025);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1027);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i19);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1029);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1031);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i13);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i24);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i4);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i6);
	init_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i7);
BEGIN_CODE

/* code for predicate 'flatten_nested_defn'/6 in mode 0 */
Define_static(mercury__ml_elim_nested__flatten_nested_defn_6_0);
	MR_incr_sp_push_msg(11, "ml_elim_nested:flatten_nested_defn/6");
	MR_stackvar(11) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	if ((MR_tag(r5) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i4);
	if ((MR_tag(r5) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
	if ((MR_tag(MR_const_field(MR_mktag(1), r5, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
	MR_stackvar(6) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i13);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__flatten_nested_defn_6_0, "mlds:fully_qualified_name/1");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r5, (Integer) 0), (Integer) 0);
	MR_stackvar(9) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(10) = (Word) MR_redofr_slot(MR_maxfr);
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1027);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i1025,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1025);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i1031,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1027);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i19,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i19);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	call_localret(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i1029,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1029);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 3)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i1031,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i1031);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(8);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i24);
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i13);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	r1 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i24);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__flatten_nested_defn_6_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__flatten_nested_defn_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i8);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__flatten_nested_defn_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r2 = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i4);
	if (((Integer) MR_const_field(MR_mktag(1), r5, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0_i6);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__flatten_nested_defn_6_0, "ml_elim_nested:elim_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__flatten_nested_defn_6_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__flatten_nested_defn_6_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r7, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r7, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__ml_elim_nested__flatten_nested_defn_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r4, (Integer) 3);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r3, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 2) = r6;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r5, (Integer) 2), (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r2 = r4;
	call_localret(STATIC(mercury__ml_elim_nested__flatten_statement_4_0),
		mercury__ml_elim_nested__flatten_nested_defn_6_0_i7,
		STATIC(mercury__ml_elim_nested__flatten_nested_defn_6_0));
Define_label(mercury__ml_elim_nested__flatten_nested_defn_6_0_i7);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__flatten_nested_defn_6_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__flatten_nested_defn_6_0, "ml_elim_nested:elim_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__flatten_nested_defn_6_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 4, mercury__ml_elim_nested__flatten_nested_defn_6_0, "mlds:defn/0");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r6, (Integer) 2) = MR_stackvar(3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 3, mercury__ml_elim_nested__flatten_nested_defn_6_0, "mlds:entity_defn/0");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r7, (Integer) 1) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__flatten_nested_defn_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r4, (Integer) 3);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = r5;
	MR_field(MR_mktag(0), r6, (Integer) 3) = r7;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE


BEGIN_MODULE(ml_elim_nested_module13)
	init_entry(mercury__ml_elim_nested__fixup_atomic_stmt_4_0);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i5);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i6);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i7);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i8);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i9);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i10);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i11);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i19);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i20);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i21);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i22);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i23);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i24);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i26);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i25);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i27);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i14);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i15);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i12);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i13);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i1016);
	init_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i2);
BEGIN_CODE

/* code for predicate 'fixup_atomic_stmt'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__fixup_atomic_stmt_4_0);
	MR_incr_sp_push_msg(7, "ml_elim_nested:fixup_atomic_stmt/4");
	MR_stackvar(7) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i1016) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i5) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i8) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i11));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i6,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i6);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i7,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i7);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r1, (Integer) 6);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i9,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i9);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rvals_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i10,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i10);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 7, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(2), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(2), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(2), r1, (Integer) 5) = r3;
	MR_field(MR_mktag(2), r1, (Integer) 6) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i11);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r3 == (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i12);
	if (((Integer) r3 == (Integer) 1))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i14);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	COMPUTED_GOTO((Unsigned) MR_tag(r3),
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i19) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i20) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i22) AND
		LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i24));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i19);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_ml_elim_nested__common_16);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i20);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i21,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i21);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i22);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i23,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i23);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i24);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i25);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i26,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i26);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i25);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i27,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i27);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i14);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i15,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i15);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i12);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i13,
		STATIC(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i13);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_atomic_stmt_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_atomic_stmt_4_0, "mlds:atomic_statement/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i1016);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_atomic_stmt_4_0_i2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module14)
	init_entry(mercury__ml_elim_nested__fixup_rvals_4_0);
	init_label(mercury__ml_elim_nested__fixup_rvals_4_0_i4);
	init_label(mercury__ml_elim_nested__fixup_rvals_4_0_i5);
	init_label(mercury__ml_elim_nested__fixup_rvals_4_0_i3);
BEGIN_CODE

/* code for predicate 'fixup_rvals'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__fixup_rvals_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_rvals_4_0_i3);
	MR_incr_sp_push_msg(2, "ml_elim_nested:fixup_rvals/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_rvals_4_0_i4,
		STATIC(mercury__ml_elim_nested__fixup_rvals_4_0));
Define_label(mercury__ml_elim_nested__fixup_rvals_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rvals_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__ml_elim_nested__fixup_rvals_4_0,
		LABEL(mercury__ml_elim_nested__fixup_rvals_4_0_i5),
		STATIC(mercury__ml_elim_nested__fixup_rvals_4_0));
Define_label(mercury__ml_elim_nested__fixup_rvals_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rvals_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__fixup_rvals_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rvals_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module15)
	init_entry(mercury__ml_elim_nested__fixup_rval_4_0);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i4);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i5);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i6);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i7);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i9);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i11);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i10);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i13);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i14);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i12);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i15);
	init_label(mercury__ml_elim_nested__fixup_rval_4_0_i1009);
BEGIN_CODE

/* code for predicate 'fixup_rval'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__fixup_rval_4_0);
	MR_incr_sp_push_msg(3, "ml_elim_nested:fixup_rval/4");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i4) AND
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i6) AND
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i1009) AND
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i9));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_rval_4_0_i5,
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__ml_elim_nested__fixup_rval_4_0, "mlds:rval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__ml_elim_nested__fixup_rval_4_0,
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i7),
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__fixup_rval_4_0, "mlds:rval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i9);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__ml_elim_nested__fixup_rval_4_0,
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i11),
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i11);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__ml_elim_nested__fixup_rval_4_0, "mlds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i10);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i12);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__ml_elim_nested__fixup_rval_4_0,
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i13),
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i13);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	localcall(mercury__ml_elim_nested__fixup_rval_4_0,
		LABEL(mercury__ml_elim_nested__fixup_rval_4_0_i14),
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i14);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__ml_elim_nested__fixup_rval_4_0, "mlds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i12);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_rval_4_0_i15,
		STATIC(mercury__ml_elim_nested__fixup_rval_4_0));
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i15);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_rval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__ml_elim_nested__fixup_rval_4_0, "mlds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_rval_4_0_i1009);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module16)
	init_entry(mercury__ml_elim_nested__fixup_lvals_4_0);
	init_label(mercury__ml_elim_nested__fixup_lvals_4_0_i4);
	init_label(mercury__ml_elim_nested__fixup_lvals_4_0_i5);
	init_label(mercury__ml_elim_nested__fixup_lvals_4_0_i3);
BEGIN_CODE

/* code for predicate 'fixup_lvals'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__fixup_lvals_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_lvals_4_0_i3);
	MR_incr_sp_push_msg(2, "ml_elim_nested:fixup_lvals/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_lval_4_0),
		mercury__ml_elim_nested__fixup_lvals_4_0_i4,
		STATIC(mercury__ml_elim_nested__fixup_lvals_4_0));
Define_label(mercury__ml_elim_nested__fixup_lvals_4_0_i4);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lvals_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__ml_elim_nested__fixup_lvals_4_0,
		LABEL(mercury__ml_elim_nested__fixup_lvals_4_0_i5),
		STATIC(mercury__ml_elim_nested__fixup_lvals_4_0));
Define_label(mercury__ml_elim_nested__fixup_lvals_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lvals_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__ml_elim_nested__fixup_lvals_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_lvals_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___mlds__mlds_module_name_0_0);

BEGIN_MODULE(ml_elim_nested_module17)
	init_entry(mercury__ml_elim_nested__fixup_lval_4_0);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i18);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i6);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i11);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i1023);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i9);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i1035);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i4);
	init_label(mercury__ml_elim_nested__fixup_lval_4_0_i5);
BEGIN_CODE

/* code for predicate 'fixup_lval'/4 in mode 0 */
Define_static(mercury__ml_elim_nested__fixup_lval_4_0);
	MR_incr_sp_push_msg(10, "ml_elim_nested:fixup_lval/4");
	MR_stackvar(10) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_lval_4_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_lval_4_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_lval_4_0_i18,
		STATIC(mercury__ml_elim_nested__fixup_lval_4_0));
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i18);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:lval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i6);
	MR_stackvar(7) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(9) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__fixup_lval_4_0_i9);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury____Unify___mlds__mlds_module_name_0_0),
		mercury__ml_elim_nested__fixup_lval_4_0_i11,
		STATIC(mercury__ml_elim_nested__fixup_lval_4_0));
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i11);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lval_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__fixup_lval_4_0_i9);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__fixup_lval_4_0_i1023,
		STATIC(mercury__ml_elim_nested__fixup_lval_4_0));
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i1023);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lval_4_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	if ((strcmp((char *)MR_stackvar(4), (char *)MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (Integer) 0)) != 0))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(9);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
	GOTO_LABEL(mercury__ml_elim_nested__fixup_lval_4_0_i1035);
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i9);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lval_4_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i1035);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:lval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_ml_elim_nested__common_7);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:rval/0");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:lval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__ml_elim_nested__fixup_lval_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_string_const("env_ptr", 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:field_id/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__fixup_rval_4_0),
		mercury__ml_elim_nested__fixup_lval_4_0_i5,
		STATIC(mercury__ml_elim_nested__fixup_lval_4_0));
Define_label(mercury__ml_elim_nested__fixup_lval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__fixup_lval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__ml_elim_nested__fixup_lval_4_0, "mlds:lval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(do_fail);

BEGIN_MODULE(ml_elim_nested_module18)
	init_entry(mercury__ml_elim_nested__defn_contains_defn_2_0);
	init_label(mercury__ml_elim_nested__defn_contains_defn_2_0_i2);
BEGIN_CODE

/* code for predicate 'defn_contains_defn'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__defn_contains_defn_2_0);
	MR_mkframe("ml_elim_nested:defn_contains_defn/2", 1, LABEL(mercury__ml_elim_nested__defn_contains_defn_2_0_i2));
	MR_framevar(1) = r1;
	MR_succeed();
Define_label(mercury__ml_elim_nested__defn_contains_defn_2_0_i2);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_contains_defn_2_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = MR_const_field(MR_mktag(0), MR_framevar(1), (Integer) 3);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	tailcall(STATIC(mercury__ml_elim_nested__defn_body_contains_defn_2_0),
		STATIC(mercury__ml_elim_nested__defn_contains_defn_2_0));
END_MODULE


BEGIN_MODULE(ml_elim_nested_module19)
	init_entry(mercury__ml_elim_nested__defn_body_contains_defn_2_0);
	init_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i2);
	init_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i5);
	init_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i4);
	init_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i1);
BEGIN_CODE

/* code for predicate 'defn_body_contains_defn'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__defn_body_contains_defn_2_0);
	MR_mkframe("ml_elim_nested:defn_body_contains_defn/2", 0, ENTRY(do_fail));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	tailcall(STATIC(mercury__ml_elim_nested__maybe_statement_contains_defn_2_0),
		STATIC(mercury__ml_elim_nested__defn_body_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i4);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 4);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__defn_body_contains_defn_2_0_i5,
		STATIC(mercury__ml_elim_nested__defn_body_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i5);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_defn_2_0));
	call_localret(STATIC(mercury__ml_elim_nested__defn_contains_defn_2_0),
		mercury__ml_elim_nested__defn_body_contains_defn_2_0_i1,
		STATIC(mercury__ml_elim_nested__defn_body_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i4);
	GOTO(ENTRY(do_fail));
Define_label(mercury__ml_elim_nested__defn_body_contains_defn_2_0_i1);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_defn_2_0));
	MR_succeed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module20)
	init_entry(mercury__ml_elim_nested__maybe_statement_contains_defn_2_0);
BEGIN_CODE

/* code for predicate 'maybe_statement_contains_defn'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__maybe_statement_contains_defn_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	MR_mkframe("ml_elim_nested:maybe_statement_contains_defn/2", 0, ENTRY(do_fail));
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	tailcall(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		STATIC(mercury__ml_elim_nested__maybe_statement_contains_defn_2_0));
END_MODULE


BEGIN_MODULE(ml_elim_nested_module21)
	init_entry(mercury__ml_elim_nested__statement_contains_defn_2_0);
BEGIN_CODE

/* code for predicate 'statement_contains_defn'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__statement_contains_defn_2_0);
	MR_mkframe("ml_elim_nested:statement_contains_defn/2", 0, ENTRY(do_fail));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	tailcall(STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0),
		STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0));
END_MODULE


BEGIN_MODULE(ml_elim_nested_module22)
	init_entry(mercury__ml_elim_nested__stmt_contains_defn_2_0);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i3);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i6);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1027);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i8);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i10);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i12);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1035);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i18);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i19);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1045);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2);
	init_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1);
BEGIN_CODE

/* code for predicate 'stmt_contains_defn'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__stmt_contains_defn_2_0);
	MR_mkframe("ml_elim_nested:stmt_contains_defn/2", 1, ENTRY(do_fail));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i3) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i10) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i12) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i18));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1027);
	MR_framevar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_defn_2_0_i6,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i6);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	call_localret(STATIC(mercury__ml_elim_nested__defn_contains_defn_2_0),
		mercury__ml_elim_nested__stmt_contains_defn_2_0_i1,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1027);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = MR_framevar(1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_defn_2_0_i8,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i8);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	call_localret(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		mercury__ml_elim_nested__stmt_contains_defn_2_0_i1,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i10);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	localtailcall(mercury__ml_elim_nested__stmt_contains_defn_2_0,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i12);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1035);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_framevar(1) = r2;
	localcall(mercury__ml_elim_nested__stmt_contains_defn_2_0,
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1),
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1035);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	if (((Integer) MR_framevar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_fail));
	r1 = MR_const_field(MR_mktag(1), MR_framevar(1), (Integer) 0);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	tailcall(STATIC(mercury__ml_elim_nested__statement_contains_defn_2_0),
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i18);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i19) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i19);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1045);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_framevar(1) = r2;
	localcall(mercury__ml_elim_nested__stmt_contains_defn_2_0,
		LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1),
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1045);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	MR_redoip_slot(MR_curfr) = ENTRY(do_fail);
	r1 = MR_const_field(MR_mktag(0), MR_framevar(1), (Integer) 0);
	MR_maxfr = MR_prevfr_slot(MR_curfr);
	MR_succip = MR_succip_slot(MR_curfr);
	MR_curfr = MR_succfr_slot(MR_curfr);
	localtailcall(mercury__ml_elim_nested__stmt_contains_defn_2_0,
		STATIC(mercury__ml_elim_nested__stmt_contains_defn_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i2);
	GOTO(ENTRY(do_fail));
Define_label(mercury__ml_elim_nested__stmt_contains_defn_2_0_i1);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_defn_2_0));
	MR_succeed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module23)
	init_entry(mercury__ml_elim_nested__defn_contains_var_2_0);
BEGIN_CODE

/* code for predicate 'defn_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__defn_contains_var_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	tailcall(STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__defn_contains_var_2_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_mlds__type_ctor_info_rval_0;

BEGIN_MODULE(ml_elim_nested_module24)
	init_entry(mercury__ml_elim_nested__defn_body_contains_var_2_0);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i15);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1029);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i7);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i9);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1037);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1043);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i4);
	init_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1023);
BEGIN_CODE

/* code for predicate 'defn_body_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__defn_body_contains_var_2_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0_i4);
	MR_incr_sp_push_msg(5, "ml_elim_nested:defn_body_contains_var/2");
	MR_stackvar(5) = (Word) MR_succip;
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0_i7);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1023);
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1043);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__defn_body_contains_var_2_0_i15,
		STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i15);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__defn_body_contains_var_2_0_i1029,
		STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1029);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i7);
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1043);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 4);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__defn_body_contains_var_2_0_i9,
		STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i9);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__defn_contains_var_2_0),
		mercury__ml_elim_nested__defn_body_contains_var_2_0_i1037,
		STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1037);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1043);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__defn_body_contains_var_2_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	tailcall(STATIC(mercury__ml_elim_nested__maybe_statement_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__defn_body_contains_var_2_0));
Define_label(mercury__ml_elim_nested__defn_body_contains_var_2_0_i1023);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module25)
	init_entry(mercury__ml_elim_nested__maybe_statement_contains_var_2_0);
	init_label(mercury__ml_elim_nested__maybe_statement_contains_var_2_0_i1);
BEGIN_CODE

/* code for predicate 'maybe_statement_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__maybe_statement_contains_var_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__maybe_statement_contains_var_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	tailcall(STATIC(mercury__ml_elim_nested__statement_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__maybe_statement_contains_var_2_0));
Define_label(mercury__ml_elim_nested__maybe_statement_contains_var_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module26)
	init_entry(mercury__ml_elim_nested__statement_contains_var_2_0);
BEGIN_CODE

/* code for predicate 'statement_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__statement_contains_var_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__statement_contains_var_2_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_mlds__type_ctor_info_lval_0;
Declare_entry(mercury____Unify___mlds__fully_qualified_name_1_0);

BEGIN_MODULE(ml_elim_nested_module27)
	init_entry(mercury__ml_elim_nested__stmt_contains_var_2_0);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i4);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i10);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1122);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i8);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i15);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1132);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i19);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i23);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i27);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i31);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i34);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i39);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i43);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i47);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i52);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i50);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i58);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1147);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i56);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i63);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1159);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i69);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1161);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i66);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1163);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i75);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i77);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1167);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i81);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i93);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i90);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i91);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i87);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i88);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i83);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i96);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i100);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i103);
	init_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1);
BEGIN_CODE

/* code for predicate 'stmt_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__stmt_contains_var_2_0);
	MR_incr_sp_push_msg(8, "ml_elim_nested:stmt_contains_var/2");
	MR_stackvar(8) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i4) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i19) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i27) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i39));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i4);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i8);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i10,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i10);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__defn_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1122,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1122);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i8);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_statement_0;
	r2 = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i15,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i15);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__statement_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1132,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1132);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i19);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i23,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i23);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(8);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i4) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i19) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i27) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i39));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i27);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i31,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i31);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	r2 = MR_stackvar(1);
	localcall(mercury__ml_elim_nested__stmt_contains_var_2_0,
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i34),
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i34);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r3 = MR_stackvar(3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__ml_elim_nested__statement_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i39);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i100) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i43) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i75) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i81) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i100) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i103));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i43);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i47,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i47);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i50);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i52,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
	}
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i52);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r3 = MR_stackvar(4);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i50);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i56);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_rval_0;
	r2 = r4;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i58,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i58);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1147,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1147);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i56);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_lval_0;
	r2 = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i63,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i63);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i66);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i69);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1159,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1159);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i69);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1161,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1161);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i66);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1163,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1163);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i75);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i77,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i77);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i1167,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1167);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1168);
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1172);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i81);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r5);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i87);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i90);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	r1 = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i93,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
	}
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i93);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i83);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i90);
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i91,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i91);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i83);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i87);
	r1 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__stmt_contains_var_2_0_i88,
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i88);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i83);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	r2 = MR_stackvar(1);
	localcall(mercury__ml_elim_nested__stmt_contains_var_2_0,
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i96),
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i96);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i1046);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i4) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i19) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i27) AND
		LABEL(mercury__ml_elim_nested__stmt_contains_var_2_0_i39));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i100);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i103);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__stmt_contains_var_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module28)
	init_entry(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i78);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i75);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i76);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i72);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i73);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i68);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i81);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1120);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1126);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i50);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i62);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i59);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i60);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1081);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i56);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i57);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i52);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i4);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1087);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i36);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i22);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1092);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i29);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i26);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i5);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1094);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i11);
	init_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
BEGIN_CODE

/* code for predicate 'atomic_stmt_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0);
	MR_incr_sp_push_msg(6, "ml_elim_nested:atomic_stmt_contains_var/2");
	MR_stackvar(6) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i4);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i50);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_tempr1 = MR_tag(MR_tempr2);
	if ((r3 != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 5);
	r4 = MR_tempr2;
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i72);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i75);
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i78,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	}
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i78);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i68);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i75);
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i76,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i76);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i68);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i72);
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i73,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i73);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1081);
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i68);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_stackvar(3) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1126);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_rval_0;
	r2 = r3;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i81,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i81);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1120,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1120);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(5);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(3);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(4);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1126);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(3);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(4);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i50);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r4);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i56);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i59);
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i62,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	}
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i62);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i52);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i59);
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i60,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i60);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i52);
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1081);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i56);
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i57,
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i57);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1081);
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i52);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i4);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r3 == (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i5);
	if (((Integer) r3 == (Integer) 1))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1092);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if ((MR_tag(r3) == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i22);
	if ((MR_tag(r3) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i36);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1087);
	r1 = MR_const_mask_field(r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i36);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i26);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i29);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i22);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1094);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i26);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i29);
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1092);
	r1 = MR_const_mask_field(r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i29);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i26);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i5);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r3);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1087);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i11);
	}
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1094);
	r1 = MR_const_mask_field(r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i11);
	r3 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		STATIC(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0));
Define_label(mercury__ml_elim_nested__atomic_stmt_contains_var_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module29)
	init_entry(mercury__ml_elim_nested__rval_contains_var_2_0);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1017);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i18);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i4);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i5);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i12);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i8);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1010);
	init_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1);
BEGIN_CODE

/* code for predicate 'rval_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__rval_contains_var_2_0);
	MR_incr_sp_push_msg(3, "ml_elim_nested:rval_contains_var/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1017);
	while (1) {
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i4);
	if ((r3 == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i18);
	if ((r3 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	/* continue */ } /* end while */
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i18);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__ml_elim_nested__lval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__rval_contains_var_2_0));
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i4);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i1017);
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i5);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i8);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__ml_elim_nested__rval_contains_var_2_0,
		LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i12),
		STATIC(mercury__ml_elim_nested__rval_contains_var_2_0));
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i12);
	update_prof_current_proc(LABEL(mercury__ml_elim_nested__rval_contains_var_2_0));
	if (r1)
		GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i1010);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__ml_elim_nested__rval_contains_var_2_0_i1017);
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i8);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__ml_elim_nested__lval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__rval_contains_var_2_0));
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1010);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__ml_elim_nested__rval_contains_var_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module30)
	init_entry(mercury__ml_elim_nested__lval_contains_var_2_0);
	init_label(mercury__ml_elim_nested__lval_contains_var_2_0_i7);
	init_label(mercury__ml_elim_nested__lval_contains_var_2_0_i4);
BEGIN_CODE

/* code for predicate 'lval_contains_var'/2 in mode 0 */
Define_static(mercury__ml_elim_nested__lval_contains_var_2_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__ml_elim_nested__lval_contains_var_2_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__ml_elim_nested__lval_contains_var_2_0_i7);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__lval_contains_var_2_0));
Define_label(mercury__ml_elim_nested__lval_contains_var_2_0_i7);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	tailcall(ENTRY(mercury____Unify___mlds__fully_qualified_name_1_0),
		STATIC(mercury__ml_elim_nested__lval_contains_var_2_0));
Define_label(mercury__ml_elim_nested__lval_contains_var_2_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	tailcall(STATIC(mercury__ml_elim_nested__rval_contains_var_2_0),
		STATIC(mercury__ml_elim_nested__lval_contains_var_2_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(ml_elim_nested_module31)
	init_entry(mercury____Unify___ml_elim_nested__elim_info_0_0);
	init_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i2);
	init_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i4);
	init_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i6);
	init_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___ml_elim_nested__elim_info_0_0);
	MR_incr_sp_push_msg(7, "ml_elim_nested:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___mlds__mlds_module_name_0_0),
		mercury____Unify___ml_elim_nested__elim_info_0_0_i2,
		STATIC(mercury____Unify___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___ml_elim_nested__elim_info_0_0_i4,
		STATIC(mercury____Unify___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___ml_elim_nested__elim_info_0_0_i6,
		STATIC(mercury____Unify___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Unify___ml_elim_nested__elim_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module32)
	init_entry(mercury____Index___ml_elim_nested__elim_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___ml_elim_nested__elim_info_0_0);
	tailcall(STATIC(mercury____Index___ml_elim_nested__elim_info_0__ua0_2_0),
		STATIC(mercury____Index___ml_elim_nested__elim_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___mlds__mlds_module_name_0_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(ml_elim_nested_module33)
	init_entry(mercury____Compare___ml_elim_nested__elim_info_0_0);
	init_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i3);
	init_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i7);
	init_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i11);
	init_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___ml_elim_nested__elim_info_0_0);
	MR_incr_sp_push_msg(7, "ml_elim_nested:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___mlds__mlds_module_name_0_0),
		mercury____Compare___ml_elim_nested__elim_info_0_0_i3,
		STATIC(mercury____Compare___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___ml_elim_nested__elim_info_0_0_i7,
		STATIC(mercury____Compare___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___ml_elim_nested__elim_info_0_0_i11,
		STATIC(mercury____Compare___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_mlds__type_ctor_info_defn_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___ml_elim_nested__elim_info_0_0));
Define_label(mercury____Compare___ml_elim_nested__elim_info_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(ml_elim_nested_module34)
	init_entry(mercury____Unify___ml_elim_nested__outervars_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___ml_elim_nested__outervars_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___ml_elim_nested__outervars_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(ml_elim_nested_module35)
	init_entry(mercury____Index___ml_elim_nested__outervars_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___ml_elim_nested__outervars_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___ml_elim_nested__outervars_0_0));
END_MODULE


BEGIN_MODULE(ml_elim_nested_module36)
	init_entry(mercury____Compare___ml_elim_nested__outervars_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___ml_elim_nested__outervars_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_ml_elim_nested__common_0);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___ml_elim_nested__outervars_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__ml_elim_nested_maybe_bunch_0(void)
{
	ml_elim_nested_module0();
	ml_elim_nested_module1();
	ml_elim_nested_module2();
	ml_elim_nested_module3();
	ml_elim_nested_module4();
	ml_elim_nested_module5();
	ml_elim_nested_module6();
	ml_elim_nested_module7();
	ml_elim_nested_module8();
	ml_elim_nested_module9();
	ml_elim_nested_module10();
	ml_elim_nested_module11();
	ml_elim_nested_module12();
	ml_elim_nested_module13();
	ml_elim_nested_module14();
	ml_elim_nested_module15();
	ml_elim_nested_module16();
	ml_elim_nested_module17();
	ml_elim_nested_module18();
	ml_elim_nested_module19();
	ml_elim_nested_module20();
	ml_elim_nested_module21();
	ml_elim_nested_module22();
	ml_elim_nested_module23();
	ml_elim_nested_module24();
	ml_elim_nested_module25();
	ml_elim_nested_module26();
	ml_elim_nested_module27();
	ml_elim_nested_module28();
	ml_elim_nested_module29();
	ml_elim_nested_module30();
	ml_elim_nested_module31();
	ml_elim_nested_module32();
	ml_elim_nested_module33();
	ml_elim_nested_module34();
	ml_elim_nested_module35();
	ml_elim_nested_module36();
}

#endif

void mercury__ml_elim_nested__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__ml_elim_nested__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__ml_elim_nested_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_ml_elim_nested__type_ctor_info_elim_info_0,
			ml_elim_nested__elim_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_ml_elim_nested__type_ctor_info_outervars_0,
			ml_elim_nested__outervars_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
