/*
** Automatically generated from `mode_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__mode_info__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___mode_info__mode_info_0__ua0_2_0);
Declare_static(mercury__mode_info__mode_info_get_instvarset__ua0_2_0);
Define_extern_entry(mercury__mode_info__mode_info_init_10_0);
Declare_label(mercury__mode_info__mode_info_init_10_0_i2);
Declare_label(mercury__mode_info__mode_info_init_10_0_i3);
Declare_label(mercury__mode_info__mode_info_init_10_0_i4);
Declare_label(mercury__mode_info__mode_info_init_10_0_i5);
Declare_label(mercury__mode_info__mode_info_init_10_0_i6);
Declare_label(mercury__mode_info__mode_info_init_10_0_i7);
Declare_label(mercury__mode_info__mode_info_init_10_0_i8);
Declare_label(mercury__mode_info__mode_info_init_10_0_i9);
Define_extern_entry(mercury__mode_info__mode_info_get_io_state_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_io_state_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_module_info_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_module_info_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_preds_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_modes_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_insts_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_predid_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_procid_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_context_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
Define_extern_entry(mercury__mode_info__mode_info_set_call_context_3_0);
Declare_label(mercury__mode_info__mode_info_set_call_context_3_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
Declare_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
Declare_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i4);
Define_extern_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_instmap_2_0);
Define_extern_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
Define_extern_entry(mercury__mode_info__mode_info_set_instmap_3_0);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i3);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i5);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i7);
Declare_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
Define_extern_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_errors_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_errors_3_0);
Define_extern_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i5);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i2);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i7);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
Declare_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
Define_extern_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
Declare_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_var_is_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i1011);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i1017);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i9);
Declare_label(mercury__mode_info__mode_info_var_is_live_3_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1011);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1017);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i9);
Declare_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_get_liveness_2_0);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1001);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
Declare_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_get_varset_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_varset_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
Define_extern_entry(mercury__mode_info__mode_info_get_var_types_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_var_types_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_lock_vars_4_0);
Define_extern_entry(mercury__mode_info__mode_info_unlock_vars_4_0);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i8);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i10);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i7);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i14);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i1014);
Declare_label(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
Define_extern_entry(mercury__mode_info__mode_info_var_is_locked_3_0);
Define_extern_entry(mercury__mode_info__mode_info_var_is_locked_2_3_0);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1002);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i4);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i3);
Declare_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1);
Define_extern_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_live_vars_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_live_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_last_checkpoint_insts_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_last_checkpoint_insts_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_parallel_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_set_parallel_vars_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_how_to_check_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_how_to_check_3_0);
Define_extern_entry(mercury__mode_info__mode_info_get_may_change_called_proc_2_0);
Define_extern_entry(mercury__mode_info__mode_info_set_may_change_called_proc_3_0);
Define_extern_entry(mercury__mode_info__mode_info_set_checking_extra_goals_3_0);
Declare_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i5);
Declare_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_get_call_id_3_0);
Declare_label(mercury__mode_info__mode_info_get_call_id_3_0_i2);
Define_extern_entry(mercury__mode_info__mode_info_error_4_0);
Define_extern_entry(mercury__mode_info__mode_info_add_error_3_0);
Declare_label(mercury__mode_info__mode_info_add_error_3_0_i2);
Define_extern_entry(mercury____Unify___mode_info__mode_context_0_0);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i8);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i10);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i4);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i6);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1012);
Declare_label(mercury____Unify___mode_info__mode_context_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__mode_context_0_0);
Declare_label(mercury____Index___mode_info__mode_context_0_0_i5);
Declare_label(mercury____Index___mode_info__mode_context_0_0_i4);
Define_extern_entry(mercury____Compare___mode_info__mode_context_0_0);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i5);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i4);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i2);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i9);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i8);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i6);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i10);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i11);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i24);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i27);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i16);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i19);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i1021);
Declare_label(mercury____Compare___mode_info__mode_context_0_0_i36);
Define_extern_entry(mercury____Unify___mode_info__side_0_0);
Declare_label(mercury____Unify___mode_info__side_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__side_0_0);
Define_extern_entry(mercury____Compare___mode_info__side_0_0);
Define_extern_entry(mercury____Unify___mode_info__call_context_0_0);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i3);
Declare_label(mercury____Unify___mode_info__call_context_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__call_context_0_0);
Declare_label(mercury____Index___mode_info__call_context_0_0_i3);
Define_extern_entry(mercury____Compare___mode_info__call_context_0_0);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i3);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i2);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i5);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i4);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i6);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i7);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i11);
Declare_label(mercury____Compare___mode_info__call_context_0_0_i1014);
Define_extern_entry(mercury____Unify___mode_info__var_lock_reason_0_0);
Declare_label(mercury____Unify___mode_info__var_lock_reason_0_0_i5);
Declare_label(mercury____Unify___mode_info__var_lock_reason_0_0_i7);
Declare_label(mercury____Unify___mode_info__var_lock_reason_0_0_i4);
Declare_label(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__var_lock_reason_0_0);
Declare_label(mercury____Index___mode_info__var_lock_reason_0_0_i5);
Declare_label(mercury____Index___mode_info__var_lock_reason_0_0_i6);
Declare_label(mercury____Index___mode_info__var_lock_reason_0_0_i4);
Define_extern_entry(mercury____Compare___mode_info__var_lock_reason_0_0);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i5);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i6);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i4);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i10);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i11);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i9);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i12);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i13);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i19);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i21);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i18);
Declare_label(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
Define_extern_entry(mercury____Unify___mode_info__how_to_check_goal_0_0);
Declare_label(mercury____Unify___mode_info__how_to_check_goal_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__how_to_check_goal_0_0);
Define_extern_entry(mercury____Compare___mode_info__how_to_check_goal_0_0);
Define_extern_entry(mercury____Unify___mode_info__may_change_called_proc_0_0);
Declare_label(mercury____Unify___mode_info__may_change_called_proc_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__may_change_called_proc_0_0);
Define_extern_entry(mercury____Compare___mode_info__may_change_called_proc_0_0);
Define_extern_entry(mercury____Unify___mode_info__locked_vars_0_0);
Define_extern_entry(mercury____Index___mode_info__locked_vars_0_0);
Define_extern_entry(mercury____Compare___mode_info__locked_vars_0_0);
Define_extern_entry(mercury____Unify___mode_info__mode_info_0_0);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i2);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i4);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i6);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i8);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i10);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i12);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i14);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i16);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i18);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i20);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i22);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i24);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i26);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i28);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i30);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i32);
Declare_label(mercury____Unify___mode_info__mode_info_0_0_i1);
Define_extern_entry(mercury____Index___mode_info__mode_info_0_0);
Define_extern_entry(mercury____Compare___mode_info__mode_info_0_0);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i3);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i7);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i11);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i15);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i19);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i23);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i27);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i31);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i35);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i39);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i43);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i47);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i51);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i55);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i59);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i63);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i67);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i71);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i75);
Declare_label(mercury____Compare___mode_info__mode_info_0_0_i97);

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_call_context_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_how_to_check_goal_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_locked_vars_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_may_change_called_proc_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_mode_context_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_mode_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_side_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_var_lock_reason_0;

static const struct mercury_data_mode_info__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_0;

static const struct mercury_data_mode_info__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_1;

static const struct mercury_data_mode_info__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_2;

static const struct mercury_data_mode_info__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_mode_info__common_3;

static const struct mercury_data_mode_info__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_mode_info__common_4;

static const struct mercury_data_mode_info__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_mode_info__common_5;

static const struct mercury_data_mode_info__common_6_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_mode_info__common_6;

static const struct mercury_data_mode_info__common_7_struct {
	Word * f1;
}  mercury_data_mode_info__common_7;

static const struct mercury_data_mode_info__common_8_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_mode_info__common_8;

static const struct mercury_data_mode_info__common_9_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_mode_info__common_9;

static const struct mercury_data_mode_info__common_10_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_mode_info__common_10;

static const struct mercury_data_mode_info__common_11_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_mode_info__common_11;

static const struct mercury_data_mode_info__common_12_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_mode_info__common_12;

static const struct mercury_data_mode_info__common_13_struct {
	Word * f1;
}  mercury_data_mode_info__common_13;

static const struct mercury_data_mode_info__common_14_struct {
	Word * f1;
}  mercury_data_mode_info__common_14;

static const struct mercury_data_mode_info__common_15_struct {
	Word * f1;
}  mercury_data_mode_info__common_15;

static const struct mercury_data_mode_info__common_16_struct {
	Word * f1;
}  mercury_data_mode_info__common_16;

static const struct mercury_data_mode_info__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_17;

static const struct mercury_data_mode_info__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_mode_info__common_18;

static const struct mercury_data_mode_info__common_19_struct {
	Word * f1;
}  mercury_data_mode_info__common_19;

static const struct mercury_data_mode_info__common_20_struct {
	Word * f1;
}  mercury_data_mode_info__common_20;

static const struct mercury_data_mode_info__common_21_struct {
	Word * f1;
}  mercury_data_mode_info__common_21;

static const struct mercury_data_mode_info__common_22_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_22;

static const struct mercury_data_mode_info__common_23_struct {
	Word * f1;
}  mercury_data_mode_info__common_23;

static const struct mercury_data_mode_info__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_24;

static const struct mercury_data_mode_info__common_25_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_25;

static const struct mercury_data_mode_info__common_26_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_26;

static const struct mercury_data_mode_info__common_27_struct {
	Word * f1;
	Word * f2;
}  mercury_data_mode_info__common_27;

static const struct mercury_data_mode_info__common_28_struct {
	Word * f1;
}  mercury_data_mode_info__common_28;

static const struct mercury_data_mode_info__common_29_struct {
	Word * f1;
}  mercury_data_mode_info__common_29;

static const struct mercury_data_mode_info__common_30_struct {
	Word * f1;
}  mercury_data_mode_info__common_30;

static const struct mercury_data_mode_info__common_31_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
	Word * f17;
	Word * f18;
	Word * f19;
	Word * f20;
	Word * f21;
	String f22;
	Word * f23;
	Integer f24;
	Integer f25;
}  mercury_data_mode_info__common_31;

static const struct mercury_data_mode_info__common_32_struct {
	Word * f1;
}  mercury_data_mode_info__common_32;

static const struct mercury_data_mode_info__common_33_struct {
	Word * f1;
}  mercury_data_mode_info__common_33;

static const struct mercury_data_mode_info__common_34_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_mode_info__common_34;

static const struct mercury_data_mode_info__common_35_struct {
	Word * f1;
}  mercury_data_mode_info__common_35;

static const struct mercury_data_mode_info__common_36_struct {
	Word * f1;
}  mercury_data_mode_info__common_36;

static const struct mercury_data_mode_info__common_37_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_mode_info__common_37;

static const struct mercury_data_mode_info__common_38_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_mode_info__common_38;

static const struct mercury_data_mode_info__common_39_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_mode_info__common_39;

static const struct mercury_data_mode_info__common_40_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_mode_info__common_40;

static const struct mercury_data_mode_info__common_41_struct {
	Integer f1;
	Word * f2;
}  mercury_data_mode_info__common_41;

static const struct mercury_data_mode_info__common_42_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_mode_info__common_42;

static const struct mercury_data_mode_info__common_43_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_mode_info__common_43;

static const struct mercury_data_mode_info__common_44_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_mode_info__common_44;

static const struct mercury_data_mode_info__type_ctor_functors_var_lock_reason_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_mode_info__type_ctor_functors_var_lock_reason_0;

static const struct mercury_data_mode_info__type_ctor_layout_var_lock_reason_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_var_lock_reason_0;

static const struct mercury_data_mode_info__type_ctor_functors_side_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_mode_info__type_ctor_functors_side_0;

static const struct mercury_data_mode_info__type_ctor_layout_side_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_side_0;

static const struct mercury_data_mode_info__type_ctor_functors_mode_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_mode_info__type_ctor_functors_mode_info_0;

static const struct mercury_data_mode_info__type_ctor_layout_mode_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_mode_info_0;

static const struct mercury_data_mode_info__type_ctor_functors_mode_context_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_mode_info__type_ctor_functors_mode_context_0;

static const struct mercury_data_mode_info__type_ctor_layout_mode_context_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_mode_context_0;

static const struct mercury_data_mode_info__type_ctor_functors_may_change_called_proc_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_mode_info__type_ctor_functors_may_change_called_proc_0;

static const struct mercury_data_mode_info__type_ctor_layout_may_change_called_proc_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_may_change_called_proc_0;

static const struct mercury_data_mode_info__type_ctor_functors_locked_vars_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_mode_info__type_ctor_functors_locked_vars_0;

static const struct mercury_data_mode_info__type_ctor_layout_locked_vars_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_locked_vars_0;

static const struct mercury_data_mode_info__type_ctor_functors_how_to_check_goal_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_mode_info__type_ctor_functors_how_to_check_goal_0;

static const struct mercury_data_mode_info__type_ctor_layout_how_to_check_goal_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_how_to_check_goal_0;

static const struct mercury_data_mode_info__type_ctor_functors_call_context_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_functors_call_context_0;

static const struct mercury_data_mode_info__type_ctor_layout_call_context_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_mode_info__type_ctor_layout_call_context_0;

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_call_context_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__call_context_0_0),
	ENTRY(mercury____Index___mode_info__call_context_0_0),
	ENTRY(mercury____Compare___mode_info__call_context_0_0),
	(Integer) 2,
	(Word *) &mercury_data_mode_info__type_ctor_functors_call_context_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_call_context_0,
	MR_string_const("mode_info", 9),
	MR_string_const("call_context", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_how_to_check_goal_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__how_to_check_goal_0_0),
	ENTRY(mercury____Index___mode_info__how_to_check_goal_0_0),
	ENTRY(mercury____Compare___mode_info__how_to_check_goal_0_0),
	(Integer) 0,
	(Word *) &mercury_data_mode_info__type_ctor_functors_how_to_check_goal_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_how_to_check_goal_0,
	MR_string_const("mode_info", 9),
	MR_string_const("how_to_check_goal", 17),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_locked_vars_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__locked_vars_0_0),
	ENTRY(mercury____Index___mode_info__locked_vars_0_0),
	ENTRY(mercury____Compare___mode_info__locked_vars_0_0),
	(Integer) 6,
	(Word *) &mercury_data_mode_info__type_ctor_functors_locked_vars_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_locked_vars_0,
	MR_string_const("mode_info", 9),
	MR_string_const("locked_vars", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_may_change_called_proc_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__may_change_called_proc_0_0),
	ENTRY(mercury____Index___mode_info__may_change_called_proc_0_0),
	ENTRY(mercury____Compare___mode_info__may_change_called_proc_0_0),
	(Integer) 0,
	(Word *) &mercury_data_mode_info__type_ctor_functors_may_change_called_proc_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_may_change_called_proc_0,
	MR_string_const("mode_info", 9),
	MR_string_const("may_change_called_proc", 22),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_mode_context_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__mode_context_0_0),
	ENTRY(mercury____Index___mode_info__mode_context_0_0),
	ENTRY(mercury____Compare___mode_info__mode_context_0_0),
	(Integer) 2,
	(Word *) &mercury_data_mode_info__type_ctor_functors_mode_context_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_mode_context_0,
	MR_string_const("mode_info", 9),
	MR_string_const("mode_context", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_mode_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__mode_info_0_0),
	ENTRY(mercury____Index___mode_info__mode_info_0_0),
	ENTRY(mercury____Compare___mode_info__mode_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_mode_info__type_ctor_functors_mode_info_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_mode_info_0,
	MR_string_const("mode_info", 9),
	MR_string_const("mode_info", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_side_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__side_0_0),
	ENTRY(mercury____Index___mode_info__side_0_0),
	ENTRY(mercury____Compare___mode_info__side_0_0),
	(Integer) 0,
	(Word *) &mercury_data_mode_info__type_ctor_functors_side_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_side_0,
	MR_string_const("mode_info", 9),
	MR_string_const("side", 4),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_mode_info__type_ctor_info_var_lock_reason_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___mode_info__var_lock_reason_0_0),
	ENTRY(mercury____Index___mode_info__var_lock_reason_0_0),
	ENTRY(mercury____Compare___mode_info__var_lock_reason_0_0),
	(Integer) 2,
	(Word *) &mercury_data_mode_info__type_ctor_functors_var_lock_reason_0,
	(Word *) &mercury_data_mode_info__type_ctor_layout_var_lock_reason_0,
	MR_string_const("mode_info", 9),
	MR_string_const("var_lock_reason", 15),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_mode_info__common_0_struct mercury_data_mode_info__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_mode_info__common_1_struct mercury_data_mode_info__common_1 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_mode_info__common_2_struct mercury_data_mode_info__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_mode_info__common_3_struct mercury_data_mode_info__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_mode_info__type_ctor_info_var_lock_reason_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_inst__type_ctor_info_inst_0;
static const struct mercury_data_mode_info__common_4_struct mercury_data_mode_info__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0),
	(Word *) &mercury_data_inst__type_ctor_info_inst_0
};

static const struct mercury_data_mode_info__common_5_struct mercury_data_mode_info__common_5 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1)
};

static const struct mercury_data_mode_info__common_6_struct mercury_data_mode_info__common_6 = {
	(Integer) 0,
	MR_string_const("if_then_else", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_pred_or_func_0;
static const struct mercury_data_mode_info__common_7_struct mercury_data_mode_info__common_7 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_pred_or_func_0
};

static const struct mercury_data_mode_info__common_8_struct mercury_data_mode_info__common_8 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_7),
	MR_string_const("lambda", 6),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_9_struct mercury_data_mode_info__common_9 = {
	(Integer) 0,
	MR_string_const("negation", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_10_struct mercury_data_mode_info__common_10 = {
	(Integer) 0,
	MR_string_const("par_conj", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_11_struct mercury_data_mode_info__common_11 = {
	(Integer) 0,
	(Integer) 3,
	MR_string_const("negation", 8),
	MR_string_const("if_then_else", 12),
	MR_string_const("par_conj", 8)
};

static const struct mercury_data_mode_info__common_12_struct mercury_data_mode_info__common_12 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("left", 4),
	MR_string_const("right", 5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_mode_info__common_13_struct mercury_data_mode_info__common_13 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_mode_info__common_14_struct mercury_data_mode_info__common_14 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_mode_info__common_15_struct mercury_data_mode_info__common_15 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
static const struct mercury_data_mode_info__common_16_struct mercury_data_mode_info__common_16 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_mode_info__common_17_struct mercury_data_mode_info__common_17 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_mode_info__common_18_struct mercury_data_mode_info__common_18 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_mode_info__common_19_struct mercury_data_mode_info__common_19 = {
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_mode_info__common_20_struct mercury_data_mode_info__common_20 = {
	(Word *) &mercury_data_mode_info__type_ctor_info_mode_context_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_instmap__type_ctor_info_instmap_0;
static const struct mercury_data_mode_info__common_21_struct mercury_data_mode_info__common_21 = {
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_mode_info__common_22_struct mercury_data_mode_info__common_22 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_delay_info__type_ctor_info_delay_info_0;
static const struct mercury_data_mode_info__common_23_struct mercury_data_mode_info__common_23 = {
	(Word *) &mercury_data_delay_info__type_ctor_info_delay_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
static const struct mercury_data_mode_info__common_24_struct mercury_data_mode_info__common_24 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0
};

static const struct mercury_data_mode_info__common_25_struct mercury_data_mode_info__common_25 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1)
};

static const struct mercury_data_mode_info__common_26_struct mercury_data_mode_info__common_26 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_4)
};

static const struct mercury_data_mode_info__common_27_struct mercury_data_mode_info__common_27 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_mode_info__common_28_struct mercury_data_mode_info__common_28 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_mode_info__common_29_struct mercury_data_mode_info__common_29 = {
	(Word *) &mercury_data_mode_info__type_ctor_info_how_to_check_goal_0
};

static const struct mercury_data_mode_info__common_30_struct mercury_data_mode_info__common_30 = {
	(Word *) &mercury_data_mode_info__type_ctor_info_may_change_called_proc_0
};

static const struct mercury_data_mode_info__common_31_struct mercury_data_mode_info__common_31 = {
	(Integer) 20,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_28),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_29),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_28),
	MR_string_const("mode_info", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_call_id_0;
static const struct mercury_data_mode_info__common_32_struct mercury_data_mode_info__common_32 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_call_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_mode_info__common_33_struct mercury_data_mode_info__common_33 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_mode_info__common_34_struct mercury_data_mode_info__common_34 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_32),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_33),
	MR_string_const("call", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_unify_context_0;
static const struct mercury_data_mode_info__common_35_struct mercury_data_mode_info__common_35 = {
	(Word *) &mercury_data_hlds_goal__type_ctor_info_unify_context_0
};

static const struct mercury_data_mode_info__common_36_struct mercury_data_mode_info__common_36 = {
	(Word *) &mercury_data_mode_info__type_ctor_info_side_0
};

static const struct mercury_data_mode_info__common_37_struct mercury_data_mode_info__common_37 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_35),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_36),
	MR_string_const("unify", 5),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_38_struct mercury_data_mode_info__common_38 = {
	(Integer) 0,
	MR_string_const("uninitialized", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_39_struct mercury_data_mode_info__common_39 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("uninitialized", 13)
};

static const struct mercury_data_mode_info__common_40_struct mercury_data_mode_info__common_40 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("may_change_called_proc", 22),
	MR_string_const("may_not_change_called_proc", 26)
};

static const struct mercury_data_mode_info__common_41_struct mercury_data_mode_info__common_41 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_22)
};

static const struct mercury_data_mode_info__common_42_struct mercury_data_mode_info__common_42 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("check_modes", 11),
	MR_string_const("check_unique_modes", 18)
};

static const struct mercury_data_mode_info__common_43_struct mercury_data_mode_info__common_43 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_32),
	MR_string_const("call", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__common_44_struct mercury_data_mode_info__common_44 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_35),
	MR_string_const("unify", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_mode_info__type_ctor_functors_var_lock_reason_0_struct mercury_data_mode_info__type_ctor_functors_var_lock_reason_0 = {
	(Integer) 0,
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_10)
};

static const struct mercury_data_mode_info__type_ctor_layout_var_lock_reason_0_struct mercury_data_mode_info__type_ctor_layout_var_lock_reason_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_11),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_mode_info__type_ctor_functors_side_0_struct mercury_data_mode_info__type_ctor_functors_side_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_12)
};

static const struct mercury_data_mode_info__type_ctor_layout_side_0_struct mercury_data_mode_info__type_ctor_layout_side_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_12)
};

static const struct mercury_data_mode_info__type_ctor_functors_mode_info_0_struct mercury_data_mode_info__type_ctor_functors_mode_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_31)
};

static const struct mercury_data_mode_info__type_ctor_layout_mode_info_0_struct mercury_data_mode_info__type_ctor_layout_mode_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_31),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_mode_info__type_ctor_functors_mode_context_0_struct mercury_data_mode_info__type_ctor_functors_mode_context_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_37),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_38)
};

static const struct mercury_data_mode_info__type_ctor_layout_mode_context_0_struct mercury_data_mode_info__type_ctor_layout_mode_context_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_39),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_34),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_37),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_mode_info__type_ctor_functors_may_change_called_proc_0_struct mercury_data_mode_info__type_ctor_functors_may_change_called_proc_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_40)
};

static const struct mercury_data_mode_info__type_ctor_layout_may_change_called_proc_0_struct mercury_data_mode_info__type_ctor_layout_may_change_called_proc_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_40)
};

static const struct mercury_data_mode_info__type_ctor_functors_locked_vars_0_struct mercury_data_mode_info__type_ctor_functors_locked_vars_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_22)
};

static const struct mercury_data_mode_info__type_ctor_layout_locked_vars_0_struct mercury_data_mode_info__type_ctor_layout_locked_vars_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_mode_info__common_41),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_mode_info__common_41),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_mode_info__common_41),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_mode_info__common_41)
};

static const struct mercury_data_mode_info__type_ctor_functors_how_to_check_goal_0_struct mercury_data_mode_info__type_ctor_functors_how_to_check_goal_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_42)
};

static const struct mercury_data_mode_info__type_ctor_layout_how_to_check_goal_0_struct mercury_data_mode_info__type_ctor_layout_how_to_check_goal_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_42),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_42),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_42),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_42)
};

static const struct mercury_data_mode_info__type_ctor_functors_call_context_0_struct mercury_data_mode_info__type_ctor_functors_call_context_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_43),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_44)
};

static const struct mercury_data_mode_info__type_ctor_layout_call_context_0_struct mercury_data_mode_info__type_ctor_layout_call_context_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_44),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_mode_info__common_43),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(mode_info_module0)
	init_entry(mercury____Index___mode_info__mode_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___mode_info__mode_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___mode_info__mode_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_inst_var_type_0;
Declare_entry(mercury__varset__init_1_0);

BEGIN_MODULE(mode_info_module1)
	init_entry(mercury__mode_info__mode_info_get_instvarset__ua0_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instvarset__ua0'/2 in mode 0 */
Define_static(mercury__mode_info__mode_info_get_instvarset__ua0_2_0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	tailcall(ENTRY(mercury__varset__init_1_0),
		STATIC(mercury__mode_info__mode_info_get_instvarset__ua0_2_0));
END_MODULE

Declare_entry(mercury__mode_errors__mode_context_init_1_0);
Declare_entry(mercury__delay_info__init_1_0);
Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);

BEGIN_MODULE(mode_info_module2)
	init_entry(mercury__mode_info__mode_info_init_10_0);
	init_label(mercury__mode_info__mode_info_init_10_0_i2);
	init_label(mercury__mode_info__mode_info_init_10_0_i3);
	init_label(mercury__mode_info__mode_info_init_10_0_i4);
	init_label(mercury__mode_info__mode_info_init_10_0_i5);
	init_label(mercury__mode_info__mode_info_init_10_0_i6);
	init_label(mercury__mode_info__mode_info_init_10_0_i7);
	init_label(mercury__mode_info__mode_info_init_10_0_i8);
	init_label(mercury__mode_info__mode_info_init_10_0_i9);
BEGIN_CODE

/* code for predicate 'mode_info_init'/10 in mode 0 */
Define_entry(mercury__mode_info__mode_info_init_10_0);
	MR_incr_sp_push_msg(13, "mode_info:mode_info_init/10");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r9;
	call_localret(ENTRY(mercury__mode_errors__mode_context_init_1_0),
		mercury__mode_info__mode_info_init_10_0_i2,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	MR_stackvar(10) = r1;
	call_localret(ENTRY(mercury__delay_info__init_1_0),
		mercury__mode_info__mode_info_init_10_0_i3,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__mode_info__mode_info_init_10_0_i4,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__mode_info__mode_info_init_10_0_i5,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__mode_info__mode_info_init_10_0_i6,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__mode_info__mode_info_init_10_0_i7,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__mode_info__mode_info_init_10_0_i8,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i8);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__mode_info__mode_info_init_10_0_i9,
		ENTRY(mercury__mode_info__mode_info_init_10_0));
Define_label(mercury__mode_info__mode_info_init_10_0_i9);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_init_10_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_init_10_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_init_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 12) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_init_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 13) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 14) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 16) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 19) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module3)
	init_entry(mercury__mode_info__mode_info_get_io_state_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_io_state'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_io_state_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module4)
	init_entry(mercury__mode_info__mode_info_set_io_state_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_io_state'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_io_state_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_io_state_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module5)
	init_entry(mercury__mode_info__mode_info_get_module_info_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_module_info'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_module_info_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module6)
	init_entry(mercury__mode_info__mode_info_set_module_info_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_module_info'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_module_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_module_info_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module7)
	init_entry(mercury__mode_info__mode_info_get_preds_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_preds'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_preds_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		ENTRY(mercury__mode_info__mode_info_get_preds_2_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_modes_2_0);

BEGIN_MODULE(mode_info_module8)
	init_entry(mercury__mode_info__mode_info_get_modes_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_modes'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_modes_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(ENTRY(mercury__hlds_module__module_info_modes_2_0),
		ENTRY(mercury__mode_info__mode_info_get_modes_2_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_insts_2_0);

BEGIN_MODULE(mode_info_module9)
	init_entry(mercury__mode_info__mode_info_get_insts_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_insts'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_insts_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(ENTRY(mercury__hlds_module__module_info_insts_2_0),
		ENTRY(mercury__mode_info__mode_info_get_insts_2_0));
END_MODULE


BEGIN_MODULE(mode_info_module10)
	init_entry(mercury__mode_info__mode_info_get_predid_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_predid'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_predid_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module11)
	init_entry(mercury__mode_info__mode_info_get_procid_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_procid'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_procid_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module12)
	init_entry(mercury__mode_info__mode_info_get_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_context_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module13)
	init_entry(mercury__mode_info__mode_info_set_context_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_context_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_context_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module14)
	init_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_mode_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_mode_context_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module15)
	init_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_mode_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_mode_context_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_mode_context_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module16)
	init_entry(mercury__mode_info__mode_info_set_call_context_3_0);
	init_label(mercury__mode_info__mode_info_set_call_context_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_set_call_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_call_context_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_context_3_0_i3);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_call_context_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__mode_info__mode_info_set_call_context_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Integer) 0;
	proceed();
	}
Define_label(mercury__mode_info__mode_info_set_call_context_3_0_i3);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_call_context_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_set_call_context_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Integer) 0;
	proceed();
	}
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(mode_info_module17)
	init_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	init_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
	init_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i4);
BEGIN_CODE

/* code for predicate 'mode_info_set_call_arg_context'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_call_arg_context_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_call_arg_context_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_set_call_arg_context_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	proceed();
	}
Define_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i2);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__mode_info__mode_info_set_call_arg_context_3_0_i4);
	r1 = r2;
	proceed();
Define_label(mercury__mode_info__mode_info_set_call_arg_context_3_0_i4);
	r1 = (Word) MR_string_const("mode_info_set_call_arg_context", 30);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__mode_info__mode_info_set_call_arg_context_3_0));
END_MODULE


BEGIN_MODULE(mode_info_module18)
	init_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_unset_call_context'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_unset_call_context_2_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module19)
	init_entry(mercury__mode_info__mode_info_get_instmap_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instmap'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_instmap_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module20)
	init_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_dcg_get_instmap'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	proceed();
END_MODULE

Declare_entry(mercury__instmap__is_unreachable_1_0);
Declare_entry(mercury__instmap__is_reachable_1_0);
Declare_entry(mercury__delay_info__bind_all_vars_2_0);

BEGIN_MODULE(mode_info_module21)
	init_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i3);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i5);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i7);
	init_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
BEGIN_CODE

/* code for predicate 'mode_info_set_instmap'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_instmap_3_0);
	MR_incr_sp_push_msg(22, "mode_info:mode_info_set_instmap/3");
	MR_stackvar(22) = (Word) MR_succip;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i3,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i5,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__delay_info__bind_all_vars_2_0),
		mercury__mode_info__mode_info_set_instmap_3_0_i7,
		ENTRY(mercury__mode_info__mode_info_set_instmap_3_0));
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_instmap_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_instmap_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_stackvar(14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_stackvar(15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_stackvar(16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_stackvar(17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_stackvar(18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_stackvar(19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_stackvar(20);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_stackvar(21);
	MR_succip = (Code *) MR_stackvar(22);
	MR_decr_sp_pop_msg(22);
	proceed();
Define_label(mercury__mode_info__mode_info_set_instmap_3_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_instmap_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_stackvar(14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_stackvar(15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_stackvar(16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_stackvar(17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_stackvar(18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_stackvar(19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_stackvar(20);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_stackvar(21);
	MR_succip = (Code *) MR_stackvar(22);
	MR_decr_sp_pop_msg(22);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module22)
	init_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_locked_vars'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_locked_vars_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module23)
	init_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_locked_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_locked_vars_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_locked_vars_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module24)
	init_entry(mercury__mode_info__mode_info_get_errors_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_errors'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_errors_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	proceed();
END_MODULE

Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(mode_info_module25)
	init_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_num_errors'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_num_errors_2_0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	r1 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
	tailcall(ENTRY(mercury__list__length_2_0),
		ENTRY(mercury__mode_info__mode_info_get_num_errors_2_0));
END_MODULE


BEGIN_MODULE(mode_info_module26)
	init_entry(mercury__mode_info__mode_info_set_errors_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_errors'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_errors_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_errors_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module27)
	init_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_add_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_add_live_vars_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_add_live_vars_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_add_live_vars_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE

Declare_entry(mercury__list__delete_first_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__delay_info__bind_var_list_3_0);

BEGIN_MODULE(mode_info_module28)
	init_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i5);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i2);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i7);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
	init_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
BEGIN_CODE

/* code for predicate 'mode_info_remove_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
	MR_incr_sp_push_msg(21, "mode_info:mode_info_remove_live_vars/3");
	MR_stackvar(21) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i3,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i3);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(14);
	MR_stackvar(14) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i5,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
	}
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0_i2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_remove_live_vars_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 13) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 19) = MR_stackvar(20);
	MR_field(MR_mktag(0), r3, (Integer) 18) = MR_stackvar(19);
	MR_field(MR_mktag(0), r3, (Integer) 17) = MR_stackvar(18);
	MR_field(MR_mktag(0), r3, (Integer) 16) = MR_stackvar(17);
	MR_field(MR_mktag(0), r3, (Integer) 15) = MR_stackvar(16);
	MR_field(MR_mktag(0), r3, (Integer) 14) = MR_stackvar(15);
	MR_field(MR_mktag(0), r3, (Integer) 12) = MR_stackvar(14);
	MR_field(MR_mktag(0), r3, (Integer) 11) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_stackvar(12);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(10);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i9,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i2);
	r1 = (Word) MR_string_const("mode_info_remove_live_vars: failed", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i7,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i7);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i9,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i9);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 10);
	call_localret(ENTRY(mercury__delay_info__bind_var_list_3_0),
		mercury__mode_info__mode_info_remove_live_vars_3_0_i10,
		ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0));
Define_label(mercury__mode_info__mode_info_remove_live_vars_3_0_i10);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_remove_live_vars_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_remove_live_vars_3_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = r2;
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module29)
	init_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
	init_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_var_list_is_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_list_is_live_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0_i3);
	MR_incr_sp_push_msg(3, "mode_info:mode_info_var_list_is_live/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r3 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__mode_info__mode_info_var_is_live_3_0),
		mercury__mode_info__mode_info_var_list_is_live_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_var_list_is_live_3_0));
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__mode_info__mode_info_var_list_is_live_3_0,
		LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0_i5),
		ENTRY(mercury__mode_info__mode_info_var_list_is_live_3_0));
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_list_is_live_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_var_list_is_live_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mode_info__mode_info_var_list_is_live_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__set__member_2_0);
Declare_entry(do_redo);

BEGIN_MODULE(mode_info_module30)
	init_entry(mercury__mode_info__mode_info_var_is_live_3_0);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i1011);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i1017);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i9);
	init_label(mercury__mode_info__mode_info_var_is_live_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_live_3_0);
	MR_incr_sp_push_msg(5, "mode_info:mode_info_var_is_live/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i1017);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__mode_info__mode_info_var_is_live_3_0_i6,
		ENTRY(mercury__mode_info__mode_info_var_is_live_3_0));
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_live_3_0_i1011,
		ENTRY(mercury__mode_info__mode_info_var_is_live_3_0));
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i1011);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i9);
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i1017);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_live_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_live_3_0_i3);
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i9);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_live_3_0_i3);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module31)
	init_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1011);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1017);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i9);
	init_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_nondet_live'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);
	MR_incr_sp_push_msg(5, "mode_info:mode_info_var_is_nondet_live/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1017);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6,
		ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i6);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1011,
		ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1011);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i9);
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i1017);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i3);
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i9);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_nondet_live_3_0_i3);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(mode_info_module32)
	init_entry(mercury__mode_info__mode_info_get_liveness_2_0);
	init_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_get_liveness'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_liveness_2_0);
	MR_incr_sp_push_msg(2, "mode_info:mode_info_get_liveness/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__mode_info__mode_info_get_liveness_2_0_i2,
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_0));
Define_label(mercury__mode_info__mode_info_get_liveness_2_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_liveness_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__mode_info__mode_info_get_liveness_2_3_0),
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_0));
END_MODULE

Declare_entry(mercury__set__union_3_0);

BEGIN_MODULE(mode_info_module33)
	init_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
	init_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1001);
	init_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
	init_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_get_liveness_2'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_liveness_2_3_0);
	MR_incr_sp_push_msg(2, "mode_info:mode_info_get_liveness_2/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_get_liveness_2_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__mode_info__mode_info_get_liveness_2_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_get_liveness_2_3_0));
Define_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_liveness_2_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__mode_info__mode_info_get_liveness_2_3_0_i1001);
Define_label(mercury__mode_info__mode_info_get_liveness_2_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module34)
	init_entry(mercury__mode_info__mode_info_get_varset_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_varset'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_varset_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module35)
	init_entry(mercury__mode_info__mode_info_set_varset_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_varset'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_varset_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_varset_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module36)
	init_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_instvarset'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_instvarset_2_0);
	tailcall(STATIC(mercury__mode_info__mode_info_get_instvarset__ua0_2_0),
		ENTRY(mercury__mode_info__mode_info_get_instvarset_2_0));
END_MODULE


BEGIN_MODULE(mode_info_module37)
	init_entry(mercury__mode_info__mode_info_get_var_types_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_var_types'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_var_types_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module38)
	init_entry(mercury__mode_info__mode_info_set_var_types_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_var_types'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_var_types_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_var_types_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE

Declare_entry(mercury__map__apply_to_list_3_0);

BEGIN_MODULE(mode_info_module39)
	init_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_types_of_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_types_of_vars_3_0);
	r3 = r2;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_2);
	tailcall(ENTRY(mercury__map__apply_to_list_3_0),
		ENTRY(mercury__mode_info__mode_info_get_types_of_vars_3_0));
END_MODULE


BEGIN_MODULE(mode_info_module40)
	init_entry(mercury__mode_info__mode_info_lock_vars_4_0);
BEGIN_CODE

/* code for predicate 'mode_info_lock_vars'/4 in mode 0 */
Define_entry(mercury__mode_info__mode_info_lock_vars_4_0);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_lock_vars_4_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_lock_vars_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__mode_info__mode_info_lock_vars_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 9) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	proceed();
	}
END_MODULE

Declare_entry(mercury__set__equal_2_0);

BEGIN_MODULE(mode_info_module41)
	init_entry(mercury__mode_info__mode_info_unlock_vars_4_0);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i8);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i10);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i7);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i14);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i1014);
	init_label(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'mode_info_unlock_vars'/4 in mode 0 */
Define_entry(mercury__mode_info__mode_info_unlock_vars_4_0);
	MR_incr_sp_push_msg(3, "mode_info:mode_info_unlock_vars/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i1014);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i7);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i1014);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__mode_info__mode_info_unlock_vars_4_0_i14,
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i8);
	if (((Integer) MR_unmkbody(r1) != (Integer) 1))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i10);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__mode_info__mode_info_unlock_vars_4_0_i14,
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i10);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__mode_info__mode_info_unlock_vars_4_0_i14,
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i7);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0)))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	MR_stackvar(1) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	call_localret(ENTRY(mercury__set__equal_2_0),
		mercury__mode_info__mode_info_unlock_vars_4_0_i14,
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
	}
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i14);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_unlock_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_unlock_vars_4_0, "origin_lost_in_value_number");
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i1014);
	r1 = (Word) MR_string_const("mode_info_unlock_vars: some kind of nesting error", 49);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
Define_label(mercury__mode_info__mode_info_unlock_vars_4_0_i3);
	r1 = (Word) MR_string_const("mode_info_unlock_vars: some kind of nesting error", 49);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0));
END_MODULE


BEGIN_MODULE(mode_info_module42)
	init_entry(mercury__mode_info__mode_info_var_is_locked_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_locked'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_locked_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	tailcall(STATIC(mercury__mode_info__mode_info_var_is_locked_2_3_0),
		ENTRY(mercury__mode_info__mode_info_var_is_locked_3_0));
END_MODULE


BEGIN_MODULE(mode_info_module43)
	init_entry(mercury__mode_info__mode_info_var_is_locked_2_3_0);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1002);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i4);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i3);
	init_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'mode_info_var_is_locked_2'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_var_is_locked_2_3_0);
	MR_incr_sp_push_msg(4, "mode_info:mode_info_var_is_locked_2/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__mode_info__mode_info_var_is_locked_2_3_0_i4,
		ENTRY(mercury__mode_info__mode_info_var_is_locked_2_3_0));
	}
Define_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_var_is_locked_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__mode_info__mode_info_var_is_locked_2_3_0_i3);
	r2 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i3);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1002);
Define_label(mercury__mode_info__mode_info_var_is_locked_2_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module44)
	init_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_delay_info'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_delay_info_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module45)
	init_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_delay_info'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_delay_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_delay_info_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module46)
	init_entry(mercury__mode_info__mode_info_get_live_vars_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_live_vars'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_live_vars_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module47)
	init_entry(mercury__mode_info__mode_info_set_live_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_live_vars_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_live_vars_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module48)
	init_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_nondet_live_vars'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module49)
	init_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_nondet_live_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_nondet_live_vars_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module50)
	init_entry(mercury__mode_info__mode_info_get_last_checkpoint_insts_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_last_checkpoint_insts'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_last_checkpoint_insts_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module51)
	init_entry(mercury__mode_info__mode_info_set_last_checkpoint_insts_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_last_checkpoint_insts'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_last_checkpoint_insts_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_last_checkpoint_insts_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module52)
	init_entry(mercury__mode_info__mode_info_get_parallel_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_parallel_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_parallel_vars_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module53)
	init_entry(mercury__mode_info__mode_info_set_parallel_vars_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_parallel_vars'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_parallel_vars_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_parallel_vars_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module54)
	init_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_changed_flag'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_changed_flag_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module55)
	init_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_changed_flag'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_changed_flag_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_changed_flag_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module56)
	init_entry(mercury__mode_info__mode_info_get_how_to_check_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_how_to_check'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_how_to_check_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module57)
	init_entry(mercury__mode_info__mode_info_set_how_to_check_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_how_to_check'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_how_to_check_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_how_to_check_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module58)
	init_entry(mercury__mode_info__mode_info_get_may_change_called_proc_2_0);
BEGIN_CODE

/* code for predicate 'mode_info_get_may_change_called_proc'/2 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_may_change_called_proc_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module59)
	init_entry(mercury__mode_info__mode_info_set_may_change_called_proc_3_0);
BEGIN_CODE

/* code for predicate 'mode_info_set_may_change_called_proc'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_may_change_called_proc_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_may_change_called_proc_3_0, "mode_info:mode_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module60)
	init_entry(mercury__mode_info__mode_info_set_checking_extra_goals_3_0);
	init_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i5);
	init_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_set_checking_extra_goals'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_set_checking_extra_goals_3_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_set_checking_extra_goals_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r3, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r3, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r3, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r3, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r3, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r3, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r3, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r3, (Integer) 19) = r1;
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 19) != (Integer) 1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i2);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i2);
	MR_incr_sp_push_msg(2, "mode_info:mode_info_set_checking_extra_goals/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("mode analysis: rechecking extra goals adds more extra goals", 59);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i5,
		ENTRY(mercury__mode_info__mode_info_set_checking_extra_goals_3_0));
Define_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i5);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_set_checking_extra_goals_3_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__mode_info__mode_info_set_checking_extra_goals_3_0_i2);
	r1 = r3;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_get_call_id_2_0);

BEGIN_MODULE(mode_info_module61)
	init_entry(mercury__mode_info__mode_info_get_call_id_3_0);
	init_label(mercury__mode_info__mode_info_get_call_id_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_get_call_id'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_get_call_id_3_0);
	MR_incr_sp_push_msg(1, "mode_info:mode_info_get_call_id/3");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__mode_info__mode_info_get_call_id_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_get_call_id_3_0));
Define_label(mercury__mode_info__mode_info_get_call_id_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_get_call_id_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__hlds_pred__pred_info_get_call_id_2_0),
		ENTRY(mercury__mode_info__mode_info_get_call_id_3_0));
END_MODULE


BEGIN_MODULE(mode_info_module62)
	init_entry(mercury__mode_info__mode_info_error_4_0);
BEGIN_CODE

/* code for predicate 'mode_info_error'/4 in mode 0 */
Define_entry(mercury__mode_info__mode_info_error_4_0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__mode_info__mode_info_error_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	r2 = r3;
	tailcall(STATIC(mercury__mode_info__mode_info_add_error_3_0),
		ENTRY(mercury__mode_info__mode_info_error_4_0));
	}
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(mode_info_module63)
	init_entry(mercury__mode_info__mode_info_add_error_3_0);
	init_label(mercury__mode_info__mode_info_add_error_3_0_i2);
BEGIN_CODE

/* code for predicate 'mode_info_add_error'/3 in mode 0 */
Define_entry(mercury__mode_info__mode_info_add_error_3_0);
	MR_incr_sp_push_msg(2, "mode_info:mode_info_add_error/3");
	MR_stackvar(2) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__mode_info__mode_info_add_error_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	r1 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__mode_info__mode_info_add_error_3_0_i2,
		ENTRY(mercury__mode_info__mode_info_add_error_3_0));
Define_label(mercury__mode_info__mode_info_add_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__mode_info__mode_info_add_error_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 20, mercury__mode_info__mode_info_add_error_3_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 19) = MR_const_field(MR_mktag(0), r3, (Integer) 19);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 11) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_goal__unify_context_0_0);
Declare_entry(mercury____Unify___hlds_pred__call_id_0_0);

BEGIN_MODULE(mode_info_module64)
	init_entry(mercury____Unify___mode_info__mode_context_0_0);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i8);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i10);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i4);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i6);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1012);
	init_label(mercury____Unify___mode_info__mode_context_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__mode_context_0_0);
	MR_incr_sp_push_msg(3, "mode_info:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i8);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1012);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i8);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_goal__unify_context_0_0),
		mercury____Unify___mode_info__mode_context_0_0_i10,
		ENTRY(mercury____Unify___mode_info__mode_context_0_0));
Define_label(mercury____Unify___mode_info__mode_context_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_context_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__call_id_0_0),
		mercury____Unify___mode_info__mode_context_0_0_i6,
		ENTRY(mercury____Unify___mode_info__mode_context_0_0));
Define_label(mercury____Unify___mode_info__mode_context_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_context_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(2)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_context_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1012);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___mode_info__mode_context_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module65)
	init_entry(mercury____Index___mode_info__mode_context_0_0);
	init_label(mercury____Index___mode_info__mode_context_0_0_i5);
	init_label(mercury____Index___mode_info__mode_context_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__mode_context_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___mode_info__mode_context_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___mode_info__mode_context_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___mode_info__mode_context_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___mode_info__mode_context_0_0_i4);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___hlds_goal__unify_context_0_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___hlds_pred__call_id_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(mode_info_module66)
	init_entry(mercury____Compare___mode_info__mode_context_0_0);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i5);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i4);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i2);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i9);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i8);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i6);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i10);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i11);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i24);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i27);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i16);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i19);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i1021);
	init_label(mercury____Compare___mode_info__mode_context_0_0_i36);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__mode_context_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i2);
Define_label(mercury____Compare___mode_info__mode_context_0_0_i5);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i2);
Define_label(mercury____Compare___mode_info__mode_context_0_0_i4);
	r3 = (Integer) 0;
Define_label(mercury____Compare___mode_info__mode_context_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i6);
	}
Define_label(mercury____Compare___mode_info__mode_context_0_0_i9);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i6);
Define_label(mercury____Compare___mode_info__mode_context_0_0_i8);
	r4 = (Integer) 0;
Define_label(mercury____Compare___mode_info__mode_context_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i24);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i1021);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___mode_info__mode_context_0_0_i24);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i1021);
	MR_incr_sp_push_msg(3, "mode_info:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_goal__unify_context_0_0),
		mercury____Compare___mode_info__mode_context_0_0_i27,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
Define_label(mercury____Compare___mode_info__mode_context_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i36);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
Define_label(mercury____Compare___mode_info__mode_context_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i1021);
	MR_incr_sp_push_msg(3, "mode_info:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_pred__call_id_0_0),
		mercury____Compare___mode_info__mode_context_0_0_i19,
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
Define_label(mercury____Compare___mode_info__mode_context_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_context_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_context_0_0_i36);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
Define_label(mercury____Compare___mode_info__mode_context_0_0_i1021);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mode_info__mode_context_0_0));
Define_label(mercury____Compare___mode_info__mode_context_0_0_i36);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module67)
	init_entry(mercury____Unify___mode_info__side_0_0);
	init_label(mercury____Unify___mode_info__side_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__side_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___mode_info__side_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__side_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module68)
	init_entry(mercury____Index___mode_info__side_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__side_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module69)
	init_entry(mercury____Compare___mode_info__side_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__side_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__side_0_0));
END_MODULE


BEGIN_MODULE(mode_info_module70)
	init_entry(mercury____Unify___mode_info__call_context_0_0);
	init_label(mercury____Unify___mode_info__call_context_0_0_i3);
	init_label(mercury____Unify___mode_info__call_context_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__call_context_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Unify___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Unify___mode_info__call_context_0_0));
Define_label(mercury____Unify___mode_info__call_context_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___mode_info__call_context_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Unify___hlds_pred__call_id_0_0),
		ENTRY(mercury____Unify___mode_info__call_context_0_0));
Define_label(mercury____Unify___mode_info__call_context_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module71)
	init_entry(mercury____Index___mode_info__call_context_0_0);
	init_label(mercury____Index___mode_info__call_context_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__call_context_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___mode_info__call_context_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___mode_info__call_context_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module72)
	init_entry(mercury____Compare___mode_info__call_context_0_0);
	init_label(mercury____Compare___mode_info__call_context_0_0_i3);
	init_label(mercury____Compare___mode_info__call_context_0_0_i2);
	init_label(mercury____Compare___mode_info__call_context_0_0_i5);
	init_label(mercury____Compare___mode_info__call_context_0_0_i4);
	init_label(mercury____Compare___mode_info__call_context_0_0_i6);
	init_label(mercury____Compare___mode_info__call_context_0_0_i7);
	init_label(mercury____Compare___mode_info__call_context_0_0_i11);
	init_label(mercury____Compare___mode_info__call_context_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__call_context_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i2);
Define_label(mercury____Compare___mode_info__call_context_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___mode_info__call_context_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i4);
Define_label(mercury____Compare___mode_info__call_context_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___mode_info__call_context_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___mode_info__call_context_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___mode_info__call_context_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i1014);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___hlds_goal__unify_context_0_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
Define_label(mercury____Compare___mode_info__call_context_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__call_context_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___hlds_pred__call_id_0_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
Define_label(mercury____Compare___mode_info__call_context_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mode_info__call_context_0_0));
END_MODULE


BEGIN_MODULE(mode_info_module73)
	init_entry(mercury____Unify___mode_info__var_lock_reason_0_0);
	init_label(mercury____Unify___mode_info__var_lock_reason_0_0_i5);
	init_label(mercury____Unify___mode_info__var_lock_reason_0_0_i7);
	init_label(mercury____Unify___mode_info__var_lock_reason_0_0_i4);
	init_label(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__var_lock_reason_0_0);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i4);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__var_lock_reason_0_0_i5);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i7);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__var_lock_reason_0_0_i7);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__var_lock_reason_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__var_lock_reason_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module74)
	init_entry(mercury____Index___mode_info__var_lock_reason_0_0);
	init_label(mercury____Index___mode_info__var_lock_reason_0_0_i5);
	init_label(mercury____Index___mode_info__var_lock_reason_0_0_i6);
	init_label(mercury____Index___mode_info__var_lock_reason_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__var_lock_reason_0_0);
	r2 = MR_tag(r1);
	if ((r2 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___mode_info__var_lock_reason_0_0_i4);
	r2 = MR_unmkbody(r1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury____Index___mode_info__var_lock_reason_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___mode_info__var_lock_reason_0_0_i5);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury____Index___mode_info__var_lock_reason_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___mode_info__var_lock_reason_0_0_i6);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___mode_info__var_lock_reason_0_0_i4);
	r1 = (Integer) 2;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module75)
	init_entry(mercury____Compare___mode_info__var_lock_reason_0_0);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i5);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i6);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i4);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i10);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i11);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i9);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i12);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i13);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i19);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i21);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i18);
	init_label(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__var_lock_reason_0_0);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i4);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i5);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i5);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i6);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i6);
	r3 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i4);
	r3 = (Integer) 2;
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i9);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i10);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i10);
	if (((Integer) MR_unmkbody(r2) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i11);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i11);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i9);
	r4 = (Integer) 2;
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i7);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i12);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i12);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i13);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i13);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i18);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i19);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i19);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i21);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i21);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i18);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__var_lock_reason_0_0));
Define_label(mercury____Compare___mode_info__var_lock_reason_0_0_i1024);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___mode_info__var_lock_reason_0_0));
END_MODULE


BEGIN_MODULE(mode_info_module76)
	init_entry(mercury____Unify___mode_info__how_to_check_goal_0_0);
	init_label(mercury____Unify___mode_info__how_to_check_goal_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__how_to_check_goal_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___mode_info__how_to_check_goal_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__how_to_check_goal_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module77)
	init_entry(mercury____Index___mode_info__how_to_check_goal_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__how_to_check_goal_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module78)
	init_entry(mercury____Compare___mode_info__how_to_check_goal_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__how_to_check_goal_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__how_to_check_goal_0_0));
END_MODULE


BEGIN_MODULE(mode_info_module79)
	init_entry(mercury____Unify___mode_info__may_change_called_proc_0_0);
	init_label(mercury____Unify___mode_info__may_change_called_proc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__may_change_called_proc_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___mode_info__may_change_called_proc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__may_change_called_proc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module80)
	init_entry(mercury____Index___mode_info__may_change_called_proc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__may_change_called_proc_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module81)
	init_entry(mercury____Compare___mode_info__may_change_called_proc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__may_change_called_proc_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__may_change_called_proc_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(mode_info_module82)
	init_entry(mercury____Unify___mode_info__locked_vars_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__locked_vars_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___mode_info__locked_vars_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(mode_info_module83)
	init_entry(mercury____Index___mode_info__locked_vars_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__locked_vars_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___mode_info__locked_vars_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(mode_info_module84)
	init_entry(mercury____Compare___mode_info__locked_vars_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__locked_vars_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___mode_info__locked_vars_0_0));
END_MODULE

Declare_entry(mercury____Unify___io__state_0_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);
Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___term__context_0_0);
Declare_entry(mercury____Unify___instmap__instmap_0_0);
Declare_entry(mercury____Unify___delay_info__delay_info_0_0);

BEGIN_MODULE(mode_info_module85)
	init_entry(mercury____Unify___mode_info__mode_info_0_0);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i2);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i4);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i6);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i8);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i10);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i12);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i14);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i16);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i18);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i20);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i22);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i24);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i26);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i28);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i30);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i32);
	init_label(mercury____Unify___mode_info__mode_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___mode_info__mode_info_0_0);
	MR_incr_sp_push_msg(39, "mode_info:__Unify__/2");
	MR_stackvar(39) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r1, (Integer) 19);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(27) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(28) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(29) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(30) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(31) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(32) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(33) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(34) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(35) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(36) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(37) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_stackvar(38) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___io__state_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i2,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i4,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i6,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(22);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i8,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i10,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_2);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___mode_info__mode_info_0_0_i12,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury____Unify___term__context_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i14,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(26);
	call_localret(STATIC(mercury____Unify___mode_info__mode_context_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i16,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(27);
	call_localret(ENTRY(mercury____Unify___instmap__instmap_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i18,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(28);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i20,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(29);
	call_localret(ENTRY(mercury____Unify___delay_info__delay_info_0_0),
		mercury____Unify___mode_info__mode_info_0_0_i22,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(30);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i24,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i24);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(31);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i26,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	r2 = MR_stackvar(13);
	r3 = MR_stackvar(32);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i28,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i28);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_4);
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(33);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i30,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i30);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_5);
	r2 = MR_stackvar(15);
	r3 = MR_stackvar(34);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___mode_info__mode_info_0_0_i32,
		ENTRY(mercury____Unify___mode_info__mode_info_0_0));
Define_label(mercury____Unify___mode_info__mode_info_0_0_i32);
	update_prof_current_proc(LABEL(mercury____Unify___mode_info__mode_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if ((MR_stackvar(16) != MR_stackvar(35)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if ((MR_stackvar(17) != MR_stackvar(36)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if ((MR_stackvar(18) != MR_stackvar(37)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	if ((MR_stackvar(19) != MR_stackvar(38)))
		GOTO_LABEL(mercury____Unify___mode_info__mode_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(39);
	MR_decr_sp_pop_msg(39);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___mode_info__mode_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(39);
	MR_decr_sp_pop_msg(39);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(mode_info_module86)
	init_entry(mercury____Index___mode_info__mode_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___mode_info__mode_info_0_0);
	tailcall(STATIC(mercury____Index___mode_info__mode_info_0__ua0_2_0),
		ENTRY(mercury____Index___mode_info__mode_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___io__state_0_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_id_0_0);
Declare_entry(mercury____Compare___hlds_pred__proc_id_0_0);
Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___term__context_0_0);
Declare_entry(mercury____Compare___instmap__instmap_0_0);
Declare_entry(mercury____Compare___delay_info__delay_info_0_0);

BEGIN_MODULE(mode_info_module87)
	init_entry(mercury____Compare___mode_info__mode_info_0_0);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i3);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i7);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i11);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i15);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i19);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i23);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i27);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i31);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i35);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i39);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i43);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i47);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i51);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i55);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i59);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i63);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i67);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i71);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i75);
	init_label(mercury____Compare___mode_info__mode_info_0_0_i97);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___mode_info__mode_info_0_0);
	MR_incr_sp_push_msg(39, "mode_info:__Compare__/3");
	MR_stackvar(39) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r1, (Integer) 19);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(27) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(28) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(29) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(30) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(31) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(32) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(33) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(34) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(35) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(36) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(37) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_stackvar(38) = MR_const_field(MR_mktag(0), r2, (Integer) 19);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___io__state_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i3,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i7,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i11,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(22);
	call_localret(ENTRY(mercury____Compare___hlds_pred__proc_id_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i15,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i19,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_2);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___mode_info__mode_info_0_0_i23,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury____Compare___term__context_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i27,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(26);
	call_localret(STATIC(mercury____Compare___mode_info__mode_context_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i31,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(27);
	call_localret(ENTRY(mercury____Compare___instmap__instmap_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i35,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_3);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(28);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i39,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(29);
	call_localret(ENTRY(mercury____Compare___delay_info__delay_info_0_0),
		mercury____Compare___mode_info__mode_info_0_0_i43,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(30);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i47,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(31);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i51,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_1);
	r2 = MR_stackvar(13);
	r3 = MR_stackvar(32);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i55,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i55);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_4);
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(33);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i59,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i59);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_mode_info__common_5);
	r2 = MR_stackvar(15);
	r3 = MR_stackvar(34);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___mode_info__mode_info_0_0_i63,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i63);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(16);
	r2 = MR_stackvar(35);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_info_0_0_i67,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i67);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(17);
	r2 = MR_stackvar(36);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_info_0_0_i71,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i71);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(18);
	r2 = MR_stackvar(37);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___mode_info__mode_info_0_0_i75,
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i75);
	update_prof_current_proc(LABEL(mercury____Compare___mode_info__mode_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___mode_info__mode_info_0_0_i97);
	r1 = MR_stackvar(19);
	r2 = MR_stackvar(38);
	MR_succip = (Code *) MR_stackvar(39);
	MR_decr_sp_pop_msg(39);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___mode_info__mode_info_0_0));
Define_label(mercury____Compare___mode_info__mode_info_0_0_i97);
	MR_succip = (Code *) MR_stackvar(39);
	MR_decr_sp_pop_msg(39);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__mode_info_maybe_bunch_0(void)
{
	mode_info_module0();
	mode_info_module1();
	mode_info_module2();
	mode_info_module3();
	mode_info_module4();
	mode_info_module5();
	mode_info_module6();
	mode_info_module7();
	mode_info_module8();
	mode_info_module9();
	mode_info_module10();
	mode_info_module11();
	mode_info_module12();
	mode_info_module13();
	mode_info_module14();
	mode_info_module15();
	mode_info_module16();
	mode_info_module17();
	mode_info_module18();
	mode_info_module19();
	mode_info_module20();
	mode_info_module21();
	mode_info_module22();
	mode_info_module23();
	mode_info_module24();
	mode_info_module25();
	mode_info_module26();
	mode_info_module27();
	mode_info_module28();
	mode_info_module29();
	mode_info_module30();
	mode_info_module31();
	mode_info_module32();
	mode_info_module33();
	mode_info_module34();
	mode_info_module35();
	mode_info_module36();
	mode_info_module37();
	mode_info_module38();
	mode_info_module39();
}

static void mercury__mode_info_maybe_bunch_1(void)
{
	mode_info_module40();
	mode_info_module41();
	mode_info_module42();
	mode_info_module43();
	mode_info_module44();
	mode_info_module45();
	mode_info_module46();
	mode_info_module47();
	mode_info_module48();
	mode_info_module49();
	mode_info_module50();
	mode_info_module51();
	mode_info_module52();
	mode_info_module53();
	mode_info_module54();
	mode_info_module55();
	mode_info_module56();
	mode_info_module57();
	mode_info_module58();
	mode_info_module59();
	mode_info_module60();
	mode_info_module61();
	mode_info_module62();
	mode_info_module63();
	mode_info_module64();
	mode_info_module65();
	mode_info_module66();
	mode_info_module67();
	mode_info_module68();
	mode_info_module69();
	mode_info_module70();
	mode_info_module71();
	mode_info_module72();
	mode_info_module73();
	mode_info_module74();
	mode_info_module75();
	mode_info_module76();
	mode_info_module77();
	mode_info_module78();
	mode_info_module79();
}

static void mercury__mode_info_maybe_bunch_2(void)
{
	mode_info_module80();
	mode_info_module81();
	mode_info_module82();
	mode_info_module83();
	mode_info_module84();
	mode_info_module85();
	mode_info_module86();
	mode_info_module87();
}

#endif

void mercury__mode_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__mode_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__mode_info_maybe_bunch_0();
		mercury__mode_info_maybe_bunch_1();
		mercury__mode_info_maybe_bunch_2();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_call_context_0,
			mode_info__call_context_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_how_to_check_goal_0,
			mode_info__how_to_check_goal_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_locked_vars_0,
			mode_info__locked_vars_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_may_change_called_proc_0,
			mode_info__may_change_called_proc_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_mode_context_0,
			mode_info__mode_context_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_mode_info_0,
			mode_info__mode_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_side_0,
			mode_info__side_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_mode_info__type_ctor_info_var_lock_reason_0,
			mode_info__var_lock_reason_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
