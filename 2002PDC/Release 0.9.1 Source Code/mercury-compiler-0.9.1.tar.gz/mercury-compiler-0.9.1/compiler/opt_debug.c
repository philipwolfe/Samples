/*
** Automatically generated from `opt_debug.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__opt_debug__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__opt_debug__msg_4_0);
Declare_label(mercury__opt_debug__msg_4_0_i3);
Declare_label(mercury__opt_debug__msg_4_0_i4);
Declare_label(mercury__opt_debug__msg_4_0_i5);
Define_extern_entry(mercury__opt_debug__dump_instrs_4_0);
Declare_label(mercury__opt_debug__dump_instrs_4_0_i3);
Declare_label(mercury__opt_debug__dump_instrs_4_0_i4);
Define_extern_entry(mercury__opt_debug__dump_node_relmap_2_0);
Declare_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_nodemap_2_0);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i4);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i5);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i6);
Declare_label(mercury__opt_debug__dump_nodemap_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_nodelist_2_0);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_nodelist_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_longnodelist_2_0);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_longnodelist_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_node_2_0);
Declare_label(mercury__opt_debug__dump_node_2_0_i4);
Declare_label(mercury__opt_debug__dump_node_2_0_i5);
Declare_label(mercury__opt_debug__dump_node_2_0_i7);
Declare_label(mercury__opt_debug__dump_node_2_0_i8);
Declare_label(mercury__opt_debug__dump_node_2_0_i10);
Declare_label(mercury__opt_debug__dump_node_2_0_i11);
Declare_label(mercury__opt_debug__dump_node_2_0_i13);
Declare_label(mercury__opt_debug__dump_node_2_0_i14);
Define_extern_entry(mercury__opt_debug__dump_intlist_2_0);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i4);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i5);
Declare_label(mercury__opt_debug__dump_intlist_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_livemap_2_0);
Declare_label(mercury__opt_debug__dump_livemap_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_livemaplist_2_0);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i7);
Declare_label(mercury__opt_debug__dump_livemaplist_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_livevals_2_0);
Declare_label(mercury__opt_debug__dump_livevals_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_livelist_2_0);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i4);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i5);
Declare_label(mercury__opt_debug__dump_livelist_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_ctrlmap_2_0);
Declare_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
Declare_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_ctrl_list_2_0);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
Declare_label(mercury__opt_debug__dump_ctrl_list_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_vninstr_2_0);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i1031);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i7);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i8);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i9);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i11);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i12);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i13);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i14);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i16);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i17);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i19);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i20);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i22);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i23);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i24);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i26);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i27);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i29);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i30);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i32);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i33);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i35);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i36);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i38);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i39);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i41);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i42);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i44);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i45);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i47);
Declare_label(mercury__opt_debug__dump_vninstr_2_0_i48);
Define_extern_entry(mercury__opt_debug__dump_flushmap_2_0);
Declare_label(mercury__opt_debug__dump_flushmap_2_0_i2);
Declare_label(mercury__opt_debug__dump_flushmap_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_flush_list_2_0);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i6);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i7);
Declare_label(mercury__opt_debug__dump_flush_list_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_flush_entry_2_0);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
Declare_label(mercury__opt_debug__dump_flush_entry_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_useful_vns_2_0);
Declare_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
Declare_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_useful_locs_2_0);
Declare_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
Declare_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_vn_locs_2_0);
Declare_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
Declare_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_tables_2_0);
Declare_label(mercury__opt_debug__dump_tables_2_0_i2);
Declare_label(mercury__opt_debug__dump_tables_2_0_i3);
Declare_label(mercury__opt_debug__dump_tables_2_0_i4);
Declare_label(mercury__opt_debug__dump_tables_2_0_i5);
Declare_label(mercury__opt_debug__dump_tables_2_0_i6);
Declare_label(mercury__opt_debug__dump_tables_2_0_i7);
Declare_label(mercury__opt_debug__dump_tables_2_0_i8);
Declare_label(mercury__opt_debug__dump_tables_2_0_i9);
Declare_label(mercury__opt_debug__dump_tables_2_0_i10);
Declare_label(mercury__opt_debug__dump_tables_2_0_i11);
Declare_label(mercury__opt_debug__dump_tables_2_0_i12);
Declare_label(mercury__opt_debug__dump_tables_2_0_i13);
Declare_label(mercury__opt_debug__dump_tables_2_0_i14);
Declare_label(mercury__opt_debug__dump_tables_2_0_i15);
Declare_label(mercury__opt_debug__dump_tables_2_0_i16);
Declare_label(mercury__opt_debug__dump_tables_2_0_i17);
Declare_label(mercury__opt_debug__dump_tables_2_0_i18);
Declare_label(mercury__opt_debug__dump_tables_2_0_i19);
Declare_label(mercury__opt_debug__dump_tables_2_0_i20);
Declare_label(mercury__opt_debug__dump_tables_2_0_i21);
Define_extern_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
Declare_label(mercury__opt_debug__dump_lval_to_vn_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
Declare_label(mercury__opt_debug__dump_rval_to_vn_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
Declare_label(mercury__opt_debug__dump_vn_to_rval_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i8);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
Declare_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
Define_extern_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
Declare_label(mercury__opt_debug__dump_vn_to_locs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_uses_list_2_0);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i4);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i5);
Declare_label(mercury__opt_debug__dump_uses_list_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_use_2_0);
Declare_label(mercury__opt_debug__dump_use_2_0_i4);
Declare_label(mercury__opt_debug__dump_use_2_0_i5);
Declare_label(mercury__opt_debug__dump_use_2_0_i7);
Declare_label(mercury__opt_debug__dump_use_2_0_i8);
Declare_label(mercury__opt_debug__dump_use_2_0_i10);
Declare_label(mercury__opt_debug__dump_use_2_0_i11);
Declare_label(mercury__opt_debug__dump_use_2_0_i13);
Declare_label(mercury__opt_debug__dump_use_2_0_i14);
Define_extern_entry(mercury__opt_debug__dump_vn_2_0);
Define_extern_entry(mercury__opt_debug__dump_vnlvals_2_0);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnlvals_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_reg_3_0);
Declare_label(mercury__opt_debug__dump_reg_3_0_i4);
Declare_label(mercury__opt_debug__dump_reg_3_0_i3);
Declare_label(mercury__opt_debug__dump_reg_3_0_i6);
Define_extern_entry(mercury__opt_debug__dump_vnlval_2_0);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i4);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i7);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i9);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i11);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i13);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i15);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i16);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i18);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i19);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i21);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i22);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i23);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i25);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i26);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i28);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i29);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i31);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i32);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i34);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i35);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i37);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i38);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i40);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i41);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i43);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i46);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i44);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i48);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i49);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i51);
Declare_label(mercury__opt_debug__dump_vnlval_2_0_i52);
Define_extern_entry(mercury__opt_debug__dump_vnrval_2_0);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i4);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i5);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i7);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i8);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i9);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i11);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i12);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i14);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i15);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i16);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i17);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i18);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i20);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i21);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i22);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i24);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i25);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i26);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i27);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i29);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i30);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i32);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i33);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i35);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i36);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i37);
Declare_label(mercury__opt_debug__dump_vnrval_2_0_i38);
Define_extern_entry(mercury__opt_debug__dump_lval_2_0);
Declare_label(mercury__opt_debug__dump_lval_2_0_i4);
Declare_label(mercury__opt_debug__dump_lval_2_0_i5);
Declare_label(mercury__opt_debug__dump_lval_2_0_i7);
Declare_label(mercury__opt_debug__dump_lval_2_0_i9);
Declare_label(mercury__opt_debug__dump_lval_2_0_i11);
Declare_label(mercury__opt_debug__dump_lval_2_0_i13);
Declare_label(mercury__opt_debug__dump_lval_2_0_i15);
Declare_label(mercury__opt_debug__dump_lval_2_0_i16);
Declare_label(mercury__opt_debug__dump_lval_2_0_i18);
Declare_label(mercury__opt_debug__dump_lval_2_0_i19);
Declare_label(mercury__opt_debug__dump_lval_2_0_i21);
Declare_label(mercury__opt_debug__dump_lval_2_0_i22);
Declare_label(mercury__opt_debug__dump_lval_2_0_i23);
Declare_label(mercury__opt_debug__dump_lval_2_0_i25);
Declare_label(mercury__opt_debug__dump_lval_2_0_i26);
Declare_label(mercury__opt_debug__dump_lval_2_0_i28);
Declare_label(mercury__opt_debug__dump_lval_2_0_i29);
Declare_label(mercury__opt_debug__dump_lval_2_0_i31);
Declare_label(mercury__opt_debug__dump_lval_2_0_i32);
Declare_label(mercury__opt_debug__dump_lval_2_0_i34);
Declare_label(mercury__opt_debug__dump_lval_2_0_i35);
Declare_label(mercury__opt_debug__dump_lval_2_0_i37);
Declare_label(mercury__opt_debug__dump_lval_2_0_i38);
Declare_label(mercury__opt_debug__dump_lval_2_0_i40);
Declare_label(mercury__opt_debug__dump_lval_2_0_i41);
Declare_label(mercury__opt_debug__dump_lval_2_0_i43);
Declare_label(mercury__opt_debug__dump_lval_2_0_i46);
Declare_label(mercury__opt_debug__dump_lval_2_0_i44);
Declare_label(mercury__opt_debug__dump_lval_2_0_i48);
Declare_label(mercury__opt_debug__dump_lval_2_0_i49);
Declare_label(mercury__opt_debug__dump_lval_2_0_i51);
Declare_label(mercury__opt_debug__dump_lval_2_0_i52);
Declare_label(mercury__opt_debug__dump_lval_2_0_i54);
Define_extern_entry(mercury__opt_debug__dump_rval_2_0);
Declare_label(mercury__opt_debug__dump_rval_2_0_i4);
Declare_label(mercury__opt_debug__dump_rval_2_0_i5);
Declare_label(mercury__opt_debug__dump_rval_2_0_i1031);
Declare_label(mercury__opt_debug__dump_rval_2_0_i9);
Declare_label(mercury__opt_debug__dump_rval_2_0_i10);
Declare_label(mercury__opt_debug__dump_rval_2_0_i11);
Declare_label(mercury__opt_debug__dump_rval_2_0_i13);
Declare_label(mercury__opt_debug__dump_rval_2_0_i14);
Declare_label(mercury__opt_debug__dump_rval_2_0_i15);
Declare_label(mercury__opt_debug__dump_rval_2_0_i17);
Declare_label(mercury__opt_debug__dump_rval_2_0_i18);
Declare_label(mercury__opt_debug__dump_rval_2_0_i19);
Declare_label(mercury__opt_debug__dump_rval_2_0_i20);
Declare_label(mercury__opt_debug__dump_rval_2_0_i22);
Declare_label(mercury__opt_debug__dump_rval_2_0_i23);
Declare_label(mercury__opt_debug__dump_rval_2_0_i25);
Declare_label(mercury__opt_debug__dump_rval_2_0_i26);
Declare_label(mercury__opt_debug__dump_rval_2_0_i27);
Declare_label(mercury__opt_debug__dump_rval_2_0_i29);
Declare_label(mercury__opt_debug__dump_rval_2_0_i30);
Declare_label(mercury__opt_debug__dump_rval_2_0_i31);
Declare_label(mercury__opt_debug__dump_rval_2_0_i32);
Declare_label(mercury__opt_debug__dump_rval_2_0_i34);
Declare_label(mercury__opt_debug__dump_rval_2_0_i35);
Define_extern_entry(mercury__opt_debug__dump_rvals_2_0);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i4);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i5);
Declare_label(mercury__opt_debug__dump_rvals_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_mem_ref_2_0);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i12);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i7);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i8);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i9);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i10);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i4);
Declare_label(mercury__opt_debug__dump_mem_ref_2_0_i5);
Define_extern_entry(mercury__opt_debug__dump_const_2_0);
Declare_label(mercury__opt_debug__dump_const_2_0_i1013);
Declare_label(mercury__opt_debug__dump_const_2_0_i5);
Declare_label(mercury__opt_debug__dump_const_2_0_i1014);
Declare_label(mercury__opt_debug__dump_const_2_0_i1015);
Declare_label(mercury__opt_debug__dump_const_2_0_i10);
Declare_label(mercury__opt_debug__dump_const_2_0_i11);
Declare_label(mercury__opt_debug__dump_const_2_0_i13);
Declare_label(mercury__opt_debug__dump_const_2_0_i14);
Declare_label(mercury__opt_debug__dump_const_2_0_i16);
Declare_label(mercury__opt_debug__dump_const_2_0_i17);
Declare_label(mercury__opt_debug__dump_const_2_0_i19);
Declare_label(mercury__opt_debug__dump_const_2_0_i20);
Declare_label(mercury__opt_debug__dump_const_2_0_i21);
Declare_label(mercury__opt_debug__dump_const_2_0_i23);
Declare_label(mercury__opt_debug__dump_const_2_0_i24);
Define_extern_entry(mercury__opt_debug__dump_data_name_2_0);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i1009);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i5);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i6);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i1011);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i10);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i19);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i16);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i17);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i13);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i14);
Declare_label(mercury__opt_debug__dump_data_name_2_0_i11);
Define_extern_entry(mercury__opt_debug__dump_unop_2_0);
Define_extern_entry(mercury__opt_debug__dump_binop_2_0);
Define_extern_entry(mercury__opt_debug__dump_label_2_0);
Declare_label(mercury__opt_debug__dump_label_2_0_i4);
Declare_label(mercury__opt_debug__dump_label_2_0_i5);
Declare_label(mercury__opt_debug__dump_label_2_0_i6);
Declare_label(mercury__opt_debug__dump_label_2_0_i1006);
Define_extern_entry(mercury__opt_debug__dump_labels_2_0);
Declare_label(mercury__opt_debug__dump_labels_2_0_i4);
Declare_label(mercury__opt_debug__dump_labels_2_0_i5);
Declare_label(mercury__opt_debug__dump_labels_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_label_pairs_2_0);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
Declare_label(mercury__opt_debug__dump_label_pairs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_proclabel_2_0);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i6);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i4);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i8);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i9);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i11);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i12);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i13);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i14);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i3);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i16);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i17);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i18);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i19);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i20);
Declare_label(mercury__opt_debug__dump_proclabel_2_0_i21);
Define_extern_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i3);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i7);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i5);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
Declare_label(mercury__opt_debug__dump_maybe_rvals_3_0_i4);
Define_extern_entry(mercury__opt_debug__dump_code_addr_2_0);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i4);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i5);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i6);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i7);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i8);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i9);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i10);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i11);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i12);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i13);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i14);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i15);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i16);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i17);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i18);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i19);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i20);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i21);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i23);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i25);
Declare_label(mercury__opt_debug__dump_code_addr_2_0_i27);
Define_extern_entry(mercury__opt_debug__dump_code_addrs_2_0);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
Declare_label(mercury__opt_debug__dump_code_addrs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_bool_2_0);
Declare_label(mercury__opt_debug__dump_bool_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_instr_2_0);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1098);
Declare_label(mercury__opt_debug__dump_instr_2_0_i5);
Declare_label(mercury__opt_debug__dump_instr_2_0_i7);
Declare_label(mercury__opt_debug__dump_instr_2_0_i8);
Declare_label(mercury__opt_debug__dump_instr_2_0_i10);
Declare_label(mercury__opt_debug__dump_instr_2_0_i11);
Declare_label(mercury__opt_debug__dump_instr_2_0_i12);
Declare_label(mercury__opt_debug__dump_instr_2_0_i13);
Declare_label(mercury__opt_debug__dump_instr_2_0_i15);
Declare_label(mercury__opt_debug__dump_instr_2_0_i16);
Declare_label(mercury__opt_debug__dump_instr_2_0_i17);
Declare_label(mercury__opt_debug__dump_instr_2_0_i19);
Declare_label(mercury__opt_debug__dump_instr_2_0_i20);
Declare_label(mercury__opt_debug__dump_instr_2_0_i21);
Declare_label(mercury__opt_debug__dump_instr_2_0_i23);
Declare_label(mercury__opt_debug__dump_instr_2_0_i24);
Declare_label(mercury__opt_debug__dump_instr_2_0_i28);
Declare_label(mercury__opt_debug__dump_instr_2_0_i1102);
Declare_label(mercury__opt_debug__dump_instr_2_0_i31);
Declare_label(mercury__opt_debug__dump_instr_2_0_i34);
Declare_label(mercury__opt_debug__dump_instr_2_0_i32);
Declare_label(mercury__opt_debug__dump_instr_2_0_i37);
Declare_label(mercury__opt_debug__dump_instr_2_0_i38);
Declare_label(mercury__opt_debug__dump_instr_2_0_i40);
Declare_label(mercury__opt_debug__dump_instr_2_0_i41);
Declare_label(mercury__opt_debug__dump_instr_2_0_i43);
Declare_label(mercury__opt_debug__dump_instr_2_0_i44);
Declare_label(mercury__opt_debug__dump_instr_2_0_i45);
Declare_label(mercury__opt_debug__dump_instr_2_0_i47);
Declare_label(mercury__opt_debug__dump_instr_2_0_i49);
Declare_label(mercury__opt_debug__dump_instr_2_0_i50);
Declare_label(mercury__opt_debug__dump_instr_2_0_i51);
Declare_label(mercury__opt_debug__dump_instr_2_0_i53);
Declare_label(mercury__opt_debug__dump_instr_2_0_i54);
Declare_label(mercury__opt_debug__dump_instr_2_0_i56);
Declare_label(mercury__opt_debug__dump_instr_2_0_i57);
Declare_label(mercury__opt_debug__dump_instr_2_0_i58);
Declare_label(mercury__opt_debug__dump_instr_2_0_i60);
Declare_label(mercury__opt_debug__dump_instr_2_0_i61);
Declare_label(mercury__opt_debug__dump_instr_2_0_i63);
Declare_label(mercury__opt_debug__dump_instr_2_0_i64);
Declare_label(mercury__opt_debug__dump_instr_2_0_i66);
Declare_label(mercury__opt_debug__dump_instr_2_0_i67);
Declare_label(mercury__opt_debug__dump_instr_2_0_i69);
Declare_label(mercury__opt_debug__dump_instr_2_0_i70);
Declare_label(mercury__opt_debug__dump_instr_2_0_i72);
Declare_label(mercury__opt_debug__dump_instr_2_0_i73);
Declare_label(mercury__opt_debug__dump_instr_2_0_i75);
Declare_label(mercury__opt_debug__dump_instr_2_0_i76);
Declare_label(mercury__opt_debug__dump_instr_2_0_i78);
Declare_label(mercury__opt_debug__dump_instr_2_0_i79);
Declare_label(mercury__opt_debug__dump_instr_2_0_i81);
Declare_label(mercury__opt_debug__dump_instr_2_0_i82);
Declare_label(mercury__opt_debug__dump_instr_2_0_i84);
Declare_label(mercury__opt_debug__dump_instr_2_0_i85);
Declare_label(mercury__opt_debug__dump_instr_2_0_i87);
Declare_label(mercury__opt_debug__dump_instr_2_0_i88);
Declare_label(mercury__opt_debug__dump_instr_2_0_i89);
Declare_label(mercury__opt_debug__dump_instr_2_0_i91);
Declare_label(mercury__opt_debug__dump_instr_2_0_i92);
Declare_label(mercury__opt_debug__dump_instr_2_0_i93);
Declare_label(mercury__opt_debug__dump_instr_2_0_i94);
Declare_label(mercury__opt_debug__dump_instr_2_0_i96);
Declare_label(mercury__opt_debug__dump_instr_2_0_i97);
Declare_label(mercury__opt_debug__dump_instr_2_0_i99);
Declare_label(mercury__opt_debug__dump_instr_2_0_i100);
Declare_label(mercury__opt_debug__dump_instr_2_0_i101);
Define_extern_entry(mercury__opt_debug__dump_fullinstr_2_0);
Declare_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
Define_extern_entry(mercury__opt_debug__dump_fullinstrs_2_0);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
Declare_label(mercury__opt_debug__dump_fullinstrs_2_0_i3);
Define_extern_entry(mercury__opt_debug__dump_code_model_2_0);
Declare_label(mercury__opt_debug__dump_code_model_2_0_i3);
Declare_label(mercury__opt_debug__dump_code_model_2_0_i4);
Declare_static(mercury__opt_debug__dump_instrs_2_4_0);
Declare_label(mercury__opt_debug__dump_instrs_2_4_0_i1001);
Declare_label(mercury__opt_debug__dump_instrs_2_4_0_i4);
Declare_label(mercury__opt_debug__dump_instrs_2_4_0_i3);
Declare_static(mercury__opt_debug__dump_components_2_0);
Declare_label(mercury__opt_debug__dump_components_2_0_i8);
Declare_label(mercury__opt_debug__dump_components_2_0_i9);
Declare_label(mercury__opt_debug__dump_components_2_0_i10);
Declare_label(mercury__opt_debug__dump_components_2_0_i11);
Declare_label(mercury__opt_debug__dump_components_2_0_i12);
Declare_label(mercury__opt_debug__dump_components_2_0_i13);
Declare_label(mercury__opt_debug__dump_components_2_0_i14);
Declare_label(mercury__opt_debug__dump_components_2_0_i3);

static const struct mercury_data_opt_debug__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_opt_debug__common_0;

static const struct mercury_data_opt_debug__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_opt_debug__common_1;

static const struct mercury_data_opt_debug__common_2_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_2;

static const struct mercury_data_opt_debug__common_3_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_3;

static const struct mercury_data_opt_debug__common_4_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_4;

static const struct mercury_data_opt_debug__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_opt_debug__common_5;

static const struct mercury_data_opt_debug__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_opt_debug__common_6;

static const struct mercury_data_opt_debug__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_opt_debug__common_7;

static const struct mercury_data_opt_debug__common_8_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_8;

static const struct mercury_data_opt_debug__common_9_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_9;

static const struct mercury_data_opt_debug__common_10_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_10;

static const struct mercury_data_opt_debug__common_11_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_11;

static const struct mercury_data_opt_debug__common_12_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_12;

static const struct mercury_data_opt_debug__common_13_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_13;

static const struct mercury_data_opt_debug__common_14_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_14;

static const struct mercury_data_opt_debug__common_15_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_15;

static const struct mercury_data_opt_debug__common_16_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_16;

static const struct mercury_data_opt_debug__common_17_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_17;

static const struct mercury_data_opt_debug__common_18_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_18;

static const struct mercury_data_opt_debug__common_19_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_19;

static const struct mercury_data_opt_debug__common_20_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_20;

static const struct mercury_data_opt_debug__common_21_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_21;

static const struct mercury_data_opt_debug__common_22_struct {
	String f1;
	Word * f2;
}  mercury_data_opt_debug__common_22;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_node_0;
static const struct mercury_data_opt_debug__common_0_struct mercury_data_opt_debug__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vn_node_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
static const struct mercury_data_opt_debug__common_1_struct mercury_data_opt_debug__common_1 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_llds__type_ctor_info_lval_0
};

static const struct mercury_data_opt_debug__common_2_struct mercury_data_opt_debug__common_2 = {
	MR_string_const("livevals(...)", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_3_struct mercury_data_opt_debug__common_3 = {
	MR_string_const(")", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_4_struct mercury_data_opt_debug__common_4 = {
	MR_string_const(", _)", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_opt_debug__common_5_struct mercury_data_opt_debug__common_5 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_src_0;
static const struct mercury_data_opt_debug__common_6_struct mercury_data_opt_debug__common_6 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0
};

static const struct mercury_data_opt_debug__common_7_struct mercury_data_opt_debug__common_7 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0
};

static const struct mercury_data_opt_debug__common_8_struct mercury_data_opt_debug__common_8 = {
	MR_string_const("vn_succip", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_9_struct mercury_data_opt_debug__common_9 = {
	MR_string_const("vn_maxfr", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_10_struct mercury_data_opt_debug__common_10 = {
	MR_string_const("vn_curfr", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_11_struct mercury_data_opt_debug__common_11 = {
	MR_string_const("vn_hp", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_12_struct mercury_data_opt_debug__common_12 = {
	MR_string_const("vn_sp", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_13_struct mercury_data_opt_debug__common_13 = {
	MR_string_const("succip", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_14_struct mercury_data_opt_debug__common_14 = {
	MR_string_const("maxfr", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_15_struct mercury_data_opt_debug__common_15 = {
	MR_string_const("curfr", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_16_struct mercury_data_opt_debug__common_16 = {
	MR_string_const("hp", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_17_struct mercury_data_opt_debug__common_17 = {
	MR_string_const("sp", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_18_struct mercury_data_opt_debug__common_18 = {
	MR_string_const("lvar(_)", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_19_struct mercury_data_opt_debug__common_19 = {
	MR_string_const("var(_)", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_20_struct mercury_data_opt_debug__common_20 = {
	MR_string_const("\"", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_21_struct mercury_data_opt_debug__common_21 = {
	MR_string_const(", ...)", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_opt_debug__common_22_struct mercury_data_opt_debug__common_22 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

Declare_entry(mercury__io__write_string_3_0);

BEGIN_MODULE(opt_debug_module0)
	init_entry(mercury__opt_debug__msg_4_0);
	init_label(mercury__opt_debug__msg_4_0_i3);
	init_label(mercury__opt_debug__msg_4_0_i4);
	init_label(mercury__opt_debug__msg_4_0_i5);
BEGIN_CODE

/* code for predicate 'msg'/4 in mode 0 */
Define_entry(mercury__opt_debug__msg_4_0);
	MR_incr_sp_push_msg(2, "opt_debug:msg/4");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__msg_4_0_i3);
	r1 = r3;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__msg_4_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("\n", 1);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__opt_debug__msg_4_0_i4,
		ENTRY(mercury__opt_debug__msg_4_0));
Define_label(mercury__opt_debug__msg_4_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__opt_debug__msg_4_0_i5,
		ENTRY(mercury__opt_debug__msg_4_0));
Define_label(mercury__opt_debug__msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__opt_debug__msg_4_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);

BEGIN_MODULE(opt_debug_module1)
	init_entry(mercury__opt_debug__dump_instrs_4_0);
	init_label(mercury__opt_debug__dump_instrs_4_0_i3);
	init_label(mercury__opt_debug__dump_instrs_4_0_i4);
BEGIN_CODE

/* code for predicate 'dump_instrs'/4 in mode 0 */
Define_entry(mercury__opt_debug__dump_instrs_4_0);
	MR_incr_sp_push_msg(2, "opt_debug:dump_instrs/4");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_instrs_4_0_i3);
	r1 = r3;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_instrs_4_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Integer) 56;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__opt_debug__dump_instrs_4_0_i4,
		ENTRY(mercury__opt_debug__dump_instrs_4_0));
Define_label(mercury__opt_debug__dump_instrs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instrs_4_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__opt_debug__dump_instrs_2_4_0),
		ENTRY(mercury__opt_debug__dump_instrs_4_0));
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(opt_debug_module2)
	init_entry(mercury__opt_debug__dump_node_relmap_2_0);
	init_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
BEGIN_CODE

/* code for predicate 'dump_node_relmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_node_relmap_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_node_relmap/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_node_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_0);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_node_relmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_node_relmap_2_0));
Define_label(mercury__opt_debug__dump_node_relmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_relmap_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_nodemap_2_0),
		ENTRY(mercury__opt_debug__dump_node_relmap_2_0));
END_MODULE

Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(opt_debug_module3)
	init_entry(mercury__opt_debug__dump_nodemap_2_0);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i4);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i5);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i6);
	init_label(mercury__opt_debug__dump_nodemap_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_nodemap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_nodemap_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_nodemap_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_nodemap/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_nodemap_2_0_i4,
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
Define_label(mercury__opt_debug__dump_nodemap_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_nodelist_2_0),
		mercury__opt_debug__dump_nodemap_2_0_i5,
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
Define_label(mercury__opt_debug__dump_nodemap_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_nodemap_2_0,
		LABEL(mercury__opt_debug__dump_nodemap_2_0_i6),
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
Define_label(mercury__opt_debug__dump_nodemap_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodemap_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodemap_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodemap_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodemap_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodemap_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodemap_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_nodemap_2_0));
	}
Define_label(mercury__opt_debug__dump_nodemap_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module4)
	init_entry(mercury__opt_debug__dump_nodelist_2_0);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i4);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i5);
	init_label(mercury__opt_debug__dump_nodelist_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_nodelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_nodelist_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_nodelist_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_nodelist/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_nodelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
Define_label(mercury__opt_debug__dump_nodelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodelist_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_nodelist_2_0,
		LABEL(mercury__opt_debug__dump_nodelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
Define_label(mercury__opt_debug__dump_nodelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_nodelist_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" ", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_nodelist_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_nodelist_2_0));
	}
Define_label(mercury__opt_debug__dump_nodelist_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module5)
	init_entry(mercury__opt_debug__dump_longnodelist_2_0);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
	init_label(mercury__opt_debug__dump_longnodelist_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_longnodelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_longnodelist_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_longnodelist_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_longnodelist/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_node_2_0),
		mercury__opt_debug__dump_longnodelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_longnodelist_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_longnodelist_2_0,
		LABEL(mercury__opt_debug__dump_longnodelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_longnodelist_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_longnodelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_longnodelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\n", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_longnodelist_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_longnodelist_2_0));
	}
Define_label(mercury__opt_debug__dump_longnodelist_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(opt_debug_module6)
	init_entry(mercury__opt_debug__dump_node_2_0);
	init_label(mercury__opt_debug__dump_node_2_0_i4);
	init_label(mercury__opt_debug__dump_node_2_0_i5);
	init_label(mercury__opt_debug__dump_node_2_0_i7);
	init_label(mercury__opt_debug__dump_node_2_0_i8);
	init_label(mercury__opt_debug__dump_node_2_0_i10);
	init_label(mercury__opt_debug__dump_node_2_0_i11);
	init_label(mercury__opt_debug__dump_node_2_0_i13);
	init_label(mercury__opt_debug__dump_node_2_0_i14);
BEGIN_CODE

/* code for predicate 'dump_node'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_node_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_node/2");
	MR_stackvar(1) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_node_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_node_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_node_2_0_i10) AND
		LABEL(mercury__opt_debug__dump_node_2_0_i13));
Define_label(mercury__opt_debug__dump_node_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_node_2_0_i5,
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("shared vn ", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_node_2_0_i8,
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vnlval ", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i10);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_node_2_0_i11,
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("orig vnlval ", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_node_2_0_i14,
		ENTRY(mercury__opt_debug__dump_node_2_0));
Define_label(mercury__opt_debug__dump_node_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_node_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("ctrl ", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_node_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_node_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module7)
	init_entry(mercury__opt_debug__dump_intlist_2_0);
	init_label(mercury__opt_debug__dump_intlist_2_0_i4);
	init_label(mercury__opt_debug__dump_intlist_2_0_i5);
	init_label(mercury__opt_debug__dump_intlist_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_intlist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_intlist_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_intlist_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_intlist/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_intlist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
Define_label(mercury__opt_debug__dump_intlist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_intlist_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_intlist_2_0,
		LABEL(mercury__opt_debug__dump_intlist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
Define_label(mercury__opt_debug__dump_intlist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_intlist_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_intlist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_intlist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_intlist_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_intlist_2_0));
	}
Define_label(mercury__opt_debug__dump_intlist_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;

BEGIN_MODULE(opt_debug_module8)
	init_entry(mercury__opt_debug__dump_livemap_2_0);
	init_label(mercury__opt_debug__dump_livemap_2_0_i2);
BEGIN_CODE

/* code for predicate 'dump_livemap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livemap_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_livemap/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_1);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_livemap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_livemap_2_0));
Define_label(mercury__opt_debug__dump_livemap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemap_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_livemaplist_2_0),
		ENTRY(mercury__opt_debug__dump_livemap_2_0));
END_MODULE

Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(opt_debug_module9)
	init_entry(mercury__opt_debug__dump_livemaplist_2_0);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i7);
	init_label(mercury__opt_debug__dump_livemaplist_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_livemaplist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livemaplist_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_livemaplist_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_livemaplist/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_livemaplist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__opt_debug__dump_livemaplist_2_0_i5,
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	call_localret(STATIC(mercury__opt_debug__dump_livelist_2_0),
		mercury__opt_debug__dump_livemaplist_2_0_i6,
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_livemaplist_2_0,
		LABEL(mercury__opt_debug__dump_livemaplist_2_0_i7),
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livemaplist_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livemaplist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livemaplist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" ->", 3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livemaplist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livemaplist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livemaplist_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_livemaplist_2_0));
	}
Define_label(mercury__opt_debug__dump_livemaplist_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module10)
	init_entry(mercury__opt_debug__dump_livevals_2_0);
	init_label(mercury__opt_debug__dump_livevals_2_0_i2);
BEGIN_CODE

/* code for predicate 'dump_livevals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livevals_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_livevals/2");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__opt_debug__dump_livevals_2_0_i2,
		ENTRY(mercury__opt_debug__dump_livevals_2_0));
Define_label(mercury__opt_debug__dump_livevals_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livevals_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_livelist_2_0),
		ENTRY(mercury__opt_debug__dump_livevals_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module11)
	init_entry(mercury__opt_debug__dump_livelist_2_0);
	init_label(mercury__opt_debug__dump_livelist_2_0_i4);
	init_label(mercury__opt_debug__dump_livelist_2_0_i5);
	init_label(mercury__opt_debug__dump_livelist_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_livelist'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_livelist_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_livelist_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_livelist/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_livelist_2_0_i4,
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
Define_label(mercury__opt_debug__dump_livelist_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livelist_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_livelist_2_0,
		LABEL(mercury__opt_debug__dump_livelist_2_0_i5),
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
Define_label(mercury__opt_debug__dump_livelist_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_livelist_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livelist_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_livelist_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_livelist_2_0));
	}
Define_label(mercury__opt_debug__dump_livelist_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_instr_0;
Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(opt_debug_module12)
	init_entry(mercury__opt_debug__dump_ctrlmap_2_0);
	init_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
	init_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_ctrlmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_ctrlmap_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_ctrlmap/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_instr_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_ctrlmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
Define_label(mercury__opt_debug__dump_ctrlmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrlmap_2_0));
	call_localret(STATIC(mercury__opt_debug__dump_ctrl_list_2_0),
		mercury__opt_debug__dump_ctrlmap_2_0_i3,
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
Define_label(mercury__opt_debug__dump_ctrlmap_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrlmap_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nCtrl map\n", 10);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_ctrlmap_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module13)
	init_entry(mercury__opt_debug__dump_ctrl_list_2_0);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
	init_label(mercury__opt_debug__dump_ctrl_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_ctrl_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_ctrl_list_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_ctrl_list_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_ctrl_list/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_ctrl_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vninstr_2_0),
		mercury__opt_debug__dump_ctrl_list_2_0_i5,
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_ctrl_list_2_0,
		LABEL(mercury__opt_debug__dump_ctrl_list_2_0_i6),
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_ctrl_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_ctrl_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_ctrl_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_ctrl_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_ctrl_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_ctrl_list_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_ctrl_list_2_0));
	}
Define_label(mercury__opt_debug__dump_ctrl_list_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module14)
	init_entry(mercury__opt_debug__dump_vninstr_2_0);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i1031);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i7);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i8);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i9);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i11);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i12);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i13);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i14);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i16);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i17);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i19);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i20);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i22);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i23);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i24);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i26);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i27);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i29);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i30);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i32);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i33);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i35);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i36);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i38);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i39);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i41);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i42);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i44);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i45);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i47);
	init_label(mercury__opt_debug__dump_vninstr_2_0_i48);
BEGIN_CODE

/* code for predicate 'dump_vninstr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vninstr_2_0);
	MR_incr_sp_push_msg(2, "opt_debug:dump_vninstr/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1030) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i1031) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i11));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1030);
	r1 = (Word) MR_string_const("discard_ticket", 14);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_vninstr_2_0_i1031);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i8,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i9,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("call(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i11);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i12) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i13) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i16) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i19) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i22) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i26) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i29) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i32) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i35) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i38) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i41) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i44) AND
		LABEL(mercury__opt_debug__dump_vninstr_2_0_i47));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i12);
	r1 = (Word) MR_string_const("mkframe", 7);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_vninstr_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i14,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("label(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i17,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("goto(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i19);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i20,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("computed_goto(", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i22);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i23,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i24,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i24);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("if_val(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
	}
Define_label(mercury__opt_debug__dump_vninstr_2_0_i26);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i27,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i27);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mark_hp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i29);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i30,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i30);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("restore_hp(", 11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i32);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i33,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i33);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("store_ticket(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i35);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i36,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i36);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("reset_ticket(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i38);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i39,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i39);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mark_ticket_stack(", 18);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i41);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_vn_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i42,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i42);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("discard_tickets_to(", 19);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i44);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i45,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i45);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("incr_sp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i47);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vninstr_2_0_i48,
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
Define_label(mercury__opt_debug__dump_vninstr_2_0_i48);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vninstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("decr_sp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vninstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vninstr_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module15)
	init_entry(mercury__opt_debug__dump_flushmap_2_0);
	init_label(mercury__opt_debug__dump_flushmap_2_0_i2);
	init_label(mercury__opt_debug__dump_flushmap_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_flushmap'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flushmap_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_flushmap/2");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_5);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_flushmap_2_0_i2,
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
Define_label(mercury__opt_debug__dump_flushmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flushmap_2_0));
	call_localret(STATIC(mercury__opt_debug__dump_flush_list_2_0),
		mercury__opt_debug__dump_flushmap_2_0_i3,
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
Define_label(mercury__opt_debug__dump_flushmap_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flushmap_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nFlush map\n", 11);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_flushmap_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module16)
	init_entry(mercury__opt_debug__dump_flush_list_2_0);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i4);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i5);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i6);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i7);
	init_label(mercury__opt_debug__dump_flush_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_flush_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flush_list_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_flush_list_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_flush_list/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
Define_label(mercury__opt_debug__dump_flush_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i5,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
Define_label(mercury__opt_debug__dump_flush_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	call_localret(STATIC(mercury__opt_debug__dump_flush_entry_2_0),
		mercury__opt_debug__dump_flush_list_2_0_i6,
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
Define_label(mercury__opt_debug__dump_flush_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_flush_list_2_0,
		LABEL(mercury__opt_debug__dump_flush_list_2_0_i7),
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
Define_label(mercury__opt_debug__dump_flush_list_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_list_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_flush_list_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_list_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module17)
	init_entry(mercury__opt_debug__dump_flush_entry_2_0);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
	init_label(mercury__opt_debug__dump_flush_entry_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_flush_entry'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_flush_entry_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_flush_entry_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_flush_entry/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_flush_entry_2_0_i4,
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_flush_entry_2_0_i5,
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_flush_entry_2_0,
		LABEL(mercury__opt_debug__dump_flush_entry_2_0_i6),
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_flush_entry_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_entry_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_entry_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_entry_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("/", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_entry_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_flush_entry_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_flush_entry_2_0));
	}
Define_label(mercury__opt_debug__dump_flush_entry_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury__vn_table__get_vn_to_uses_table_2_0);

BEGIN_MODULE(opt_debug_module18)
	init_entry(mercury__opt_debug__dump_useful_vns_2_0);
	init_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
	init_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_useful_vns'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_useful_vns_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_useful_vns/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__opt_debug__dump_useful_vns_2_0_i2,
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
Define_label(mercury__opt_debug__dump_useful_vns_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_vns_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_6);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_useful_vns_2_0_i3,
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
Define_label(mercury__opt_debug__dump_useful_vns_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_vns_2_0));
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_vn_to_uses_3_0),
		ENTRY(mercury__opt_debug__dump_useful_vns_2_0));
END_MODULE

Declare_entry(mercury__vn_table__get_loc_to_vn_table_2_0);

BEGIN_MODULE(opt_debug_module19)
	init_entry(mercury__opt_debug__dump_useful_locs_2_0);
	init_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
	init_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_useful_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_useful_locs_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_useful_locs/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__opt_debug__dump_useful_locs_2_0_i2,
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
Define_label(mercury__opt_debug__dump_useful_locs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_locs_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_useful_locs_2_0_i3,
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
Define_label(mercury__opt_debug__dump_useful_locs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_useful_locs_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		ENTRY(mercury__opt_debug__dump_useful_locs_2_0));
END_MODULE

Declare_entry(mercury__vn_table__get_vn_to_locs_table_2_0);

BEGIN_MODULE(opt_debug_module20)
	init_entry(mercury__opt_debug__dump_vn_locs_2_0);
	init_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
	init_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_vn_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_locs_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_vn_locs/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__opt_debug__dump_vn_locs_2_0_i2,
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_locs_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_locs_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_7);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_vn_locs_2_0_i3,
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_locs_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_locs_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(STATIC(mercury__opt_debug__dump_vn_to_locs_2_0),
		ENTRY(mercury__opt_debug__dump_vn_locs_2_0));
END_MODULE

Declare_entry(mercury__vn_table__get_next_vn_2_0);
Declare_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
Declare_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
Declare_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnrval_0;

BEGIN_MODULE(opt_debug_module21)
	init_entry(mercury__opt_debug__dump_tables_2_0);
	init_label(mercury__opt_debug__dump_tables_2_0_i2);
	init_label(mercury__opt_debug__dump_tables_2_0_i3);
	init_label(mercury__opt_debug__dump_tables_2_0_i4);
	init_label(mercury__opt_debug__dump_tables_2_0_i5);
	init_label(mercury__opt_debug__dump_tables_2_0_i6);
	init_label(mercury__opt_debug__dump_tables_2_0_i7);
	init_label(mercury__opt_debug__dump_tables_2_0_i8);
	init_label(mercury__opt_debug__dump_tables_2_0_i9);
	init_label(mercury__opt_debug__dump_tables_2_0_i10);
	init_label(mercury__opt_debug__dump_tables_2_0_i11);
	init_label(mercury__opt_debug__dump_tables_2_0_i12);
	init_label(mercury__opt_debug__dump_tables_2_0_i13);
	init_label(mercury__opt_debug__dump_tables_2_0_i14);
	init_label(mercury__opt_debug__dump_tables_2_0_i15);
	init_label(mercury__opt_debug__dump_tables_2_0_i16);
	init_label(mercury__opt_debug__dump_tables_2_0_i17);
	init_label(mercury__opt_debug__dump_tables_2_0_i18);
	init_label(mercury__opt_debug__dump_tables_2_0_i19);
	init_label(mercury__opt_debug__dump_tables_2_0_i20);
	init_label(mercury__opt_debug__dump_tables_2_0_i21);
BEGIN_CODE

/* code for predicate 'dump_tables'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_tables_2_0);
	MR_incr_sp_push_msg(7, "opt_debug:dump_tables/2");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__vn_table__get_next_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i2,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__get_lval_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i3,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i3);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__get_rval_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i4,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_rval_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i5,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_uses_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i6,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__get_vn_to_locs_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i7,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_table__get_loc_to_vn_table_2_0),
		mercury__opt_debug__dump_tables_2_0_i8,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_tables_2_0_i9,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i10,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i11,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i12,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_6);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i13,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_opt_debug__common_7);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i14,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__opt_debug__dump_tables_2_0_i15,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i16,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i17,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__opt_debug__dump_vn_to_rval_2_0),
		mercury__opt_debug__dump_tables_2_0_i18,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = (Integer) 1;
	call_localret(STATIC(mercury__opt_debug__dump_vn_to_uses_3_0),
		mercury__opt_debug__dump_tables_2_0_i19,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vn_to_locs_2_0),
		mercury__opt_debug__dump_tables_2_0_i20,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_lval_to_vn_2_0),
		mercury__opt_debug__dump_tables_2_0_i21,
		ENTRY(mercury__opt_debug__dump_tables_2_0));
Define_label(mercury__opt_debug__dump_tables_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_tables_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\nNext vn\n", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\nVn to rval\n", 12);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("\nVn to uses\n", 12);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("\nLval to vn\n", 12);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_string_const("\nVn to locs\n", 12);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = (Word) MR_string_const("\nLoc to vn\n", 11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_tables_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r13, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_tables_2_0));
	}
END_MODULE


BEGIN_MODULE(opt_debug_module22)
	init_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
	init_label(mercury__opt_debug__dump_lval_to_vn_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_lval_to_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_lval_to_vn_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_to_vn_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_lval_to_vn/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__opt_debug__dump_lval_to_vn_2_0,
		LABEL(mercury__opt_debug__dump_lval_to_vn_2_0_i4),
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_lval_to_vn_2_0_i5,
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_to_vn_2_0_i6,
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_to_vn_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_to_vn_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_lval_to_vn_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module23)
	init_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
	init_label(mercury__opt_debug__dump_rval_to_vn_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_rval_to_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rval_to_vn_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_rval_to_vn_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_rval_to_vn/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__opt_debug__dump_rval_to_vn_2_0,
		LABEL(mercury__opt_debug__dump_rval_to_vn_2_0_i4),
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vnrval_2_0),
		mercury__opt_debug__dump_rval_to_vn_2_0_i5,
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_to_vn_2_0_i6,
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_to_vn_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_to_vn_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_to_vn_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_to_vn_2_0));
Define_label(mercury__opt_debug__dump_rval_to_vn_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module24)
	init_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
	init_label(mercury__opt_debug__dump_vn_to_rval_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_vn_to_rval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_rval_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_rval_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_vn_to_rval/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__opt_debug__dump_vn_to_rval_2_0,
		LABEL(mercury__opt_debug__dump_vn_to_rval_2_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vn_to_rval_2_0_i5,
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vnrval_2_0),
		mercury__opt_debug__dump_vn_to_rval_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_rval_2_0));
Define_label(mercury__opt_debug__dump_vn_to_rval_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module25)
	init_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i8);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	init_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
BEGIN_CODE

/* code for predicate 'dump_vn_to_uses'/3 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_uses_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	MR_incr_sp_push_msg(4, "opt_debug:dump_vn_to_uses/3");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_vn_to_uses_3_0,
		LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	if (((Integer) MR_stackvar(1) == (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i5);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vn_to_uses_3_0_i8,
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__opt_debug__dump_uses_list_2_0),
		mercury__opt_debug__dump_vn_to_uses_3_0_i9,
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_uses_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_uses_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_uses_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_uses_3_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_uses_3_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_uses_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_uses_3_0));
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
Define_label(mercury__opt_debug__dump_vn_to_uses_3_0_i2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module26)
	init_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
	init_label(mercury__opt_debug__dump_vn_to_locs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_vn_to_locs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_to_locs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vn_to_locs_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_vn_to_locs/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__opt_debug__dump_vn_to_locs_2_0,
		LABEL(mercury__opt_debug__dump_vn_to_locs_2_0_i4),
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vn_to_locs_2_0_i5,
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_vnlvals_2_0),
		mercury__opt_debug__dump_vn_to_locs_2_0_i6,
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vn_to_locs_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_locs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_locs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" -> ", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_locs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_locs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vn_to_locs_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vn_to_locs_2_0));
Define_label(mercury__opt_debug__dump_vn_to_locs_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module27)
	init_entry(mercury__opt_debug__dump_uses_list_2_0);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i4);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i5);
	init_label(mercury__opt_debug__dump_uses_list_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_uses_list'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_uses_list_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_uses_list_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_uses_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_use_2_0),
		mercury__opt_debug__dump_uses_list_2_0_i4,
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
Define_label(mercury__opt_debug__dump_uses_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_uses_list_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_uses_list_2_0,
		LABEL(mercury__opt_debug__dump_uses_list_2_0_i5),
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
Define_label(mercury__opt_debug__dump_uses_list_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_uses_list_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_uses_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_uses_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_uses_list_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_uses_list_2_0));
	}
Define_label(mercury__opt_debug__dump_uses_list_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module28)
	init_entry(mercury__opt_debug__dump_use_2_0);
	init_label(mercury__opt_debug__dump_use_2_0_i4);
	init_label(mercury__opt_debug__dump_use_2_0_i5);
	init_label(mercury__opt_debug__dump_use_2_0_i7);
	init_label(mercury__opt_debug__dump_use_2_0_i8);
	init_label(mercury__opt_debug__dump_use_2_0_i10);
	init_label(mercury__opt_debug__dump_use_2_0_i11);
	init_label(mercury__opt_debug__dump_use_2_0_i13);
	init_label(mercury__opt_debug__dump_use_2_0_i14);
BEGIN_CODE

/* code for predicate 'dump_use'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_use_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_use/2");
	MR_stackvar(1) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_use_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_use_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_use_2_0_i10) AND
		LABEL(mercury__opt_debug__dump_use_2_0_i13));
Define_label(mercury__opt_debug__dump_use_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_use_2_0_i5,
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("src_ctrl(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_use_2_0_i8,
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("src_liveval(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i10);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_use_2_0_i11,
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("src_access(", 11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_use_2_0_i14,
		ENTRY(mercury__opt_debug__dump_use_2_0));
Define_label(mercury__opt_debug__dump_use_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_use_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("src_vn(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_use_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_use_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module29)
	init_entry(mercury__opt_debug__dump_vn_2_0);
BEGIN_CODE

/* code for predicate 'dump_vn'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vn_2_0);
	tailcall(ENTRY(mercury__string__int_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_vn_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module30)
	init_entry(mercury__opt_debug__dump_vnlvals_2_0);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
	init_label(mercury__opt_debug__dump_vnlvals_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_vnlvals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnlvals_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlvals_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_vnlvals/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vnlvals_2_0_i4,
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlvals_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_vnlvals_2_0,
		LABEL(mercury__opt_debug__dump_vnlvals_2_0_i5),
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlvals_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlvals_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlvals_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlvals_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlvals_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlvals_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module31)
	init_entry(mercury__opt_debug__dump_reg_3_0);
	init_label(mercury__opt_debug__dump_reg_3_0_i4);
	init_label(mercury__opt_debug__dump_reg_3_0_i3);
	init_label(mercury__opt_debug__dump_reg_3_0_i6);
BEGIN_CODE

/* code for predicate 'dump_reg'/3 in mode 0 */
Define_entry(mercury__opt_debug__dump_reg_3_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_reg/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_reg_3_0_i3);
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_reg_3_0_i4,
		ENTRY(mercury__opt_debug__dump_reg_3_0));
Define_label(mercury__opt_debug__dump_reg_3_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_reg_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_reg_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("r(", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_reg_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_reg_3_0));
Define_label(mercury__opt_debug__dump_reg_3_0_i3);
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_reg_3_0_i6,
		ENTRY(mercury__opt_debug__dump_reg_3_0));
Define_label(mercury__opt_debug__dump_reg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_reg_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_reg_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("f(", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_reg_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_reg_3_0));
END_MODULE


BEGIN_MODULE(opt_debug_module32)
	init_entry(mercury__opt_debug__dump_vnlval_2_0);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i4);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i5);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i7);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i9);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i11);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i13);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i15);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i16);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i18);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i19);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i21);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i22);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i23);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i25);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i26);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i28);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i29);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i31);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i32);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i34);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i35);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i37);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i38);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i40);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i41);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i43);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i46);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i44);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i48);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i49);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i51);
	init_label(mercury__opt_debug__dump_vnlval_2_0_i52);
BEGIN_CODE

/* code for predicate 'dump_vnlval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnlval_2_0);
	MR_incr_sp_push_msg(3, "opt_debug:dump_vnlval/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i15) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i18) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i21));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i5) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i9) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i13));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_8);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_9);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_10);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_12);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i15);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_reg_3_0),
		mercury__opt_debug__dump_vnlval_2_0_i16,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_reg(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i18);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_reg_3_0),
		mercury__opt_debug__dump_vnlval_2_0_i19,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_temp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i21);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i22) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i25) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i28) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i31) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i34) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i37) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i40) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i43) AND
		LABEL(mercury__opt_debug__dump_vnlval_2_0_i51));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i22);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i23,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_stackvar(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i25);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_framevar(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i28);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i29,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i29);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_succfr(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i31);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i32,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i32);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_prevfr(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i34);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i35,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i35);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_redofr(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i38,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i38);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_redoip(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i40);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i41,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i41);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_succip(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i43);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_vnlval_2_0_i44);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i46,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i46);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i48,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i44);
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(1) = (Word) MR_string_const("no", 2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i48,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i48);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i49,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i49);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_field(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnlval_2_0_i51);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnlval_2_0_i52,
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
Define_label(mercury__opt_debug__dump_vnlval_2_0_i52);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnlval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_mem_ref(", 11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnlval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnlval_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module33)
	init_entry(mercury__opt_debug__dump_vnrval_2_0);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i4);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i5);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i7);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i8);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i9);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i11);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i12);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i14);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i15);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i16);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i17);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i18);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i20);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i21);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i22);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i24);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i25);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i26);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i27);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i29);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i30);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i32);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i33);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i35);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i36);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i37);
	init_label(mercury__opt_debug__dump_vnrval_2_0_i38);
BEGIN_CODE

/* code for predicate 'dump_vnrval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_vnrval_2_0);
	MR_incr_sp_push_msg(3, "opt_debug:dump_vnrval/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i14));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_vnlval_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i5,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_origlval(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i8,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i9,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_mkword(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i11);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_const_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i12,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_const(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i15) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i20) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i24) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i29) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i32) AND
		LABEL(mercury__opt_debug__dump_vnrval_2_0_i35));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i15);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i16,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = (Integer) 3;
	call_localret(STATIC(mercury__opt_debug__dump_maybe_rvals_3_0),
		mercury__opt_debug__dump_vnrval_2_0_i17,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i18,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_create(", 10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i20);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_unop_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i21,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i22,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i22);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_unop(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i24);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_binop_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i25,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i25);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i27,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i27);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_binop(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
Define_label(mercury__opt_debug__dump_vnrval_2_0_i29);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i30,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i30);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_stackvar_addr(", 17);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i32);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i33,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i33);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_framevar_addr(", 17);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i35);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i36,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i36);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i37,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i37);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_vnrval_2_0_i38,
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
Define_label(mercury__opt_debug__dump_vnrval_2_0_i38);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_vnrval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("vn_heap_addr(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_vnrval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_vnrval_2_0));
	}
END_MODULE


BEGIN_MODULE(opt_debug_module34)
	init_entry(mercury__opt_debug__dump_lval_2_0);
	init_label(mercury__opt_debug__dump_lval_2_0_i4);
	init_label(mercury__opt_debug__dump_lval_2_0_i5);
	init_label(mercury__opt_debug__dump_lval_2_0_i7);
	init_label(mercury__opt_debug__dump_lval_2_0_i9);
	init_label(mercury__opt_debug__dump_lval_2_0_i11);
	init_label(mercury__opt_debug__dump_lval_2_0_i13);
	init_label(mercury__opt_debug__dump_lval_2_0_i15);
	init_label(mercury__opt_debug__dump_lval_2_0_i16);
	init_label(mercury__opt_debug__dump_lval_2_0_i18);
	init_label(mercury__opt_debug__dump_lval_2_0_i19);
	init_label(mercury__opt_debug__dump_lval_2_0_i21);
	init_label(mercury__opt_debug__dump_lval_2_0_i22);
	init_label(mercury__opt_debug__dump_lval_2_0_i23);
	init_label(mercury__opt_debug__dump_lval_2_0_i25);
	init_label(mercury__opt_debug__dump_lval_2_0_i26);
	init_label(mercury__opt_debug__dump_lval_2_0_i28);
	init_label(mercury__opt_debug__dump_lval_2_0_i29);
	init_label(mercury__opt_debug__dump_lval_2_0_i31);
	init_label(mercury__opt_debug__dump_lval_2_0_i32);
	init_label(mercury__opt_debug__dump_lval_2_0_i34);
	init_label(mercury__opt_debug__dump_lval_2_0_i35);
	init_label(mercury__opt_debug__dump_lval_2_0_i37);
	init_label(mercury__opt_debug__dump_lval_2_0_i38);
	init_label(mercury__opt_debug__dump_lval_2_0_i40);
	init_label(mercury__opt_debug__dump_lval_2_0_i41);
	init_label(mercury__opt_debug__dump_lval_2_0_i43);
	init_label(mercury__opt_debug__dump_lval_2_0_i46);
	init_label(mercury__opt_debug__dump_lval_2_0_i44);
	init_label(mercury__opt_debug__dump_lval_2_0_i48);
	init_label(mercury__opt_debug__dump_lval_2_0_i49);
	init_label(mercury__opt_debug__dump_lval_2_0_i51);
	init_label(mercury__opt_debug__dump_lval_2_0_i52);
	init_label(mercury__opt_debug__dump_lval_2_0_i54);
BEGIN_CODE

/* code for predicate 'dump_lval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_lval_2_0);
	MR_incr_sp_push_msg(3, "opt_debug:dump_lval/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_lval_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i15) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i18) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i21));
Define_label(mercury__opt_debug__dump_lval_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__opt_debug__dump_lval_2_0_i5) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i9) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i13));
Define_label(mercury__opt_debug__dump_lval_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_13);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_14);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_15);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_16);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_17);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i15);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_reg_3_0),
		mercury__opt_debug__dump_lval_2_0_i16,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("reg(", 4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i18);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_reg_3_0),
		mercury__opt_debug__dump_lval_2_0_i19,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("temp(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i21);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_lval_2_0_i22) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i25) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i28) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i31) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i34) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i37) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i40) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i43) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i51) AND
		LABEL(mercury__opt_debug__dump_lval_2_0_i54));
Define_label(mercury__opt_debug__dump_lval_2_0_i22);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i23,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("stackvar(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i25);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("framevar(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i28);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i29,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i29);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("succip(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i31);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i32,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i32);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("redoip(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i34);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i35,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i35);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("redofr(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i38,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i38);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("succfr(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i40);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i41,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i41);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("prevfr(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i43);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_lval_2_0_i44);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_lval_2_0_i46,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i46);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i48,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i44);
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(1) = (Word) MR_string_const("no", 2);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i48,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i48);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i49,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i49);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("field(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
	}
Define_label(mercury__opt_debug__dump_lval_2_0_i51);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_lval_2_0_i52,
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i52);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_lval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mem_ref(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_lval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
Define_label(mercury__opt_debug__dump_lval_2_0_i54);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_18);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_lval_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module35)
	init_entry(mercury__opt_debug__dump_rval_2_0);
	init_label(mercury__opt_debug__dump_rval_2_0_i4);
	init_label(mercury__opt_debug__dump_rval_2_0_i5);
	init_label(mercury__opt_debug__dump_rval_2_0_i1031);
	init_label(mercury__opt_debug__dump_rval_2_0_i9);
	init_label(mercury__opt_debug__dump_rval_2_0_i10);
	init_label(mercury__opt_debug__dump_rval_2_0_i11);
	init_label(mercury__opt_debug__dump_rval_2_0_i13);
	init_label(mercury__opt_debug__dump_rval_2_0_i14);
	init_label(mercury__opt_debug__dump_rval_2_0_i15);
	init_label(mercury__opt_debug__dump_rval_2_0_i17);
	init_label(mercury__opt_debug__dump_rval_2_0_i18);
	init_label(mercury__opt_debug__dump_rval_2_0_i19);
	init_label(mercury__opt_debug__dump_rval_2_0_i20);
	init_label(mercury__opt_debug__dump_rval_2_0_i22);
	init_label(mercury__opt_debug__dump_rval_2_0_i23);
	init_label(mercury__opt_debug__dump_rval_2_0_i25);
	init_label(mercury__opt_debug__dump_rval_2_0_i26);
	init_label(mercury__opt_debug__dump_rval_2_0_i27);
	init_label(mercury__opt_debug__dump_rval_2_0_i29);
	init_label(mercury__opt_debug__dump_rval_2_0_i30);
	init_label(mercury__opt_debug__dump_rval_2_0_i31);
	init_label(mercury__opt_debug__dump_rval_2_0_i32);
	init_label(mercury__opt_debug__dump_rval_2_0_i34);
	init_label(mercury__opt_debug__dump_rval_2_0_i35);
BEGIN_CODE

/* code for predicate 'dump_rval'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rval_2_0);
	MR_incr_sp_push_msg(4, "opt_debug:dump_rval/2");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_rval_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i1031) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i9) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i17));
Define_label(mercury__opt_debug__dump_rval_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_rval_2_0_i5,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("lval(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i1031);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_19);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i10,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = (Integer) 3;
	call_localret(STATIC(mercury__opt_debug__dump_maybe_rvals_3_0),
		mercury__opt_debug__dump_rval_2_0_i11,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i13);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = (Word) MR_string_const("static", 6);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i13);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__opt_debug__dump_rval_2_0_i14);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = (Word) MR_string_const("either", 6);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i14);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = (Word) MR_string_const("dynamic", 7);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i15,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i15);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("create(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i17);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_rval_2_0_i18) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i22) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i25) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i29) AND
		LABEL(mercury__opt_debug__dump_rval_2_0_i34));
Define_label(mercury__opt_debug__dump_rval_2_0_i18);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_rval_2_0_i19,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i20),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mkword(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i22);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_const_2_0),
		mercury__opt_debug__dump_rval_2_0_i23,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i23);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("const(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i25);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_unop_2_0),
		mercury__opt_debug__dump_rval_2_0_i26,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i26);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i27),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i27);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("unop(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i29);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_binop_2_0),
		mercury__opt_debug__dump_rval_2_0_i30,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i30);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i31),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i31);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_rval_2_0,
		LABEL(mercury__opt_debug__dump_rval_2_0_i32),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i32);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("binop(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
	}
Define_label(mercury__opt_debug__dump_rval_2_0_i34);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_mem_ref_2_0),
		mercury__opt_debug__dump_rval_2_0_i35,
		ENTRY(mercury__opt_debug__dump_rval_2_0));
Define_label(mercury__opt_debug__dump_rval_2_0_i35);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mem_addr(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rval_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module36)
	init_entry(mercury__opt_debug__dump_rvals_2_0);
	init_label(mercury__opt_debug__dump_rvals_2_0_i4);
	init_label(mercury__opt_debug__dump_rvals_2_0_i5);
	init_label(mercury__opt_debug__dump_rvals_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_rvals'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_rvals_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_rvals_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_rvals/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_rvals_2_0_i4,
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
Define_label(mercury__opt_debug__dump_rvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rvals_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_rvals_2_0,
		LABEL(mercury__opt_debug__dump_rvals_2_0_i5),
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
Define_label(mercury__opt_debug__dump_rvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_rvals_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rvals_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rvals_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_rvals_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_rvals_2_0));
	}
Define_label(mercury__opt_debug__dump_rvals_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module37)
	init_entry(mercury__opt_debug__dump_mem_ref_2_0);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i12);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i7);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i8);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i9);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i10);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i4);
	init_label(mercury__opt_debug__dump_mem_ref_2_0_i5);
BEGIN_CODE

/* code for predicate 'dump_mem_ref'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_mem_ref_2_0);
	MR_incr_sp_push_msg(3, "opt_debug:dump_mem_ref/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__opt_debug__dump_mem_ref_2_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__opt_debug__dump_mem_ref_2_0_i7);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_mem_ref_2_0_i12,
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_mem_ref_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("stackvar_ref(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_mem_ref_2_0_i8,
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_mem_ref_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_mem_ref_2_0_i9,
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_mem_ref_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_mem_ref_2_0_i10,
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i10);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_mem_ref_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("heap_ref(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
	}
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_mem_ref_2_0_i5,
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
Define_label(mercury__opt_debug__dump_mem_ref_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_mem_ref_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("framevar_ref(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_mem_ref_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_mem_ref_2_0));
END_MODULE

Declare_entry(mercury__string__float_to_string_2_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);

BEGIN_MODULE(opt_debug_module38)
	init_entry(mercury__opt_debug__dump_const_2_0);
	init_label(mercury__opt_debug__dump_const_2_0_i1013);
	init_label(mercury__opt_debug__dump_const_2_0_i5);
	init_label(mercury__opt_debug__dump_const_2_0_i1014);
	init_label(mercury__opt_debug__dump_const_2_0_i1015);
	init_label(mercury__opt_debug__dump_const_2_0_i10);
	init_label(mercury__opt_debug__dump_const_2_0_i11);
	init_label(mercury__opt_debug__dump_const_2_0_i13);
	init_label(mercury__opt_debug__dump_const_2_0_i14);
	init_label(mercury__opt_debug__dump_const_2_0_i16);
	init_label(mercury__opt_debug__dump_const_2_0_i17);
	init_label(mercury__opt_debug__dump_const_2_0_i19);
	init_label(mercury__opt_debug__dump_const_2_0_i20);
	init_label(mercury__opt_debug__dump_const_2_0_i21);
	init_label(mercury__opt_debug__dump_const_2_0_i23);
	init_label(mercury__opt_debug__dump_const_2_0_i24);
BEGIN_CODE

/* code for predicate 'dump_const'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_const_2_0);
	MR_incr_sp_push_msg(2, "opt_debug:dump_const/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_const_2_0_i1013) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i1014) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i1015) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i10));
Define_label(mercury__opt_debug__dump_const_2_0_i1013);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_const_2_0_i5);
	r1 = (Word) MR_string_const("true", 4);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_const_2_0_i5);
	r1 = (Word) MR_string_const("false", 5);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__opt_debug__dump_const_2_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__int_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i1015);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__float_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_const_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i13) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i16) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i19) AND
		LABEL(mercury__opt_debug__dump_const_2_0_i23));
Define_label(mercury__opt_debug__dump_const_2_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\"", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_20);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_const_2_0_i14,
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("multi_string(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_const_2_0_i17,
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("code_addr_const(", 16);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i19);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_data_name_2_0),
		mercury__opt_debug__dump_const_2_0_i20,
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__opt_debug__dump_const_2_0_i21,
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("data_addr_const(", 16);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i23);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_const_2_0_i24,
		ENTRY(mercury__opt_debug__dump_const_2_0));
Define_label(mercury__opt_debug__dump_const_2_0_i24);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_const_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("label_entry(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_const_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_const_2_0));
END_MODULE

Declare_entry(mercury__llds_out__make_type_ctor_name_4_0);
Declare_entry(mercury__llds_out__make_base_typeclass_info_name_3_0);

BEGIN_MODULE(opt_debug_module39)
	init_entry(mercury__opt_debug__dump_data_name_2_0);
	init_label(mercury__opt_debug__dump_data_name_2_0_i1009);
	init_label(mercury__opt_debug__dump_data_name_2_0_i5);
	init_label(mercury__opt_debug__dump_data_name_2_0_i6);
	init_label(mercury__opt_debug__dump_data_name_2_0_i1011);
	init_label(mercury__opt_debug__dump_data_name_2_0_i10);
	init_label(mercury__opt_debug__dump_data_name_2_0_i19);
	init_label(mercury__opt_debug__dump_data_name_2_0_i16);
	init_label(mercury__opt_debug__dump_data_name_2_0_i17);
	init_label(mercury__opt_debug__dump_data_name_2_0_i13);
	init_label(mercury__opt_debug__dump_data_name_2_0_i14);
	init_label(mercury__opt_debug__dump_data_name_2_0_i11);
BEGIN_CODE

/* code for predicate 'dump_data_name'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_data_name_2_0);
	MR_incr_sp_push_msg(1, "opt_debug:dump_data_name/2");
	MR_stackvar(1) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_data_name_2_0_i1009) AND
		LABEL(mercury__opt_debug__dump_data_name_2_0_i5) AND
		LABEL(mercury__opt_debug__dump_data_name_2_0_i1011) AND
		LABEL(mercury__opt_debug__dump_data_name_2_0_i10));
Define_label(mercury__opt_debug__dump_data_name_2_0_i1009);
	r1 = (Word) MR_string_const("module_layout", 13);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__opt_debug__dump_data_name_2_0_i5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_data_name_2_0_i6,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = r1;
	r1 = (Word) MR_string_const("common", 6);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_3_2),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i1011);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__llds_out__make_type_ctor_name_4_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i10);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_data_name_2_0_i11);
	if (((Integer) r2 == (Integer) 1))
		GOTO_LABEL(mercury__opt_debug__dump_data_name_2_0_i13);
	if (((Integer) r2 == (Integer) 2))
		GOTO_LABEL(mercury__opt_debug__dump_data_name_2_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		mercury__opt_debug__dump_data_name_2_0_i19,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("tabling_pointer(", 16);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_data_name_2_0_i17,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("internal_layout(", 16);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i13);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_data_name_2_0_i14,
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_data_name_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("proc_layout(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_data_name_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
Define_label(mercury__opt_debug__dump_data_name_2_0_i11);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__llds_out__make_base_typeclass_info_name_3_0),
		ENTRY(mercury__opt_debug__dump_data_name_2_0));
END_MODULE

static const struct mercury_const_365_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
}  mercury_const_365 = {
	MR_string_const("mktag", 5),
	MR_string_const("tag", 3),
	MR_string_const("unmktag", 7),
	MR_string_const("mkbody", 6),
	MR_string_const("body", 4),
	MR_string_const("unmkbody", 8),
	MR_string_const("cast_to_unsigned", 16),
	MR_string_const("hash_string", 11),
	MR_string_const("bitwise_complement", 18),
	MR_string_const("not", 3)
};

BEGIN_MODULE(opt_debug_module40)
	init_entry(mercury__opt_debug__dump_unop_2_0);
BEGIN_CODE

/* code for predicate 'dump_unop'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_unop_2_0);
	r1 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_365), r1);
	proceed();
END_MODULE

Declare_entry(mercury__llds_out__binary_op_to_string_2_0);

BEGIN_MODULE(opt_debug_module41)
	init_entry(mercury__opt_debug__dump_binop_2_0);
BEGIN_CODE

/* code for predicate 'dump_binop'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_binop_2_0);
	tailcall(ENTRY(mercury__llds_out__binary_op_to_string_2_0),
		ENTRY(mercury__opt_debug__dump_binop_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module42)
	init_entry(mercury__opt_debug__dump_label_2_0);
	init_label(mercury__opt_debug__dump_label_2_0_i4);
	init_label(mercury__opt_debug__dump_label_2_0_i5);
	init_label(mercury__opt_debug__dump_label_2_0_i6);
	init_label(mercury__opt_debug__dump_label_2_0_i1006);
BEGIN_CODE

/* code for predicate 'dump_label'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_label_2_0);
	MR_incr_sp_push_msg(2, "opt_debug:dump_label/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_label_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_label_2_0_i1006) AND
		LABEL(mercury__opt_debug__dump_label_2_0_i1006) AND
		LABEL(mercury__opt_debug__dump_label_2_0_i1006));
Define_label(mercury__opt_debug__dump_label_2_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		mercury__opt_debug__dump_label_2_0_i5,
		ENTRY(mercury__opt_debug__dump_label_2_0));
Define_label(mercury__opt_debug__dump_label_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_label_2_0_i6,
		ENTRY(mercury__opt_debug__dump_label_2_0));
Define_label(mercury__opt_debug__dump_label_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("_", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
	}
Define_label(mercury__opt_debug__dump_label_2_0_i1006);
	r1 = MR_const_mask_field(r1, (Integer) 0);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_label_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module43)
	init_entry(mercury__opt_debug__dump_labels_2_0);
	init_label(mercury__opt_debug__dump_labels_2_0_i4);
	init_label(mercury__opt_debug__dump_labels_2_0_i5);
	init_label(mercury__opt_debug__dump_labels_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_labels'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_labels_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_labels_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_labels/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_labels_2_0_i4,
		ENTRY(mercury__opt_debug__dump_labels_2_0));
Define_label(mercury__opt_debug__dump_labels_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_labels_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_labels_2_0,
		LABEL(mercury__opt_debug__dump_labels_2_0_i5),
		ENTRY(mercury__opt_debug__dump_labels_2_0));
Define_label(mercury__opt_debug__dump_labels_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_labels_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_labels_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_labels_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_labels_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_labels_2_0));
	}
Define_label(mercury__opt_debug__dump_labels_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module44)
	init_entry(mercury__opt_debug__dump_label_pairs_2_0);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
	init_label(mercury__opt_debug__dump_label_pairs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_label_pairs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_label_pairs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_label_pairs_2_0_i3);
	MR_incr_sp_push_msg(3, "opt_debug:dump_label_pairs/2");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_label_pairs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_label_pairs_2_0_i5,
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__opt_debug__dump_label_pairs_2_0,
		LABEL(mercury__opt_debug__dump_label_pairs_2_0_i6),
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_label_pairs_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_pairs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_pairs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_pairs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("-", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_pairs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_label_pairs_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_label_pairs_2_0));
	}
Define_label(mercury__opt_debug__dump_label_pairs_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
Declare_entry(mercury__llds_out__sym_name_mangle_2_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);
Declare_entry(mercury__llds_out__qualify_name_3_0);

BEGIN_MODULE(opt_debug_module45)
	init_entry(mercury__opt_debug__dump_proclabel_2_0);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i6);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i4);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i8);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i9);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i11);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i12);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i13);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i14);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i3);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i16);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i17);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i18);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i19);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i20);
	init_label(mercury__opt_debug__dump_proclabel_2_0_i21);
BEGIN_CODE

/* code for predicate 'dump_proclabel'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_proclabel_2_0);
	MR_incr_sp_push_msg(9, "opt_debug:dump_proclabel/2");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_proclabel_2_0_i3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__opt_debug__dump_proclabel_2_0_i6,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i6);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__opt_debug__dump_proclabel_2_0_i4);
	r1 = MR_stackvar(1);
	MR_stackvar(6) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i11,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i4);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i8,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = (Word) MR_string_const("_", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__opt_debug__dump_proclabel_2_0_i9,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i11,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i11);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i12,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i13,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i14,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const("_", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
Define_label(mercury__opt_debug__dump_proclabel_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i16,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i17,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__llds_out__qualify_name_3_0),
		mercury__opt_debug__dump_proclabel_2_0_i18,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i18);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i19,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i19);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i20,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_proclabel_2_0_i21,
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
Define_label(mercury__opt_debug__dump_proclabel_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_proclabel_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("_", 1);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("_", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_proclabel_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_proclabel_2_0));
	}
END_MODULE


BEGIN_MODULE(opt_debug_module46)
	init_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i3);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i7);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i5);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
	init_label(mercury__opt_debug__dump_maybe_rvals_3_0_i4);
BEGIN_CODE

/* code for predicate 'dump_maybe_rvals'/3 in mode 0 */
Define_entry(mercury__opt_debug__dump_maybe_rvals_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i3);
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i4);
	MR_incr_sp_push_msg(3, "opt_debug:dump_maybe_rvals/3");
	MR_stackvar(3) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i5);
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_maybe_rvals_3_0_i7,
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
	}
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i7);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_maybe_rvals_3_0));
	r2 = ((Integer) MR_stackvar(1) + (Integer) -1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__opt_debug__dump_maybe_rvals_3_0,
		LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i9),
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i5);
	r1 = r3;
	r2 = ((Integer) r2 + (Integer) -1);
	MR_stackvar(1) = (Word) MR_string_const("no", 2);
	localcall(mercury__opt_debug__dump_maybe_rvals_3_0,
		LABEL(mercury__opt_debug__dump_maybe_rvals_3_0_i9),
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i9);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_maybe_rvals_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_maybe_rvals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_maybe_rvals_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_maybe_rvals_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_maybe_rvals_3_0));
	}
Define_label(mercury__opt_debug__dump_maybe_rvals_3_0_i4);
	r1 = (Word) MR_string_const("truncated", 9);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module47)
	init_entry(mercury__opt_debug__dump_code_addr_2_0);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i4);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i5);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i6);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i7);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i8);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i9);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i10);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i11);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i12);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i13);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i14);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i15);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i16);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i17);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i18);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i19);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i20);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i21);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i23);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i25);
	init_label(mercury__opt_debug__dump_code_addr_2_0_i27);
BEGIN_CODE

/* code for predicate 'dump_code_addr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_addr_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i4) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i21) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i23) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i25));
Define_label(mercury__opt_debug__dump_code_addr_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i5) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i6) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i8) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i9) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i10) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i12) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i13) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i14) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i15) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i16) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i17) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i18) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i19) AND
		LABEL(mercury__opt_debug__dump_code_addr_2_0_i20));
Define_label(mercury__opt_debug__dump_code_addr_2_0_i5);
	r1 = (Word) MR_string_const("succip", 6);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i6);
	r1 = (Word) MR_string_const("do_redo", 7);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i7);
	r1 = (Word) MR_string_const("do_fail", 7);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i8);
	r1 = (Word) MR_string_const("do_trace_redo_fail_shallow", 26);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i9);
	r1 = (Word) MR_string_const("do_trace_redo_fail_deep", 23);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i10);
	r1 = (Word) MR_string_const("do_nondet_closure", 17);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i11);
	r1 = (Word) MR_string_const("do_nondet_class_method", 22);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i12);
	r1 = (Word) MR_string_const("do_det_aditi_call", 17);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i13);
	r1 = (Word) MR_string_const("do_semidet_aditi_call", 21);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i14);
	r1 = (Word) MR_string_const("do_nondet_aditi_call", 20);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i15);
	r1 = (Word) MR_string_const("do_aditi_insert", 15);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i16);
	r1 = (Word) MR_string_const("do_aditi_delete", 15);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i17);
	r1 = (Word) MR_string_const("do_aditi_bulk_insert", 20);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i18);
	r1 = (Word) MR_string_const("do_aditi_bulk_delete", 20);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i19);
	r1 = (Word) MR_string_const("do_aditi_modify", 15);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i20);
	r1 = (Word) MR_string_const("do_not_reached", 14);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i21);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	tailcall(STATIC(mercury__opt_debug__dump_label_2_0),
		ENTRY(mercury__opt_debug__dump_code_addr_2_0));
Define_label(mercury__opt_debug__dump_code_addr_2_0_i23);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	tailcall(STATIC(mercury__opt_debug__dump_proclabel_2_0),
		ENTRY(mercury__opt_debug__dump_code_addr_2_0));
Define_label(mercury__opt_debug__dump_code_addr_2_0_i25);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_code_addr_2_0_i27);
	r1 = (Word) MR_string_const("do_succeed", 10);
	proceed();
Define_label(mercury__opt_debug__dump_code_addr_2_0_i27);
	r1 = (Word) MR_string_const("do_last_succeed", 15);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module48)
	init_entry(mercury__opt_debug__dump_code_addrs_2_0);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
	init_label(mercury__opt_debug__dump_code_addrs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_code_addrs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_addrs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_code_addrs_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_code_addrs/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_code_addrs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_code_addrs_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_code_addrs_2_0,
		LABEL(mercury__opt_debug__dump_code_addrs_2_0_i5),
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_code_addrs_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_code_addrs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const(" ", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_code_addrs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_code_addrs_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_code_addrs_2_0));
	}
Define_label(mercury__opt_debug__dump_code_addrs_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module49)
	init_entry(mercury__opt_debug__dump_bool_2_0);
	init_label(mercury__opt_debug__dump_bool_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_bool'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_bool_2_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_bool_2_0_i3);
	r1 = (Word) MR_string_const("no", 2);
	proceed();
Define_label(mercury__opt_debug__dump_bool_2_0_i3);
	r1 = (Word) MR_string_const("yes", 3);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module50)
	init_entry(mercury__opt_debug__dump_instr_2_0);
	init_label(mercury__opt_debug__dump_instr_2_0_i1098);
	init_label(mercury__opt_debug__dump_instr_2_0_i5);
	init_label(mercury__opt_debug__dump_instr_2_0_i7);
	init_label(mercury__opt_debug__dump_instr_2_0_i8);
	init_label(mercury__opt_debug__dump_instr_2_0_i10);
	init_label(mercury__opt_debug__dump_instr_2_0_i11);
	init_label(mercury__opt_debug__dump_instr_2_0_i12);
	init_label(mercury__opt_debug__dump_instr_2_0_i13);
	init_label(mercury__opt_debug__dump_instr_2_0_i15);
	init_label(mercury__opt_debug__dump_instr_2_0_i16);
	init_label(mercury__opt_debug__dump_instr_2_0_i17);
	init_label(mercury__opt_debug__dump_instr_2_0_i19);
	init_label(mercury__opt_debug__dump_instr_2_0_i20);
	init_label(mercury__opt_debug__dump_instr_2_0_i21);
	init_label(mercury__opt_debug__dump_instr_2_0_i23);
	init_label(mercury__opt_debug__dump_instr_2_0_i24);
	init_label(mercury__opt_debug__dump_instr_2_0_i28);
	init_label(mercury__opt_debug__dump_instr_2_0_i1102);
	init_label(mercury__opt_debug__dump_instr_2_0_i31);
	init_label(mercury__opt_debug__dump_instr_2_0_i34);
	init_label(mercury__opt_debug__dump_instr_2_0_i32);
	init_label(mercury__opt_debug__dump_instr_2_0_i37);
	init_label(mercury__opt_debug__dump_instr_2_0_i38);
	init_label(mercury__opt_debug__dump_instr_2_0_i40);
	init_label(mercury__opt_debug__dump_instr_2_0_i41);
	init_label(mercury__opt_debug__dump_instr_2_0_i43);
	init_label(mercury__opt_debug__dump_instr_2_0_i44);
	init_label(mercury__opt_debug__dump_instr_2_0_i45);
	init_label(mercury__opt_debug__dump_instr_2_0_i47);
	init_label(mercury__opt_debug__dump_instr_2_0_i49);
	init_label(mercury__opt_debug__dump_instr_2_0_i50);
	init_label(mercury__opt_debug__dump_instr_2_0_i51);
	init_label(mercury__opt_debug__dump_instr_2_0_i53);
	init_label(mercury__opt_debug__dump_instr_2_0_i54);
	init_label(mercury__opt_debug__dump_instr_2_0_i56);
	init_label(mercury__opt_debug__dump_instr_2_0_i57);
	init_label(mercury__opt_debug__dump_instr_2_0_i58);
	init_label(mercury__opt_debug__dump_instr_2_0_i60);
	init_label(mercury__opt_debug__dump_instr_2_0_i61);
	init_label(mercury__opt_debug__dump_instr_2_0_i63);
	init_label(mercury__opt_debug__dump_instr_2_0_i64);
	init_label(mercury__opt_debug__dump_instr_2_0_i66);
	init_label(mercury__opt_debug__dump_instr_2_0_i67);
	init_label(mercury__opt_debug__dump_instr_2_0_i69);
	init_label(mercury__opt_debug__dump_instr_2_0_i70);
	init_label(mercury__opt_debug__dump_instr_2_0_i72);
	init_label(mercury__opt_debug__dump_instr_2_0_i73);
	init_label(mercury__opt_debug__dump_instr_2_0_i75);
	init_label(mercury__opt_debug__dump_instr_2_0_i76);
	init_label(mercury__opt_debug__dump_instr_2_0_i78);
	init_label(mercury__opt_debug__dump_instr_2_0_i79);
	init_label(mercury__opt_debug__dump_instr_2_0_i81);
	init_label(mercury__opt_debug__dump_instr_2_0_i82);
	init_label(mercury__opt_debug__dump_instr_2_0_i84);
	init_label(mercury__opt_debug__dump_instr_2_0_i85);
	init_label(mercury__opt_debug__dump_instr_2_0_i87);
	init_label(mercury__opt_debug__dump_instr_2_0_i88);
	init_label(mercury__opt_debug__dump_instr_2_0_i89);
	init_label(mercury__opt_debug__dump_instr_2_0_i91);
	init_label(mercury__opt_debug__dump_instr_2_0_i92);
	init_label(mercury__opt_debug__dump_instr_2_0_i93);
	init_label(mercury__opt_debug__dump_instr_2_0_i94);
	init_label(mercury__opt_debug__dump_instr_2_0_i96);
	init_label(mercury__opt_debug__dump_instr_2_0_i97);
	init_label(mercury__opt_debug__dump_instr_2_0_i99);
	init_label(mercury__opt_debug__dump_instr_2_0_i100);
	init_label(mercury__opt_debug__dump_instr_2_0_i101);
BEGIN_CODE

/* code for predicate 'dump_instr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_instr_2_0);
	MR_incr_sp_push_msg(4, "opt_debug:dump_instr/2");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__opt_debug__dump_instr_2_0_i1098) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i5) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i7) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i10));
Define_label(mercury__opt_debug__dump_instr_2_0_i1098);
	r1 = (Word) MR_string_const("discard_ticket", 14);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__opt_debug__dump_instr_2_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("comment(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i7);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_livevals_2_0),
		mercury__opt_debug__dump_instr_2_0_i8,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i8);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("livevals(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__opt_debug__dump_instr_2_0_i11) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i15) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i19) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i23) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i37) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i40) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i43) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i47) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i49) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i53) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i60) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i63) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i66) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i69) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i72) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i75) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i78) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i81) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i84) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i87) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i91) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i96) AND
		LABEL(mercury__opt_debug__dump_instr_2_0_i99));
Define_label(mercury__opt_debug__dump_instr_2_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i12,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i13,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("block(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_21);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i15);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i16,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i16);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i17,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i17);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("assign(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i19);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i20,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i20);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i21,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i21);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("call(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_21);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i23);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i24,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i24);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i1102);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i28);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mkdettempframe(", 15);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i28);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mktempframe(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i1102);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i31,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i31);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	if (((Integer) MR_stackvar(3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i32);
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("yes(", 4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__opt_debug__dump_instr_2_0_i34,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i34);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mkframe(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = r2;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i32);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mkframe(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("no", 2);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_instr_2_0_i38,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i38);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("label(", 6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i40);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i41,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i41);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("goto(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i43);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i44,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i44);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_labels_2_0),
		mercury__opt_debug__dump_instr_2_0_i45,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i45);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("computed_goto(", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i47);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("c_code(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i49);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i50,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i50);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_code_addr_2_0),
		mercury__opt_debug__dump_instr_2_0_i51,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i51);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("if_val(", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i53);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i54,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i54);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_instr_2_0_i56);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = (Word) MR_string_const("no", 2);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i58,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i56);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i57,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i57);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i58,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i58);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("incr_hp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i60);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i61,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i61);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mark_hp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i63);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i64,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i64);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("restore_hp(", 11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i66);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i67,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i67);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("store_ticket(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i69);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i70,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i70);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("reset_ticket(", 13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i72);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i73,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i73);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mark_ticket_stack(", 18);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i75);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_rval_2_0),
		mercury__opt_debug__dump_instr_2_0_i76,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i76);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("discard_tickets_to(", 19);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i78);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i79,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i79);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("incr_sp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i81);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i82,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i82);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("decr_sp(", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i84);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__opt_debug__dump_components_2_0),
		mercury__opt_debug__dump_instr_2_0_i85,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i85);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("pragma_c(", 9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i87);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i88,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i88);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i89,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i89);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("init_sync_term(", 15);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i91);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_instr_2_0_i92,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i92);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_instr_2_0_i93,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i93);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__opt_debug__dump_instr_2_0_i94,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i94);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("fork(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
Define_label(mercury__opt_debug__dump_instr_2_0_i96);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i97,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i97);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("join_and_terminate(", 19);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i99);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_lval_2_0),
		mercury__opt_debug__dump_instr_2_0_i100,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i100);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_instr_2_0_i101,
		ENTRY(mercury__opt_debug__dump_instr_2_0));
Define_label(mercury__opt_debug__dump_instr_2_0_i101);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("join(", 5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(", ", 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_instr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_instr_2_0));
	}
END_MODULE


BEGIN_MODULE(opt_debug_module51)
	init_entry(mercury__opt_debug__dump_fullinstr_2_0);
	init_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
BEGIN_CODE

/* code for predicate 'dump_fullinstr'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_fullinstr_2_0);
	MR_incr_sp_push_msg(2, "opt_debug:dump_fullinstr/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_instr_2_0),
		mercury__opt_debug__dump_fullinstr_2_0_i2,
		ENTRY(mercury__opt_debug__dump_fullinstr_2_0));
Define_label(mercury__opt_debug__dump_fullinstr_2_0_i2);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstr_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_fullinstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_fullinstr_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" - ", 3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_fullinstr_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_opt_debug__common_22);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_fullinstr_2_0));
END_MODULE


BEGIN_MODULE(opt_debug_module52)
	init_entry(mercury__opt_debug__dump_fullinstrs_2_0);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
	init_label(mercury__opt_debug__dump_fullinstrs_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_fullinstrs'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_fullinstrs_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_fullinstrs_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_fullinstrs/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__opt_debug__dump_fullinstrs_2_0_i4,
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstrs_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_fullinstrs_2_0,
		LABEL(mercury__opt_debug__dump_fullinstrs_2_0_i5),
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i5);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_fullinstrs_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_fullinstrs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_fullinstrs_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__opt_debug__dump_fullinstrs_2_0));
Define_label(mercury__opt_debug__dump_fullinstrs_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module53)
	init_entry(mercury__opt_debug__dump_code_model_2_0);
	init_label(mercury__opt_debug__dump_code_model_2_0_i3);
	init_label(mercury__opt_debug__dump_code_model_2_0_i4);
BEGIN_CODE

/* code for predicate 'dump_code_model'/2 in mode 0 */
Define_entry(mercury__opt_debug__dump_code_model_2_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_code_model_2_0_i3);
	r1 = (Word) MR_string_const("model_det", 9);
	proceed();
Define_label(mercury__opt_debug__dump_code_model_2_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__opt_debug__dump_code_model_2_0_i4);
	r1 = (Word) MR_string_const("model_semi", 10);
	proceed();
Define_label(mercury__opt_debug__dump_code_model_2_0_i4);
	r1 = (Word) MR_string_const("model_non", 9);
	proceed();
END_MODULE

Declare_entry(mercury__llds_out__output_instruction_and_comment_5_0);

BEGIN_MODULE(opt_debug_module54)
	init_entry(mercury__opt_debug__dump_instrs_2_4_0);
	init_label(mercury__opt_debug__dump_instrs_2_4_0_i1001);
	init_label(mercury__opt_debug__dump_instrs_2_4_0_i4);
	init_label(mercury__opt_debug__dump_instrs_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'dump_instrs_2'/4 in mode 0 */
Define_static(mercury__opt_debug__dump_instrs_2_4_0);
	MR_incr_sp_push_msg(3, "opt_debug:dump_instrs_2/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__opt_debug__dump_instrs_2_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_instrs_2_4_0_i3);
	r4 = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	call_localret(ENTRY(mercury__llds_out__output_instruction_and_comment_5_0),
		mercury__opt_debug__dump_instrs_2_4_0_i4,
		STATIC(mercury__opt_debug__dump_instrs_2_4_0));
	}
Define_label(mercury__opt_debug__dump_instrs_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_instrs_2_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__opt_debug__dump_instrs_2_4_0_i1001);
Define_label(mercury__opt_debug__dump_instrs_2_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(opt_debug_module55)
	init_entry(mercury__opt_debug__dump_components_2_0);
	init_label(mercury__opt_debug__dump_components_2_0_i8);
	init_label(mercury__opt_debug__dump_components_2_0_i9);
	init_label(mercury__opt_debug__dump_components_2_0_i10);
	init_label(mercury__opt_debug__dump_components_2_0_i11);
	init_label(mercury__opt_debug__dump_components_2_0_i12);
	init_label(mercury__opt_debug__dump_components_2_0_i13);
	init_label(mercury__opt_debug__dump_components_2_0_i14);
	init_label(mercury__opt_debug__dump_components_2_0_i3);
BEGIN_CODE

/* code for predicate 'dump_components'/2 in mode 0 */
Define_static(mercury__opt_debug__dump_components_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__opt_debug__dump_components_2_0_i3);
	MR_incr_sp_push_msg(2, "opt_debug:dump_components/2");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__opt_debug__dump_components_2_0_i8) AND
		LABEL(mercury__opt_debug__dump_components_2_0_i8) AND
		LABEL(mercury__opt_debug__dump_components_2_0_i8) AND
		LABEL(mercury__opt_debug__dump_components_2_0_i9));
Define_label(mercury__opt_debug__dump_components_2_0_i8);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("", 0);
	localcall(mercury__opt_debug__dump_components_2_0,
		LABEL(mercury__opt_debug__dump_components_2_0_i14),
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i9);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__opt_debug__dump_components_2_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__opt_debug__dump_components_2_0,
		LABEL(mercury__opt_debug__dump_components_2_0_i14),
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i10);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__opt_debug__dump_components_2_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__opt_debug__dump_components_2_0,
		LABEL(mercury__opt_debug__dump_components_2_0_i14),
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(STATIC(mercury__opt_debug__dump_label_2_0),
		mercury__opt_debug__dump_components_2_0_i12,
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i12);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_components_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_components_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("fail to ", 8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__opt_debug__dump_components_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__opt_debug__dump_components_2_0_i13,
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i13);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_components_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__opt_debug__dump_components_2_0,
		LABEL(mercury__opt_debug__dump_components_2_0_i14),
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i14);
	update_prof_current_proc(LABEL(mercury__opt_debug__dump_components_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_3_2),
		STATIC(mercury__opt_debug__dump_components_2_0));
Define_label(mercury__opt_debug__dump_components_2_0_i3);
	r1 = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__opt_debug_maybe_bunch_0(void)
{
	opt_debug_module0();
	opt_debug_module1();
	opt_debug_module2();
	opt_debug_module3();
	opt_debug_module4();
	opt_debug_module5();
	opt_debug_module6();
	opt_debug_module7();
	opt_debug_module8();
	opt_debug_module9();
	opt_debug_module10();
	opt_debug_module11();
	opt_debug_module12();
	opt_debug_module13();
	opt_debug_module14();
	opt_debug_module15();
	opt_debug_module16();
	opt_debug_module17();
	opt_debug_module18();
	opt_debug_module19();
	opt_debug_module20();
	opt_debug_module21();
	opt_debug_module22();
	opt_debug_module23();
	opt_debug_module24();
	opt_debug_module25();
	opt_debug_module26();
	opt_debug_module27();
	opt_debug_module28();
	opt_debug_module29();
	opt_debug_module30();
	opt_debug_module31();
	opt_debug_module32();
	opt_debug_module33();
	opt_debug_module34();
	opt_debug_module35();
	opt_debug_module36();
	opt_debug_module37();
	opt_debug_module38();
	opt_debug_module39();
}

static void mercury__opt_debug_maybe_bunch_1(void)
{
	opt_debug_module40();
	opt_debug_module41();
	opt_debug_module42();
	opt_debug_module43();
	opt_debug_module44();
	opt_debug_module45();
	opt_debug_module46();
	opt_debug_module47();
	opt_debug_module48();
	opt_debug_module49();
	opt_debug_module50();
	opt_debug_module51();
	opt_debug_module52();
	opt_debug_module53();
	opt_debug_module54();
	opt_debug_module55();
}

#endif

void mercury__opt_debug__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__opt_debug__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__opt_debug_maybe_bunch_0();
		mercury__opt_debug_maybe_bunch_1();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
