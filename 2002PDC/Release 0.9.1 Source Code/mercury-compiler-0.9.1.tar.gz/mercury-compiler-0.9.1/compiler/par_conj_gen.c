/*
** Automatically generated from `par_conj_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__par_conj_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__par_conj_gen__generate_par_conj_6_0);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i3);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i4);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i6);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i7);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i8);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i9);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i10);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i11);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i12);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i13);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i14);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i15);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i16);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i17);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i18);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i19);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i20);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i21);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i22);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i23);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i24);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i25);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i26);
Declare_label(mercury__par_conj_gen__generate_par_conj_6_0_i27);
Declare_static(mercury__par_conj_gen__generate_det_par_conj_2_9_0);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i4);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i5);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i6);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i7);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i8);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i9);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i10);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i11);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i12);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i13);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i14);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i15);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i16);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i17);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i20);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i21);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i18);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i22);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i24);
Declare_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i3);
Declare_static(mercury__par_conj_gen__find_outputs_6_0);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i1002);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i4);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i5);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i7);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i6);
Declare_label(mercury__par_conj_gen__find_outputs_6_0_i3);
Declare_static(mercury__par_conj_gen__copy_outputs_5_0);
Declare_label(mercury__par_conj_gen__copy_outputs_5_0_i4);
Declare_label(mercury__par_conj_gen__copy_outputs_5_0_i5);
Declare_label(mercury__par_conj_gen__copy_outputs_5_0_i7);
Declare_label(mercury__par_conj_gen__copy_outputs_5_0_i9);
Declare_label(mercury__par_conj_gen__copy_outputs_5_0_i3);
Declare_static(mercury__par_conj_gen__place_all_outputs_3_0);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i1003);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i4);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i5);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i7);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i9);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i6);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i11);
Declare_label(mercury__par_conj_gen__place_all_outputs_3_0_i3);

static const struct mercury_data_par_conj_gen__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_par_conj_gen__common_0;

static const struct mercury_data_par_conj_gen__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_par_conj_gen__common_1;

static const struct mercury_data_par_conj_gen__common_2_struct {
	Word * f1;
}  mercury_data_par_conj_gen__common_2;

static const struct mercury_data_par_conj_gen__common_3_struct {
	Integer f1;
}  mercury_data_par_conj_gen__common_3;

static const struct mercury_data_par_conj_gen__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_par_conj_gen__common_4;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_par_conj_gen__common_0_struct mercury_data_par_conj_gen__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_par_conj_gen__common_1_struct mercury_data_par_conj_gen__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

static const struct mercury_data_par_conj_gen__common_2_struct mercury_data_par_conj_gen__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))
};

static const struct mercury_data_par_conj_gen__common_3_struct mercury_data_par_conj_gen__common_3 = {
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_rval_0;
static const struct mercury_data_par_conj_gen__common_4_struct mercury_data_par_conj_gen__common_4 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_llds__type_ctor_info_rval_0
};

Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__globals__lookup_int_option_3_0);
Declare_entry(mercury__code_info__get_known_variables_3_0);
Declare_entry(mercury__code_info__save_variables_on_stack_4_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__code_info__get_instmap_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__code_info__acquire_reg_4_0);
Declare_entry(mercury__code_info__acquire_temp_slot_4_0);
Declare_entry(mercury__code_info__release_reg_3_0);
Declare_entry(mercury__code_info__clear_all_registers_2_0);
Declare_entry(mercury__code_info__release_temp_slot_3_0);

BEGIN_MODULE(par_conj_gen_module0)
	init_entry(mercury__par_conj_gen__generate_par_conj_6_0);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i3);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i4);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i6);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i7);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i8);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i9);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i10);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i11);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i12);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i13);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i14);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i15);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i16);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i17);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i18);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i19);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i20);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i21);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i22);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i23);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i24);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i25);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i26);
	init_label(mercury__par_conj_gen__generate_par_conj_6_0_i27);
BEGIN_CODE

/* code for predicate 'generate_par_conj'/6 in mode 0 */
Define_entry(mercury__par_conj_gen__generate_par_conj_6_0);
	MR_incr_sp_push_msg(9, "par_conj_gen:generate_par_conj/6");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__par_conj_gen__generate_par_conj_6_0_i3);
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i7,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i3);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__par_conj_gen__generate_par_conj_6_0_i4);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("sorry, semidet parallel conjunction not implemented", 51);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i6,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i4);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("sorry, nondet parallel conjunction not implemented", 50);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i6,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i6);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i7,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i7);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(3) = r2;
	r2 = (Integer) 104;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i8,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i8);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_info__get_known_variables_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i9,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i9);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	call_localret(ENTRY(mercury__code_info__save_variables_on_stack_4_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i10,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i10);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i11,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i11);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i12,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i12);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i13,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i13);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i14,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i14);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i15,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i15);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i16,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i16);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r3 = MR_stackvar(6);
	r4 = r1;
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__par_conj_gen__find_outputs_6_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i17,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i17);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_1);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i18,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i18);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i19,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i19);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	call_localret(ENTRY(mercury__code_info__acquire_temp_slot_4_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i20,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i20);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_par_conj_gen__common_2);
	call_localret(ENTRY(mercury__code_info__acquire_temp_slot_4_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i21,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i21);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(1), (Integer) 1, mercury__par_conj_gen__generate_par_conj_6_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__par_conj_gen__generate_par_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("save the parent stack pointer", 29);
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 5, mercury__par_conj_gen__generate_par_conj_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(3), r8, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 4) = (Word) MR_string_const("synchronization vector", 22);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__par_conj_gen__generate_par_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("allocate a synchronization vector", 33);
	MR_field(MR_mktag(3), r8, (Integer) 3) = r9;
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__par_conj_gen__generate_par_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 19;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("initialize sync term", 20);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r3;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 3, mercury__par_conj_gen__generate_par_conj_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__par_conj_gen__generate_par_conj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 2) = r3;
	r1 = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_stackvar(6), (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("store the sync-term on the stack", 32);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i22,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
	}
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i22);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i23,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i23);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r7 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i24,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i24);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__code_info__release_temp_slot_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i25,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i25);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_par_conj_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 0) = r3;
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 1) = r2;
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i26,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i26);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__par_conj_gen__place_all_outputs_3_0),
		mercury__par_conj_gen__generate_par_conj_6_0_i27,
		ENTRY(mercury__par_conj_gen__generate_par_conj_6_0));
Define_label(mercury__par_conj_gen__generate_par_conj_6_0_i27);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__get_stack_slots_3_0);
Declare_entry(mercury__set__list_to_set_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__map__select_3_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);
Declare_entry(mercury__code_info__get_total_stackslot_count_3_0);

BEGIN_MODULE(par_conj_gen_module1)
	init_entry(mercury__par_conj_gen__generate_det_par_conj_2_9_0);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i4);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i5);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i6);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i7);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i8);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i9);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i10);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i11);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i12);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i13);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i14);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i15);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i16);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i17);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i20);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i21);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i18);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i22);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i24);
	init_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i3);
BEGIN_CODE

/* code for predicate 'generate_det_par_conj_2'/9 in mode 0 */
Define_static(mercury__par_conj_gen__generate_det_par_conj_2_9_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i3);
	MR_incr_sp_push_msg(15, "par_conj_gen:generate_det_par_conj_2/9");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r7;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i4,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i4);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i5,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i5);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i6,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i6);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r3 = r2;
	MR_stackvar(10) = r1;
	r1 = (Integer) 0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i7,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i7);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(11) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_stack_slots_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i8,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i8);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(12) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_known_variables_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i9,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i9);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(14) = r2;
	r2 = r1;
	MR_stackvar(13) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_0);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i10,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i10);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury__map__select_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i11,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i11);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i12,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i12);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	MR_stackvar(5) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(6), (Integer) 1);
	MR_stackvar(6) = r2;
	MR_stackvar(12) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i13,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i13);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i14,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i14);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i15,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i15);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r3 = MR_stackvar(12);
	r4 = r1;
	MR_stackvar(12) = r2;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(4);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__par_conj_gen__find_outputs_6_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i16,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i16);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(12);
	call_localret(STATIC(mercury__par_conj_gen__copy_outputs_5_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i17,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i17);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	if (((Integer) MR_stackvar(7) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i18);
	r3 = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(8) = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i20,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i20);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	call_localret(ENTRY(mercury__code_info__get_total_stackslot_count_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i21,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i21);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = r1;
	r8 = MR_stackvar(1);
	r1 = MR_stackvar(7);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r7;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 20;
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("fork off a child", 16);
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r12, (Integer) 1) = (Word) MR_string_const("child thread", 12);
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r10, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(2), r10, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 1, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 21;
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("finish", 6);
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r14, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	r7 = r2;
	MR_field(MR_mktag(0), r14, (Integer) 0) = MR_tempr1;
	r2 = ((Integer) r8 + (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 1) = r9;
	MR_field(MR_mktag(2), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(2), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(0), r14, (Integer) 1) = (Word) MR_string_const("start of the next conjunct", 26);
	localcall(mercury__par_conj_gen__generate_det_par_conj_2_9_0,
		LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i24),
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	}
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i18);
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__par_conj_gen__generate_det_par_conj_2_9_0_i22,
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i22);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r7 = r1;
	r1 = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r8 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(1) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r10, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(2), r10, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 1, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r7;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 22;
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("sync with children then continue", 32);
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "list:list/1");
	tag_incr_hp_msg(r14, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r7;
	r7 = r2;
	MR_field(MR_mktag(0), r14, (Integer) 0) = MR_tempr1;
	r2 = ((Integer) r8 + (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 1) = r9;
	MR_field(MR_mktag(2), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(2), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(0), r14, (Integer) 1) = (Word) MR_string_const("end of parallel conjunction", 27);
	localcall(mercury__par_conj_gen__generate_det_par_conj_2_9_0,
		LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i24),
		STATIC(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	}
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i24);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__generate_det_par_conj_2_9_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__generate_det_par_conj_2_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__par_conj_gen__generate_det_par_conj_2_9_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r7;
	proceed();
END_MODULE

Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__mode_util__mode_is_output_2_0);

BEGIN_MODULE(par_conj_gen_module2)
	init_entry(mercury__par_conj_gen__find_outputs_6_0);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i1002);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i4);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i5);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i7);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i6);
	init_label(mercury__par_conj_gen__find_outputs_6_0_i3);
BEGIN_CODE

/* code for predicate 'find_outputs'/6 in mode 0 */
Define_static(mercury__par_conj_gen__find_outputs_6_0);
	MR_incr_sp_push_msg(8, "par_conj_gen:find_outputs/6");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__par_conj_gen__find_outputs_6_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__par_conj_gen__find_outputs_6_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_tempr1;
	r1 = r2;
	r2 = MR_tempr1;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__par_conj_gen__find_outputs_6_0_i4,
		STATIC(mercury__par_conj_gen__find_outputs_6_0));
	}
Define_label(mercury__par_conj_gen__find_outputs_6_0_i4);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__find_outputs_6_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__par_conj_gen__find_outputs_6_0_i5,
		STATIC(mercury__par_conj_gen__find_outputs_6_0));
Define_label(mercury__par_conj_gen__find_outputs_6_0_i5);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__find_outputs_6_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__find_outputs_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__par_conj_gen__find_outputs_6_0_i7,
		STATIC(mercury__par_conj_gen__find_outputs_6_0));
Define_label(mercury__par_conj_gen__find_outputs_6_0_i7);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__find_outputs_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__par_conj_gen__find_outputs_6_0_i6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r1 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__find_outputs_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__par_conj_gen__find_outputs_6_0_i1002);
Define_label(mercury__par_conj_gen__find_outputs_6_0_i6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r1 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__par_conj_gen__find_outputs_6_0_i1002);
Define_label(mercury__par_conj_gen__find_outputs_6_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_variable_slot_4_0);

BEGIN_MODULE(par_conj_gen_module3)
	init_entry(mercury__par_conj_gen__copy_outputs_5_0);
	init_label(mercury__par_conj_gen__copy_outputs_5_0_i4);
	init_label(mercury__par_conj_gen__copy_outputs_5_0_i5);
	init_label(mercury__par_conj_gen__copy_outputs_5_0_i7);
	init_label(mercury__par_conj_gen__copy_outputs_5_0_i9);
	init_label(mercury__par_conj_gen__copy_outputs_5_0_i3);
BEGIN_CODE

/* code for predicate 'copy_outputs'/5 in mode 0 */
Define_static(mercury__par_conj_gen__copy_outputs_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__par_conj_gen__copy_outputs_5_0_i3);
	MR_incr_sp_push_msg(4, "par_conj_gen:copy_outputs/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__get_variable_slot_4_0),
		mercury__par_conj_gen__copy_outputs_5_0_i4,
		STATIC(mercury__par_conj_gen__copy_outputs_5_0));
Define_label(mercury__par_conj_gen__copy_outputs_5_0_i4);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__copy_outputs_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__par_conj_gen__copy_outputs_5_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__par_conj_gen__copy_outputs_5_0_i5);
	r3 = r2;
	r4 = r1;
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__par_conj_gen__copy_outputs_5_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__par_conj_gen__copy_outputs_5_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__par_conj_gen__copy_outputs_5_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__par_conj_gen__copy_outputs_5_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 4, mercury__par_conj_gen__copy_outputs_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_par_conj_gen__common_3);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__par_conj_gen__copy_outputs_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(3), r9, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__par_conj_gen__copy_outputs_5_0, "llds:rval/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 1, mercury__par_conj_gen__copy_outputs_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = ((Integer) 0 - (Integer) MR_const_field(MR_mktag(3), r4, (Integer) 1));
	MR_field(MR_mktag(3), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(3), r9, (Integer) 3) = r10;
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__par_conj_gen__copy_outputs_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("copy result to parent stackframe", 32);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	localcall(mercury__par_conj_gen__copy_outputs_5_0,
		LABEL(mercury__par_conj_gen__copy_outputs_5_0_i9),
		STATIC(mercury__par_conj_gen__copy_outputs_5_0));
	}
Define_label(mercury__par_conj_gen__copy_outputs_5_0_i5);
	MR_stackvar(3) = r2;
	r1 = (Word) MR_string_const("par conj in model non procedure!", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__par_conj_gen__copy_outputs_5_0_i7,
		STATIC(mercury__par_conj_gen__copy_outputs_5_0));
Define_label(mercury__par_conj_gen__copy_outputs_5_0_i7);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__copy_outputs_5_0));
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	localcall(mercury__par_conj_gen__copy_outputs_5_0,
		LABEL(mercury__par_conj_gen__copy_outputs_5_0_i9),
		STATIC(mercury__par_conj_gen__copy_outputs_5_0));
Define_label(mercury__par_conj_gen__copy_outputs_5_0_i9);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__copy_outputs_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__par_conj_gen__copy_outputs_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__par_conj_gen__copy_outputs_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__variable_locations_3_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__code_info__set_var_location_4_0);

BEGIN_MODULE(par_conj_gen_module4)
	init_entry(mercury__par_conj_gen__place_all_outputs_3_0);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i1003);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i4);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i5);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i7);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i9);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i6);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i11);
	init_label(mercury__par_conj_gen__place_all_outputs_3_0_i3);
BEGIN_CODE

/* code for predicate 'place_all_outputs'/3 in mode 0 */
Define_static(mercury__par_conj_gen__place_all_outputs_3_0);
	MR_incr_sp_push_msg(5, "par_conj_gen:place_all_outputs/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__par_conj_gen__place_all_outputs_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__variable_locations_3_0),
		mercury__par_conj_gen__place_all_outputs_3_0_i4,
		STATIC(mercury__par_conj_gen__place_all_outputs_3_0));
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__place_all_outputs_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__get_variable_slot_4_0),
		mercury__par_conj_gen__place_all_outputs_3_0_i5,
		STATIC(mercury__par_conj_gen__place_all_outputs_3_0));
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__place_all_outputs_3_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_par_conj_gen__common_4);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__par_conj_gen__place_all_outputs_3_0_i7,
		STATIC(mercury__par_conj_gen__place_all_outputs_3_0));
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i7);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__place_all_outputs_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__par_conj_gen__place_all_outputs_3_0_i6);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__par_conj_gen__place_all_outputs_3_0, "llds:rval/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__par_conj_gen__place_all_outputs_3_0_i9,
		STATIC(mercury__par_conj_gen__place_all_outputs_3_0));
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i9);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__place_all_outputs_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__par_conj_gen__place_all_outputs_3_0_i6);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__par_conj_gen__place_all_outputs_3_0_i1003);
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i6);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__set_var_location_4_0),
		mercury__par_conj_gen__place_all_outputs_3_0_i11,
		STATIC(mercury__par_conj_gen__place_all_outputs_3_0));
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i11);
	update_prof_current_proc(LABEL(mercury__par_conj_gen__place_all_outputs_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__par_conj_gen__place_all_outputs_3_0_i1003);
Define_label(mercury__par_conj_gen__place_all_outputs_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__par_conj_gen_maybe_bunch_0(void)
{
	par_conj_gen_module0();
	par_conj_gen_module1();
	par_conj_gen_module2();
	par_conj_gen_module3();
	par_conj_gen_module4();
}

#endif

void mercury__par_conj_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__par_conj_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__par_conj_gen_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
