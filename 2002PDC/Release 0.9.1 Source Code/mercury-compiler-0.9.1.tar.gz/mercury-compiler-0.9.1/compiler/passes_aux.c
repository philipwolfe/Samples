/*
** Automatically generated from `passes_aux.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__passes_aux__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i1001);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i6);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i3);
Declare_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i1002);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i10);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i12);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i13);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i3);
Declare_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i1002);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i10);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i12);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i13);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i3);
Declare_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i1001);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i6);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i3);
Declare_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1__ua0_1_0);
Declare_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0);
Declare_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i4);
Declare_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i1);
Declare_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0);
Declare_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0_i2);
Define_extern_entry(mercury__passes_aux__process_all_nonimported_procs_5_0);
Declare_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i2);
Declare_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i3);
Declare_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i6);
Define_extern_entry(mercury__passes_aux__process_matching_nonimported_procs_6_0);
Declare_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i2);
Declare_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i3);
Declare_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i6);
Define_extern_entry(mercury__passes_aux__process_matching_nonimported_procs_7_0);
Declare_label(mercury__passes_aux__process_matching_nonimported_procs_7_0_i2);
Define_extern_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0);
Declare_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i2);
Declare_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i3);
Declare_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i6);
Define_extern_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0);
Declare_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0_i2);
Define_extern_entry(mercury__passes_aux__process_all_nonimported_procs_6_0);
Declare_label(mercury__passes_aux__process_all_nonimported_procs_6_0_i2);
Define_extern_entry(mercury__passes_aux__write_pred_progress_message_5_0);
Declare_label(mercury__passes_aux__write_pred_progress_message_5_0_i2);
Declare_label(mercury__passes_aux__write_pred_progress_message_5_0_i5);
Declare_label(mercury__passes_aux__write_pred_progress_message_5_0_i6);
Declare_label(mercury__passes_aux__write_pred_progress_message_5_0_i3);
Define_extern_entry(mercury__passes_aux__write_proc_progress_message_6_0);
Declare_label(mercury__passes_aux__write_proc_progress_message_6_0_i2);
Declare_label(mercury__passes_aux__write_proc_progress_message_6_0_i5);
Declare_label(mercury__passes_aux__write_proc_progress_message_6_0_i6);
Declare_label(mercury__passes_aux__write_proc_progress_message_6_0_i3);
Define_extern_entry(mercury__passes_aux__maybe_report_stats_3_0);
Declare_label(mercury__passes_aux__maybe_report_stats_3_0_i3);
Define_extern_entry(mercury__passes_aux__maybe_write_string_4_0);
Declare_label(mercury__passes_aux__maybe_write_string_4_0_i3);
Define_extern_entry(mercury__passes_aux__maybe_flush_output_3_0);
Declare_label(mercury__passes_aux__maybe_flush_output_3_0_i3);
Define_extern_entry(mercury__passes_aux__report_error_3_0);
Declare_label(mercury__passes_aux__report_error_3_0_i2);
Declare_label(mercury__passes_aux__report_error_3_0_i3);
Declare_label(mercury__passes_aux__report_error_3_0_i4);
Define_extern_entry(mercury__passes_aux__invoke_system_command_4_0);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i2);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i5);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i6);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i7);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i8);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i3);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i10);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i15);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i16);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i11);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i19);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i17);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i23);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i24);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i25);
Declare_label(mercury__passes_aux__invoke_system_command_4_0_i26);
Define_extern_entry(mercury__passes_aux__maybe_report_sizes_3_0);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i2);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i5);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i6);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i7);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i8);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i9);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i10);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i11);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i12);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i13);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i14);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i15);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i16);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i17);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i18);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i19);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i20);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i21);
Declare_label(mercury__passes_aux__maybe_report_sizes_3_0_i3);
Define_extern_entry(mercury__passes_aux__report_pred_proc_id_7_0);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i2);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i3);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i4);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i5);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i6);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i7);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i8);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i10);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i9);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i12);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i13);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i15);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i16);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i17);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i18);
Declare_label(mercury__passes_aux__report_pred_proc_id_7_0_i19);
Define_extern_entry(mercury__passes_aux__report_pred_name_mode_5_0);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i4);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i9);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i10);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i11);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i12);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i3);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i15);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i16);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i17);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i18);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i23);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i24);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i20);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i27);
Declare_label(mercury__passes_aux__report_pred_name_mode_5_0_i2);
Declare_static(mercury__passes_aux__process_nonimported_pred_7_0);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i2);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i8);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i6);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i12);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i3);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i14);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i15);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i16);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i19);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i22);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i23);
Declare_label(mercury__passes_aux__process_nonimported_pred_7_0_i18);
Declare_static(mercury__passes_aux__process_nonimported_procs_in_preds_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i1002);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i8);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i10);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i11);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i3);
Declare_static(mercury__passes_aux__process_nonimported_procs_8_0);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i1003);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i4);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i5);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i6);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i7);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i10);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i12);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i14);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i15);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i16);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i17);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i18);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i19);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i20);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i21);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i24);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i27);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i23);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i30);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i31);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i32);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i33);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i34);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i35);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i36);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i37);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i38);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i39);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i40);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i41);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i42);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i43);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i44);
Declare_label(mercury__passes_aux__process_nonimported_procs_8_0_i3);
Define_extern_entry(mercury____Unify___passes_aux__task_0_0);
Declare_label(mercury____Unify___passes_aux__task_0_0_i1017);
Declare_label(mercury____Unify___passes_aux__task_0_0_i1018);
Declare_label(mercury____Unify___passes_aux__task_0_0_i1019);
Declare_label(mercury____Unify___passes_aux__task_0_0_i16);
Declare_label(mercury____Unify___passes_aux__task_0_0_i17);
Declare_label(mercury____Unify___passes_aux__task_0_0_i21);
Declare_label(mercury____Unify___passes_aux__task_0_0_i25);
Declare_label(mercury____Unify___passes_aux__task_0_0_i29);
Declare_label(mercury____Unify___passes_aux__task_0_0_i33);
Declare_label(mercury____Unify___passes_aux__task_0_0_i37);
Declare_label(mercury____Unify___passes_aux__task_0_0_i39);
Declare_label(mercury____Unify___passes_aux__task_0_0_i1);
Define_extern_entry(mercury____Index___passes_aux__task_0_0);
Declare_label(mercury____Index___passes_aux__task_0_0_i4);
Declare_label(mercury____Index___passes_aux__task_0_0_i5);
Declare_label(mercury____Index___passes_aux__task_0_0_i6);
Declare_label(mercury____Index___passes_aux__task_0_0_i7);
Declare_label(mercury____Index___passes_aux__task_0_0_i8);
Declare_label(mercury____Index___passes_aux__task_0_0_i9);
Declare_label(mercury____Index___passes_aux__task_0_0_i10);
Declare_label(mercury____Index___passes_aux__task_0_0_i11);
Declare_label(mercury____Index___passes_aux__task_0_0_i12);
Declare_label(mercury____Index___passes_aux__task_0_0_i13);
Define_extern_entry(mercury____Compare___passes_aux__task_0_0);
Declare_label(mercury____Compare___passes_aux__task_0_0_i2);
Declare_label(mercury____Compare___passes_aux__task_0_0_i3);
Declare_label(mercury____Compare___passes_aux__task_0_0_i4);
Declare_label(mercury____Compare___passes_aux__task_0_0_i5);
Declare_label(mercury____Compare___passes_aux__task_0_0_i10);
Declare_label(mercury____Compare___passes_aux__task_0_0_i13);
Declare_label(mercury____Compare___passes_aux__task_0_0_i16);
Declare_label(mercury____Compare___passes_aux__task_0_0_i19);
Declare_label(mercury____Compare___passes_aux__task_0_0_i20);
Declare_label(mercury____Compare___passes_aux__task_0_0_i23);
Declare_label(mercury____Compare___passes_aux__task_0_0_i26);
Declare_label(mercury____Compare___passes_aux__task_0_0_i29);
Declare_label(mercury____Compare___passes_aux__task_0_0_i32);
Declare_label(mercury____Compare___passes_aux__task_0_0_i35);
Declare_label(mercury____Compare___passes_aux__task_0_0_i38);
Declare_label(mercury____Compare___passes_aux__task_0_0_i7);
Declare_label(mercury____Compare___passes_aux__task_0_0_i46);
Define_extern_entry(mercury____Unify___passes_aux__pred_error_task_0_0);
Define_extern_entry(mercury____Index___passes_aux__pred_error_task_0_0);
Define_extern_entry(mercury____Compare___passes_aux__pred_error_task_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_passes_aux__type_ctor_info_pred_error_task_0;

const struct MR_TypeCtorInfo_struct mercury_data_passes_aux__type_ctor_info_task_0;

static const struct mercury_data_passes_aux__common_0_struct {
	Word * f1;
}  mercury_data_passes_aux__common_0;

static const struct mercury_data_passes_aux__common_1_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_passes_aux__common_1;

static const struct mercury_data_passes_aux__common_2_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_passes_aux__common_2;

static const struct mercury_data_passes_aux__common_3_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_passes_aux__common_3;

static const struct mercury_data_passes_aux__common_4_struct {
	Word * f1;
	Integer f2;
	Word * f3;
}  mercury_data_passes_aux__common_4;

static const struct mercury_data_passes_aux__common_5_struct {
	Word * f1;
}  mercury_data_passes_aux__common_5;

static const struct mercury_data_passes_aux__common_6_struct {
	Word * f1;
}  mercury_data_passes_aux__common_6;

static const struct mercury_data_passes_aux__common_7_struct {
	Word * f1;
}  mercury_data_passes_aux__common_7;

static const struct mercury_data_passes_aux__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_passes_aux__common_8;

static const struct mercury_data_passes_aux__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
}  mercury_data_passes_aux__common_9;

static const struct mercury_data_passes_aux__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_passes_aux__common_10;

static const struct mercury_data_passes_aux__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_passes_aux__common_11;

static const struct mercury_data_passes_aux__common_12_struct {
	Word * f1;
	Word * f2;
}  mercury_data_passes_aux__common_12;

static const struct mercury_data_passes_aux__common_13_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_passes_aux__common_13;

static const struct mercury_data_passes_aux__common_14_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_14;

static const struct mercury_data_passes_aux__common_15_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
}  mercury_data_passes_aux__common_15;

static const struct mercury_data_passes_aux__common_16_struct {
	Word * f1;
}  mercury_data_passes_aux__common_16;

static const struct mercury_data_passes_aux__common_17_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_passes_aux__common_17;

static const struct mercury_data_passes_aux__common_18_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
}  mercury_data_passes_aux__common_18;

static const struct mercury_data_passes_aux__common_19_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_19;

static const struct mercury_data_passes_aux__common_20_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_20;

static const struct mercury_data_passes_aux__common_21_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_passes_aux__common_21;

static const struct mercury_data_passes_aux__common_22_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_22;

static const struct mercury_data_passes_aux__common_23_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_passes_aux__common_23;

static const struct mercury_data_passes_aux__common_24_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_24;

static const struct mercury_data_passes_aux__common_25_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
}  mercury_data_passes_aux__common_25;

static const struct mercury_data_passes_aux__common_26_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_26;

static const struct mercury_data_passes_aux__common_27_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_passes_aux__common_27;

static const struct mercury_data_passes_aux__common_28_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_28;

static const struct mercury_data_passes_aux__common_29_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_passes_aux__common_29;

static const struct mercury_data_passes_aux__common_30_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_passes_aux__common_30;

static const struct mercury_data_passes_aux__common_31_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_passes_aux__common_31;

static const struct mercury_data_passes_aux__common_32_struct {
	Integer f1;
	Word * f2;
}  mercury_data_passes_aux__common_32;

static const struct mercury_data_passes_aux__type_ctor_functors_task_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_passes_aux__type_ctor_functors_task_0;

static const struct mercury_data_passes_aux__type_ctor_layout_task_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_passes_aux__type_ctor_layout_task_0;

static const struct mercury_data_passes_aux__type_ctor_functors_pred_error_task_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_passes_aux__type_ctor_functors_pred_error_task_0;

static const struct mercury_data_passes_aux__type_ctor_layout_pred_error_task_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_passes_aux__type_ctor_layout_pred_error_task_0;

const struct MR_TypeCtorInfo_struct mercury_data_passes_aux__type_ctor_info_pred_error_task_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___passes_aux__pred_error_task_0_0),
	ENTRY(mercury____Index___passes_aux__pred_error_task_0_0),
	ENTRY(mercury____Compare___passes_aux__pred_error_task_0_0),
	(Integer) 6,
	(Word *) &mercury_data_passes_aux__type_ctor_functors_pred_error_task_0,
	(Word *) &mercury_data_passes_aux__type_ctor_layout_pred_error_task_0,
	MR_string_const("passes_aux", 10),
	MR_string_const("pred_error_task", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_passes_aux__type_ctor_info_task_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___passes_aux__task_0_0),
	ENTRY(mercury____Index___passes_aux__task_0_0),
	ENTRY(mercury____Compare___passes_aux__task_0_0),
	(Integer) 2,
	(Word *) &mercury_data_passes_aux__type_ctor_functors_task_0,
	(Word *) &mercury_data_passes_aux__type_ctor_layout_task_0,
	MR_string_const("passes_aux", 10),
	MR_string_const("task", 4),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
static const struct mercury_data_passes_aux__common_0_struct mercury_data_passes_aux__common_0 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

static const struct mercury_data_passes_aux__common_1_struct mercury_data_passes_aux__common_1 = {
	(Integer) 0,
	MR_string_const("passes_aux", 10),
	MR_string_const("passes_aux", 10),
	MR_string_const("IntroducedFrom__pred__process_all_nonimported_procs__174__1", 59),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_0)
};

static const struct mercury_data_passes_aux__common_2_struct mercury_data_passes_aux__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_1),
	STATIC(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_pred_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_passes_aux__common_3_struct mercury_data_passes_aux__common_3 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 9,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_passes_aux__common_4_struct mercury_data_passes_aux__common_4 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

static const struct mercury_data_passes_aux__common_5_struct mercury_data_passes_aux__common_5 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_passes_aux__common_6_struct mercury_data_passes_aux__common_6 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_passes_aux__common_7_struct mercury_data_passes_aux__common_7 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_passes_aux__common_8_struct mercury_data_passes_aux__common_8 = {
	(Integer) 0,
	MR_string_const("passes_aux", 10),
	MR_string_const("passes_aux", 10),
	MR_string_const("process_nonimported_pred", 24),
	7,
	0,
	0,
	7,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_7)
};

static const struct mercury_data_passes_aux__common_9_struct mercury_data_passes_aux__common_9 = {
	(Integer) 0,
	MR_string_const("passes_aux", 10),
	MR_string_const("passes_aux", 10),
	MR_string_const("IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2", 68),
	1,
	0,
	0,
	1,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_0)
};

static const struct mercury_data_passes_aux__common_10_struct mercury_data_passes_aux__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_9),
	STATIC(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_passes_aux__common_11_struct mercury_data_passes_aux__common_11 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
static const struct mercury_data_passes_aux__common_12_struct mercury_data_passes_aux__common_12 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_data_passes_aux__common_13_struct mercury_data_passes_aux__common_13 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 4,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_passes_aux__common_14_struct mercury_data_passes_aux__common_14 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_13),
	MR_string_const("update_module", 13),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_univ_0;
static const struct mercury_data_passes_aux__common_15_struct mercury_data_passes_aux__common_15 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 8,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_std_util__type_ctor_info_univ_0,
	(Word *) &mercury_data_std_util__type_ctor_info_univ_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_passes_aux__common_16_struct mercury_data_passes_aux__common_16 = {
	(Word *) &mercury_data_std_util__type_ctor_info_univ_0
};

static const struct mercury_data_passes_aux__common_17_struct mercury_data_passes_aux__common_17 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_16),
	MR_string_const("update_module_cookie", 20),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 5)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_18_struct mercury_data_passes_aux__common_18 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 8,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_passes_aux__common_19_struct mercury_data_passes_aux__common_19 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_18),
	MR_string_const("update_module_io", 16),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_20_struct mercury_data_passes_aux__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_3),
	MR_string_const("update_pred_error", 17),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_21_struct mercury_data_passes_aux__common_21 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 3,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_passes_aux__common_22_struct mercury_data_passes_aux__common_22 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_21),
	MR_string_const("update_proc", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_23_struct mercury_data_passes_aux__common_23 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 10,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_passes_aux__common_24_struct mercury_data_passes_aux__common_24 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_23),
	MR_string_const("update_proc_error", 17),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_25_struct mercury_data_passes_aux__common_25 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 7,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_passes_aux__common_26_struct mercury_data_passes_aux__common_26 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_25),
	MR_string_const("update_proc_io", 14),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_27_struct mercury_data_passes_aux__common_27 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 4,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_passes_aux__common_28_struct mercury_data_passes_aux__common_28 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_27),
	MR_string_const("update_proc_predid", 18),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_29_struct mercury_data_passes_aux__common_29 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 5,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0,
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_passes_aux__common_30_struct mercury_data_passes_aux__common_30 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_29),
	MR_string_const("update_proc_predprocid", 22),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_passes_aux__common_31_struct mercury_data_passes_aux__common_31 = {
	(Integer) 6,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_26),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_24),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_20),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_19),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_17)
};

static const struct mercury_data_passes_aux__common_32_struct mercury_data_passes_aux__common_32 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_3)
};

static const struct mercury_data_passes_aux__type_ctor_functors_task_0_struct mercury_data_passes_aux__type_ctor_functors_task_0 = {
	(Integer) 0,
	(Integer) 9,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_28),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_30)
};

static const struct mercury_data_passes_aux__type_ctor_layout_task_0_struct mercury_data_passes_aux__type_ctor_layout_task_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_22),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_28),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_passes_aux__common_30),
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_passes_aux__common_31)
};

static const struct mercury_data_passes_aux__type_ctor_functors_pred_error_task_0_struct mercury_data_passes_aux__type_ctor_functors_pred_error_task_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_3)
};

static const struct mercury_data_passes_aux__type_ctor_layout_pred_error_task_0_struct mercury_data_passes_aux__type_ctor_layout_pred_error_task_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_passes_aux__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_passes_aux__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_passes_aux__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_passes_aux__common_32)
};

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);

BEGIN_MODULE(passes_aux_module0)
	init_entry(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i1001);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i6);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs_in_preds__ho8__ua0'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0);
	MR_incr_sp_push_msg(6, "passes_aux:process_nonimported_procs_in_preds__ho8__ua0/8");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i6,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_8_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i7,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i1001);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_is_aditi_relation_1_0);

BEGIN_MODULE(passes_aux_module1)
	init_entry(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i1002);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i10);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i12);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i13);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs_in_preds__ho7__ua0'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0);
	MR_incr_sp_push_msg(7, "passes_aux:process_nonimported_procs_in_preds__ho7__ua0/8");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_aditi_relation_1_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i10,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
	if (r1)
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i7);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i12,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_8_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i13,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i13);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i7);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module2)
	init_entry(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i1002);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i10);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i12);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i13);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs_in_preds__ho6__ua0'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0);
	MR_incr_sp_push_msg(7, "passes_aux:process_nonimported_procs_in_preds__ho6__ua0/8");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_aditi_relation_1_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i10,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
	if (r1)
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i7);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i12,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_8_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i13,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i13);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i7);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module3)
	init_entry(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i1001);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i6);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs_in_preds__ho5__ua0'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0);
	MR_incr_sp_push_msg(6, "passes_aux:process_nonimported_procs_in_preds__ho5__ua0/8");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i6,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_8_0),
		mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i7,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0));
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i1001);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module4)
	init_entry(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1__ua0_1_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__process_all_nonimported_procs__174__1__ua0'/1 in mode 0 */
Define_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1__ua0_1_0);
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module5)
	init_entry(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0);
	init_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i4);
	init_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2'/1 in mode 0 */
Define_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0);
	MR_incr_sp_push_msg(1, "passes_aux:IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2/1");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_aditi_relation_1_0),
		mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i4,
		STATIC(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0));
Define_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0));
	if (r1)
		GOTO_LABEL(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = TRUE;
	proceed();
Define_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_nonaditi_procs__180__2_1_0_i1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module6)
	init_entry(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0);
	init_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__process_all_nonimported_procs__174__1'/1 in mode 0 */
Define_static(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0);
	MR_incr_sp_push_msg(1, "passes_aux:IntroducedFrom__pred__process_all_nonimported_procs__174__1/1");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1__ua0_1_0),
		mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0_i2,
		STATIC(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0));
Define_label(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__IntroducedFrom__pred__process_all_nonimported_procs__174__1_1_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = TRUE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__list__foldl2_6_4);

BEGIN_MODULE(passes_aux_module7)
	init_entry(mercury__passes_aux__process_all_nonimported_procs_5_0);
	init_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i2);
	init_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i3);
	init_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i6);
BEGIN_CODE

/* code for predicate 'process_all_nonimported_procs'/5 in mode 0 */
Define_entry(mercury__passes_aux__process_all_nonimported_procs_5_0);
	MR_incr_sp_push_msg(4, "passes_aux:process_all_nonimported_procs/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_all_nonimported_procs_5_0_i2,
		ENTRY(mercury__passes_aux__process_all_nonimported_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_procs_5_0));
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__passes_aux__process_all_nonimported_procs_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__passes_aux__process_all_nonimported_procs_5_0_i3);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__passes_aux__process_all_nonimported_procs_5_0, "origin_lost_in_value_number");
	r5 = r1;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_2);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__passes_aux__process_nonimported_pred_7_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_8);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl2_6_4),
		ENTRY(mercury__passes_aux__process_all_nonimported_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho5__ua0_8_0),
		mercury__passes_aux__process_all_nonimported_procs_5_0_i6,
		ENTRY(mercury__passes_aux__process_all_nonimported_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_procs_5_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_procs_5_0));
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module8)
	init_entry(mercury__passes_aux__process_matching_nonimported_procs_6_0);
	init_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i2);
	init_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i3);
	init_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i6);
BEGIN_CODE

/* code for predicate 'process_matching_nonimported_procs'/6 in mode 0 */
Define_entry(mercury__passes_aux__process_matching_nonimported_procs_6_0);
	MR_incr_sp_push_msg(5, "passes_aux:process_matching_nonimported_procs/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_matching_nonimported_procs_6_0_i2,
		ENTRY(mercury__passes_aux__process_matching_nonimported_procs_6_0));
Define_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_matching_nonimported_procs_6_0));
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__passes_aux__process_matching_nonimported_procs_6_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__passes_aux__process_matching_nonimported_procs_6_0_i3);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__passes_aux__process_matching_nonimported_procs_6_0, "origin_lost_in_value_number");
	r5 = r1;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__passes_aux__process_nonimported_pred_7_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_8);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__list__foldl2_6_4),
		ENTRY(mercury__passes_aux__process_matching_nonimported_procs_6_0));
Define_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0),
		mercury__passes_aux__process_matching_nonimported_procs_6_0_i6,
		ENTRY(mercury__passes_aux__process_matching_nonimported_procs_6_0));
Define_label(mercury__passes_aux__process_matching_nonimported_procs_6_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_matching_nonimported_procs_6_0));
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module9)
	init_entry(mercury__passes_aux__process_matching_nonimported_procs_7_0);
	init_label(mercury__passes_aux__process_matching_nonimported_procs_7_0_i2);
BEGIN_CODE

/* code for predicate 'process_matching_nonimported_procs'/7 in mode 0 */
Define_entry(mercury__passes_aux__process_matching_nonimported_procs_7_0);
	MR_incr_sp_push_msg(5, "passes_aux:process_matching_nonimported_procs/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_matching_nonimported_procs_7_0_i2,
		ENTRY(mercury__passes_aux__process_matching_nonimported_procs_7_0));
Define_label(mercury__passes_aux__process_matching_nonimported_procs_7_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_matching_nonimported_procs_7_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0),
		ENTRY(mercury__passes_aux__process_matching_nonimported_procs_7_0));
END_MODULE


BEGIN_MODULE(passes_aux_module10)
	init_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0);
	init_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i2);
	init_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i3);
	init_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i6);
BEGIN_CODE

/* code for predicate 'process_all_nonimported_nonaditi_procs'/5 in mode 0 */
Define_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0);
	MR_incr_sp_push_msg(4, "passes_aux:process_all_nonimported_nonaditi_procs/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i2,
		ENTRY(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0));
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i3);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0, "origin_lost_in_value_number");
	r5 = r1;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r6 = MR_stackvar(2);
	r7 = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_10);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__passes_aux__process_nonimported_pred_7_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_8);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl2_6_4),
		ENTRY(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho6__ua0_8_0),
		mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i6,
		ENTRY(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0));
Define_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_nonaditi_procs_5_0));
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module11)
	init_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0);
	init_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0_i2);
BEGIN_CODE

/* code for predicate 'process_all_nonimported_nonaditi_procs'/6 in mode 0 */
Define_entry(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0);
	MR_incr_sp_push_msg(4, "passes_aux:process_all_nonimported_nonaditi_procs/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0_i2,
		ENTRY(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0));
Define_label(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho7__ua0_8_0),
		ENTRY(mercury__passes_aux__process_all_nonimported_nonaditi_procs_6_0));
END_MODULE


BEGIN_MODULE(passes_aux_module12)
	init_entry(mercury__passes_aux__process_all_nonimported_procs_6_0);
	init_label(mercury__passes_aux__process_all_nonimported_procs_6_0_i2);
BEGIN_CODE

/* code for predicate 'process_all_nonimported_procs'/6 in mode 0 */
Define_entry(mercury__passes_aux__process_all_nonimported_procs_6_0);
	MR_incr_sp_push_msg(4, "passes_aux:process_all_nonimported_procs/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__passes_aux__process_all_nonimported_procs_6_0_i2,
		ENTRY(mercury__passes_aux__process_all_nonimported_procs_6_0));
Define_label(mercury__passes_aux__process_all_nonimported_procs_6_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_all_nonimported_procs_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__passes_aux__process_nonimported_procs_in_preds__ho8__ua0_8_0),
		ENTRY(mercury__passes_aux__process_all_nonimported_procs_6_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_id_4_0);

BEGIN_MODULE(passes_aux_module13)
	init_entry(mercury__passes_aux__write_pred_progress_message_5_0);
	init_label(mercury__passes_aux__write_pred_progress_message_5_0_i2);
	init_label(mercury__passes_aux__write_pred_progress_message_5_0_i5);
	init_label(mercury__passes_aux__write_pred_progress_message_5_0_i6);
	init_label(mercury__passes_aux__write_pred_progress_message_5_0_i3);
BEGIN_CODE

/* code for predicate 'write_pred_progress_message'/5 in mode 0 */
Define_entry(mercury__passes_aux__write_pred_progress_message_5_0);
	MR_incr_sp_push_msg(4, "passes_aux:write_pred_progress_message/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 18;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__write_pred_progress_message_5_0_i2,
		ENTRY(mercury__passes_aux__write_pred_progress_message_5_0));
Define_label(mercury__passes_aux__write_pred_progress_message_5_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_pred_progress_message_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__write_pred_progress_message_5_0_i3);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__write_pred_progress_message_5_0_i5,
		ENTRY(mercury__passes_aux__write_pred_progress_message_5_0));
Define_label(mercury__passes_aux__write_pred_progress_message_5_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_pred_progress_message_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__passes_aux__write_pred_progress_message_5_0_i6,
		ENTRY(mercury__passes_aux__write_pred_progress_message_5_0));
Define_label(mercury__passes_aux__write_pred_progress_message_5_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_pred_progress_message_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__passes_aux__write_pred_progress_message_5_0));
Define_label(mercury__passes_aux__write_pred_progress_message_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);

BEGIN_MODULE(passes_aux_module14)
	init_entry(mercury__passes_aux__write_proc_progress_message_6_0);
	init_label(mercury__passes_aux__write_proc_progress_message_6_0_i2);
	init_label(mercury__passes_aux__write_proc_progress_message_6_0_i5);
	init_label(mercury__passes_aux__write_proc_progress_message_6_0_i6);
	init_label(mercury__passes_aux__write_proc_progress_message_6_0_i3);
BEGIN_CODE

/* code for predicate 'write_proc_progress_message'/6 in mode 0 */
Define_entry(mercury__passes_aux__write_proc_progress_message_6_0);
	MR_incr_sp_push_msg(5, "passes_aux:write_proc_progress_message/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 18;
	r2 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__write_proc_progress_message_6_0_i2,
		ENTRY(mercury__passes_aux__write_proc_progress_message_6_0));
Define_label(mercury__passes_aux__write_proc_progress_message_6_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_proc_progress_message_6_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__write_proc_progress_message_6_0_i3);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__write_proc_progress_message_6_0_i5,
		ENTRY(mercury__passes_aux__write_proc_progress_message_6_0));
Define_label(mercury__passes_aux__write_proc_progress_message_6_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_proc_progress_message_6_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__passes_aux__write_proc_progress_message_6_0_i6,
		ENTRY(mercury__passes_aux__write_proc_progress_message_6_0));
Define_label(mercury__passes_aux__write_proc_progress_message_6_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__write_proc_progress_message_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__passes_aux__write_proc_progress_message_6_0));
Define_label(mercury__passes_aux__write_proc_progress_message_6_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__io__report_stats_2_0);

BEGIN_MODULE(passes_aux_module15)
	init_entry(mercury__passes_aux__maybe_report_stats_3_0);
	init_label(mercury__passes_aux__maybe_report_stats_3_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_report_stats'/3 in mode 0 */
Define_entry(mercury__passes_aux__maybe_report_stats_3_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__maybe_report_stats_3_0_i3);
	r1 = r2;
	proceed();
Define_label(mercury__passes_aux__maybe_report_stats_3_0_i3);
	r1 = r2;
	tailcall(ENTRY(mercury__io__report_stats_2_0),
		ENTRY(mercury__passes_aux__maybe_report_stats_3_0));
END_MODULE


BEGIN_MODULE(passes_aux_module16)
	init_entry(mercury__passes_aux__maybe_write_string_4_0);
	init_label(mercury__passes_aux__maybe_write_string_4_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_write_string'/4 in mode 0 */
Define_entry(mercury__passes_aux__maybe_write_string_4_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__maybe_write_string_4_0_i3);
	r1 = r3;
	proceed();
Define_label(mercury__passes_aux__maybe_write_string_4_0_i3);
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__passes_aux__maybe_write_string_4_0));
END_MODULE

Declare_entry(mercury__io__flush_output_2_0);

BEGIN_MODULE(passes_aux_module17)
	init_entry(mercury__passes_aux__maybe_flush_output_3_0);
	init_label(mercury__passes_aux__maybe_flush_output_3_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_flush_output'/3 in mode 0 */
Define_entry(mercury__passes_aux__maybe_flush_output_3_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__maybe_flush_output_3_0_i3);
	r1 = r2;
	proceed();
Define_label(mercury__passes_aux__maybe_flush_output_3_0_i3);
	r1 = r2;
	tailcall(ENTRY(mercury__io__flush_output_2_0),
		ENTRY(mercury__passes_aux__maybe_flush_output_3_0));
END_MODULE

Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(passes_aux_module18)
	init_entry(mercury__passes_aux__report_error_3_0);
	init_label(mercury__passes_aux__report_error_3_0_i2);
	init_label(mercury__passes_aux__report_error_3_0_i3);
	init_label(mercury__passes_aux__report_error_3_0_i4);
BEGIN_CODE

/* code for predicate 'report_error'/3 in mode 0 */
Define_entry(mercury__passes_aux__report_error_3_0);
	MR_incr_sp_push_msg(2, "passes_aux:report_error/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Error: ", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_error_3_0_i2,
		ENTRY(mercury__passes_aux__report_error_3_0));
Define_label(mercury__passes_aux__report_error_3_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_error_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_error_3_0_i3,
		ENTRY(mercury__passes_aux__report_error_3_0));
Define_label(mercury__passes_aux__report_error_3_0_i3);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_error_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_error_3_0_i4,
		ENTRY(mercury__passes_aux__report_error_3_0));
Define_label(mercury__passes_aux__report_error_3_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_error_3_0));
	r2 = r1;
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		ENTRY(mercury__passes_aux__report_error_3_0));
END_MODULE

Declare_entry(mercury__io__call_system_4_0);

BEGIN_MODULE(passes_aux_module19)
	init_entry(mercury__passes_aux__invoke_system_command_4_0);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i2);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i5);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i6);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i7);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i8);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i3);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i10);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i15);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i16);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i11);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i19);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i17);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i23);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i24);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i25);
	init_label(mercury__passes_aux__invoke_system_command_4_0_i26);
BEGIN_CODE

/* code for predicate 'invoke_system_command'/4 in mode 0 */
Define_entry(mercury__passes_aux__invoke_system_command_4_0);
	MR_incr_sp_push_msg(3, "passes_aux:invoke_system_command/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 17;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__invoke_system_command_4_0_i2,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__invoke_system_command_4_0_i3);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("% Invoking system command `", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i5,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i6,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'...\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i7,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__passes_aux__invoke_system_command_4_0_i8,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__passes_aux__invoke_system_command_4_0_i10,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i3);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__call_system_4_0),
		mercury__passes_aux__invoke_system_command_4_0_i10,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__passes_aux__invoke_system_command_4_0_i11);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__invoke_system_command_4_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__invoke_system_command_4_0_i15);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__passes_aux__invoke_system_command_4_0_i15);
	r1 = (Word) MR_string_const("% done.\n", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i16,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i16);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__passes_aux__invoke_system_command_4_0_i11);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__passes_aux__invoke_system_command_4_0_i17);
	r1 = (Word) MR_string_const("Error: ", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i19,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i19);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("system command returned non-zero exit status.", 45);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i24,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i17);
	r1 = (Word) MR_string_const("Error: ", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i23,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i23);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("unable to invoke system command.", 32);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i24,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i24);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i25,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i25);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__passes_aux__invoke_system_command_4_0_i26,
		ENTRY(mercury__passes_aux__invoke_system_command_4_0));
Define_label(mercury__passes_aux__invoke_system_command_4_0_i26);
	update_prof_current_proc(LABEL(mercury__passes_aux__invoke_system_command_4_0));
	r2 = r1;
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__map__count_2_0);
Declare_entry(mercury__io__write_int_3_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__hlds_module__module_info_ctors_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;

BEGIN_MODULE(passes_aux_module20)
	init_entry(mercury__passes_aux__maybe_report_sizes_3_0);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i2);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i5);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i6);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i7);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i8);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i9);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i10);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i11);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i12);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i13);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i14);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i15);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i16);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i17);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i18);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i19);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i20);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i21);
	init_label(mercury__passes_aux__maybe_report_sizes_3_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_report_sizes'/3 in mode 0 */
Define_entry(mercury__passes_aux__maybe_report_sizes_3_0);
	MR_incr_sp_push_msg(3, "passes_aux:maybe_report_sizes/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 20;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i2,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__maybe_report_sizes_3_0_i3);
	MR_stackvar(2) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i5,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	call_localret(ENTRY(mercury__map__count_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i6,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("Pred table", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i7,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": count = ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i8,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i9,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i9);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i10,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i11,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i11);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_11);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	call_localret(ENTRY(mercury__map__count_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i12,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("Type table", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i13,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i13);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": count = ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i14,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i14);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i15,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i15);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i16,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i16);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_ctors_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i17,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i17);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_passes_aux__common_12);
	call_localret(ENTRY(mercury__map__count_2_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i18,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i18);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Constructor table", 17);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i19,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i19);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": count = ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i20,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i20);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__passes_aux__maybe_report_sizes_3_0_i21,
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i21);
	update_prof_current_proc(LABEL(mercury__passes_aux__maybe_report_sizes_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__passes_aux__maybe_report_sizes_3_0));
Define_label(mercury__passes_aux__maybe_report_sizes_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__proc_info_context_2_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__drop_3_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__prog_out__write_context_3_0);

BEGIN_MODULE(passes_aux_module21)
	init_entry(mercury__passes_aux__report_pred_proc_id_7_0);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i2);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i3);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i4);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i5);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i6);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i7);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i8);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i10);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i9);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i12);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i13);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i15);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i16);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i17);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i18);
	init_label(mercury__passes_aux__report_pred_proc_id_7_0_i19);
BEGIN_CODE

/* code for predicate 'report_pred_proc_id'/7 in mode 0 */
Define_entry(mercury__passes_aux__report_pred_proc_id_7_0);
	MR_incr_sp_push_msg(8, "passes_aux:report_pred_proc_id/7");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r4;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i2,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i3,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i3);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i4,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i5,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_context_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i6,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i7,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	MR_stackvar(4) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i8,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r2 = ((Integer) r1 - (Integer) MR_stackvar(6));
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__drop_3_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i10,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__passes_aux__report_pred_proc_id_7_0_i9);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	GOTO_LABEL(mercury__passes_aux__report_pred_proc_id_7_0_i13);
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i9);
	r1 = (Word) MR_string_const("report_pred_proc_id: list__drop failed", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i12,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i13);
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__report_pred_proc_id_7_0_i15);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i16,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i15);
	MR_stackvar(2) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i16,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i16);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In `", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i17,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i17);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r4 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__passes_aux__report_pred_name_mode_5_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i18,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i18);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("':\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_proc_id_7_0_i19,
		ENTRY(mercury__passes_aux__report_pred_proc_id_7_0));
Define_label(mercury__passes_aux__report_pred_proc_id_7_0_i19);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_proc_id_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_inst_var_type_0;
Declare_entry(mercury__varset__init_1_0);
Declare_entry(mercury__mode_util__strip_builtin_qualifiers_from_mode_list_2_0);
Declare_entry(mercury__mercury_to_mercury__mercury_output_mode_list_4_0);
Declare_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
Declare_entry(mercury__mercury_to_mercury__mercury_output_mode_4_0);

BEGIN_MODULE(passes_aux_module22)
	init_entry(mercury__passes_aux__report_pred_name_mode_5_0);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i4);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i9);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i10);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i11);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i12);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i3);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i15);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i16);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i17);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i18);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i23);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i24);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i20);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i27);
	init_label(mercury__passes_aux__report_pred_name_mode_5_0_i2);
BEGIN_CODE

/* code for predicate 'report_pred_name_mode'/5 in mode 0 */
Define_entry(mercury__passes_aux__report_pred_name_mode_5_0);
	MR_incr_sp_push_msg(5, "passes_aux:report_pred_name_mode/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__report_pred_name_mode_5_0_i3);
	MR_stackvar(2) = r3;
	r1 = r2;
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i4,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__report_pred_name_mode_5_0_i2);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i9,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i9);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("(", 1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i10,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__mode_util__strip_builtin_qualifiers_from_mode_list_2_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i11,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i11);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_mode_list_4_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i12,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i15,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i15);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__mode_util__strip_builtin_qualifiers_from_mode_list_2_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i16,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i16);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	call_localret(ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i17,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i17);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i18,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
	}
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i18);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__report_pred_name_mode_5_0_i20);
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i23,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i23);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_mode_list_4_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i24,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i24);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i20,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i20);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__passes_aux__report_pred_name_mode_5_0_i27,
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i27);
	update_prof_current_proc(LABEL(mercury__passes_aux__report_pred_name_mode_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__mercury_to_mercury__mercury_output_mode_4_0),
		ENTRY(mercury__passes_aux__report_pred_name_mode_5_0));
Define_label(mercury__passes_aux__report_pred_name_mode_5_0_i2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
Declare_entry(mercury__do_call_closure);
Declare_entry(mercury__hlds_module__module_info_set_pred_info_4_0);
Declare_entry(mercury__hlds_module__module_info_incr_errors_2_0);

BEGIN_MODULE(passes_aux_module23)
	init_entry(mercury__passes_aux__process_nonimported_pred_7_0);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i2);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i8);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i6);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i12);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i3);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i14);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i15);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i16);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i19);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i22);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i23);
	init_label(mercury__passes_aux__process_nonimported_pred_7_0_i18);
BEGIN_CODE

/* code for predicate 'process_nonimported_pred'/7 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_pred_7_0);
	MR_incr_sp_push_msg(7, "passes_aux:process_nonimported_pred/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r4;
	r2 = r3;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i2,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i2);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i8,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_pred_7_0_i6);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i6);
	r1 = MR_stackvar(2);
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_pred_7_0_i12,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i12);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	if (r1)
		GOTO_LABEL(mercury__passes_aux__process_nonimported_pred_7_0_i3);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i3);
	r1 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = r1;
	r7 = MR_stackvar(5);
	r1 = MR_stackvar(1);
	r2 = (Integer) 4;
	r3 = (Integer) 5;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_pred_7_0_i14,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i14);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	MR_stackvar(1) = r3;
	r3 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_set_pred_info_4_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i15,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i15);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i16,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i16);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	if (((Integer) MR_stackvar(2) > (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_pred_7_0_i19);
	if (((Integer) MR_stackvar(1) <= (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_pred_7_0_i18);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_pred_7_0_i18);
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i19);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i22,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i22);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_incr_errors_2_0),
		mercury__passes_aux__process_nonimported_pred_7_0_i23,
		STATIC(mercury__passes_aux__process_nonimported_pred_7_0));
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i23);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_pred_7_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__passes_aux__process_nonimported_pred_7_0_i18);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module24)
	init_entry(mercury__passes_aux__process_nonimported_procs_in_preds_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i1002);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i8);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i10);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i11);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs_in_preds'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_in_preds_8_0);
	MR_incr_sp_push_msg(8, "passes_aux:process_nonimported_procs_in_preds/8");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
	MR_stackvar(7) = r1;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = (Integer) 1;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i8,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i7);
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i10,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i10);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(STATIC(mercury__passes_aux__process_nonimported_procs_8_0),
		mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i11,
		STATIC(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i11);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0));
	r4 = r2;
	r2 = r1;
	r5 = r3;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i7);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i1002);
Define_label(mercury__passes_aux__process_nonimported_procs_in_preds_8_0_i3);
	r1 = r2;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(passes_aux_module25)
	init_entry(mercury__passes_aux__process_nonimported_procs_8_0);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i1003);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i4);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i5);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i6);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i7);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i10);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i12);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i14);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i15);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i16);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i17);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i18);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i19);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i20);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i21);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i24);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i27);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i23);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i30);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i31);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i32);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i33);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i34);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i35);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i36);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i37);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i8);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i38);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i39);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i40);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i41);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i42);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i43);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i44);
	init_label(mercury__passes_aux__process_nonimported_procs_8_0_i3);
BEGIN_CODE

/* code for predicate 'process_nonimported_procs'/8 in mode 0 */
Define_static(mercury__passes_aux__process_nonimported_procs_8_0);
	MR_incr_sp_push_msg(12, "passes_aux:process_nonimported_procs/8");
	MR_stackvar(12) = (Word) MR_succip;
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i4,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i4);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i5,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i5);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i6,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i6);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i7,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i7);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r2 = MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i10) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i12) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i14) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i16));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i10);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i15,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i12);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Integer) 3;
	r3 = (Integer) 1;
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(3);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i15,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i14);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = (Integer) 4;
	r3 = (Integer) 1;
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(3);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i15,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i15);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(7) = MR_stackvar(4);
	MR_stackvar(4) = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i17) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i19) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i30) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i32) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i34) AND
		LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i36));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i17);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 5;
	r3 = (Integer) 2;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(3);
	r8 = MR_stackvar(4);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i18,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i18);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(4) = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(7) = r2;
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i19);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 5;
	r3 = (Integer) 5;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(3);
	r8 = MR_stackvar(4);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i20,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i20);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(4) = MR_stackvar(2);
	MR_stackvar(2) = r2;
	MR_stackvar(8) = r1;
	r1 = (Integer) 1;
	r2 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i21,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i21);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	if (((Integer) MR_stackvar(7) > (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i24);
	if (((Integer) MR_stackvar(3) <= (Integer) 0))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i23);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i23);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i24);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i27,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i27);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_module__module_info_incr_errors_2_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i8,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i23);
	r1 = MR_stackvar(8);
	MR_stackvar(7) = r2;
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i30);
	r1 = (Word) MR_string_const("passes_aux:process_non_imported_procs", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i31,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i31);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r1 = MR_stackvar(3);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i32);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 2;
	r3 = (Integer) 2;
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i33,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i33);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(7) = MR_stackvar(4);
	MR_stackvar(4) = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r2;
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i34);
	r6 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 5;
	r3 = (Integer) 3;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	r7 = MR_stackvar(3);
	r8 = MR_stackvar(4);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i35,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i35);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(4) = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r2;
	MR_stackvar(7) = r3;
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i8);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i36);
	r6 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(2) = r1;
	r7 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = (Integer) 5;
	r3 = (Integer) 3;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	r8 = MR_stackvar(3);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__passes_aux__process_nonimported_procs_8_0_i37,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i37);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(7) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__passes_aux__process_nonimported_procs_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_stackvar(2) = r1;
	r1 = r3;
	MR_stackvar(4) = MR_tempr1;
	}
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i8);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i38,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i38);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r3 = r1;
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i39,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i39);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	MR_stackvar(10) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i40,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i40);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i41,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i41);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r2 = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i42,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i42);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i43,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i43);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__passes_aux__process_nonimported_procs_8_0_i44,
		STATIC(mercury__passes_aux__process_nonimported_procs_8_0));
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i44);
	update_prof_current_proc(LABEL(mercury__passes_aux__process_nonimported_procs_8_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r5 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__passes_aux__process_nonimported_procs_8_0_i1003);
Define_label(mercury__passes_aux__process_nonimported_procs_8_0_i3);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_unify_pred_2_0);
Declare_entry(mercury____Unify___std_util__univ_0_0);

BEGIN_MODULE(passes_aux_module26)
	init_entry(mercury____Unify___passes_aux__task_0_0);
	init_label(mercury____Unify___passes_aux__task_0_0_i1017);
	init_label(mercury____Unify___passes_aux__task_0_0_i1018);
	init_label(mercury____Unify___passes_aux__task_0_0_i1019);
	init_label(mercury____Unify___passes_aux__task_0_0_i16);
	init_label(mercury____Unify___passes_aux__task_0_0_i17);
	init_label(mercury____Unify___passes_aux__task_0_0_i21);
	init_label(mercury____Unify___passes_aux__task_0_0_i25);
	init_label(mercury____Unify___passes_aux__task_0_0_i29);
	init_label(mercury____Unify___passes_aux__task_0_0_i33);
	init_label(mercury____Unify___passes_aux__task_0_0_i37);
	init_label(mercury____Unify___passes_aux__task_0_0_i39);
	init_label(mercury____Unify___passes_aux__task_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___passes_aux__task_0_0);
	MR_incr_sp_push_msg(3, "passes_aux:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___passes_aux__task_0_0_i1017) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i1018) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i1019) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i16));
Define_label(mercury____Unify___passes_aux__task_0_0_i1017);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i1018);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i1019);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Unify___passes_aux__task_0_0_i17) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i21) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i25) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i29) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i33) AND
		LABEL(mercury____Unify___passes_aux__task_0_0_i37));
Define_label(mercury____Unify___passes_aux__task_0_0_i17);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i21);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i25);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i29);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i33);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i37);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 5))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___passes_aux__task_0_0_i39,
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Unify___passes_aux__task_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___std_util__univ_0_0),
		ENTRY(mercury____Unify___passes_aux__task_0_0));
Define_label(mercury____Unify___passes_aux__task_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module27)
	init_entry(mercury____Index___passes_aux__task_0_0);
	init_label(mercury____Index___passes_aux__task_0_0_i4);
	init_label(mercury____Index___passes_aux__task_0_0_i5);
	init_label(mercury____Index___passes_aux__task_0_0_i6);
	init_label(mercury____Index___passes_aux__task_0_0_i7);
	init_label(mercury____Index___passes_aux__task_0_0_i8);
	init_label(mercury____Index___passes_aux__task_0_0_i9);
	init_label(mercury____Index___passes_aux__task_0_0_i10);
	init_label(mercury____Index___passes_aux__task_0_0_i11);
	init_label(mercury____Index___passes_aux__task_0_0_i12);
	init_label(mercury____Index___passes_aux__task_0_0_i13);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___passes_aux__task_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___passes_aux__task_0_0_i4) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i5) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i6) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i7));
Define_label(mercury____Index___passes_aux__task_0_0_i4);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i6);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Index___passes_aux__task_0_0_i8) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i9) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i10) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i11) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i12) AND
		LABEL(mercury____Index___passes_aux__task_0_0_i13));
Define_label(mercury____Index___passes_aux__task_0_0_i8);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i9);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i10);
	r1 = (Integer) 5;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i11);
	r1 = (Integer) 6;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i12);
	r1 = (Integer) 7;
	proceed();
Define_label(mercury____Index___passes_aux__task_0_0_i13);
	r1 = (Integer) 8;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_pred_3_0);
Declare_entry(mercury____Compare___std_util__univ_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(passes_aux_module28)
	init_entry(mercury____Compare___passes_aux__task_0_0);
	init_label(mercury____Compare___passes_aux__task_0_0_i2);
	init_label(mercury____Compare___passes_aux__task_0_0_i3);
	init_label(mercury____Compare___passes_aux__task_0_0_i4);
	init_label(mercury____Compare___passes_aux__task_0_0_i5);
	init_label(mercury____Compare___passes_aux__task_0_0_i10);
	init_label(mercury____Compare___passes_aux__task_0_0_i13);
	init_label(mercury____Compare___passes_aux__task_0_0_i16);
	init_label(mercury____Compare___passes_aux__task_0_0_i19);
	init_label(mercury____Compare___passes_aux__task_0_0_i20);
	init_label(mercury____Compare___passes_aux__task_0_0_i23);
	init_label(mercury____Compare___passes_aux__task_0_0_i26);
	init_label(mercury____Compare___passes_aux__task_0_0_i29);
	init_label(mercury____Compare___passes_aux__task_0_0_i32);
	init_label(mercury____Compare___passes_aux__task_0_0_i35);
	init_label(mercury____Compare___passes_aux__task_0_0_i38);
	init_label(mercury____Compare___passes_aux__task_0_0_i7);
	init_label(mercury____Compare___passes_aux__task_0_0_i46);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___passes_aux__task_0_0);
	MR_incr_sp_push_msg(4, "passes_aux:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury____Index___passes_aux__task_0_0),
		mercury____Compare___passes_aux__task_0_0_i2,
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___passes_aux__task_0_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury____Index___passes_aux__task_0_0),
		mercury____Compare___passes_aux__task_0_0_i3,
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___passes_aux__task_0_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___passes_aux__task_0_0_i4);
	if (((Integer) MR_stackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i5);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___passes_aux__task_0_0_i5);
	r1 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___passes_aux__task_0_0_i10) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i13) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i16) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i19));
Define_label(mercury____Compare___passes_aux__task_0_0_i10);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i13);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i16);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i19);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Compare___passes_aux__task_0_0_i20) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i23) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i26) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i29) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i32) AND
		LABEL(mercury____Compare___passes_aux__task_0_0_i35));
Define_label(mercury____Compare___passes_aux__task_0_0_i20);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i23);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i26);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i29);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i32);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i35);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___passes_aux__task_0_0_i38,
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i38);
	update_prof_current_proc(LABEL(mercury____Compare___passes_aux__task_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___passes_aux__task_0_0_i46);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___std_util__univ_0_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i7);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___passes_aux__task_0_0));
Define_label(mercury____Compare___passes_aux__task_0_0_i46);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(passes_aux_module29)
	init_entry(mercury____Unify___passes_aux__pred_error_task_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___passes_aux__pred_error_task_0_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___passes_aux__pred_error_task_0_0));
END_MODULE

Declare_entry(mercury__builtin_index_pred_2_0);

BEGIN_MODULE(passes_aux_module30)
	init_entry(mercury____Index___passes_aux__pred_error_task_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___passes_aux__pred_error_task_0_0);
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___passes_aux__pred_error_task_0_0));
END_MODULE


BEGIN_MODULE(passes_aux_module31)
	init_entry(mercury____Compare___passes_aux__pred_error_task_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___passes_aux__pred_error_task_0_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___passes_aux__pred_error_task_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__passes_aux_maybe_bunch_0(void)
{
	passes_aux_module0();
	passes_aux_module1();
	passes_aux_module2();
	passes_aux_module3();
	passes_aux_module4();
	passes_aux_module5();
	passes_aux_module6();
	passes_aux_module7();
	passes_aux_module8();
	passes_aux_module9();
	passes_aux_module10();
	passes_aux_module11();
	passes_aux_module12();
	passes_aux_module13();
	passes_aux_module14();
	passes_aux_module15();
	passes_aux_module16();
	passes_aux_module17();
	passes_aux_module18();
	passes_aux_module19();
	passes_aux_module20();
	passes_aux_module21();
	passes_aux_module22();
	passes_aux_module23();
	passes_aux_module24();
	passes_aux_module25();
	passes_aux_module26();
	passes_aux_module27();
	passes_aux_module28();
	passes_aux_module29();
	passes_aux_module30();
	passes_aux_module31();
}

#endif

void mercury__passes_aux__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__passes_aux__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__passes_aux_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_passes_aux__type_ctor_info_pred_error_task_0,
			passes_aux__pred_error_task_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_passes_aux__type_ctor_info_task_0,
			passes_aux__task_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
