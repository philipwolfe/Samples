/*
** Automatically generated from `pd_cost.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__pd_cost__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0);
Define_extern_entry(mercury__pd_cost__goal_2_0);
Declare_label(mercury__pd_cost__goal_2_0_i1002);
Declare_label(mercury__pd_cost__goal_2_0_i4);
Declare_label(mercury__pd_cost__goal_2_0_i6);
Declare_label(mercury__pd_cost__goal_2_0_i7);
Declare_label(mercury__pd_cost__goal_2_0_i10);
Declare_label(mercury__pd_cost__goal_2_0_i11);
Declare_label(mercury__pd_cost__goal_2_0_i12);
Declare_label(mercury__pd_cost__goal_2_0_i13);
Declare_label(mercury__pd_cost__goal_2_0_i15);
Declare_label(mercury__pd_cost__goal_2_0_i16);
Declare_label(mercury__pd_cost__goal_2_0_i17);
Declare_label(mercury__pd_cost__goal_2_0_i18);
Declare_label(mercury__pd_cost__goal_2_0_i20);
Declare_label(mercury__pd_cost__goal_2_0_i21);
Declare_label(mercury__pd_cost__goal_2_0_i22);
Declare_label(mercury__pd_cost__goal_2_0_i24);
Declare_label(mercury__pd_cost__goal_2_0_i25);
Declare_label(mercury__pd_cost__goal_2_0_i27);
Declare_label(mercury__pd_cost__goal_2_0_i28);
Declare_label(mercury__pd_cost__goal_2_0_i29);
Declare_label(mercury__pd_cost__goal_2_0_i30);
Declare_label(mercury__pd_cost__goal_2_0_i32);
Declare_label(mercury__pd_cost__goal_2_0_i34);
Declare_label(mercury__pd_cost__goal_2_0_i35);
Declare_label(mercury__pd_cost__goal_2_0_i36);
Declare_label(mercury__pd_cost__goal_2_0_i37);
Declare_label(mercury__pd_cost__goal_2_0_i38);
Declare_label(mercury__pd_cost__goal_2_0_i40);
Declare_label(mercury__pd_cost__goal_2_0_i39);
Declare_label(mercury__pd_cost__goal_2_0_i41);
Declare_label(mercury__pd_cost__goal_2_0_i43);
Declare_label(mercury__pd_cost__goal_2_0_i44);
Declare_label(mercury__pd_cost__goal_2_0_i45);
Declare_label(mercury__pd_cost__goal_2_0_i46);
Declare_label(mercury__pd_cost__goal_2_0_i48);
Define_extern_entry(mercury__pd_cost__reg_assign_1_0);
Define_extern_entry(mercury__pd_cost__heap_assign_1_0);
Define_extern_entry(mercury__pd_cost__simple_test_1_0);
Define_extern_entry(mercury__pd_cost__heap_incr_1_0);
Define_extern_entry(mercury__pd_cost__stack_flush_1_0);
Define_extern_entry(mercury__pd_cost__builtin_call_1_0);
Define_extern_entry(mercury__pd_cost__call_1_0);
Define_extern_entry(mercury__pd_cost__higher_order_call_1_0);
Define_extern_entry(mercury__pd_cost__eliminate_switch_1_0);
Define_extern_entry(mercury__pd_cost__fold_1_0);
Define_extern_entry(mercury__pd_cost__recursive_fold_1_0);
Declare_static(mercury__pd_cost__unify_3_0);
Declare_label(mercury__pd_cost__unify_3_0_i4);
Declare_label(mercury__pd_cost__unify_3_0_i6);
Declare_label(mercury__pd_cost__unify_3_0_i8);
Declare_label(mercury__pd_cost__unify_3_0_i10);
Declare_label(mercury__pd_cost__unify_3_0_i11);
Declare_label(mercury__pd_cost__unify_3_0_i14);
Declare_label(mercury__pd_cost__unify_3_0_i15);
Declare_label(mercury__pd_cost__unify_3_0_i1007);
Declare_label(mercury__pd_cost__unify_3_0_i16);
Declare_label(mercury__pd_cost__unify_3_0_i1008);
Declare_label(mercury__pd_cost__unify_3_0_i18);
Declare_static(mercury__pd_cost__goals_3_0);
Declare_label(mercury__pd_cost__goals_3_0_i1001);
Declare_label(mercury__pd_cost__goals_3_0_i4);
Declare_label(mercury__pd_cost__goals_3_0_i3);
Declare_static(mercury__pd_cost__cases_3_0);
Declare_label(mercury__pd_cost__cases_3_0_i1001);
Declare_label(mercury__pd_cost__cases_3_0_i4);
Declare_label(mercury__pd_cost__cases_3_0_i3);

static const struct mercury_data_pd_cost__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_cost__common_0;

static const struct mercury_data_pd_cost__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_cost__common_1;

static const struct mercury_data_pd_cost__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_pd_cost__common_2;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_pd_cost__common_0_struct mercury_data_pd_cost__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_pd_cost__common_1_struct mercury_data_pd_cost__common_1 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0)
};

static const struct mercury_data_pd_cost__common_2_struct mercury_data_pd_cost__common_2 = {
	(Integer) 0,
	MR_string_const("pd_cost", 7),
	MR_string_const("pd_cost", 7),
	MR_string_const("IntroducedFrom__pred__unify__136__1", 35),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0)
};

Declare_entry(mercury__set__member_2_0);

BEGIN_MODULE(pd_cost_module0)
	init_entry(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__unify__136__1'/2 in mode 0 */
Define_static(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	tailcall(ENTRY(mercury__set__member_2_0),
		STATIC(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0));
END_MODULE

Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__prog_data__may_call_mercury_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(pd_cost_module1)
	init_entry(mercury__pd_cost__goal_2_0);
	init_label(mercury__pd_cost__goal_2_0_i1002);
	init_label(mercury__pd_cost__goal_2_0_i4);
	init_label(mercury__pd_cost__goal_2_0_i6);
	init_label(mercury__pd_cost__goal_2_0_i7);
	init_label(mercury__pd_cost__goal_2_0_i10);
	init_label(mercury__pd_cost__goal_2_0_i11);
	init_label(mercury__pd_cost__goal_2_0_i12);
	init_label(mercury__pd_cost__goal_2_0_i13);
	init_label(mercury__pd_cost__goal_2_0_i15);
	init_label(mercury__pd_cost__goal_2_0_i16);
	init_label(mercury__pd_cost__goal_2_0_i17);
	init_label(mercury__pd_cost__goal_2_0_i18);
	init_label(mercury__pd_cost__goal_2_0_i20);
	init_label(mercury__pd_cost__goal_2_0_i21);
	init_label(mercury__pd_cost__goal_2_0_i22);
	init_label(mercury__pd_cost__goal_2_0_i24);
	init_label(mercury__pd_cost__goal_2_0_i25);
	init_label(mercury__pd_cost__goal_2_0_i27);
	init_label(mercury__pd_cost__goal_2_0_i28);
	init_label(mercury__pd_cost__goal_2_0_i29);
	init_label(mercury__pd_cost__goal_2_0_i30);
	init_label(mercury__pd_cost__goal_2_0_i32);
	init_label(mercury__pd_cost__goal_2_0_i34);
	init_label(mercury__pd_cost__goal_2_0_i35);
	init_label(mercury__pd_cost__goal_2_0_i36);
	init_label(mercury__pd_cost__goal_2_0_i37);
	init_label(mercury__pd_cost__goal_2_0_i38);
	init_label(mercury__pd_cost__goal_2_0_i40);
	init_label(mercury__pd_cost__goal_2_0_i39);
	init_label(mercury__pd_cost__goal_2_0_i41);
	init_label(mercury__pd_cost__goal_2_0_i43);
	init_label(mercury__pd_cost__goal_2_0_i44);
	init_label(mercury__pd_cost__goal_2_0_i45);
	init_label(mercury__pd_cost__goal_2_0_i46);
	init_label(mercury__pd_cost__goal_2_0_i48);
BEGIN_CODE

/* code for predicate 'goal'/2 in mode 0 */
Define_entry(mercury__pd_cost__goal_2_0);
	MR_incr_sp_push_msg(5, "pd_cost:goal/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__pd_cost__goal_2_0_i1002);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__pd_cost__goal_2_0_i4) AND
		LABEL(mercury__pd_cost__goal_2_0_i6) AND
		LABEL(mercury__pd_cost__goal_2_0_i15) AND
		LABEL(mercury__pd_cost__goal_2_0_i20));
Define_label(mercury__pd_cost__goal_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_cost__goals_3_0),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i6);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__pd_cost__goal_2_0_i7);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_cost__builtin_call_1_0),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i7);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__pd_cost__stack_flush_1_0),
		mercury__pd_cost__goal_2_0_i10,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__pd_cost__goal_2_0_i11,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(2) = ((Integer) r1 / (Integer) 2);
	call_localret(STATIC(mercury__pd_cost__reg_assign_1_0),
		mercury__pd_cost__goal_2_0_i12,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(3) = r1;
	call_localret(STATIC(mercury__pd_cost__call_1_0),
		mercury__pd_cost__goal_2_0_i13,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r1 = (((Integer) MR_stackvar(1) + (Integer) r1) + ((Integer) MR_stackvar(3) * (Integer) MR_stackvar(2)));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pd_cost__goal_2_0_i15);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__pd_cost__goal_2_0_i16,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__pd_cost__reg_assign_1_0),
		mercury__pd_cost__goal_2_0_i17,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = (((Integer) r1 * (Integer) r2) / (Integer) 2);
	call_localret(STATIC(mercury__pd_cost__stack_flush_1_0),
		mercury__pd_cost__goal_2_0_i18,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i18);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(2) = r1;
	call_localret(STATIC(mercury__pd_cost__higher_order_call_1_0),
		mercury__pd_cost__goal_2_0_i37,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i20);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__pd_cost__goal_2_0_i21) AND
		LABEL(mercury__pd_cost__goal_2_0_i24) AND
		LABEL(mercury__pd_cost__goal_2_0_i27) AND
		LABEL(mercury__pd_cost__goal_2_0_i30) AND
		LABEL(mercury__pd_cost__goal_2_0_i32) AND
		LABEL(mercury__pd_cost__goal_2_0_i34) AND
		LABEL(mercury__pd_cost__goal_2_0_i38) AND
		LABEL(mercury__pd_cost__goal_2_0_i46) AND
		LABEL(mercury__pd_cost__goal_2_0_i48));
Define_label(mercury__pd_cost__goal_2_0_i21);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	call_localret(STATIC(mercury__pd_cost__simple_test_1_0),
		mercury__pd_cost__goal_2_0_i22,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i22);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_cost__cases_3_0),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i24);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__pd_cost__goal_2_0_i25,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i25);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_cost__unify_3_0),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i27);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__pd_cost__goals_3_0),
		mercury__pd_cost__goal_2_0_i28,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i28);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__pd_cost__stack_flush_1_0),
		mercury__pd_cost__goal_2_0_i29,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i29);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r1 = ((Integer) MR_stackvar(1) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pd_cost__goal_2_0_i30);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__pd_cost__goal_2_0_i1002);
Define_label(mercury__pd_cost__goal_2_0_i32);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__pd_cost__goal_2_0_i1002);
Define_label(mercury__pd_cost__goal_2_0_i34);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	localcall(mercury__pd_cost__goal_2_0,
		LABEL(mercury__pd_cost__goal_2_0_i35),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i35);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__pd_cost__goal_2_0,
		LABEL(mercury__pd_cost__goal_2_0_i36),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i36);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__pd_cost__goal_2_0,
		LABEL(mercury__pd_cost__goal_2_0_i37),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i37);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r1 = (((Integer) MR_stackvar(1) + (Integer) MR_stackvar(2)) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pd_cost__goal_2_0_i38);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	call_localret(ENTRY(mercury__prog_data__may_call_mercury_2_0),
		mercury__pd_cost__goal_2_0_i40,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i40);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	if (((Integer) 1 != (Integer) r1))
		GOTO_LABEL(mercury__pd_cost__goal_2_0_i39);
	MR_stackvar(2) = (Integer) 0;
	call_localret(STATIC(mercury__pd_cost__call_1_0),
		mercury__pd_cost__goal_2_0_i43,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i39);
	call_localret(STATIC(mercury__pd_cost__stack_flush_1_0),
		mercury__pd_cost__goal_2_0_i41,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i41);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(2) = r1;
	call_localret(STATIC(mercury__pd_cost__call_1_0),
		mercury__pd_cost__goal_2_0_i43,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i43);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__pd_cost__goal_2_0_i44,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i44);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	MR_stackvar(4) = ((Integer) r1 / (Integer) 2);
	call_localret(STATIC(mercury__pd_cost__reg_assign_1_0),
		mercury__pd_cost__goal_2_0_i45,
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i45);
	update_prof_current_proc(LABEL(mercury__pd_cost__goal_2_0));
	r1 = (((Integer) MR_stackvar(2) + (Integer) MR_stackvar(3)) + ((Integer) r1 * (Integer) MR_stackvar(4)));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pd_cost__goal_2_0_i46);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_cost__goals_3_0),
		ENTRY(mercury__pd_cost__goal_2_0));
Define_label(mercury__pd_cost__goal_2_0_i48);
	r1 = (Word) MR_string_const("pd_cost__goal: unexpected bi_implication", 40);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_cost__goal_2_0));
END_MODULE


BEGIN_MODULE(pd_cost_module2)
	init_entry(mercury__pd_cost__reg_assign_1_0);
BEGIN_CODE

/* code for predicate 'reg_assign'/1 in mode 0 */
Define_entry(mercury__pd_cost__reg_assign_1_0);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module3)
	init_entry(mercury__pd_cost__heap_assign_1_0);
BEGIN_CODE

/* code for predicate 'heap_assign'/1 in mode 0 */
Define_entry(mercury__pd_cost__heap_assign_1_0);
	r1 = (Integer) 2;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module4)
	init_entry(mercury__pd_cost__simple_test_1_0);
BEGIN_CODE

/* code for predicate 'simple_test'/1 in mode 0 */
Define_entry(mercury__pd_cost__simple_test_1_0);
	r1 = (Integer) 3;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module5)
	init_entry(mercury__pd_cost__heap_incr_1_0);
BEGIN_CODE

/* code for predicate 'heap_incr'/1 in mode 0 */
Define_entry(mercury__pd_cost__heap_incr_1_0);
	r1 = (Integer) 3;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module6)
	init_entry(mercury__pd_cost__stack_flush_1_0);
BEGIN_CODE

/* code for predicate 'stack_flush'/1 in mode 0 */
Define_entry(mercury__pd_cost__stack_flush_1_0);
	r1 = (Integer) 5;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module7)
	init_entry(mercury__pd_cost__builtin_call_1_0);
BEGIN_CODE

/* code for predicate 'builtin_call'/1 in mode 0 */
Define_entry(mercury__pd_cost__builtin_call_1_0);
	r1 = (Integer) 3;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module8)
	init_entry(mercury__pd_cost__call_1_0);
BEGIN_CODE

/* code for predicate 'call'/1 in mode 0 */
Define_entry(mercury__pd_cost__call_1_0);
	r1 = (Integer) 3;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module9)
	init_entry(mercury__pd_cost__higher_order_call_1_0);
BEGIN_CODE

/* code for predicate 'higher_order_call'/1 in mode 0 */
Define_entry(mercury__pd_cost__higher_order_call_1_0);
	r1 = (Integer) 8;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module10)
	init_entry(mercury__pd_cost__eliminate_switch_1_0);
BEGIN_CODE

/* code for predicate 'eliminate_switch'/1 in mode 0 */
Define_entry(mercury__pd_cost__eliminate_switch_1_0);
	r1 = (Integer) 5;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module11)
	init_entry(mercury__pd_cost__fold_1_0);
BEGIN_CODE

/* code for predicate 'fold'/1 in mode 0 */
Define_entry(mercury__pd_cost__fold_1_0);
	r1 = (Integer) 15;
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module12)
	init_entry(mercury__pd_cost__recursive_fold_1_0);
BEGIN_CODE

/* code for predicate 'recursive_fold'/1 in mode 0 */
Define_entry(mercury__pd_cost__recursive_fold_1_0);
	r1 = (Integer) 25;
	proceed();
END_MODULE

Declare_entry(mercury__list__filter_3_0);

BEGIN_MODULE(pd_cost_module13)
	init_entry(mercury__pd_cost__unify_3_0);
	init_label(mercury__pd_cost__unify_3_0_i4);
	init_label(mercury__pd_cost__unify_3_0_i6);
	init_label(mercury__pd_cost__unify_3_0_i8);
	init_label(mercury__pd_cost__unify_3_0_i10);
	init_label(mercury__pd_cost__unify_3_0_i11);
	init_label(mercury__pd_cost__unify_3_0_i14);
	init_label(mercury__pd_cost__unify_3_0_i15);
	init_label(mercury__pd_cost__unify_3_0_i1007);
	init_label(mercury__pd_cost__unify_3_0_i16);
	init_label(mercury__pd_cost__unify_3_0_i1008);
	init_label(mercury__pd_cost__unify_3_0_i18);
BEGIN_CODE

/* code for predicate 'unify'/3 in mode 0 */
Define_static(mercury__pd_cost__unify_3_0);
	MR_incr_sp_push_msg(2, "pd_cost:unify/3");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__pd_cost__unify_3_0_i4) AND
		LABEL(mercury__pd_cost__unify_3_0_i10) AND
		LABEL(mercury__pd_cost__unify_3_0_i1007) AND
		LABEL(mercury__pd_cost__unify_3_0_i1008));
Define_label(mercury__pd_cost__unify_3_0_i4);
	r3 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__pd_cost__unify_3_0_i6,
		STATIC(mercury__pd_cost__unify_3_0));
Define_label(mercury__pd_cost__unify_3_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_cost__unify_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_cost__unify_3_0_i16);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__pd_cost__unify_3_0_i8,
		STATIC(mercury__pd_cost__unify_3_0));
Define_label(mercury__pd_cost__unify_3_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_cost__unify_3_0));
	r1 = ((Integer) 3 + ((Integer) r1 * (Integer) 2));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_cost__unify_3_0_i10);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 4) != (Integer) 0))
		GOTO_LABEL(mercury__pd_cost__unify_3_0_i11);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__pd_cost__unify_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	MR_stackvar(1) = (Integer) 3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_2);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__pd_cost__unify_3_0_i14,
		STATIC(mercury__pd_cost__unify_3_0));
Define_label(mercury__pd_cost__unify_3_0_i11);
	MR_stackvar(1) = (Integer) 0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__pd_cost__unify_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__pd_cost__IntroducedFrom__pred__unify__136__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_2);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__pd_cost__unify_3_0_i14,
		STATIC(mercury__pd_cost__unify_3_0));
Define_label(mercury__pd_cost__unify_3_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_cost__unify_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_cost__common_0);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__pd_cost__unify_3_0_i15,
		STATIC(mercury__pd_cost__unify_3_0));
Define_label(mercury__pd_cost__unify_3_0_i15);
	update_prof_current_proc(LABEL(mercury__pd_cost__unify_3_0));
	r1 = (((Integer) MR_stackvar(1) + (Integer) 3) + ((Integer) r1 * (Integer) 2));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_cost__unify_3_0_i1007);
	r1 = (Integer) 0;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_cost__unify_3_0_i16);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_cost__unify_3_0_i1008);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__pd_cost__unify_3_0_i18);
	r1 = (Integer) 3;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_cost__unify_3_0_i18);
	r1 = (Integer) 5;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module14)
	init_entry(mercury__pd_cost__goals_3_0);
	init_label(mercury__pd_cost__goals_3_0_i1001);
	init_label(mercury__pd_cost__goals_3_0_i4);
	init_label(mercury__pd_cost__goals_3_0_i3);
BEGIN_CODE

/* code for predicate 'goals'/3 in mode 0 */
Define_static(mercury__pd_cost__goals_3_0);
	MR_incr_sp_push_msg(3, "pd_cost:goals/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__pd_cost__goals_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_cost__goals_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__pd_cost__goal_2_0),
		mercury__pd_cost__goals_3_0_i4,
		STATIC(mercury__pd_cost__goals_3_0));
Define_label(mercury__pd_cost__goals_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_cost__goals_3_0));
	r2 = ((Integer) MR_stackvar(1) + (Integer) r1);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__pd_cost__goals_3_0_i1001);
Define_label(mercury__pd_cost__goals_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(pd_cost_module15)
	init_entry(mercury__pd_cost__cases_3_0);
	init_label(mercury__pd_cost__cases_3_0_i1001);
	init_label(mercury__pd_cost__cases_3_0_i4);
	init_label(mercury__pd_cost__cases_3_0_i3);
BEGIN_CODE

/* code for predicate 'cases'/3 in mode 0 */
Define_static(mercury__pd_cost__cases_3_0);
	MR_incr_sp_push_msg(3, "pd_cost:cases/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__pd_cost__cases_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_cost__cases_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__pd_cost__goal_2_0),
		mercury__pd_cost__cases_3_0_i4,
		STATIC(mercury__pd_cost__cases_3_0));
Define_label(mercury__pd_cost__cases_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_cost__cases_3_0));
	r2 = ((Integer) MR_stackvar(1) + (Integer) r1);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__pd_cost__cases_3_0_i1001);
Define_label(mercury__pd_cost__cases_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__pd_cost_maybe_bunch_0(void)
{
	pd_cost_module0();
	pd_cost_module1();
	pd_cost_module2();
	pd_cost_module3();
	pd_cost_module4();
	pd_cost_module5();
	pd_cost_module6();
	pd_cost_module7();
	pd_cost_module8();
	pd_cost_module9();
	pd_cost_module10();
	pd_cost_module11();
	pd_cost_module12();
	pd_cost_module13();
	pd_cost_module14();
	pd_cost_module15();
}

#endif

void mercury__pd_cost__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__pd_cost__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__pd_cost_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
