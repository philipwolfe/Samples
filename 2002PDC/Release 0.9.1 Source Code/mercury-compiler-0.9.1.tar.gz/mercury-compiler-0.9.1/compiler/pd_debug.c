/*
** Automatically generated from `pd_debug.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__pd_debug__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__pd_debug__do_io_3_0);
Declare_label(mercury__pd_debug__do_io_3_0_i2);
Declare_label(mercury__pd_debug__do_io_3_0_i3);
Declare_label(mercury__pd_debug__do_io_3_0_i4);
Declare_label(mercury__pd_debug__do_io_3_0_i7);
Declare_label(mercury__pd_debug__do_io_3_0_i8);
Declare_label(mercury__pd_debug__do_io_3_0_i9);
Declare_label(mercury__pd_debug__do_io_3_0_i11);
Define_extern_entry(mercury__pd_debug__output_goal_4_0);
Declare_label(mercury__pd_debug__output_goal_4_0_i2);
Declare_label(mercury__pd_debug__output_goal_4_0_i3);
Declare_label(mercury__pd_debug__output_goal_4_0_i4);
Declare_label(mercury__pd_debug__output_goal_4_0_i7);
Declare_label(mercury__pd_debug__output_goal_4_0_i8);
Declare_label(mercury__pd_debug__output_goal_4_0_i9);
Declare_label(mercury__pd_debug__output_goal_4_0_i10);
Declare_label(mercury__pd_debug__output_goal_4_0_i11);
Declare_label(mercury__pd_debug__output_goal_4_0_i12);
Declare_label(mercury__pd_debug__output_goal_4_0_i13);
Declare_label(mercury__pd_debug__output_goal_4_0_i14);
Declare_label(mercury__pd_debug__output_goal_4_0_i15);
Declare_label(mercury__pd_debug__output_goal_4_0_i16);
Declare_label(mercury__pd_debug__output_goal_4_0_i17);
Declare_label(mercury__pd_debug__output_goal_4_0_i18);
Declare_label(mercury__pd_debug__output_goal_4_0_i19);
Declare_label(mercury__pd_debug__output_goal_4_0_i21);
Define_extern_entry(mercury__pd_debug__search_version_result_3_0);
Declare_label(mercury__pd_debug__search_version_result_3_0_i2);
Declare_label(mercury__pd_debug__search_version_result_3_0_i3);
Declare_label(mercury__pd_debug__search_version_result_3_0_i4);
Declare_label(mercury__pd_debug__search_version_result_3_0_i5);
Declare_label(mercury__pd_debug__search_version_result_3_0_i8);
Declare_label(mercury__pd_debug__search_version_result_3_0_i9);
Declare_label(mercury__pd_debug__search_version_result_3_0_i10);
Declare_label(mercury__pd_debug__search_version_result_3_0_i12);
Define_extern_entry(mercury__pd_debug__register_version_4_0);
Declare_label(mercury__pd_debug__register_version_4_0_i2);
Declare_label(mercury__pd_debug__register_version_4_0_i3);
Declare_label(mercury__pd_debug__register_version_4_0_i4);
Declare_label(mercury__pd_debug__register_version_4_0_i5);
Declare_label(mercury__pd_debug__register_version_4_0_i8);
Declare_label(mercury__pd_debug__register_version_4_0_i9);
Declare_label(mercury__pd_debug__register_version_4_0_i10);
Declare_label(mercury__pd_debug__register_version_4_0_i11);
Declare_label(mercury__pd_debug__register_version_4_0_i13);
Define_extern_entry(mercury__pd_debug__write_instmap_2_0);
Declare_label(mercury__pd_debug__write_instmap_2_0_i2);
Declare_label(mercury__pd_debug__write_instmap_2_0_i3);
Declare_label(mercury__pd_debug__write_instmap_2_0_i4);
Declare_label(mercury__pd_debug__write_instmap_2_0_i5);
Declare_label(mercury__pd_debug__write_instmap_2_0_i6);
Declare_label(mercury__pd_debug__write_instmap_2_0_i7);
Declare_label(mercury__pd_debug__write_instmap_2_0_i10);
Declare_label(mercury__pd_debug__write_instmap_2_0_i11);
Declare_label(mercury__pd_debug__write_instmap_2_0_i12);
Declare_label(mercury__pd_debug__write_instmap_2_0_i14);
Define_extern_entry(mercury__pd_debug__message_4_0);
Declare_label(mercury__pd_debug__message_4_0_i2);
Declare_label(mercury__pd_debug__message_4_0_i3);
Declare_label(mercury__pd_debug__message_4_0_i4);
Declare_label(mercury__pd_debug__message_4_0_i7);
Declare_label(mercury__pd_debug__message_4_0_i8);
Declare_label(mercury__pd_debug__message_4_0_i9);
Declare_label(mercury__pd_debug__message_4_0_i11);
Define_extern_entry(mercury__pd_debug__message_5_0);
Declare_label(mercury__pd_debug__message_5_0_i2);
Declare_label(mercury__pd_debug__message_5_0_i3);
Declare_label(mercury__pd_debug__message_5_0_i4);
Declare_label(mercury__pd_debug__message_5_0_i7);
Declare_label(mercury__pd_debug__message_5_0_i8);
Declare_label(mercury__pd_debug__message_5_0_i9);
Declare_label(mercury__pd_debug__message_5_0_i11);
Declare_label(mercury__pd_debug__message_5_0_i12);
Declare_label(mercury__pd_debug__message_5_0_i13);
Declare_label(mercury__pd_debug__message_5_0_i14);
Declare_label(mercury__pd_debug__message_5_0_i17);
Declare_label(mercury__pd_debug__message_5_0_i18);
Declare_label(mercury__pd_debug__message_5_0_i19);
Declare_label(mercury__pd_debug__message_5_0_i21);
Define_extern_entry(mercury__pd_debug__write_3_0);
Declare_label(mercury__pd_debug__write_3_0_i2);
Declare_label(mercury__pd_debug__write_3_0_i3);
Declare_label(mercury__pd_debug__write_3_0_i4);
Declare_label(mercury__pd_debug__write_3_0_i7);
Declare_label(mercury__pd_debug__write_3_0_i8);
Declare_label(mercury__pd_debug__write_3_0_i9);
Declare_label(mercury__pd_debug__write_3_0_i11);
Define_extern_entry(mercury__pd_debug__write_pred_proc_id_list_3_0);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i2);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i3);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i4);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i5);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i8);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i9);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i10);
Declare_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i12);
Declare_static(mercury__pd_debug__search_version_result_2_4_0);
Declare_label(mercury__pd_debug__search_version_result_2_4_0_i3);
Declare_label(mercury__pd_debug__search_version_result_2_4_0_i6);
Declare_label(mercury__pd_debug__search_version_result_2_4_0_i8);
Declare_static(mercury__pd_debug__output_version_6_0);
Declare_label(mercury__pd_debug__output_version_6_0_i2);
Declare_label(mercury__pd_debug__output_version_6_0_i3);
Declare_label(mercury__pd_debug__output_version_6_0_i4);
Declare_label(mercury__pd_debug__output_version_6_0_i5);
Declare_label(mercury__pd_debug__output_version_6_0_i6);
Declare_label(mercury__pd_debug__output_version_6_0_i7);
Declare_label(mercury__pd_debug__output_version_6_0_i8);
Declare_label(mercury__pd_debug__output_version_6_0_i9);
Declare_label(mercury__pd_debug__output_version_6_0_i10);
Declare_label(mercury__pd_debug__output_version_6_0_i11);
Declare_label(mercury__pd_debug__output_version_6_0_i12);
Declare_label(mercury__pd_debug__output_version_6_0_i13);
Declare_label(mercury__pd_debug__output_version_6_0_i14);
Declare_label(mercury__pd_debug__output_version_6_0_i15);
Declare_label(mercury__pd_debug__output_version_6_0_i16);
Declare_label(mercury__pd_debug__output_version_6_0_i17);
Declare_label(mercury__pd_debug__output_version_6_0_i18);
Declare_label(mercury__pd_debug__output_version_6_0_i19);
Declare_label(mercury__pd_debug__output_version_6_0_i20);
Declare_label(mercury__pd_debug__output_version_6_0_i21);
Declare_label(mercury__pd_debug__output_version_6_0_i22);
Declare_label(mercury__pd_debug__output_version_6_0_i23);
Declare_label(mercury__pd_debug__output_version_6_0_i24);
Declare_label(mercury__pd_debug__output_version_6_0_i25);
Declare_label(mercury__pd_debug__output_version_6_0_i26);
Declare_label(mercury__pd_debug__output_version_6_0_i27);
Declare_label(mercury__pd_debug__output_version_6_0_i28);
Declare_label(mercury__pd_debug__output_version_6_0_i29);
Declare_label(mercury__pd_debug__output_version_6_0_i32);
Declare_label(mercury__pd_debug__output_version_6_0_i33);
Declare_label(mercury__pd_debug__output_version_6_0_i34);
Declare_label(mercury__pd_debug__output_version_6_0_i36);
Declare_static(mercury__pd_debug__write_pred_proc_id_4_0);

static const struct mercury_data_pd_debug__common_0_struct {
	Word * f1;
}  mercury_data_pd_debug__common_0;

static const struct mercury_data_pd_debug__common_1_struct {
	Word * f1;
}  mercury_data_pd_debug__common_1;

static const struct mercury_data_pd_debug__common_2_struct {
	Word * f1;
}  mercury_data_pd_debug__common_2;

static const struct mercury_data_pd_debug__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_pd_debug__common_3;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_pd_debug__common_0_struct mercury_data_pd_debug__common_0 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_pd_debug__common_1_struct mercury_data_pd_debug__common_1 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_pd_debug__common_2_struct mercury_data_pd_debug__common_2 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_pd_debug__common_3_struct mercury_data_pd_debug__common_3 = {
	(Integer) 0,
	MR_string_const("pd_debug", 8),
	MR_string_const("pd_debug", 8),
	MR_string_const("write_pred_proc_id", 18),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_2)
};

Declare_entry(mercury__pd_info__pd_info_get_io_state_3_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__pd_info__pd_info_set_io_state_3_0);
Declare_entry(mercury__do_call_closure);
Declare_entry(mercury__io__flush_output_2_0);

BEGIN_MODULE(pd_debug_module0)
	init_entry(mercury__pd_debug__do_io_3_0);
	init_label(mercury__pd_debug__do_io_3_0_i2);
	init_label(mercury__pd_debug__do_io_3_0_i3);
	init_label(mercury__pd_debug__do_io_3_0_i4);
	init_label(mercury__pd_debug__do_io_3_0_i7);
	init_label(mercury__pd_debug__do_io_3_0_i8);
	init_label(mercury__pd_debug__do_io_3_0_i9);
	init_label(mercury__pd_debug__do_io_3_0_i11);
BEGIN_CODE

/* code for predicate 'do_io'/3 in mode 0 */
Define_entry(mercury__pd_debug__do_io_3_0);
	MR_incr_sp_push_msg(3, "pd_debug:do_io/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__do_io_3_0_i2,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__do_io_3_0_i3,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__do_io_3_0_i4,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__do_io_3_0_i11);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__do_io_3_0_i7,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = (Integer) 1;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__pd_debug__do_io_3_0_i8,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__do_io_3_0_i9,
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__do_io_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__do_io_3_0));
Define_label(mercury__pd_debug__do_io_3_0_i11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__pd_info__pd_info_get_proc_info_3_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__pd_info__pd_info_get_instmap_3_0);
Declare_entry(mercury__pd_info__pd_info_get_module_info_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__goal_util__goal_vars_2_0);
Declare_entry(mercury__instmap__restrict_3_0);
Declare_entry(mercury__hlds_out__write_instmap_6_0);
Declare_entry(mercury__io__nl_2_0);
Declare_entry(mercury__hlds_out__write_goal_8_0);

BEGIN_MODULE(pd_debug_module1)
	init_entry(mercury__pd_debug__output_goal_4_0);
	init_label(mercury__pd_debug__output_goal_4_0_i2);
	init_label(mercury__pd_debug__output_goal_4_0_i3);
	init_label(mercury__pd_debug__output_goal_4_0_i4);
	init_label(mercury__pd_debug__output_goal_4_0_i7);
	init_label(mercury__pd_debug__output_goal_4_0_i8);
	init_label(mercury__pd_debug__output_goal_4_0_i9);
	init_label(mercury__pd_debug__output_goal_4_0_i10);
	init_label(mercury__pd_debug__output_goal_4_0_i11);
	init_label(mercury__pd_debug__output_goal_4_0_i12);
	init_label(mercury__pd_debug__output_goal_4_0_i13);
	init_label(mercury__pd_debug__output_goal_4_0_i14);
	init_label(mercury__pd_debug__output_goal_4_0_i15);
	init_label(mercury__pd_debug__output_goal_4_0_i16);
	init_label(mercury__pd_debug__output_goal_4_0_i17);
	init_label(mercury__pd_debug__output_goal_4_0_i18);
	init_label(mercury__pd_debug__output_goal_4_0_i19);
	init_label(mercury__pd_debug__output_goal_4_0_i21);
BEGIN_CODE

/* code for predicate 'output_goal'/4 in mode 0 */
Define_entry(mercury__pd_debug__output_goal_4_0);
	MR_incr_sp_push_msg(7, "pd_debug:output_goal/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__output_goal_4_0_i2,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__output_goal_4_0_i3,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__output_goal_4_0_i4,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__output_goal_4_0_i21);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_proc_info_3_0),
		mercury__pd_debug__output_goal_4_0_i7,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__pd_debug__output_goal_4_0_i8,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_instmap_3_0),
		mercury__pd_debug__output_goal_4_0_i9,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__output_goal_4_0_i10,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_debug__output_goal_4_0_i11,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(6) = r2;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_goal_4_0_i12,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__goal_util__goal_vars_2_0),
		mercury__pd_debug__output_goal_4_0_i13,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__restrict_3_0),
		mercury__pd_debug__output_goal_4_0_i14,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r2 = MR_stackvar(3);
	r3 = (Integer) 1;
	r4 = (Integer) 1;
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_out__write_instmap_6_0),
		mercury__pd_debug__output_goal_4_0_i15,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_goal_4_0_i16,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r7 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = (Integer) 1;
	r5 = (Integer) 1;
	r6 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__hlds_out__write_goal_8_0),
		mercury__pd_debug__output_goal_4_0_i17,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_goal_4_0_i18,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i18);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__output_goal_4_0_i19,
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_goal_4_0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__output_goal_4_0));
Define_label(mercury__pd_debug__output_goal_4_0_i21);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(pd_debug_module2)
	init_entry(mercury__pd_debug__search_version_result_3_0);
	init_label(mercury__pd_debug__search_version_result_3_0_i2);
	init_label(mercury__pd_debug__search_version_result_3_0_i3);
	init_label(mercury__pd_debug__search_version_result_3_0_i4);
	init_label(mercury__pd_debug__search_version_result_3_0_i5);
	init_label(mercury__pd_debug__search_version_result_3_0_i8);
	init_label(mercury__pd_debug__search_version_result_3_0_i9);
	init_label(mercury__pd_debug__search_version_result_3_0_i10);
	init_label(mercury__pd_debug__search_version_result_3_0_i12);
BEGIN_CODE

/* code for predicate 'search_version_result'/3 in mode 0 */
Define_entry(mercury__pd_debug__search_version_result_3_0);
	MR_incr_sp_push_msg(4, "pd_debug:search_version_result/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_debug__search_version_result_3_0_i2,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__search_version_result_3_0_i3,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__search_version_result_3_0_i4,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__search_version_result_3_0_i5,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__search_version_result_3_0_i12);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__search_version_result_3_0_i8,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r3 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__pd_debug__search_version_result_2_4_0),
		mercury__pd_debug__search_version_result_3_0_i9,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
	}
Define_label(mercury__pd_debug__search_version_result_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__search_version_result_3_0_i10,
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__search_version_result_3_0));
Define_label(mercury__pd_debug__search_version_result_3_0_i12);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(pd_debug_module3)
	init_entry(mercury__pd_debug__register_version_4_0);
	init_label(mercury__pd_debug__register_version_4_0_i2);
	init_label(mercury__pd_debug__register_version_4_0_i3);
	init_label(mercury__pd_debug__register_version_4_0_i4);
	init_label(mercury__pd_debug__register_version_4_0_i5);
	init_label(mercury__pd_debug__register_version_4_0_i8);
	init_label(mercury__pd_debug__register_version_4_0_i9);
	init_label(mercury__pd_debug__register_version_4_0_i10);
	init_label(mercury__pd_debug__register_version_4_0_i11);
	init_label(mercury__pd_debug__register_version_4_0_i13);
BEGIN_CODE

/* code for predicate 'register_version'/4 in mode 0 */
Define_entry(mercury__pd_debug__register_version_4_0);
	MR_incr_sp_push_msg(5, "pd_debug:register_version/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_debug__register_version_4_0_i2,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__register_version_4_0_i3,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__register_version_4_0_i4,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__register_version_4_0_i5,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__register_version_4_0_i13);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__register_version_4_0_i8,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Word) MR_string_const("Registering version:\n", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__register_version_4_0_i9,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = (Integer) 0;
	call_localret(STATIC(mercury__pd_debug__output_version_6_0),
		mercury__pd_debug__register_version_4_0_i10,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__register_version_4_0_i11,
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_debug__register_version_4_0));
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__register_version_4_0));
Define_label(mercury__pd_debug__register_version_4_0_i13);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(pd_debug_module4)
	init_entry(mercury__pd_debug__write_instmap_2_0);
	init_label(mercury__pd_debug__write_instmap_2_0_i2);
	init_label(mercury__pd_debug__write_instmap_2_0_i3);
	init_label(mercury__pd_debug__write_instmap_2_0_i4);
	init_label(mercury__pd_debug__write_instmap_2_0_i5);
	init_label(mercury__pd_debug__write_instmap_2_0_i6);
	init_label(mercury__pd_debug__write_instmap_2_0_i7);
	init_label(mercury__pd_debug__write_instmap_2_0_i10);
	init_label(mercury__pd_debug__write_instmap_2_0_i11);
	init_label(mercury__pd_debug__write_instmap_2_0_i12);
	init_label(mercury__pd_debug__write_instmap_2_0_i14);
BEGIN_CODE

/* code for predicate 'write_instmap'/2 in mode 0 */
Define_entry(mercury__pd_debug__write_instmap_2_0);
	MR_incr_sp_push_msg(4, "pd_debug:write_instmap/2");
	MR_stackvar(4) = (Word) MR_succip;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_instmap_3_0),
		mercury__pd_debug__write_instmap_2_0_i2,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_proc_info_3_0),
		mercury__pd_debug__write_instmap_2_0_i3,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__pd_debug__write_instmap_2_0_i4,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_instmap_2_0_i5,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__write_instmap_2_0_i6,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__write_instmap_2_0_i7,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__write_instmap_2_0_i14);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_instmap_2_0_i10,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(2);
	r3 = (Integer) 1;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_out__write_instmap_6_0),
		mercury__pd_debug__write_instmap_2_0_i11,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__write_instmap_2_0_i12,
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_instmap_2_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__write_instmap_2_0));
Define_label(mercury__pd_debug__write_instmap_2_0_i14);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__io__format_4_0);

BEGIN_MODULE(pd_debug_module5)
	init_entry(mercury__pd_debug__message_4_0);
	init_label(mercury__pd_debug__message_4_0_i2);
	init_label(mercury__pd_debug__message_4_0_i3);
	init_label(mercury__pd_debug__message_4_0_i4);
	init_label(mercury__pd_debug__message_4_0_i7);
	init_label(mercury__pd_debug__message_4_0_i8);
	init_label(mercury__pd_debug__message_4_0_i9);
	init_label(mercury__pd_debug__message_4_0_i11);
BEGIN_CODE

/* code for predicate 'message'/4 in mode 0 */
Define_entry(mercury__pd_debug__message_4_0);
	MR_incr_sp_push_msg(4, "pd_debug:message/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_4_0_i2,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__message_4_0_i3,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__message_4_0_i4,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__message_4_0_i11);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_4_0_i7,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__format_4_0),
		mercury__pd_debug__message_4_0_i8,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__message_4_0_i9,
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__message_4_0));
Define_label(mercury__pd_debug__message_4_0_i11);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__prog_out__write_context_3_0);

BEGIN_MODULE(pd_debug_module6)
	init_entry(mercury__pd_debug__message_5_0);
	init_label(mercury__pd_debug__message_5_0_i2);
	init_label(mercury__pd_debug__message_5_0_i3);
	init_label(mercury__pd_debug__message_5_0_i4);
	init_label(mercury__pd_debug__message_5_0_i7);
	init_label(mercury__pd_debug__message_5_0_i8);
	init_label(mercury__pd_debug__message_5_0_i9);
	init_label(mercury__pd_debug__message_5_0_i11);
	init_label(mercury__pd_debug__message_5_0_i12);
	init_label(mercury__pd_debug__message_5_0_i13);
	init_label(mercury__pd_debug__message_5_0_i14);
	init_label(mercury__pd_debug__message_5_0_i17);
	init_label(mercury__pd_debug__message_5_0_i18);
	init_label(mercury__pd_debug__message_5_0_i19);
	init_label(mercury__pd_debug__message_5_0_i21);
BEGIN_CODE

/* code for predicate 'message'/5 in mode 0 */
Define_entry(mercury__pd_debug__message_5_0);
	MR_incr_sp_push_msg(5, "pd_debug:message/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_5_0_i2,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__message_5_0_i3,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__message_5_0_i4,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__message_5_0_i11);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_5_0_i7,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__pd_debug__message_5_0_i8,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__message_5_0_i9,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__message_5_0_i11,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_5_0_i12,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__message_5_0_i13,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__message_5_0_i14,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__message_5_0_i21);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__message_5_0_i17,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__format_4_0),
		mercury__pd_debug__message_5_0_i18,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i18);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__message_5_0_i19,
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i19);
	update_prof_current_proc(LABEL(mercury__pd_debug__message_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__message_5_0));
Define_label(mercury__pd_debug__message_5_0_i21);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_3_0);

BEGIN_MODULE(pd_debug_module7)
	init_entry(mercury__pd_debug__write_3_0);
	init_label(mercury__pd_debug__write_3_0_i2);
	init_label(mercury__pd_debug__write_3_0_i3);
	init_label(mercury__pd_debug__write_3_0_i4);
	init_label(mercury__pd_debug__write_3_0_i7);
	init_label(mercury__pd_debug__write_3_0_i8);
	init_label(mercury__pd_debug__write_3_0_i9);
	init_label(mercury__pd_debug__write_3_0_i11);
BEGIN_CODE

/* code for predicate 'write'/3 in mode 0 */
Define_entry(mercury__pd_debug__write_3_0);
	MR_incr_sp_push_msg(4, "pd_debug:write/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r1;
	r1 = r3;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_3_0_i2,
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__write_3_0_i3,
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__write_3_0_i4,
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__write_3_0_i11);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_3_0_i7,
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r3 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__pd_debug__write_3_0_i8,
		ENTRY(mercury__pd_debug__write_3_0));
	}
Define_label(mercury__pd_debug__write_3_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__write_3_0_i9,
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__write_3_0));
Define_label(mercury__pd_debug__write_3_0_i11);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_list_5_0);

BEGIN_MODULE(pd_debug_module8)
	init_entry(mercury__pd_debug__write_pred_proc_id_list_3_0);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i2);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i3);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i4);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i5);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i8);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i9);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i10);
	init_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i12);
BEGIN_CODE

/* code for predicate 'write_pred_proc_id_list'/3 in mode 0 */
Define_entry(mercury__pd_debug__write_pred_proc_id_list_3_0);
	MR_incr_sp_push_msg(4, "pd_debug:write_pred_proc_id_list/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i2,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__pd_debug__write_pred_proc_id_list_3_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__pd_debug__write_pred_proc_id_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_3);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i3,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Integer) 26;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i4,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i5,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0_i12);
	call_localret(ENTRY(mercury__pd_info__pd_info_get_io_state_3_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i8,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i9,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
	}
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__pd_debug__write_pred_proc_id_list_3_0_i10,
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__write_pred_proc_id_list_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__pd_info__pd_info_set_io_state_3_0),
		ENTRY(mercury__pd_debug__write_pred_proc_id_list_3_0));
Define_label(mercury__pd_debug__write_pred_proc_id_list_3_0_i12);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(pd_debug_module9)
	init_entry(mercury__pd_debug__search_version_result_2_4_0);
	init_label(mercury__pd_debug__search_version_result_2_4_0_i3);
	init_label(mercury__pd_debug__search_version_result_2_4_0_i6);
	init_label(mercury__pd_debug__search_version_result_2_4_0_i8);
BEGIN_CODE

/* code for predicate 'search_version_result_2'/4 in mode 0 */
Define_static(mercury__pd_debug__search_version_result_2_4_0);
	MR_incr_sp_push_msg(4, "pd_debug:search_version_result_2/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_debug__search_version_result_2_4_0_i3);
	r1 = (Word) MR_string_const("Specialised version not found.\n", 31);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__pd_debug__search_version_result_2_4_0));
Define_label(mercury__pd_debug__search_version_result_2_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__pd_debug__search_version_result_2_4_0_i6);
	r1 = (Word) MR_string_const("Exact match found.\n", 19);
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__pd_debug__search_version_result_2_4_0));
Define_label(mercury__pd_debug__search_version_result_2_4_0_i6);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = (Word) MR_string_const("More general version.\n", 22);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__search_version_result_2_4_0_i8,
		STATIC(mercury__pd_debug__search_version_result_2_4_0));
Define_label(mercury__pd_debug__search_version_result_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__search_version_result_2_4_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__pd_debug__output_version_6_0),
		STATIC(mercury__pd_debug__search_version_result_2_4_0));
END_MODULE

Declare_entry(mercury__hlds_module__predicate_name_3_0);
Declare_entry(mercury__hlds_pred__pred_id_to_int_2_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);
Declare_entry(mercury__io__write_int_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);

BEGIN_MODULE(pd_debug_module10)
	init_entry(mercury__pd_debug__output_version_6_0);
	init_label(mercury__pd_debug__output_version_6_0_i2);
	init_label(mercury__pd_debug__output_version_6_0_i3);
	init_label(mercury__pd_debug__output_version_6_0_i4);
	init_label(mercury__pd_debug__output_version_6_0_i5);
	init_label(mercury__pd_debug__output_version_6_0_i6);
	init_label(mercury__pd_debug__output_version_6_0_i7);
	init_label(mercury__pd_debug__output_version_6_0_i8);
	init_label(mercury__pd_debug__output_version_6_0_i9);
	init_label(mercury__pd_debug__output_version_6_0_i10);
	init_label(mercury__pd_debug__output_version_6_0_i11);
	init_label(mercury__pd_debug__output_version_6_0_i12);
	init_label(mercury__pd_debug__output_version_6_0_i13);
	init_label(mercury__pd_debug__output_version_6_0_i14);
	init_label(mercury__pd_debug__output_version_6_0_i15);
	init_label(mercury__pd_debug__output_version_6_0_i16);
	init_label(mercury__pd_debug__output_version_6_0_i17);
	init_label(mercury__pd_debug__output_version_6_0_i18);
	init_label(mercury__pd_debug__output_version_6_0_i19);
	init_label(mercury__pd_debug__output_version_6_0_i20);
	init_label(mercury__pd_debug__output_version_6_0_i21);
	init_label(mercury__pd_debug__output_version_6_0_i22);
	init_label(mercury__pd_debug__output_version_6_0_i23);
	init_label(mercury__pd_debug__output_version_6_0_i24);
	init_label(mercury__pd_debug__output_version_6_0_i25);
	init_label(mercury__pd_debug__output_version_6_0_i26);
	init_label(mercury__pd_debug__output_version_6_0_i27);
	init_label(mercury__pd_debug__output_version_6_0_i28);
	init_label(mercury__pd_debug__output_version_6_0_i29);
	init_label(mercury__pd_debug__output_version_6_0_i32);
	init_label(mercury__pd_debug__output_version_6_0_i33);
	init_label(mercury__pd_debug__output_version_6_0_i34);
	init_label(mercury__pd_debug__output_version_6_0_i36);
BEGIN_CODE

/* code for predicate 'output_version'/6 in mode 0 */
Define_static(mercury__pd_debug__output_version_6_0);
	MR_incr_sp_push_msg(13, "pd_debug:output_version/6");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(9) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(12) = MR_tempr1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__hlds_module__predicate_name_3_0),
		mercury__pd_debug__output_version_6_0_i2,
		STATIC(mercury__pd_debug__output_version_6_0));
	}
Define_label(mercury__pd_debug__output_version_6_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i3,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": (PredProcId :", 15);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i4,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__pred_id_to_int_2_0),
		mercury__pd_debug__output_version_6_0_i5,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__pd_debug__output_version_6_0_i6,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__pd_debug__output_version_6_0_i7,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("-", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i8,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__pd_debug__output_version_6_0_i9,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i10,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i11,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" initial cost: ", 15);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i12,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__pd_debug__output_version_6_0_i13,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i14,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" cost delta: ", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i15,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i15);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__pd_debug__output_version_6_0_i16,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i17,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__pd_debug__output_version_6_0_i18,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i18);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__pd_debug__output_version_6_0_i19,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i19);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r1 = r2;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__pd_debug__output_version_6_0_i20,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i20);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__instmap__restrict_3_0),
		mercury__pd_debug__output_version_6_0_i21,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i21);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = MR_stackvar(3);
	r3 = (Integer) 1;
	r4 = (Integer) 1;
	r5 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_out__write_instmap_6_0),
		mercury__pd_debug__output_version_6_0_i22,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i22);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i23,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i23);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r7 = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = (Integer) 0;
	r5 = (Integer) 1;
	r6 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__hlds_out__write_goal_8_0),
		mercury__pd_debug__output_version_6_0_i24,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i24);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i25,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i25);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Parents: ", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i26,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i26);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__pd_debug__output_version_6_0_i27,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i27);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r3 = (Word) MR_string_const(", ", 2);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__pd_debug__output_version_6_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_debug__common_3);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__pd_debug__write_pred_proc_id_4_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__pd_debug__output_version_6_0_i28,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i28);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__pd_debug__output_version_6_0_i29,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i29);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pd_debug__output_version_6_0_i36);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__pd_debug__output_version_6_0_i32,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i32);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("Unfolded goal\n", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__pd_debug__output_version_6_0_i33,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i33);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	r7 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = (Integer) 0;
	r5 = (Integer) 1;
	r6 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__hlds_out__write_goal_8_0),
		mercury__pd_debug__output_version_6_0_i34,
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i34);
	update_prof_current_proc(LABEL(mercury__pd_debug__output_version_6_0));
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__pd_debug__output_version_6_0));
Define_label(mercury__pd_debug__output_version_6_0_i36);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);

BEGIN_MODULE(pd_debug_module11)
	init_entry(mercury__pd_debug__write_pred_proc_id_4_0);
BEGIN_CODE

/* code for predicate 'write_pred_proc_id'/4 in mode 0 */
Define_static(mercury__pd_debug__write_pred_proc_id_4_0);
	r4 = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		STATIC(mercury__pd_debug__write_pred_proc_id_4_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__pd_debug_maybe_bunch_0(void)
{
	pd_debug_module0();
	pd_debug_module1();
	pd_debug_module2();
	pd_debug_module3();
	pd_debug_module4();
	pd_debug_module5();
	pd_debug_module6();
	pd_debug_module7();
	pd_debug_module8();
	pd_debug_module9();
	pd_debug_module10();
	pd_debug_module11();
}

#endif

void mercury__pd_debug__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__pd_debug__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__pd_debug_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
