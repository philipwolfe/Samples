/*
** Automatically generated from `pd_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__pd_info__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___pd_info__version_info_0__ua0_2_0);
Declare_static(mercury____Index___pd_info__pd_branch_info_1__ua0_2_0);
Declare_static(mercury____Index___pd_info__pd_proc_arg_info_0__ua0_2_0);
Declare_static(mercury____Index___pd_info__unfold_info_0__ua0_2_0);
Declare_static(mercury____Index___pd_info__pd_info_0__ua0_2_0);
Declare_static(mercury__pd_info__pick_version__ua0_7_0);
Declare_label(mercury__pd_info__pick_version__ua0_7_0_i3);
Declare_label(mercury__pd_info__pick_version__ua0_7_0_i5);
Declare_label(mercury__pd_info__pick_version__ua0_7_0_i1011);
Define_extern_entry(mercury__pd_info__pd_info_init_4_0);
Declare_label(mercury__pd_info__pd_info_init_4_0_i2);
Declare_label(mercury__pd_info__pd_info_init_4_0_i3);
Declare_label(mercury__pd_info__pd_info_init_4_0_i4);
Declare_label(mercury__pd_info__pd_info_init_4_0_i5);
Declare_label(mercury__pd_info__pd_info_init_4_0_i6);
Declare_label(mercury__pd_info__pd_info_init_4_0_i7);
Define_extern_entry(mercury__pd_info__pd_info_init_unfold_info_5_0);
Declare_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i2);
Declare_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i3);
Declare_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i4);
Define_extern_entry(mercury__pd_info__pd_info_get_io_state_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_module_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_unfold_info_3_0);
Declare_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_goal_version_index_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_proc_arg_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_counter_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_global_term_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_parent_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_depth_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_created_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_get_useless_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_io_state_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_module_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_unfold_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_goal_version_index_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_proc_arg_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_counter_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_global_term_info_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_parent_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_depth_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_created_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_set_useless_versions_3_0);
Define_extern_entry(mercury__pd_info__pd_info_update_goal_3_0);
Declare_label(mercury__pd_info__pd_info_update_goal_3_0_i4);
Declare_label(mercury__pd_info__pd_info_update_goal_3_0_i3);
Declare_label(mercury__pd_info__pd_info_update_goal_3_0_i5);
Declare_label(mercury__pd_info__pd_info_update_goal_3_0_i6);
Define_extern_entry(mercury__pd_info__pd_info_lookup_option_4_0);
Declare_label(mercury__pd_info__pd_info_lookup_option_4_0_i2);
Define_extern_entry(mercury__pd_info__pd_info_lookup_bool_option_4_0);
Declare_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i2);
Declare_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i3);
Declare_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i5);
Define_extern_entry(mercury__pd_info__pd_info_bind_var_to_functor_4_0);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i3);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i2);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i5);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i6);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i7);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i8);
Declare_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i9);
Define_extern_entry(mercury__pd_info__pd_info_unset_unfold_info_2_0);
Define_extern_entry(mercury__pd_info__pd_info_foldl_4_0);
Declare_label(mercury__pd_info__pd_info_foldl_4_0_i1001);
Declare_label(mercury__pd_info__pd_info_foldl_4_0_i4);
Declare_label(mercury__pd_info__pd_info_foldl_4_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_foldl2_6_0);
Declare_label(mercury__pd_info__pd_info_foldl2_6_0_i1001);
Declare_label(mercury__pd_info__pd_info_foldl2_6_0_i4);
Declare_label(mercury__pd_info__pd_info_foldl2_6_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_proc_info_3_0);
Declare_label(mercury__pd_info__pd_info_get_proc_info_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_proc_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_instmap_3_0);
Declare_label(mercury__pd_info__pd_info_get_instmap_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_instmap_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_cost_delta_3_0);
Declare_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_local_term_info_3_0);
Declare_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_pred_info_3_0);
Declare_label(mercury__pd_info__pd_info_get_pred_info_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_pred_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_parents_3_0);
Declare_label(mercury__pd_info__pd_info_get_parents_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_parents_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_pred_proc_id_3_0);
Declare_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_changed_3_0);
Declare_label(mercury__pd_info__pd_info_get_changed_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_changed_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_size_delta_3_0);
Declare_label(mercury__pd_info__pd_info_get_size_delta_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_size_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_get_rerun_det_3_0);
Declare_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i4);
Declare_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_proc_info_3_0);
Declare_label(mercury__pd_info__pd_info_set_proc_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_instmap_3_0);
Declare_label(mercury__pd_info__pd_info_set_instmap_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_cost_delta_3_0);
Declare_label(mercury__pd_info__pd_info_set_cost_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_local_term_info_3_0);
Declare_label(mercury__pd_info__pd_info_set_local_term_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_pred_info_3_0);
Declare_label(mercury__pd_info__pd_info_set_pred_info_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_parents_3_0);
Declare_label(mercury__pd_info__pd_info_set_parents_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_pred_proc_id_3_0);
Declare_label(mercury__pd_info__pd_info_set_pred_proc_id_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_changed_3_0);
Declare_label(mercury__pd_info__pd_info_set_changed_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_size_delta_3_0);
Declare_label(mercury__pd_info__pd_info_set_size_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_set_rerun_det_3_0);
Declare_label(mercury__pd_info__pd_info_set_rerun_det_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_incr_cost_delta_3_0);
Declare_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i4);
Declare_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__pd_info_incr_size_delta_3_0);
Declare_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i4);
Declare_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i3);
Define_extern_entry(mercury__pd_info__search_version_4_0);
Declare_label(mercury__pd_info__search_version_4_0_i2);
Declare_label(mercury__pd_info__search_version_4_0_i3);
Declare_label(mercury__pd_info__search_version_4_0_i4);
Declare_label(mercury__pd_info__search_version_4_0_i5);
Declare_label(mercury__pd_info__search_version_4_0_i6);
Declare_label(mercury__pd_info__search_version_4_0_i8);
Declare_label(mercury__pd_info__search_version_4_0_i10);
Declare_label(mercury__pd_info__search_version_4_0_i7);
Declare_label(mercury__pd_info__search_version_4_0_i12);
Declare_label(mercury__pd_info__search_version_4_0_i13);
Define_extern_entry(mercury__pd_info__define_new_pred_5_0);
Declare_label(mercury__pd_info__define_new_pred_5_0_i4);
Declare_label(mercury__pd_info__define_new_pred_5_0_i3);
Declare_label(mercury__pd_info__define_new_pred_5_0_i2);
Declare_label(mercury__pd_info__define_new_pred_5_0_i5);
Declare_label(mercury__pd_info__define_new_pred_5_0_i6);
Declare_label(mercury__pd_info__define_new_pred_5_0_i7);
Declare_label(mercury__pd_info__define_new_pred_5_0_i8);
Declare_label(mercury__pd_info__define_new_pred_5_0_i9);
Declare_label(mercury__pd_info__define_new_pred_5_0_i10);
Declare_label(mercury__pd_info__define_new_pred_5_0_i11);
Declare_label(mercury__pd_info__define_new_pred_5_0_i12);
Declare_label(mercury__pd_info__define_new_pred_5_0_i13);
Declare_label(mercury__pd_info__define_new_pred_5_0_i14);
Declare_label(mercury__pd_info__define_new_pred_5_0_i15);
Declare_label(mercury__pd_info__define_new_pred_5_0_i16);
Declare_label(mercury__pd_info__define_new_pred_5_0_i17);
Declare_label(mercury__pd_info__define_new_pred_5_0_i18);
Declare_label(mercury__pd_info__define_new_pred_5_0_i19);
Declare_label(mercury__pd_info__define_new_pred_5_0_i20);
Declare_label(mercury__pd_info__define_new_pred_5_0_i21);
Declare_label(mercury__pd_info__define_new_pred_5_0_i22);
Declare_label(mercury__pd_info__define_new_pred_5_0_i23);
Declare_label(mercury__pd_info__define_new_pred_5_0_i24);
Declare_label(mercury__pd_info__define_new_pred_5_0_i25);
Declare_label(mercury__pd_info__define_new_pred_5_0_i26);
Define_extern_entry(mercury__pd_info__register_version_4_0);
Declare_label(mercury__pd_info__register_version_4_0_i2);
Declare_label(mercury__pd_info__register_version_4_0_i3);
Declare_label(mercury__pd_info__register_version_4_0_i5);
Declare_label(mercury__pd_info__register_version_4_0_i4);
Declare_label(mercury__pd_info__register_version_4_0_i8);
Declare_label(mercury__pd_info__register_version_4_0_i10);
Declare_label(mercury__pd_info__register_version_4_0_i11);
Declare_label(mercury__pd_info__register_version_4_0_i12);
Declare_label(mercury__pd_info__register_version_4_0_i13);
Declare_label(mercury__pd_info__register_version_4_0_i14);
Define_extern_entry(mercury__pd_info__invalidate_version_3_0);
Declare_label(mercury__pd_info__invalidate_version_3_0_i2);
Declare_label(mercury__pd_info__invalidate_version_3_0_i3);
Declare_label(mercury__pd_info__invalidate_version_3_0_i7);
Declare_label(mercury__pd_info__invalidate_version_3_0_i9);
Declare_label(mercury__pd_info__invalidate_version_3_0_i5);
Define_extern_entry(mercury__pd_info__remove_version_3_0);
Declare_label(mercury__pd_info__remove_version_3_0_i2);
Declare_label(mercury__pd_info__remove_version_3_0_i3);
Declare_label(mercury__pd_info__remove_version_3_0_i4);
Declare_label(mercury__pd_info__remove_version_3_0_i5);
Declare_label(mercury__pd_info__remove_version_3_0_i7);
Declare_label(mercury__pd_info__remove_version_3_0_i9);
Declare_label(mercury__pd_info__remove_version_3_0_i10);
Declare_label(mercury__pd_info__remove_version_3_0_i6);
Declare_label(mercury__pd_info__remove_version_3_0_i12);
Declare_label(mercury__pd_info__remove_version_3_0_i13);
Declare_label(mercury__pd_info__remove_version_3_0_i14);
Declare_label(mercury__pd_info__remove_version_3_0_i15);
Declare_label(mercury__pd_info__remove_version_3_0_i16);
Declare_label(mercury__pd_info__remove_version_3_0_i17);
Declare_static(mercury__pd_info__get_matching_version_7_0);
Declare_label(mercury__pd_info__get_matching_version_7_0_i1005);
Declare_label(mercury__pd_info__get_matching_version_7_0_i3);
Declare_label(mercury__pd_info__get_matching_version_7_0_i4);
Declare_label(mercury__pd_info__get_matching_version_7_0_i6);
Declare_label(mercury__pd_info__get_matching_version_7_0_i8);
Declare_label(mercury__pd_info__get_matching_version_7_0_i9);
Declare_label(mercury__pd_info__get_matching_version_7_0_i10);
Declare_label(mercury__pd_info__get_matching_version_7_0_i13);
Declare_label(mercury__pd_info__get_matching_version_7_0_i14);
Declare_label(mercury__pd_info__get_matching_version_7_0_i16);
Declare_label(mercury__pd_info__get_matching_version_7_0_i5);
Declare_label(mercury__pd_info__get_matching_version_7_0_i1);
Declare_static(mercury__pd_info__check_insts_7_0);
Declare_label(mercury__pd_info__check_insts_7_0_i1004);
Declare_label(mercury__pd_info__check_insts_7_0_i3);
Declare_label(mercury__pd_info__check_insts_7_0_i4);
Declare_label(mercury__pd_info__check_insts_7_0_i5);
Declare_label(mercury__pd_info__check_insts_7_0_i6);
Declare_label(mercury__pd_info__check_insts_7_0_i7);
Declare_label(mercury__pd_info__check_insts_7_0_i13);
Declare_label(mercury__pd_info__check_insts_7_0_i9);
Declare_label(mercury__pd_info__check_insts_7_0_i1);
Define_extern_entry(mercury____Unify___pd_info__pd_info_0_0);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i2);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i4);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i6);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i8);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i10);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i12);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i14);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i16);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i18);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i20);
Declare_label(mercury____Unify___pd_info__pd_info_0_0_i1);
Define_extern_entry(mercury____Index___pd_info__pd_info_0_0);
Define_extern_entry(mercury____Compare___pd_info__pd_info_0_0);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i3);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i7);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i11);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i15);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i19);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i23);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i27);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i31);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i35);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i39);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i43);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i47);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i51);
Declare_label(mercury____Compare___pd_info__pd_info_0_0_i67);
Define_extern_entry(mercury____Unify___pd_info__goal_version_index_0_0);
Define_extern_entry(mercury____Index___pd_info__goal_version_index_0_0);
Define_extern_entry(mercury____Compare___pd_info__goal_version_index_0_0);
Define_extern_entry(mercury____Unify___pd_info__version_index_0_0);
Define_extern_entry(mercury____Index___pd_info__version_index_0_0);
Define_extern_entry(mercury____Compare___pd_info__version_index_0_0);
Define_extern_entry(mercury____Unify___pd_info__unfold_info_0_0);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i2);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i4);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i6);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i8);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i10);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i12);
Declare_label(mercury____Unify___pd_info__unfold_info_0_0_i1);
Define_extern_entry(mercury____Index___pd_info__unfold_info_0_0);
Define_extern_entry(mercury____Compare___pd_info__unfold_info_0_0);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i3);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i7);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i11);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i15);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i19);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i23);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i27);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i31);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i35);
Declare_label(mercury____Compare___pd_info__unfold_info_0_0_i47);
Define_extern_entry(mercury____Unify___pd_info__pd_arg_info_0_0);
Define_extern_entry(mercury____Index___pd_info__pd_arg_info_0_0);
Define_extern_entry(mercury____Compare___pd_info__pd_arg_info_0_0);
Define_extern_entry(mercury____Unify___pd_info__pd_proc_arg_info_0_0);
Define_extern_entry(mercury____Index___pd_info__pd_proc_arg_info_0_0);
Define_extern_entry(mercury____Compare___pd_info__pd_proc_arg_info_0_0);
Define_extern_entry(mercury____Unify___pd_info__pd_branch_info_1_0);
Declare_label(mercury____Unify___pd_info__pd_branch_info_1_0_i2);
Declare_label(mercury____Unify___pd_info__pd_branch_info_1_0_i4);
Declare_label(mercury____Unify___pd_info__pd_branch_info_1_0_i1);
Define_extern_entry(mercury____Index___pd_info__pd_branch_info_1_0);
Define_extern_entry(mercury____Compare___pd_info__pd_branch_info_1_0);
Declare_label(mercury____Compare___pd_info__pd_branch_info_1_0_i3);
Declare_label(mercury____Compare___pd_info__pd_branch_info_1_0_i7);
Declare_label(mercury____Compare___pd_info__pd_branch_info_1_0_i12);
Define_extern_entry(mercury____Unify___pd_info__branch_info_map_1_0);
Define_extern_entry(mercury____Index___pd_info__branch_info_map_1_0);
Define_extern_entry(mercury____Compare___pd_info__branch_info_map_1_0);
Define_extern_entry(mercury____Unify___pd_info__maybe_version_0_0);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i3);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i6);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i8);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i10);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i1009);
Declare_label(mercury____Unify___pd_info__maybe_version_0_0_i1);
Define_extern_entry(mercury____Index___pd_info__maybe_version_0_0);
Declare_label(mercury____Index___pd_info__maybe_version_0_0_i3);
Define_extern_entry(mercury____Compare___pd_info__maybe_version_0_0);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i3);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i2);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i5);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i4);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i6);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i7);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i11);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i15);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i19);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i23);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i27);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i1018);
Declare_label(mercury____Compare___pd_info__maybe_version_0_0_i38);
Define_extern_entry(mercury____Unify___pd_info__version_is_exact_0_0);
Declare_label(mercury____Unify___pd_info__version_is_exact_0_0_i1);
Define_extern_entry(mercury____Index___pd_info__version_is_exact_0_0);
Define_extern_entry(mercury____Compare___pd_info__version_is_exact_0_0);
Define_extern_entry(mercury____Unify___pd_info__version_info_0_0);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i2);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i4);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i6);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i8);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i10);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i12);
Declare_label(mercury____Unify___pd_info__version_info_0_0_i1);
Define_extern_entry(mercury____Index___pd_info__version_info_0_0);
Define_extern_entry(mercury____Compare___pd_info__version_info_0_0);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i3);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i7);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i11);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i15);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i19);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i23);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i27);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i31);
Declare_label(mercury____Compare___pd_info__version_info_0_0_i42);

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_branch_info_map_1;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_goal_version_index_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_maybe_version_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_arg_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_branch_info_1;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_proc_arg_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_unfold_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_index_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_is_exact_0;

static const struct mercury_data_pd_info__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_0;

static const struct mercury_data_pd_info__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_1;

static const struct mercury_data_pd_info__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_2;

static const struct mercury_data_pd_info__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_3;

static const struct mercury_data_pd_info__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_4;

static const struct mercury_data_pd_info__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_5;

static const struct mercury_data_pd_info__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_6;

static const struct mercury_data_pd_info__common_7_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_pd_info__common_7;

static const struct mercury_data_pd_info__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_8;

static const struct mercury_data_pd_info__common_9_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_9;

static const struct mercury_data_pd_info__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_10;

static const struct mercury_data_pd_info__common_11_struct {
	Word * f1;
}  mercury_data_pd_info__common_11;

static const struct mercury_data_pd_info__common_12_struct {
	Word * f1;
}  mercury_data_pd_info__common_12;

static const struct mercury_data_pd_info__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_13;

static const struct mercury_data_pd_info__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_14;

static const struct mercury_data_pd_info__common_15_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	String f11;
	Word * f12;
	Integer f13;
	Integer f14;
}  mercury_data_pd_info__common_15;

static const struct mercury_data_pd_info__common_16_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_16;

static const struct mercury_data_pd_info__common_17_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__common_17;

static const struct mercury_data_pd_info__common_18_struct {
	Word * f1;
}  mercury_data_pd_info__common_18;

static const struct mercury_data_pd_info__common_19_struct {
	Word * f1;
}  mercury_data_pd_info__common_19;

static const struct mercury_data_pd_info__common_20_struct {
	Word * f1;
}  mercury_data_pd_info__common_20;

static const struct mercury_data_pd_info__common_21_struct {
	Word * f1;
}  mercury_data_pd_info__common_21;

static const struct mercury_data_pd_info__common_22_struct {
	Word * f1;
}  mercury_data_pd_info__common_22;

static const struct mercury_data_pd_info__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	String f12;
	Word * f13;
	Integer f14;
	Integer f15;
}  mercury_data_pd_info__common_23;

static const struct mercury_data_pd_info__common_24_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__common_24;

static const struct mercury_data_pd_info__common_25_struct {
	Word * f1;
}  mercury_data_pd_info__common_25;

static const struct mercury_data_pd_info__common_26_struct {
	Word * f1;
}  mercury_data_pd_info__common_26;

static const struct mercury_data_pd_info__common_27_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_27;

static const struct mercury_data_pd_info__common_28_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_28;

static const struct mercury_data_pd_info__common_29_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_29;

static const struct mercury_data_pd_info__common_30_struct {
	Word * f1;
}  mercury_data_pd_info__common_30;

static const struct mercury_data_pd_info__common_31_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pd_info__common_31;

static const struct mercury_data_pd_info__common_32_struct {
	Word * f1;
}  mercury_data_pd_info__common_32;

static const struct mercury_data_pd_info__common_33_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	String f16;
	Word * f17;
	Integer f18;
	Integer f19;
}  mercury_data_pd_info__common_33;

static const struct mercury_data_pd_info__common_34_struct {
	Word * f1;
	Integer f2;
	Word * f3;
}  mercury_data_pd_info__common_34;

static const struct mercury_data_pd_info__common_35_struct {
	Word * f1;
	Integer f2;
}  mercury_data_pd_info__common_35;

static const struct mercury_data_pd_info__common_36_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_pd_info__common_36;

static const struct mercury_data_pd_info__common_37_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__common_37;

static const struct mercury_data_pd_info__common_38_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_pd_info__common_38;

static const struct mercury_data_pd_info__common_39_struct {
	Word * f1;
}  mercury_data_pd_info__common_39;

static const struct mercury_data_pd_info__common_40_struct {
	Word * f1;
}  mercury_data_pd_info__common_40;

static const struct mercury_data_pd_info__common_41_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_41;

static const struct mercury_data_pd_info__common_42_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_pd_info__common_42;

static const struct mercury_data_pd_info__common_43_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_pd_info__common_43;

static const struct mercury_data_pd_info__common_44_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_pd_info__common_44;

static const struct mercury_data_pd_info__common_45_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__common_45;

static const struct mercury_data_pd_info__common_46_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__common_46;

static const struct mercury_data_pd_info__type_ctor_functors_version_is_exact_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_version_is_exact_0;

static const struct mercury_data_pd_info__type_ctor_layout_version_is_exact_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_version_is_exact_0;

static const struct mercury_data_pd_info__type_ctor_functors_version_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_pd_info__type_ctor_functors_version_info_0;

static const struct mercury_data_pd_info__type_ctor_layout_version_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_version_info_0;

static const struct mercury_data_pd_info__type_ctor_functors_version_index_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_version_index_0;

static const struct mercury_data_pd_info__type_ctor_layout_version_index_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_version_index_0;

static const struct mercury_data_pd_info__type_ctor_functors_unfold_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_pd_info__type_ctor_functors_unfold_info_0;

static const struct mercury_data_pd_info__type_ctor_layout_unfold_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_unfold_info_0;

static const struct mercury_data_pd_info__type_ctor_functors_pd_proc_arg_info_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_pd_proc_arg_info_0;

static const struct mercury_data_pd_info__type_ctor_layout_pd_proc_arg_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_pd_proc_arg_info_0;

static const struct mercury_data_pd_info__type_ctor_functors_pd_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_pd_info__type_ctor_functors_pd_info_0;

static const struct mercury_data_pd_info__type_ctor_layout_pd_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_pd_info_0;

static const struct mercury_data_pd_info__type_ctor_functors_pd_branch_info_1_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_pd_info__type_ctor_functors_pd_branch_info_1;

static const struct mercury_data_pd_info__type_ctor_layout_pd_branch_info_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_pd_branch_info_1;

static const struct mercury_data_pd_info__type_ctor_functors_pd_arg_info_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_pd_arg_info_0;

static const struct mercury_data_pd_info__type_ctor_layout_pd_arg_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_pd_arg_info_0;

static const struct mercury_data_pd_info__type_ctor_functors_maybe_version_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_functors_maybe_version_0;

static const struct mercury_data_pd_info__type_ctor_layout_maybe_version_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_maybe_version_0;

static const struct mercury_data_pd_info__type_ctor_functors_goal_version_index_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_goal_version_index_0;

static const struct mercury_data_pd_info__type_ctor_layout_goal_version_index_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_goal_version_index_0;

static const struct mercury_data_pd_info__type_ctor_functors_branch_info_map_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pd_info__type_ctor_functors_branch_info_map_1;

static const struct mercury_data_pd_info__type_ctor_layout_branch_info_map_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pd_info__type_ctor_layout_branch_info_map_1;

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_branch_info_map_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___pd_info__branch_info_map_1_0),
	ENTRY(mercury____Index___pd_info__branch_info_map_1_0),
	ENTRY(mercury____Compare___pd_info__branch_info_map_1_0),
	(Integer) 6,
	(Word *) &mercury_data_pd_info__type_ctor_functors_branch_info_map_1,
	(Word *) &mercury_data_pd_info__type_ctor_layout_branch_info_map_1,
	MR_string_const("pd_info", 7),
	MR_string_const("branch_info_map", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_goal_version_index_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__goal_version_index_0_0),
	ENTRY(mercury____Index___pd_info__goal_version_index_0_0),
	ENTRY(mercury____Compare___pd_info__goal_version_index_0_0),
	(Integer) 6,
	(Word *) &mercury_data_pd_info__type_ctor_functors_goal_version_index_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_goal_version_index_0,
	MR_string_const("pd_info", 7),
	MR_string_const("goal_version_index", 18),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_maybe_version_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__maybe_version_0_0),
	ENTRY(mercury____Index___pd_info__maybe_version_0_0),
	ENTRY(mercury____Compare___pd_info__maybe_version_0_0),
	(Integer) 2,
	(Word *) &mercury_data_pd_info__type_ctor_functors_maybe_version_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_maybe_version_0,
	MR_string_const("pd_info", 7),
	MR_string_const("maybe_version", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_arg_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__pd_arg_info_0_0),
	ENTRY(mercury____Index___pd_info__pd_arg_info_0_0),
	ENTRY(mercury____Compare___pd_info__pd_arg_info_0_0),
	(Integer) 6,
	(Word *) &mercury_data_pd_info__type_ctor_functors_pd_arg_info_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_pd_arg_info_0,
	MR_string_const("pd_info", 7),
	MR_string_const("pd_arg_info", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_branch_info_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___pd_info__pd_branch_info_1_0),
	ENTRY(mercury____Index___pd_info__pd_branch_info_1_0),
	ENTRY(mercury____Compare___pd_info__pd_branch_info_1_0),
	(Integer) 2,
	(Word *) &mercury_data_pd_info__type_ctor_functors_pd_branch_info_1,
	(Word *) &mercury_data_pd_info__type_ctor_layout_pd_branch_info_1,
	MR_string_const("pd_info", 7),
	MR_string_const("pd_branch_info", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__pd_info_0_0),
	ENTRY(mercury____Index___pd_info__pd_info_0_0),
	ENTRY(mercury____Compare___pd_info__pd_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_pd_info__type_ctor_functors_pd_info_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_pd_info_0,
	MR_string_const("pd_info", 7),
	MR_string_const("pd_info", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_pd_proc_arg_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__pd_proc_arg_info_0_0),
	ENTRY(mercury____Index___pd_info__pd_proc_arg_info_0_0),
	ENTRY(mercury____Compare___pd_info__pd_proc_arg_info_0_0),
	(Integer) 6,
	(Word *) &mercury_data_pd_info__type_ctor_functors_pd_proc_arg_info_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_pd_proc_arg_info_0,
	MR_string_const("pd_info", 7),
	MR_string_const("pd_proc_arg_info", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_unfold_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__unfold_info_0_0),
	ENTRY(mercury____Index___pd_info__unfold_info_0_0),
	ENTRY(mercury____Compare___pd_info__unfold_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_pd_info__type_ctor_functors_unfold_info_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_unfold_info_0,
	MR_string_const("pd_info", 7),
	MR_string_const("unfold_info", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_index_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__version_index_0_0),
	ENTRY(mercury____Index___pd_info__version_index_0_0),
	ENTRY(mercury____Compare___pd_info__version_index_0_0),
	(Integer) 6,
	(Word *) &mercury_data_pd_info__type_ctor_functors_version_index_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_version_index_0,
	MR_string_const("pd_info", 7),
	MR_string_const("version_index", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__version_info_0_0),
	ENTRY(mercury____Index___pd_info__version_info_0_0),
	ENTRY(mercury____Compare___pd_info__version_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_pd_info__type_ctor_functors_version_info_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_version_info_0,
	MR_string_const("pd_info", 7),
	MR_string_const("version_info", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_pd_info__type_ctor_info_version_is_exact_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___pd_info__version_is_exact_0_0),
	ENTRY(mercury____Index___pd_info__version_is_exact_0_0),
	ENTRY(mercury____Compare___pd_info__version_is_exact_0_0),
	(Integer) 0,
	(Word *) &mercury_data_pd_info__type_ctor_functors_version_is_exact_0,
	(Word *) &mercury_data_pd_info__type_ctor_layout_version_is_exact_0,
	MR_string_const("pd_info", 7),
	MR_string_const("version_is_exact", 16),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_pd_info__common_0_struct mercury_data_pd_info__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_pd_info__common_1_struct mercury_data_pd_info__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_pd_info__common_2_struct mercury_data_pd_info__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_pd_info__common_3_struct mercury_data_pd_info__common_3 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_pd_info__common_4_struct mercury_data_pd_info__common_4 = {
	(Word *) &mercury_data_pd_info__type_ctor_info_pd_branch_info_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_pd_info__common_5_struct mercury_data_pd_info__common_5 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_pd_info__common_6_struct mercury_data_pd_info__common_6 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_pd_info__common_7_struct mercury_data_pd_info__common_7 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("exact", 5),
	MR_string_const("more_general", 12)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_pd_info__common_8_struct mercury_data_pd_info__common_8 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

static const struct mercury_data_pd_info__common_9_struct mercury_data_pd_info__common_9 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2)
};

static const struct mercury_data_pd_info__common_10_struct mercury_data_pd_info__common_10 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_instmap__type_ctor_info_instmap_0;
static const struct mercury_data_pd_info__common_11_struct mercury_data_pd_info__common_11 = {
	(Word *) &mercury_data_instmap__type_ctor_info_instmap_0
};

static const struct mercury_data_pd_info__common_12_struct mercury_data_pd_info__common_12 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_pd_info__common_13_struct mercury_data_pd_info__common_13 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_pd_info__common_14_struct mercury_data_pd_info__common_14 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_pd_info__common_15_struct mercury_data_pd_info__common_15 = {
	(Integer) 9,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_14),
	MR_string_const("version_info", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_pd_info__common_16_struct mercury_data_pd_info__common_16 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	(Word *) &mercury_data_pd_info__type_ctor_info_version_info_0
};

static const struct mercury_data_pd_info__common_17_struct mercury_data_pd_info__common_17 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_16)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_data_pd_info__common_18_struct mercury_data_pd_info__common_18 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_pd_term__type_ctor_info_local_term_info_0;
static const struct mercury_data_pd_info__common_19_struct mercury_data_pd_info__common_19 = {
	(Word *) &mercury_data_pd_term__type_ctor_info_local_term_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
static const struct mercury_data_pd_info__common_20_struct mercury_data_pd_info__common_20 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

static const struct mercury_data_pd_info__common_21_struct mercury_data_pd_info__common_21 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_pd_info__common_22_struct mercury_data_pd_info__common_22 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_pd_info__common_23_struct mercury_data_pd_info__common_23 = {
	(Integer) 10,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_22),
	MR_string_const("unfold_info", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pd_info__common_24_struct mercury_data_pd_info__common_24 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_pd_info__common_25_struct mercury_data_pd_info__common_25 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_pd_info__common_26_struct mercury_data_pd_info__common_26 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_pd_info__common_27_struct mercury_data_pd_info__common_27 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_pd_info__type_ctor_info_unfold_info_0
};

static const struct mercury_data_pd_info__common_28_struct mercury_data_pd_info__common_28 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0)
};

static const struct mercury_data_pd_info__common_29_struct mercury_data_pd_info__common_29 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_pd_term__type_ctor_info_global_term_info_0;
static const struct mercury_data_pd_info__common_30_struct mercury_data_pd_info__common_30 = {
	(Word *) &mercury_data_pd_term__type_ctor_info_global_term_info_0
};

static const struct mercury_data_pd_info__common_31_struct mercury_data_pd_info__common_31 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_unit_0;
static const struct mercury_data_pd_info__common_32_struct mercury_data_pd_info__common_32 = {
	(Word *) &mercury_data_std_util__type_ctor_info_unit_0
};

static const struct mercury_data_pd_info__common_33_struct mercury_data_pd_info__common_33 = {
	(Integer) 14,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_28),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_29),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_31),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_32),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_32),
	MR_string_const("pd_info", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pd_info__common_34_struct mercury_data_pd_info__common_34 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5)
};

static const struct mercury_data_pd_info__common_35_struct mercury_data_pd_info__common_35 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Integer) 1
};

static const struct mercury_data_pd_info__common_36_struct mercury_data_pd_info__common_36 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_35),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_35),
	MR_string_const("pd_branch_info", 14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pd_info__common_37_struct mercury_data_pd_info__common_37 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_29)
};

static const struct mercury_data_pd_info__common_38_struct mercury_data_pd_info__common_38 = {
	(Integer) 0,
	MR_string_const("no_version", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pd_info__common_39_struct mercury_data_pd_info__common_39 = {
	(Word *) &mercury_data_pd_info__type_ctor_info_version_is_exact_0
};

static const struct mercury_data_pd_info__common_40_struct mercury_data_pd_info__common_40 = {
	(Word *) &mercury_data_pd_info__type_ctor_info_version_info_0
};

static const struct mercury_data_pd_info__common_41_struct mercury_data_pd_info__common_41 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2)
};

static const struct mercury_data_pd_info__common_42_struct mercury_data_pd_info__common_42 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3)
};

static const struct mercury_data_pd_info__common_43_struct mercury_data_pd_info__common_43 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_39),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_41),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_42),
	MR_string_const("version", 7),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pd_info__common_44_struct mercury_data_pd_info__common_44 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("no_version", 10)
};

static const struct mercury_data_pd_info__common_45_struct mercury_data_pd_info__common_45 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_28)
};

static const struct mercury_data_pd_info__common_46_struct mercury_data_pd_info__common_46 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_34)
};

static const struct mercury_data_pd_info__type_ctor_functors_version_is_exact_0_struct mercury_data_pd_info__type_ctor_functors_version_is_exact_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_7)
};

static const struct mercury_data_pd_info__type_ctor_layout_version_is_exact_0_struct mercury_data_pd_info__type_ctor_layout_version_is_exact_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_7)
};

static const struct mercury_data_pd_info__type_ctor_functors_version_info_0_struct mercury_data_pd_info__type_ctor_functors_version_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_15)
};

static const struct mercury_data_pd_info__type_ctor_layout_version_info_0_struct mercury_data_pd_info__type_ctor_layout_version_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pd_info__common_15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_pd_info__type_ctor_functors_version_index_0_struct mercury_data_pd_info__type_ctor_functors_version_index_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_16)
};

static const struct mercury_data_pd_info__type_ctor_layout_version_index_0_struct mercury_data_pd_info__type_ctor_layout_version_index_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_17)
};

static const struct mercury_data_pd_info__type_ctor_functors_unfold_info_0_struct mercury_data_pd_info__type_ctor_functors_unfold_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_23)
};

static const struct mercury_data_pd_info__type_ctor_layout_unfold_info_0_struct mercury_data_pd_info__type_ctor_layout_unfold_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pd_info__common_23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_pd_info__type_ctor_functors_pd_proc_arg_info_0_struct mercury_data_pd_info__type_ctor_functors_pd_proc_arg_info_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4)
};

static const struct mercury_data_pd_info__type_ctor_layout_pd_proc_arg_info_0_struct mercury_data_pd_info__type_ctor_layout_pd_proc_arg_info_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_24),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_24),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_24),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_24)
};

static const struct mercury_data_pd_info__type_ctor_functors_pd_info_0_struct mercury_data_pd_info__type_ctor_functors_pd_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_33)
};

static const struct mercury_data_pd_info__type_ctor_layout_pd_info_0_struct mercury_data_pd_info__type_ctor_layout_pd_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pd_info__common_33),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_pd_info__type_ctor_functors_pd_branch_info_1_struct mercury_data_pd_info__type_ctor_functors_pd_branch_info_1 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_36)
};

static const struct mercury_data_pd_info__type_ctor_layout_pd_branch_info_1_struct mercury_data_pd_info__type_ctor_layout_pd_branch_info_1 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pd_info__common_36),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_pd_info__type_ctor_functors_pd_arg_info_0_struct mercury_data_pd_info__type_ctor_functors_pd_arg_info_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_29)
};

static const struct mercury_data_pd_info__type_ctor_layout_pd_arg_info_0_struct mercury_data_pd_info__type_ctor_layout_pd_arg_info_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_37),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_37),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_37),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_37)
};

static const struct mercury_data_pd_info__type_ctor_functors_maybe_version_0_struct mercury_data_pd_info__type_ctor_functors_maybe_version_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_38),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_43)
};

static const struct mercury_data_pd_info__type_ctor_layout_maybe_version_0_struct mercury_data_pd_info__type_ctor_layout_maybe_version_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_44),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pd_info__common_43),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_pd_info__type_ctor_functors_goal_version_index_0_struct mercury_data_pd_info__type_ctor_functors_goal_version_index_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_28)
};

static const struct mercury_data_pd_info__type_ctor_layout_goal_version_index_0_struct mercury_data_pd_info__type_ctor_layout_goal_version_index_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_45),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_45),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_45),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_45)
};

static const struct mercury_data_pd_info__type_ctor_functors_branch_info_map_1_struct mercury_data_pd_info__type_ctor_functors_branch_info_map_1 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_34)
};

static const struct mercury_data_pd_info__type_ctor_layout_branch_info_map_1_struct mercury_data_pd_info__type_ctor_layout_branch_info_map_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_46),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_46),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_46),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_pd_info__common_46)
};


BEGIN_MODULE(pd_info_module0)
	init_entry(mercury____Index___pd_info__version_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pd_info__version_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___pd_info__version_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module1)
	init_entry(mercury____Index___pd_info__pd_branch_info_1__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pd_info__pd_branch_info_1__ua0'/2 in mode 0 */
Define_static(mercury____Index___pd_info__pd_branch_info_1__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module2)
	init_entry(mercury____Index___pd_info__pd_proc_arg_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pd_info__pd_proc_arg_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___pd_info__pd_proc_arg_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module3)
	init_entry(mercury____Index___pd_info__unfold_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pd_info__unfold_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___pd_info__unfold_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module4)
	init_entry(mercury____Index___pd_info__pd_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pd_info__pd_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___pd_info__pd_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module5)
	init_entry(mercury__pd_info__pick_version__ua0_7_0);
	init_label(mercury__pd_info__pick_version__ua0_7_0_i3);
	init_label(mercury__pd_info__pick_version__ua0_7_0_i5);
	init_label(mercury__pd_info__pick_version__ua0_7_0_i1011);
BEGIN_CODE

/* code for predicate 'pick_version__ua0'/7 in mode 0 */
Define_static(mercury__pd_info__pick_version__ua0_7_0);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pick_version__ua0_7_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 5, mercury__pd_info__pick_version__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = (Integer) 1;
	proceed();
	}
Define_label(mercury__pd_info__pick_version__ua0_7_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r5, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__pd_info__pick_version__ua0_7_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 5, mercury__pd_info__pick_version__ua0_7_0, "pd_info:maybe_version/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 2) = MR_const_field(MR_mktag(1), r5, (Integer) 2);
	MR_field(MR_mktag(1), r1, (Integer) 3) = MR_const_field(MR_mktag(1), r5, (Integer) 3);
	MR_field(MR_mktag(1), r1, (Integer) 4) = MR_const_field(MR_mktag(1), r5, (Integer) 4);
	proceed();
Define_label(mercury__pd_info__pick_version__ua0_7_0_i5);
	r9 = MR_const_field(MR_mktag(1), r5, (Integer) 4);
	r8 = MR_const_field(MR_mktag(1), r5, (Integer) 3);
	r7 = MR_const_field(MR_mktag(1), r5, (Integer) 2);
	r6 = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), r4, (Integer) 6) <= (Integer) MR_const_field(MR_mktag(0), r7, (Integer) 6)))
		GOTO_LABEL(mercury__pd_info__pick_version__ua0_7_0_i1011);
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 5, mercury__pd_info__pick_version__ua0_7_0, "pd_info:maybe_version/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r1, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 4) = r3;
	proceed();
Define_label(mercury__pd_info__pick_version__ua0_7_0_i1011);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 5, mercury__pd_info__pick_version__ua0_7_0, "pd_info:maybe_version/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r1, (Integer) 2) = r7;
	MR_field(MR_mktag(1), r1, (Integer) 3) = r8;
	MR_field(MR_mktag(1), r1, (Integer) 4) = r9;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__pd_term__global_term_info_init_1_0);

BEGIN_MODULE(pd_info_module6)
	init_entry(mercury__pd_info__pd_info_init_4_0);
	init_label(mercury__pd_info__pd_info_init_4_0_i2);
	init_label(mercury__pd_info__pd_info_init_4_0_i3);
	init_label(mercury__pd_info__pd_info_init_4_0_i4);
	init_label(mercury__pd_info__pd_info_init_4_0_i5);
	init_label(mercury__pd_info__pd_info_init_4_0_i6);
	init_label(mercury__pd_info__pd_info_init_4_0_i7);
BEGIN_CODE

/* code for predicate 'pd_info_init'/4 in mode 0 */
Define_entry(mercury__pd_info__pd_info_init_4_0);
	MR_incr_sp_push_msg(9, "pd_info:pd_info_init/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__pd_info__pd_info_init_4_0_i2,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__pd_info__pd_info_init_4_0_i3,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__pd_info__pd_info_init_4_0_i4,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__pd_term__global_term_info_init_1_0),
		mercury__pd_info__pd_info_init_4_0_i5,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__pd_info__pd_info_init_4_0_i6,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__pd_info__pd_info_init_4_0_i7,
		ENTRY(mercury__pd_info__pd_info_init_4_0));
Define_label(mercury__pd_info__pd_info_init_4_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_init_4_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 6) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 9) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 11) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 12) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 13) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
Declare_entry(mercury__pd_term__local_term_info_init_1_0);
Declare_entry(mercury__set__singleton_set_2_1);

BEGIN_MODULE(pd_info_module7)
	init_entry(mercury__pd_info__pd_info_init_unfold_info_5_0);
	init_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i2);
	init_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i3);
	init_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i4);
BEGIN_CODE

/* code for predicate 'pd_info_init_unfold_info'/5 in mode 0 */
Define_entry(mercury__pd_info__pd_info_init_unfold_info_5_0);
	MR_incr_sp_push_msg(7, "pd_info:pd_info_init_unfold_info/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r1 = r3;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__pd_info__pd_info_init_unfold_info_5_0_i2,
		ENTRY(mercury__pd_info__pd_info_init_unfold_info_5_0));
Define_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_unfold_info_5_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__pd_term__local_term_info_init_1_0),
		mercury__pd_info__pd_info_init_unfold_info_5_0_i3,
		ENTRY(mercury__pd_info__pd_info_init_unfold_info_5_0));
Define_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_unfold_info_5_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__pd_info__pd_info_init_unfold_info_5_0_i4,
		ENTRY(mercury__pd_info__pd_info_init_unfold_info_5_0));
Define_label(mercury__pd_info__pd_info_init_unfold_info_5_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_init_unfold_info_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_init_unfold_info_5_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_init_unfold_info_5_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_init_unfold_info_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module8)
	init_entry(mercury__pd_info__pd_info_get_io_state_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_io_state'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_io_state_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module9)
	init_entry(mercury__pd_info__pd_info_get_module_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_module_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_module_info_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(pd_info_module10)
	init_entry(mercury__pd_info__pd_info_get_unfold_info_3_0);
	init_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_unfold_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_unfold_info_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_unfold_info_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_unfold_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_unfold_info_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_unfold_info_3_0));
Define_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_unfold_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_unfold_info_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module11)
	init_entry(mercury__pd_info__pd_info_get_goal_version_index_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_goal_version_index'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_goal_version_index_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module12)
	init_entry(mercury__pd_info__pd_info_get_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_versions_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module13)
	init_entry(mercury__pd_info__pd_info_get_proc_arg_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_proc_arg_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_proc_arg_info_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module14)
	init_entry(mercury__pd_info__pd_info_get_counter_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_counter'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_counter_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module15)
	init_entry(mercury__pd_info__pd_info_get_global_term_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_global_term_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_global_term_info_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module16)
	init_entry(mercury__pd_info__pd_info_get_parent_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_parent_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_parent_versions_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module17)
	init_entry(mercury__pd_info__pd_info_get_depth_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_depth'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_depth_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module18)
	init_entry(mercury__pd_info__pd_info_get_created_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_created_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_created_versions_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module19)
	init_entry(mercury__pd_info__pd_info_get_useless_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_get_useless_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_useless_versions_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module20)
	init_entry(mercury__pd_info__pd_info_set_io_state_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_io_state'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_io_state_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_io_state_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module21)
	init_entry(mercury__pd_info__pd_info_set_module_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_module_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_module_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_module_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module22)
	init_entry(mercury__pd_info__pd_info_set_unfold_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_unfold_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_unfold_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_unfold_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_unfold_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module23)
	init_entry(mercury__pd_info__pd_info_set_goal_version_index_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_goal_version_index'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_goal_version_index_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_goal_version_index_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module24)
	init_entry(mercury__pd_info__pd_info_set_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_versions_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_versions_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module25)
	init_entry(mercury__pd_info__pd_info_set_proc_arg_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_proc_arg_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_proc_arg_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_proc_arg_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module26)
	init_entry(mercury__pd_info__pd_info_set_counter_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_counter'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_counter_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_counter_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module27)
	init_entry(mercury__pd_info__pd_info_set_global_term_info_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_global_term_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_global_term_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_global_term_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module28)
	init_entry(mercury__pd_info__pd_info_set_parent_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_parent_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_parent_versions_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_parent_versions_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module29)
	init_entry(mercury__pd_info__pd_info_set_depth_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_depth'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_depth_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_depth_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module30)
	init_entry(mercury__pd_info__pd_info_set_created_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_created_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_created_versions_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_created_versions_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module31)
	init_entry(mercury__pd_info__pd_info_set_useless_versions_3_0);
BEGIN_CODE

/* code for predicate 'pd_info_set_useless_versions'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_useless_versions_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_useless_versions_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__instmap__apply_instmap_delta_3_0);

BEGIN_MODULE(pd_info_module32)
	init_entry(mercury__pd_info__pd_info_update_goal_3_0);
	init_label(mercury__pd_info__pd_info_update_goal_3_0_i4);
	init_label(mercury__pd_info__pd_info_update_goal_3_0_i3);
	init_label(mercury__pd_info__pd_info_update_goal_3_0_i5);
	init_label(mercury__pd_info__pd_info_update_goal_3_0_i6);
BEGIN_CODE

/* code for predicate 'pd_info_update_goal'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_update_goal_3_0);
	MR_incr_sp_push_msg(3, "pd_info:pd_info_update_goal/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_update_goal_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_update_goal_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_update_goal_3_0));
Define_label(mercury__pd_info__pd_info_update_goal_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_update_goal_3_0));
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__pd_info__pd_info_update_goal_3_0_i5,
		ENTRY(mercury__pd_info__pd_info_update_goal_3_0));
Define_label(mercury__pd_info__pd_info_update_goal_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__pd_info__pd_info_update_goal_3_0_i5,
		ENTRY(mercury__pd_info__pd_info_update_goal_3_0));
Define_label(mercury__pd_info__pd_info_update_goal_3_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_update_goal_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__instmap__apply_instmap_delta_3_0),
		mercury__pd_info__pd_info_update_goal_3_0_i6,
		ENTRY(mercury__pd_info__pd_info_update_goal_3_0));
Define_label(mercury__pd_info__pd_info_update_goal_3_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_update_goal_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__pd_info__pd_info_set_instmap_3_0),
		ENTRY(mercury__pd_info__pd_info_update_goal_3_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_option_4_0);

BEGIN_MODULE(pd_info_module33)
	init_entry(mercury__pd_info__pd_info_lookup_option_4_0);
	init_label(mercury__pd_info__pd_info_lookup_option_4_0_i2);
BEGIN_CODE

/* code for predicate 'pd_info_lookup_option'/4 in mode 0 */
Define_entry(mercury__pd_info__pd_info_lookup_option_4_0);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_lookup_option/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__globals__io_lookup_option_4_0),
		mercury__pd_info__pd_info_lookup_option_4_0_i2,
		ENTRY(mercury__pd_info__pd_info_lookup_option_4_0));
Define_label(mercury__pd_info__pd_info_lookup_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_lookup_option_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_lookup_option_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r2 = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 13);
	MR_field(MR_mktag(0), r3, (Integer) 12) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 12);
	MR_field(MR_mktag(0), r3, (Integer) 11) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 11);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 10);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 9);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 7);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 8);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module34)
	init_entry(mercury__pd_info__pd_info_lookup_bool_option_4_0);
	init_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i2);
	init_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i3);
	init_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i5);
BEGIN_CODE

/* code for predicate 'pd_info_lookup_bool_option'/4 in mode 0 */
Define_entry(mercury__pd_info__pd_info_lookup_bool_option_4_0);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_lookup_bool_option/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__globals__io_lookup_option_4_0),
		mercury__pd_info__pd_info_lookup_bool_option_4_0_i2,
		ENTRY(mercury__pd_info__pd_info_lookup_bool_option_4_0));
Define_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_lookup_bool_option_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_lookup_bool_option_4_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 13);
	MR_field(MR_mktag(0), r3, (Integer) 12) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 12);
	MR_field(MR_mktag(0), r3, (Integer) 11) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 11);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 10);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 9);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 7);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 8);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__pd_info__pd_info_lookup_bool_option_4_0_i3);
	r2 = r3;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i3);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("pd_info_lookup_bool_option", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_lookup_bool_option_4_0_i5,
		ENTRY(mercury__pd_info__pd_info_lookup_bool_option_4_0));
Define_label(mercury__pd_info__pd_info_lookup_bool_option_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_lookup_bool_option_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__instmap__bind_var_to_functor_7_0);

BEGIN_MODULE(pd_info_module35)
	init_entry(mercury__pd_info__pd_info_bind_var_to_functor_4_0);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i3);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i2);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i5);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i6);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i7);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i8);
	init_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i9);
BEGIN_CODE

/* code for predicate 'pd_info_bind_var_to_functor'/4 in mode 0 */
Define_entry(mercury__pd_info__pd_info_bind_var_to_functor_4_0);
	MR_incr_sp_push_msg(6, "pd_info:pd_info_bind_var_to_functor/4");
	MR_stackvar(6) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i3);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i2,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1);
	r1 = r3;
	MR_stackvar(2) = r2;
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	call_localret(STATIC(mercury__pd_info__pd_info_get_proc_info_3_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i5,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i6,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i7,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__bind_var_to_functor_7_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i8,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__pd_info__pd_info_set_instmap_3_0),
		mercury__pd_info__pd_info_bind_var_to_functor_4_0_i9,
		ENTRY(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
Define_label(mercury__pd_info__pd_info_bind_var_to_functor_4_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_bind_var_to_functor_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_bind_var_to_functor_4_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module36)
	init_entry(mercury__pd_info__pd_info_unset_unfold_info_2_0);
BEGIN_CODE

/* code for predicate 'pd_info_unset_unfold_info'/2 in mode 0 */
Define_entry(mercury__pd_info__pd_info_unset_unfold_info_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_unset_unfold_info_2_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE

Declare_entry(mercury__do_call_closure);

BEGIN_MODULE(pd_info_module37)
	init_entry(mercury__pd_info__pd_info_foldl_4_0);
	init_label(mercury__pd_info__pd_info_foldl_4_0_i1001);
	init_label(mercury__pd_info__pd_info_foldl_4_0_i4);
	init_label(mercury__pd_info__pd_info_foldl_4_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_foldl'/4 in mode 0 */
Define_entry(mercury__pd_info__pd_info_foldl_4_0);
	MR_incr_sp_push_msg(4, "pd_info:pd_info_foldl/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__pd_info__pd_info_foldl_4_0_i1001);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_foldl_4_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(3) = r1;
	r5 = r4;
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = r2;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__pd_info__pd_info_foldl_4_0_i4,
		ENTRY(mercury__pd_info__pd_info_foldl_4_0));
Define_label(mercury__pd_info__pd_info_foldl_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_foldl_4_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__pd_info__pd_info_foldl_4_0_i1001);
Define_label(mercury__pd_info__pd_info_foldl_4_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module38)
	init_entry(mercury__pd_info__pd_info_foldl2_6_0);
	init_label(mercury__pd_info__pd_info_foldl2_6_0_i1001);
	init_label(mercury__pd_info__pd_info_foldl2_6_0_i4);
	init_label(mercury__pd_info__pd_info_foldl2_6_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_foldl2'/6 in mode 0 */
Define_entry(mercury__pd_info__pd_info_foldl2_6_0);
	MR_incr_sp_push_msg(5, "pd_info:pd_info_foldl2/6");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__pd_info__pd_info_foldl2_6_0_i1001);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_foldl2_6_0_i3);
	MR_stackvar(3) = r1;
	r1 = r3;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(4) = r2;
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = (Integer) 3;
	r3 = (Integer) 2;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__pd_info__pd_info_foldl2_6_0_i4,
		ENTRY(mercury__pd_info__pd_info_foldl2_6_0));
Define_label(mercury__pd_info__pd_info_foldl2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_foldl2_6_0));
	r5 = r1;
	r6 = r2;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__pd_info__pd_info_foldl2_6_0_i1001);
Define_label(mercury__pd_info__pd_info_foldl2_6_0_i3);
	r1 = r5;
	r2 = r6;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module39)
	init_entry(mercury__pd_info__pd_info_get_proc_info_3_0);
	init_label(mercury__pd_info__pd_info_get_proc_info_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_proc_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_proc_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_proc_info_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_proc_info_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_proc_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_proc_info_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_proc_info_3_0));
Define_label(mercury__pd_info__pd_info_get_proc_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_proc_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_proc_info_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module40)
	init_entry(mercury__pd_info__pd_info_get_instmap_3_0);
	init_label(mercury__pd_info__pd_info_get_instmap_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_instmap_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_instmap'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_instmap_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_instmap_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_instmap/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_instmap_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_instmap_3_0));
Define_label(mercury__pd_info__pd_info_get_instmap_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_instmap_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_instmap_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module41)
	init_entry(mercury__pd_info__pd_info_get_cost_delta_3_0);
	init_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_cost_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_cost_delta_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_cost_delta_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_cost_delta/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_cost_delta_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_cost_delta_3_0));
Define_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_cost_delta_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_cost_delta_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module42)
	init_entry(mercury__pd_info__pd_info_get_local_term_info_3_0);
	init_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_local_term_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_local_term_info_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_local_term_info_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_local_term_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_local_term_info_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_local_term_info_3_0));
Define_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_local_term_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_local_term_info_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module43)
	init_entry(mercury__pd_info__pd_info_get_pred_info_3_0);
	init_label(mercury__pd_info__pd_info_get_pred_info_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_pred_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_pred_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_pred_info_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_pred_info_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_pred_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_pred_info_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_pred_info_3_0));
Define_label(mercury__pd_info__pd_info_get_pred_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_pred_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_pred_info_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module44)
	init_entry(mercury__pd_info__pd_info_get_parents_3_0);
	init_label(mercury__pd_info__pd_info_get_parents_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_parents_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_parents'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_parents_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_parents_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_parents/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_parents_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_parents_3_0));
Define_label(mercury__pd_info__pd_info_get_parents_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_parents_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_parents_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module45)
	init_entry(mercury__pd_info__pd_info_get_pred_proc_id_3_0);
	init_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_pred_proc_id'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_pred_proc_id_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_pred_proc_id/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_pred_proc_id_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_pred_proc_id_3_0));
Define_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_pred_proc_id_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_pred_proc_id_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 6);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module46)
	init_entry(mercury__pd_info__pd_info_get_changed_3_0);
	init_label(mercury__pd_info__pd_info_get_changed_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_changed_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_changed'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_changed_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_changed_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_changed/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_changed_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_changed_3_0));
Define_label(mercury__pd_info__pd_info_get_changed_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_changed_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_changed_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 7);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module47)
	init_entry(mercury__pd_info__pd_info_get_size_delta_3_0);
	init_label(mercury__pd_info__pd_info_get_size_delta_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_size_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_size_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_size_delta_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_size_delta_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_size_delta/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_size_delta_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_size_delta_3_0));
Define_label(mercury__pd_info__pd_info_get_size_delta_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_size_delta_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_size_delta_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 8);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module48)
	init_entry(mercury__pd_info__pd_info_get_rerun_det_3_0);
	init_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i4);
	init_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_get_rerun_det'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_get_rerun_det_3_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_get_rerun_det_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_get_rerun_det/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_get_rerun_det_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_get_rerun_det_3_0));
Define_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_get_rerun_det_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pd_info__pd_info_get_rerun_det_3_0_i3);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0), (Integer) 9);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module49)
	init_entry(mercury__pd_info__pd_info_set_proc_info_3_0);
	init_label(mercury__pd_info__pd_info_set_proc_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_proc_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_proc_info_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_proc_info_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_proc_info_3_0));
Define_label(mercury__pd_info__pd_info_set_proc_info_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_proc_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_proc_info_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_proc_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module50)
	init_entry(mercury__pd_info__pd_info_set_instmap_3_0);
	init_label(mercury__pd_info__pd_info_set_instmap_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_instmap'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_instmap_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_instmap_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_instmap_3_0));
Define_label(mercury__pd_info__pd_info_set_instmap_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_instmap_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_instmap_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_instmap_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module51)
	init_entry(mercury__pd_info__pd_info_set_cost_delta_3_0);
	init_label(mercury__pd_info__pd_info_set_cost_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_cost_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_cost_delta_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_cost_delta_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_cost_delta_3_0));
Define_label(mercury__pd_info__pd_info_set_cost_delta_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_cost_delta_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_cost_delta_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_cost_delta_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module52)
	init_entry(mercury__pd_info__pd_info_set_local_term_info_3_0);
	init_label(mercury__pd_info__pd_info_set_local_term_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_local_term_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_local_term_info_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_local_term_info_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_local_term_info_3_0));
Define_label(mercury__pd_info__pd_info_set_local_term_info_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_local_term_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_local_term_info_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_local_term_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module53)
	init_entry(mercury__pd_info__pd_info_set_pred_info_3_0);
	init_label(mercury__pd_info__pd_info_set_pred_info_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_pred_info'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_pred_info_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_pred_info_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_pred_info_3_0));
Define_label(mercury__pd_info__pd_info_set_pred_info_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_pred_info_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_pred_info_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_pred_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module54)
	init_entry(mercury__pd_info__pd_info_set_parents_3_0);
	init_label(mercury__pd_info__pd_info_set_parents_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_parents'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_parents_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_parents_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_parents_3_0));
Define_label(mercury__pd_info__pd_info_set_parents_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_parents_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_parents_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_parents_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module55)
	init_entry(mercury__pd_info__pd_info_set_pred_proc_id_3_0);
	init_label(mercury__pd_info__pd_info_set_pred_proc_id_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_pred_proc_id'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_pred_proc_id_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_pred_proc_id_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_pred_proc_id_3_0));
Define_label(mercury__pd_info__pd_info_set_pred_proc_id_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_pred_proc_id_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_pred_proc_id_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_pred_proc_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module56)
	init_entry(mercury__pd_info__pd_info_set_changed_3_0);
	init_label(mercury__pd_info__pd_info_set_changed_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_changed'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_changed_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_changed_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_changed_3_0));
Define_label(mercury__pd_info__pd_info_set_changed_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_changed_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_changed_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_changed_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module57)
	init_entry(mercury__pd_info__pd_info_set_size_delta_3_0);
	init_label(mercury__pd_info__pd_info_set_size_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_size_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_size_delta_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_size_delta_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_size_delta_3_0));
Define_label(mercury__pd_info__pd_info_set_size_delta_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_size_delta_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_size_delta_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_size_delta_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module58)
	init_entry(mercury__pd_info__pd_info_set_rerun_det_3_0);
	init_label(mercury__pd_info__pd_info_set_rerun_det_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_set_rerun_det'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_set_rerun_det_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_set_rerun_det_3_0_i3);
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__pd_info__pd_info_set_rerun_det_3_0));
Define_label(mercury__pd_info__pd_info_set_rerun_det_3_0_i3);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__pd_info_set_rerun_det_3_0, "pd_info:pd_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pd_info__pd_info_set_rerun_det_3_0, "std_util:maybe/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 10, mercury__pd_info__pd_info_set_rerun_det_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 9) = r4;
	proceed();
	}
END_MODULE


BEGIN_MODULE(pd_info_module59)
	init_entry(mercury__pd_info__pd_info_incr_cost_delta_3_0);
	init_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i4);
	init_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_incr_cost_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_incr_cost_delta_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_incr_cost_delta_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_incr_cost_delta/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_incr_cost_delta_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_incr_cost_delta_3_0));
Define_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_incr_cost_delta_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__pd_info__pd_info_set_cost_delta_3_0),
		ENTRY(mercury__pd_info__pd_info_incr_cost_delta_3_0));
Define_label(mercury__pd_info__pd_info_incr_cost_delta_3_0_i3);
	r1 = ((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 2) + (Integer) r1);
	tailcall(STATIC(mercury__pd_info__pd_info_set_cost_delta_3_0),
		ENTRY(mercury__pd_info__pd_info_incr_cost_delta_3_0));
END_MODULE


BEGIN_MODULE(pd_info_module60)
	init_entry(mercury__pd_info__pd_info_incr_size_delta_3_0);
	init_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i4);
	init_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i3);
BEGIN_CODE

/* code for predicate 'pd_info_incr_size_delta'/3 in mode 0 */
Define_entry(mercury__pd_info__pd_info_incr_size_delta_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__pd_info_incr_size_delta_3_0_i3);
	MR_incr_sp_push_msg(2, "pd_info:pd_info_incr_size_delta/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__pd_info_incr_size_delta_3_0_i4,
		ENTRY(mercury__pd_info__pd_info_incr_size_delta_3_0));
Define_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__pd_info_incr_size_delta_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__pd_info__pd_info_set_size_delta_3_0),
		ENTRY(mercury__pd_info__pd_info_incr_size_delta_3_0));
Define_label(mercury__pd_info__pd_info_incr_size_delta_3_0_i3);
	r1 = ((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 8) + (Integer) r1);
	tailcall(STATIC(mercury__pd_info__pd_info_set_size_delta_3_0),
		ENTRY(mercury__pd_info__pd_info_incr_size_delta_3_0));
END_MODULE

Declare_entry(mercury__pd_debug__output_goal_4_0);
Declare_entry(mercury__pd_util__goal_get_calls_2_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__pd_debug__search_version_result_3_0);

BEGIN_MODULE(pd_info_module61)
	init_entry(mercury__pd_info__search_version_4_0);
	init_label(mercury__pd_info__search_version_4_0_i2);
	init_label(mercury__pd_info__search_version_4_0_i3);
	init_label(mercury__pd_info__search_version_4_0_i4);
	init_label(mercury__pd_info__search_version_4_0_i5);
	init_label(mercury__pd_info__search_version_4_0_i6);
	init_label(mercury__pd_info__search_version_4_0_i8);
	init_label(mercury__pd_info__search_version_4_0_i10);
	init_label(mercury__pd_info__search_version_4_0_i7);
	init_label(mercury__pd_info__search_version_4_0_i12);
	init_label(mercury__pd_info__search_version_4_0_i13);
BEGIN_CODE

/* code for predicate 'search_version'/4 in mode 0 */
Define_entry(mercury__pd_info__search_version_4_0);
	MR_incr_sp_push_msg(8, "pd_info:search_version/4");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Searching for version:\n", 23);
	call_localret(ENTRY(mercury__pd_debug__output_goal_4_0),
		mercury__pd_info__search_version_4_0_i2,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__pd_util__goal_get_calls_2_0),
		mercury__pd_info__search_version_4_0_i3,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__pd_info__pd_info_get_proc_info_3_0),
		mercury__pd_info__search_version_4_0_i4,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__pd_info__pd_info_get_instmap_3_0),
		mercury__pd_info__search_version_4_0_i5,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__pd_info__search_version_4_0_i6,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	r4 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__pd_info__search_version_4_0_i8,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__search_version_4_0_i7);
	r5 = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	call_localret(STATIC(mercury__pd_info__get_matching_version_7_0),
		mercury__pd_info__search_version_4_0_i10,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__search_version_4_0_i7);
	r1 = r2;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__pd_info__search_version_4_0_i12);
Define_label(mercury__pd_info__search_version_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(5);
Define_label(mercury__pd_info__search_version_4_0_i12);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__pd_debug__search_version_result_3_0),
		mercury__pd_info__search_version_4_0_i13,
		ENTRY(mercury__pd_info__search_version_4_0));
Define_label(mercury__pd_info__search_version_4_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_info__search_version_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__term__context_line_2_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__prog_util__make_pred_name_with_context_7_0);
Declare_entry(mercury__prog_util__unqualify_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_typevarset_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_markers_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_class_context_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_aditi_owner_2_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0);
Declare_entry(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0);
Declare_entry(mercury__hlds_pred__define_new_pred_18_0);

BEGIN_MODULE(pd_info_module62)
	init_entry(mercury__pd_info__define_new_pred_5_0);
	init_label(mercury__pd_info__define_new_pred_5_0_i4);
	init_label(mercury__pd_info__define_new_pred_5_0_i3);
	init_label(mercury__pd_info__define_new_pred_5_0_i2);
	init_label(mercury__pd_info__define_new_pred_5_0_i5);
	init_label(mercury__pd_info__define_new_pred_5_0_i6);
	init_label(mercury__pd_info__define_new_pred_5_0_i7);
	init_label(mercury__pd_info__define_new_pred_5_0_i8);
	init_label(mercury__pd_info__define_new_pred_5_0_i9);
	init_label(mercury__pd_info__define_new_pred_5_0_i10);
	init_label(mercury__pd_info__define_new_pred_5_0_i11);
	init_label(mercury__pd_info__define_new_pred_5_0_i12);
	init_label(mercury__pd_info__define_new_pred_5_0_i13);
	init_label(mercury__pd_info__define_new_pred_5_0_i14);
	init_label(mercury__pd_info__define_new_pred_5_0_i15);
	init_label(mercury__pd_info__define_new_pred_5_0_i16);
	init_label(mercury__pd_info__define_new_pred_5_0_i17);
	init_label(mercury__pd_info__define_new_pred_5_0_i18);
	init_label(mercury__pd_info__define_new_pred_5_0_i19);
	init_label(mercury__pd_info__define_new_pred_5_0_i20);
	init_label(mercury__pd_info__define_new_pred_5_0_i21);
	init_label(mercury__pd_info__define_new_pred_5_0_i22);
	init_label(mercury__pd_info__define_new_pred_5_0_i23);
	init_label(mercury__pd_info__define_new_pred_5_0_i24);
	init_label(mercury__pd_info__define_new_pred_5_0_i25);
	init_label(mercury__pd_info__define_new_pred_5_0_i26);
BEGIN_CODE

/* code for predicate 'define_new_pred'/5 in mode 0 */
Define_entry(mercury__pd_info__define_new_pred_5_0);
	MR_incr_sp_push_msg(14, "pd_info:define_new_pred/5");
	MR_stackvar(14) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__define_new_pred_5_0_i3);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("pd_info_get_unfold_info: unfold_info not set.", 45);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pd_info__define_new_pred_5_0_i4,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r1 = MR_stackvar(4);
	GOTO_LABEL(mercury__pd_info__define_new_pred_5_0_i2);
Define_label(mercury__pd_info__define_new_pred_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = r2;
Define_label(mercury__pd_info__define_new_pred_5_0_i2);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__pd_info__define_new_pred_5_0_i5,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__pd_info__define_new_pred_5_0_i6,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 6);
	r2 = MR_stackvar(2);
	MR_stackvar(5) = r3;
	MR_stackvar(2) = r1;
	r1 = ((Integer) r3 + (Integer) 1);
	call_localret(STATIC(mercury__pd_info__pd_info_set_counter_3_0),
		mercury__pd_info__define_new_pred_5_0_i7,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	call_localret(STATIC(mercury__pd_info__pd_info_get_pred_info_3_0),
		mercury__pd_info__define_new_pred_5_0_i8,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__pd_info__define_new_pred_5_0_i9,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__pd_info__define_new_pred_5_0_i10,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__pd_info__define_new_pred_5_0_i11,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	call_localret(STATIC(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_info__define_new_pred_5_0_i12,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(8) = r1;
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__pd_info__define_new_pred_5_0_i13,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = (Word) MR_string_const("DeforestationIn", 15);
	r3 = (Integer) 0;
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(5);
	call_localret(ENTRY(mercury__prog_util__make_pred_name_with_context_7_0),
		mercury__pd_info__define_new_pred_5_0_i14,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__pd_info__define_new_pred_5_0_i15,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i15);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(9);
	call_localret(STATIC(mercury__pd_info__pd_info_get_proc_info_3_0),
		mercury__pd_info__define_new_pred_5_0_i16,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(13) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_typevarset_2_0),
		mercury__pd_info__define_new_pred_5_0_i17,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__pd_info__define_new_pred_5_0_i18,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i18);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_class_context_2_0),
		mercury__pd_info__define_new_pred_5_0_i19,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i19);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_aditi_owner_2_0),
		mercury__pd_info__define_new_pred_5_0_i20,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i20);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__pd_info__define_new_pred_5_0_i21,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i21);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__pd_info__define_new_pred_5_0_i22,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i22);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeinfo_varmap_2_0),
		mercury__pd_info__define_new_pred_5_0_i23,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i23);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_typeclass_info_varmap_2_0),
		mercury__pd_info__define_new_pred_5_0_i24,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i24);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r9 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(12);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(5);
	r10 = MR_stackvar(11);
	r11 = MR_stackvar(9);
	r12 = MR_stackvar(10);
	r13 = (Integer) 1;
	r14 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__define_new_pred_18_0),
		mercury__pd_info__define_new_pred_5_0_i25,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i25);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	MR_stackvar(2) = r1;
	r1 = r3;
	r2 = MR_stackvar(13);
	MR_stackvar(1) = r4;
	call_localret(STATIC(mercury__pd_info__pd_info_set_module_info_3_0),
		mercury__pd_info__define_new_pred_5_0_i26,
		ENTRY(mercury__pd_info__define_new_pred_5_0));
Define_label(mercury__pd_info__define_new_pred_5_0_i26);
	update_prof_current_proc(LABEL(mercury__pd_info__define_new_pred_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__pd_debug__register_version_4_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__map__set_4_1);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__set__insert_3_1);

BEGIN_MODULE(pd_info_module63)
	init_entry(mercury__pd_info__register_version_4_0);
	init_label(mercury__pd_info__register_version_4_0_i2);
	init_label(mercury__pd_info__register_version_4_0_i3);
	init_label(mercury__pd_info__register_version_4_0_i5);
	init_label(mercury__pd_info__register_version_4_0_i4);
	init_label(mercury__pd_info__register_version_4_0_i8);
	init_label(mercury__pd_info__register_version_4_0_i10);
	init_label(mercury__pd_info__register_version_4_0_i11);
	init_label(mercury__pd_info__register_version_4_0_i12);
	init_label(mercury__pd_info__register_version_4_0_i13);
	init_label(mercury__pd_info__register_version_4_0_i14);
BEGIN_CODE

/* code for predicate 'register_version'/4 in mode 0 */
Define_entry(mercury__pd_info__register_version_4_0);
	MR_incr_sp_push_msg(7, "pd_info:register_version/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__pd_debug__register_version_4_0),
		mercury__pd_info__register_version_4_0_i2,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(5) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	call_localret(ENTRY(mercury__pd_util__goal_get_calls_2_0),
		mercury__pd_info__register_version_4_0_i3,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	r4 = r1;
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__pd_info__register_version_4_0_i5,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__register_version_4_0_i4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__pd_info__register_version_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__pd_info__register_version_4_0_i8,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__pd_info__register_version_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__pd_info__register_version_4_0_i8,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 14, mercury__pd_info__register_version_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	call_localret(STATIC(mercury__pd_info__pd_info_get_versions_3_0),
		mercury__pd_info__register_version_4_0_i10,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	r3 = r1;
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__pd_info__register_version_4_0_i11,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i11);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__pd_info__pd_info_set_versions_3_0),
		mercury__pd_info__register_version_4_0_i12,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	call_localret(STATIC(mercury__pd_info__pd_info_get_created_versions_3_0),
		mercury__pd_info__register_version_4_0_i13,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	MR_stackvar(6) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__pd_info__register_version_4_0_i14,
		ENTRY(mercury__pd_info__register_version_4_0));
Define_label(mercury__pd_info__register_version_4_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_info__register_version_4_0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__pd_info__pd_info_set_created_versions_3_0),
		ENTRY(mercury__pd_info__register_version_4_0));
END_MODULE

Declare_entry(mercury__list__last_2_0);

BEGIN_MODULE(pd_info_module64)
	init_entry(mercury__pd_info__invalidate_version_3_0);
	init_label(mercury__pd_info__invalidate_version_3_0_i2);
	init_label(mercury__pd_info__invalidate_version_3_0_i3);
	init_label(mercury__pd_info__invalidate_version_3_0_i7);
	init_label(mercury__pd_info__invalidate_version_3_0_i9);
	init_label(mercury__pd_info__invalidate_version_3_0_i5);
BEGIN_CODE

/* code for predicate 'invalidate_version'/3 in mode 0 */
Define_entry(mercury__pd_info__invalidate_version_3_0);
	MR_incr_sp_push_msg(4, "pd_info:invalidate_version/3");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__pd_info__invalidate_version_3_0_i2,
		ENTRY(mercury__pd_info__invalidate_version_3_0));
Define_label(mercury__pd_info__invalidate_version_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__invalidate_version_3_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__pd_util__goal_get_calls_2_0),
		mercury__pd_info__invalidate_version_3_0_i3,
		ENTRY(mercury__pd_info__invalidate_version_3_0));
Define_label(mercury__pd_info__invalidate_version_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__invalidate_version_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__invalidate_version_3_0_i5);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__list__last_2_0),
		mercury__pd_info__invalidate_version_3_0_i7,
		ENTRY(mercury__pd_info__invalidate_version_3_0));
Define_label(mercury__pd_info__invalidate_version_3_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__invalidate_version_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__invalidate_version_3_0_i5);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__pd_info__invalidate_version_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__pd_info__invalidate_version_3_0_i9,
		ENTRY(mercury__pd_info__invalidate_version_3_0));
Define_label(mercury__pd_info__invalidate_version_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_info__invalidate_version_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 14, mercury__pd_info__invalidate_version_3_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 12);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 8);
	MR_field(MR_mktag(0), r2, (Integer) 11) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__pd_info__remove_version_3_0),
		ENTRY(mercury__pd_info__invalidate_version_3_0));
	}
Define_label(mercury__pd_info__invalidate_version_3_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__pd_info__remove_version_3_0),
		ENTRY(mercury__pd_info__invalidate_version_3_0));
END_MODULE

Declare_entry(mercury__map__delete_3_1);
Declare_entry(mercury__list__delete_all_3_1);
Declare_entry(mercury__set__delete_3_0);
Declare_entry(mercury__hlds_module__module_info_remove_predicate_3_0);

BEGIN_MODULE(pd_info_module65)
	init_entry(mercury__pd_info__remove_version_3_0);
	init_label(mercury__pd_info__remove_version_3_0_i2);
	init_label(mercury__pd_info__remove_version_3_0_i3);
	init_label(mercury__pd_info__remove_version_3_0_i4);
	init_label(mercury__pd_info__remove_version_3_0_i5);
	init_label(mercury__pd_info__remove_version_3_0_i7);
	init_label(mercury__pd_info__remove_version_3_0_i9);
	init_label(mercury__pd_info__remove_version_3_0_i10);
	init_label(mercury__pd_info__remove_version_3_0_i6);
	init_label(mercury__pd_info__remove_version_3_0_i12);
	init_label(mercury__pd_info__remove_version_3_0_i13);
	init_label(mercury__pd_info__remove_version_3_0_i14);
	init_label(mercury__pd_info__remove_version_3_0_i15);
	init_label(mercury__pd_info__remove_version_3_0_i16);
	init_label(mercury__pd_info__remove_version_3_0_i17);
BEGIN_CODE

/* code for predicate 'remove_version'/3 in mode 0 */
Define_entry(mercury__pd_info__remove_version_3_0);
	MR_incr_sp_push_msg(5, "pd_info:remove_version/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(3) = r3;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__pd_info__remove_version_3_0_i2,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i2);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__pd_util__goal_get_calls_2_0),
		mercury__pd_info__remove_version_3_0_i3,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i3);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__pd_info__remove_version_3_0_i4,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 14, mercury__pd_info__remove_version_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 4) = r1;
	r1 = r2;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r2, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	call_localret(STATIC(mercury__pd_info__pd_info_get_goal_version_index_3_0),
		mercury__pd_info__remove_version_3_0_i5,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r3 = r1;
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__pd_info__remove_version_3_0_i7,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__remove_version_3_0_i6);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__pd_info__remove_version_3_0_i9,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__pd_info__remove_version_3_0_i10,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__pd_info__pd_info_set_goal_version_index_3_0),
		mercury__pd_info__remove_version_3_0_i12,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i6);
	r1 = MR_stackvar(4);
Define_label(mercury__pd_info__remove_version_3_0_i12);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	call_localret(STATIC(mercury__pd_info__pd_info_get_created_versions_3_0),
		mercury__pd_info__remove_version_3_0_i13,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__pd_info__remove_version_3_0_i14,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__pd_info__pd_info_set_created_versions_3_0),
		mercury__pd_info__remove_version_3_0_i15,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i15);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	call_localret(STATIC(mercury__pd_info__pd_info_get_module_info_3_0),
		mercury__pd_info__remove_version_3_0_i16,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	MR_stackvar(2) = r2;
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_remove_predicate_3_0),
		mercury__pd_info__remove_version_3_0_i17,
		ENTRY(mercury__pd_info__remove_version_3_0));
Define_label(mercury__pd_info__remove_version_3_0_i17);
	update_prof_current_proc(LABEL(mercury__pd_info__remove_version_3_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__pd_info__pd_info_set_module_info_3_0),
		ENTRY(mercury__pd_info__remove_version_3_0));
END_MODULE

Declare_entry(mercury__pd_util__goals_match_8_0);

BEGIN_MODULE(pd_info_module66)
	init_entry(mercury__pd_info__get_matching_version_7_0);
	init_label(mercury__pd_info__get_matching_version_7_0_i1005);
	init_label(mercury__pd_info__get_matching_version_7_0_i3);
	init_label(mercury__pd_info__get_matching_version_7_0_i4);
	init_label(mercury__pd_info__get_matching_version_7_0_i6);
	init_label(mercury__pd_info__get_matching_version_7_0_i8);
	init_label(mercury__pd_info__get_matching_version_7_0_i9);
	init_label(mercury__pd_info__get_matching_version_7_0_i10);
	init_label(mercury__pd_info__get_matching_version_7_0_i13);
	init_label(mercury__pd_info__get_matching_version_7_0_i14);
	init_label(mercury__pd_info__get_matching_version_7_0_i16);
	init_label(mercury__pd_info__get_matching_version_7_0_i5);
	init_label(mercury__pd_info__get_matching_version_7_0_i1);
BEGIN_CODE

/* code for predicate 'get_matching_version'/7 in mode 0 */
Define_static(mercury__pd_info__get_matching_version_7_0);
	MR_incr_sp_push_msg(12, "pd_info:get_matching_version/7");
	MR_stackvar(12) = (Word) MR_succip;
Define_label(mercury__pd_info__get_matching_version_7_0_i1005);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__pd_info__get_matching_version_7_0_i3);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r4 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(6) = r4;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	r3 = r6;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__pd_info__get_matching_version_7_0_i4,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(9) = r2;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(8) = r1;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(4);
	call_localret(ENTRY(mercury__pd_util__goals_match_8_0),
		mercury__pd_info__get_matching_version_7_0_i6,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i5);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 1);
	MR_stackvar(9) = r2;
	MR_stackvar(11) = r3;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__pd_info__get_matching_version_7_0_i8,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i8);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__pd_info__get_matching_version_7_0_i9,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i9);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(3);
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__pd_info__check_insts_7_0),
		mercury__pd_info__get_matching_version_7_0_i10,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i10);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 5, mercury__pd_info__get_matching_version_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(1), r3, (Integer) 3) = MR_stackvar(9);
	MR_field(MR_mktag(1), r3, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i13);
	r2 = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__pd_info__get_matching_version_7_0_i13);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r3, (Integer) 3);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(5);
	localcall(mercury__pd_info__get_matching_version_7_0,
		LABEL(mercury__pd_info__get_matching_version_7_0_i14),
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i14);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i1);
	r5 = r2;
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(9);
	call_localret(STATIC(mercury__pd_info__pick_version__ua0_7_0),
		mercury__pd_info__get_matching_version_7_0_i16,
		STATIC(mercury__pd_info__get_matching_version_7_0));
Define_label(mercury__pd_info__get_matching_version_7_0_i16);
	update_prof_current_proc(LABEL(mercury__pd_info__get_matching_version_7_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__pd_info__get_matching_version_7_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__pd_info__get_matching_version_7_0_i1005);
Define_label(mercury__pd_info__get_matching_version_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__inst_match__inst_matches_initial_3_0);

BEGIN_MODULE(pd_info_module67)
	init_entry(mercury__pd_info__check_insts_7_0);
	init_label(mercury__pd_info__check_insts_7_0_i1004);
	init_label(mercury__pd_info__check_insts_7_0_i3);
	init_label(mercury__pd_info__check_insts_7_0_i4);
	init_label(mercury__pd_info__check_insts_7_0_i5);
	init_label(mercury__pd_info__check_insts_7_0_i6);
	init_label(mercury__pd_info__check_insts_7_0_i7);
	init_label(mercury__pd_info__check_insts_7_0_i13);
	init_label(mercury__pd_info__check_insts_7_0_i9);
	init_label(mercury__pd_info__check_insts_7_0_i1);
BEGIN_CODE

/* code for predicate 'check_insts'/7 in mode 0 */
Define_static(mercury__pd_info__check_insts_7_0);
	MR_incr_sp_push_msg(9, "pd_info:check_insts/7");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__pd_info__check_insts_7_0_i1004);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pd_info__check_insts_7_0_i3);
	r2 = r6;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__pd_info__check_insts_7_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(6) = r2;
	r1 = r4;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__pd_info__check_insts_7_0_i4,
		STATIC(mercury__pd_info__check_insts_7_0));
Define_label(mercury__pd_info__check_insts_7_0_i4);
	update_prof_current_proc(LABEL(mercury__pd_info__check_insts_7_0));
	r4 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__pd_info__check_insts_7_0_i5,
		STATIC(mercury__pd_info__check_insts_7_0));
Define_label(mercury__pd_info__check_insts_7_0_i5);
	update_prof_current_proc(LABEL(mercury__pd_info__check_insts_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__pd_info__check_insts_7_0_i6,
		STATIC(mercury__pd_info__check_insts_7_0));
Define_label(mercury__pd_info__check_insts_7_0_i6);
	update_prof_current_proc(LABEL(mercury__pd_info__check_insts_7_0));
	MR_stackvar(8) = r1;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_matches_initial_3_0),
		mercury__pd_info__check_insts_7_0_i7,
		STATIC(mercury__pd_info__check_insts_7_0));
Define_label(mercury__pd_info__check_insts_7_0_i7);
	update_prof_current_proc(LABEL(mercury__pd_info__check_insts_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__check_insts_7_0_i1);
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__pd_info__check_insts_7_0_i9);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_matches_initial_3_0),
		mercury__pd_info__check_insts_7_0_i13,
		STATIC(mercury__pd_info__check_insts_7_0));
Define_label(mercury__pd_info__check_insts_7_0_i13);
	update_prof_current_proc(LABEL(mercury__pd_info__check_insts_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__pd_info__check_insts_7_0_i9);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r2 = MR_stackvar(7);
	r6 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__pd_info__check_insts_7_0_i1004);
Define_label(mercury__pd_info__check_insts_7_0_i9);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r2 = MR_stackvar(7);
	r6 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__pd_info__check_insts_7_0_i1004);
Define_label(mercury__pd_info__check_insts_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___io__state_0_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___pd_term__global_term_info_0_0);
Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(pd_info_module68)
	init_entry(mercury____Unify___pd_info__pd_info_0_0);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i2);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i4);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i6);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i8);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i10);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i12);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i14);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i16);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i18);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i20);
	init_label(mercury____Unify___pd_info__pd_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__pd_info_0_0);
	MR_incr_sp_push_msg(27, "pd_info:__Unify__/2");
	MR_stackvar(27) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___io__state_0_0),
		mercury____Unify___pd_info__pd_info_0_0_i2,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___pd_info__pd_info_0_0_i4,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_unfold_info_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___pd_info__pd_info_0_0_i6,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___pd_info__pd_info_0_0_i8,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(17);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___pd_info__pd_info_0_0_i10,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___pd_info__pd_info_0_0_i12,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	if ((MR_stackvar(6) != MR_stackvar(19)))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Unify___pd_term__global_term_info_0_0),
		mercury____Unify___pd_info__pd_info_0_0_i14,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__pd_info_0_0_i16,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	if ((MR_stackvar(9) != MR_stackvar(22)))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__pd_info_0_0_i18,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_1);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__pd_info_0_0_i20,
		ENTRY(mercury____Unify___pd_info__pd_info_0_0));
Define_label(mercury____Unify___pd_info__pd_info_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	if ((MR_stackvar(12) != MR_stackvar(25)))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	if ((MR_stackvar(13) != MR_stackvar(26)))
		GOTO_LABEL(mercury____Unify___pd_info__pd_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___pd_info__pd_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module69)
	init_entry(mercury____Index___pd_info__pd_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__pd_info_0_0);
	tailcall(STATIC(mercury____Index___pd_info__pd_info_0__ua0_2_0),
		ENTRY(mercury____Index___pd_info__pd_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___io__state_0_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___pd_term__global_term_info_0_0);
Declare_entry(mercury____Compare___set__set_1_0);

BEGIN_MODULE(pd_info_module70)
	init_entry(mercury____Compare___pd_info__pd_info_0_0);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i3);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i7);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i11);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i15);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i19);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i23);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i27);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i31);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i35);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i39);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i43);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i47);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i51);
	init_label(mercury____Compare___pd_info__pd_info_0_0_i67);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__pd_info_0_0);
	MR_incr_sp_push_msg(27, "pd_info:__Compare__/3");
	MR_stackvar(27) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___io__state_0_0),
		mercury____Compare___pd_info__pd_info_0_0_i3,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___pd_info__pd_info_0_0_i7,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_unfold_info_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___pd_info__pd_info_0_0_i11,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___pd_info__pd_info_0_0_i15,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(17);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___pd_info__pd_info_0_0_i19,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___pd_info__pd_info_0_0_i23,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__pd_info_0_0_i27,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Compare___pd_term__global_term_info_0_0),
		mercury____Compare___pd_info__pd_info_0_0_i31,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__pd_info_0_0_i35,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(22);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__pd_info_0_0_i39,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__pd_info_0_0_i43,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_1);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__pd_info_0_0_i47,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__pd_info_0_0_i51,
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_info_0_0_i67);
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(26);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___pd_info__pd_info_0_0));
Define_label(mercury____Compare___pd_info__pd_info_0_0_i67);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module71)
	init_entry(mercury____Unify___pd_info__goal_version_index_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__goal_version_index_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___pd_info__goal_version_index_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(pd_info_module72)
	init_entry(mercury____Index___pd_info__goal_version_index_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__goal_version_index_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___pd_info__goal_version_index_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module73)
	init_entry(mercury____Compare___pd_info__goal_version_index_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__goal_version_index_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___pd_info__goal_version_index_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module74)
	init_entry(mercury____Unify___pd_info__version_index_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__version_index_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___pd_info__version_index_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module75)
	init_entry(mercury____Index___pd_info__version_index_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__version_index_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___pd_info__version_index_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module76)
	init_entry(mercury____Compare___pd_info__version_index_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__version_index_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_pd_info__type_ctor_info_version_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___pd_info__version_index_0_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_pred__proc_info_0_0);
Declare_entry(mercury____Unify___instmap__instmap_0_0);
Declare_entry(mercury____Unify___pd_term__local_term_info_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_info_0_0);
Declare_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);

BEGIN_MODULE(pd_info_module77)
	init_entry(mercury____Unify___pd_info__unfold_info_0_0);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i2);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i4);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i6);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i8);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i10);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i12);
	init_label(mercury____Unify___pd_info__unfold_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__unfold_info_0_0);
	MR_incr_sp_push_msg(19, "pd_info:__Unify__/2");
	MR_stackvar(19) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_info_0_0),
		mercury____Unify___pd_info__unfold_info_0_0_i2,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___instmap__instmap_0_0),
		mercury____Unify___pd_info__unfold_info_0_0_i4,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(11)))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___pd_term__local_term_info_0_0),
		mercury____Unify___pd_info__unfold_info_0_0_i6,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_info_0_0),
		mercury____Unify___pd_info__unfold_info_0_0_i8,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__unfold_info_0_0_i10,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___pd_info__unfold_info_0_0_i12,
		ENTRY(mercury____Unify___pd_info__unfold_info_0_0));
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__unfold_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	if ((MR_stackvar(7) != MR_stackvar(16)))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	if ((MR_stackvar(8) != MR_stackvar(17)))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	if ((MR_stackvar(9) != MR_stackvar(18)))
		GOTO_LABEL(mercury____Unify___pd_info__unfold_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___pd_info__unfold_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module78)
	init_entry(mercury____Index___pd_info__unfold_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__unfold_info_0_0);
	tailcall(STATIC(mercury____Index___pd_info__unfold_info_0__ua0_2_0),
		ENTRY(mercury____Index___pd_info__unfold_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_pred__proc_info_0_0);
Declare_entry(mercury____Compare___instmap__instmap_0_0);
Declare_entry(mercury____Compare___pd_term__local_term_info_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_info_0_0);
Declare_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);

BEGIN_MODULE(pd_info_module79)
	init_entry(mercury____Compare___pd_info__unfold_info_0_0);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i3);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i7);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i11);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i15);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i19);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i23);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i27);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i31);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i35);
	init_label(mercury____Compare___pd_info__unfold_info_0_0_i47);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__unfold_info_0_0);
	MR_incr_sp_push_msg(19, "pd_info:__Compare__/3");
	MR_stackvar(19) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_pred__proc_info_0_0),
		mercury____Compare___pd_info__unfold_info_0_0_i3,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Compare___instmap__instmap_0_0),
		mercury____Compare___pd_info__unfold_info_0_0_i7,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__unfold_info_0_0_i11,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Compare___pd_term__local_term_info_0_0),
		mercury____Compare___pd_info__unfold_info_0_0_i15,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_info_0_0),
		mercury____Compare___pd_info__unfold_info_0_0_i19,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__unfold_info_0_0_i23,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___pd_info__unfold_info_0_0_i27,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(16);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__unfold_info_0_0_i31,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(17);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__unfold_info_0_0_i35,
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__unfold_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__unfold_info_0_0_i47);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(18);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___pd_info__unfold_info_0_0));
Define_label(mercury____Compare___pd_info__unfold_info_0_0_i47);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module80)
	init_entry(mercury____Unify___pd_info__pd_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__pd_arg_info_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___pd_info__pd_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module81)
	init_entry(mercury____Index___pd_info__pd_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__pd_arg_info_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___pd_info__pd_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module82)
	init_entry(mercury____Compare___pd_info__pd_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__pd_arg_info_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_4);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___pd_info__pd_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module83)
	init_entry(mercury____Unify___pd_info__pd_proc_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__pd_proc_arg_info_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(STATIC(mercury____Unify___pd_info__pd_branch_info_1_0),
		ENTRY(mercury____Unify___pd_info__pd_proc_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module84)
	init_entry(mercury____Index___pd_info__pd_proc_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__pd_proc_arg_info_0_0);
	tailcall(STATIC(mercury____Index___pd_info__pd_proc_arg_info_0__ua0_2_0),
		ENTRY(mercury____Index___pd_info__pd_proc_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module85)
	init_entry(mercury____Compare___pd_info__pd_proc_arg_info_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__pd_proc_arg_info_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(STATIC(mercury____Compare___pd_info__pd_branch_info_1_0),
		ENTRY(mercury____Compare___pd_info__pd_proc_arg_info_0_0));
END_MODULE


BEGIN_MODULE(pd_info_module86)
	init_entry(mercury____Unify___pd_info__pd_branch_info_1_0);
	init_label(mercury____Unify___pd_info__pd_branch_info_1_0_i2);
	init_label(mercury____Unify___pd_info__pd_branch_info_1_0_i4);
	init_label(mercury____Unify___pd_info__pd_branch_info_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__pd_branch_info_1_0);
	MR_incr_sp_push_msg(6, "pd_info:__Unify__/2");
	MR_stackvar(6) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___pd_info__pd_branch_info_1_0_i2,
		ENTRY(mercury____Unify___pd_info__pd_branch_info_1_0));
Define_label(mercury____Unify___pd_info__pd_branch_info_1_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_branch_info_1_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_branch_info_1_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__pd_branch_info_1_0_i4,
		ENTRY(mercury____Unify___pd_info__pd_branch_info_1_0));
Define_label(mercury____Unify___pd_info__pd_branch_info_1_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__pd_branch_info_1_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__pd_branch_info_1_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		ENTRY(mercury____Unify___pd_info__pd_branch_info_1_0));
Define_label(mercury____Unify___pd_info__pd_branch_info_1_0_i1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module87)
	init_entry(mercury____Index___pd_info__pd_branch_info_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__pd_branch_info_1_0);
	tailcall(STATIC(mercury____Index___pd_info__pd_branch_info_1__ua0_2_0),
		ENTRY(mercury____Index___pd_info__pd_branch_info_1_0));
END_MODULE


BEGIN_MODULE(pd_info_module88)
	init_entry(mercury____Compare___pd_info__pd_branch_info_1_0);
	init_label(mercury____Compare___pd_info__pd_branch_info_1_0_i3);
	init_label(mercury____Compare___pd_info__pd_branch_info_1_0_i7);
	init_label(mercury____Compare___pd_info__pd_branch_info_1_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__pd_branch_info_1_0);
	MR_incr_sp_push_msg(6, "pd_info:__Compare__/3");
	MR_stackvar(6) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___pd_info__pd_branch_info_1_0_i3,
		ENTRY(mercury____Compare___pd_info__pd_branch_info_1_0));
Define_label(mercury____Compare___pd_info__pd_branch_info_1_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_branch_info_1_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_branch_info_1_0_i12);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__pd_branch_info_1_0_i7,
		ENTRY(mercury____Compare___pd_info__pd_branch_info_1_0));
Define_label(mercury____Compare___pd_info__pd_branch_info_1_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__pd_branch_info_1_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__pd_branch_info_1_0_i12);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		ENTRY(mercury____Compare___pd_info__pd_branch_info_1_0));
Define_label(mercury____Compare___pd_info__pd_branch_info_1_0_i12);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module89)
	init_entry(mercury____Unify___pd_info__branch_info_map_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__branch_info_map_1_0);
	r4 = r3;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___pd_info__branch_info_map_1_0));
END_MODULE


BEGIN_MODULE(pd_info_module90)
	init_entry(mercury____Index___pd_info__branch_info_map_1_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__branch_info_map_1_0);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___pd_info__branch_info_map_1_0));
END_MODULE


BEGIN_MODULE(pd_info_module91)
	init_entry(mercury____Compare___pd_info__branch_info_map_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__branch_info_map_1_0);
	r4 = r3;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_5);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___pd_info__branch_info_map_1_0));
END_MODULE


BEGIN_MODULE(pd_info_module92)
	init_entry(mercury____Unify___pd_info__maybe_version_0_0);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i3);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i6);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i8);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i10);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i1009);
	init_label(mercury____Unify___pd_info__maybe_version_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__maybe_version_0_0);
	MR_incr_sp_push_msg(7, "pd_info:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1009);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != r3))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___pd_info__maybe_version_0_0_i6,
		ENTRY(mercury____Unify___pd_info__maybe_version_0_0));
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__maybe_version_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury____Unify___pd_info__version_info_0_0),
		mercury____Unify___pd_info__maybe_version_0_0_i8,
		ENTRY(mercury____Unify___pd_info__maybe_version_0_0));
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__maybe_version_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___pd_info__maybe_version_0_0_i10,
		ENTRY(mercury____Unify___pd_info__maybe_version_0_0));
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__maybe_version_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__maybe_version_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___pd_info__maybe_version_0_0));
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i1009);
	r1 = FALSE;
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___pd_info__maybe_version_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module93)
	init_entry(mercury____Index___pd_info__maybe_version_0_0);
	init_label(mercury____Index___pd_info__maybe_version_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__maybe_version_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___pd_info__maybe_version_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___pd_info__maybe_version_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(pd_info_module94)
	init_entry(mercury____Compare___pd_info__maybe_version_0_0);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i3);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i2);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i5);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i4);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i6);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i7);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i11);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i15);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i19);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i23);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i27);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i1018);
	init_label(mercury____Compare___pd_info__maybe_version_0_0_i38);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__maybe_version_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i2);
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i4);
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i1018);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i1018);
	MR_incr_sp_push_msg(9, "pd_info:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__maybe_version_0_0_i15,
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__maybe_version_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i38);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___pd_info__maybe_version_0_0_i19,
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__maybe_version_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i38);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury____Compare___pd_info__version_info_0_0),
		mercury____Compare___pd_info__maybe_version_0_0_i23,
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__maybe_version_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i38);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___pd_info__maybe_version_0_0_i27,
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__maybe_version_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__maybe_version_0_0_i38);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_6);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i1018);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___pd_info__maybe_version_0_0));
Define_label(mercury____Compare___pd_info__maybe_version_0_0_i38);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module95)
	init_entry(mercury____Unify___pd_info__version_is_exact_0_0);
	init_label(mercury____Unify___pd_info__version_is_exact_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__version_is_exact_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___pd_info__version_is_exact_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___pd_info__version_is_exact_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module96)
	init_entry(mercury____Index___pd_info__version_is_exact_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__version_is_exact_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module97)
	init_entry(mercury____Compare___pd_info__version_is_exact_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__version_is_exact_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___pd_info__version_is_exact_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(pd_info_module98)
	init_entry(mercury____Unify___pd_info__version_info_0_0);
	init_label(mercury____Unify___pd_info__version_info_0_0_i2);
	init_label(mercury____Unify___pd_info__version_info_0_0_i4);
	init_label(mercury____Unify___pd_info__version_info_0_0_i6);
	init_label(mercury____Unify___pd_info__version_info_0_0_i8);
	init_label(mercury____Unify___pd_info__version_info_0_0_i10);
	init_label(mercury____Unify___pd_info__version_info_0_0_i12);
	init_label(mercury____Unify___pd_info__version_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___pd_info__version_info_0_0);
	MR_incr_sp_push_msg(17, "pd_info:__Unify__/2");
	MR_stackvar(17) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___pd_info__version_info_0_0_i2,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___pd_info__version_info_0_0_i4,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___pd_info__version_info_0_0_i6,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___pd_info__version_info_0_0_i8,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___instmap__instmap_0_0),
		mercury____Unify___pd_info__version_info_0_0_i10,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(13)))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	if ((MR_stackvar(6) != MR_stackvar(14)))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___pd_info__version_info_0_0_i12,
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___pd_info__version_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pd_info__version_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(16);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___pd_info__version_info_0_0));
Define_label(mercury____Unify___pd_info__version_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pd_info_module99)
	init_entry(mercury____Index___pd_info__version_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___pd_info__version_info_0_0);
	tailcall(STATIC(mercury____Index___pd_info__version_info_0__ua0_2_0),
		ENTRY(mercury____Index___pd_info__version_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(pd_info_module100)
	init_entry(mercury____Compare___pd_info__version_info_0_0);
	init_label(mercury____Compare___pd_info__version_info_0_0_i3);
	init_label(mercury____Compare___pd_info__version_info_0_0_i7);
	init_label(mercury____Compare___pd_info__version_info_0_0_i11);
	init_label(mercury____Compare___pd_info__version_info_0_0_i15);
	init_label(mercury____Compare___pd_info__version_info_0_0_i19);
	init_label(mercury____Compare___pd_info__version_info_0_0_i23);
	init_label(mercury____Compare___pd_info__version_info_0_0_i27);
	init_label(mercury____Compare___pd_info__version_info_0_0_i31);
	init_label(mercury____Compare___pd_info__version_info_0_0_i42);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___pd_info__version_info_0_0);
	MR_incr_sp_push_msg(17, "pd_info:__Compare__/3");
	MR_stackvar(17) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___pd_info__version_info_0_0_i3,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___pd_info__version_info_0_0_i7,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_2);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___pd_info__version_info_0_0_i11,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pd_info__common_3);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___pd_info__version_info_0_0_i15,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Compare___instmap__instmap_0_0),
		mercury____Compare___pd_info__version_info_0_0_i19,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__version_info_0_0_i23,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___pd_info__version_info_0_0_i27,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(15);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___pd_info__version_info_0_0_i31,
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___pd_info__version_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pd_info__version_info_0_0_i42);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(16);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___pd_info__version_info_0_0));
Define_label(mercury____Compare___pd_info__version_info_0_0_i42);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__pd_info_maybe_bunch_0(void)
{
	pd_info_module0();
	pd_info_module1();
	pd_info_module2();
	pd_info_module3();
	pd_info_module4();
	pd_info_module5();
	pd_info_module6();
	pd_info_module7();
	pd_info_module8();
	pd_info_module9();
	pd_info_module10();
	pd_info_module11();
	pd_info_module12();
	pd_info_module13();
	pd_info_module14();
	pd_info_module15();
	pd_info_module16();
	pd_info_module17();
	pd_info_module18();
	pd_info_module19();
	pd_info_module20();
	pd_info_module21();
	pd_info_module22();
	pd_info_module23();
	pd_info_module24();
	pd_info_module25();
	pd_info_module26();
	pd_info_module27();
	pd_info_module28();
	pd_info_module29();
	pd_info_module30();
	pd_info_module31();
	pd_info_module32();
	pd_info_module33();
	pd_info_module34();
	pd_info_module35();
	pd_info_module36();
	pd_info_module37();
	pd_info_module38();
	pd_info_module39();
}

static void mercury__pd_info_maybe_bunch_1(void)
{
	pd_info_module40();
	pd_info_module41();
	pd_info_module42();
	pd_info_module43();
	pd_info_module44();
	pd_info_module45();
	pd_info_module46();
	pd_info_module47();
	pd_info_module48();
	pd_info_module49();
	pd_info_module50();
	pd_info_module51();
	pd_info_module52();
	pd_info_module53();
	pd_info_module54();
	pd_info_module55();
	pd_info_module56();
	pd_info_module57();
	pd_info_module58();
	pd_info_module59();
	pd_info_module60();
	pd_info_module61();
	pd_info_module62();
	pd_info_module63();
	pd_info_module64();
	pd_info_module65();
	pd_info_module66();
	pd_info_module67();
	pd_info_module68();
	pd_info_module69();
	pd_info_module70();
	pd_info_module71();
	pd_info_module72();
	pd_info_module73();
	pd_info_module74();
	pd_info_module75();
	pd_info_module76();
	pd_info_module77();
	pd_info_module78();
	pd_info_module79();
}

static void mercury__pd_info_maybe_bunch_2(void)
{
	pd_info_module80();
	pd_info_module81();
	pd_info_module82();
	pd_info_module83();
	pd_info_module84();
	pd_info_module85();
	pd_info_module86();
	pd_info_module87();
	pd_info_module88();
	pd_info_module89();
	pd_info_module90();
	pd_info_module91();
	pd_info_module92();
	pd_info_module93();
	pd_info_module94();
	pd_info_module95();
	pd_info_module96();
	pd_info_module97();
	pd_info_module98();
	pd_info_module99();
	pd_info_module100();
}

#endif

void mercury__pd_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__pd_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__pd_info_maybe_bunch_0();
		mercury__pd_info_maybe_bunch_1();
		mercury__pd_info_maybe_bunch_2();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_branch_info_map_1,
			pd_info__branch_info_map_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_goal_version_index_0,
			pd_info__goal_version_index_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_maybe_version_0,
			pd_info__maybe_version_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_pd_arg_info_0,
			pd_info__pd_arg_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_pd_branch_info_1,
			pd_info__pd_branch_info_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_pd_info_0,
			pd_info__pd_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_pd_proc_arg_info_0,
			pd_info__pd_proc_arg_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_unfold_info_0,
			pd_info__unfold_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_version_index_0,
			pd_info__version_index_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_version_info_0,
			pd_info__version_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pd_info__type_ctor_info_version_is_exact_0,
			pd_info__version_is_exact_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
