/*
** Automatically generated from `pragma_c_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__pragma_c_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___pragma_c_gen__c_arg_0__ua0_2_0);
Declare_static(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i2);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i3);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i4);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i5);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i6);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i7);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i8);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i9);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i10);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i11);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i12);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i13);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i14);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i15);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i16);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i17);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i18);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1029);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i20);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1034);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i22);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i23);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i24);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i25);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i26);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i27);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i28);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i29);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i31);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i33);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i34);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i36);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1047);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i39);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i41);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i42);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i44);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i48);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i52);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i54);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1057);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i45);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i46);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i55);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i56);
Declare_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i57);
Declare_static(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0);
Declare_label(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0_i3);
Declare_static(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0);
Declare_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i10);
Declare_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i11);
Declare_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i6);
Declare_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i9);
Declare_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i2);
Declare_static(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0);
Declare_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0_i2);
Declare_static(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0);
Declare_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0_i1);
Define_extern_entry(mercury__pragma_c_gen__generate_pragma_c_code_12_0);
Define_extern_entry(mercury__pragma_c_gen__struct_name_5_0);
Declare_label(mercury__pragma_c_gen__struct_name_5_0_i2);
Declare_label(mercury__pragma_c_gen__struct_name_5_0_i3);
Declare_label(mercury__pragma_c_gen__struct_name_5_0_i4);
Declare_label(mercury__pragma_c_gen__struct_name_5_0_i5);
Declare_label(mercury__pragma_c_gen__struct_name_5_0_i6);
Declare_static(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i2);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i3);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i4);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i5);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i6);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i7);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i9);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i10);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i11);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i12);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i14);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i17);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i15);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i19);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i20);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i21);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i22);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i23);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i24);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i26);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i27);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i29);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i30);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i31);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i32);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1064);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i34);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i37);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i35);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i38);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i39);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i41);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i44);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i45);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i46);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1071);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i50);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i51);
Declare_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1107);
Declare_static(mercury__pragma_c_gen__make_proc_label_hash_define_5_0);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i2);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i5);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i3);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i8);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i6);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i11);
Declare_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12);
Declare_static(mercury__pragma_c_gen__make_c_arg_list_5_0);
Declare_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
Declare_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i13);
Declare_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i14);
Declare_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
Declare_static(mercury__pragma_c_gen__get_c_arg_list_vars_2_0);
Declare_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i4);
Declare_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i5);
Declare_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i2);
Declare_static(mercury__pragma_c_gen__make_pragma_decls_2_0);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i1003);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i8);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i10);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i4);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i5);
Declare_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i3);
Declare_static(mercury__pragma_c_gen__get_pragma_input_vars_5_0);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i1003);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i8);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i10);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i11);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i4);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i5);
Declare_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i3);
Declare_static(mercury__pragma_c_gen__pragma_acquire_regs_4_0);
Declare_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i4);
Declare_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i5);
Declare_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i3);
Declare_static(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i5);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i6);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i3);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i9);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i10);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i11);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i16);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i12);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i8);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i19);
Declare_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i2);
Declare_static(mercury__pragma_c_gen__input_descs_from_arg_info_2_0);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i1003);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i8);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i10);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i4);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i5);
Declare_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i3);
Declare_static(mercury__pragma_c_gen__output_descs_from_arg_info_2_0);
Declare_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i4);
Declare_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i9);
Declare_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i5);
Declare_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i3);
Declare_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i2);
Declare_static(mercury____Unify___pragma_c_gen__c_arg_0_0);
Declare_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i2);
Declare_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i4);
Declare_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i6);
Declare_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
Declare_static(mercury____Index___pragma_c_gen__c_arg_0_0);
Declare_static(mercury____Compare___pragma_c_gen__c_arg_0_0);
Declare_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i3);
Declare_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i7);
Declare_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i11);
Declare_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);

const struct MR_TypeCtorInfo_struct mercury_data_pragma_c_gen__type_ctor_info_c_arg_0;

static const struct mercury_data_pragma_c_gen__common_0_struct {
	Word * f1;
}  mercury_data_pragma_c_gen__common_0;

static const struct mercury_data_pragma_c_gen__common_1_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_pragma_c_gen__common_1;

static const struct mercury_data_pragma_c_gen__common_2_struct {
	Word * f1;
}  mercury_data_pragma_c_gen__common_2;

static const struct mercury_data_pragma_c_gen__common_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_3;

static const struct mercury_data_pragma_c_gen__common_4_struct {
	Word * f1;
}  mercury_data_pragma_c_gen__common_4;

static const struct mercury_data_pragma_c_gen__common_5_struct {
	Word * f1;
}  mercury_data_pragma_c_gen__common_5;

static const struct mercury_data_pragma_c_gen__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_pragma_c_gen__common_6;

static const struct mercury_data_pragma_c_gen__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_pragma_c_gen__common_7;

static const struct mercury_data_pragma_c_gen__common_8_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_8;

static const struct mercury_data_pragma_c_gen__common_9_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_9;

static const struct mercury_data_pragma_c_gen__common_10_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_10;

static const struct mercury_data_pragma_c_gen__common_11_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_11;

static const struct mercury_data_pragma_c_gen__common_12_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_12;

static const struct mercury_data_pragma_c_gen__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_13;

static const struct mercury_data_pragma_c_gen__common_14_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_14;

static const struct mercury_data_pragma_c_gen__common_15_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_15;

static const struct mercury_data_pragma_c_gen__common_16_struct {
	String f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_16;

static const struct mercury_data_pragma_c_gen__common_17_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_17;

static const struct mercury_data_pragma_c_gen__common_18_struct {
	String f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_18;

static const struct mercury_data_pragma_c_gen__common_19_struct {
	Integer f1;
	String f2;
}  mercury_data_pragma_c_gen__common_19;

static const struct mercury_data_pragma_c_gen__common_20_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_20;

static const struct mercury_data_pragma_c_gen__common_21_struct {
	Word * f1;
	Word * f2;
}  mercury_data_pragma_c_gen__common_21;

static const struct mercury_data_pragma_c_gen__common_22_struct {
	Word * f1;
}  mercury_data_pragma_c_gen__common_22;

static const struct mercury_data_pragma_c_gen__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_pragma_c_gen__common_23;

static const struct mercury_data_pragma_c_gen__type_ctor_functors_c_arg_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_pragma_c_gen__type_ctor_functors_c_arg_0;

static const struct mercury_data_pragma_c_gen__type_ctor_layout_c_arg_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_pragma_c_gen__type_ctor_layout_c_arg_0;

const struct MR_TypeCtorInfo_struct mercury_data_pragma_c_gen__type_ctor_info_c_arg_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___pragma_c_gen__c_arg_0_0),
	STATIC(mercury____Index___pragma_c_gen__c_arg_0_0),
	STATIC(mercury____Compare___pragma_c_gen__c_arg_0_0),
	(Integer) 2,
	(Word *) &mercury_data_pragma_c_gen__type_ctor_functors_c_arg_0,
	(Word *) &mercury_data_pragma_c_gen__type_ctor_layout_c_arg_0,
	MR_string_const("pragma_c_gen", 12),
	MR_string_const("c_arg", 5),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_code_model_0;
static const struct mercury_data_pragma_c_gen__common_0_struct mercury_data_pragma_c_gen__common_0 = {
	(Word *) &mercury_data_llds__type_ctor_info_code_model_0
};

static const struct mercury_data_pragma_c_gen__common_1_struct mercury_data_pragma_c_gen__common_1 = {
	(Integer) 0,
	MR_string_const("pragma_c_gen", 12),
	MR_string_const("pragma_c_gen", 12),
	MR_string_const("IntroducedFrom__pred__nondet_pragma_c_code__564__1", 50),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_0)
};

static const struct mercury_data_pragma_c_gen__common_2_struct mercury_data_pragma_c_gen__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))
};

static const struct mercury_data_pragma_c_gen__common_3_struct mercury_data_pragma_c_gen__common_3 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_pragma_c_gen__common_4_struct mercury_data_pragma_c_gen__common_4 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_pragma_c_gen__common_5_struct mercury_data_pragma_c_gen__common_5 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_pragma_c_gen__common_6_struct mercury_data_pragma_c_gen__common_6 = {
	(Integer) 0,
	MR_string_const("pragma_c_gen", 12),
	MR_string_const("pragma_c_gen", 12),
	MR_string_const("IntroducedFrom__pred__nondet_pragma_c_code__720__2", 50),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_5)
};

static const struct mercury_data_pragma_c_gen__common_7_struct mercury_data_pragma_c_gen__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_6),
	STATIC(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0),
	(Integer) 0
};

static const struct mercury_data_pragma_c_gen__common_8_struct mercury_data_pragma_c_gen__common_8 = {
	(Integer) 1,
	MR_string_const("#define\tSUCCEED     \tgoto MR_shared_success\n", 44)
};

static const struct mercury_data_pragma_c_gen__common_9_struct mercury_data_pragma_c_gen__common_9 = {
	(Integer) 1,
	MR_string_const("#define\tSUCCEED_LAST\tgoto MR_shared_success_last\n", 49)
};

static const struct mercury_data_pragma_c_gen__common_10_struct mercury_data_pragma_c_gen__common_10 = {
	(Integer) 1,
	MR_string_const("#define\tFAIL\tMR_fail()\n", 23)
};

static const struct mercury_data_pragma_c_gen__common_11_struct mercury_data_pragma_c_gen__common_11 = {
	(Integer) 1,
	MR_string_const("MR_shared_success:\n", 19)
};

static const struct mercury_data_pragma_c_gen__common_12_struct mercury_data_pragma_c_gen__common_12 = {
	(Integer) 1,
	MR_string_const("MR_shared_success_last:\n", 24)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_pragma_c_gen__common_13_struct mercury_data_pragma_c_gen__common_13 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_pragma_c_gen__common_14_struct mercury_data_pragma_c_gen__common_14 = {
	(Integer) 1,
	MR_string_const("", 0)
};

static const struct mercury_data_pragma_c_gen__common_15_struct mercury_data_pragma_c_gen__common_15 = {
	(Integer) 1,
	MR_string_const("\tsave_registers();\n", 19)
};

static const struct mercury_data_pragma_c_gen__common_16_struct mercury_data_pragma_c_gen__common_16 = {
	MR_string_const("\");\n", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_pragma_c_gen__common_17_struct mercury_data_pragma_c_gen__common_17 = {
	(Integer) 1,
	MR_string_const("#ifndef CONSERVATIVE_GC\n\trestore_registers();\n#endif\n", 53)
};

static const struct mercury_data_pragma_c_gen__common_18_struct mercury_data_pragma_c_gen__common_18 = {
	MR_string_const("\n", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_pragma_c_gen__common_19_struct mercury_data_pragma_c_gen__common_19 = {
	(Integer) 1,
	MR_string_const("#undef MR_PROC_LABEL\n", 21)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_pragma_c_gen__common_20_struct mercury_data_pragma_c_gen__common_20 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_pragma_c_gen__common_21_struct mercury_data_pragma_c_gen__common_21 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_arg_info_0;
static const struct mercury_data_pragma_c_gen__common_22_struct mercury_data_pragma_c_gen__common_22 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_arg_info_0
};

static const struct mercury_data_pragma_c_gen__common_23_struct mercury_data_pragma_c_gen__common_23 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_22),
	MR_string_const("c_arg", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_pragma_c_gen__type_ctor_functors_c_arg_0_struct mercury_data_pragma_c_gen__type_ctor_functors_c_arg_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_23)
};

static const struct mercury_data_pragma_c_gen__type_ctor_layout_c_arg_0_struct mercury_data_pragma_c_gen__type_ctor_layout_c_arg_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_pragma_c_gen__common_23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(pragma_c_gen_module0)
	init_entry(mercury____Index___pragma_c_gen__c_arg_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___pragma_c_gen__c_arg_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___pragma_c_gen__c_arg_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__require__require_2_0);
Declare_entry(mercury__prog_data__may_call_mercury_2_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__code_info__get_pred_id_3_0);
Declare_entry(mercury__code_info__get_proc_id_3_0);
Declare_entry(mercury__code_info__get_pred_proc_arginfo_5_0);
Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__string__format_3_0);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__globals__lookup_bool_option_3_0);
Declare_entry(mercury__code_info__maybe_save_hp_5_0);
Declare_entry(mercury__code_info__maybe_restore_hp_4_0);
Declare_entry(mercury__code_info__maybe_save_ticket_5_0);
Declare_entry(mercury__code_info__maybe_reset_ticket_5_0);
Declare_entry(mercury__trace__maybe_generate_pragma_event_code_5_0);
Declare_entry(mercury__term__context_init_1_0);
Declare_entry(mercury__hlds_pred__pred_info_requested_no_inlining_1_0);
Declare_entry(mercury__string__foldl_4_0);
Declare_entry(mercury__llds_out__get_label_3_0);

BEGIN_MODULE(pragma_c_gen_module1)
	init_entry(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i2);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i3);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i4);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i5);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i6);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i7);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i8);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i9);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i10);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i11);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i12);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i13);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i14);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i15);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i16);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i17);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i18);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1029);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i20);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1034);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i22);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i23);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i24);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i25);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i26);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i27);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i28);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i29);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i31);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i33);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i34);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i36);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1047);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i39);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i41);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i42);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i44);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i48);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i52);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i54);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1057);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i45);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i46);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i55);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i56);
	init_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i57);
BEGIN_CODE

/* code for predicate 'nondet_pragma_c_code__ua0'/19 in mode 0 */
Define_static(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0);
	MR_incr_sp_push_msg(40, "pragma_c_gen:nondet_pragma_c_code__ua0/19");
	MR_stackvar(40) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 5, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	r1 = MR_tempr1;
	MR_stackvar(1) = r2;
	r2 = (Word) MR_string_const("inappropriate code model for nondet pragma C code", 49);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r12;
	MR_stackvar(12) = r13;
	MR_stackvar(13) = r14;
	MR_stackvar(14) = r15;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = (Integer) 2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_1);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i2,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i2);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_data__may_call_mercury_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i3,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i3);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	MR_stackvar(14) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i4,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i4);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i5,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i5);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(15) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i6,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i6);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(15);
	MR_stackvar(15) = MR_tempr1;
	r3 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i7,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i7);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r3 = MR_stackvar(15);
	MR_stackvar(15) = r1;
	MR_stackvar(16) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i8,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i8);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r4 = r1;
	MR_stackvar(19) = r2;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__pragma_c_gen__make_c_arg_list_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i9,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i9);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(4) = r1;
	call_localret(STATIC(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i10,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	call_localret(STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i11,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i11);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i12,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i12);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__pragma_c_gen__input_descs_from_arg_info_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i13,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i13);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(STATIC(mercury__pragma_c_gen__output_descs_from_arg_info_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i14,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i14);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i15,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i15);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i16,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i16);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i17,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i17);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i18,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i18);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r3 = r1;
	r1 = MR_stackvar(17);
	r2 = MR_stackvar(18);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__pragma_c_gen__struct_name_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1029,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1029);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_string_const("LOCALS", 6);
	r3 = r1;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	r1 = (Word) MR_string_const("\tLOCALS = (struct %s *) ((char *)\n\t\t(MR_curfr + 1 - MR_ORDINARY_SLOTS - MR_NONDET_FIXED_SIZE)\n\t\t- sizeof(struct %s));\n", 118);
	MR_stackvar(3) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i20,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i20);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(19);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1034,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1034);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	tag_incr_hp_msg(MR_stackvar(18), MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_3);
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Set up backtracking to retry label", 34);
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(MR_stackvar(19), MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(19), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Start of the retry block", 24);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i22,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i22);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(21) = r2;
	r2 = (Integer) 121;
	MR_stackvar(20) = r1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i23,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i23);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = MR_stackvar(21);
	call_localret(ENTRY(mercury__code_info__maybe_save_hp_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i24,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i24);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(21) = r1;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__maybe_restore_hp_4_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i25,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i25);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r3 = r1;
	r1 = MR_stackvar(20);
	MR_stackvar(20) = r3;
	MR_stackvar(22) = r2;
	r2 = (Integer) 92;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i26,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i26);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = MR_stackvar(22);
	call_localret(ENTRY(mercury__code_info__maybe_save_ticket_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i27,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i27);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(22) = r1;
	r1 = r2;
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__maybe_reset_ticket_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i28,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i28);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	if (((Integer) MR_stackvar(8) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i29);
	r3 = r2;
	MR_stackvar(23) = r1;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(8), (Integer) 0);
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i33,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i29);
	MR_stackvar(23) = r1;
	MR_stackvar(24) = r2;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i31,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i31);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	r1 = (Integer) 0;
	r3 = MR_stackvar(24);
	call_localret(ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i33,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i33);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	if (((Integer) MR_stackvar(10) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i34);
	r3 = r2;
	MR_stackvar(24) = r1;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(10), (Integer) 0);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1047,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i34);
	MR_stackvar(24) = r1;
	MR_stackvar(25) = r2;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i36,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i36);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	r1 = (Integer) 1;
	r3 = MR_stackvar(25);
	call_localret(ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1047,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1047);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(20);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(23);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(21);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(22);
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	if (((Integer) MR_stackvar(14) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i39);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(20) = r3;
	MR_stackvar(21) = (Word) MR_string_const("", 0);
	GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i41);
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i39);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(20) = r3;
	MR_stackvar(21) = (Word) MR_string_const("\tsave_registers();\n", 19);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i41);
	if (((Integer) MR_stackvar(14) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i42);
	MR_stackvar(22) = (Word) MR_string_const("", 0);
	MR_stackvar(23) = (Word) MR_string_const("\tMR_succeed();\n", 15);
	MR_stackvar(24) = (Word) MR_string_const("\tMR_succeed_discard();\n", 23);
	MR_stackvar(25) = (Word) MR_string_const("#define\tSUCCEED     \tgoto MR_call_success\n", 42);
	MR_stackvar(26) = (Word) MR_string_const("#define\tSUCCEED_LAST\tgoto MR_call_success_last\n", 47);
	MR_stackvar(27) = (Word) MR_string_const("#define\tFAIL\tMR_fail()\n", 23);
	MR_stackvar(28) = (Word) MR_string_const("MR_call_success:\n", 17);
	MR_stackvar(29) = (Word) MR_string_const("MR_call_success_last:\n", 22);
	MR_stackvar(30) = (Word) MR_string_const("#define\tSUCCEED     \tgoto MR_retry_success\n", 43);
	MR_stackvar(31) = (Word) MR_string_const("#define\tSUCCEED_LAST\tgoto MR_retry_success_last\n", 48);
	MR_stackvar(32) = (Word) MR_string_const("#define\tFAIL\tMR_fail()\n", 23);
	MR_stackvar(33) = (Word) MR_string_const("MR_retry_success:\n", 18);
	MR_stackvar(34) = (Word) MR_string_const("MR_retry_success_last:\n", 23);
	MR_stackvar(35) = (Word) MR_string_const("#undef\tSUCCEED\n", 15);
	MR_stackvar(36) = (Word) MR_string_const("#undef\tSUCCEED_LAST\n", 20);
	MR_stackvar(37) = (Word) MR_string_const("#undef\tFAIL\n", 12);
	GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i44);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i42);
	MR_stackvar(22) = (Word) MR_string_const("\trestore_registers();\n", 22);
	MR_stackvar(23) = (Word) MR_string_const("\tMR_succeed();\n", 15);
	MR_stackvar(24) = (Word) MR_string_const("\tMR_succeed_discard();\n", 23);
	MR_stackvar(25) = (Word) MR_string_const("#define\tSUCCEED     \tgoto MR_call_success\n", 42);
	MR_stackvar(26) = (Word) MR_string_const("#define\tSUCCEED_LAST\tgoto MR_call_success_last\n", 47);
	MR_stackvar(27) = (Word) MR_string_const("#define\tFAIL\tMR_fail()\n", 23);
	MR_stackvar(28) = (Word) MR_string_const("MR_call_success:\n", 17);
	MR_stackvar(29) = (Word) MR_string_const("MR_call_success_last:\n", 22);
	MR_stackvar(30) = (Word) MR_string_const("#define\tSUCCEED     \tgoto MR_retry_success\n", 43);
	MR_stackvar(31) = (Word) MR_string_const("#define\tSUCCEED_LAST\tgoto MR_retry_success_last\n", 48);
	MR_stackvar(32) = (Word) MR_string_const("#define\tFAIL\tMR_fail()\n", 23);
	MR_stackvar(33) = (Word) MR_string_const("MR_retry_success:\n", 18);
	MR_stackvar(34) = (Word) MR_string_const("MR_retry_success_last:\n", 23);
	MR_stackvar(35) = (Word) MR_string_const("#undef\tSUCCEED\n", 15);
	MR_stackvar(36) = (Word) MR_string_const("#undef\tSUCCEED_LAST\n", 20);
	MR_stackvar(37) = (Word) MR_string_const("#undef\tFAIL\n", 12);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i44);
	if (((Integer) MR_stackvar(11) != (Integer) 0))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i48);
	MR_stackvar(11) = r2;
	r2 = MR_stackvar(1);
	GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1057);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i48);
	if (((Integer) MR_stackvar(11) != (Integer) 2))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i46);
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_requested_no_inlining_1_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i52,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i52);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i45);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_7);
	r3 = MR_stackvar(12);
	r4 = (Integer) 0;
	call_localret(ENTRY(mercury__string__foldl_4_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i54,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i54);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	if (((Integer) r1 >= (Integer) 32))
		GOTO_LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i45);
	r2 = MR_stackvar(1);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i1057);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 18;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(25);
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(26);
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(27);
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r16, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(28);
	MR_field(MR_mktag(1), r18, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r20, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(29);
	MR_field(MR_mktag(1), r22, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r23, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r24, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(1), r25, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(35);
	MR_field(MR_mktag(1), r26, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(36);
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(37);
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r8, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r8, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r8, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Call and shared pragma C inclusion", 34);
	MR_field(MR_mktag(3), r8, (Integer) 2) = r9;
	MR_field(MR_mktag(2), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(19);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(20);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 18;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(30);
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(31);
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(32);
	MR_field(MR_mktag(1), r16, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r18, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(33);
	MR_field(MR_mktag(1), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r20, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(1), r22, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(34);
	MR_field(MR_mktag(1), r23, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r24, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r25, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(1), r26, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(35);
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(36);
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r29, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(37);
	MR_field(MR_mktag(1), r29, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r29, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), r10, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r10, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r10, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r10, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(3), r10, (Integer) 2) = r11;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = r29;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("Retry and shared pragma C inclusion", 35);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_succip = (Code *) MR_stackvar(40);
	MR_decr_sp_pop_msg(40);
	proceed();
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i45);
	r2 = MR_stackvar(11);
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i46);
	MR_stackvar(11) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i55,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i55);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	MR_stackvar(1) = r2;
	MR_stackvar(38) = r1;
	tag_incr_hp_msg(MR_stackvar(39), MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r2 = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(39), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("Start of the shared block", 25);
	call_localret(ENTRY(mercury__llds_out__get_label_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i56,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i56);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r3 = r1;
	r1 = (Word) MR_string_const("\tGOTO_LABEL(%s);\n", 17);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i57,
		STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	}
Define_label(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0_i57);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 18;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(25);
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(26);
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(27);
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r16, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(28);
	MR_field(MR_mktag(1), r18, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r20, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(29);
	MR_field(MR_mktag(1), r22, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r23, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r24, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(1), r25, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(35);
	MR_field(MR_mktag(1), r26, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(36);
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(37);
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r8, (Integer) 3) = MR_stackvar(14);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(3), r8, (Integer) 2) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), r8, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(38);
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Call pragma C inclusion", 23);
	MR_field(MR_mktag(3), r8, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(2), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(19);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(20);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 18;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r11, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(30);
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(31);
	MR_field(MR_mktag(1), r16, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(32);
	MR_field(MR_mktag(1), r17, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r18, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(33);
	MR_field(MR_mktag(1), r20, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r22, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(1), r23, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(34);
	MR_field(MR_mktag(1), r24, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r25, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r26, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(35);
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r29, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(36);
	MR_field(MR_mktag(1), r29, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r30, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(37);
	MR_field(MR_mktag(1), r30, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r11, (Integer) 3) = MR_stackvar(14);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(3), r11, (Integer) 2) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = r29;
	MR_field(MR_mktag(1), r29, (Integer) 1) = r30;
	MR_field(MR_mktag(1), r30, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), r11, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r11, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(38);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("Retry pragma C inclusion", 24);
	MR_field(MR_mktag(3), r11, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(2), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r10, (Integer) 0) = r11;
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = MR_stackvar(39);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 18;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r12, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(21);
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r16, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_8);
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r17, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_9);
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r18, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_10);
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r20, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_11);
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r22, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(23);
	MR_field(MR_mktag(1), r23, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	MR_field(MR_mktag(1), r24, (Integer) 0) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_12);
	tag_incr_hp_msg(r25, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(22);
	MR_field(MR_mktag(1), r25, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r26, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r26, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r27, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(24);
	MR_field(MR_mktag(1), r27, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r28, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(35);
	MR_field(MR_mktag(1), r28, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r29, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(36);
	MR_field(MR_mktag(1), r29, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r30, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(37);
	MR_field(MR_mktag(1), r30, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r30, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r12, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r12, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r12, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r12, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(3), r12, (Integer) 2) = r13;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 1) = r25;
	MR_field(MR_mktag(1), r25, (Integer) 1) = r26;
	MR_field(MR_mktag(1), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(1), r27, (Integer) 1) = r28;
	MR_field(MR_mktag(1), r28, (Integer) 1) = r29;
	MR_field(MR_mktag(1), r29, (Integer) 1) = r30;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("Shared pragma C inclusion", 25);
	MR_field(MR_mktag(0), r11, (Integer) 0) = r12;
	MR_succip = (Code *) MR_stackvar(40);
	MR_decr_sp_pop_msg(40);
	proceed();
	}
END_MODULE


BEGIN_MODULE(pragma_c_gen_module2)
	init_entry(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0);
	init_label(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0_i3);
BEGIN_CODE

/* code for predicate 'generate_pragma_c_code__ua0'/12 in mode 0 */
Define_static(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0_i3);
	r10 = r9;
	r9 = MR_const_field(MR_mktag(0), r8, (Integer) 1);
	r8 = MR_const_field(MR_mktag(0), r8, (Integer) 0);
	tailcall(STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0),
		STATIC(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0));
Define_label(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0_i3);
	r15 = r9;
	r9 = MR_const_field(MR_mktag(1), r8, (Integer) 3);
	r10 = MR_const_field(MR_mktag(1), r8, (Integer) 4);
	r11 = MR_const_field(MR_mktag(1), r8, (Integer) 5);
	r12 = MR_const_field(MR_mktag(1), r8, (Integer) 6);
	r13 = MR_const_field(MR_mktag(1), r8, (Integer) 7);
	r14 = MR_const_field(MR_mktag(1), r8, (Integer) 8);
	r8 = MR_const_field(MR_mktag(1), r8, (Integer) 2);
	tailcall(STATIC(mercury__pragma_c_gen__nondet_pragma_c_code__ua0_19_0),
		STATIC(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0));
END_MODULE


BEGIN_MODULE(pragma_c_gen_module3)
	init_entry(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0);
	init_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i10);
	init_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i11);
	init_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i6);
	init_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i9);
	init_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i2);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__ordinary_pragma_c_code__991__1'/3 in mode 0 */
Define_static(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i2);
	r4 = (Word) MR_sp;
Define_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i10);
	while (1) {
	MR_incr_sp_push_msg(2, "pragma_c_gen:DeforestationIn__pred__ordinary_pragma_c_code__991__1");
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 3), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i6);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
Define_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i6);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i9);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
Define_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i9);
	MR_decr_sp_pop_msg(2);
	if (((Integer) MR_sp > (Integer) r4))
		GOTO_LABEL(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i11);
	proceed();
Define_label(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module4)
	init_entry(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0);
	init_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__nondet_pragma_c_code__720__2'/3 in mode 0 */
Define_static(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0);
	if (((Integer) r1 != (Integer) 59))
		GOTO_LABEL(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0_i2);
	r1 = ((Integer) r2 + (Integer) 1);
	proceed();
Define_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__720__2_3_0_i2);
	r1 = r2;
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module5)
	init_entry(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0);
	init_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__nondet_pragma_c_code__564__1'/2 in mode 0 */
Define_static(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__pragma_c_gen__IntroducedFrom__pred__nondet_pragma_c_code__564__1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module6)
	init_entry(mercury__pragma_c_gen__generate_pragma_c_code_12_0);
BEGIN_CODE

/* code for predicate 'generate_pragma_c_code'/12 in mode 0 */
Define_entry(mercury__pragma_c_gen__generate_pragma_c_code_12_0);
	r8 = r9;
	r9 = r10;
	tailcall(STATIC(mercury__pragma_c_gen__generate_pragma_c_code__ua0_12_0),
		ENTRY(mercury__pragma_c_gen__generate_pragma_c_code_12_0));
END_MODULE

Declare_entry(mercury__llds_out__sym_name_mangle_2_0);
Declare_entry(mercury__llds_out__name_mangle_2_0);
Declare_entry(mercury__hlds_pred__proc_id_to_int_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(pragma_c_gen_module7)
	init_entry(mercury__pragma_c_gen__struct_name_5_0);
	init_label(mercury__pragma_c_gen__struct_name_5_0_i2);
	init_label(mercury__pragma_c_gen__struct_name_5_0_i3);
	init_label(mercury__pragma_c_gen__struct_name_5_0_i4);
	init_label(mercury__pragma_c_gen__struct_name_5_0_i5);
	init_label(mercury__pragma_c_gen__struct_name_5_0_i6);
BEGIN_CODE

/* code for predicate 'struct_name'/5 in mode 0 */
Define_entry(mercury__pragma_c_gen__struct_name_5_0);
	MR_incr_sp_push_msg(4, "pragma_c_gen:struct_name/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__llds_out__sym_name_mangle_2_0),
		mercury__pragma_c_gen__struct_name_5_0_i2,
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
Define_label(mercury__pragma_c_gen__struct_name_5_0_i2);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__struct_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__llds_out__name_mangle_2_0),
		mercury__pragma_c_gen__struct_name_5_0_i3,
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
Define_label(mercury__pragma_c_gen__struct_name_5_0_i3);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__struct_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_id_to_int_2_0),
		mercury__pragma_c_gen__struct_name_5_0_i4,
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
Define_label(mercury__pragma_c_gen__struct_name_5_0_i4);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__struct_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__pragma_c_gen__struct_name_5_0_i5,
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
Define_label(mercury__pragma_c_gen__struct_name_5_0_i5);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__struct_name_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__pragma_c_gen__struct_name_5_0_i6,
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
Define_label(mercury__pragma_c_gen__struct_name_5_0_i6);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__struct_name_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("mercury_save__", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("__", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("__", 2);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const("_", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__struct_name_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__pragma_c_gen__struct_name_5_0));
	}
END_MODULE

Declare_entry(mercury__prog_data__thread_safe_2_0);
Declare_entry(mercury__code_info__succip_is_used_2_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__call_gen__save_variables_4_0);
Declare_entry(mercury__code_info__clear_r1_3_0);
Declare_entry(mercury__llds_out__quote_c_string_2_0);
Declare_entry(mercury__code_info__clear_all_registers_2_0);
Declare_entry(mercury__code_info__generate_failure_3_0);

BEGIN_MODULE(pragma_c_gen_module8)
	init_entry(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i2);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i3);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i4);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i5);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i6);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i7);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i9);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i10);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i11);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i12);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i14);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i17);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i15);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i19);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i20);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i21);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i22);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i23);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i24);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i26);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i27);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i29);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i30);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i31);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i32);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1064);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i34);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i37);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i35);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i38);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i39);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i41);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i44);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i45);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i46);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1071);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i50);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i51);
	init_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1107);
BEGIN_CODE

/* code for predicate 'ordinary_pragma_c_code'/12 in mode 0 */
Define_static(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0);
	MR_incr_sp_push_msg(17, "pragma_c_gen:ordinary_pragma_c_code/12");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r9;
	MR_stackvar(10) = r10;
	call_localret(ENTRY(mercury__prog_data__may_call_mercury_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i2,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i2);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__prog_data__thread_safe_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i3,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i3);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury__code_info__get_pred_proc_arginfo_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i4,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i4);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = MR_tempr1;
	r4 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	call_localret(STATIC(mercury__pragma_c_gen__make_c_arg_list_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i5,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i5);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(5) = r1;
	call_localret(STATIC(mercury__pragma_c_gen__DeforestationIn__pred__ordinary_pragma_c_code__991__1_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i6,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i6);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i7);
	MR_stackvar(7) = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__pragma_c_gen__get_pragma_input_vars_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i14,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i7);
	r3 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r3;
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__code_info__succip_is_used_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i9,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i9);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__pragma_c_gen__get_c_arg_list_vars_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i10,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_pragma_c_gen__common_13);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i11,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i11);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__call_gen__save_variables_4_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i12,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i12);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r3;
	call_localret(STATIC(mercury__pragma_c_gen__get_pragma_input_vars_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i14,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i14);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i15);
	MR_stackvar(10) = r1;
	r1 = r3;
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__code_info__clear_r1_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i17,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i17);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	MR_stackvar(12) = r2;
	call_localret(STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i19,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i15);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(11) = r2;
	MR_stackvar(12) = r3;
	call_localret(STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i19,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i19);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i20,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i20);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(13) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i21,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i21);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(14) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i22,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i22);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r1;
	MR_stackvar(15) = r2;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(14);
	call_localret(STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i23,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i23);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "llds:pragma_c_component/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(10);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i24);
	MR_stackvar(10) = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(15);
	r4 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_14);
	GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i26);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i24);
	MR_stackvar(10) = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(15);
	r4 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_15);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i26);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i27);
	MR_stackvar(3) = r2;
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_14);
	r6 = MR_stackvar(8);
	MR_stackvar(4) = r3;
	MR_stackvar(13) = r4;
	MR_stackvar(14) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_14);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 2) = r6;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_stackvar(8) = r3;
	GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i34);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i27);
	MR_stackvar(15) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r1 = MR_stackvar(13);
	MR_stackvar(4) = r3;
	MR_stackvar(13) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i29,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i29);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i30,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i30);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	call_localret(ENTRY(mercury__llds_out__quote_c_string_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i31,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i31);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(14) = r1;
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\tMR_OBTAIN_GLOBAL_LOCK(\"", 24);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_pragma_c_gen__common_16);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i32,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i32);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = MR_stackvar(14);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	MR_stackvar(14) = r3;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\tMR_RELEASE_GLOBAL_LOCK(\"", 25);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_pragma_c_gen__common_16);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1064,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1064);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "llds:pragma_c_component/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r1;
	r3 = MR_stackvar(8);
	r1 = MR_stackvar(15);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_stackvar(8) = MR_tempr1;
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i34);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i35);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i37,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i37);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_stackvar(9) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_stackvar(15) = MR_tempr1;
	GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i38);
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i35);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i38);
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i39);
	MR_stackvar(16) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i41);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i39);
	MR_stackvar(16) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_17);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i41);
	if (((Integer) MR_stackvar(2) == (Integer) 1))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i45);
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__clear_all_registers_2_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i44,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i44);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r2 = r1;
	r1 = MR_stackvar(7);
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i45);
	MR_stackvar(7) = r1;
	call_localret(STATIC(mercury__pragma_c_gen__pragma_acquire_regs_4_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i46,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i46);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1071,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1071);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 7, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 18;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_stackvar(12);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_stackvar(14);
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r12, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r13, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	MR_field(MR_mktag(1), r14, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r15, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r6, (Integer) 6) = (Integer) 0;
	MR_field(MR_mktag(3), r6, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r6, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("Pragma C inclusion", 18);
	MR_tempr2 = MR_stackvar(15);
	MR_field(MR_mktag(3), r6, (Integer) 5) = MR_tempr2;
	MR_field(MR_mktag(3), r6, (Integer) 2) = r7;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1107);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r1 = r2;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i50,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i50);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i51,
		STATIC(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i51);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("Skip past failure code", 22);
	MR_field(MR_mktag(3), r11, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r10, (Integer) 0) = r11;
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(2), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = r3;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r12, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(2), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
Define_label(mercury__pragma_c_gen__ordinary_pragma_c_code_12_0_i1107);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__ordinary_pragma_c_code_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_util__make_entry_label_5_0);
Declare_entry(mercury__llds_out__get_proc_label_3_0);
Declare_entry(mercury__fn__string__append_list_1_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(pragma_c_gen_module9)
	init_entry(mercury__pragma_c_gen__make_proc_label_hash_define_5_0);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i2);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i5);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i3);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i8);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i6);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i11);
	init_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12);
BEGIN_CODE

/* code for predicate 'make_proc_label_hash_define'/5 in mode 0 */
Define_static(mercury__pragma_c_gen__make_proc_label_hash_define_5_0);
	MR_incr_sp_push_msg(1, "pragma_c_gen:make_proc_label_hash_define/5");
	MR_stackvar(1) = (Word) MR_succip;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_util__make_entry_label_5_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i2,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i2);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i3);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__llds_out__get_proc_label_3_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i5,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i5);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_proc_label_hash_define_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("#define MR_PROC_LABEL ", 22);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_proc_label_hash_define_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_pragma_c_gen__common_18);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__fn__string__append_list_1_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i3);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i6);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__llds_out__get_label_3_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i8,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i8);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_proc_label_hash_define_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("#define MR_PROC_LABEL ", 22);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_proc_label_hash_define_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_pragma_c_gen__common_18);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__fn__string__append_list_1_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i6);
	r1 = (Word) MR_string_const("unexpected code_addr in make_proc_label_hash_define", 51);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i11,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i11);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
	call_localret(ENTRY(mercury__fn__string__append_list_1_0),
		mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12,
		STATIC(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
Define_label(mercury__pragma_c_gen__make_proc_label_hash_define_5_0_i12);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_proc_label_hash_define_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__pragma_c_gen__make_proc_label_hash_define_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_pragma_c_gen__common_19);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module10)
	init_entry(mercury__pragma_c_gen__make_c_arg_list_5_0);
	init_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	init_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i13);
	init_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i14);
	init_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
BEGIN_CODE

/* code for predicate 'make_c_arg_list'/5 in mode 0 */
Define_static(mercury__pragma_c_gen__make_c_arg_list_5_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i2);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
	MR_incr_sp_push_msg(2, "pragma_c_gen:make_c_arg_list/5");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i13);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__pragma_c_gen__make_c_arg_list_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__pragma_c_gen__make_c_arg_list_5_0,
		LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i14),
		STATIC(mercury__pragma_c_gen__make_c_arg_list_5_0));
	}
Define_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i13);
	r5 = r1;
	r6 = r2;
	r7 = r3;
	r8 = r4;
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__pragma_c_gen__make_c_arg_list_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__pragma_c_gen__make_c_arg_list_5_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 3) = MR_const_field(MR_mktag(1), r8, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr2, (Integer) 2) = MR_const_field(MR_mktag(1), r7, (Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r6, (Integer) 0), (Integer) 0), (Integer) 0);
	localcall(mercury__pragma_c_gen__make_c_arg_list_5_0,
		LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0_i14),
		STATIC(mercury__pragma_c_gen__make_c_arg_list_5_0));
	}
Define_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i14);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_c_arg_list_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_c_arg_list_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pragma_c_gen__make_c_arg_list_5_0_i7);
	r1 = (Word) MR_string_const("pragma_c_gen:make_c_arg_list - length mismatch", 46);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__pragma_c_gen__make_c_arg_list_5_0));
END_MODULE


BEGIN_MODULE(pragma_c_gen_module11)
	init_entry(mercury__pragma_c_gen__get_c_arg_list_vars_2_0);
	init_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i4);
	init_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i5);
	init_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i2);
BEGIN_CODE

/* code for predicate 'get_c_arg_list_vars'/2 in mode 0 */
Define_static(mercury__pragma_c_gen__get_c_arg_list_vars_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i2);
	r3 = (Word) MR_sp;
Define_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "pragma_c_gen:get_c_arg_list_vars");
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__get_c_arg_list_vars_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__pragma_c_gen__get_c_arg_list_vars_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__string__first_char_3_2);

BEGIN_MODULE(pragma_c_gen_module12)
	init_entry(mercury__pragma_c_gen__make_pragma_decls_2_0);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i1003);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i8);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i10);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i4);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i5);
	init_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i3);
BEGIN_CODE

/* code for predicate 'make_pragma_decls'/2 in mode 0 */
Define_static(mercury__pragma_c_gen__make_pragma_decls_2_0);
	MR_incr_sp_push_msg(4, "pragma_c_gen:make_pragma_decls/2");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r2 = (Integer) 95;
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__pragma_c_gen__make_pragma_decls_2_0_i8,
		STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0));
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i8);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0_i4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__pragma_c_gen__make_pragma_decls_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	localcall(mercury__pragma_c_gen__make_pragma_decls_2_0,
		LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0_i10),
		STATIC(mercury__pragma_c_gen__make_pragma_decls_2_0));
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__make_pragma_decls_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i4);
	r2 = MR_stackvar(1);
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i5);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__pragma_c_gen__make_pragma_decls_2_0_i1003);
Define_label(mercury__pragma_c_gen__make_pragma_decls_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__produce_variable_5_0);

BEGIN_MODULE(pragma_c_gen_module13)
	init_entry(mercury__pragma_c_gen__get_pragma_input_vars_5_0);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i1003);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i8);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i10);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i11);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i4);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i5);
	init_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i3);
BEGIN_CODE

/* code for predicate 'get_pragma_input_vars'/5 in mode 0 */
Define_static(mercury__pragma_c_gen__get_pragma_input_vars_5_0);
	MR_incr_sp_push_msg(6, "pragma_c_gen:get_pragma_input_vars/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1), (Integer) 0);
	MR_stackvar(5) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = (Integer) 95;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__pragma_c_gen__get_pragma_input_vars_5_0_i8,
		STATIC(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
	}
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__pragma_c_gen__get_pragma_input_vars_5_0_i10,
		STATIC(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__pragma_c_gen__get_pragma_input_vars_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_stackvar(3) = r1;
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	r1 = MR_stackvar(2);
	r2 = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	localcall(mercury__pragma_c_gen__get_pragma_input_vars_5_0,
		LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i11),
		STATIC(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
	}
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i11);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__get_pragma_input_vars_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__pragma_c_gen__get_pragma_input_vars_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i5);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i1003);
Define_label(mercury__pragma_c_gen__get_pragma_input_vars_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__acquire_reg_for_var_4_0);

BEGIN_MODULE(pragma_c_gen_module14)
	init_entry(mercury__pragma_c_gen__pragma_acquire_regs_4_0);
	init_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i4);
	init_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i5);
	init_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i3);
BEGIN_CODE

/* code for predicate 'pragma_acquire_regs'/4 in mode 0 */
Define_static(mercury__pragma_c_gen__pragma_acquire_regs_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i3);
	MR_incr_sp_push_msg(2, "pragma_c_gen:pragma_acquire_regs/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__acquire_reg_for_var_4_0),
		mercury__pragma_c_gen__pragma_acquire_regs_4_0_i4,
		STATIC(mercury__pragma_c_gen__pragma_acquire_regs_4_0));
Define_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__pragma_acquire_regs_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	localcall(mercury__pragma_c_gen__pragma_acquire_regs_4_0,
		LABEL(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i5),
		STATIC(mercury__pragma_c_gen__pragma_acquire_regs_4_0));
Define_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__pragma_acquire_regs_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__pragma_acquire_regs_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__pragma_c_gen__pragma_acquire_regs_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__code_info__release_reg_3_0);
Declare_entry(mercury__code_info__set_var_location_4_0);

BEGIN_MODULE(pragma_c_gen_module15)
	init_entry(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i5);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i6);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i3);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i9);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i10);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i11);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i16);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i12);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i8);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i19);
	init_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i2);
BEGIN_CODE

/* code for predicate 'place_pragma_output_args_in_regs'/5 in mode 0 */
Define_static(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0);
	MR_incr_sp_push_msg(7, "pragma_c_gen:place_pragma_output_args_in_regs/5");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i5);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("place_pragma_output_args_in_regs: length mismatch", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i6,
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i6);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i9,
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	}
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i9);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__set_var_location_4_0),
		mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i10,
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	localcall(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0,
		LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i11),
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	if (((Integer) MR_stackvar(4) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i2);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r1;
	r1 = r3;
	MR_stackvar(1) = r2;
	r2 = (Integer) 95;
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i16,
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i16);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i12);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0, "llds:pragma_c_output/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i12);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i8);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("place_pragma_output_args_in_regs: length mismatch", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i19,
		STATIC(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i19);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0));
	r2 = MR_stackvar(1);
Define_label(mercury__pragma_c_gen__place_pragma_output_args_in_regs_5_0_i2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module16)
	init_entry(mercury__pragma_c_gen__input_descs_from_arg_info_2_0);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i1003);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i8);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i10);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i4);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i5);
	init_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i3);
BEGIN_CODE

/* code for predicate 'input_descs_from_arg_info'/2 in mode 0 */
Define_static(mercury__pragma_c_gen__input_descs_from_arg_info_2_0);
	MR_incr_sp_push_msg(5, "pragma_c_gen:input_descs_from_arg_info/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 0);
	MR_stackvar(4) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	r2 = (Integer) 95;
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i8,
		STATIC(mercury__pragma_c_gen__input_descs_from_arg_info_2_0));
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i8);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i4);
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__pragma_c_gen__input_descs_from_arg_info_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__pragma_c_gen__input_descs_from_arg_info_2_0, "llds:rval/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__input_descs_from_arg_info_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), MR_stackvar(2), (Integer) 2) = r2;
	localcall(mercury__pragma_c_gen__input_descs_from_arg_info_2_0,
		LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i10),
		STATIC(mercury__pragma_c_gen__input_descs_from_arg_info_2_0));
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i10);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__input_descs_from_arg_info_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i4);
	r2 = MR_stackvar(1);
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i5);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i1003);
Define_label(mercury__pragma_c_gen__input_descs_from_arg_info_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module17)
	init_entry(mercury__pragma_c_gen__output_descs_from_arg_info_2_0);
	init_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i4);
	init_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i9);
	init_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i5);
	init_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i3);
	init_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i2);
BEGIN_CODE

/* code for predicate 'output_descs_from_arg_info'/2 in mode 0 */
Define_static(mercury__pragma_c_gen__output_descs_from_arg_info_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i3);
	MR_incr_sp_push_msg(5, "pragma_c_gen:output_descs_from_arg_info/2");
	MR_stackvar(5) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	localcall(mercury__pragma_c_gen__output_descs_from_arg_info_2_0,
		LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i4),
		STATIC(mercury__pragma_c_gen__output_descs_from_arg_info_2_0));
Define_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i4);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i2);
	MR_stackvar(4) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(1) = r1;
	r2 = (Integer) 95;
	call_localret(ENTRY(mercury__string__first_char_3_2),
		mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i9,
		STATIC(mercury__pragma_c_gen__output_descs_from_arg_info_2_0));
Define_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i9);
	update_prof_current_proc(LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0));
	if (r1)
		GOTO_LABEL(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__output_descs_from_arg_info_2_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__pragma_c_gen__output_descs_from_arg_info_2_0, "llds:pragma_c_output/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__pragma_c_gen__output_descs_from_arg_info_2_0, "llds:lval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i5);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__pragma_c_gen__output_descs_from_arg_info_2_0_i2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);
Declare_entry(mercury____Unify___term__term_1_0);
Declare_entry(mercury____Unify___hlds_pred__arg_info_0_0);

BEGIN_MODULE(pragma_c_gen_module18)
	init_entry(mercury____Unify___pragma_c_gen__c_arg_0_0);
	init_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i2);
	init_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i4);
	init_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i6);
	init_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___pragma_c_gen__c_arg_0_0);
	MR_incr_sp_push_msg(7, "pragma_c_gen:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury____Unify___pragma_c_gen__c_arg_0_0_i2,
		STATIC(mercury____Unify___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___pragma_c_gen__c_arg_0_0_i4,
		STATIC(mercury____Unify___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___term__term_1_0),
		mercury____Unify___pragma_c_gen__c_arg_0_0_i6,
		STATIC(mercury____Unify___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Unify___hlds_pred__arg_info_0_0),
		STATIC(mercury____Unify___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Unify___pragma_c_gen__c_arg_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(pragma_c_gen_module19)
	init_entry(mercury____Index___pragma_c_gen__c_arg_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___pragma_c_gen__c_arg_0_0);
	tailcall(STATIC(mercury____Index___pragma_c_gen__c_arg_0__ua0_2_0),
		STATIC(mercury____Index___pragma_c_gen__c_arg_0_0));
END_MODULE

Declare_entry(mercury____Compare___term__var_1_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);
Declare_entry(mercury____Compare___term__term_1_0);
Declare_entry(mercury____Compare___hlds_pred__arg_info_0_0);

BEGIN_MODULE(pragma_c_gen_module20)
	init_entry(mercury____Compare___pragma_c_gen__c_arg_0_0);
	init_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i3);
	init_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i7);
	init_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i11);
	init_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___pragma_c_gen__c_arg_0_0);
	MR_incr_sp_push_msg(7, "pragma_c_gen:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___term__var_1_0),
		mercury____Compare___pragma_c_gen__c_arg_0_0_i3,
		STATIC(mercury____Compare___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___pragma_c_gen__c_arg_0_0_i7,
		STATIC(mercury____Compare___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___term__term_1_0),
		mercury____Compare___pragma_c_gen__c_arg_0_0_i11,
		STATIC(mercury____Compare___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___hlds_pred__arg_info_0_0),
		STATIC(mercury____Compare___pragma_c_gen__c_arg_0_0));
Define_label(mercury____Compare___pragma_c_gen__c_arg_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__pragma_c_gen_maybe_bunch_0(void)
{
	pragma_c_gen_module0();
	pragma_c_gen_module1();
	pragma_c_gen_module2();
	pragma_c_gen_module3();
	pragma_c_gen_module4();
	pragma_c_gen_module5();
	pragma_c_gen_module6();
	pragma_c_gen_module7();
	pragma_c_gen_module8();
	pragma_c_gen_module9();
	pragma_c_gen_module10();
	pragma_c_gen_module11();
	pragma_c_gen_module12();
	pragma_c_gen_module13();
	pragma_c_gen_module14();
	pragma_c_gen_module15();
	pragma_c_gen_module16();
	pragma_c_gen_module17();
	pragma_c_gen_module18();
	pragma_c_gen_module19();
	pragma_c_gen_module20();
}

#endif

void mercury__pragma_c_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__pragma_c_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__pragma_c_gen_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_pragma_c_gen__type_ctor_info_c_arg_0,
			pragma_c_gen__c_arg_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
