/*
** Automatically generated from `prog_io_dcg.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__prog_io_dcg__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__prog_io_dcg__term_list_append_term__ua0_3_0);
Declare_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
Declare_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i13);
Declare_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1016);
Declare_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i15);
Declare_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
Declare_static(mercury__prog_io_dcg__IntroducedFrom__pred__process_dcg_clause__449__2_2_0);
Declare_static(mercury__prog_io_dcg__IntroducedFrom__pred__parse_dcg_goal__98__1_2_0);
Define_extern_entry(mercury__prog_io_dcg__parse_dcg_clause_6_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i4);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i5);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i6);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i7);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i8);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i10);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i11);
Declare_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i12);
Define_extern_entry(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i4);
Declare_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i5);
Declare_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i6);
Declare_static(mercury__prog_io_dcg__new_dcg_var_5_0);
Declare_label(mercury__prog_io_dcg__new_dcg_var_5_0_i2);
Declare_label(mercury__prog_io_dcg__new_dcg_var_5_0_i3);
Declare_label(mercury__prog_io_dcg__new_dcg_var_5_0_i4);
Declare_label(mercury__prog_io_dcg__new_dcg_var_5_0_i5);
Declare_static(mercury__prog_io_dcg__parse_dcg_goal_8_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i4);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i6);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i7);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i12);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i13);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i9);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i10);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i15);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i16);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i17);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i18);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i19);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i5);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i21);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i22);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i23);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i24);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i25);
Declare_static(mercury__prog_io_dcg__parse_dcg_goal_2_10_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1002);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i5);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i6);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i8);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i9);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i13);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i14);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i15);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i16);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i20);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i21);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i22);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i25);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i26);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i30);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i34);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i35);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i36);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i40);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i49);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i51);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1147);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i54);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i58);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1159);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i60);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i62);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i66);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i67);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i68);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i69);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i73);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i76);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i77);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i89);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i90);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i92);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i94);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i91);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i97);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i96);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i101);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1196);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i100);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1198);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i109);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i125);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1216);
Declare_static(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i6);
Declare_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i7);
Declare_static(mercury__prog_io_dcg__append_to_disjunct_4_0);
Declare_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i4);
Declare_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i5);
Declare_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i2);
Declare_static(mercury__prog_io_dcg__parse_dcg_if_then_12_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i9);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i10);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i11);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i12);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i13);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i17);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i19);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i21);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i22);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i23);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i24);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i14);
Declare_static(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i2);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i3);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i5);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i7);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i4);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i10);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i9);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i13);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i12);
Declare_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i15);

static const struct mercury_data_prog_io_dcg__common_0_struct {
	String f1;
}  mercury_data_prog_io_dcg__common_0;

static const struct mercury_data_prog_io_dcg__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_dcg__common_1;

static const struct mercury_data_prog_io_dcg__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_dcg__common_2;

static const struct mercury_data_prog_io_dcg__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_prog_io_dcg__common_3;

static const struct mercury_data_prog_io_dcg__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_prog_io_dcg__common_4;

static const struct mercury_data_prog_io_dcg__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_prog_io_dcg__common_5;

static const struct mercury_data_prog_io_dcg__common_6_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_prog_io_dcg__common_6;

static const struct mercury_data_prog_io_dcg__common_7_struct {
	String f1;
}  mercury_data_prog_io_dcg__common_7;

static const struct mercury_data_prog_io_dcg__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	Integer f7;
	String f8;
	String f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	String f14;
	Integer f15;
	String f16;
	String f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	String f22;
	String f23;
	Integer f24;
	Integer f25;
	Integer f26;
	String f27;
	String f28;
	String f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_prog_io_dcg__common_8;

static const struct mercury_data_prog_io_dcg__common_9_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_prog_io_dcg__common_9;

static const struct mercury_data_prog_io_dcg__common_0_struct mercury_data_prog_io_dcg__common_0 = {
	MR_string_const(".", 1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_prog_io_dcg__common_1_struct mercury_data_prog_io_dcg__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_prog_io_dcg__common_2_struct mercury_data_prog_io_dcg__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_prog_io_dcg__common_3_struct mercury_data_prog_io_dcg__common_3 = {
	(Integer) 0,
	MR_string_const("prog_io_dcg", 11),
	MR_string_const("prog_io_dcg", 11),
	MR_string_const("IntroducedFrom__pred__process_dcg_clause__449__2", 48),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2)
};

static const struct mercury_data_prog_io_dcg__common_4_struct mercury_data_prog_io_dcg__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_3),
	STATIC(mercury__prog_io_dcg__IntroducedFrom__pred__process_dcg_clause__449__2_2_0),
	(Integer) 0
};

static const struct mercury_data_prog_io_dcg__common_5_struct mercury_data_prog_io_dcg__common_5 = {
	(Integer) 0,
	MR_string_const("prog_io_dcg", 11),
	MR_string_const("prog_io_dcg", 11),
	MR_string_const("IntroducedFrom__pred__parse_dcg_goal__98__1", 43),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_1)
};

static const struct mercury_data_prog_io_dcg__common_6_struct mercury_data_prog_io_dcg__common_6 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_5),
	STATIC(mercury__prog_io_dcg__IntroducedFrom__pred__parse_dcg_goal__98__1_2_0),
	(Integer) 0
};

static const struct mercury_data_prog_io_dcg__common_7_struct mercury_data_prog_io_dcg__common_7 = {
	MR_string_const("call", 4)
};

static const struct mercury_data_prog_io_dcg__common_8_struct mercury_data_prog_io_dcg__common_8 = {
	(Integer) 0,
	MR_string_const("[]", 2),
	MR_string_const("all", 3),
	MR_string_const(",", 1),
	MR_string_const("{}", 2),
	MR_string_const("impure", 6),
	(Integer) 0,
	MR_string_const("&", 1),
	MR_string_const("semipure", 8),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("if", 2),
	(Integer) 0,
	MR_string_const(".", 1),
	MR_string_const("some", 4),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("\\+", 2),
	MR_string_const("not", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const(";", 1),
	MR_string_const("else", 4),
	MR_string_const("=", 1),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_dcg__common_9_struct mercury_data_prog_io_dcg__common_9 = {
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) 1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 3,
	(Integer) -2,
	(Integer) -1,
	(Integer) 5,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2
};


BEGIN_MODULE(prog_io_dcg_module0)
	init_entry(mercury__prog_io_dcg__term_list_append_term__ua0_3_0);
	init_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
	init_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i13);
	init_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1016);
	init_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i15);
	init_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
BEGIN_CODE

/* code for predicate 'term_list_append_term__ua0'/3 in mode 0 */
Define_static(mercury__prog_io_dcg__term_list_append_term__ua0_3_0);
	MR_incr_sp_push_msg(4, "prog_io_dcg:term_list_append_term__ua0/3");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("[]", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1016);
Define_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const(".", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_0);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1), (Integer) 0);
	localcall(mercury__prog_io_dcg__term_list_append_term__ua0_3_0,
		LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i13),
		STATIC(mercury__prog_io_dcg__term_list_append_term__ua0_3_0));
Define_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__prog_io_dcg__term_list_append_term__ua0_3_0, "term:term/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__term_list_append_term__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__term_list_append_term__ua0_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	GOTO_LABEL(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i15);
	}
Define_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1016);
	r1 = TRUE;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i15);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_dcg__term_list_append_term__ua0_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__term__coerce_2_0);

BEGIN_MODULE(prog_io_dcg_module1)
	init_entry(mercury__prog_io_dcg__IntroducedFrom__pred__process_dcg_clause__449__2_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__process_dcg_clause__449__2'/2 in mode 0 */
Define_static(mercury__prog_io_dcg__IntroducedFrom__pred__process_dcg_clause__449__2_2_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury__term__coerce_2_0),
		STATIC(mercury__prog_io_dcg__IntroducedFrom__pred__process_dcg_clause__449__2_2_0));
END_MODULE


BEGIN_MODULE(prog_io_dcg_module2)
	init_entry(mercury__prog_io_dcg__IntroducedFrom__pred__parse_dcg_goal__98__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__parse_dcg_goal__98__1'/2 in mode 0 */
Define_static(mercury__prog_io_dcg__IntroducedFrom__pred__parse_dcg_goal__98__1_2_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	tailcall(ENTRY(mercury__term__coerce_2_0),
		STATIC(mercury__prog_io_dcg__IntroducedFrom__pred__parse_dcg_goal__98__1_2_0));
END_MODULE

Declare_entry(mercury__varset__coerce_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__varset__new_var_3_0);
Declare_entry(mercury__varset__name_var_4_0);
Declare_entry(mercury__prog_io__parse_implicitly_qualified_term_5_0);
Declare_entry(mercury__prog_io_util__add_context_3_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(prog_io_dcg_module3)
	init_entry(mercury__prog_io_dcg__parse_dcg_clause_6_0);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i4);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i5);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i6);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i7);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i8);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i10);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i11);
	init_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i12);
BEGIN_CODE

/* code for predicate 'parse_dcg_clause'/6 in mode 0 */
Define_entry(mercury__prog_io_dcg__parse_dcg_clause_6_0);
	MR_incr_sp_push_msg(7, "prog_io_dcg:parse_dcg_clause/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__varset__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i2,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	MR_stackvar(5) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i3,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i4,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i5,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r4 = MR_stackvar(5);
	r3 = r1;
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i6,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = (Integer) 1;
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i7,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = r4;
	r4 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r5 = (Word) MR_string_const("DCG clause head", 15);
	call_localret(ENTRY(mercury__prog_io__parse_implicitly_qualified_term_5_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i8,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0_i10);
	r2 = MR_stackvar(4);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_clause_6_0, "prog_io_util:maybe1/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__prog_io_util__add_context_3_0),
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i10);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_4);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i11,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_clause_6_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_clause_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_clause_6_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_clause_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_dcg__parse_dcg_clause_6_0_i12,
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_clause_6_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	r2 = MR_stackvar(4);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_clause_6_0, "prog_io_util:maybe1/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 4, mercury__prog_io_dcg__parse_dcg_clause_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__prog_io_util__add_context_3_0),
		ENTRY(mercury__prog_io_dcg__parse_dcg_clause_6_0));
	}
END_MODULE


BEGIN_MODULE(prog_io_dcg_module4)
	init_entry(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0);
	init_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i4);
	init_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i5);
	init_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i6);
BEGIN_CODE

/* code for predicate 'parse_dcg_pred_goal'/6 in mode 0 */
Define_entry(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0);
	MR_incr_sp_push_msg(3, "prog_io_dcg:parse_dcg_pred_goal/6");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 0;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i2,
		ENTRY(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i3,
		ENTRY(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i4,
		ENTRY(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
	r4 = MR_stackvar(2);
	r3 = r1;
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i5,
		ENTRY(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = (Integer) 1;
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i6,
		ENTRY(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
Define_label(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_pred_goal_6_0));
	r3 = r4;
	r4 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_dcg_module5)
	init_entry(mercury__prog_io_dcg__new_dcg_var_5_0);
	init_label(mercury__prog_io_dcg__new_dcg_var_5_0_i2);
	init_label(mercury__prog_io_dcg__new_dcg_var_5_0_i3);
	init_label(mercury__prog_io_dcg__new_dcg_var_5_0_i4);
	init_label(mercury__prog_io_dcg__new_dcg_var_5_0_i5);
BEGIN_CODE

/* code for predicate 'new_dcg_var'/5 in mode 0 */
Define_static(mercury__prog_io_dcg__new_dcg_var_5_0);
	MR_incr_sp_push_msg(3, "prog_io_dcg:new_dcg_var/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__new_dcg_var_5_0_i2,
		STATIC(mercury__prog_io_dcg__new_dcg_var_5_0));
Define_label(mercury__prog_io_dcg__new_dcg_var_5_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__new_dcg_var_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__new_dcg_var_5_0_i3,
		STATIC(mercury__prog_io_dcg__new_dcg_var_5_0));
Define_label(mercury__prog_io_dcg__new_dcg_var_5_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__new_dcg_var_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__new_dcg_var_5_0_i4,
		STATIC(mercury__prog_io_dcg__new_dcg_var_5_0));
Define_label(mercury__prog_io_dcg__new_dcg_var_5_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__new_dcg_var_5_0));
	r4 = MR_stackvar(1);
	r3 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__new_dcg_var_5_0_i5,
		STATIC(mercury__prog_io_dcg__new_dcg_var_5_0));
Define_label(mercury__prog_io_dcg__new_dcg_var_5_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__new_dcg_var_5_0));
	r2 = ((Integer) MR_stackvar(2) + (Integer) 1);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__term__context_init_1_0);
Declare_entry(mercury__prog_io__sym_name_and_args_3_0);

BEGIN_MODULE(prog_io_dcg_module6)
	init_entry(mercury__prog_io_dcg__parse_dcg_goal_8_0);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i4);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i6);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i7);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i12);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i13);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i9);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i10);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i15);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i16);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i17);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i18);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i19);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i5);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i21);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i22);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i23);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i24);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i25);
BEGIN_CODE

/* code for predicate 'parse_dcg_goal'/8 in mode 0 */
Define_static(mercury__prog_io_dcg__parse_dcg_goal_8_0);
	MR_incr_sp_push_msg(10, "prog_io_dcg:parse_dcg_goal/8");
	MR_stackvar(10) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0_i3);
	MR_stackvar(3) = r3;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r3 = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0_i2);
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i4,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r3 = MR_stackvar(1);
	MR_stackvar(8) = r1;
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i2);
	MR_stackvar(1) = r3;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i6,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__prog_io__sym_name_and_args_3_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i7,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0_i5);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0_i10);
	r4 = r3;
	MR_stackvar(5) = r3;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(9) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_6);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i12,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i13,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0_i9);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i9);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(5);
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i10);
	MR_stackvar(9) = r2;
	MR_stackvar(5) = r3;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i15,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i16,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i16);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i17,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	MR_stackvar(7) = r1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i18,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_stackvar(6) = ((Integer) MR_stackvar(3) + (Integer) 1);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i19,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i19);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i5);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i21,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i22,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i22);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i23,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i23);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	MR_stackvar(7) = r1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i24,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i24);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(1);
	MR_stackvar(6) = ((Integer) MR_stackvar(3) + (Integer) 1);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_8_0_i25,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_8_0_i25);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__prog_io_dcg__parse_dcg_goal_8_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_7);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_8_0, "list:list/1");
	r2 = MR_stackvar(5);
	MR_field(MR_mktag(3), r3, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(10);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	r4 = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r3 = MR_stackvar(6);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
END_MODULE

Declare_entry(mercury__term__vars_2_0);
Declare_entry(mercury__prog_io_goal__parse_goal_4_0);
Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury__prog_util__rename_in_goal_4_0);

BEGIN_MODULE(prog_io_dcg_module7)
	init_entry(mercury__prog_io_dcg__parse_dcg_goal_2_10_0);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1002);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i5);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i6);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i8);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i9);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i13);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i14);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i15);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i16);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i20);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i21);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i22);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i25);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i26);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i30);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i34);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i35);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i36);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i40);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i49);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i51);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1147);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i54);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i58);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1159);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i60);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i62);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i66);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i67);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i68);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i69);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i73);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i76);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i77);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i89);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i90);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i92);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i94);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i91);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i97);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i96);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i101);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1196);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i100);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1198);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i109);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i125);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1216);
BEGIN_CODE

/* code for predicate 'parse_dcg_goal_2'/10 in mode 0 */
Define_static(mercury__prog_io_dcg__parse_dcg_goal_2_10_0);
	r7 = (hash_string(r1) & (Integer) 31);
	MR_incr_sp_push_msg(10, "prog_io_dcg:parse_dcg_goal_2/10");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_8))[(Integer) r7];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1002);
	if ((strcmp((char *)MR_tempr1, (char *)r1) == 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i5);
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1002);
	r7 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_9))[(Integer) r7];
	if (((Integer) r7 >= (Integer) 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i3);
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i5);
	COMPUTED_GOTO((Unsigned) r7,
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i6) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i9) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i16) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i22) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i26) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i30) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i36) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i40) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i54) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i62) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i69) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i73) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i77) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i109) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i125) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001) AND
		LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i6);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r6;
	r1 = r4;
	r2 = r5;
	call_localret(STATIC(mercury__prog_io_dcg__new_dcg_var_5_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i8,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 9;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r5 = r3;
	r3 = r1;
	r1 = TRUE;
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i9);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i13,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i14,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i15,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	r4 = r3;
	r3 = r5;
	r5 = MR_tempr1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr2;
	r1 = TRUE;
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i16);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r3 = r5;
	r4 = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i20,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i20);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i21,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	r4 = r3;
	r3 = r5;
	r5 = MR_tempr1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr2;
	r1 = TRUE;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i22);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r6;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	call_localret(ENTRY(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i25,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i25);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r3 = r2;
	r2 = r1;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i26);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	r3 = r5;
	r4 = r6;
	r5 = (Integer) 2;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i30);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r3 = r5;
	r4 = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i34,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i34);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i35,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i35);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	r4 = r3;
	r3 = r5;
	r5 = MR_tempr1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(2), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr2;
	r1 = TRUE;
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i36);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	r3 = r5;
	r4 = r6;
	r5 = (Integer) 1;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i40);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("then", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r6;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0);
	r7 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r7, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i49,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i49);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	MR_stackvar(7) = r2;
	MR_stackvar(6) = r1;
	MR_stackvar(8) = r3;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = r6;
	r3 = MR_stackvar(4);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i51,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i51);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1147);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1147);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 9;
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_tempr1;
	r5 = MR_stackvar(5);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(10);
	MR_tempr2 = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(3), r4, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr2;
	r1 = TRUE;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i54);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = r4;
	r2 = r5;
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__prog_io_dcg__new_dcg_var_5_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i58,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i58);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	MR_stackvar(2) = r1;
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_dcg__common_0);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r9;
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(1);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1159,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1159);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(STATIC(mercury__prog_io_dcg__term_list_append_term__ua0_3_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i60,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i60);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 9;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	MR_field(MR_mktag(3), r3, (Integer) 2) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	r1 = TRUE;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	r3 = MR_stackvar(2);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i62);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i66,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i66);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i67,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i67);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i68,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i68);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	r4 = r3;
	r3 = r5;
	r5 = MR_tempr1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr2;
	r1 = TRUE;
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i69);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	MR_stackvar(1) = r3;
	r3 = r5;
	r4 = r6;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i76,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i73);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	MR_stackvar(1) = r3;
	r3 = r5;
	r4 = r6;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i76,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i76);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	r4 = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	r3 = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r1 = TRUE;
	r5 = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i77);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r7 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r7) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	r8 = MR_const_field(MR_mktag(0), r7, (Integer) 0);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r8, (Integer) 0), (char *)(Word) MR_string_const("->", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	r8 = MR_const_field(MR_mktag(0), r7, (Integer) 1);
	if (((Integer) r8 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	if (((Integer) MR_const_field(MR_mktag(1), r8, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r8, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	r7 = r6;
	r6 = r5;
	r5 = r4;
	r4 = r3;
	r3 = r1;
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r8, (Integer) 1), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r8, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i81);
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r1;
	r1 = r7;
	r3 = r5;
	r4 = r6;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i89,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i89);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r4;
	r1 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i90,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i90);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(4);
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i92,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i92);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i91);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i94,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i94);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i91);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i91);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i97,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i97);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i96);
	MR_stackvar(5) = MR_stackvar(9);
	r1 = MR_stackvar(6);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 9;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r3;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_io_dcg__append_to_disjunct_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1198,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i96);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i101,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i101);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i100);
	MR_stackvar(5) = MR_stackvar(7);
	r1 = MR_stackvar(8);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 9;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "term:term/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r3;
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_io_dcg__append_to_disjunct_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1196,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1196);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r3, (Integer) 2) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i100);
	r3 = MR_stackvar(9);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	MR_stackvar(5) = r3;
	call_localret(ENTRY(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1198,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1198);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i109);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("if", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("then", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 0);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	r7 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r7, (Integer) 1), (Integer) 0);
	r8 = r4;
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r7, (Integer) 0), (Integer) 2);
	r7 = r5;
	r5 = r8;
	r8 = r6;
	r6 = r7;
	r7 = r8;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i124);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i125);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1216,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_2_10_0_i1216);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_2_10_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	r1 = TRUE;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_2_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	r3 = MR_stackvar(2);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
END_MODULE

Declare_entry(mercury__purity__purity_name_2_0);

BEGIN_MODULE(prog_io_dcg_module8)
	init_entry(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i6);
	init_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i7);
BEGIN_CODE

/* code for predicate 'parse_dcg_goal_with_purity'/9 in mode 0 */
Define_static(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0);
	MR_incr_sp_push_msg(6, "prog_io_dcg:parse_dcg_goal_with_purity/9");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r5;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i2,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
	r6 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r6, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__purity__purity_name_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i6,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i7,
		STATIC(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
Define_label(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 8;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	r4 = MR_stackvar(4);
	MR_field(MR_mktag(3), r3, (Integer) 3) = (Integer) 0;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_goal_with_purity_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	r3 = MR_stackvar(3);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE


BEGIN_MODULE(prog_io_dcg_module9)
	init_entry(mercury__prog_io_dcg__append_to_disjunct_4_0);
	init_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i4);
	init_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i5);
	init_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i2);
BEGIN_CODE

/* code for predicate 'append_to_disjunct'/4 in mode 0 */
Define_static(mercury__prog_io_dcg__append_to_disjunct_4_0);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0_i2);
	MR_incr_sp_push_msg(5, "prog_io_dcg:append_to_disjunct/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__prog_io_dcg__append_to_disjunct_4_0,
		LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0_i4),
		STATIC(mercury__prog_io_dcg__append_to_disjunct_4_0));
Define_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	localcall(mercury__prog_io_dcg__append_to_disjunct_4_0,
		LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0_i5),
		STATIC(mercury__prog_io_dcg__append_to_disjunct_4_0));
Define_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__append_to_disjunct_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__append_to_disjunct_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__append_to_disjunct_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__prog_io_dcg__append_to_disjunct_4_0_i2);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__append_to_disjunct_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__append_to_disjunct_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__append_to_disjunct_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	proceed();
	}
END_MODULE


BEGIN_MODULE(prog_io_dcg_module10)
	init_entry(mercury__prog_io_dcg__parse_dcg_if_then_12_0);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i9);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i10);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i11);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i12);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i13);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i17);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i19);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i21);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i22);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i23);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i24);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i14);
BEGIN_CODE

/* code for predicate 'parse_dcg_if_then'/12 in mode 0 */
Define_static(mercury__prog_io_dcg__parse_dcg_if_then_12_0);
	MR_incr_sp_push_msg(9, "prog_io_dcg:parse_dcg_if_then/12");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r7) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r7, (Integer) 0), (char *)(Word) MR_string_const("some", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r7 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r7, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r7, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r7, (Integer) 1), (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r7, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i9,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i10,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i11);
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r2 = r4;
	r3 = r5;
	r4 = r6;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i11);
	MR_stackvar(5) = r4;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i12,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i13,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	}
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	MR_stackvar(6) = r2;
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	MR_stackvar(7) = r3;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(4);
	MR_stackvar(8) = r4;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i17,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	if (r1)
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i14);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i19,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i19);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i14);
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i21,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	r2 = r1;
	r1 = (Word) MR_string_const("DCG_", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i22,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i22);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i23,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i23);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	r4 = MR_stackvar(4);
	r3 = r1;
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__name_var_4_0),
		mercury__prog_io_dcg__parse_dcg_if_then_12_0_i24,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i24);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_12_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 9;
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r7, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_tempr2;
	r5 = ((Integer) MR_stackvar(7) + (Integer) 1);
	r6 = MR_stackvar(4);
	MR_decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_12_0_i14);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_dcg_module11)
	init_entry(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i2);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i3);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i5);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i7);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i4);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i10);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i9);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i13);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i12);
	init_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i15);
BEGIN_CODE

/* code for predicate 'parse_dcg_if_then_else'/11 in mode 0 */
Define_static(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0);
	MR_incr_sp_push_msg(11, "prog_io_dcg:parse_dcg_if_then_else/11");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = r4;
	MR_stackvar(2) = r4;
	r4 = r5;
	r5 = r6;
	r6 = r7;
	MR_stackvar(3) = r7;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_if_then_12_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i2,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	MR_stackvar(6) = r2;
	r2 = r4;
	MR_stackvar(5) = r1;
	MR_stackvar(7) = r3;
	r1 = MR_stackvar(1);
	r3 = r5;
	r4 = MR_stackvar(3);
	MR_stackvar(8) = r6;
	call_localret(STATIC(mercury__prog_io_dcg__parse_dcg_goal_8_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i3,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r3;
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	MR_stackvar(10) = r4;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i5,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i4);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i7,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i4);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 5, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(3), r2, (Integer) 4) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i4);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i10,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i9);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 5, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 9;
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), r2, (Integer) 4) = MR_stackvar(9);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r3;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(10);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i9);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(10);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i13,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i12);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 5, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 9;
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 4) = r3;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i12);
	r3 = MR_stackvar(10);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i15,
		STATIC(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
Define_label(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_dcg__parse_dcg_if_then_else_11_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__prog_io_dcg__parse_dcg_if_then_else_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__prog_io_dcg_maybe_bunch_0(void)
{
	prog_io_dcg_module0();
	prog_io_dcg_module1();
	prog_io_dcg_module2();
	prog_io_dcg_module3();
	prog_io_dcg_module4();
	prog_io_dcg_module5();
	prog_io_dcg_module6();
	prog_io_dcg_module7();
	prog_io_dcg_module8();
	prog_io_dcg_module9();
	prog_io_dcg_module10();
	prog_io_dcg_module11();
}

#endif

void mercury__prog_io_dcg__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__prog_io_dcg__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__prog_io_dcg_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
