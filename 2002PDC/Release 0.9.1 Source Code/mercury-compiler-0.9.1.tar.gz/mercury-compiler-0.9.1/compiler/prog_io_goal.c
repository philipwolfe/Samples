/*
** Automatically generated from `prog_io_goal.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__prog_io_goal__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_goal_2__213__3_2_0);
Declare_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_func_expression__352__2_2_0);
Declare_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_some_vars_goal__254__1_2_0);
Define_extern_entry(mercury__prog_io_goal__parse_goal_4_0);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i3);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i2);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i8);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i11);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i5);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i1014);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i6);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i13);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i15);
Declare_label(mercury__prog_io_goal__parse_goal_4_0_i1023);
Define_extern_entry(mercury__prog_io_goal__parse_some_vars_goal_5_0);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i10);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i12);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i13);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i2);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
Declare_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i14);
Define_extern_entry(mercury__prog_io_goal__parse_lambda_expression_4_0);
Declare_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i11);
Declare_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i13);
Declare_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
Declare_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1);
Define_extern_entry(mercury__prog_io_goal__parse_pred_expression_5_0);
Declare_label(mercury__prog_io_goal__parse_pred_expression_5_0_i11);
Declare_label(mercury__prog_io_goal__parse_pred_expression_5_0_i13);
Declare_label(mercury__prog_io_goal__parse_pred_expression_5_0_i17);
Declare_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
Declare_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
Define_extern_entry(mercury__prog_io_goal__parse_dcg_pred_expression_5_0);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i11);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i13);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i17);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
Define_extern_entry(mercury__prog_io_goal__parse_func_expression_5_0);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i9);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i13);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i14);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i15);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i16);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i17);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i18);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i19);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i8);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i30);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i32);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i36);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i38);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i40);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i41);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
Declare_label(mercury__prog_io_goal__parse_func_expression_5_0_i1);
Define_extern_entry(mercury__prog_io_goal__parse_lambda_eval_method_3_0);
Declare_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i7);
Declare_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
Declare_static(mercury__prog_io_goal__parse_goal_2_5_0);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i3);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i1002);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i5);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i6);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i10);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i11);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i12);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i16);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i20);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i22);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i23);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i24);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i28);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i43);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i44);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i45);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i46);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i50);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i51);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i52);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i56);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i57);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i58);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i62);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i63);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i64);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i65);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i67);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i71);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i72);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i73);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i77);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i78);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i79);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i82);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i83);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i85);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i88);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i89);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i93);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i95);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i106);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i107);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i108);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i99);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i109);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i110);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i112);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i116);
Declare_label(mercury__prog_io_goal__parse_goal_2_5_0_i1148);
Declare_static(mercury__prog_io_goal__parse_goal_with_purity_5_0);
Declare_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i2);
Declare_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
Declare_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i6);
Declare_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i7);
Declare_static(mercury__prog_io_goal__parse_lambda_args_3_0);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i15);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i16);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i18);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i31);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i32);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
Declare_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
Declare_static(mercury__prog_io_goal__parse_lambda_arg_3_0);
Declare_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i8);
Declare_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i9);
Declare_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
Declare_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1);
Declare_static(mercury__prog_io_goal__parse_pred_expr_args_3_0);
Declare_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i3);
Declare_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i10);
Declare_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i11);
Declare_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i13);
Declare_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
Declare_static(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i6);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i8);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i5);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i16);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i17);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i19);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1018);
Declare_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);

static const struct mercury_data_prog_io_goal__common_0_struct {
	String f1;
}  mercury_data_prog_io_goal__common_0;

static const struct mercury_data_prog_io_goal__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_goal__common_1;

static const struct mercury_data_prog_io_goal__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_goal__common_2;

static const struct mercury_data_prog_io_goal__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_prog_io_goal__common_3;

static const struct mercury_data_prog_io_goal__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_prog_io_goal__common_4;

static const struct mercury_data_prog_io_goal__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_goal__common_5;

static const struct mercury_data_prog_io_goal__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_goal__common_6;

static const struct mercury_data_prog_io_goal__common_7_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_prog_io_goal__common_7;

static const struct mercury_data_prog_io_goal__common_8_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_prog_io_goal__common_8;

static const struct mercury_data_prog_io_goal__common_9_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	String f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	String f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	String f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	String f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	String f28;
	String f29;
	Integer f30;
	Integer f31;
	Integer f32;
	Integer f33;
	String f34;
	String f35;
	Integer f36;
	Integer f37;
	Integer f38;
	String f39;
	String f40;
	Integer f41;
	Integer f42;
	Integer f43;
	Integer f44;
	Integer f45;
	String f46;
	Integer f47;
	Integer f48;
	String f49;
	Integer f50;
	String f51;
	Integer f52;
	Integer f53;
	String f54;
	Integer f55;
	Integer f56;
	String f57;
	Integer f58;
	String f59;
	Integer f60;
	String f61;
	Integer f62;
	Integer f63;
	Integer f64;
}  mercury_data_prog_io_goal__common_9;

static const struct mercury_data_prog_io_goal__common_10_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
	Integer f33;
	Integer f34;
	Integer f35;
	Integer f36;
	Integer f37;
	Integer f38;
	Integer f39;
	Integer f40;
	Integer f41;
	Integer f42;
	Integer f43;
	Integer f44;
	Integer f45;
	Integer f46;
	Integer f47;
	Integer f48;
	Integer f49;
	Integer f50;
	Integer f51;
	Integer f52;
	Integer f53;
	Integer f54;
	Integer f55;
	Integer f56;
	Integer f57;
	Integer f58;
	Integer f59;
	Integer f60;
	Integer f61;
	Integer f62;
	Integer f63;
	Integer f64;
}  mercury_data_prog_io_goal__common_10;

static const struct mercury_data_prog_io_goal__common_11_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_prog_io_goal__common_11;

static const struct mercury_data_prog_io_goal__common_12_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_prog_io_goal__common_12;

static const struct mercury_data_prog_io_goal__common_0_struct mercury_data_prog_io_goal__common_0 = {
	MR_string_const("call", 4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_prog_io_goal__common_1_struct mercury_data_prog_io_goal__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_prog_io_goal__common_2_struct mercury_data_prog_io_goal__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_prog_io_goal__common_3_struct mercury_data_prog_io_goal__common_3 = {
	(Integer) 0,
	MR_string_const("prog_io_goal", 12),
	MR_string_const("prog_io_goal", 12),
	MR_string_const("IntroducedFrom__pred__parse_some_vars_goal__254__1", 50),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_2)
};

static const struct mercury_data_prog_io_goal__common_4_struct mercury_data_prog_io_goal__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_3),
	STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_some_vars_goal__254__1_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
static const struct mercury_data_prog_io_goal__common_5_struct mercury_data_prog_io_goal__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

static const struct mercury_data_prog_io_goal__common_6_struct mercury_data_prog_io_goal__common_6 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_prog_io_goal__common_7_struct mercury_data_prog_io_goal__common_7 = {
	(Integer) 0,
	MR_string_const("prog_io_goal", 12),
	MR_string_const("prog_io_goal", 12),
	MR_string_const("IntroducedFrom__pred__parse_func_expression__352__2", 51),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_6)
};

static const struct mercury_data_prog_io_goal__common_8_struct mercury_data_prog_io_goal__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_7),
	STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_func_expression__352__2_2_0),
	(Integer) 0
};

static const struct mercury_data_prog_io_goal__common_9_struct mercury_data_prog_io_goal__common_9 = {
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("<=", 2),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("semipure", 8),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("some", 4),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("not", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("else", 4),
	MR_string_const("<=>", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("=>", 2),
	MR_string_const("all", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("fail", 4),
	MR_string_const("&", 1),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const(",", 1),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("impure", 6),
	(Integer) 0,
	MR_string_const("true", 4),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("\\+", 2),
	(Integer) 0,
	(Integer) 0,
	MR_string_const("is", 2),
	(Integer) 0,
	MR_string_const(";", 1),
	(Integer) 0,
	MR_string_const("=", 1),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_goal__common_10_struct mercury_data_prog_io_goal__common_10 = {
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2
};

static const struct mercury_data_prog_io_goal__common_11_struct mercury_data_prog_io_goal__common_11 = {
	(Integer) 0,
	MR_string_const("prog_io_goal", 12),
	MR_string_const("prog_io_goal", 12),
	MR_string_const("IntroducedFrom__pred__parse_goal_2__213__3", 42),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_2)
};

static const struct mercury_data_prog_io_goal__common_12_struct mercury_data_prog_io_goal__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_11),
	STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_goal_2__213__3_2_0),
	(Integer) 0
};

Declare_entry(mercury__term__coerce_var_2_0);

BEGIN_MODULE(prog_io_goal_module0)
	init_entry(mercury__prog_io_goal__IntroducedFrom__pred__parse_goal_2__213__3_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__parse_goal_2__213__3'/2 in mode 0 */
Define_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_goal_2__213__3_2_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury__term__coerce_var_2_0),
		STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_goal_2__213__3_2_0));
END_MODULE

Declare_entry(mercury__term__coerce_2_0);

BEGIN_MODULE(prog_io_goal_module1)
	init_entry(mercury__prog_io_goal__IntroducedFrom__pred__parse_func_expression__352__2_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__parse_func_expression__352__2'/2 in mode 0 */
Define_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_func_expression__352__2_2_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury__term__coerce_2_0),
		STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_func_expression__352__2_2_0));
END_MODULE


BEGIN_MODULE(prog_io_goal_module2)
	init_entry(mercury__prog_io_goal__IntroducedFrom__pred__parse_some_vars_goal__254__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__parse_some_vars_goal__254__1'/2 in mode 0 */
Define_static(mercury__prog_io_goal__IntroducedFrom__pred__parse_some_vars_goal__254__1_2_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury__term__coerce_var_2_0),
		STATIC(mercury__prog_io_goal__IntroducedFrom__pred__parse_some_vars_goal__254__1_2_0));
END_MODULE

Declare_entry(mercury__term__context_init_1_0);
Declare_entry(mercury____Unify___term__context_0_0);
Declare_entry(mercury__prog_io__sym_name_and_args_3_0);

BEGIN_MODULE(prog_io_goal_module3)
	init_entry(mercury__prog_io_goal__parse_goal_4_0);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i3);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i2);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i8);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i11);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i5);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i1014);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i6);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i13);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i15);
	init_label(mercury__prog_io_goal__parse_goal_4_0_i1023);
BEGIN_CODE

/* code for predicate 'parse_goal'/4 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_goal_4_0);
	MR_incr_sp_push_msg(6, "prog_io_goal:parse_goal/4");
	MR_stackvar(6) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i3);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = r2;
	GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i2);
Define_label(mercury__prog_io_goal__parse_goal_4_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__prog_io_goal__parse_goal_4_0_i2,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
Define_label(mercury__prog_io_goal__parse_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_4_0));
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i1014);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury____Unify___term__context_0_0),
		mercury__prog_io_goal__parse_goal_4_0_i8,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
Define_label(mercury__prog_io_goal__parse_goal_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i5);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_2_5_0),
		mercury__prog_io_goal__parse_goal_4_0_i11,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_goal__parse_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	r2 = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_4_0_i5);
	r1 = MR_stackvar(3);
	GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i6);
Define_label(mercury__prog_io_goal__parse_goal_4_0_i1014);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_4_0_i13,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
Define_label(mercury__prog_io_goal__parse_goal_4_0_i6);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_4_0_i13,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
Define_label(mercury__prog_io_goal__parse_goal_4_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_4_0));
	MR_stackvar(1) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__prog_io__sym_name_and_args_3_0),
		mercury__prog_io_goal__parse_goal_4_0_i15,
		ENTRY(mercury__prog_io_goal__parse_goal_4_0));
Define_label(mercury__prog_io_goal__parse_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_4_0_i1023);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_goal__parse_goal_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__prog_io_goal__parse_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__prog_io_goal__parse_goal_4_0_i1023);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_goal__parse_goal_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__prog_io_goal__parse_goal_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_0);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_goal_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r2, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__prog_io_util__parse_list_of_vars_2_0);
Declare_entry(mercury__list__map_3_0);

BEGIN_MODULE(prog_io_goal_module4)
	init_entry(mercury__prog_io_goal__parse_some_vars_goal_5_0);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i10);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i12);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i13);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i2);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	init_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i14);
BEGIN_CODE

/* code for predicate 'parse_some_vars_goal'/5 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_some_vars_goal_5_0);
	MR_incr_sp_push_msg(4, "prog_io_goal:parse_some_vars_goal/5");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("some", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__prog_io_util__parse_list_of_vars_2_0),
		mercury__prog_io_goal__parse_some_vars_goal_5_0_i10,
		ENTRY(mercury__prog_io_goal__parse_some_vars_goal_5_0));
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0_i2);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_4);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__prog_io_goal__parse_some_vars_goal_5_0_i12,
		ENTRY(mercury__prog_io_goal__parse_some_vars_goal_5_0));
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_some_vars_goal_5_0_i13,
		ENTRY(mercury__prog_io_goal__parse_some_vars_goal_5_0));
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i3);
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_some_vars_goal_5_0_i14,
		ENTRY(mercury__prog_io_goal__parse_some_vars_goal_5_0));
Define_label(mercury__prog_io_goal__parse_some_vars_goal_5_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_some_vars_goal_5_0));
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__prog_io_util__standard_det_2_0);

BEGIN_MODULE(prog_io_goal_module5)
	init_entry(mercury__prog_io_goal__parse_lambda_expression_4_0);
	init_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i11);
	init_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i13);
	init_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	init_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1);
BEGIN_CODE

/* code for predicate 'parse_lambda_expression'/4 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_lambda_expression_4_0);
	MR_incr_sp_push_msg(2, "prog_io_goal:parse_lambda_expression/4");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_goal__parse_lambda_expression_4_0_i11,
		ENTRY(mercury__prog_io_goal__parse_lambda_expression_4_0));
Define_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_args_3_0),
		mercury__prog_io_goal__parse_lambda_expression_4_0_i13,
		ENTRY(mercury__prog_io_goal__parse_lambda_expression_4_0));
Define_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_expression_4_0_i1);
	r4 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1020);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_expression_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module6)
	init_entry(mercury__prog_io_goal__parse_pred_expression_5_0);
	init_label(mercury__prog_io_goal__parse_pred_expression_5_0_i11);
	init_label(mercury__prog_io_goal__parse_pred_expression_5_0_i13);
	init_label(mercury__prog_io_goal__parse_pred_expression_5_0_i17);
	init_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	init_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
BEGIN_CODE

/* code for predicate 'parse_pred_expression'/5 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_pred_expression_5_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_pred_expression/5");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_goal__parse_pred_expression_5_0_i11,
		ENTRY(mercury__prog_io_goal__parse_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_pred_expression_5_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_eval_method_3_0),
		mercury__prog_io_goal__parse_pred_expression_5_0_i13,
		ENTRY(mercury__prog_io_goal__parse_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_pred_expression_5_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expression_5_0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(STATIC(mercury__prog_io_goal__parse_pred_expr_args_3_0),
		mercury__prog_io_goal__parse_pred_expression_5_0_i17,
		ENTRY(mercury__prog_io_goal__parse_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_pred_expression_5_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	r4 = r3;
	r3 = r2;
	r1 = TRUE;
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1023);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_pred_expression_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module7)
	init_entry(mercury__prog_io_goal__parse_dcg_pred_expression_5_0);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i11);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i13);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i17);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
BEGIN_CODE

/* code for predicate 'parse_dcg_pred_expression'/5 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_dcg_pred_expression_5_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_dcg_pred_expression/5");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i11,
		ENTRY(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_eval_method_3_0),
		mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i13,
		ENTRY(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0),
		mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i17,
		ENTRY(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	r4 = r3;
	r3 = r2;
	r1 = TRUE;
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1023);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_dcg_pred_expression_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__mode_util__in_mode_1_0);
Declare_entry(mercury__mode_util__out_mode_1_0);
Declare_entry(mercury__list__length_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(prog_io_goal_module8)
	init_entry(mercury__prog_io_goal__parse_func_expression_5_0);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i9);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i13);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i14);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i15);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i16);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i17);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i18);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i19);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i8);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i30);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i32);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i36);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i38);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i40);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i41);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	init_label(mercury__prog_io_goal__parse_func_expression_5_0_i1);
BEGIN_CODE

/* code for predicate 'parse_func_expression'/5 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_func_expression_5_0);
	MR_incr_sp_push_msg(6, "prog_io_goal:parse_func_expression/5");
	MR_stackvar(6) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i8);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_eval_method_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i9,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i13,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__mode_util__out_mode_1_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i14,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_5);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i15,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i16,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i16);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_func_expression_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_goal__parse_func_expression_5_0_i17,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_func_expression_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_goal__parse_func_expression_5_0_i18,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_5);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_8);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i19,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i19);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r4 = MR_stackvar(2);
	r5 = (Integer) 0;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i8);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i30,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i30);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_eval_method_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i32,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i32);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(STATIC(mercury__prog_io_goal__parse_pred_expr_args_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i36,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i36);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_lambda_arg_3_0),
		mercury__prog_io_goal__parse_func_expression_5_0_i38,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i38);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	r5 = r2;
	r2 = MR_stackvar(2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_6);
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_func_expression_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_goal__parse_func_expression_5_0_i40,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i40);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r4 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_func_expression_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_goal__parse_func_expression_5_0_i41,
		ENTRY(mercury__prog_io_goal__parse_func_expression_5_0));
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i41);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_func_expression_5_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = r1;
	r5 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i1033);
	r1 = FALSE;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_io_goal__parse_func_expression_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module9)
	init_entry(mercury__prog_io_goal__parse_lambda_eval_method_3_0);
	init_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i7);
	init_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
BEGIN_CODE

/* code for predicate 'parse_lambda_eval_method'/3 in mode 0 */
Define_entry(mercury__prog_io_goal__parse_lambda_eval_method_3_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	r5 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r6 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r6, (char *)(Word) MR_string_const("aditi_bottom_up", 15)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i7);
	r1 = (Integer) 2;
	r2 = r5;
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i7);
	if ((strcmp((char *)r6, (char *)(Word) MR_string_const("aditi_top_down", 14)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	r1 = (Integer) 1;
	r2 = r5;
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_eval_method_3_0_i2);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__term__vars_2_0);

BEGIN_MODULE(prog_io_goal_module10)
	init_entry(mercury__prog_io_goal__parse_goal_2_5_0);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i3);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i1002);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i5);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i6);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i10);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i11);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i12);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i16);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i20);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i22);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i23);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i24);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i28);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i43);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i44);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i45);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i46);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i50);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i51);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i52);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i56);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i57);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i58);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i62);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i63);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i64);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i65);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i67);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i71);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i72);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i73);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i77);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i78);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i79);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i82);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i83);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i85);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i88);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i89);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i93);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i95);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i106);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i107);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i108);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i109);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i110);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i112);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i116);
	init_label(mercury__prog_io_goal__parse_goal_2_5_0_i1148);
BEGIN_CODE

/* code for predicate 'parse_goal_2'/5 in mode 0 */
Define_static(mercury__prog_io_goal__parse_goal_2_5_0);
	r4 = (hash_string(r1) & (Integer) 63);
	MR_incr_sp_push_msg(4, "prog_io_goal:parse_goal_2/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_9))[(Integer) r4];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1002);
	if ((strcmp((char *)MR_tempr1, (char *)r1) == 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i5);
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i1002);
	r4 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_10))[(Integer) r4];
	if (((Integer) r4 >= (Integer) 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i3);
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i5);
	COMPUTED_GOTO((Unsigned) r4,
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i6) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i12) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i16) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i24) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i28) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i46) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i52) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i58) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i65) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i67) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i73) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i79) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i83) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i85) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i89) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i95) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i112) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001) AND
		LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i6);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i10,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i11,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i12);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r3;
	r3 = (Integer) 1;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_with_purity_5_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i82,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i16);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__prog_io_util__parse_list_of_vars_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i20,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i20);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_goal__common_12);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i22,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i23,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i24);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i88,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i28);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("if", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("then", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 1), (Integer) 0);
	r4 = r2;
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_some_vars_goal_5_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i43,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i43);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i44,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i44);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i45,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 5, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 4) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i46);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i50,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i50);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i51,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i51);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i52);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i56,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i56);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i57,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i57);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i58);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i62,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i62);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__vars_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i63,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i63);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i64,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i64);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i65);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i67);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i71,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i71);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i72,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i72);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i73);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i77,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i77);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i78,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i78);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i79);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r3;
	r3 = (Integer) 2;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_with_purity_5_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i82,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i82);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i83);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i85);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i88,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i88);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i89);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i93,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i93);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i1148,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i95);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	r5 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r5, (Integer) 0), (char *)(Word) MR_string_const("->", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	r5 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	if (((Integer) MR_const_field(MR_mktag(1), r5, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r5, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r5, (Integer) 1), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_some_vars_goal_5_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i106,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i106);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(3) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i107,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i107);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i108,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i108);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 5, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 4) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i99);
	MR_stackvar(1) = r1;
	r1 = r4;
	r2 = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i109,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i109);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i110,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i110);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i112);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_2_5_0_i1001);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i116,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
	}
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i116);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_2_5_0_i1148,
		STATIC(mercury__prog_io_goal__parse_goal_2_5_0));
Define_label(mercury__prog_io_goal__parse_goal_2_5_0_i1148);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_2_5_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_goal__parse_goal_2_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	r3 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__purity__purity_name_2_0);

BEGIN_MODULE(prog_io_goal_module11)
	init_entry(mercury__prog_io_goal__parse_goal_with_purity_5_0);
	init_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i2);
	init_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
	init_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i6);
	init_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i7);
BEGIN_CODE

/* code for predicate 'parse_goal_with_purity'/5 in mode 0 */
Define_static(mercury__prog_io_goal__parse_goal_with_purity_5_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_goal_with_purity/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_io_goal__parse_goal_4_0),
		mercury__prog_io_goal__parse_goal_with_purity_5_0_i2,
		STATIC(mercury__prog_io_goal__parse_goal_with_purity_5_0));
Define_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 3) != (Integer) 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__prog_io_goal__parse_goal_with_purity_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i3);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__purity__purity_name_2_0),
		mercury__prog_io_goal__parse_goal_with_purity_5_0_i6,
		STATIC(mercury__prog_io_goal__parse_goal_with_purity_5_0));
Define_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_goal_with_purity_5_0_i7,
		STATIC(mercury__prog_io_goal__parse_goal_with_purity_5_0));
Define_label(mercury__prog_io_goal__parse_goal_with_purity_5_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_goal_with_purity_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__prog_io_goal__parse_goal_with_purity_5_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__prog_io_goal__parse_goal_with_purity_5_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_goal_with_purity_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__prog_io_util__convert_mode_2_0);

BEGIN_MODULE(prog_io_goal_module12)
	init_entry(mercury__prog_io_goal__parse_lambda_args_3_0);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i15);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i16);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i18);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i31);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i32);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	init_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
BEGIN_CODE

/* code for predicate 'parse_lambda_args'/3 in mode 0 */
Define_static(mercury__prog_io_goal__parse_lambda_args_3_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_lambda_args/3");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const(".", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("::", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 0);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_lambda_args_3_0_i15,
		STATIC(mercury__prog_io_goal__parse_lambda_args_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_lambda_args_3_0_i16,
		STATIC(mercury__prog_io_goal__parse_lambda_args_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i16);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_goal__parse_lambda_args_3_0,
		LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i18),
		STATIC(mercury__prog_io_goal__parse_lambda_args_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_lambda_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_lambda_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("[]", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i20);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("::", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_lambda_args_3_0_i31,
		STATIC(mercury__prog_io_goal__parse_lambda_args_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i31);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_lambda_args_3_0_i32,
		STATIC(mercury__prog_io_goal__parse_lambda_args_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i32);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_lambda_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_lambda_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1040);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_args_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module13)
	init_entry(mercury__prog_io_goal__parse_lambda_arg_3_0);
	init_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i8);
	init_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i9);
	init_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	init_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1);
BEGIN_CODE

/* code for predicate 'parse_lambda_arg'/3 in mode 0 */
Define_static(mercury__prog_io_goal__parse_lambda_arg_3_0);
	MR_incr_sp_push_msg(2, "prog_io_goal:parse_lambda_arg/3");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("::", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_lambda_arg_3_0_i8,
		STATIC(mercury__prog_io_goal__parse_lambda_arg_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_lambda_arg_3_0_i9,
		STATIC(mercury__prog_io_goal__parse_lambda_arg_3_0));
Define_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_lambda_arg_3_0_i1);
	r3 = r2;
	r1 = TRUE;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1013);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_goal__parse_lambda_arg_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module14)
	init_entry(mercury__prog_io_goal__parse_pred_expr_args_3_0);
	init_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i3);
	init_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i10);
	init_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i11);
	init_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i13);
	init_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
BEGIN_CODE

/* code for predicate 'parse_pred_expr_args'/3 in mode 0 */
Define_static(mercury__prog_io_goal__parse_pred_expr_args_3_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_pred_expr_args/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i3);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("::", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 0);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_pred_expr_args_3_0_i10,
		STATIC(mercury__prog_io_goal__parse_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_pred_expr_args_3_0_i11,
		STATIC(mercury__prog_io_goal__parse_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_goal__parse_pred_expr_args_3_0,
		LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i13),
		STATIC(mercury__prog_io_goal__parse_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_pred_expr_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_pred_expr_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_pred_expr_args_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_goal_module15)
	init_entry(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i6);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i8);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i5);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i16);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i17);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i19);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1018);
	init_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
BEGIN_CODE

/* code for predicate 'parse_dcg_pred_expr_args'/3 in mode 0 */
Define_static(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0);
	MR_incr_sp_push_msg(3, "prog_io_goal:parse_dcg_pred_expr_args/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1018);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1018);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i6,
		STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i8,
		STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	r1 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("::", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 0), (Integer) 1), (Integer) 0);
	call_localret(ENTRY(mercury__term__coerce_2_0),
		mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i16,
		STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i16);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i17,
		STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	localcall(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0,
		LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i19),
		STATIC(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i19);
	update_prof_current_proc(LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1018);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_goal__parse_dcg_pred_expr_args_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__prog_io_goal_maybe_bunch_0(void)
{
	prog_io_goal_module0();
	prog_io_goal_module1();
	prog_io_goal_module2();
	prog_io_goal_module3();
	prog_io_goal_module4();
	prog_io_goal_module5();
	prog_io_goal_module6();
	prog_io_goal_module7();
	prog_io_goal_module8();
	prog_io_goal_module9();
	prog_io_goal_module10();
	prog_io_goal_module11();
	prog_io_goal_module12();
	prog_io_goal_module13();
	prog_io_goal_module14();
	prog_io_goal_module15();
}

#endif

void mercury__prog_io_goal__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__prog_io_goal__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__prog_io_goal_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
