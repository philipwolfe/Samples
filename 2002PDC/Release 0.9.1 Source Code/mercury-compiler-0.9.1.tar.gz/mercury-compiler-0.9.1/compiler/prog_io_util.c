/*
** Automatically generated from `prog_io_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__prog_io_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0);
Declare_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i1006);
Declare_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i8);
Declare_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
Define_extern_entry(mercury__prog_io_util__add_context_3_0);
Declare_label(mercury__prog_io_util__add_context_3_0_i3);
Define_extern_entry(mercury__prog_io_util__parse_list_of_vars_2_0);
Declare_label(mercury__prog_io_util__parse_list_of_vars_2_0_i5);
Declare_label(mercury__prog_io_util__parse_list_of_vars_2_0_i11);
Declare_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
Declare_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
Define_extern_entry(mercury__prog_io_util__parse_name_and_arity_4_0);
Declare_label(mercury__prog_io_util__parse_name_and_arity_4_0_i8);
Declare_label(mercury__prog_io_util__parse_name_and_arity_4_0_i10);
Declare_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
Declare_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
Define_extern_entry(mercury__prog_io_util__parse_name_and_arity_3_0);
Define_extern_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0);
Declare_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i5);
Declare_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i4);
Declare_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i9);
Declare_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1009);
Declare_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
Define_extern_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_4_0);
Define_extern_entry(mercury__prog_io_util__parse_pred_or_func_and_args_5_0);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i9);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i11);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i10);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i14);
Define_extern_entry(mercury__prog_io_util__parse_pred_or_func_and_args_4_0);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i2);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i5);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i6);
Declare_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i1);
Define_extern_entry(mercury__prog_io_util__convert_mode_list_2_0);
Declare_label(mercury__prog_io_util__convert_mode_list_2_0_i3);
Declare_label(mercury__prog_io_util__convert_mode_list_2_0_i4);
Declare_label(mercury__prog_io_util__convert_mode_list_2_0_i6);
Declare_label(mercury__prog_io_util__convert_mode_list_2_0_i1);
Define_extern_entry(mercury__prog_io_util__convert_mode_2_0);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i9);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i11);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i2);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i26);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i28);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i13);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i49);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i51);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i53);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i1103);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i30);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i56);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i58);
Declare_label(mercury__prog_io_util__convert_mode_2_0_i1);
Define_extern_entry(mercury__prog_io_util__convert_inst_list_2_0);
Declare_label(mercury__prog_io_util__convert_inst_list_2_0_i3);
Declare_label(mercury__prog_io_util__convert_inst_list_2_0_i4);
Declare_label(mercury__prog_io_util__convert_inst_list_2_0_i6);
Declare_label(mercury__prog_io_util__convert_inst_list_2_0_i1);
Define_extern_entry(mercury__prog_io_util__convert_inst_2_0);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i4);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i8);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i12);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i16);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i20);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i24);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i28);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i32);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i36);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i40);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i44);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i60);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i62);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i48);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i82);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i84);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i86);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i1167);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i64);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i89);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i93);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i100);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i107);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i114);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i121);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i123);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i3);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i1193);
Declare_label(mercury__prog_io_util__convert_inst_2_0_i1);
Define_extern_entry(mercury__prog_io_util__standard_det_2_0);
Declare_label(mercury__prog_io_util__standard_det_2_0_i3);
Declare_label(mercury__prog_io_util__standard_det_2_0_i1002);
Declare_label(mercury__prog_io_util__standard_det_2_0_i1001);
Declare_label(mercury__prog_io_util__standard_det_2_0_i5);
Declare_label(mercury__prog_io_util__standard_det_2_0_i6);
Declare_label(mercury__prog_io_util__standard_det_2_0_i7);
Declare_label(mercury__prog_io_util__standard_det_2_0_i8);
Declare_label(mercury__prog_io_util__standard_det_2_0_i9);
Declare_label(mercury__prog_io_util__standard_det_2_0_i11);
Declare_label(mercury__prog_io_util__standard_det_2_0_i12);
Declare_label(mercury__prog_io_util__standard_det_2_0_i13);
Declare_label(mercury__prog_io_util__standard_det_2_0_i14);
Define_extern_entry(mercury__prog_io_util__disjunction_to_list_2_0);
Define_extern_entry(mercury__prog_io_util__conjunction_to_list_2_0);
Define_extern_entry(mercury__prog_io_util__sum_to_list_2_0);
Define_extern_entry(mercury__prog_io_util__report_warning_3_0);
Declare_label(mercury__prog_io_util__report_warning_3_0_i2);
Declare_label(mercury__prog_io_util__report_warning_3_0_i3);
Declare_label(mercury__prog_io_util__report_warning_3_0_i6);
Declare_label(mercury__prog_io_util__report_warning_3_0_i4);
Define_extern_entry(mercury__prog_io_util__report_warning_4_0);
Declare_label(mercury__prog_io_util__report_warning_4_0_i2);
Declare_label(mercury__prog_io_util__report_warning_4_0_i5);
Declare_label(mercury__prog_io_util__report_warning_4_0_i3);
Define_extern_entry(mercury__prog_io_util__report_warning_5_0);
Declare_label(mercury__prog_io_util__report_warning_5_0_i2);
Declare_label(mercury__prog_io_util__report_warning_5_0_i3);
Declare_label(mercury__prog_io_util__report_warning_5_0_i4);
Declare_label(mercury__prog_io_util__report_warning_5_0_i5);
Declare_label(mercury__prog_io_util__report_warning_5_0_i6);
Declare_static(mercury__prog_io_util__parse_bound_inst_list_3_0);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i2);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i3);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i5);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1011);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1015);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i8);
Declare_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1);
Declare_static(mercury__prog_io_util__convert_bound_inst_list_2_0);
Declare_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i3);
Declare_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i4);
Declare_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i6);
Declare_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i1);
Declare_static(mercury__prog_io_util__convert_bound_inst_2_0);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i5);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i7);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i3);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i8);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i9);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i11);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i1006);
Declare_label(mercury__prog_io_util__convert_bound_inst_2_0_i1);
Define_extern_entry(mercury____Unify___prog_io_util__maybe2_2_0);
Declare_label(mercury____Unify___prog_io_util__maybe2_2_0_i3);
Declare_label(mercury____Unify___prog_io_util__maybe2_2_0_i8);
Declare_label(mercury____Unify___prog_io_util__maybe2_2_0_i1008);
Declare_label(mercury____Unify___prog_io_util__maybe2_2_0_i1);
Define_extern_entry(mercury____Index___prog_io_util__maybe2_2_0);
Declare_label(mercury____Index___prog_io_util__maybe2_2_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe2_2_0);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i3);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i2);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i5);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i4);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i6);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i7);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i14);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i11);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i21);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i9);
Declare_label(mercury____Compare___prog_io_util__maybe2_2_0_i29);
Define_extern_entry(mercury____Unify___prog_io_util__maybe1_1_0);
Define_extern_entry(mercury____Index___prog_io_util__maybe1_1_0);
Declare_label(mercury____Index___prog_io_util__maybe1_1_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe1_1_0);
Define_extern_entry(mercury____Unify___prog_io_util__maybe1_2_0);
Declare_label(mercury____Unify___prog_io_util__maybe1_2_0_i3);
Declare_label(mercury____Unify___prog_io_util__maybe1_2_0_i1);
Define_extern_entry(mercury____Index___prog_io_util__maybe1_2_0);
Declare_label(mercury____Index___prog_io_util__maybe1_2_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe1_2_0);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i3);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i2);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i5);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i4);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i6);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i7);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i14);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i11);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i9);
Declare_label(mercury____Compare___prog_io_util__maybe1_2_0_i24);
Define_extern_entry(mercury____Unify___prog_io_util__maybe_functor_0_0);
Define_extern_entry(mercury____Index___prog_io_util__maybe_functor_0_0);
Declare_label(mercury____Index___prog_io_util__maybe_functor_0_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe_functor_0_0);
Define_extern_entry(mercury____Unify___prog_io_util__maybe_functor_1_0);
Define_extern_entry(mercury____Index___prog_io_util__maybe_functor_1_0);
Declare_label(mercury____Index___prog_io_util__maybe_functor_1_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe_functor_1_0);
Define_extern_entry(mercury____Unify___prog_io_util__maybe_pred_or_func_1_0);
Define_extern_entry(mercury____Index___prog_io_util__maybe_pred_or_func_1_0);
Declare_label(mercury____Index___prog_io_util__maybe_pred_or_func_1_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe_pred_or_func_1_0);
Define_extern_entry(mercury____Unify___prog_io_util__maybe_item_and_context_0_0);
Define_extern_entry(mercury____Index___prog_io_util__maybe_item_and_context_0_0);
Declare_label(mercury____Index___prog_io_util__maybe_item_and_context_0_0_i3);
Define_extern_entry(mercury____Compare___prog_io_util__maybe_item_and_context_0_0);
Define_extern_entry(mercury____Unify___prog_io_util__var2tvar_0_0);
Define_extern_entry(mercury____Index___prog_io_util__var2tvar_0_0);
Define_extern_entry(mercury____Compare___prog_io_util__var2tvar_0_0);
Define_extern_entry(mercury____Unify___prog_io_util__var2pvar_0_0);
Define_extern_entry(mercury____Index___prog_io_util__var2pvar_0_0);
Define_extern_entry(mercury____Compare___prog_io_util__var2pvar_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe1_1;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe1_2;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe2_2;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_functor_0;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_functor_1;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_item_and_context_0;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_pred_or_func_1;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_var2pvar_0;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_var2tvar_0;

static const struct mercury_data_prog_io_util__common_0_struct {
	String f1;
}  mercury_data_prog_io_util__common_0;

static const struct mercury_data_prog_io_util__common_1_struct {
	Integer f1;
}  mercury_data_prog_io_util__common_1;

static const struct mercury_data_prog_io_util__common_2_struct {
	Integer f1;
}  mercury_data_prog_io_util__common_2;

static const struct mercury_data_prog_io_util__common_3_struct {
	Integer f1;
}  mercury_data_prog_io_util__common_3;

static const struct mercury_data_prog_io_util__common_4_struct {
	Integer f1;
}  mercury_data_prog_io_util__common_4;

static const struct mercury_data_prog_io_util__common_5_struct {
	Integer f1;
}  mercury_data_prog_io_util__common_5;

static const struct mercury_data_prog_io_util__common_6_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_6;

static const struct mercury_data_prog_io_util__common_7_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_7;

static const struct mercury_data_prog_io_util__common_8_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_8;

static const struct mercury_data_prog_io_util__common_9_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_9;

static const struct mercury_data_prog_io_util__common_10_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_10;

static const struct mercury_data_prog_io_util__common_11_struct {
	String f1;
	String f2;
	String f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	String f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	String f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	String f21;
	Integer f22;
	String f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	String f29;
	Integer f30;
	String f31;
	Integer f32;
}  mercury_data_prog_io_util__common_11;

static const struct mercury_data_prog_io_util__common_12_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_prog_io_util__common_12;

static const struct mercury_data_prog_io_util__common_13_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_13;

static const struct mercury_data_prog_io_util__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_14;

static const struct mercury_data_prog_io_util__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_15;

static const struct mercury_data_prog_io_util__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_16;

static const struct mercury_data_prog_io_util__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_17;

static const struct mercury_data_prog_io_util__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_18;

static const struct mercury_data_prog_io_util__common_19_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_19;

static const struct mercury_data_prog_io_util__common_20_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_20;

static const struct mercury_data_prog_io_util__common_21_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_21;

static const struct mercury_data_prog_io_util__common_22_struct {
	Word * f1;
	Integer f2;
}  mercury_data_prog_io_util__common_22;

static const struct mercury_data_prog_io_util__common_23_struct {
	Word * f1;
	Integer f2;
}  mercury_data_prog_io_util__common_23;

static const struct mercury_data_prog_io_util__common_24_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_24;

static const struct mercury_data_prog_io_util__common_25_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_25;

static const struct mercury_data_prog_io_util__common_26_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_26;

static const struct mercury_data_prog_io_util__common_27_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_27;

static const struct mercury_data_prog_io_util__common_28_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_28;

static const struct mercury_data_prog_io_util__common_29_struct {
	Word * f1;
	Integer f2;
}  mercury_data_prog_io_util__common_29;

static const struct mercury_data_prog_io_util__common_30_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_io_util__common_30;

static const struct mercury_data_prog_io_util__common_31_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_31;

static const struct mercury_data_prog_io_util__common_32_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_32;

static const struct mercury_data_prog_io_util__common_33_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_io_util__common_33;

static const struct mercury_data_prog_io_util__common_34_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_34;

static const struct mercury_data_prog_io_util__common_35_struct {
	Word * f1;
}  mercury_data_prog_io_util__common_35;

static const struct mercury_data_prog_io_util__common_36_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_prog_io_util__common_36;

static const struct mercury_data_prog_io_util__common_37_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_prog_io_util__common_37;

static const struct mercury_data_prog_io_util__common_38_struct {
	Word * f1;
	Integer f2;
}  mercury_data_prog_io_util__common_38;

static const struct mercury_data_prog_io_util__common_39_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_prog_io_util__common_39;

static const struct mercury_data_prog_io_util__common_40_struct {
	Integer f1;
	Integer f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_prog_io_util__common_40;

static const struct mercury_data_prog_io_util__common_41_struct {
	Word * f1;
	Integer f2;
	Word * f3;
}  mercury_data_prog_io_util__common_41;

static const struct mercury_data_prog_io_util__common_42_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__common_42;

static const struct mercury_data_prog_io_util__type_ctor_functors_var2tvar_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_var2tvar_0;

static const struct mercury_data_prog_io_util__type_ctor_layout_var2tvar_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_var2tvar_0;

static const struct mercury_data_prog_io_util__type_ctor_functors_var2pvar_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_var2pvar_0;

static const struct mercury_data_prog_io_util__type_ctor_layout_var2pvar_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_var2pvar_0;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_pred_or_func_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_maybe_pred_or_func_1;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_pred_or_func_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe_pred_or_func_1;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_item_and_context_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_maybe_item_and_context_0;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_item_and_context_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe_item_and_context_0;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_maybe_functor_1;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe_functor_1;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_maybe_functor_0;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe_functor_0;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe2_2_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_functors_maybe2_2;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe2_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe2_2;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe1_2_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_functors_maybe1_2;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe1_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe1_2;

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe1_1_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_io_util__type_ctor_functors_maybe1_1;

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe1_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_io_util__type_ctor_layout_maybe1_1;

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe1_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___prog_io_util__maybe1_1_0),
	ENTRY(mercury____Index___prog_io_util__maybe1_1_0),
	ENTRY(mercury____Compare___prog_io_util__maybe1_1_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe1_1,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe1_1,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe1", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe1_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___prog_io_util__maybe1_2_0),
	ENTRY(mercury____Index___prog_io_util__maybe1_2_0),
	ENTRY(mercury____Compare___prog_io_util__maybe1_2_0),
	(Integer) 2,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe1_2,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe1_2,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe1", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe2_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___prog_io_util__maybe2_2_0),
	ENTRY(mercury____Index___prog_io_util__maybe2_2_0),
	ENTRY(mercury____Compare___prog_io_util__maybe2_2_0),
	(Integer) 2,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe2_2,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe2_2,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe2", 6),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_functor_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_io_util__maybe_functor_0_0),
	ENTRY(mercury____Index___prog_io_util__maybe_functor_0_0),
	ENTRY(mercury____Compare___prog_io_util__maybe_functor_0_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe_functor_0,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe_functor_0,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe_functor", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_functor_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___prog_io_util__maybe_functor_1_0),
	ENTRY(mercury____Index___prog_io_util__maybe_functor_1_0),
	ENTRY(mercury____Compare___prog_io_util__maybe_functor_1_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe_functor_1,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe_functor_1,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe_functor", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_item_and_context_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_io_util__maybe_item_and_context_0_0),
	ENTRY(mercury____Index___prog_io_util__maybe_item_and_context_0_0),
	ENTRY(mercury____Compare___prog_io_util__maybe_item_and_context_0_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe_item_and_context_0,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe_item_and_context_0,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe_item_and_context", 22),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_maybe_pred_or_func_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___prog_io_util__maybe_pred_or_func_1_0),
	ENTRY(mercury____Index___prog_io_util__maybe_pred_or_func_1_0),
	ENTRY(mercury____Compare___prog_io_util__maybe_pred_or_func_1_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_maybe_pred_or_func_1,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_maybe_pred_or_func_1,
	MR_string_const("prog_io_util", 12),
	MR_string_const("maybe_pred_or_func", 18),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_var2pvar_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_io_util__var2pvar_0_0),
	ENTRY(mercury____Index___prog_io_util__var2pvar_0_0),
	ENTRY(mercury____Compare___prog_io_util__var2pvar_0_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_var2pvar_0,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_var2pvar_0,
	MR_string_const("prog_io_util", 12),
	MR_string_const("var2pvar", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_io_util__type_ctor_info_var2tvar_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_io_util__var2tvar_0_0),
	ENTRY(mercury____Index___prog_io_util__var2tvar_0_0),
	ENTRY(mercury____Compare___prog_io_util__var2tvar_0_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_io_util__type_ctor_functors_var2tvar_0,
	(Word *) &mercury_data_prog_io_util__type_ctor_layout_var2tvar_0,
	MR_string_const("prog_io_util", 12),
	MR_string_const("var2tvar", 8),
	(Integer) 3
};

static const struct mercury_data_prog_io_util__common_0_struct mercury_data_prog_io_util__common_0 = {
	MR_string_const("", 0)
};

static const struct mercury_data_prog_io_util__common_1_struct mercury_data_prog_io_util__common_1 = {
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_2_struct mercury_data_prog_io_util__common_2 = {
	(Integer) 1
};

static const struct mercury_data_prog_io_util__common_3_struct mercury_data_prog_io_util__common_3 = {
	(Integer) 2
};

static const struct mercury_data_prog_io_util__common_4_struct mercury_data_prog_io_util__common_4 = {
	(Integer) 3
};

static const struct mercury_data_prog_io_util__common_5_struct mercury_data_prog_io_util__common_5 = {
	(Integer) 4
};

static const struct mercury_data_prog_io_util__common_6_struct mercury_data_prog_io_util__common_6 = {
	(Integer) 1,
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_io_util__common_7_struct mercury_data_prog_io_util__common_7 = {
	(Integer) 1,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_io_util__common_8_struct mercury_data_prog_io_util__common_8 = {
	(Integer) 1,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_io_util__common_9_struct mercury_data_prog_io_util__common_9 = {
	(Integer) 1,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_io_util__common_10_struct mercury_data_prog_io_util__common_10 = {
	(Integer) 1,
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_io_util__common_11_struct mercury_data_prog_io_util__common_11 = {
	MR_string_const("semidet", 7),
	MR_string_const("erroneous", 9),
	MR_string_const("cc_nondet", 9),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("failure", 7),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("multi", 5),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("multidet", 8),
	(Integer) 0,
	MR_string_const("det", 3),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("nondet", 6),
	(Integer) 0,
	MR_string_const("cc_multi", 8),
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_12_struct mercury_data_prog_io_util__common_12 = {
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) 2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_prog_io_util__common_13_struct mercury_data_prog_io_util__common_13 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_prog_io_util__common_14_struct mercury_data_prog_io_util__common_14 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_13)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
static const struct mercury_data_prog_io_util__common_15_struct mercury_data_prog_io_util__common_15 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_prog_io_util__common_16_struct mercury_data_prog_io_util__common_16 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_prog_io_util__common_17_struct mercury_data_prog_io_util__common_17 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_prog_io_util__common_18_struct mercury_data_prog_io_util__common_18 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_16)
};

static const struct mercury_data_prog_io_util__common_19_struct mercury_data_prog_io_util__common_19 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_18)
};

static const struct mercury_data_prog_io_util__common_20_struct mercury_data_prog_io_util__common_20 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_17)
};

static const struct mercury_data_prog_io_util__common_21_struct mercury_data_prog_io_util__common_21 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_20)
};

static const struct mercury_data_prog_io_util__common_22_struct mercury_data_prog_io_util__common_22 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Integer) 1
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_prog_io_util__common_23_struct mercury_data_prog_io_util__common_23 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Integer) 1
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_prog_io_util__common_24_struct mercury_data_prog_io_util__common_24 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_23)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_prog_io_util__common_25_struct mercury_data_prog_io_util__common_25 = {
	(Word *) &mercury_data_prog_io_util__type_ctor_info_maybe2_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_24)
};

static const struct mercury_data_prog_io_util__common_26_struct mercury_data_prog_io_util__common_26 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_25)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_item_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_prog_io_util__common_27_struct mercury_data_prog_io_util__common_27 = {
	(Word *) &mercury_data_prog_io_util__type_ctor_info_maybe2_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_item_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_prog_io_util__common_28_struct mercury_data_prog_io_util__common_28 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_27)
};

static const struct mercury_data_prog_io_util__common_29_struct mercury_data_prog_io_util__common_29 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Integer) 1
};

static const struct mercury_data_prog_io_util__common_30_struct mercury_data_prog_io_util__common_30 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_29)
};

static const struct mercury_data_prog_io_util__common_31_struct mercury_data_prog_io_util__common_31 = {
	(Word *) &mercury_data_prog_io_util__type_ctor_info_maybe2_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_30)
};

static const struct mercury_data_prog_io_util__common_32_struct mercury_data_prog_io_util__common_32 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_31)
};

static const struct mercury_data_prog_io_util__common_33_struct mercury_data_prog_io_util__common_33 = {
	(Word *) &mercury_data_prog_io_util__type_ctor_info_maybe2_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_14)
};

static const struct mercury_data_prog_io_util__common_34_struct mercury_data_prog_io_util__common_34 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_33)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_prog_io_util__common_35_struct mercury_data_prog_io_util__common_35 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_prog_io_util__common_36_struct mercury_data_prog_io_util__common_36 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_35),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_13),
	MR_string_const("error", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_37_struct mercury_data_prog_io_util__common_37 = {
	(Integer) 2,
	(Integer) 1,
	(Integer) 2,
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_38_struct mercury_data_prog_io_util__common_38 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Integer) 2
};

static const struct mercury_data_prog_io_util__common_39_struct mercury_data_prog_io_util__common_39 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_35),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_38),
	MR_string_const("error", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_40_struct mercury_data_prog_io_util__common_40 = {
	(Integer) 1,
	(Integer) 1,
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_prog_io_util__common_41_struct mercury_data_prog_io_util__common_41 = {
	(Word *) &mercury_data_prog_io_util__type_ctor_info_maybe1_2,
	(Integer) 1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

static const struct mercury_data_prog_io_util__common_42_struct mercury_data_prog_io_util__common_42 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_41)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_var2tvar_0_struct mercury_data_prog_io_util__type_ctor_functors_var2tvar_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_18)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_var2tvar_0_struct mercury_data_prog_io_util__type_ctor_layout_var2tvar_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_19),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_19)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_var2pvar_0_struct mercury_data_prog_io_util__type_ctor_functors_var2pvar_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_20)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_var2pvar_0_struct mercury_data_prog_io_util__type_ctor_layout_var2pvar_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_21),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_21)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_pred_or_func_1_struct mercury_data_prog_io_util__type_ctor_functors_maybe_pred_or_func_1 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_25)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_pred_or_func_1_struct mercury_data_prog_io_util__type_ctor_layout_maybe_pred_or_func_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_26)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_item_and_context_0_struct mercury_data_prog_io_util__type_ctor_functors_maybe_item_and_context_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_27)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_item_and_context_0_struct mercury_data_prog_io_util__type_ctor_layout_maybe_item_and_context_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_28)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_1_struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_1 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_31)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_1_struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_32)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_0_struct mercury_data_prog_io_util__type_ctor_functors_maybe_functor_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_33)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_0_struct mercury_data_prog_io_util__type_ctor_layout_maybe_functor_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_34)
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe2_2_struct mercury_data_prog_io_util__type_ctor_functors_maybe2_2 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_36),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_37)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe2_2_struct mercury_data_prog_io_util__type_ctor_layout_maybe2_2 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_36),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_37),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe1_2_struct mercury_data_prog_io_util__type_ctor_functors_maybe1_2 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_39),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_40)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe1_2_struct mercury_data_prog_io_util__type_ctor_layout_maybe1_2 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_39),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_40),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_prog_io_util__type_ctor_functors_maybe1_1_struct mercury_data_prog_io_util__type_ctor_functors_maybe1_1 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_41)
};

static const struct mercury_data_prog_io_util__type_ctor_layout_maybe1_1_struct mercury_data_prog_io_util__type_ctor_layout_maybe1_1 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_42)
};


BEGIN_MODULE(prog_io_util_module0)
	init_entry(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0);
	init_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i1006);
	init_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i8);
	init_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
BEGIN_CODE

/* code for predicate 'binop_term_to_list_2__ua0'/4 in mode 0 */
Define_static(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0);
	MR_incr_sp_push_msg(3, "prog_io_util:binop_term_to_list_2__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i1006);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	if ((strcmp((char *)r1, (char *)MR_const_field(MR_mktag(0), r4, (Integer) 0)) != 0))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
	localcall(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0,
		LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i8),
		STATIC(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0));
Define_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i1006);
Define_label(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_io_util__binop_term_to_list_2__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module1)
	init_entry(mercury__prog_io_util__add_context_3_0);
	init_label(mercury__prog_io_util__add_context_3_0_i3);
BEGIN_CODE

/* code for predicate 'add_context'/3 in mode 0 */
Define_entry(mercury__prog_io_util__add_context_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__add_context_3_0_i3);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_util__add_context_3_0, "prog_io_util:maybe2/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
Define_label(mercury__prog_io_util__add_context_3_0_i3);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_io_util__add_context_3_0, "prog_io_util:maybe2/2");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module2)
	init_entry(mercury__prog_io_util__parse_list_of_vars_2_0);
	init_label(mercury__prog_io_util__parse_list_of_vars_2_0_i5);
	init_label(mercury__prog_io_util__parse_list_of_vars_2_0_i11);
	init_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
	init_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
BEGIN_CODE

/* code for predicate 'parse_list_of_vars'/2 in mode 0 */
Define_entry(mercury__prog_io_util__parse_list_of_vars_2_0);
	MR_incr_sp_push_msg(2, "prog_io_util:parse_list_of_vars/2");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("[]", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__parse_list_of_vars_2_0_i5);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0);
	if ((strcmp((char *)r3, (char *)(Word) MR_string_const(".", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	MR_tempr4 = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	if ((MR_tag(MR_tempr4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr4, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	localcall(mercury__prog_io_util__parse_list_of_vars_2_0,
		LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i11),
		ENTRY(mercury__prog_io_util__parse_list_of_vars_2_0));
	}
Define_label(mercury__prog_io_util__parse_list_of_vars_2_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_list_of_vars_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__parse_list_of_vars_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1013);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__parse_list_of_vars_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__prog_io__parse_implicitly_qualified_term_5_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(prog_io_util_module3)
	init_entry(mercury__prog_io_util__parse_name_and_arity_4_0);
	init_label(mercury__prog_io_util__parse_name_and_arity_4_0_i8);
	init_label(mercury__prog_io_util__parse_name_and_arity_4_0_i10);
	init_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	init_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
BEGIN_CODE

/* code for predicate 'parse_name_and_arity'/4 in mode 0 */
Define_entry(mercury__prog_io_util__parse_name_and_arity_4_0);
	MR_incr_sp_push_msg(3, "prog_io_util:parse_name_and_arity/4");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	if ((MR_tag(MR_const_field(MR_mktag(0), r3, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("/", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_stackvar(1) = r1;
	r4 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r4, (Integer) 1), (Integer) 0);
	r5 = r4;
	r4 = r3;
	r6 = r5;
	r5 = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__prog_io__parse_implicitly_qualified_term_5_0),
		mercury__prog_io_util__parse_name_and_arity_4_0_i8,
		ENTRY(mercury__prog_io_util__parse_name_and_arity_4_0));
Define_label(mercury__prog_io_util__parse_name_and_arity_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_name_and_arity_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_util__parse_name_and_arity_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__prog_io_util__parse_name_and_arity_4_0_i10,
		ENTRY(mercury__prog_io_util__parse_name_and_arity_4_0));
	}
Define_label(mercury__prog_io_util__parse_name_and_arity_4_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_name_and_arity_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	r2 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1017);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__parse_name_and_arity_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module4)
	init_entry(mercury__prog_io_util__parse_name_and_arity_3_0);
BEGIN_CODE

/* code for predicate 'parse_name_and_arity'/3 in mode 0 */
Define_entry(mercury__prog_io_util__parse_name_and_arity_3_0);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_0);
	tailcall(STATIC(mercury__prog_io_util__parse_name_and_arity_4_0),
		ENTRY(mercury__prog_io_util__parse_name_and_arity_3_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module5)
	init_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0);
	init_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i5);
	init_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i4);
	init_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i9);
	init_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1009);
	init_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
BEGIN_CODE

/* code for predicate 'parse_pred_or_func_name_and_arity'/5 in mode 0 */
Define_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0);
	MR_incr_sp_push_msg(2, "prog_io_util:parse_pred_or_func_name_and_arity/5");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1009);
	if ((MR_tag(MR_const_field(MR_mktag(0), r3, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1009);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i5);
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = (Integer) 1;
	GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i4);
Define_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = (Integer) 0;
Define_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i4);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__parse_name_and_arity_4_0),
		mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i9,
		ENTRY(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0));
Define_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
	r4 = r3;
	r3 = r2;
	r1 = TRUE;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1009);
	r1 = FALSE;
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module6)
	init_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_4_0);
BEGIN_CODE

/* code for predicate 'parse_pred_or_func_name_and_arity'/4 in mode 0 */
Define_entry(mercury__prog_io_util__parse_pred_or_func_name_and_arity_4_0);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_0);
	tailcall(STATIC(mercury__prog_io_util__parse_pred_or_func_name_and_arity_5_0),
		ENTRY(mercury__prog_io_util__parse_pred_or_func_name_and_arity_4_0));
END_MODULE

Declare_entry(mercury__prog_io__parse_qualified_term_4_0);

BEGIN_MODULE(prog_io_util_module7)
	init_entry(mercury__prog_io_util__parse_pred_or_func_and_args_5_0);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i9);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i11);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i10);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i14);
BEGIN_CODE

/* code for predicate 'parse_pred_or_func_and_args'/5 in mode 0 */
Define_entry(mercury__prog_io_util__parse_pred_or_func_and_args_5_0);
	MR_incr_sp_push_msg(2, "prog_io_util:parse_pred_or_func_and_args/5");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	r6 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r6, (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	r6 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r6, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r6, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_util__parse_pred_or_func_and_args_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r6, (Integer) 1), (Integer) 0);
	MR_tempr2 = r2;
	r2 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	r3 = r4;
	r4 = r5;
	r5 = MR_tempr2;
	MR_stackvar(1) = MR_tempr1;
	GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i9);
	}
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r5 = MR_tempr1;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	}
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i9);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i11);
	call_localret(ENTRY(mercury__prog_io__parse_qualified_term_4_0),
		mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i10,
		ENTRY(mercury__prog_io_util__parse_pred_or_func_and_args_5_0));
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i11);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r5 = r4;
	r4 = r3;
	r3 = MR_tempr1;
	call_localret(ENTRY(mercury__prog_io__parse_implicitly_qualified_term_5_0),
		mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i10,
		ENTRY(mercury__prog_io_util__parse_pred_or_func_and_args_5_0));
	}
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0));
	if ((MR_tag(r1) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_io_util__parse_pred_or_func_and_args_5_0, "prog_io_util:maybe2/2");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_util__parse_pred_or_func_and_args_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_5_0_i14);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(prog_io_util_module8)
	init_entry(mercury__prog_io_util__parse_pred_or_func_and_args_4_0);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i2);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i5);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i6);
	init_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i1);
BEGIN_CODE

/* code for predicate 'parse_pred_or_func_and_args'/4 in mode 0 */
Define_entry(mercury__prog_io_util__parse_pred_or_func_and_args_4_0);
	MR_incr_sp_push_msg(2, "prog_io_util:parse_pred_or_func_and_args/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r3;
	r5 = (Word) MR_string_const("", 0);
	call_localret(STATIC(mercury__prog_io_util__parse_pred_or_func_and_args_5_0),
		mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i2,
		ENTRY(mercury__prog_io_util__parse_pred_or_func_and_args_4_0));
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_4_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i5);
	r2 = (Integer) 0;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_io_util__parse_pred_or_func_and_args_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_util__parse_pred_or_func_and_args_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i6,
		ENTRY(mercury__prog_io_util__parse_pred_or_func_and_args_4_0));
	}
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_pred_or_func_and_args_4_0));
	r2 = (Integer) 1;
	r3 = MR_stackvar(1);
	r4 = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__parse_pred_or_func_and_args_4_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module9)
	init_entry(mercury__prog_io_util__convert_mode_list_2_0);
	init_label(mercury__prog_io_util__convert_mode_list_2_0_i3);
	init_label(mercury__prog_io_util__convert_mode_list_2_0_i4);
	init_label(mercury__prog_io_util__convert_mode_list_2_0_i6);
	init_label(mercury__prog_io_util__convert_mode_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_mode_list'/2 in mode 0 */
Define_entry(mercury__prog_io_util__convert_mode_list_2_0);
	MR_incr_sp_push_msg(2, "prog_io_util:convert_mode_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_list_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_mode_list_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_util__convert_mode_list_2_0_i4,
		ENTRY(mercury__prog_io_util__convert_mode_list_2_0));
Define_label(mercury__prog_io_util__convert_mode_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_list_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_util__convert_mode_list_2_0,
		LABEL(mercury__prog_io_util__convert_mode_list_2_0_i6),
		ENTRY(mercury__prog_io_util__convert_mode_list_2_0));
Define_label(mercury__prog_io_util__convert_mode_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_list_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_mode_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_mode_list_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;

BEGIN_MODULE(prog_io_util_module10)
	init_entry(mercury__prog_io_util__convert_mode_2_0);
	init_label(mercury__prog_io_util__convert_mode_2_0_i9);
	init_label(mercury__prog_io_util__convert_mode_2_0_i11);
	init_label(mercury__prog_io_util__convert_mode_2_0_i2);
	init_label(mercury__prog_io_util__convert_mode_2_0_i26);
	init_label(mercury__prog_io_util__convert_mode_2_0_i28);
	init_label(mercury__prog_io_util__convert_mode_2_0_i13);
	init_label(mercury__prog_io_util__convert_mode_2_0_i49);
	init_label(mercury__prog_io_util__convert_mode_2_0_i51);
	init_label(mercury__prog_io_util__convert_mode_2_0_i53);
	init_label(mercury__prog_io_util__convert_mode_2_0_i1103);
	init_label(mercury__prog_io_util__convert_mode_2_0_i30);
	init_label(mercury__prog_io_util__convert_mode_2_0_i56);
	init_label(mercury__prog_io_util__convert_mode_2_0_i58);
	init_label(mercury__prog_io_util__convert_mode_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_mode'/2 in mode 0 */
Define_entry(mercury__prog_io_util__convert_mode_2_0);
	MR_incr_sp_push_msg(3, "prog_io_util:convert_mode/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("->", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i2);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_2_0),
		mercury__prog_io_util__convert_mode_2_0_i9,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_inst_2_0),
		mercury__prog_io_util__convert_mode_2_0_i11,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_mode_2_0, "prog_data:mode/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_mode_2_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i13);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_util__convert_mode_2_0_i26,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
	}
Define_label(mercury__prog_io_util__convert_mode_2_0_i26);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_mode_list_2_0),
		mercury__prog_io_util__convert_mode_2_0_i28,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i28);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_mode_2_0, "prog_data:mode/0");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_mode_2_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_mode_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__prog_io_util__convert_mode_2_0_i13);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((MR_tag(MR_const_field(MR_mktag(1), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i30);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_util__convert_mode_2_0_i49,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
	}
Define_label(mercury__prog_io_util__convert_mode_2_0_i49);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_mode_list_2_0),
		mercury__prog_io_util__convert_mode_2_0_i51,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i51);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_util__convert_mode_2_0,
		LABEL(mercury__prog_io_util__convert_mode_2_0_i53),
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i53);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_mode_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_util__convert_mode_2_0_i1103,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i1103);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_mode_2_0, "prog_data:mode/0");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_mode_2_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_mode_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_mode_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(3), r3, (Integer) 2) = r4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__prog_io_util__convert_mode_2_0_i30);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r4 = (Word) MR_string_const("mode definition", 15);
	call_localret(ENTRY(mercury__prog_io__parse_qualified_term_4_0),
		mercury__prog_io_util__convert_mode_2_0_i56,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i56);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_list_2_0),
		mercury__prog_io_util__convert_mode_2_0_i58,
		ENTRY(mercury__prog_io_util__convert_mode_2_0));
Define_label(mercury__prog_io_util__convert_mode_2_0_i58);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_mode_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_mode_2_0, "prog_data:mode/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_mode_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module11)
	init_entry(mercury__prog_io_util__convert_inst_list_2_0);
	init_label(mercury__prog_io_util__convert_inst_list_2_0_i3);
	init_label(mercury__prog_io_util__convert_inst_list_2_0_i4);
	init_label(mercury__prog_io_util__convert_inst_list_2_0_i6);
	init_label(mercury__prog_io_util__convert_inst_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_inst_list'/2 in mode 0 */
Define_entry(mercury__prog_io_util__convert_inst_list_2_0);
	MR_incr_sp_push_msg(2, "prog_io_util:convert_inst_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_list_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_list_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_2_0),
		mercury__prog_io_util__convert_inst_list_2_0_i4,
		ENTRY(mercury__prog_io_util__convert_inst_list_2_0));
Define_label(mercury__prog_io_util__convert_inst_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_list_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_util__convert_inst_list_2_0,
		LABEL(mercury__prog_io_util__convert_inst_list_2_0_i6),
		ENTRY(mercury__prog_io_util__convert_inst_list_2_0));
Define_label(mercury__prog_io_util__convert_inst_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_list_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_inst_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_list_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_inst_var_type_0;
Declare_entry(mercury__term__coerce_var_2_0);

BEGIN_MODULE(prog_io_util_module12)
	init_entry(mercury__prog_io_util__convert_inst_2_0);
	init_label(mercury__prog_io_util__convert_inst_2_0_i4);
	init_label(mercury__prog_io_util__convert_inst_2_0_i8);
	init_label(mercury__prog_io_util__convert_inst_2_0_i12);
	init_label(mercury__prog_io_util__convert_inst_2_0_i16);
	init_label(mercury__prog_io_util__convert_inst_2_0_i20);
	init_label(mercury__prog_io_util__convert_inst_2_0_i24);
	init_label(mercury__prog_io_util__convert_inst_2_0_i28);
	init_label(mercury__prog_io_util__convert_inst_2_0_i32);
	init_label(mercury__prog_io_util__convert_inst_2_0_i36);
	init_label(mercury__prog_io_util__convert_inst_2_0_i40);
	init_label(mercury__prog_io_util__convert_inst_2_0_i44);
	init_label(mercury__prog_io_util__convert_inst_2_0_i60);
	init_label(mercury__prog_io_util__convert_inst_2_0_i62);
	init_label(mercury__prog_io_util__convert_inst_2_0_i48);
	init_label(mercury__prog_io_util__convert_inst_2_0_i82);
	init_label(mercury__prog_io_util__convert_inst_2_0_i84);
	init_label(mercury__prog_io_util__convert_inst_2_0_i86);
	init_label(mercury__prog_io_util__convert_inst_2_0_i1167);
	init_label(mercury__prog_io_util__convert_inst_2_0_i64);
	init_label(mercury__prog_io_util__convert_inst_2_0_i89);
	init_label(mercury__prog_io_util__convert_inst_2_0_i93);
	init_label(mercury__prog_io_util__convert_inst_2_0_i100);
	init_label(mercury__prog_io_util__convert_inst_2_0_i107);
	init_label(mercury__prog_io_util__convert_inst_2_0_i114);
	init_label(mercury__prog_io_util__convert_inst_2_0_i121);
	init_label(mercury__prog_io_util__convert_inst_2_0_i123);
	init_label(mercury__prog_io_util__convert_inst_2_0_i3);
	init_label(mercury__prog_io_util__convert_inst_2_0_i1193);
	init_label(mercury__prog_io_util__convert_inst_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_inst'/2 in mode 0 */
Define_entry(mercury__prog_io_util__convert_inst_2_0);
	MR_incr_sp_push_msg(3, "prog_io_util:convert_inst/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i4);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("free", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i4);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i4);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i8);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("any", 3)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i8);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i8);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i8);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i12);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("unique_any", 10)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i12);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i12);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i16);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("mostly_unique_any", 17)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i16);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i16);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i16);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i20);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("clobbered_any", 13)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i20);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i20);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_4);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i20);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i24);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("mostly_clobbered_any", 20)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i24);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i24);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_io_util__common_5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i24);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i28);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("ground", 6)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i28);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i28);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i28);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i32);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("unique", 6)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i32);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i32);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_7);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i32);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i36);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("mostly_unique", 13)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i36);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i36);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_8);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i36);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i40);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("clobbered", 9)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i40);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i40);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_9);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i40);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i44);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("mostly_clobbered", 16)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i44);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i44);
	r2 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_io_util__common_10);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i44);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	r5 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r5, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i48);
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_util__convert_inst_2_0_i60,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i60);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_mode_list_2_0),
		mercury__prog_io_util__convert_inst_2_0_i62,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i62);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_inst_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_inst_2_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_inst_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(3), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__prog_io_util__convert_inst_2_0_i48);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("is", 2)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	r5 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((MR_tag(MR_const_field(MR_mktag(0), r5, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r5, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if (((Integer) MR_const_field(MR_mktag(0), r5, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r5, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i64);
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__standard_det_2_0),
		mercury__prog_io_util__convert_inst_2_0_i82,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
	}
Define_label(mercury__prog_io_util__convert_inst_2_0_i82);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_mode_list_2_0),
		mercury__prog_io_util__convert_inst_2_0_i84,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i84);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_io_util__convert_mode_2_0),
		mercury__prog_io_util__convert_inst_2_0_i86,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i86);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_inst_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__prog_io_util__convert_inst_2_0_i1167,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i1167);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_util__convert_inst_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__prog_io_util__convert_inst_2_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__prog_io_util__convert_inst_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = TRUE;
	MR_field(MR_mktag(3), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__prog_io_util__convert_inst_2_0_i64);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i89);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("not_reached", 11)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i89);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i89);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i89);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i93);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("bound", 5)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i93);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i93);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i93);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0),
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i93);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i100);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("bound_unique", 12)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i100);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i100);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i100);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0),
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i100);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i107);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((strcmp((char *)r4, (char *)(Word) MR_string_const("unique", 6)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i107);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i107);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i107);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0),
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i107);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i114);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("mostly_unique", 13)) != 0))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i114);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i114);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i114);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0),
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i114);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r4 = (Word) MR_string_const("inst", 4);
	call_localret(ENTRY(mercury__prog_io__parse_qualified_term_4_0),
		mercury__prog_io_util__convert_inst_2_0_i121,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i121);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_list_2_0),
		mercury__prog_io_util__convert_inst_2_0_i123,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i123);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__prog_io_util__convert_inst_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_inst_2_0, "prog_data:inst_name/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r3;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_inst_var_type_0;
	call_localret(ENTRY(mercury__term__coerce_var_2_0),
		mercury__prog_io_util__convert_inst_2_0_i1193,
		ENTRY(mercury__prog_io_util__convert_inst_2_0));
Define_label(mercury__prog_io_util__convert_inst_2_0_i1193);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_inst_2_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__prog_io_util__convert_inst_2_0, "inst:inst/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_inst_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module13)
	init_entry(mercury__prog_io_util__standard_det_2_0);
	init_label(mercury__prog_io_util__standard_det_2_0_i3);
	init_label(mercury__prog_io_util__standard_det_2_0_i1002);
	init_label(mercury__prog_io_util__standard_det_2_0_i1001);
	init_label(mercury__prog_io_util__standard_det_2_0_i5);
	init_label(mercury__prog_io_util__standard_det_2_0_i6);
	init_label(mercury__prog_io_util__standard_det_2_0_i7);
	init_label(mercury__prog_io_util__standard_det_2_0_i8);
	init_label(mercury__prog_io_util__standard_det_2_0_i9);
	init_label(mercury__prog_io_util__standard_det_2_0_i11);
	init_label(mercury__prog_io_util__standard_det_2_0_i12);
	init_label(mercury__prog_io_util__standard_det_2_0_i13);
	init_label(mercury__prog_io_util__standard_det_2_0_i14);
BEGIN_CODE

/* code for predicate 'standard_det'/2 in mode 0 */
Define_entry(mercury__prog_io_util__standard_det_2_0);
	r2 = (hash_string(r1) & (Integer) 31);
Define_label(mercury__prog_io_util__standard_det_2_0_i3);
	r3 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_11))[(Integer) r2];
	if (!(r3))
		GOTO_LABEL(mercury__prog_io_util__standard_det_2_0_i1002);
	if ((strcmp((char *)r3, (char *)r1) == 0))
		GOTO_LABEL(mercury__prog_io_util__standard_det_2_0_i5);
Define_label(mercury__prog_io_util__standard_det_2_0_i1002);
	r2 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_12))[(Integer) r2];
	if (((Integer) r2 >= (Integer) 0))
		GOTO_LABEL(mercury__prog_io_util__standard_det_2_0_i3);
Define_label(mercury__prog_io_util__standard_det_2_0_i1001);
	r1 = FALSE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i5);
	COMPUTED_GOTO((Unsigned) r2,
		LABEL(mercury__prog_io_util__standard_det_2_0_i6) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i7) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i8) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i9) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i11) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i11) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i12) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i13) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i14) AND
		LABEL(mercury__prog_io_util__standard_det_2_0_i1001));
Define_label(mercury__prog_io_util__standard_det_2_0_i6);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i7);
	r2 = (Integer) 6;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i8);
	r2 = (Integer) 4;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i9);
	r2 = (Integer) 7;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i11);
	r2 = (Integer) 3;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i12);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i13);
	r2 = (Integer) 2;
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__standard_det_2_0_i14);
	r2 = (Integer) 5;
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module14)
	init_entry(mercury__prog_io_util__disjunction_to_list_2_0);
BEGIN_CODE

/* code for predicate 'disjunction_to_list'/2 in mode 0 */
Define_entry(mercury__prog_io_util__disjunction_to_list_2_0);
	r1 = (Word) MR_string_const(";", 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0),
		ENTRY(mercury__prog_io_util__disjunction_to_list_2_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module15)
	init_entry(mercury__prog_io_util__conjunction_to_list_2_0);
BEGIN_CODE

/* code for predicate 'conjunction_to_list'/2 in mode 0 */
Define_entry(mercury__prog_io_util__conjunction_to_list_2_0);
	r1 = (Word) MR_string_const(",", 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0),
		ENTRY(mercury__prog_io_util__conjunction_to_list_2_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module16)
	init_entry(mercury__prog_io_util__sum_to_list_2_0);
BEGIN_CODE

/* code for predicate 'sum_to_list'/2 in mode 0 */
Define_entry(mercury__prog_io_util__sum_to_list_2_0);
	r1 = (Word) MR_string_const("+", 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0),
		ENTRY(mercury__prog_io_util__sum_to_list_2_0));
END_MODULE

Declare_entry(mercury__io__stderr_stream_3_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__set_exit_status_3_0);
Declare_entry(mercury__io__write_string_4_0);

BEGIN_MODULE(prog_io_util_module17)
	init_entry(mercury__prog_io_util__report_warning_3_0);
	init_label(mercury__prog_io_util__report_warning_3_0_i2);
	init_label(mercury__prog_io_util__report_warning_3_0_i3);
	init_label(mercury__prog_io_util__report_warning_3_0_i6);
	init_label(mercury__prog_io_util__report_warning_3_0_i4);
BEGIN_CODE

/* code for predicate 'report_warning'/3 in mode 0 */
Define_entry(mercury__prog_io_util__report_warning_3_0);
	MR_incr_sp_push_msg(3, "prog_io_util:report_warning/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__prog_io_util__report_warning_3_0_i2,
		ENTRY(mercury__prog_io_util__report_warning_3_0));
Define_label(mercury__prog_io_util__report_warning_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_3_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__prog_io_util__report_warning_3_0_i3,
		ENTRY(mercury__prog_io_util__report_warning_3_0));
Define_label(mercury__prog_io_util__report_warning_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__prog_io_util__report_warning_3_0_i4);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__prog_io_util__report_warning_3_0_i6,
		ENTRY(mercury__prog_io_util__report_warning_3_0));
Define_label(mercury__prog_io_util__report_warning_3_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__prog_io_util__report_warning_3_0));
Define_label(mercury__prog_io_util__report_warning_3_0_i4);
	r3 = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__prog_io_util__report_warning_3_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module18)
	init_entry(mercury__prog_io_util__report_warning_4_0);
	init_label(mercury__prog_io_util__report_warning_4_0_i2);
	init_label(mercury__prog_io_util__report_warning_4_0_i5);
	init_label(mercury__prog_io_util__report_warning_4_0_i3);
BEGIN_CODE

/* code for predicate 'report_warning'/4 in mode 0 */
Define_entry(mercury__prog_io_util__report_warning_4_0);
	MR_incr_sp_push_msg(3, "prog_io_util:report_warning/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 1;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__prog_io_util__report_warning_4_0_i2,
		ENTRY(mercury__prog_io_util__report_warning_4_0));
Define_label(mercury__prog_io_util__report_warning_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__prog_io_util__report_warning_4_0_i3);
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__prog_io_util__report_warning_4_0_i5,
		ENTRY(mercury__prog_io_util__report_warning_4_0));
Define_label(mercury__prog_io_util__report_warning_4_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__prog_io_util__report_warning_4_0));
Define_label(mercury__prog_io_util__report_warning_4_0_i3);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_4_0),
		ENTRY(mercury__prog_io_util__report_warning_4_0));
END_MODULE

Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(prog_io_util_module19)
	init_entry(mercury__prog_io_util__report_warning_5_0);
	init_label(mercury__prog_io_util__report_warning_5_0_i2);
	init_label(mercury__prog_io_util__report_warning_5_0_i3);
	init_label(mercury__prog_io_util__report_warning_5_0_i4);
	init_label(mercury__prog_io_util__report_warning_5_0_i5);
	init_label(mercury__prog_io_util__report_warning_5_0_i6);
BEGIN_CODE

/* code for predicate 'report_warning'/5 in mode 0 */
Define_entry(mercury__prog_io_util__report_warning_5_0);
	MR_incr_sp_push_msg(2, "prog_io_util:report_warning/5");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r4;
	r5 = r1;
	r1 = (Word) MR_string_const("%s:%3d: Warning: %s\n", 20);
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__report_warning_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_io_util__report_warning_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__prog_io_util__report_warning_5_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_io_util__report_warning_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__prog_io_util__report_warning_5_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_io_util__report_warning_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__prog_io_util__report_warning_5_0_i2,
		ENTRY(mercury__prog_io_util__report_warning_5_0));
	}
Define_label(mercury__prog_io_util__report_warning_5_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__prog_io_util__report_warning_5_0_i3,
		ENTRY(mercury__prog_io_util__report_warning_5_0));
Define_label(mercury__prog_io_util__report_warning_5_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_5_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_4_0),
		mercury__prog_io_util__report_warning_5_0_i4,
		ENTRY(mercury__prog_io_util__report_warning_5_0));
Define_label(mercury__prog_io_util__report_warning_5_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_5_0));
	r2 = r1;
	r1 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__prog_io_util__report_warning_5_0_i5,
		ENTRY(mercury__prog_io_util__report_warning_5_0));
Define_label(mercury__prog_io_util__report_warning_5_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_util__report_warning_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__prog_io_util__report_warning_5_0_i6);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		ENTRY(mercury__prog_io_util__report_warning_5_0));
Define_label(mercury__prog_io_util__report_warning_5_0_i6);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_inst__type_ctor_info_bound_inst_0;
Declare_entry(mercury__list__sort_2_0);
Declare_entry(mercury__list__append_3_4);
Declare_entry(do_redo);
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);

BEGIN_MODULE(prog_io_util_module20)
	init_entry(mercury__prog_io_util__parse_bound_inst_list_3_0);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i2);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i3);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i5);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1011);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1015);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i8);
	init_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1);
BEGIN_CODE

/* code for predicate 'parse_bound_inst_list'/3 in mode 0 */
Define_static(mercury__prog_io_util__parse_bound_inst_list_3_0);
	MR_incr_sp_push_msg(5, "prog_io_util:parse_bound_inst_list/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_string_const(";", 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__prog_io_util__binop_term_to_list_2__ua0_4_0),
		mercury__prog_io_util__parse_bound_inst_list_3_0_i2,
		STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0));
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	call_localret(STATIC(mercury__prog_io_util__convert_bound_inst_list_2_0),
		mercury__prog_io_util__parse_bound_inst_list_3_0_i3,
		STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0));
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0_i1);
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_bound_inst_0;
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__prog_io_util__parse_bound_inst_list_3_0_i5,
		STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0));
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__prog_io_util__parse_bound_inst_list_3_0, "inst:inst/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	MR_stackvar(2) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(3) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(4) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0_i8);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_bound_inst_0;
	call_localret(ENTRY(mercury__list__append_3_4),
		mercury__prog_io_util__parse_bound_inst_list_3_0_i1011,
		STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0));
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1011);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__prog_io_util__parse_bound_inst_list_3_0_i1015,
		STATIC(mercury__prog_io_util__parse_bound_inst_list_3_0));
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1015);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_util__parse_bound_inst_list_3_0));
	r2 = MR_stackvar(1);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(2);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = TRUE;
	proceed();
Define_label(mercury__prog_io_util__parse_bound_inst_list_3_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module21)
	init_entry(mercury__prog_io_util__convert_bound_inst_list_2_0);
	init_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i3);
	init_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i4);
	init_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i6);
	init_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_bound_inst_list'/2 in mode 0 */
Define_static(mercury__prog_io_util__convert_bound_inst_list_2_0);
	MR_incr_sp_push_msg(2, "prog_io_util:convert_bound_inst_list/2");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_io_util__convert_bound_inst_2_0),
		mercury__prog_io_util__convert_bound_inst_list_2_0_i4,
		STATIC(mercury__prog_io_util__convert_bound_inst_list_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__prog_io_util__convert_bound_inst_list_2_0,
		LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0_i6),
		STATIC(mercury__prog_io_util__convert_bound_inst_list_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_list_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_io_util__convert_bound_inst_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_io_util__convert_bound_inst_list_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__hlds_data__make_functor_cons_id_3_0);

BEGIN_MODULE(prog_io_util_module22)
	init_entry(mercury__prog_io_util__convert_bound_inst_2_0);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i5);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i7);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i3);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i8);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i9);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i11);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i1006);
	init_label(mercury__prog_io_util__convert_bound_inst_2_0_i1);
BEGIN_CODE

/* code for predicate 'convert_bound_inst'/2 in mode 0 */
Define_static(mercury__prog_io_util__convert_bound_inst_2_0);
	MR_incr_sp_push_msg(3, "prog_io_util:convert_bound_inst/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_2_0_i1006);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_2_0_i3);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = r2;
	r4 = (Word) MR_string_const("inst", 4);
	call_localret(ENTRY(mercury__prog_io__parse_qualified_term_4_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i5,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_2_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_13);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i7,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_2_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_bound_inst_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_list_2_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i11,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i3);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_13);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i8,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_data__make_functor_cons_id_3_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i9,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_2_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_io_util__convert_inst_list_2_0),
		mercury__prog_io_util__convert_bound_inst_2_0_i11,
		STATIC(mercury__prog_io_util__convert_bound_inst_2_0));
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_io_util__convert_bound_inst_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_io_util__convert_bound_inst_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__prog_io_util__convert_bound_inst_2_0, "inst:bound_inst/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i1006);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_io_util__convert_bound_inst_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__term_1_0);
Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(prog_io_util_module23)
	init_entry(mercury____Unify___prog_io_util__maybe2_2_0);
	init_label(mercury____Unify___prog_io_util__maybe2_2_0_i3);
	init_label(mercury____Unify___prog_io_util__maybe2_2_0_i8);
	init_label(mercury____Unify___prog_io_util__maybe2_2_0_i1008);
	init_label(mercury____Unify___prog_io_util__maybe2_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe2_2_0);
	MR_incr_sp_push_msg(4, "prog_io_util:__Unify__/2");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe2_2_0_i3);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe2_2_0_i1008);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)MR_const_field(MR_mktag(0), r4, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe2_2_0_i1008);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Unify___term__term_1_0),
		ENTRY(mercury____Unify___prog_io_util__maybe2_2_0));
Define_label(mercury____Unify___prog_io_util__maybe2_2_0_i3);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe2_2_0_i1);
	MR_stackvar(3) = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___prog_io_util__maybe2_2_0_i8,
		ENTRY(mercury____Unify___prog_io_util__maybe2_2_0));
Define_label(mercury____Unify___prog_io_util__maybe2_2_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___prog_io_util__maybe2_2_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe2_2_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe2_2_0));
Define_label(mercury____Unify___prog_io_util__maybe2_2_0_i1008);
	r1 = FALSE;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Unify___prog_io_util__maybe2_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module24)
	init_entry(mercury____Index___prog_io_util__maybe2_2_0);
	init_label(mercury____Index___prog_io_util__maybe2_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe2_2_0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe2_2_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe2_2_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury____Compare___term__term_1_0);
Declare_entry(mercury__compare_3_3);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(prog_io_util_module25)
	init_entry(mercury____Compare___prog_io_util__maybe2_2_0);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i3);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i2);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i5);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i4);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i6);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i7);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i14);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i11);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i21);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i9);
	init_label(mercury____Compare___prog_io_util__maybe2_2_0_i29);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe2_2_0);
	MR_incr_sp_push_msg(4, "prog_io_util:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i3);
	MR_stackvar(3) = r2;
	r2 = r4;
	r4 = r1;
	r1 = r3;
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i2);
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i3);
	MR_stackvar(3) = r2;
	r2 = r4;
	r4 = r1;
	r1 = r3;
	r3 = (Integer) 1;
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i5);
	r5 = r4;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i4);
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i5);
	r5 = r4;
	r4 = (Integer) 1;
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i6);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i7);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___prog_io_util__maybe2_2_0_i14,
		ENTRY(mercury____Compare___prog_io_util__maybe2_2_0));
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___prog_io_util__maybe2_2_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i29);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___term__term_1_0),
		ENTRY(mercury____Compare___prog_io_util__maybe2_2_0));
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i9);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r5;
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___prog_io_util__maybe2_2_0_i21,
		ENTRY(mercury____Compare___prog_io_util__maybe2_2_0));
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___prog_io_util__maybe2_2_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe2_2_0_i29);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_3_3),
		ENTRY(mercury____Compare___prog_io_util__maybe2_2_0));
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i9);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___prog_io_util__maybe2_2_0));
Define_label(mercury____Compare___prog_io_util__maybe2_2_0_i29);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module26)
	init_entry(mercury____Unify___prog_io_util__maybe1_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe1_1_0);
	r4 = r3;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	tailcall(STATIC(mercury____Unify___prog_io_util__maybe1_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe1_1_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module27)
	init_entry(mercury____Index___prog_io_util__maybe1_1_0);
	init_label(mercury____Index___prog_io_util__maybe1_1_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe1_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe1_1_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe1_1_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module28)
	init_entry(mercury____Compare___prog_io_util__maybe1_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe1_1_0);
	r4 = r3;
	r3 = r2;
	r2 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	tailcall(STATIC(mercury____Compare___prog_io_util__maybe1_2_0),
		ENTRY(mercury____Compare___prog_io_util__maybe1_1_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module29)
	init_entry(mercury____Unify___prog_io_util__maybe1_2_0);
	init_label(mercury____Unify___prog_io_util__maybe1_2_0_i3);
	init_label(mercury____Unify___prog_io_util__maybe1_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe1_2_0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe1_2_0_i3);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe1_2_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)MR_const_field(MR_mktag(0), r4, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe1_2_0_i1);
	r1 = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	tailcall(ENTRY(mercury____Unify___term__term_1_0),
		ENTRY(mercury____Unify___prog_io_util__maybe1_2_0));
Define_label(mercury____Unify___prog_io_util__maybe1_2_0_i3);
	if ((MR_tag(r4) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___prog_io_util__maybe1_2_0_i1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe1_2_0));
Define_label(mercury____Unify___prog_io_util__maybe1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module30)
	init_entry(mercury____Index___prog_io_util__maybe1_2_0);
	init_label(mercury____Index___prog_io_util__maybe1_2_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe1_2_0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe1_2_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe1_2_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module31)
	init_entry(mercury____Compare___prog_io_util__maybe1_2_0);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i3);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i2);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i5);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i4);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i6);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i7);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i14);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i11);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i9);
	init_label(mercury____Compare___prog_io_util__maybe1_2_0_i24);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe1_2_0);
	MR_incr_sp_push_msg(4, "prog_io_util:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i3);
	MR_stackvar(3) = r2;
	r2 = r4;
	r4 = r1;
	r1 = r3;
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i2);
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i3);
	MR_stackvar(3) = r2;
	r2 = r4;
	r4 = r1;
	r1 = r3;
	r3 = (Integer) 1;
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i5);
	r5 = r4;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i4);
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i5);
	r5 = r4;
	r4 = (Integer) 1;
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i6);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i7);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_string_3_0),
		mercury____Compare___prog_io_util__maybe1_2_0_i14,
		ENTRY(mercury____Compare___prog_io_util__maybe1_2_0));
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___prog_io_util__maybe1_2_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i24);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury____Compare___term__term_1_0),
		ENTRY(mercury____Compare___prog_io_util__maybe1_2_0));
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___prog_io_util__maybe1_2_0_i9);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_3_3),
		ENTRY(mercury____Compare___prog_io_util__maybe1_2_0));
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i9);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___prog_io_util__maybe1_2_0));
Define_label(mercury____Compare___prog_io_util__maybe1_2_0_i24);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module32)
	init_entry(mercury____Unify___prog_io_util__maybe_functor_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe_functor_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_14);
	tailcall(STATIC(mercury____Unify___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe_functor_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module33)
	init_entry(mercury____Index___prog_io_util__maybe_functor_0_0);
	init_label(mercury____Index___prog_io_util__maybe_functor_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe_functor_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe_functor_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe_functor_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module34)
	init_entry(mercury____Compare___prog_io_util__maybe_functor_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe_functor_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_14);
	tailcall(STATIC(mercury____Compare___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Compare___prog_io_util__maybe_functor_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module35)
	init_entry(mercury____Unify___prog_io_util__maybe_functor_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe_functor_1_0);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury____Unify___prog_io_util__maybe_functor_1_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Unify___prog_io_util__maybe_functor_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	r4 = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	r3 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	tailcall(STATIC(mercury____Unify___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe_functor_1_0));
	}
END_MODULE


BEGIN_MODULE(prog_io_util_module36)
	init_entry(mercury____Index___prog_io_util__maybe_functor_1_0);
	init_label(mercury____Index___prog_io_util__maybe_functor_1_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe_functor_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe_functor_1_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe_functor_1_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module37)
	init_entry(mercury____Compare___prog_io_util__maybe_functor_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe_functor_1_0);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury____Compare___prog_io_util__maybe_functor_1_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Compare___prog_io_util__maybe_functor_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	r4 = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	r3 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	tailcall(STATIC(mercury____Compare___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Compare___prog_io_util__maybe_functor_1_0));
	}
END_MODULE


BEGIN_MODULE(prog_io_util_module38)
	init_entry(mercury____Unify___prog_io_util__maybe_pred_or_func_1_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe_pred_or_func_1_0);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury____Unify___prog_io_util__maybe_pred_or_func_1_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_std_util__type_ctor_info_pair_2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Unify___prog_io_util__maybe_pred_or_func_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Unify___prog_io_util__maybe_pred_or_func_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	r4 = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_tempr1;
	r3 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_std_util__type_ctor_info_maybe_1;
	tailcall(STATIC(mercury____Unify___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe_pred_or_func_1_0));
	}
END_MODULE


BEGIN_MODULE(prog_io_util_module39)
	init_entry(mercury____Index___prog_io_util__maybe_pred_or_func_1_0);
	init_label(mercury____Index___prog_io_util__maybe_pred_or_func_1_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe_pred_or_func_1_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe_pred_or_func_1_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe_pred_or_func_1_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module40)
	init_entry(mercury____Compare___prog_io_util__maybe_pred_or_func_1_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe_pred_or_func_1_0);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury____Compare___prog_io_util__maybe_pred_or_func_1_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_std_util__type_ctor_info_pair_2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Compare___prog_io_util__maybe_pred_or_func_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_list__type_ctor_info_list_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury____Compare___prog_io_util__maybe_pred_or_func_1_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	r4 = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_tempr1;
	r3 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_std_util__type_ctor_info_maybe_1;
	tailcall(STATIC(mercury____Compare___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Compare___prog_io_util__maybe_pred_or_func_1_0));
	}
END_MODULE


BEGIN_MODULE(prog_io_util_module41)
	init_entry(mercury____Unify___prog_io_util__maybe_item_and_context_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__maybe_item_and_context_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_item_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	tailcall(STATIC(mercury____Unify___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Unify___prog_io_util__maybe_item_and_context_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module42)
	init_entry(mercury____Index___prog_io_util__maybe_item_and_context_0_0);
	init_label(mercury____Index___prog_io_util__maybe_item_and_context_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__maybe_item_and_context_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_io_util__maybe_item_and_context_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_io_util__maybe_item_and_context_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(prog_io_util_module43)
	init_entry(mercury____Compare___prog_io_util__maybe_item_and_context_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__maybe_item_and_context_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_item_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	tailcall(STATIC(mercury____Compare___prog_io_util__maybe2_2_0),
		ENTRY(mercury____Compare___prog_io_util__maybe_item_and_context_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(prog_io_util_module44)
	init_entry(mercury____Unify___prog_io_util__var2tvar_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__var2tvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_16);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prog_io_util__var2tvar_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(prog_io_util_module45)
	init_entry(mercury____Index___prog_io_util__var2tvar_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__var2tvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_16);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___prog_io_util__var2tvar_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(prog_io_util_module46)
	init_entry(mercury____Compare___prog_io_util__var2tvar_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__var2tvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_16);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prog_io_util__var2tvar_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module47)
	init_entry(mercury____Unify___prog_io_util__var2pvar_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_io_util__var2pvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_17);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___prog_io_util__var2pvar_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module48)
	init_entry(mercury____Index___prog_io_util__var2pvar_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_io_util__var2pvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_17);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___prog_io_util__var2pvar_0_0));
END_MODULE


BEGIN_MODULE(prog_io_util_module49)
	init_entry(mercury____Compare___prog_io_util__var2pvar_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_io_util__var2pvar_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_15);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_io_util__common_17);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___prog_io_util__var2pvar_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__prog_io_util_maybe_bunch_0(void)
{
	prog_io_util_module0();
	prog_io_util_module1();
	prog_io_util_module2();
	prog_io_util_module3();
	prog_io_util_module4();
	prog_io_util_module5();
	prog_io_util_module6();
	prog_io_util_module7();
	prog_io_util_module8();
	prog_io_util_module9();
	prog_io_util_module10();
	prog_io_util_module11();
	prog_io_util_module12();
	prog_io_util_module13();
	prog_io_util_module14();
	prog_io_util_module15();
	prog_io_util_module16();
	prog_io_util_module17();
	prog_io_util_module18();
	prog_io_util_module19();
	prog_io_util_module20();
	prog_io_util_module21();
	prog_io_util_module22();
	prog_io_util_module23();
	prog_io_util_module24();
	prog_io_util_module25();
	prog_io_util_module26();
	prog_io_util_module27();
	prog_io_util_module28();
	prog_io_util_module29();
	prog_io_util_module30();
	prog_io_util_module31();
	prog_io_util_module32();
	prog_io_util_module33();
	prog_io_util_module34();
	prog_io_util_module35();
	prog_io_util_module36();
	prog_io_util_module37();
	prog_io_util_module38();
	prog_io_util_module39();
}

static void mercury__prog_io_util_maybe_bunch_1(void)
{
	prog_io_util_module40();
	prog_io_util_module41();
	prog_io_util_module42();
	prog_io_util_module43();
	prog_io_util_module44();
	prog_io_util_module45();
	prog_io_util_module46();
	prog_io_util_module47();
	prog_io_util_module48();
	prog_io_util_module49();
}

#endif

void mercury__prog_io_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__prog_io_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__prog_io_util_maybe_bunch_0();
		mercury__prog_io_util_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe1_1,
			prog_io_util__maybe1_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe1_2,
			prog_io_util__maybe1_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe2_2,
			prog_io_util__maybe2_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe_functor_0,
			prog_io_util__maybe_functor_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe_functor_1,
			prog_io_util__maybe_functor_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe_item_and_context_0,
			prog_io_util__maybe_item_and_context_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_maybe_pred_or_func_1,
			prog_io_util__maybe_pred_or_func_1_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_var2pvar_0,
			prog_io_util__var2pvar_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_io_util__type_ctor_info_var2tvar_0,
			prog_io_util__var2tvar_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
