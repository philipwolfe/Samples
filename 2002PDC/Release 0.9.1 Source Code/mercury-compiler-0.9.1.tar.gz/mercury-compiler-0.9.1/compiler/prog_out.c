/*
** Automatically generated from `prog_out.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__prog_out__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__prog_out__write_list__ho1__ua0_4_0);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i1003);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i4);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i3);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i7);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i6);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i12);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i13);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i14);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i15);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i11);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i17);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i18);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i19);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i20);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i21);
Declare_label(mercury__prog_out__write_list__ho1__ua0_4_0_i22);
Define_extern_entry(mercury__prog_out__write_messages_3_0);
Declare_label(mercury__prog_out__write_messages_3_0_i1006);
Declare_label(mercury__prog_out__write_messages_3_0_i6);
Declare_label(mercury__prog_out__write_messages_3_0_i7);
Declare_label(mercury__prog_out__write_messages_3_0_i4);
Declare_label(mercury__prog_out__write_messages_3_0_i9);
Declare_label(mercury__prog_out__write_messages_3_0_i10);
Declare_label(mercury__prog_out__write_messages_3_0_i16);
Declare_label(mercury__prog_out__write_messages_3_0_i17);
Declare_label(mercury__prog_out__write_messages_3_0_i18);
Declare_label(mercury__prog_out__write_messages_3_0_i3);
Define_extern_entry(mercury__prog_out__write_context_3_0);
Declare_label(mercury__prog_out__write_context_3_0_i2);
Define_extern_entry(mercury__prog_out__context_to_string_2_0);
Declare_label(mercury__prog_out__context_to_string_2_0_i2);
Declare_label(mercury__prog_out__context_to_string_2_0_i3);
Declare_label(mercury__prog_out__context_to_string_2_0_i4);
Define_extern_entry(mercury__prog_out__write_strings_with_context_4_0);
Declare_label(mercury__prog_out__write_strings_with_context_4_0_i2);
Declare_label(mercury__prog_out__write_strings_with_context_4_0_i3);
Define_extern_entry(mercury__prog_out__write_sym_name_3_0);
Declare_label(mercury__prog_out__write_sym_name_3_0_i3);
Declare_label(mercury__prog_out__write_sym_name_3_0_i5);
Declare_label(mercury__prog_out__write_sym_name_3_0_i6);
Define_extern_entry(mercury__prog_out__write_sym_name_and_arity_3_0);
Declare_label(mercury__prog_out__write_sym_name_and_arity_3_0_i2);
Declare_label(mercury__prog_out__write_sym_name_and_arity_3_0_i3);
Define_extern_entry(mercury__prog_out__write_quoted_sym_name_3_0);
Declare_label(mercury__prog_out__write_quoted_sym_name_3_0_i2);
Declare_label(mercury__prog_out__write_quoted_sym_name_3_0_i3);
Define_extern_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_label(mercury__prog_out__sym_name_to_string_2_0_i2);
Define_extern_entry(mercury__prog_out__sym_name_to_string_3_0);
Declare_label(mercury__prog_out__sym_name_to_string_3_0_i2);
Define_extern_entry(mercury__prog_out__write_module_spec_3_0);
Define_extern_entry(mercury__prog_out__write_module_list_3_0);
Define_extern_entry(mercury__prog_out__write_list_4_0);
Declare_label(mercury__prog_out__write_list_4_0_i1003);
Declare_label(mercury__prog_out__write_list_4_0_i4);
Declare_label(mercury__prog_out__write_list_4_0_i3);
Declare_label(mercury__prog_out__write_list_4_0_i6);
Declare_label(mercury__prog_out__write_list_4_0_i10);
Declare_label(mercury__prog_out__write_list_4_0_i11);
Declare_label(mercury__prog_out__write_list_4_0_i9);
Declare_label(mercury__prog_out__write_list_4_0_i13);
Declare_label(mercury__prog_out__write_list_4_0_i14);
Declare_static(mercury__prog_out__write_strings_with_context_2_6_0);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i4);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i7);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i8);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i9);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i5);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i11);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i10);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i12);
Declare_label(mercury__prog_out__write_strings_with_context_2_6_0_i3);
Declare_static(mercury__prog_out__sym_name_to_string_2_4_0);
Declare_label(mercury__prog_out__sym_name_to_string_2_4_0_i4);
Declare_label(mercury__prog_out__sym_name_to_string_2_4_0_i2);

Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__io__write_string_3_0);

BEGIN_MODULE(prog_out_module0)
	init_entry(mercury__prog_out__write_list__ho1__ua0_4_0);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i1003);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i4);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i3);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i7);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i6);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i12);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i13);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i14);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i15);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i11);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i17);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i18);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i19);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i20);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i21);
	init_label(mercury__prog_out__write_list__ho1__ua0_4_0_i22);
BEGIN_CODE

/* code for predicate 'write_list__ho1__ua0'/4 in mode 0 */
Define_static(mercury__prog_out__write_list__ho1__ua0_4_0);
	MR_incr_sp_push_msg(3, "prog_out:write_list__ho1__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i1003);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list__ho1__ua0_4_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("prog_out__write_module_list", 27);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i4,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list__ho1__ua0_4_0_i6);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("`", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i7,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i22,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i6);
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list__ho1__ua0_4_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("`", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i12,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i13,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i14,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i15,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__prog_out__write_list__ho1__ua0_4_0_i1003);
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("`", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i17,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i18,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i19,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i19);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" and ", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i20,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i20);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("`", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i21,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_list__ho1__ua0_4_0_i22,
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
Define_label(mercury__prog_out__write_list__ho1__ua0_4_0_i22);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list__ho1__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__prog_out__write_list__ho1__ua0_4_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
Declare_entry(mercury__varset__init_1_0);
Declare_entry(mercury__term_io__write_term_nl_4_0);

BEGIN_MODULE(prog_out_module1)
	init_entry(mercury__prog_out__write_messages_3_0);
	init_label(mercury__prog_out__write_messages_3_0_i1006);
	init_label(mercury__prog_out__write_messages_3_0_i6);
	init_label(mercury__prog_out__write_messages_3_0_i7);
	init_label(mercury__prog_out__write_messages_3_0_i4);
	init_label(mercury__prog_out__write_messages_3_0_i9);
	init_label(mercury__prog_out__write_messages_3_0_i10);
	init_label(mercury__prog_out__write_messages_3_0_i16);
	init_label(mercury__prog_out__write_messages_3_0_i17);
	init_label(mercury__prog_out__write_messages_3_0_i18);
	init_label(mercury__prog_out__write_messages_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_messages'/3 in mode 0 */
Define_entry(mercury__prog_out__write_messages_3_0);
	MR_incr_sp_push_msg(5, "prog_out:write_messages/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__prog_out__write_messages_3_0_i1006);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i3);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i4);
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_out__context_to_string_2_0),
		mercury__prog_out__write_messages_3_0_i6,
		ENTRY(mercury__prog_out__write_messages_3_0));
	}
Define_label(mercury__prog_out__write_messages_3_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_messages_3_0_i7,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_messages_3_0_i9,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i4);
	MR_stackvar(2) = r5;
	r1 = r4;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_messages_3_0_i9,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	if ((MR_tag(MR_stackvar(4)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i10);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i10);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i10);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_messages_3_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_messages_3_0_i18,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const(": ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_messages_3_0_i16,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i16);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__prog_out__write_messages_3_0_i17,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__term_io__write_term_nl_4_0),
		mercury__prog_out__write_messages_3_0_i18,
		ENTRY(mercury__prog_out__write_messages_3_0));
Define_label(mercury__prog_out__write_messages_3_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_out__write_messages_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__prog_out__write_messages_3_0_i1006);
Define_label(mercury__prog_out__write_messages_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(prog_out_module2)
	init_entry(mercury__prog_out__write_context_3_0);
	init_label(mercury__prog_out__write_context_3_0_i2);
BEGIN_CODE

/* code for predicate 'write_context'/3 in mode 0 */
Define_entry(mercury__prog_out__write_context_3_0);
	MR_incr_sp_push_msg(2, "prog_out:write_context/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__prog_out__context_to_string_2_0),
		mercury__prog_out__write_context_3_0_i2,
		ENTRY(mercury__prog_out__write_context_3_0));
Define_label(mercury__prog_out__write_context_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__write_context_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__prog_out__write_context_3_0));
END_MODULE

Declare_entry(mercury__term__context_file_2_0);
Declare_entry(mercury__term__context_line_2_0);
Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(prog_out_module3)
	init_entry(mercury__prog_out__context_to_string_2_0);
	init_label(mercury__prog_out__context_to_string_2_0_i2);
	init_label(mercury__prog_out__context_to_string_2_0_i3);
	init_label(mercury__prog_out__context_to_string_2_0_i4);
BEGIN_CODE

/* code for predicate 'context_to_string'/2 in mode 0 */
Define_entry(mercury__prog_out__context_to_string_2_0);
	MR_incr_sp_push_msg(2, "prog_out:context_to_string/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__term__context_file_2_0),
		mercury__prog_out__context_to_string_2_0_i2,
		ENTRY(mercury__prog_out__context_to_string_2_0));
Define_label(mercury__prog_out__context_to_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__context_to_string_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__term__context_line_2_0),
		mercury__prog_out__context_to_string_2_0_i3,
		ENTRY(mercury__prog_out__context_to_string_2_0));
Define_label(mercury__prog_out__context_to_string_2_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_out__context_to_string_2_0));
	if ((strcmp((char *)MR_stackvar(1), (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__prog_out__context_to_string_2_0_i4);
	r1 = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__prog_out__context_to_string_2_0_i4);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_out__context_to_string_2_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_string_const("%s:%03d: ", 9);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_out__context_to_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_out__context_to_string_2_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_out__context_to_string_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__format_3_0),
		ENTRY(mercury__prog_out__context_to_string_2_0));
	}
END_MODULE

Declare_entry(mercury__string__length_2_0);

BEGIN_MODULE(prog_out_module4)
	init_entry(mercury__prog_out__write_strings_with_context_4_0);
	init_label(mercury__prog_out__write_strings_with_context_4_0_i2);
	init_label(mercury__prog_out__write_strings_with_context_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_strings_with_context'/4 in mode 0 */
Define_entry(mercury__prog_out__write_strings_with_context_4_0);
	MR_incr_sp_push_msg(4, "prog_out:write_strings_with_context/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_out__context_to_string_2_0),
		mercury__prog_out__write_strings_with_context_4_0_i2,
		ENTRY(mercury__prog_out__write_strings_with_context_4_0));
Define_label(mercury__prog_out__write_strings_with_context_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_4_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_out__write_strings_with_context_4_0_i3,
		ENTRY(mercury__prog_out__write_strings_with_context_4_0));
Define_label(mercury__prog_out__write_strings_with_context_4_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = (Integer) 0;
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__prog_out__write_strings_with_context_2_6_0),
		ENTRY(mercury__prog_out__write_strings_with_context_4_0));
END_MODULE

Declare_entry(mercury__term_io__write_escaped_string_3_0);

BEGIN_MODULE(prog_out_module5)
	init_entry(mercury__prog_out__write_sym_name_3_0);
	init_label(mercury__prog_out__write_sym_name_3_0_i3);
	init_label(mercury__prog_out__write_sym_name_3_0_i5);
	init_label(mercury__prog_out__write_sym_name_3_0_i6);
BEGIN_CODE

/* code for predicate 'write_sym_name'/3 in mode 0 */
Define_entry(mercury__prog_out__write_sym_name_3_0);
	MR_incr_sp_push_msg(2, "prog_out:write_sym_name/3");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__write_sym_name_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__term_io__write_escaped_string_3_0),
		ENTRY(mercury__prog_out__write_sym_name_3_0));
Define_label(mercury__prog_out__write_sym_name_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_out__write_module_spec_3_0),
		mercury__prog_out__write_sym_name_3_0_i5,
		ENTRY(mercury__prog_out__write_sym_name_3_0));
Define_label(mercury__prog_out__write_sym_name_3_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_out__write_sym_name_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_sym_name_3_0_i6,
		ENTRY(mercury__prog_out__write_sym_name_3_0));
Define_label(mercury__prog_out__write_sym_name_3_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_out__write_sym_name_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__term_io__write_escaped_string_3_0),
		ENTRY(mercury__prog_out__write_sym_name_3_0));
END_MODULE

Declare_entry(mercury__io__write_int_3_0);

BEGIN_MODULE(prog_out_module6)
	init_entry(mercury__prog_out__write_sym_name_and_arity_3_0);
	init_label(mercury__prog_out__write_sym_name_and_arity_3_0_i2);
	init_label(mercury__prog_out__write_sym_name_and_arity_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_sym_name_and_arity'/3 in mode 0 */
Define_entry(mercury__prog_out__write_sym_name_and_arity_3_0);
	MR_incr_sp_push_msg(2, "prog_out:write_sym_name_and_arity/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_sym_name_and_arity_3_0_i2,
		ENTRY(mercury__prog_out__write_sym_name_and_arity_3_0));
Define_label(mercury__prog_out__write_sym_name_and_arity_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__write_sym_name_and_arity_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("/", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_sym_name_and_arity_3_0_i3,
		ENTRY(mercury__prog_out__write_sym_name_and_arity_3_0));
Define_label(mercury__prog_out__write_sym_name_and_arity_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_out__write_sym_name_and_arity_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		ENTRY(mercury__prog_out__write_sym_name_and_arity_3_0));
END_MODULE


BEGIN_MODULE(prog_out_module7)
	init_entry(mercury__prog_out__write_quoted_sym_name_3_0);
	init_label(mercury__prog_out__write_quoted_sym_name_3_0_i2);
	init_label(mercury__prog_out__write_quoted_sym_name_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_quoted_sym_name'/3 in mode 0 */
Define_entry(mercury__prog_out__write_quoted_sym_name_3_0);
	MR_incr_sp_push_msg(2, "prog_out:write_quoted_sym_name/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("'", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_quoted_sym_name_3_0_i2,
		ENTRY(mercury__prog_out__write_quoted_sym_name_3_0));
Define_label(mercury__prog_out__write_quoted_sym_name_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__write_quoted_sym_name_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__prog_out__write_sym_name_3_0),
		mercury__prog_out__write_quoted_sym_name_3_0_i3,
		ENTRY(mercury__prog_out__write_quoted_sym_name_3_0));
Define_label(mercury__prog_out__write_quoted_sym_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_out__write_quoted_sym_name_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__prog_out__write_quoted_sym_name_3_0));
END_MODULE

Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(prog_out_module8)
	init_entry(mercury__prog_out__sym_name_to_string_2_0);
	init_label(mercury__prog_out__sym_name_to_string_2_0_i2);
BEGIN_CODE

/* code for predicate 'sym_name_to_string'/2 in mode 0 */
Define_entry(mercury__prog_out__sym_name_to_string_2_0);
	MR_incr_sp_push_msg(1, "prog_out:sym_name_to_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = (Word) MR_string_const(":", 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__prog_out__sym_name_to_string_2_4_0),
		mercury__prog_out__sym_name_to_string_2_0_i2,
		ENTRY(mercury__prog_out__sym_name_to_string_2_0));
Define_label(mercury__prog_out__sym_name_to_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__sym_name_to_string_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__prog_out__sym_name_to_string_2_0));
END_MODULE


BEGIN_MODULE(prog_out_module9)
	init_entry(mercury__prog_out__sym_name_to_string_3_0);
	init_label(mercury__prog_out__sym_name_to_string_3_0_i2);
BEGIN_CODE

/* code for predicate 'sym_name_to_string'/3 in mode 0 */
Define_entry(mercury__prog_out__sym_name_to_string_3_0);
	MR_incr_sp_push_msg(1, "prog_out:sym_name_to_string/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__prog_out__sym_name_to_string_2_4_0),
		mercury__prog_out__sym_name_to_string_3_0_i2,
		ENTRY(mercury__prog_out__sym_name_to_string_3_0));
Define_label(mercury__prog_out__sym_name_to_string_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_out__sym_name_to_string_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__prog_out__sym_name_to_string_3_0));
END_MODULE


BEGIN_MODULE(prog_out_module10)
	init_entry(mercury__prog_out__write_module_spec_3_0);
BEGIN_CODE

/* code for predicate 'write_module_spec'/3 in mode 0 */
Define_entry(mercury__prog_out__write_module_spec_3_0);
	tailcall(STATIC(mercury__prog_out__write_sym_name_3_0),
		ENTRY(mercury__prog_out__write_module_spec_3_0));
END_MODULE


BEGIN_MODULE(prog_out_module11)
	init_entry(mercury__prog_out__write_module_list_3_0);
BEGIN_CODE

/* code for predicate 'write_module_list'/3 in mode 0 */
Define_entry(mercury__prog_out__write_module_list_3_0);
	tailcall(STATIC(mercury__prog_out__write_list__ho1__ua0_4_0),
		ENTRY(mercury__prog_out__write_module_list_3_0));
END_MODULE

Declare_entry(mercury__do_call_closure);

BEGIN_MODULE(prog_out_module12)
	init_entry(mercury__prog_out__write_list_4_0);
	init_label(mercury__prog_out__write_list_4_0_i1003);
	init_label(mercury__prog_out__write_list_4_0_i4);
	init_label(mercury__prog_out__write_list_4_0_i3);
	init_label(mercury__prog_out__write_list_4_0_i6);
	init_label(mercury__prog_out__write_list_4_0_i10);
	init_label(mercury__prog_out__write_list_4_0_i11);
	init_label(mercury__prog_out__write_list_4_0_i9);
	init_label(mercury__prog_out__write_list_4_0_i13);
	init_label(mercury__prog_out__write_list_4_0_i14);
BEGIN_CODE

/* code for predicate 'write_list'/4 in mode 0 */
Define_entry(mercury__prog_out__write_list_4_0);
	MR_incr_sp_push_msg(4, "prog_out:write_list/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__prog_out__write_list_4_0_i1003);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list_4_0_i3);
	MR_stackvar(1) = r4;
	r1 = (Word) MR_string_const("prog_out__write_module_list", 27);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__prog_out__write_list_4_0_i4,
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list_4_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_out__write_list_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list_4_0_i6);
	r1 = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = r1;
	r1 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__do_call_closure),
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i6);
	r5 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_list_4_0_i9);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r5 = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__prog_out__write_list_4_0_i10,
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list_4_0_i11,
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list_4_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__prog_out__write_list_4_0_i1003);
Define_label(mercury__prog_out__write_list_4_0_i9);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r1 = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = r1;
	r1 = r3;
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__prog_out__write_list_4_0_i13,
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i13);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" and ", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_list_4_0_i14,
		ENTRY(mercury__prog_out__write_list_4_0));
Define_label(mercury__prog_out__write_list_4_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_out__write_list_4_0));
	r4 = MR_stackvar(2);
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__do_call_closure),
		ENTRY(mercury__prog_out__write_list_4_0));
END_MODULE

Declare_entry(mercury__io__write_char_3_0);

BEGIN_MODULE(prog_out_module13)
	init_entry(mercury__prog_out__write_strings_with_context_2_6_0);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i4);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i7);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i8);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i9);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i5);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i11);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i10);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i12);
	init_label(mercury__prog_out__write_strings_with_context_2_6_0_i3);
BEGIN_CODE

/* code for predicate 'write_strings_with_context_2'/6 in mode 0 */
Define_static(mercury__prog_out__write_strings_with_context_2_6_0);
	MR_incr_sp_push_msg(8, "prog_out:write_strings_with_context_2/6");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i3);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(6) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i4,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i5);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i7,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i8,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i9,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	r5 = r1;
	r2 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	r4 = ((Integer) r2 + (Integer) MR_stackvar(3));
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i5);
	r2 = ((Integer) r1 + (Integer) MR_stackvar(4));
	if (((Integer) r2 >= (Integer) 80))
		GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i10);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i11,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i10);
	r1 = (Integer) 10;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_char_3_0),
		mercury__prog_out__write_strings_with_context_2_6_0_i12,
		STATIC(mercury__prog_out__write_strings_with_context_2_6_0));
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__prog_out__write_strings_with_context_2_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__prog_out__write_strings_with_context_2_6_0_i1003);
Define_label(mercury__prog_out__write_strings_with_context_2_6_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(prog_out_module14)
	init_entry(mercury__prog_out__sym_name_to_string_2_4_0);
	init_label(mercury__prog_out__sym_name_to_string_2_4_0_i4);
	init_label(mercury__prog_out__sym_name_to_string_2_4_0_i2);
BEGIN_CODE

/* code for predicate 'sym_name_to_string_2'/4 in mode 0 */
Define_static(mercury__prog_out__sym_name_to_string_2_4_0);
	if ((MR_tag(r1) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__sym_name_to_string_2_4_0_i2);
Define_label(mercury__prog_out__sym_name_to_string_2_4_0_i4);
	r4 = r1;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_out__sym_name_to_string_2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_out__sym_name_to_string_2_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r5;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_out__sym_name_to_string_2_4_0_i4);
	}
Define_label(mercury__prog_out__sym_name_to_string_2_4_0_i2);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_out__sym_name_to_string_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__prog_out_maybe_bunch_0(void)
{
	prog_out_module0();
	prog_out_module1();
	prog_out_module2();
	prog_out_module3();
	prog_out_module4();
	prog_out_module5();
	prog_out_module6();
	prog_out_module7();
	prog_out_module8();
	prog_out_module9();
	prog_out_module10();
	prog_out_module11();
	prog_out_module12();
	prog_out_module13();
	prog_out_module14();
}

#endif

void mercury__prog_out__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__prog_out__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__prog_out_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
