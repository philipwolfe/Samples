/*
** Automatically generated from `prog_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__prog_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__prog_util__list_to_string_2__ho2__ua0_4_0);
Declare_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i3);
Declare_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i4);
Declare_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i5);
Declare_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i7);
Declare_static(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i3);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i5);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i6);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i7);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i8);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i9);
Declare_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i2);
Declare_static(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0);
Declare_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i2);
Declare_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i3);
Define_extern_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
Define_extern_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Define_extern_entry(mercury__prog_util__unqualify_name_2_0);
Declare_label(mercury__prog_util__unqualify_name_2_0_i3);
Define_extern_entry(mercury__prog_util__sym_name_get_module_name_3_0);
Declare_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
Define_extern_entry(mercury__prog_util__string_to_sym_name_3_0);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i3);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i5);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i6);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i7);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i8);
Declare_label(mercury__prog_util__string_to_sym_name_3_0_i2);
Define_extern_entry(mercury__prog_util__match_sym_name_2_0);
Declare_label(mercury__prog_util__match_sym_name_2_0_i1006);
Declare_label(mercury__prog_util__match_sym_name_2_0_i5);
Declare_label(mercury__prog_util__match_sym_name_2_0_i3);
Declare_label(mercury__prog_util__match_sym_name_2_0_i1);
Define_extern_entry(mercury__prog_util__insert_module_qualifier_3_0);
Declare_label(mercury__prog_util__insert_module_qualifier_3_0_i4);
Declare_label(mercury__prog_util__insert_module_qualifier_3_0_i5);
Declare_label(mercury__prog_util__insert_module_qualifier_3_0_i2);
Define_extern_entry(mercury__prog_util__construct_qualified_term_3_0);
Declare_label(mercury__prog_util__construct_qualified_term_3_0_i2);
Define_extern_entry(mercury__prog_util__construct_qualified_term_4_0);
Declare_label(mercury__prog_util__construct_qualified_term_4_0_i4);
Declare_label(mercury__prog_util__construct_qualified_term_4_0_i5);
Declare_label(mercury__prog_util__construct_qualified_term_4_0_i1019);
Define_extern_entry(mercury__prog_util__make_pred_name_6_0);
Declare_label(mercury__prog_util__make_pred_name_6_0_i3);
Declare_label(mercury__prog_util__make_pred_name_6_0_i5);
Declare_label(mercury__prog_util__make_pred_name_6_0_i2);
Declare_label(mercury__prog_util__make_pred_name_6_0_i7);
Declare_label(mercury__prog_util__make_pred_name_6_0_i9);
Declare_label(mercury__prog_util__make_pred_name_6_0_i10);
Declare_label(mercury__prog_util__make_pred_name_6_0_i11);
Define_extern_entry(mercury__prog_util__make_pred_name_with_context_7_0);
Define_extern_entry(mercury__prog_util__split_types_and_modes_3_0);
Declare_label(mercury__prog_util__split_types_and_modes_3_0_i2);
Declare_label(mercury__prog_util__split_types_and_modes_3_0_i3);
Define_extern_entry(mercury__prog_util__split_type_and_mode_3_0);
Declare_label(mercury__prog_util__split_type_and_mode_3_0_i3);
Define_extern_entry(mercury__prog_util__rename_in_goal_4_0);
Declare_label(mercury__prog_util__rename_in_goal_4_0_i2);
Declare_static(mercury__prog_util__split_types_and_modes_2_5_0);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i4);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i7);
Declare_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
Declare_static(mercury__prog_util__rename_in_goal_expr_4_0);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i1016);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i34);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i40);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i41);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i42);
Declare_label(mercury__prog_util__rename_in_goal_expr_4_0_i43);
Declare_static(mercury__prog_util__rename_in_vars_4_0);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i5);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i4);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i8);
Declare_label(mercury__prog_util__rename_in_vars_4_0_i3);
Define_extern_entry(mercury____Unify___prog_util__new_pred_id_0_0);
Declare_label(mercury____Unify___prog_util__new_pred_id_0_0_i3);
Declare_label(mercury____Unify___prog_util__new_pred_id_0_0_i6);
Declare_label(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
Declare_label(mercury____Unify___prog_util__new_pred_id_0_0_i1);
Define_extern_entry(mercury____Index___prog_util__new_pred_id_0_0);
Declare_label(mercury____Index___prog_util__new_pred_id_0_0_i3);
Define_extern_entry(mercury____Compare___prog_util__new_pred_id_0_0);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i3);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i2);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i5);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i4);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i6);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i7);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i14);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i11);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i21);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i1016);
Declare_label(mercury____Compare___prog_util__new_pred_id_0_0_i29);
Define_extern_entry(mercury____Unify___prog_util__maybe_modes_0_0);
Define_extern_entry(mercury____Index___prog_util__maybe_modes_0_0);
Define_extern_entry(mercury____Compare___prog_util__maybe_modes_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_prog_util__type_ctor_info_maybe_modes_0;

const struct MR_TypeCtorInfo_struct mercury_data_prog_util__type_ctor_info_new_pred_id_0;

static const struct mercury_data_prog_util__common_0_struct {
	String f1;
}  mercury_data_prog_util__common_0;

static const struct mercury_data_prog_util__common_1_struct {
	String f1;
}  mercury_data_prog_util__common_1;

static const struct mercury_data_prog_util__common_2_struct {
	String f1;
}  mercury_data_prog_util__common_2;

static const struct mercury_data_prog_util__common_3_struct {
	String f1;
	Word * f2;
}  mercury_data_prog_util__common_3;

static const struct mercury_data_prog_util__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_4;

static const struct mercury_data_prog_util__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_5;

static const struct mercury_data_prog_util__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_6;

static const struct mercury_data_prog_util__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_prog_util__common_7;

static const struct mercury_data_prog_util__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_8;

static const struct mercury_data_prog_util__common_9_struct {
	Word * f1;
}  mercury_data_prog_util__common_9;

static const struct mercury_data_prog_util__common_10_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_prog_util__common_10;

static const struct mercury_data_prog_util__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_11;

static const struct mercury_data_prog_util__common_12_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_12;

static const struct mercury_data_prog_util__common_13_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_prog_util__common_13;

static const struct mercury_data_prog_util__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_prog_util__common_14;

static const struct mercury_data_prog_util__common_15_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_util__common_15;

static const struct mercury_data_prog_util__type_ctor_functors_new_pred_id_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_util__type_ctor_functors_new_pred_id_0;

static const struct mercury_data_prog_util__type_ctor_layout_new_pred_id_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_util__type_ctor_layout_new_pred_id_0;

static const struct mercury_data_prog_util__type_ctor_functors_maybe_modes_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_prog_util__type_ctor_functors_maybe_modes_0;

static const struct mercury_data_prog_util__type_ctor_layout_maybe_modes_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_prog_util__type_ctor_layout_maybe_modes_0;

const struct MR_TypeCtorInfo_struct mercury_data_prog_util__type_ctor_info_maybe_modes_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_util__maybe_modes_0_0),
	ENTRY(mercury____Index___prog_util__maybe_modes_0_0),
	ENTRY(mercury____Compare___prog_util__maybe_modes_0_0),
	(Integer) 6,
	(Word *) &mercury_data_prog_util__type_ctor_functors_maybe_modes_0,
	(Word *) &mercury_data_prog_util__type_ctor_layout_maybe_modes_0,
	MR_string_const("prog_util", 9),
	MR_string_const("maybe_modes", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_prog_util__type_ctor_info_new_pred_id_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___prog_util__new_pred_id_0_0),
	ENTRY(mercury____Index___prog_util__new_pred_id_0_0),
	ENTRY(mercury____Compare___prog_util__new_pred_id_0_0),
	(Integer) 2,
	(Word *) &mercury_data_prog_util__type_ctor_functors_new_pred_id_0,
	(Word *) &mercury_data_prog_util__type_ctor_layout_new_pred_id_0,
	MR_string_const("prog_util", 9),
	MR_string_const("new_pred_id", 11),
	(Integer) 3
};

static const struct mercury_data_prog_util__common_0_struct mercury_data_prog_util__common_0 = {
	MR_string_const("builtin", 7)
};

static const struct mercury_data_prog_util__common_1_struct mercury_data_prog_util__common_1 = {
	MR_string_const("private_builtin", 15)
};

static const struct mercury_data_prog_util__common_2_struct mercury_data_prog_util__common_2 = {
	MR_string_const(":", 1)
};

static const struct mercury_data_prog_util__common_3_struct mercury_data_prog_util__common_3 = {
	MR_string_const("]", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_prog_util__common_4_struct mercury_data_prog_util__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_prog_util__common_5_struct mercury_data_prog_util__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
static const struct mercury_data_prog_util__common_6_struct mercury_data_prog_util__common_6 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_prog_util__common_7_struct mercury_data_prog_util__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_6)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
static const struct mercury_data_prog_util__common_8_struct mercury_data_prog_util__common_8 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_mode_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_prog_util__common_9_struct mercury_data_prog_util__common_9 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_prog_util__common_10_struct mercury_data_prog_util__common_10 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_9),
	MR_string_const("counter", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_prog_util__common_11_struct mercury_data_prog_util__common_11 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_prog_util__common_12_struct mercury_data_prog_util__common_12 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_7)
};

static const struct mercury_data_prog_util__common_13_struct mercury_data_prog_util__common_13 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_11),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_12),
	MR_string_const("type_subst", 10),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_prog_util__common_14_struct mercury_data_prog_util__common_14 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_8)
};

static const struct mercury_data_prog_util__common_15_struct mercury_data_prog_util__common_15 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_14)
};

static const struct mercury_data_prog_util__type_ctor_functors_new_pred_id_0_struct mercury_data_prog_util__type_ctor_functors_new_pred_id_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_13)
};

static const struct mercury_data_prog_util__type_ctor_layout_new_pred_id_0_struct mercury_data_prog_util__type_ctor_layout_new_pred_id_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_util__common_10),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_util__common_13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_prog_util__type_ctor_functors_maybe_modes_0_struct mercury_data_prog_util__type_ctor_functors_maybe_modes_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_14)
};

static const struct mercury_data_prog_util__type_ctor_layout_maybe_modes_0_struct mercury_data_prog_util__type_ctor_layout_maybe_modes_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_prog_util__common_15)
};


BEGIN_MODULE(prog_util_module0)
	init_entry(mercury__prog_util__list_to_string_2__ho2__ua0_4_0);
	init_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i3);
	init_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i4);
	init_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i5);
	init_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i7);
BEGIN_CODE

/* code for predicate 'list_to_string_2__ho2__ua0'/4 in mode 0 */
Define_static(mercury__prog_util__list_to_string_2__ho2__ua0_4_0);
	MR_incr_sp_push_msg(4, "prog_util:list_to_string_2__ho2__ua0/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i3);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0),
		mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i4,
		STATIC(mercury__prog_util__list_to_string_2__ho2__ua0_4_0));
Define_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i4);
	update_prof_current_proc(LABEL(mercury__prog_util__list_to_string_2__ho2__ua0_4_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__list_to_string_2__ho2__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i5);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	localcall(mercury__prog_util__list_to_string_2__ho2__ua0_4_0,
		LABEL(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i7),
		STATIC(mercury__prog_util__list_to_string_2__ho2__ua0_4_0));
Define_label(mercury__prog_util__list_to_string_2__ho2__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_util__list_to_string_2__ho2__ua0_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__list_to_string_2__ho2__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_util__list_to_string_2__ho2__ua0_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(", ", 2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__string__sub_string_search_3_0);
Declare_entry(mercury__string__left_3_0);
Declare_entry(mercury__string__length_2_0);
Declare_entry(mercury__string__right_3_0);

BEGIN_MODULE(prog_util_module1)
	init_entry(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i3);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i5);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i6);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i7);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i8);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i9);
	init_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i2);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__string_to_sym_name__301__0'/4 in mode 0 */
Define_static(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0);
	MR_incr_sp_push_msg(7, "prog_util:DeforestationIn__pred__string_to_sym_name__301__0/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__string__sub_string_search_3_0),
		mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i3,
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i2);
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i2);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__left_3_0),
		mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i5,
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i6,
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i7,
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	r2 = (((Integer) MR_stackvar(6) - (Integer) MR_stackvar(4)) - (Integer) r1);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__right_3_0),
		mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i8,
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	localcall(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0,
		LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i9),
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__prog_util__insert_module_qualifier_3_0),
		STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0));
Define_label(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0, "prog_data:sym_name/0");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__varset__lookup_name_3_0);
Declare_entry(mercury__mercury_to_mercury__mercury_type_to_string_3_0);
Declare_entry(mercury__string__append_list_2_0);

BEGIN_MODULE(prog_util_module2)
	init_entry(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0);
	init_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i2);
	init_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i3);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__make_pred_name__349__1'/3 in mode 0 */
Define_static(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0);
	MR_incr_sp_push_msg(3, "prog_util:IntroducedFrom__pred__make_pred_name__349__1/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i2,
		STATIC(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0));
Define_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_type_to_string_3_0),
		mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i3,
		STATIC(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0));
Define_label(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(" = ", 3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__prog_util__IntroducedFrom__pred__make_pred_name__349__1_3_0));
	}
END_MODULE


BEGIN_MODULE(prog_util_module3)
	init_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
BEGIN_CODE

/* code for predicate 'mercury_public_builtin_module'/1 in mode 0 */
Define_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_0);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module4)
	init_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
BEGIN_CODE

/* code for predicate 'mercury_private_builtin_module'/1 in mode 0 */
Define_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_1);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module5)
	init_entry(mercury__prog_util__unqualify_name_2_0);
	init_label(mercury__prog_util__unqualify_name_2_0_i3);
BEGIN_CODE

/* code for predicate 'unqualify_name'/2 in mode 0 */
Define_entry(mercury__prog_util__unqualify_name_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__unqualify_name_2_0_i3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
Define_label(mercury__prog_util__unqualify_name_2_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module6)
	init_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	init_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
BEGIN_CODE

/* code for predicate 'sym_name_get_module_name'/3 in mode 0 */
Define_entry(mercury__prog_util__sym_name_get_module_name_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__sym_name_get_module_name_3_0_i3);
	r1 = r2;
	proceed();
Define_label(mercury__prog_util__sym_name_get_module_name_3_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module7)
	init_entry(mercury__prog_util__string_to_sym_name_3_0);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i3);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i5);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i6);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i7);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i8);
	init_label(mercury__prog_util__string_to_sym_name_3_0_i2);
BEGIN_CODE

/* code for predicate 'string_to_sym_name'/3 in mode 0 */
Define_entry(mercury__prog_util__string_to_sym_name_3_0);
	MR_incr_sp_push_msg(6, "prog_util:string_to_sym_name/3");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__string__sub_string_search_3_0),
		mercury__prog_util__string_to_sym_name_3_0_i3,
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i3);
	update_prof_current_proc(LABEL(mercury__prog_util__string_to_sym_name_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_util__string_to_sym_name_3_0_i2);
	if (((Integer) r2 <= (Integer) 0))
		GOTO_LABEL(mercury__prog_util__string_to_sym_name_3_0_i2);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__left_3_0),
		mercury__prog_util__string_to_sym_name_3_0_i5,
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_util__string_to_sym_name_3_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_util__string_to_sym_name_3_0_i6,
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i6);
	update_prof_current_proc(LABEL(mercury__prog_util__string_to_sym_name_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__length_2_0),
		mercury__prog_util__string_to_sym_name_3_0_i7,
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_util__string_to_sym_name_3_0));
	r2 = (((Integer) MR_stackvar(5) - (Integer) MR_stackvar(3)) - (Integer) r1);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__right_3_0),
		mercury__prog_util__string_to_sym_name_3_0_i8,
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_util__string_to_sym_name_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__prog_util__DeforestationIn__pred__string_to_sym_name__301__0_4_0),
		ENTRY(mercury__prog_util__string_to_sym_name_3_0));
Define_label(mercury__prog_util__string_to_sym_name_3_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__prog_util__string_to_sym_name_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module8)
	init_entry(mercury__prog_util__match_sym_name_2_0);
	init_label(mercury__prog_util__match_sym_name_2_0_i1006);
	init_label(mercury__prog_util__match_sym_name_2_0_i5);
	init_label(mercury__prog_util__match_sym_name_2_0_i3);
	init_label(mercury__prog_util__match_sym_name_2_0_i1);
BEGIN_CODE

/* code for predicate 'match_sym_name'/2 in mode 0 */
Define_entry(mercury__prog_util__match_sym_name_2_0);
	MR_incr_sp_push_msg(1, "prog_util:match_sym_name/2");
	MR_stackvar(1) = (Word) MR_succip;
Define_label(mercury__prog_util__match_sym_name_2_0_i1006);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(0), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__prog_util__match_sym_name_2_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(1), r2, (Integer) 1)) != 0))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__prog_util__match_sym_name_2_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r1, (Integer) 1), (char *)r3) != 0))
		GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__prog_util__match_sym_name_2_0_i1006);
Define_label(mercury__prog_util__match_sym_name_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module9)
	init_entry(mercury__prog_util__insert_module_qualifier_3_0);
	init_label(mercury__prog_util__insert_module_qualifier_3_0_i4);
	init_label(mercury__prog_util__insert_module_qualifier_3_0_i5);
	init_label(mercury__prog_util__insert_module_qualifier_3_0_i2);
BEGIN_CODE

/* code for predicate 'insert_module_qualifier'/3 in mode 0 */
Define_entry(mercury__prog_util__insert_module_qualifier_3_0);
	if ((MR_tag(r2) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__insert_module_qualifier_3_0_i2);
	r5 = (Word) MR_sp;
Define_label(mercury__prog_util__insert_module_qualifier_3_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "prog_util:insert_module_qualifier");
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		continue;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__insert_module_qualifier_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__prog_util__insert_module_qualifier_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_tempr1;
	}
	break; } /* end while */
Define_label(mercury__prog_util__insert_module_qualifier_3_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__insert_module_qualifier_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r5))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__prog_util__insert_module_qualifier_3_0_i2);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__insert_module_qualifier_3_0, "prog_data:sym_name/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__prog_util__insert_module_qualifier_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE

Declare_entry(mercury__term__context_init_1_0);

BEGIN_MODULE(prog_util_module10)
	init_entry(mercury__prog_util__construct_qualified_term_3_0);
	init_label(mercury__prog_util__construct_qualified_term_3_0_i2);
BEGIN_CODE

/* code for predicate 'construct_qualified_term'/3 in mode 0 */
Define_entry(mercury__prog_util__construct_qualified_term_3_0);
	MR_incr_sp_push_msg(4, "prog_util:construct_qualified_term/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__prog_util__construct_qualified_term_3_0_i2,
		ENTRY(mercury__prog_util__construct_qualified_term_3_0));
Define_label(mercury__prog_util__construct_qualified_term_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__construct_qualified_term_3_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__prog_util__construct_qualified_term_4_0),
		ENTRY(mercury__prog_util__construct_qualified_term_3_0));
END_MODULE


BEGIN_MODULE(prog_util_module11)
	init_entry(mercury__prog_util__construct_qualified_term_4_0);
	init_label(mercury__prog_util__construct_qualified_term_4_0_i4);
	init_label(mercury__prog_util__construct_qualified_term_4_0_i5);
	init_label(mercury__prog_util__construct_qualified_term_4_0_i1019);
BEGIN_CODE

/* code for predicate 'construct_qualified_term'/4 in mode 0 */
Define_entry(mercury__prog_util__construct_qualified_term_4_0);
	if ((MR_tag(r2) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__construct_qualified_term_4_0_i1019);
	r7 = (Word) MR_sp;
Define_label(mercury__prog_util__construct_qualified_term_4_0_i4);
	while (1) {
	MR_incr_sp_push_msg(3, "prog_util:construct_qualified_term");
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r6 = r3;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		continue;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__prog_util__construct_qualified_term_4_0, "term:term/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__prog_util__construct_qualified_term_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	}
	break; } /* end while */
Define_label(mercury__prog_util__construct_qualified_term_4_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__prog_util__construct_qualified_term_4_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__prog_util__construct_qualified_term_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_util__construct_qualified_term_4_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__prog_util__construct_qualified_term_4_0, "term:term/1");
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__prog_util__construct_qualified_term_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	MR_decr_sp_pop_msg(3);
	if (((Integer) MR_sp > (Integer) r7))
		GOTO_LABEL(mercury__prog_util__construct_qualified_term_4_0_i5);
	proceed();
	}
Define_label(mercury__prog_util__construct_qualified_term_4_0_i1019);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__prog_util__construct_qualified_term_4_0, "term:term/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__prog_util__construct_qualified_term_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	proceed();
	}
END_MODULE

Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(prog_util_module12)
	init_entry(mercury__prog_util__make_pred_name_6_0);
	init_label(mercury__prog_util__make_pred_name_6_0_i3);
	init_label(mercury__prog_util__make_pred_name_6_0_i5);
	init_label(mercury__prog_util__make_pred_name_6_0_i2);
	init_label(mercury__prog_util__make_pred_name_6_0_i7);
	init_label(mercury__prog_util__make_pred_name_6_0_i9);
	init_label(mercury__prog_util__make_pred_name_6_0_i10);
	init_label(mercury__prog_util__make_pred_name_6_0_i11);
BEGIN_CODE

/* code for predicate 'make_pred_name'/6 in mode 0 */
Define_entry(mercury__prog_util__make_pred_name_6_0);
	MR_incr_sp_push_msg(5, "prog_util:make_pred_name/6");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__make_pred_name_6_0_i3);
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = (Word) MR_string_const("pred_or_func", 12);
	GOTO_LABEL(mercury__prog_util__make_pred_name_6_0_i2);
Define_label(mercury__prog_util__make_pred_name_6_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__prog_util__make_pred_name_6_0_i5);
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = (Word) MR_string_const("pred", 4);
	GOTO_LABEL(mercury__prog_util__make_pred_name_6_0_i2);
Define_label(mercury__prog_util__make_pred_name_6_0_i5);
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = (Word) MR_string_const("func", 4);
Define_label(mercury__prog_util__make_pred_name_6_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__make_pred_name_6_0_i7);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_string_const("%d__%d", 6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__prog_util__make_pred_name_6_0_i10,
		ENTRY(mercury__prog_util__make_pred_name_6_0));
	}
Define_label(mercury__prog_util__make_pred_name_6_0_i7);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_prog_util__common_3);
	call_localret(STATIC(mercury__prog_util__list_to_string_2__ho2__ua0_4_0),
		mercury__prog_util__make_pred_name_6_0_i9,
		ENTRY(mercury__prog_util__make_pred_name_6_0));
Define_label(mercury__prog_util__make_pred_name_6_0_i9);
	update_prof_current_proc(LABEL(mercury__prog_util__make_pred_name_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("[", 1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__prog_util__make_pred_name_6_0_i10,
		ENTRY(mercury__prog_util__make_pred_name_6_0));
Define_label(mercury__prog_util__make_pred_name_6_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_util__make_pred_name_6_0));
	r3 = r1;
	r1 = (Word) MR_string_const("%s__%s__%s__%s", 14);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "list:list/1");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__prog_util__make_pred_name_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__prog_util__make_pred_name_6_0_i11,
		ENTRY(mercury__prog_util__make_pred_name_6_0));
	}
Define_label(mercury__prog_util__make_pred_name_6_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_util__make_pred_name_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__make_pred_name_6_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module13)
	init_entry(mercury__prog_util__make_pred_name_with_context_7_0);
BEGIN_CODE

/* code for predicate 'make_pred_name_with_context'/7 in mode 0 */
Define_entry(mercury__prog_util__make_pred_name_with_context_7_0);
	r7 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__prog_util__make_pred_name_with_context_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__prog_util__make_pred_name_with_context_7_0, "prog_util:new_pred_id/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	tailcall(STATIC(mercury__prog_util__make_pred_name_6_0),
		ENTRY(mercury__prog_util__make_pred_name_with_context_7_0));
	}
END_MODULE


BEGIN_MODULE(prog_util_module14)
	init_entry(mercury__prog_util__split_types_and_modes_3_0);
	init_label(mercury__prog_util__split_types_and_modes_3_0_i2);
	init_label(mercury__prog_util__split_types_and_modes_3_0_i3);
BEGIN_CODE

/* code for predicate 'split_types_and_modes'/3 in mode 0 */
Define_entry(mercury__prog_util__split_types_and_modes_3_0);
	MR_incr_sp_push_msg(1, "prog_util:split_types_and_modes/3");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = (Integer) 1;
	call_localret(STATIC(mercury__prog_util__split_types_and_modes_2_5_0),
		mercury__prog_util__split_types_and_modes_3_0_i2,
		ENTRY(mercury__prog_util__split_types_and_modes_3_0));
Define_label(mercury__prog_util__split_types_and_modes_3_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__split_types_and_modes_3_0));
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_3_0_i3);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__prog_util__split_types_and_modes_3_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__prog_util__split_types_and_modes_3_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module15)
	init_entry(mercury__prog_util__split_type_and_mode_3_0);
	init_label(mercury__prog_util__split_type_and_mode_3_0_i3);
BEGIN_CODE

/* code for predicate 'split_type_and_mode'/3 in mode 0 */
Define_entry(mercury__prog_util__split_type_and_mode_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__split_type_and_mode_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__prog_util__split_type_and_mode_3_0_i3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__prog_util__split_type_and_mode_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module16)
	init_entry(mercury__prog_util__rename_in_goal_4_0);
	init_label(mercury__prog_util__rename_in_goal_4_0_i2);
BEGIN_CODE

/* code for predicate 'rename_in_goal'/4 in mode 0 */
Define_entry(mercury__prog_util__rename_in_goal_4_0);
	MR_incr_sp_push_msg(2, "prog_util:rename_in_goal/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_expr_4_0),
		mercury__prog_util__rename_in_goal_4_0_i2,
		ENTRY(mercury__prog_util__rename_in_goal_4_0));
Define_label(mercury__prog_util__rename_in_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__prog_util__rename_in_goal_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module17)
	init_entry(mercury__prog_util__split_types_and_modes_2_5_0);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i4);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i7);
	init_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
BEGIN_CODE

/* code for predicate 'split_types_and_modes_2'/5 in mode 0 */
Define_static(mercury__prog_util__split_types_and_modes_2_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i2);
	r6 = (Word) MR_sp;
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	MR_incr_sp_push_msg(2, "prog_util:split_types_and_modes_2");
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = (Integer) 0;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_4);
	GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i3);
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i4);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i3);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i7);
	r5 = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__prog_util__split_types_and_modes_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	r1 = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__prog_util__split_types_and_modes_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_decr_sp_pop_msg(2);
	if (((Integer) MR_sp > (Integer) r6))
		GOTO_LABEL(mercury__prog_util__split_types_and_modes_2_5_0_i7);
	proceed();
	}
Define_label(mercury__prog_util__split_types_and_modes_2_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
Declare_entry(mercury__term__substitute_list_4_0);
Declare_entry(mercury__term__substitute_4_0);

BEGIN_MODULE(prog_util_module18)
	init_entry(mercury__prog_util__rename_in_goal_expr_4_0);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i1016);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i34);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i40);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i41);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i42);
	init_label(mercury__prog_util__rename_in_goal_expr_4_0_i43);
BEGIN_CODE

/* code for predicate 'rename_in_goal_expr'/4 in mode 0 */
Define_static(mercury__prog_util__rename_in_goal_expr_4_0);
	MR_incr_sp_push_msg(6, "prog_util:rename_in_goal_expr/4");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i1016) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i6) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i9) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i12));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i1016);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i6);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i7,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i7);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i8,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i9);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__prog_util__rename_in_goal_expr_4_0,
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i10),
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i10);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__prog_util__rename_in_goal_expr_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i11,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i11);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i13) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i16) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i19) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i22) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i25) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i28) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i30) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i34) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i39) AND
		LABEL(mercury__prog_util__rename_in_goal_expr_4_0_i41));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i13);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i14,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i14);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i15,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i15);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i16);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i17,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i17);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i18,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i18);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i19);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i20,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i20);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i21,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i21);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i22);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i23,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i23);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i24,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i24);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i25);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i26,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i26);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i27,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i27);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i28);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i29,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i29);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i30);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i31,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i31);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i32,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i32);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i33,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i33);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i34);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__prog_util__rename_in_vars_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i35,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i35);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i36,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i36);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i37,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
	}
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i37);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__prog_util__rename_in_goal_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i38,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i38);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 4) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i39);
	r6 = r3;
	r3 = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_util__rename_in_goal_expr_4_0, "term:term/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r6;
	call_localret(ENTRY(mercury__term__substitute_list_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i40,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i40);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i41);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__prog_util__rename_in_goal_expr_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r3;
	r3 = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = r4;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__term__substitute_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i42,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i42);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__substitute_4_0),
		mercury__prog_util__rename_in_goal_expr_4_0_i43,
		STATIC(mercury__prog_util__rename_in_goal_expr_4_0));
Define_label(mercury__prog_util__rename_in_goal_expr_4_0_i43);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_goal_expr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__prog_util__rename_in_goal_expr_4_0, "prog_data:goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__var_1_0);

BEGIN_MODULE(prog_util_module19)
	init_entry(mercury__prog_util__rename_in_vars_4_0);
	init_label(mercury__prog_util__rename_in_vars_4_0_i5);
	init_label(mercury__prog_util__rename_in_vars_4_0_i4);
	init_label(mercury__prog_util__rename_in_vars_4_0_i8);
	init_label(mercury__prog_util__rename_in_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'rename_in_vars'/4 in mode 0 */
Define_static(mercury__prog_util__rename_in_vars_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__prog_util__rename_in_vars_4_0_i3);
	MR_incr_sp_push_msg(6, "prog_util:rename_in_vars/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__prog_util__rename_in_vars_4_0_i5,
		STATIC(mercury__prog_util__rename_in_vars_4_0));
Define_label(mercury__prog_util__rename_in_vars_4_0_i5);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__prog_util__rename_in_vars_4_0_i4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(4);
	MR_stackvar(5) = r3;
	localcall(mercury__prog_util__rename_in_vars_4_0,
		LABEL(mercury__prog_util__rename_in_vars_4_0_i8),
		STATIC(mercury__prog_util__rename_in_vars_4_0));
Define_label(mercury__prog_util__rename_in_vars_4_0_i4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = MR_stackvar(4);
	MR_stackvar(5) = MR_stackvar(3);
	localcall(mercury__prog_util__rename_in_vars_4_0,
		LABEL(mercury__prog_util__rename_in_vars_4_0_i8),
		STATIC(mercury__prog_util__rename_in_vars_4_0));
Define_label(mercury__prog_util__rename_in_vars_4_0_i8);
	update_prof_current_proc(LABEL(mercury__prog_util__rename_in_vars_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__prog_util__rename_in_vars_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__prog_util__rename_in_vars_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(prog_util_module20)
	init_entry(mercury____Unify___prog_util__new_pred_id_0_0);
	init_label(mercury____Unify___prog_util__new_pred_id_0_0_i3);
	init_label(mercury____Unify___prog_util__new_pred_id_0_0_i6);
	init_label(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
	init_label(mercury____Unify___prog_util__new_pred_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_util__new_pred_id_0_0);
	MR_incr_sp_push_msg(3, "prog_util:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___prog_util__new_pred_id_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___prog_util__new_pred_id_0_0_i6,
		ENTRY(mercury____Unify___prog_util__new_pred_id_0_0));
Define_label(mercury____Unify___prog_util__new_pred_id_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___prog_util__new_pred_id_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___prog_util__new_pred_id_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___prog_util__new_pred_id_0_0));
Define_label(mercury____Unify___prog_util__new_pred_id_0_0_i1010);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___prog_util__new_pred_id_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(prog_util_module21)
	init_entry(mercury____Index___prog_util__new_pred_id_0_0);
	init_label(mercury____Index___prog_util__new_pred_id_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_util__new_pred_id_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___prog_util__new_pred_id_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___prog_util__new_pred_id_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(prog_util_module22)
	init_entry(mercury____Compare___prog_util__new_pred_id_0_0);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i3);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i2);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i5);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i4);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i6);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i7);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i14);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i11);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i21);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i1016);
	init_label(mercury____Compare___prog_util__new_pred_id_0_0_i29);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_util__new_pred_id_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i2);
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i4);
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i1016);
	MR_incr_sp_push_msg(3, "prog_util:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___prog_util__new_pred_id_0_0_i14,
		ENTRY(mercury____Compare___prog_util__new_pred_id_0_0));
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___prog_util__new_pred_id_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i29);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___prog_util__new_pred_id_0_0));
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i1016);
	MR_incr_sp_push_msg(3, "prog_util:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___prog_util__new_pred_id_0_0_i21,
		ENTRY(mercury____Compare___prog_util__new_pred_id_0_0));
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___prog_util__new_pred_id_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___prog_util__new_pred_id_0_0_i29);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_7);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___prog_util__new_pred_id_0_0));
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i1016);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___prog_util__new_pred_id_0_0));
Define_label(mercury____Compare___prog_util__new_pred_id_0_0_i29);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__maybe_1_0);

BEGIN_MODULE(prog_util_module23)
	init_entry(mercury____Unify___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___prog_util__maybe_modes_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_8);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___prog_util__maybe_modes_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__maybe_1_0);

BEGIN_MODULE(prog_util_module24)
	init_entry(mercury____Index___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___prog_util__maybe_modes_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_8);
	tailcall(ENTRY(mercury____Index___std_util__maybe_1_0),
		ENTRY(mercury____Index___prog_util__maybe_modes_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__maybe_1_0);

BEGIN_MODULE(prog_util_module25)
	init_entry(mercury____Compare___prog_util__maybe_modes_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___prog_util__maybe_modes_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_prog_util__common_8);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___prog_util__maybe_modes_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__prog_util_maybe_bunch_0(void)
{
	prog_util_module0();
	prog_util_module1();
	prog_util_module2();
	prog_util_module3();
	prog_util_module4();
	prog_util_module5();
	prog_util_module6();
	prog_util_module7();
	prog_util_module8();
	prog_util_module9();
	prog_util_module10();
	prog_util_module11();
	prog_util_module12();
	prog_util_module13();
	prog_util_module14();
	prog_util_module15();
	prog_util_module16();
	prog_util_module17();
	prog_util_module18();
	prog_util_module19();
	prog_util_module20();
	prog_util_module21();
	prog_util_module22();
	prog_util_module23();
	prog_util_module24();
	prog_util_module25();
}

#endif

void mercury__prog_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__prog_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__prog_util_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_util__type_ctor_info_maybe_modes_0,
			prog_util__maybe_modes_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_prog_util__type_ctor_info_new_pred_id_0,
			prog_util__new_pred_id_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
