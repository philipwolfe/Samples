/*
** Automatically generated from `purity.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__purity__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i2);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i3);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i4);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i5);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i6);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i7);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i9);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i10);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i12);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i13);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i14);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i17);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i19);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i20);
Declare_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21);
Declare_static(mercury__purity__error_missing_body_impurity_decl__ua0_7_0);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i2);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i3);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i5);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i6);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i8);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i9);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i10);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i11);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i12);
Declare_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i13);
Define_extern_entry(mercury__purity__puritycheck_6_0);
Declare_label(mercury__purity__puritycheck_6_0_i2);
Declare_label(mercury__purity__puritycheck_6_0_i3);
Declare_label(mercury__purity__puritycheck_6_0_i4);
Declare_label(mercury__purity__puritycheck_6_0_i5);
Declare_label(mercury__purity__puritycheck_6_0_i6);
Declare_label(mercury__purity__puritycheck_6_0_i7);
Declare_label(mercury__purity__puritycheck_6_0_i8);
Declare_label(mercury__purity__puritycheck_6_0_i9);
Declare_label(mercury__purity__puritycheck_6_0_i10);
Declare_label(mercury__purity__puritycheck_6_0_i11);
Declare_label(mercury__purity__puritycheck_6_0_i12);
Define_extern_entry(mercury__purity__worst_purity_3_0);
Declare_label(mercury__purity__worst_purity_3_0_i5);
Declare_label(mercury__purity__worst_purity_3_0_i3);
Declare_label(mercury__purity__worst_purity_3_0_i9);
Declare_label(mercury__purity__worst_purity_3_0_i1014);
Define_extern_entry(mercury__purity__less_pure_2_0);
Declare_label(mercury__purity__less_pure_2_0_i3);
Declare_label(mercury__purity__less_pure_2_0_i1);
Define_extern_entry(mercury__purity__write_purity_3_0);
Declare_label(mercury__purity__write_purity_3_0_i3);
Declare_label(mercury__purity__write_purity_3_0_i4);
Define_extern_entry(mercury__purity__write_purity_prefix_3_0);
Declare_label(mercury__purity__write_purity_prefix_3_0_i2);
Declare_label(mercury__purity__write_purity_prefix_3_0_i5);
Declare_label(mercury__purity__write_purity_prefix_3_0_i6);
Declare_label(mercury__purity__write_purity_prefix_3_0_i7);
Define_extern_entry(mercury__purity__purity_name_2_0);
Declare_label(mercury__purity__purity_name_2_0_i3);
Declare_label(mercury__purity__purity_name_2_0_i4);
Define_extern_entry(mercury__purity__add_goal_info_purity_feature_3_0);
Declare_label(mercury__purity__add_goal_info_purity_feature_3_0_i4);
Declare_label(mercury__purity__add_goal_info_purity_feature_3_0_i3);
Declare_label(mercury__purity__add_goal_info_purity_feature_3_0_i6);
Define_extern_entry(mercury__purity__infer_goal_info_purity_2_0);
Declare_label(mercury__purity__infer_goal_info_purity_2_0_i3);
Declare_label(mercury__purity__infer_goal_info_purity_2_0_i2);
Declare_label(mercury__purity__infer_goal_info_purity_2_0_i6);
Declare_label(mercury__purity__infer_goal_info_purity_2_0_i5);
Define_extern_entry(mercury__purity__goal_info_is_pure_1_0);
Declare_label(mercury__purity__goal_info_is_pure_1_0_i3);
Declare_label(mercury__purity__goal_info_is_pure_1_0_i6);
Declare_label(mercury__purity__goal_info_is_pure_1_0_i1);
Define_extern_entry(mercury__purity__goal_info_is_impure_1_0);
Declare_static(mercury__purity__check_preds_purity_2_10_0);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i1005);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i4);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i5);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i11);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i9);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i13);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i8);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i15);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i6);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i16);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i17);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i18);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i20);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i23);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i24);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i25);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i26);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i27);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i28);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i29);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i30);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i32);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i33);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i31);
Declare_label(mercury__purity__check_preds_purity_2_10_0_i3);
Declare_static(mercury__purity__puritycheck_pred_7_0);
Declare_label(mercury__purity__puritycheck_pred_7_0_i2);
Declare_label(mercury__purity__puritycheck_pred_7_0_i3);
Declare_label(mercury__purity__puritycheck_pred_7_0_i5);
Declare_label(mercury__purity__puritycheck_pred_7_0_i4);
Declare_label(mercury__purity__puritycheck_pred_7_0_i6);
Declare_label(mercury__purity__puritycheck_pred_7_0_i7);
Declare_label(mercury__purity__puritycheck_pred_7_0_i8);
Declare_label(mercury__purity__puritycheck_pred_7_0_i9);
Declare_label(mercury__purity__puritycheck_pred_7_0_i10);
Declare_label(mercury__purity__puritycheck_pred_7_0_i11);
Declare_label(mercury__purity__puritycheck_pred_7_0_i17);
Declare_label(mercury__purity__puritycheck_pred_7_0_i18);
Declare_label(mercury__purity__puritycheck_pred_7_0_i19);
Declare_label(mercury__purity__puritycheck_pred_7_0_i20);
Declare_label(mercury__purity__puritycheck_pred_7_0_i21);
Declare_label(mercury__purity__puritycheck_pred_7_0_i22);
Declare_label(mercury__purity__puritycheck_pred_7_0_i23);
Declare_label(mercury__purity__puritycheck_pred_7_0_i24);
Declare_label(mercury__purity__puritycheck_pred_7_0_i26);
Declare_label(mercury__purity__puritycheck_pred_7_0_i27);
Declare_label(mercury__purity__puritycheck_pred_7_0_i28);
Declare_label(mercury__purity__puritycheck_pred_7_0_i29);
Declare_label(mercury__purity__puritycheck_pred_7_0_i30);
Declare_label(mercury__purity__puritycheck_pred_7_0_i33);
Declare_label(mercury__purity__puritycheck_pred_7_0_i34);
Declare_label(mercury__purity__puritycheck_pred_7_0_i35);
Declare_label(mercury__purity__puritycheck_pred_7_0_i36);
Declare_label(mercury__purity__puritycheck_pred_7_0_i37);
Declare_label(mercury__purity__puritycheck_pred_7_0_i38);
Declare_label(mercury__purity__puritycheck_pred_7_0_i31);
Declare_label(mercury__purity__puritycheck_pred_7_0_i13);
Declare_label(mercury__purity__puritycheck_pred_7_0_i44);
Declare_label(mercury__purity__puritycheck_pred_7_0_i41);
Declare_label(mercury__purity__puritycheck_pred_7_0_i49);
Declare_label(mercury__purity__puritycheck_pred_7_0_i46);
Declare_label(mercury__purity__puritycheck_pred_7_0_i55);
Declare_label(mercury__purity__puritycheck_pred_7_0_i52);
Declare_static(mercury__purity__compute_purity_10_0);
Declare_label(mercury__purity__compute_purity_10_0_i4);
Declare_label(mercury__purity__compute_purity_10_0_i5);
Declare_label(mercury__purity__compute_purity_10_0_i6);
Declare_label(mercury__purity__compute_purity_10_0_i7);
Declare_label(mercury__purity__compute_purity_10_0_i3);
Declare_static(mercury__purity__compute_expr_purity_11_0);
Declare_label(mercury__purity__compute_expr_purity_11_0_i4);
Declare_label(mercury__purity__compute_expr_purity_11_0_i5);
Declare_label(mercury__purity__compute_expr_purity_11_0_i6);
Declare_label(mercury__purity__compute_expr_purity_11_0_i7);
Declare_label(mercury__purity__compute_expr_purity_11_0_i8);
Declare_label(mercury__purity__compute_expr_purity_11_0_i9);
Declare_label(mercury__purity__compute_expr_purity_11_0_i10);
Declare_label(mercury__purity__compute_expr_purity_11_0_i11);
Declare_label(mercury__purity__compute_expr_purity_11_0_i12);
Declare_label(mercury__purity__compute_expr_purity_11_0_i15);
Declare_label(mercury__purity__compute_expr_purity_11_0_i13);
Declare_label(mercury__purity__compute_expr_purity_11_0_i17);
Declare_label(mercury__purity__compute_expr_purity_11_0_i18);
Declare_label(mercury__purity__compute_expr_purity_11_0_i22);
Declare_label(mercury__purity__compute_expr_purity_11_0_i24);
Declare_label(mercury__purity__compute_expr_purity_11_0_i20);
Declare_label(mercury__purity__compute_expr_purity_11_0_i25);
Declare_label(mercury__purity__compute_expr_purity_11_0_i30);
Declare_label(mercury__purity__compute_expr_purity_11_0_i1005);
Declare_label(mercury__purity__compute_expr_purity_11_0_i34);
Declare_label(mercury__purity__compute_expr_purity_11_0_i35);
Declare_label(mercury__purity__compute_expr_purity_11_0_i36);
Declare_label(mercury__purity__compute_expr_purity_11_0_i37);
Declare_label(mercury__purity__compute_expr_purity_11_0_i38);
Declare_label(mercury__purity__compute_expr_purity_11_0_i39);
Declare_label(mercury__purity__compute_expr_purity_11_0_i40);
Declare_label(mercury__purity__compute_expr_purity_11_0_i43);
Declare_label(mercury__purity__compute_expr_purity_11_0_i44);
Declare_label(mercury__purity__compute_expr_purity_11_0_i49);
Declare_label(mercury__purity__compute_expr_purity_11_0_i48);
Declare_label(mercury__purity__compute_expr_purity_11_0_i50);
Declare_label(mercury__purity__compute_expr_purity_11_0_i52);
Declare_label(mercury__purity__compute_expr_purity_11_0_i53);
Declare_label(mercury__purity__compute_expr_purity_11_0_i54);
Declare_label(mercury__purity__compute_expr_purity_11_0_i55);
Declare_label(mercury__purity__compute_expr_purity_11_0_i56);
Declare_label(mercury__purity__compute_expr_purity_11_0_i46);
Declare_label(mercury__purity__compute_expr_purity_11_0_i57);
Declare_label(mercury__purity__compute_expr_purity_11_0_i58);
Declare_label(mercury__purity__compute_expr_purity_11_0_i59);
Declare_label(mercury__purity__compute_expr_purity_11_0_i60);
Declare_label(mercury__purity__compute_expr_purity_11_0_i61);
Declare_label(mercury__purity__compute_expr_purity_11_0_i64);
Declare_label(mercury__purity__compute_expr_purity_11_0_i62);
Declare_label(mercury__purity__compute_expr_purity_11_0_i65);
Declare_label(mercury__purity__compute_expr_purity_11_0_i67);
Declare_label(mercury__purity__compute_expr_purity_11_0_i68);
Declare_label(mercury__purity__compute_expr_purity_11_0_i69);
Declare_label(mercury__purity__compute_expr_purity_11_0_i70);
Declare_label(mercury__purity__compute_expr_purity_11_0_i71);
Declare_label(mercury__purity__compute_expr_purity_11_0_i72);
Declare_label(mercury__purity__compute_expr_purity_11_0_i73);
Declare_label(mercury__purity__compute_expr_purity_11_0_i75);
Declare_label(mercury__purity__compute_expr_purity_11_0_i76);
Declare_label(mercury__purity__compute_expr_purity_11_0_i77);
Declare_label(mercury__purity__compute_expr_purity_11_0_i78);
Declare_label(mercury__purity__compute_expr_purity_11_0_i79);
Declare_label(mercury__purity__compute_expr_purity_11_0_i80);
Declare_label(mercury__purity__compute_expr_purity_11_0_i81);
Declare_label(mercury__purity__compute_expr_purity_11_0_i82);
Declare_static(mercury__purity__compute_goal_purity_10_0);
Declare_label(mercury__purity__compute_goal_purity_10_0_i2);
Declare_label(mercury__purity__compute_goal_purity_10_0_i3);
Declare_static(mercury__purity__compute_goals_purity_11_0);
Declare_label(mercury__purity__compute_goals_purity_11_0_i4);
Declare_label(mercury__purity__compute_goals_purity_11_0_i5);
Declare_label(mercury__purity__compute_goals_purity_11_0_i6);
Declare_label(mercury__purity__compute_goals_purity_11_0_i7);
Declare_label(mercury__purity__compute_goals_purity_11_0_i3);
Declare_static(mercury__purity__compute_cases_purity_11_0);
Declare_label(mercury__purity__compute_cases_purity_11_0_i4);
Declare_label(mercury__purity__compute_cases_purity_11_0_i5);
Declare_label(mercury__purity__compute_cases_purity_11_0_i6);
Declare_label(mercury__purity__compute_cases_purity_11_0_i7);
Declare_label(mercury__purity__compute_cases_purity_11_0_i3);
Declare_static(mercury__purity__fix_aditi_state_modes_4_0);
Declare_label(mercury__purity__fix_aditi_state_modes_4_0_i3);
Declare_label(mercury__purity__fix_aditi_state_modes_4_0_i11);
Declare_label(mercury__purity__fix_aditi_state_modes_4_0_i9);
Declare_label(mercury__purity__fix_aditi_state_modes_4_0_i14);
Declare_label(mercury__purity__fix_aditi_state_modes_4_0_i8);
Declare_static(mercury__purity__warn_exaggerated_impurity_decl_7_0);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i2);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i3);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i4);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i5);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i6);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i7);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i8);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i9);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i11);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i12);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i13);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i14);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i16);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i17);
Declare_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i18);
Declare_static(mercury__purity__warn_unnecessary_promise_pure_5_0);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i2);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i3);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i4);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i5);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i6);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i7);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i8);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i9);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i10);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i13);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i14);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i15);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i16);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i17);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i18);
Declare_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i11);
Declare_static(mercury__purity__error_inferred_impure_6_0);
Declare_label(mercury__purity__error_inferred_impure_6_0_i2);
Declare_label(mercury__purity__error_inferred_impure_6_0_i3);
Declare_label(mercury__purity__error_inferred_impure_6_0_i4);
Declare_label(mercury__purity__error_inferred_impure_6_0_i5);
Declare_label(mercury__purity__error_inferred_impure_6_0_i6);
Declare_label(mercury__purity__error_inferred_impure_6_0_i7);
Declare_label(mercury__purity__error_inferred_impure_6_0_i8);
Declare_label(mercury__purity__error_inferred_impure_6_0_i9);
Declare_label(mercury__purity__error_inferred_impure_6_0_i10);
Declare_label(mercury__purity__error_inferred_impure_6_0_i11);
Declare_label(mercury__purity__error_inferred_impure_6_0_i12);
Declare_label(mercury__purity__error_inferred_impure_6_0_i14);
Declare_label(mercury__purity__error_inferred_impure_6_0_i15);
Declare_label(mercury__purity__error_inferred_impure_6_0_i16);
Declare_label(mercury__purity__error_inferred_impure_6_0_i17);
Declare_label(mercury__purity__error_inferred_impure_6_0_i18);
Declare_label(mercury__purity__error_inferred_impure_6_0_i21);
Declare_label(mercury__purity__error_inferred_impure_6_0_i19);
Declare_label(mercury__purity__error_inferred_impure_6_0_i24);
Declare_label(mercury__purity__error_inferred_impure_6_0_i26);
Declare_label(mercury__purity__error_inferred_impure_6_0_i27);
Declare_label(mercury__purity__error_inferred_impure_6_0_i28);
Declare_static(mercury__purity__error_if_closure_impure_6_0);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i2);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i4);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i5);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i6);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i8);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i9);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i10);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i11);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i12);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i15);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i16);
Declare_label(mercury__purity__error_if_closure_impure_6_0_i13);

static const struct mercury_data_purity__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_purity__common_0;

static const struct mercury_data_purity__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_purity__common_1;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_purity__common_0_struct mercury_data_purity__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_purity__common_1_struct mercury_data_purity__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

Declare_entry(mercury__prog_out__write_context_3_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_id_4_0);

BEGIN_MODULE(purity_module0)
	init_entry(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i2);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i3);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i4);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i5);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i6);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i7);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i9);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i10);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i12);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i13);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i14);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i17);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i19);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i20);
	init_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21);
BEGIN_CODE

/* code for predicate 'warn_unnecessary_body_impurity_decl__ua0'/8 in mode 0 */
Define_static(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0);
	MR_incr_sp_push_msg(6, "purity:warn_unnecessary_body_impurity_decl__ua0/8");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r3;
	r2 = r6;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i2,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In call to ", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i3,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i4,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i5,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i6,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  warning: unnecessary `", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i7,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i9);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i9);
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' indicator.\n", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i12,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i13,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i13);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i14);
	r2 = r1;
	r1 = (Word) MR_string_const("  No purity indicator is necessary.\n", 36);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i14);
	r2 = r1;
	r1 = (Word) MR_string_const("  A purity indicator of `", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i17,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i17);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i19);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i19);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i20);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i20);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21,
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
Define_label(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0_i21);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' is sufficient.\n", 17);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0));
END_MODULE


BEGIN_MODULE(purity_module1)
	init_entry(mercury__purity__error_missing_body_impurity_decl__ua0_7_0);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i2);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i3);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i5);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i6);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i8);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i9);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i10);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i11);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i12);
	init_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i13);
BEGIN_CODE

/* code for predicate 'error_missing_body_impurity_decl__ua0'/7 in mode 0 */
Define_static(mercury__purity__error_missing_body_impurity_decl__ua0_7_0);
	MR_incr_sp_push_msg(5, "purity:error_missing_body_impurity_decl__ua0/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r3;
	r2 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i2,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In call to ", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i3,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i5);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	MR_stackvar(4) = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i5);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i6);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	MR_stackvar(4) = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i6);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	MR_stackvar(4) = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i8,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i9,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i10,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i11,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  error: call must be preceded by `", 35);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i12,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i13,
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
Define_label(mercury__purity__error_missing_body_impurity_decl__ua0_7_0_i13);
	update_prof_current_proc(LABEL(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' indicator.\n", 13);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__stderr_stream_3_0);
Declare_entry(mercury__io__set_output_stream_4_0);
Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__hlds_module__module_info_num_errors_2_0);
Declare_entry(mercury__hlds_module__module_info_set_num_errors_3_0);
Declare_entry(mercury__passes_aux__maybe_report_stats_3_0);

BEGIN_MODULE(purity_module2)
	init_entry(mercury__purity__puritycheck_6_0);
	init_label(mercury__purity__puritycheck_6_0_i2);
	init_label(mercury__purity__puritycheck_6_0_i3);
	init_label(mercury__purity__puritycheck_6_0_i4);
	init_label(mercury__purity__puritycheck_6_0_i5);
	init_label(mercury__purity__puritycheck_6_0_i6);
	init_label(mercury__purity__puritycheck_6_0_i7);
	init_label(mercury__purity__puritycheck_6_0_i8);
	init_label(mercury__purity__puritycheck_6_0_i9);
	init_label(mercury__purity__puritycheck_6_0_i10);
	init_label(mercury__purity__puritycheck_6_0_i11);
	init_label(mercury__purity__puritycheck_6_0_i12);
BEGIN_CODE

/* code for predicate 'puritycheck'/6 in mode 0 */
Define_entry(mercury__purity__puritycheck_6_0);
	MR_incr_sp_push_msg(7, "purity:puritycheck/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 20;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__purity__puritycheck_6_0_i2,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	MR_stackvar(3) = r1;
	r1 = (Integer) 17;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__purity__puritycheck_6_0_i3,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__io__stderr_stream_3_0),
		mercury__purity__puritycheck_6_0_i4,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__purity__puritycheck_6_0_i5,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	r3 = r2;
	r2 = (Word) MR_string_const("% Purity-checking clauses...\n", 29);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__purity__puritycheck_6_0_i6,
		ENTRY(mercury__purity__puritycheck_6_0));
	}
Define_label(mercury__purity__puritycheck_6_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__purity__puritycheck_6_0_i7,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = MR_stackvar(5);
	call_localret(STATIC(mercury__purity__check_preds_purity_2_10_0),
		mercury__purity__puritycheck_6_0_i8,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(5) = r1;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_num_errors_2_0),
		mercury__purity__puritycheck_6_0_i9,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	r2 = ((Integer) r1 + (Integer) MR_stackvar(6));
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_num_errors_3_0),
		mercury__purity__puritycheck_6_0_i10,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_report_stats_3_0),
		mercury__purity__puritycheck_6_0_i11,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__purity__puritycheck_6_0_i12,
		ENTRY(mercury__purity__puritycheck_6_0));
Define_label(mercury__purity__puritycheck_6_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_6_0));
	r3 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(purity_module3)
	init_entry(mercury__purity__worst_purity_3_0);
	init_label(mercury__purity__worst_purity_3_0_i5);
	init_label(mercury__purity__worst_purity_3_0_i3);
	init_label(mercury__purity__worst_purity_3_0_i9);
	init_label(mercury__purity__worst_purity_3_0_i1014);
BEGIN_CODE

/* code for predicate 'worst_purity'/3 in mode 0 */
Define_entry(mercury__purity__worst_purity_3_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i3);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury__purity__worst_purity_3_0_i5);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i1014);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury__purity__worst_purity_3_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i1014);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i9);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury__purity__worst_purity_3_0_i9);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__purity__worst_purity_3_0_i1014);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury__purity__worst_purity_3_0_i1014);
	r1 = (Integer) 2;
	proceed();
END_MODULE


BEGIN_MODULE(purity_module4)
	init_entry(mercury__purity__less_pure_2_0);
	init_label(mercury__purity__less_pure_2_0_i3);
	init_label(mercury__purity__less_pure_2_0_i1);
BEGIN_CODE

/* code for predicate 'less_pure'/2 in mode 0 */
Define_entry(mercury__purity__less_pure_2_0);
	MR_incr_sp_push_msg(2, "purity:less_pure/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__less_pure_2_0_i3,
		ENTRY(mercury__purity__less_pure_2_0));
Define_label(mercury__purity__less_pure_2_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__less_pure_2_0));
	if ((MR_stackvar(1) == r1))
		GOTO_LABEL(mercury__purity__less_pure_2_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__purity__less_pure_2_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(purity_module5)
	init_entry(mercury__purity__write_purity_3_0);
	init_label(mercury__purity__write_purity_3_0_i3);
	init_label(mercury__purity__write_purity_3_0_i4);
BEGIN_CODE

/* code for predicate 'write_purity'/3 in mode 0 */
Define_entry(mercury__purity__write_purity_3_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__purity__write_purity_3_0_i3);
	r1 = (Word) MR_string_const("pure", 4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__purity__write_purity_3_0));
Define_label(mercury__purity__write_purity_3_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__write_purity_3_0_i4);
	r1 = (Word) MR_string_const("semipure", 8);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__purity__write_purity_3_0));
Define_label(mercury__purity__write_purity_3_0_i4);
	r1 = (Word) MR_string_const("impure", 6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__purity__write_purity_3_0));
END_MODULE


BEGIN_MODULE(purity_module6)
	init_entry(mercury__purity__write_purity_prefix_3_0);
	init_label(mercury__purity__write_purity_prefix_3_0_i2);
	init_label(mercury__purity__write_purity_prefix_3_0_i5);
	init_label(mercury__purity__write_purity_prefix_3_0_i6);
	init_label(mercury__purity__write_purity_prefix_3_0_i7);
BEGIN_CODE

/* code for predicate 'write_purity_prefix'/3 in mode 0 */
Define_entry(mercury__purity__write_purity_prefix_3_0);
	MR_incr_sp_push_msg(1, "purity:write_purity_prefix/3");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__purity__write_purity_prefix_3_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__purity__write_purity_prefix_3_0_i2);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__purity__write_purity_prefix_3_0_i5);
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__write_purity_prefix_3_0_i7,
		ENTRY(mercury__purity__write_purity_prefix_3_0));
Define_label(mercury__purity__write_purity_prefix_3_0_i5);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__write_purity_prefix_3_0_i6);
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__write_purity_prefix_3_0_i7,
		ENTRY(mercury__purity__write_purity_prefix_3_0));
Define_label(mercury__purity__write_purity_prefix_3_0_i6);
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__write_purity_prefix_3_0_i7,
		ENTRY(mercury__purity__write_purity_prefix_3_0));
Define_label(mercury__purity__write_purity_prefix_3_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__write_purity_prefix_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ", 1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__purity__write_purity_prefix_3_0));
END_MODULE


BEGIN_MODULE(purity_module7)
	init_entry(mercury__purity__purity_name_2_0);
	init_label(mercury__purity__purity_name_2_0_i3);
	init_label(mercury__purity__purity_name_2_0_i4);
BEGIN_CODE

/* code for predicate 'purity_name'/2 in mode 0 */
Define_entry(mercury__purity__purity_name_2_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__purity__purity_name_2_0_i3);
	r1 = (Word) MR_string_const("pure", 4);
	proceed();
Define_label(mercury__purity__purity_name_2_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__purity_name_2_0_i4);
	r1 = (Word) MR_string_const("semipure", 8);
	proceed();
Define_label(mercury__purity__purity_name_2_0_i4);
	r1 = (Word) MR_string_const("impure", 6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_remove_feature_3_0);
Declare_entry(mercury__hlds_goal__goal_info_add_feature_3_0);

BEGIN_MODULE(purity_module8)
	init_entry(mercury__purity__add_goal_info_purity_feature_3_0);
	init_label(mercury__purity__add_goal_info_purity_feature_3_0_i4);
	init_label(mercury__purity__add_goal_info_purity_feature_3_0_i3);
	init_label(mercury__purity__add_goal_info_purity_feature_3_0_i6);
BEGIN_CODE

/* code for predicate 'add_goal_info_purity_feature'/3 in mode 0 */
Define_entry(mercury__purity__add_goal_info_purity_feature_3_0);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__purity__add_goal_info_purity_feature_3_0_i3);
	MR_incr_sp_push_msg(1, "purity:add_goal_info_purity_feature/3");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = (Integer) 2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_remove_feature_3_0),
		mercury__purity__add_goal_info_purity_feature_3_0_i4,
		ENTRY(mercury__purity__add_goal_info_purity_feature_3_0));
Define_label(mercury__purity__add_goal_info_purity_feature_3_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__add_goal_info_purity_feature_3_0));
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__hlds_goal__goal_info_remove_feature_3_0),
		ENTRY(mercury__purity__add_goal_info_purity_feature_3_0));
Define_label(mercury__purity__add_goal_info_purity_feature_3_0_i3);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__purity__add_goal_info_purity_feature_3_0_i6);
	r2 = (Integer) 2;
	tailcall(ENTRY(mercury__hlds_goal__goal_info_add_feature_3_0),
		ENTRY(mercury__purity__add_goal_info_purity_feature_3_0));
Define_label(mercury__purity__add_goal_info_purity_feature_3_0_i6);
	r2 = (Integer) 1;
	tailcall(ENTRY(mercury__hlds_goal__goal_info_add_feature_3_0),
		ENTRY(mercury__purity__add_goal_info_purity_feature_3_0));
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_has_feature_2_0);

BEGIN_MODULE(purity_module9)
	init_entry(mercury__purity__infer_goal_info_purity_2_0);
	init_label(mercury__purity__infer_goal_info_purity_2_0_i3);
	init_label(mercury__purity__infer_goal_info_purity_2_0_i2);
	init_label(mercury__purity__infer_goal_info_purity_2_0_i6);
	init_label(mercury__purity__infer_goal_info_purity_2_0_i5);
BEGIN_CODE

/* code for predicate 'infer_goal_info_purity'/2 in mode 0 */
Define_entry(mercury__purity__infer_goal_info_purity_2_0);
	MR_incr_sp_push_msg(2, "purity:infer_goal_info_purity/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0),
		mercury__purity__infer_goal_info_purity_2_0_i3,
		ENTRY(mercury__purity__infer_goal_info_purity_2_0));
Define_label(mercury__purity__infer_goal_info_purity_2_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__infer_goal_info_purity_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__infer_goal_info_purity_2_0_i2);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__purity__infer_goal_info_purity_2_0_i2);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0),
		mercury__purity__infer_goal_info_purity_2_0_i6,
		ENTRY(mercury__purity__infer_goal_info_purity_2_0));
Define_label(mercury__purity__infer_goal_info_purity_2_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__infer_goal_info_purity_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__infer_goal_info_purity_2_0_i5);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__purity__infer_goal_info_purity_2_0_i5);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(purity_module10)
	init_entry(mercury__purity__goal_info_is_pure_1_0);
	init_label(mercury__purity__goal_info_is_pure_1_0_i3);
	init_label(mercury__purity__goal_info_is_pure_1_0_i6);
	init_label(mercury__purity__goal_info_is_pure_1_0_i1);
BEGIN_CODE

/* code for predicate 'goal_info_is_pure'/1 in mode 0 */
Define_entry(mercury__purity__goal_info_is_pure_1_0);
	MR_incr_sp_push_msg(2, "purity:goal_info_is_pure/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0),
		mercury__purity__goal_info_is_pure_1_0_i3,
		ENTRY(mercury__purity__goal_info_is_pure_1_0));
Define_label(mercury__purity__goal_info_is_pure_1_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__goal_info_is_pure_1_0));
	if (r1)
		GOTO_LABEL(mercury__purity__goal_info_is_pure_1_0_i1);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0),
		mercury__purity__goal_info_is_pure_1_0_i6,
		ENTRY(mercury__purity__goal_info_is_pure_1_0));
Define_label(mercury__purity__goal_info_is_pure_1_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__goal_info_is_pure_1_0));
	if (r1)
		GOTO_LABEL(mercury__purity__goal_info_is_pure_1_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__purity__goal_info_is_pure_1_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(purity_module11)
	init_entry(mercury__purity__goal_info_is_impure_1_0);
BEGIN_CODE

/* code for predicate 'goal_info_is_impure'/1 in mode 0 */
Define_entry(mercury__purity__goal_info_is_impure_1_0);
	r2 = (Integer) 1;
	tailcall(ENTRY(mercury__hlds_goal__goal_info_has_feature_2_0),
		ENTRY(mercury__purity__goal_info_is_impure_1_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_is_imported_1_0);
Declare_entry(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0);
Declare_entry(mercury__post_typecheck__finish_imported_pred_6_0);
Declare_entry(mercury__passes_aux__write_pred_progress_message_5_0);
Declare_entry(mercury__bool__not_2_0);
Declare_entry(mercury__post_typecheck__check_type_bindings_8_0);
Declare_entry(mercury__post_typecheck__finish_pred_6_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__hlds_module__predicate_table_set_preds_3_0);
Declare_entry(mercury__hlds_module__module_info_set_predicate_table_3_0);
Declare_entry(mercury__hlds_pred__pred_info_get_goal_type_2_0);
Declare_entry(mercury__post_typecheck__finish_assertion_5_0);

BEGIN_MODULE(purity_module12)
	init_entry(mercury__purity__check_preds_purity_2_10_0);
	init_label(mercury__purity__check_preds_purity_2_10_0_i1005);
	init_label(mercury__purity__check_preds_purity_2_10_0_i4);
	init_label(mercury__purity__check_preds_purity_2_10_0_i5);
	init_label(mercury__purity__check_preds_purity_2_10_0_i11);
	init_label(mercury__purity__check_preds_purity_2_10_0_i9);
	init_label(mercury__purity__check_preds_purity_2_10_0_i13);
	init_label(mercury__purity__check_preds_purity_2_10_0_i8);
	init_label(mercury__purity__check_preds_purity_2_10_0_i15);
	init_label(mercury__purity__check_preds_purity_2_10_0_i6);
	init_label(mercury__purity__check_preds_purity_2_10_0_i16);
	init_label(mercury__purity__check_preds_purity_2_10_0_i17);
	init_label(mercury__purity__check_preds_purity_2_10_0_i18);
	init_label(mercury__purity__check_preds_purity_2_10_0_i20);
	init_label(mercury__purity__check_preds_purity_2_10_0_i23);
	init_label(mercury__purity__check_preds_purity_2_10_0_i24);
	init_label(mercury__purity__check_preds_purity_2_10_0_i25);
	init_label(mercury__purity__check_preds_purity_2_10_0_i26);
	init_label(mercury__purity__check_preds_purity_2_10_0_i27);
	init_label(mercury__purity__check_preds_purity_2_10_0_i28);
	init_label(mercury__purity__check_preds_purity_2_10_0_i29);
	init_label(mercury__purity__check_preds_purity_2_10_0_i30);
	init_label(mercury__purity__check_preds_purity_2_10_0_i32);
	init_label(mercury__purity__check_preds_purity_2_10_0_i33);
	init_label(mercury__purity__check_preds_purity_2_10_0_i31);
	init_label(mercury__purity__check_preds_purity_2_10_0_i3);
BEGIN_CODE

/* code for predicate 'check_preds_purity_2'/10 in mode 0 */
Define_static(mercury__purity__check_preds_purity_2_10_0);
	MR_incr_sp_push_msg(17, "purity:check_preds_purity_2/10");
	MR_stackvar(17) = (Word) MR_succip;
Define_label(mercury__purity__check_preds_purity_2_10_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i3);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__purity__check_preds_purity_2_10_0_i4,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__purity__check_preds_purity_2_10_0_i5,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_imported_1_0),
		mercury__purity__check_preds_purity_2_10_0_i11,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i9);
	r1 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(9);
	GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i8);
Define_label(mercury__purity__check_preds_purity_2_10_0_i9);
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_pseudo_imported_1_0),
		mercury__purity__check_preds_purity_2_10_0_i13,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i13);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i6);
	r1 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(9);
Define_label(mercury__purity__check_preds_purity_2_10_0_i8);
	MR_stackvar(2) = r1;
	MR_stackvar(6) = r2;
	MR_stackvar(9) = r3;
	call_localret(ENTRY(mercury__post_typecheck__finish_imported_pred_6_0),
		mercury__purity__check_preds_purity_2_10_0_i15,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i15);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r5 = r1;
	MR_stackvar(16) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(6);
	MR_stackvar(10) = MR_stackvar(3);
	MR_stackvar(11) = MR_stackvar(4);
	GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i26);
Define_label(mercury__purity__check_preds_purity_2_10_0_i6);
	r1 = (Word) MR_string_const("% Purity-checking ", 18);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__passes_aux__write_pred_progress_message_5_0),
		mercury__purity__check_preds_purity_2_10_0_i16,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i16);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__bool__not_2_0),
		mercury__purity__check_preds_purity_2_10_0_i17,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i17);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r4 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__post_typecheck__check_type_bindings_8_0),
		mercury__purity__check_preds_purity_2_10_0_i18,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i18);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i20);
	r4 = r3;
	MR_stackvar(13) = r2;
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	MR_stackvar(11) = (Integer) 1;
	GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i23);
Define_label(mercury__purity__check_preds_purity_2_10_0_i20);
	r4 = r3;
	MR_stackvar(13) = r2;
	r2 = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	MR_stackvar(11) = MR_stackvar(4);
Define_label(mercury__purity__check_preds_purity_2_10_0_i23);
	MR_stackvar(2) = r3;
	MR_stackvar(6) = r1;
	call_localret(STATIC(mercury__purity__puritycheck_pred_7_0),
		mercury__purity__check_preds_purity_2_10_0_i24,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i24);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r4 = r3;
	r3 = r1;
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__post_typecheck__finish_pred_6_0),
		mercury__purity__check_preds_purity_2_10_0_i25,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i25);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r5 = r1;
	MR_stackvar(16) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(6);
	MR_stackvar(10) = (((Integer) MR_stackvar(3) + (Integer) MR_stackvar(13)) + (Integer) MR_stackvar(5));
Define_label(mercury__purity__check_preds_purity_2_10_0_i26);
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__purity__check_preds_purity_2_10_0_i27,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i27);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__purity__check_preds_purity_2_10_0_i28,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i28);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_set_preds_3_0),
		mercury__purity__check_preds_purity_2_10_0_i29,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i29);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_predicate_table_3_0),
		mercury__purity__check_preds_purity_2_10_0_i30,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i30);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_goal_type_2_0),
		mercury__purity__check_preds_purity_2_10_0_i32,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i32);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	if (((Integer) 2 != (Integer) r1))
		GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i31);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury__post_typecheck__finish_assertion_5_0),
		mercury__purity__check_preds_purity_2_10_0_i33,
		STATIC(mercury__purity__check_preds_purity_2_10_0));
Define_label(mercury__purity__check_preds_purity_2_10_0_i33);
	update_prof_current_proc(LABEL(mercury__purity__check_preds_purity_2_10_0));
	r3 = r1;
	r6 = r2;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(11);
	MR_succip = (Code *) MR_stackvar(17);
	GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i1005);
Define_label(mercury__purity__check_preds_purity_2_10_0_i31);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(7);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(11);
	r3 = MR_stackvar(14);
	r6 = MR_stackvar(16);
	MR_succip = (Code *) MR_stackvar(17);
	GOTO_LABEL(mercury__purity__check_preds_purity_2_10_0_i1005);
Define_label(mercury__purity__check_preds_purity_2_10_0_i3);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	r4 = r6;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_get_purity_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_promised_pure_2_0);
Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
Declare_entry(mercury__hlds_pred__clauses_info_clauses_2_0);
Declare_entry(mercury__hlds_pred__clauses_info_set_clauses_3_0);
Declare_entry(mercury__hlds_pred__pred_info_set_clauses_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
Declare_entry(mercury__prog_io_util__report_warning_3_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_out__write_pred_or_func_3_0);

BEGIN_MODULE(purity_module13)
	init_entry(mercury__purity__puritycheck_pred_7_0);
	init_label(mercury__purity__puritycheck_pred_7_0_i2);
	init_label(mercury__purity__puritycheck_pred_7_0_i3);
	init_label(mercury__purity__puritycheck_pred_7_0_i5);
	init_label(mercury__purity__puritycheck_pred_7_0_i4);
	init_label(mercury__purity__puritycheck_pred_7_0_i6);
	init_label(mercury__purity__puritycheck_pred_7_0_i7);
	init_label(mercury__purity__puritycheck_pred_7_0_i8);
	init_label(mercury__purity__puritycheck_pred_7_0_i9);
	init_label(mercury__purity__puritycheck_pred_7_0_i10);
	init_label(mercury__purity__puritycheck_pred_7_0_i11);
	init_label(mercury__purity__puritycheck_pred_7_0_i17);
	init_label(mercury__purity__puritycheck_pred_7_0_i18);
	init_label(mercury__purity__puritycheck_pred_7_0_i19);
	init_label(mercury__purity__puritycheck_pred_7_0_i20);
	init_label(mercury__purity__puritycheck_pred_7_0_i21);
	init_label(mercury__purity__puritycheck_pred_7_0_i22);
	init_label(mercury__purity__puritycheck_pred_7_0_i23);
	init_label(mercury__purity__puritycheck_pred_7_0_i24);
	init_label(mercury__purity__puritycheck_pred_7_0_i26);
	init_label(mercury__purity__puritycheck_pred_7_0_i27);
	init_label(mercury__purity__puritycheck_pred_7_0_i28);
	init_label(mercury__purity__puritycheck_pred_7_0_i29);
	init_label(mercury__purity__puritycheck_pred_7_0_i30);
	init_label(mercury__purity__puritycheck_pred_7_0_i33);
	init_label(mercury__purity__puritycheck_pred_7_0_i34);
	init_label(mercury__purity__puritycheck_pred_7_0_i35);
	init_label(mercury__purity__puritycheck_pred_7_0_i36);
	init_label(mercury__purity__puritycheck_pred_7_0_i37);
	init_label(mercury__purity__puritycheck_pred_7_0_i38);
	init_label(mercury__purity__puritycheck_pred_7_0_i31);
	init_label(mercury__purity__puritycheck_pred_7_0_i13);
	init_label(mercury__purity__puritycheck_pred_7_0_i44);
	init_label(mercury__purity__puritycheck_pred_7_0_i41);
	init_label(mercury__purity__puritycheck_pred_7_0_i49);
	init_label(mercury__purity__puritycheck_pred_7_0_i46);
	init_label(mercury__purity__puritycheck_pred_7_0_i55);
	init_label(mercury__purity__puritycheck_pred_7_0_i52);
BEGIN_CODE

/* code for predicate 'puritycheck_pred'/7 in mode 0 */
Define_static(mercury__purity__puritycheck_pred_7_0);
	MR_incr_sp_push_msg(15, "purity:puritycheck_pred/7");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r3;
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_purity_2_0),
		mercury__purity__puritycheck_pred_7_0_i2,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_promised_pure_2_0),
		mercury__purity__puritycheck_pred_7_0_i3,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_goal_type_2_0),
		mercury__purity__puritycheck_pred_7_0_i5,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i4);
	r1 = MR_stackvar(2);
	MR_stackvar(9) = (Integer) 2;
	MR_stackvar(10) = (Integer) 0;
	MR_stackvar(11) = (Integer) 0;
	MR_stackvar(12) = MR_stackvar(6);
	GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i11);
Define_label(mercury__purity__puritycheck_pred_7_0_i4);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__purity__puritycheck_pred_7_0_i6,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_clauses_2_0),
		mercury__purity__puritycheck_pred_7_0_i7,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = (Integer) 0;
	r5 = (Integer) 0;
	r6 = MR_stackvar(6);
	call_localret(STATIC(mercury__purity__compute_purity_10_0),
		mercury__purity__puritycheck_pred_7_0_i8,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(10) = r2;
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(11) = r3;
	MR_stackvar(12) = r4;
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_set_clauses_3_0),
		mercury__purity__puritycheck_pred_7_0_i9,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_clauses_info_3_0),
		mercury__purity__puritycheck_pred_7_0_i10,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(9) = MR_stackvar(10);
Define_label(mercury__purity__puritycheck_pred_7_0_i11);
	if (((Integer) MR_stackvar(7) == (Integer) 0))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i13);
	if (((Integer) MR_stackvar(8) != (Integer) 1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i13);
	MR_stackvar(3) = r1;
	MR_stackvar(5) = ((Integer) MR_stackvar(11) + (Integer) 1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__puritycheck_pred_7_0_i17,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i17);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__puritycheck_pred_7_0_i18,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i18);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__puritycheck_pred_7_0_i19,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i19);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i20,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i20);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__puritycheck_pred_7_0_i21,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i21);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i22,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i22);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__puritycheck_pred_7_0_i23,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i23);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  warning: declared `", 21);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__purity__puritycheck_pred_7_0_i24,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i24);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	if (((Integer) MR_stackvar(7) != (Integer) 0))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i26);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i28,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i26);
	if (((Integer) MR_stackvar(7) != (Integer) 1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i27);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i28,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i27);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i28,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i28);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' but promised pure.\n", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i29,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i29);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Integer) 19;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__purity__puritycheck_pred_7_0_i30,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i30);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i31);
	MR_stackvar(14) = r2;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__purity__puritycheck_pred_7_0_i33,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i33);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__puritycheck_pred_7_0_i34,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i34);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  A pure ", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i35,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i35);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__hlds_out__write_pred_or_func_3_0),
		mercury__purity__puritycheck_pred_7_0_i36,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i36);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" that invokes impure or semipure code should\n", 45);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i37,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i37);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__puritycheck_pred_7_0_i38,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i38);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  be promised pure and should have no impurity declaration.\n", 60);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__puritycheck_pred_7_0_i55,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i31);
	r1 = MR_stackvar(3);
	r3 = r2;
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__puritycheck_pred_7_0_i13);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(9);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__puritycheck_pred_7_0_i44,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i44);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	if ((MR_stackvar(9) == r1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i41);
	MR_stackvar(5) = MR_stackvar(11);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(12);
	call_localret(STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0),
		mercury__purity__puritycheck_pred_7_0_i55,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i41);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__puritycheck_pred_7_0_i49,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i49);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	if ((MR_stackvar(7) == r1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i46);
	if (((Integer) MR_stackvar(8) != (Integer) 0))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i46);
	MR_stackvar(5) = ((Integer) MR_stackvar(11) + (Integer) 1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(12);
	call_localret(STATIC(mercury__purity__error_inferred_impure_6_0),
		mercury__purity__puritycheck_pred_7_0_i55,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i46);
	r1 = MR_stackvar(3);
	if (((Integer) MR_stackvar(10) != (Integer) 0))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i52);
	if (((Integer) MR_stackvar(8) != (Integer) 1))
		GOTO_LABEL(mercury__purity__puritycheck_pred_7_0_i52);
	MR_stackvar(3) = r1;
	MR_stackvar(5) = MR_stackvar(11);
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(12);
	call_localret(STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0),
		mercury__purity__puritycheck_pred_7_0_i55,
		STATIC(mercury__purity__puritycheck_pred_7_0));
Define_label(mercury__purity__puritycheck_pred_7_0_i55);
	update_prof_current_proc(LABEL(mercury__purity__puritycheck_pred_7_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__puritycheck_pred_7_0_i52);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE


BEGIN_MODULE(purity_module14)
	init_entry(mercury__purity__compute_purity_10_0);
	init_label(mercury__purity__compute_purity_10_0_i4);
	init_label(mercury__purity__compute_purity_10_0_i5);
	init_label(mercury__purity__compute_purity_10_0_i6);
	init_label(mercury__purity__compute_purity_10_0_i7);
	init_label(mercury__purity__compute_purity_10_0_i3);
BEGIN_CODE

/* code for predicate 'compute_purity'/10 in mode 0 */
Define_static(mercury__purity__compute_purity_10_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__compute_purity_10_0_i3);
	MR_incr_sp_push_msg(11, "purity:compute_purity/10");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(3) = r4;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r7 = r6;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = r2;
	r6 = r5;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__purity__compute_expr_purity_11_0),
		mercury__purity__compute_purity_10_0_i4,
		STATIC(mercury__purity__compute_purity_10_0));
	}
Define_label(mercury__purity__compute_purity_10_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__compute_purity_10_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = MR_tempr1;
	MR_stackvar(8) = r2;
	MR_stackvar(9) = r3;
	MR_stackvar(10) = r4;
	call_localret(STATIC(mercury__purity__add_goal_info_purity_feature_3_0),
		mercury__purity__compute_purity_10_0_i5,
		STATIC(mercury__purity__compute_purity_10_0));
	}
Define_label(mercury__purity__compute_purity_10_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__compute_purity_10_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__compute_purity_10_0_i6,
		STATIC(mercury__purity__compute_purity_10_0));
Define_label(mercury__purity__compute_purity_10_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__compute_purity_10_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__purity__compute_purity_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	MR_stackvar(1) = r3;
	r4 = r1;
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__purity__compute_purity_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(7);
	r1 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(2);
	localcall(mercury__purity__compute_purity_10_0,
		LABEL(mercury__purity__compute_purity_10_0_i7),
		STATIC(mercury__purity__compute_purity_10_0));
	}
Define_label(mercury__purity__compute_purity_10_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__compute_purity_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__purity__compute_purity_10_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__purity__compute_purity_10_0_i3);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	r4 = r6;
	proceed();
END_MODULE

Declare_entry(mercury__post_typecheck__resolve_pred_overloading_7_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__code_util__compiler_generated_1_0);
Declare_entry(mercury__post_typecheck__finish_aditi_builtin_11_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__mode_util__unused_mode_1_0);
Declare_entry(mercury__fn__mode_util__aditi_ui_mode_0_0);
Declare_entry(mercury__hlds_pred__clauses_info_vartypes_2_0);
Declare_entry(mercury__map__apply_to_list_3_0);
Declare_entry(mercury__hlds_goal__negate_goal_3_0);

BEGIN_MODULE(purity_module15)
	init_entry(mercury__purity__compute_expr_purity_11_0);
	init_label(mercury__purity__compute_expr_purity_11_0_i4);
	init_label(mercury__purity__compute_expr_purity_11_0_i5);
	init_label(mercury__purity__compute_expr_purity_11_0_i6);
	init_label(mercury__purity__compute_expr_purity_11_0_i7);
	init_label(mercury__purity__compute_expr_purity_11_0_i8);
	init_label(mercury__purity__compute_expr_purity_11_0_i9);
	init_label(mercury__purity__compute_expr_purity_11_0_i10);
	init_label(mercury__purity__compute_expr_purity_11_0_i11);
	init_label(mercury__purity__compute_expr_purity_11_0_i12);
	init_label(mercury__purity__compute_expr_purity_11_0_i15);
	init_label(mercury__purity__compute_expr_purity_11_0_i13);
	init_label(mercury__purity__compute_expr_purity_11_0_i17);
	init_label(mercury__purity__compute_expr_purity_11_0_i18);
	init_label(mercury__purity__compute_expr_purity_11_0_i22);
	init_label(mercury__purity__compute_expr_purity_11_0_i24);
	init_label(mercury__purity__compute_expr_purity_11_0_i20);
	init_label(mercury__purity__compute_expr_purity_11_0_i25);
	init_label(mercury__purity__compute_expr_purity_11_0_i30);
	init_label(mercury__purity__compute_expr_purity_11_0_i1005);
	init_label(mercury__purity__compute_expr_purity_11_0_i34);
	init_label(mercury__purity__compute_expr_purity_11_0_i35);
	init_label(mercury__purity__compute_expr_purity_11_0_i36);
	init_label(mercury__purity__compute_expr_purity_11_0_i37);
	init_label(mercury__purity__compute_expr_purity_11_0_i38);
	init_label(mercury__purity__compute_expr_purity_11_0_i39);
	init_label(mercury__purity__compute_expr_purity_11_0_i40);
	init_label(mercury__purity__compute_expr_purity_11_0_i43);
	init_label(mercury__purity__compute_expr_purity_11_0_i44);
	init_label(mercury__purity__compute_expr_purity_11_0_i49);
	init_label(mercury__purity__compute_expr_purity_11_0_i48);
	init_label(mercury__purity__compute_expr_purity_11_0_i50);
	init_label(mercury__purity__compute_expr_purity_11_0_i52);
	init_label(mercury__purity__compute_expr_purity_11_0_i53);
	init_label(mercury__purity__compute_expr_purity_11_0_i54);
	init_label(mercury__purity__compute_expr_purity_11_0_i55);
	init_label(mercury__purity__compute_expr_purity_11_0_i56);
	init_label(mercury__purity__compute_expr_purity_11_0_i46);
	init_label(mercury__purity__compute_expr_purity_11_0_i57);
	init_label(mercury__purity__compute_expr_purity_11_0_i58);
	init_label(mercury__purity__compute_expr_purity_11_0_i59);
	init_label(mercury__purity__compute_expr_purity_11_0_i60);
	init_label(mercury__purity__compute_expr_purity_11_0_i61);
	init_label(mercury__purity__compute_expr_purity_11_0_i64);
	init_label(mercury__purity__compute_expr_purity_11_0_i62);
	init_label(mercury__purity__compute_expr_purity_11_0_i65);
	init_label(mercury__purity__compute_expr_purity_11_0_i67);
	init_label(mercury__purity__compute_expr_purity_11_0_i68);
	init_label(mercury__purity__compute_expr_purity_11_0_i69);
	init_label(mercury__purity__compute_expr_purity_11_0_i70);
	init_label(mercury__purity__compute_expr_purity_11_0_i71);
	init_label(mercury__purity__compute_expr_purity_11_0_i72);
	init_label(mercury__purity__compute_expr_purity_11_0_i73);
	init_label(mercury__purity__compute_expr_purity_11_0_i75);
	init_label(mercury__purity__compute_expr_purity_11_0_i76);
	init_label(mercury__purity__compute_expr_purity_11_0_i77);
	init_label(mercury__purity__compute_expr_purity_11_0_i78);
	init_label(mercury__purity__compute_expr_purity_11_0_i79);
	init_label(mercury__purity__compute_expr_purity_11_0_i80);
	init_label(mercury__purity__compute_expr_purity_11_0_i81);
	init_label(mercury__purity__compute_expr_purity_11_0_i82);
BEGIN_CODE

/* code for predicate 'compute_expr_purity'/11 in mode 0 */
Define_static(mercury__purity__compute_expr_purity_11_0);
	MR_incr_sp_push_msg(15, "purity:compute_expr_purity/11");
	MR_stackvar(15) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__purity__compute_expr_purity_11_0_i4) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i6) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i30) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i37));
Define_label(mercury__purity__compute_expr_purity_11_0_i4);
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__purity__compute_goals_purity_11_0),
		mercury__purity__compute_expr_purity_11_0_i5,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i6);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r5;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(6) = r2;
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 5);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(7) = r6;
	MR_stackvar(8) = r7;
	call_localret(ENTRY(mercury__post_typecheck__resolve_pred_overloading_7_0),
		mercury__purity__compute_expr_purity_11_0_i7,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 6, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = MR_stackvar(9);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 5) = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(9) = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__purity__compute_expr_purity_11_0_i8,
		STATIC(mercury__purity__compute_expr_purity_11_0));
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__purity__compute_expr_purity_11_0_i9,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_purity_2_0),
		mercury__purity__compute_expr_purity_11_0_i10,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__purity__infer_goal_info_purity_2_0),
		mercury__purity__compute_expr_purity_11_0_i11,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__purity__compute_expr_purity_11_0_i12,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_util__compiler_generated_1_0),
		mercury__purity__compute_expr_purity_11_0_i15,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i15);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i13);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i13);
	r1 = MR_stackvar(3);
	if ((MR_stackvar(6) != MR_stackvar(2)))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i17);
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i18);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i18);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__purity__less_pure_2_0),
		mercury__purity__compute_expr_purity_11_0_i22,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i22);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i20);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(8);
	call_localret(STATIC(mercury__purity__error_missing_body_impurity_decl__ua0_7_0),
		mercury__purity__compute_expr_purity_11_0_i24,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i24);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = ((Integer) MR_stackvar(7) + (Integer) 1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i20);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__purity__warn_unnecessary_body_impurity_decl__ua0_8_0),
		mercury__purity__compute_expr_purity_11_0_i25,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i25);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i30);
	r5 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r5);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i1005);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i34);
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i1005);
	r3 = r6;
	r4 = r7;
	GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i57);
Define_label(mercury__purity__compute_expr_purity_11_0_i34);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r5, (Integer) 1);
	r1 = r2;
	MR_stackvar(2) = r6;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(8) = r7;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__purity__compute_expr_purity_11_0_i35,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i35);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(8);
	call_localret(ENTRY(mercury__post_typecheck__finish_aditi_builtin_11_0),
		mercury__purity__compute_expr_purity_11_0_i36,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i36);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 4, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(2), r1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 2) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r5;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i57);
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i37);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__purity__compute_expr_purity_11_0_i38) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i40) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i58) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i60) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i67) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i69) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i75) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i79) AND
		LABEL(mercury__purity__compute_expr_purity_11_0_i81));
Define_label(mercury__purity__compute_expr_purity_11_0_i38);
	r2 = r3;
	r3 = r4;
	r4 = r5;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__purity__compute_cases_purity_11_0),
		mercury__purity__compute_expr_purity_11_0_i39,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i39);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r5;
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i40);
	r5 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if ((MR_tag(r5) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i1005);
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r5, (Integer) 7);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(14) = r2;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r5, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r5, (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(2), r5, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(2), r5, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(2), r5, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(2), r5, (Integer) 6);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r5 = (Integer) 1;
	MR_stackvar(3) = r3;
	localcall(mercury__purity__compute_expr_purity_11_0,
		LABEL(mercury__purity__compute_expr_purity_11_0_i43),
		STATIC(mercury__purity__compute_expr_purity_11_0));
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i43);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = MR_stackvar(14);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_stackvar(14) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r5;
	call_localret(STATIC(mercury__purity__error_if_closure_impure_6_0),
		mercury__purity__compute_expr_purity_11_0_i44,
		STATIC(mercury__purity__compute_expr_purity_11_0));
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i44);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i46);
	if (((Integer) MR_stackvar(9) != (Integer) 0))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i48);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("compute_expr_purity: modes need fixing for normal lambda_goal", 61);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__purity__compute_expr_purity_11_0_i49,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i49);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__purity__compute_expr_purity_11_0_i53,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i48);
	if (((Integer) MR_stackvar(9) != (Integer) 1))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i50);
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__mode_util__unused_mode_1_0),
		mercury__purity__compute_expr_purity_11_0_i52,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i50);
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__fn__mode_util__aditi_ui_mode_0_0),
		mercury__purity__compute_expr_purity_11_0_i52,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i52);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__purity__compute_expr_purity_11_0_i53,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i53);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	call_localret(ENTRY(mercury__hlds_pred__clauses_info_vartypes_2_0),
		mercury__purity__compute_expr_purity_11_0_i54,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i54);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_purity__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_purity__common_1);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__purity__compute_expr_purity_11_0_i55,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i55);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(12);
	call_localret(STATIC(mercury__purity__fix_aditi_state_modes_4_0),
		mercury__purity__compute_expr_purity_11_0_i56,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i56);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 6, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 8, mercury__purity__compute_expr_purity_11_0, "hlds_goal:unify_rhs/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(2), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(2), r3, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(2), r3, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(2), r3, (Integer) 5) = r2;
	MR_field(MR_mktag(2), r3, (Integer) 6) = MR_stackvar(13);
	MR_field(MR_mktag(2), r3, (Integer) 7) = MR_stackvar(14);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_stackvar(7);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i57);
Define_label(mercury__purity__compute_expr_purity_11_0_i46);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 6, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	r4 = r2;
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 8, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 7) = MR_stackvar(14);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 6) = MR_stackvar(13);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 5) = MR_stackvar(12);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_tempr1;
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i57);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i58);
	r2 = r3;
	r3 = r4;
	r4 = r5;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__purity__compute_goals_purity_11_0),
		mercury__purity__compute_expr_purity_11_0_i59,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i59);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i60);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(7) = r6;
	MR_stackvar(8) = r7;
	call_localret(ENTRY(mercury__hlds_goal__negate_goal_3_0),
		mercury__purity__compute_expr_purity_11_0_i61,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i61);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i62);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__purity__compute_expr_purity_11_0_i62);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i64,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i64);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i62);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i65,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i65);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i67);
	r2 = r3;
	r3 = r4;
	r4 = r5;
	r5 = r6;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r6 = r7;
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i68,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i68);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r5;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i69);
	r2 = r3;
	MR_stackvar(3) = r3;
	r3 = r4;
	MR_stackvar(4) = r4;
	r4 = r5;
	MR_stackvar(5) = r5;
	r5 = r6;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r6 = r7;
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i70,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i70);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	r5 = r3;
	r6 = r4;
	MR_stackvar(8) = r2;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i71,
		STATIC(mercury__purity__compute_expr_purity_11_0));
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i71);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r3;
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(3);
	r6 = r4;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(6);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__purity__compute_goal_purity_10_0),
		mercury__purity__compute_expr_purity_11_0_i72,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i72);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__purity__compute_expr_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(3);
	MR_stackvar(3) = r2;
	r2 = MR_stackvar(4);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	r1 = MR_stackvar(8);
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(7);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__compute_expr_purity_11_0_i73,
		STATIC(mercury__purity__compute_expr_purity_11_0));
	}
Define_label(mercury__purity__compute_expr_purity_11_0_i73);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__compute_expr_purity_11_0_i78,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i75);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = r4;
	MR_stackvar(2) = r6;
	MR_stackvar(4) = r7;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__purity__compute_expr_purity_11_0_i76,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i76);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__purity__compute_expr_purity_11_0_i77,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i77);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_purity_2_0),
		mercury__purity__compute_expr_purity_11_0_i78,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i78);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i79);
	r2 = r3;
	r3 = r4;
	r4 = r5;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r5 = (Integer) 0;
	call_localret(STATIC(mercury__purity__compute_goals_purity_11_0),
		mercury__purity__compute_expr_purity_11_0_i80,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i80);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__purity__compute_expr_purity_11_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__purity__compute_expr_purity_11_0_i81);
	MR_stackvar(4) = r7;
	r1 = (Word) MR_string_const("compute_expr_purity: unexpected bi_implication", 46);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__purity__compute_expr_purity_11_0_i82,
		STATIC(mercury__purity__compute_expr_purity_11_0));
Define_label(mercury__purity__compute_expr_purity_11_0_i82);
	update_prof_current_proc(LABEL(mercury__purity__compute_expr_purity_11_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE


BEGIN_MODULE(purity_module16)
	init_entry(mercury__purity__compute_goal_purity_10_0);
	init_label(mercury__purity__compute_goal_purity_10_0_i2);
	init_label(mercury__purity__compute_goal_purity_10_0_i3);
BEGIN_CODE

/* code for predicate 'compute_goal_purity'/10 in mode 0 */
Define_static(mercury__purity__compute_goal_purity_10_0);
	MR_incr_sp_push_msg(5, "purity:compute_goal_purity/10");
	MR_stackvar(5) = (Word) MR_succip;
	r7 = r6;
	r6 = r5;
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__purity__compute_expr_purity_11_0),
		mercury__purity__compute_goal_purity_10_0_i2,
		STATIC(mercury__purity__compute_goal_purity_10_0));
Define_label(mercury__purity__compute_goal_purity_10_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__compute_goal_purity_10_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__purity__add_goal_info_purity_feature_3_0),
		mercury__purity__compute_goal_purity_10_0_i3,
		STATIC(mercury__purity__compute_goal_purity_10_0));
Define_label(mercury__purity__compute_goal_purity_10_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__compute_goal_purity_10_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__purity__compute_goal_purity_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE


BEGIN_MODULE(purity_module17)
	init_entry(mercury__purity__compute_goals_purity_11_0);
	init_label(mercury__purity__compute_goals_purity_11_0_i4);
	init_label(mercury__purity__compute_goals_purity_11_0_i5);
	init_label(mercury__purity__compute_goals_purity_11_0_i6);
	init_label(mercury__purity__compute_goals_purity_11_0_i7);
	init_label(mercury__purity__compute_goals_purity_11_0_i3);
BEGIN_CODE

/* code for predicate 'compute_goals_purity'/11 in mode 0 */
Define_static(mercury__purity__compute_goals_purity_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__compute_goals_purity_11_0_i3);
	MR_incr_sp_push_msg(10, "purity:compute_goals_purity/11");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(4) = r5;
	r5 = r4;
	MR_stackvar(3) = r4;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__purity__compute_expr_purity_11_0),
		mercury__purity__compute_goals_purity_11_0_i4,
		STATIC(mercury__purity__compute_goals_purity_11_0));
	}
Define_label(mercury__purity__compute_goals_purity_11_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__compute_goals_purity_11_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = r3;
	MR_stackvar(8) = r4;
	call_localret(STATIC(mercury__purity__add_goal_info_purity_feature_3_0),
		mercury__purity__compute_goals_purity_11_0_i5,
		STATIC(mercury__purity__compute_goals_purity_11_0));
Define_label(mercury__purity__compute_goals_purity_11_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__compute_goals_purity_11_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__purity__compute_goals_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	r2 = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__compute_goals_purity_11_0_i6,
		STATIC(mercury__purity__compute_goals_purity_11_0));
Define_label(mercury__purity__compute_goals_purity_11_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__compute_goals_purity_11_0));
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(8);
	localcall(mercury__purity__compute_goals_purity_11_0,
		LABEL(mercury__purity__compute_goals_purity_11_0_i7),
		STATIC(mercury__purity__compute_goals_purity_11_0));
Define_label(mercury__purity__compute_goals_purity_11_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__compute_goals_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__purity__compute_goals_purity_11_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__purity__compute_goals_purity_11_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r5;
	r3 = r6;
	r4 = r7;
	proceed();
END_MODULE


BEGIN_MODULE(purity_module18)
	init_entry(mercury__purity__compute_cases_purity_11_0);
	init_label(mercury__purity__compute_cases_purity_11_0_i4);
	init_label(mercury__purity__compute_cases_purity_11_0_i5);
	init_label(mercury__purity__compute_cases_purity_11_0_i6);
	init_label(mercury__purity__compute_cases_purity_11_0_i7);
	init_label(mercury__purity__compute_cases_purity_11_0_i3);
BEGIN_CODE

/* code for predicate 'compute_cases_purity'/11 in mode 0 */
Define_static(mercury__purity__compute_cases_purity_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__compute_cases_purity_11_0_i3);
	MR_incr_sp_push_msg(11, "purity:compute_cases_purity/11");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(4) = r5;
	r5 = r4;
	MR_stackvar(3) = r4;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(7) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	call_localret(STATIC(mercury__purity__compute_expr_purity_11_0),
		mercury__purity__compute_cases_purity_11_0_i4,
		STATIC(mercury__purity__compute_cases_purity_11_0));
	}
Define_label(mercury__purity__compute_cases_purity_11_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__compute_cases_purity_11_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	MR_stackvar(8) = r3;
	MR_stackvar(9) = r4;
	call_localret(STATIC(mercury__purity__add_goal_info_purity_feature_3_0),
		mercury__purity__compute_cases_purity_11_0_i5,
		STATIC(mercury__purity__compute_cases_purity_11_0));
Define_label(mercury__purity__compute_cases_purity_11_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__compute_cases_purity_11_0));
	r2 = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__purity__compute_cases_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	MR_stackvar(4) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__purity__compute_cases_purity_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = r2;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 1) = r3;
	r2 = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(10);
	call_localret(STATIC(mercury__purity__worst_purity_3_0),
		mercury__purity__compute_cases_purity_11_0_i6,
		STATIC(mercury__purity__compute_cases_purity_11_0));
Define_label(mercury__purity__compute_cases_purity_11_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__compute_cases_purity_11_0));
	r5 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	localcall(mercury__purity__compute_cases_purity_11_0,
		LABEL(mercury__purity__compute_cases_purity_11_0_i7),
		STATIC(mercury__purity__compute_cases_purity_11_0));
Define_label(mercury__purity__compute_cases_purity_11_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__compute_cases_purity_11_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__purity__compute_cases_purity_11_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__purity__compute_cases_purity_11_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r5;
	r3 = r6;
	r4 = r7;
	proceed();
END_MODULE

Declare_entry(mercury__type_util__type_is_aditi_state_1_0);

BEGIN_MODULE(purity_module19)
	init_entry(mercury__purity__fix_aditi_state_modes_4_0);
	init_label(mercury__purity__fix_aditi_state_modes_4_0_i3);
	init_label(mercury__purity__fix_aditi_state_modes_4_0_i11);
	init_label(mercury__purity__fix_aditi_state_modes_4_0_i9);
	init_label(mercury__purity__fix_aditi_state_modes_4_0_i14);
	init_label(mercury__purity__fix_aditi_state_modes_4_0_i8);
BEGIN_CODE

/* code for predicate 'fix_aditi_state_modes'/4 in mode 0 */
Define_static(mercury__purity__fix_aditi_state_modes_4_0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__fix_aditi_state_modes_4_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__fix_aditi_state_modes_4_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__purity__fix_aditi_state_modes_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__purity__fix_aditi_state_modes_4_0_i8);
	MR_incr_sp_push_msg(6, "purity:fix_aditi_state_modes/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	call_localret(ENTRY(mercury__type_util__type_is_aditi_state_1_0),
		mercury__purity__fix_aditi_state_modes_4_0_i11,
		STATIC(mercury__purity__fix_aditi_state_modes_4_0));
Define_label(mercury__purity__fix_aditi_state_modes_4_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__fix_aditi_state_modes_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__fix_aditi_state_modes_4_0_i9);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(5);
	localcall(mercury__purity__fix_aditi_state_modes_4_0,
		LABEL(mercury__purity__fix_aditi_state_modes_4_0_i14),
		STATIC(mercury__purity__fix_aditi_state_modes_4_0));
Define_label(mercury__purity__fix_aditi_state_modes_4_0_i9);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	MR_stackvar(4) = MR_stackvar(2);
	localcall(mercury__purity__fix_aditi_state_modes_4_0,
		LABEL(mercury__purity__fix_aditi_state_modes_4_0_i14),
		STATIC(mercury__purity__fix_aditi_state_modes_4_0));
Define_label(mercury__purity__fix_aditi_state_modes_4_0_i14);
	update_prof_current_proc(LABEL(mercury__purity__fix_aditi_state_modes_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__purity__fix_aditi_state_modes_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__purity__fix_aditi_state_modes_4_0_i8);
	r1 = (Word) MR_string_const("purity:fix_aditi_state_modes", 28);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__purity__fix_aditi_state_modes_4_0));
END_MODULE


BEGIN_MODULE(purity_module20)
	init_entry(mercury__purity__warn_exaggerated_impurity_decl_7_0);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i2);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i3);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i4);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i5);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i6);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i7);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i8);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i9);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i11);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i12);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i13);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i14);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i16);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i17);
	init_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i18);
BEGIN_CODE

/* code for predicate 'warn_exaggerated_impurity_decl'/7 in mode 0 */
Define_static(mercury__purity__warn_exaggerated_impurity_decl_7_0);
	MR_incr_sp_push_msg(7, "purity:warn_exaggerated_impurity_decl/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i2,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i3,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i4,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i5,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i6,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i7,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i8,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  warning: declared `", 21);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i9,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0_i11);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i13,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i11);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0_i12);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i13,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i12);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i13,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i13);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' but actually ", 15);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i14,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i14);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	if (((Integer) MR_stackvar(5) != (Integer) 0))
		GOTO_LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0_i16);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i18,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i16);
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0_i17);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i18,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i17);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_exaggerated_impurity_decl_7_0_i18,
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
Define_label(mercury__purity__warn_exaggerated_impurity_decl_7_0_i18);
	update_prof_current_proc(LABEL(mercury__purity__warn_exaggerated_impurity_decl_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__warn_exaggerated_impurity_decl_7_0));
END_MODULE


BEGIN_MODULE(purity_module21)
	init_entry(mercury__purity__warn_unnecessary_promise_pure_5_0);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i2);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i3);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i4);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i5);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i6);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i7);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i8);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i9);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i10);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i13);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i14);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i15);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i16);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i17);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i18);
	init_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i11);
BEGIN_CODE

/* code for predicate 'warn_unnecessary_promise_pure'/5 in mode 0 */
Define_static(mercury__purity__warn_unnecessary_promise_pure_5_0);
	MR_incr_sp_push_msg(6, "purity:warn_unnecessary_promise_pure/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i2,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i3,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i4,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i5,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i6,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i7,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i8,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  warning: unnecessary `promise_pure' pragma.\n", 46);
	call_localret(ENTRY(mercury__prog_io_util__report_warning_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i9,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Integer) 19;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i10,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0_i11);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i13,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i13);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i14,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i14);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("  This ", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i15,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i15);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_out__write_pred_or_func_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i16,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i16);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" does not invoke any impure or semipure code,\n", 46);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i17,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i17);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__warn_unnecessary_promise_pure_5_0_i18,
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i18);
	update_prof_current_proc(LABEL(mercury__purity__warn_unnecessary_promise_pure_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  so there is no need for a `promise_pure' pragma.\n", 51);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__warn_unnecessary_promise_pure_5_0));
Define_label(mercury__purity__warn_unnecessary_promise_pure_5_0_i11);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(purity_module22)
	init_entry(mercury__purity__error_inferred_impure_6_0);
	init_label(mercury__purity__error_inferred_impure_6_0_i2);
	init_label(mercury__purity__error_inferred_impure_6_0_i3);
	init_label(mercury__purity__error_inferred_impure_6_0_i4);
	init_label(mercury__purity__error_inferred_impure_6_0_i5);
	init_label(mercury__purity__error_inferred_impure_6_0_i6);
	init_label(mercury__purity__error_inferred_impure_6_0_i7);
	init_label(mercury__purity__error_inferred_impure_6_0_i8);
	init_label(mercury__purity__error_inferred_impure_6_0_i9);
	init_label(mercury__purity__error_inferred_impure_6_0_i10);
	init_label(mercury__purity__error_inferred_impure_6_0_i11);
	init_label(mercury__purity__error_inferred_impure_6_0_i12);
	init_label(mercury__purity__error_inferred_impure_6_0_i14);
	init_label(mercury__purity__error_inferred_impure_6_0_i15);
	init_label(mercury__purity__error_inferred_impure_6_0_i16);
	init_label(mercury__purity__error_inferred_impure_6_0_i17);
	init_label(mercury__purity__error_inferred_impure_6_0_i18);
	init_label(mercury__purity__error_inferred_impure_6_0_i21);
	init_label(mercury__purity__error_inferred_impure_6_0_i19);
	init_label(mercury__purity__error_inferred_impure_6_0_i24);
	init_label(mercury__purity__error_inferred_impure_6_0_i26);
	init_label(mercury__purity__error_inferred_impure_6_0_i27);
	init_label(mercury__purity__error_inferred_impure_6_0_i28);
BEGIN_CODE

/* code for predicate 'error_inferred_impure'/6 in mode 0 */
Define_static(mercury__purity__error_inferred_impure_6_0);
	MR_incr_sp_push_msg(8, "purity:error_inferred_impure/6");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__error_inferred_impure_6_0_i2,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i2);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__purity__error_inferred_impure_6_0_i3,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i3);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__purity__error_inferred_impure_6_0_i4,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_inferred_impure_6_0_i5,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("In ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i6,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_out__write_pred_id_4_0),
		mercury__purity__error_inferred_impure_6_0_i7,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i7);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i8,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i8);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_inferred_impure_6_0_i9,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i9);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  error: ", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i10,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_out__write_pred_or_func_3_0),
		mercury__purity__error_inferred_impure_6_0_i11,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" is ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i12,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__error_inferred_impure_6_0_i14);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i16,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i14);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__purity__error_inferred_impure_6_0_i15);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i16,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i15);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i16,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i16);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i17,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i17);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_inferred_impure_6_0_i18,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i18);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_util__compiler_generated_1_0),
		mercury__purity__error_inferred_impure_6_0_i21,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i21);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__purity__error_inferred_impure_6_0_i19);
	r1 = (Word) MR_string_const("  It must be pure.\n", 19);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i19);
	r1 = (Word) MR_string_const("  It must be declared `", 23);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i24,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i24);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__purity__error_inferred_impure_6_0_i26);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i28,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i26);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__purity__error_inferred_impure_6_0_i27);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i28,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i27);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_inferred_impure_6_0_i28,
		STATIC(mercury__purity__error_inferred_impure_6_0));
Define_label(mercury__purity__error_inferred_impure_6_0_i28);
	update_prof_current_proc(LABEL(mercury__purity__error_inferred_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' or promised pure.\n", 20);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__purity__error_inferred_impure_6_0));
END_MODULE


BEGIN_MODULE(purity_module23)
	init_entry(mercury__purity__error_if_closure_impure_6_0);
	init_label(mercury__purity__error_if_closure_impure_6_0_i2);
	init_label(mercury__purity__error_if_closure_impure_6_0_i4);
	init_label(mercury__purity__error_if_closure_impure_6_0_i5);
	init_label(mercury__purity__error_if_closure_impure_6_0_i6);
	init_label(mercury__purity__error_if_closure_impure_6_0_i8);
	init_label(mercury__purity__error_if_closure_impure_6_0_i9);
	init_label(mercury__purity__error_if_closure_impure_6_0_i10);
	init_label(mercury__purity__error_if_closure_impure_6_0_i11);
	init_label(mercury__purity__error_if_closure_impure_6_0_i12);
	init_label(mercury__purity__error_if_closure_impure_6_0_i15);
	init_label(mercury__purity__error_if_closure_impure_6_0_i16);
	init_label(mercury__purity__error_if_closure_impure_6_0_i13);
BEGIN_CODE

/* code for predicate 'error_if_closure_impure'/6 in mode 0 */
Define_static(mercury__purity__error_if_closure_impure_6_0);
	MR_incr_sp_push_msg(4, "purity:error_if_closure_impure/6");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__purity__error_if_closure_impure_6_0_i2);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__purity__error_if_closure_impure_6_0_i2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = ((Integer) r3 + (Integer) 1);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__purity__error_if_closure_impure_6_0_i4,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i4);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_if_closure_impure_6_0_i5,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i5);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Error in closure: closure is ", 29);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i6,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i6);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__purity__error_if_closure_impure_6_0_i8);
	r2 = r1;
	r1 = (Word) MR_string_const("pure", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i10,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i8);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__purity__error_if_closure_impure_6_0_i9);
	r2 = r1;
	r1 = (Word) MR_string_const("semipure", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i10,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i9);
	r2 = r1;
	r1 = (Word) MR_string_const("impure", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i10,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i10);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i11,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i11);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = r1;
	r1 = (Integer) 19;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__purity__error_if_closure_impure_6_0_i12,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i12);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__purity__error_if_closure_impure_6_0_i13);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__write_context_3_0),
		mercury__purity__error_if_closure_impure_6_0_i15,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i15);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("  All closures must be pure.\n", 29);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__purity__error_if_closure_impure_6_0_i16,
		STATIC(mercury__purity__error_if_closure_impure_6_0));
Define_label(mercury__purity__error_if_closure_impure_6_0_i16);
	update_prof_current_proc(LABEL(mercury__purity__error_if_closure_impure_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__purity__error_if_closure_impure_6_0_i13);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__purity_maybe_bunch_0(void)
{
	purity_module0();
	purity_module1();
	purity_module2();
	purity_module3();
	purity_module4();
	purity_module5();
	purity_module6();
	purity_module7();
	purity_module8();
	purity_module9();
	purity_module10();
	purity_module11();
	purity_module12();
	purity_module13();
	purity_module14();
	purity_module15();
	purity_module16();
	purity_module17();
	purity_module18();
	purity_module19();
	purity_module20();
	purity_module21();
	purity_module22();
	purity_module23();
}

#endif

void mercury__purity__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__purity__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__purity_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
