/*
** Automatically generated from `rl_analyse.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_analyse__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__rl_analyse__do_io__ho3__ua0_3_0);
Declare_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i2);
Declare_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i3);
Declare_static(mercury____Index___rl_analyse__gen_kill_data_0__ua0_2_0);
Declare_static(mercury____Index___rl_analyse__block_data_2__ua0_2_0);
Declare_static(mercury____Index___rl_analyse__rl_analysis_3__ua0_2_0);
Declare_static(mercury__rl_analyse__equal__ua0_4_0);
Declare_static(mercury__rl_analyse__block_update__ua0_9_0);
Declare_static(mercury__rl_analyse__direction__ua0_2_0);
Declare_static(mercury__rl_analyse__confluence_list__ua0_8_0);
Declare_label(mercury__rl_analyse__confluence_list__ua0_8_0_i1001);
Declare_label(mercury__rl_analyse__confluence_list__ua0_8_0_i4);
Declare_label(mercury__rl_analyse__confluence_list__ua0_8_0_i3);
Declare_static(mercury__rl_analyse__dump_changed_data__ua0_7_0);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i2);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i3);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i4);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i5);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i6);
Declare_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i7);
Declare_static(mercury__rl_analyse__dump_block_data__ua0_6_0);
Declare_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i2);
Declare_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i3);
Declare_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i4);
Declare_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i5);
Declare_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i6);
Declare_static(mercury__rl_analyse__blocks__ua0_12_0);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i1004);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i4);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i5);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i6);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i8);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i10);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i11);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i12);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i13);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i14);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i15);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i17);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i16);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i18);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i19);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i22);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i20);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i24);
Declare_label(mercury__rl_analyse__blocks__ua0_12_0_i3);
Declare_static(mercury__rl_analyse__to_fixpoint__ua0_10_0);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i1003);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i2);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i5);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i3);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i6);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i7);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i8);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i11);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i14);
Declare_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i12);
Declare_static(mercury__rl_analyse__write_gen_kill_data__ua0_4_0);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i2);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i3);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i4);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i5);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i6);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i7);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i8);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i9);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i10);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i11);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i12);
Declare_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i13);
Declare_static(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0);
Declare_label(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0_i2);
Declare_static(mercury__rl_analyse__IntroducedFrom__pred__blocks__171__1_3_0);
Define_extern_entry(mercury__rl_analyse__rl_analyse_10_0);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i2);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i3);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i4);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i7);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i5);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i9);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i12);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i10);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i13);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i14);
Declare_label(mercury__rl_analyse__rl_analyse_10_0_i15);
Define_extern_entry(mercury__rl_analyse__write_gen_kill_data_4_0);
Declare_static(mercury__rl_analyse__dump_block_data_map_6_0);
Declare_label(mercury__rl_analyse__dump_block_data_map_6_0_i2);
Declare_label(mercury__rl_analyse__dump_block_data_map_6_0_i3);
Declare_static(mercury__rl_analyse__dump_block_data_6_0);
Define_extern_entry(mercury____Unify___rl_analyse__rl_analysis_3_0);
Declare_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i2);
Declare_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i4);
Declare_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i6);
Declare_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1005);
Declare_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
Define_extern_entry(mercury____Index___rl_analyse__rl_analysis_3_0);
Define_extern_entry(mercury____Compare___rl_analyse__rl_analysis_3_0);
Declare_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i3);
Declare_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i7);
Declare_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i11);
Declare_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i15);
Declare_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
Define_extern_entry(mercury____Unify___rl_analyse__block_data_map_2_0);
Define_extern_entry(mercury____Index___rl_analyse__block_data_map_2_0);
Define_extern_entry(mercury____Compare___rl_analyse__block_data_map_2_0);
Define_extern_entry(mercury____Unify___rl_analyse__block_data_2_0);
Declare_label(mercury____Unify___rl_analyse__block_data_2_0_i2);
Declare_label(mercury____Unify___rl_analyse__block_data_2_0_i4);
Declare_label(mercury____Unify___rl_analyse__block_data_2_0_i1);
Define_extern_entry(mercury____Index___rl_analyse__block_data_2_0);
Define_extern_entry(mercury____Compare___rl_analyse__block_data_2_0);
Declare_label(mercury____Compare___rl_analyse__block_data_2_0_i3);
Declare_label(mercury____Compare___rl_analyse__block_data_2_0_i7);
Declare_label(mercury____Compare___rl_analyse__block_data_2_0_i12);
Define_extern_entry(mercury____Unify___rl_analyse__direction_0_0);
Declare_label(mercury____Unify___rl_analyse__direction_0_0_i1);
Define_extern_entry(mercury____Index___rl_analyse__direction_0_0);
Define_extern_entry(mercury____Compare___rl_analyse__direction_0_0);
Define_extern_entry(mercury____Unify___rl_analyse__confluence_2_0);
Define_extern_entry(mercury____Index___rl_analyse__confluence_2_0);
Define_extern_entry(mercury____Compare___rl_analyse__confluence_2_0);
Define_extern_entry(mercury____Unify___rl_analyse__block_update_3_0);
Define_extern_entry(mercury____Index___rl_analyse__block_update_3_0);
Define_extern_entry(mercury____Compare___rl_analyse__block_update_3_0);
Define_extern_entry(mercury____Unify___rl_analyse__equal_2_0);
Define_extern_entry(mercury____Index___rl_analyse__equal_2_0);
Define_extern_entry(mercury____Compare___rl_analyse__equal_2_0);
Define_extern_entry(mercury____Unify___rl_analyse__write_3_0);
Define_extern_entry(mercury____Index___rl_analyse__write_3_0);
Define_extern_entry(mercury____Compare___rl_analyse__write_3_0);
Define_extern_entry(mercury____Unify___rl_analyse__gen_kill_data_0_0);
Declare_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i2);
Declare_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i4);
Declare_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i1);
Define_extern_entry(mercury____Index___rl_analyse__gen_kill_data_0_0);
Define_extern_entry(mercury____Compare___rl_analyse__gen_kill_data_0_0);
Define_extern_entry(mercury____Unify___rl_analyse__gen_kill_data_map_0_0);
Define_extern_entry(mercury____Index___rl_analyse__gen_kill_data_map_0_0);
Define_extern_entry(mercury____Compare___rl_analyse__gen_kill_data_map_0_0);
Define_extern_entry(mercury____Unify___rl_analyse__int_set_0_0);
Define_extern_entry(mercury____Index___rl_analyse__int_set_0_0);
Define_extern_entry(mercury____Compare___rl_analyse__int_set_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_data_2;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_data_map_2;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_update_3;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_confluence_2;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_direction_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_equal_2;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_gen_kill_data_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_gen_kill_data_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_int_set_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_rl_analysis_3;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_write_3;

static const struct mercury_data_rl_analyse__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_analyse__common_0;

static const struct mercury_data_rl_analyse__common_1_struct {
	Word * f1;
}  mercury_data_rl_analyse__common_1;

static const struct mercury_data_rl_analyse__common_2_struct {
	Word * f1;
}  mercury_data_rl_analyse__common_2;

static const struct mercury_data_rl_analyse__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_analyse__common_3;

static const struct mercury_data_rl_analyse__common_4_struct {
	MR_uint_least32_t f1;
	MR_uint_least32_t f2;
	MR_uint_least32_t f3;
}  mercury_data_rl_analyse__common_4;

static const struct mercury_data_rl_analyse__common_5_struct {
	Word * f1;
	Integer f2;
	Integer f3;
}  mercury_data_rl_analyse__common_5;

static const struct mercury_data_rl_analyse__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_analyse__common_6;

static const struct mercury_data_rl_analyse__common_7_struct {
	Word * f1;
	Integer f2;
}  mercury_data_rl_analyse__common_7;

static const struct mercury_data_rl_analyse__common_8_struct {
	Word * f1;
	Integer f2;
}  mercury_data_rl_analyse__common_8;

static const struct mercury_data_rl_analyse__common_9_struct {
	Word * f1;
	Word * f2;
	Integer f3;
}  mercury_data_rl_analyse__common_9;

static const struct mercury_data_rl_analyse__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_analyse__common_10;

static const struct mercury_data_rl_analyse__common_11_struct {
	Word * f1;
}  mercury_data_rl_analyse__common_11;

static const struct mercury_data_rl_analyse__common_12_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_analyse__common_12;

static const struct mercury_data_rl_analyse__common_13_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_analyse__common_13;

static const struct mercury_data_rl_analyse__common_14_struct {
	MR_uint_least32_t f1;
	MR_uint_least32_t f2;
	MR_uint_least32_t f3;
	MR_uint_least32_t f4;
}  mercury_data_rl_analyse__common_14;

static const struct mercury_data_rl_analyse__common_15_struct {
	Word * f1;
	Integer f2;
}  mercury_data_rl_analyse__common_15;

static const struct mercury_data_rl_analyse__common_16_struct {
	Word * f1;
	Integer f2;
	Integer f3;
	Integer f4;
}  mercury_data_rl_analyse__common_16;

static const struct mercury_data_rl_analyse__common_17_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Integer f14;
	Word * f15;
	Word * f16;
	Word * f17;
}  mercury_data_rl_analyse__common_17;

static const struct mercury_data_rl_analyse__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_analyse__common_18;

static const struct mercury_data_rl_analyse__common_19_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_analyse__common_19;

static const struct mercury_data_rl_analyse__common_20_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_analyse__common_20;

static const struct mercury_data_rl_analyse__common_21_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Integer f4;
	Word * f5;
	Word * f6;
}  mercury_data_rl_analyse__common_21;

static const struct mercury_data_rl_analyse__common_22_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_22;

static const struct mercury_data_rl_analyse__common_23_struct {
	Word * f1;
}  mercury_data_rl_analyse__common_23;

static const struct mercury_data_rl_analyse__common_24_struct {
	Word * f1;
	Integer f2;
}  mercury_data_rl_analyse__common_24;

static const struct mercury_data_rl_analyse__common_25_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_analyse__common_25;

static const struct mercury_data_rl_analyse__common_26_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Word * f8;
	Word * f9;
}  mercury_data_rl_analyse__common_26;

static const struct mercury_data_rl_analyse__common_27_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Integer f4;
	Word * f5;
	Word * f6;
	Integer f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_rl_analyse__common_27;

static const struct mercury_data_rl_analyse__common_28_struct {
	Word * f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
}  mercury_data_rl_analyse__common_28;

static const struct mercury_data_rl_analyse__common_29_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_rl_analyse__common_29;

static const struct mercury_data_rl_analyse__common_30_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_30;

static const struct mercury_data_rl_analyse__common_31_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_analyse__common_31;

static const struct mercury_data_rl_analyse__common_32_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_32;

static const struct mercury_data_rl_analyse__common_33_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_33;

static const struct mercury_data_rl_analyse__common_34_struct {
	Word * f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
}  mercury_data_rl_analyse__common_34;

static const struct mercury_data_rl_analyse__common_35_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_35;

static const struct mercury_data_rl_analyse__common_36_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_rl_analyse__common_36;

static const struct mercury_data_rl_analyse__common_37_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Word * f8;
	Word * f9;
}  mercury_data_rl_analyse__common_37;

static const struct mercury_data_rl_analyse__common_38_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_38;

static const struct mercury_data_rl_analyse__common_39_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_39;

static const struct mercury_data_rl_analyse__common_40_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__common_40;

static const struct mercury_data_rl_analyse__common_41_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_rl_analyse__common_41;

static const struct mercury_data_rl_analyse__type_ctor_functors_write_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_write_3;

static const struct mercury_data_rl_analyse__type_ctor_layout_write_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_write_3;

static const struct mercury_data_rl_analyse__type_ctor_functors_rl_analysis_3_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_analyse__type_ctor_functors_rl_analysis_3;

static const struct mercury_data_rl_analyse__type_ctor_layout_rl_analysis_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_rl_analysis_3;

static const struct mercury_data_rl_analyse__type_ctor_functors_int_set_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_int_set_0;

static const struct mercury_data_rl_analyse__type_ctor_layout_int_set_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_int_set_0;

static const struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_map_0;

static const struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_map_0;

static const struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_0;

static const struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_0;

static const struct mercury_data_rl_analyse__type_ctor_functors_equal_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_equal_2;

static const struct mercury_data_rl_analyse__type_ctor_layout_equal_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_equal_2;

static const struct mercury_data_rl_analyse__type_ctor_functors_direction_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_direction_0;

static const struct mercury_data_rl_analyse__type_ctor_layout_direction_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_direction_0;

static const struct mercury_data_rl_analyse__type_ctor_functors_confluence_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_confluence_2;

static const struct mercury_data_rl_analyse__type_ctor_layout_confluence_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_confluence_2;

static const struct mercury_data_rl_analyse__type_ctor_functors_block_update_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_block_update_3;

static const struct mercury_data_rl_analyse__type_ctor_layout_block_update_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_block_update_3;

static const struct mercury_data_rl_analyse__type_ctor_functors_block_data_map_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_analyse__type_ctor_functors_block_data_map_2;

static const struct mercury_data_rl_analyse__type_ctor_layout_block_data_map_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_block_data_map_2;

static const struct mercury_data_rl_analyse__type_ctor_functors_block_data_2_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_analyse__type_ctor_functors_block_data_2;

static const struct mercury_data_rl_analyse__type_ctor_layout_block_data_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_analyse__type_ctor_layout_block_data_2;

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_data_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___rl_analyse__block_data_2_0),
	ENTRY(mercury____Index___rl_analyse__block_data_2_0),
	ENTRY(mercury____Compare___rl_analyse__block_data_2_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_block_data_2,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_block_data_2,
	MR_string_const("rl_analyse", 10),
	MR_string_const("block_data", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_data_map_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___rl_analyse__block_data_map_2_0),
	ENTRY(mercury____Index___rl_analyse__block_data_map_2_0),
	ENTRY(mercury____Compare___rl_analyse__block_data_map_2_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_block_data_map_2,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_block_data_map_2,
	MR_string_const("rl_analyse", 10),
	MR_string_const("block_data_map", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_block_update_3 = {
	(Integer) 3,
	ENTRY(mercury____Unify___rl_analyse__block_update_3_0),
	ENTRY(mercury____Index___rl_analyse__block_update_3_0),
	ENTRY(mercury____Compare___rl_analyse__block_update_3_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_block_update_3,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_block_update_3,
	MR_string_const("rl_analyse", 10),
	MR_string_const("block_update", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_confluence_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___rl_analyse__confluence_2_0),
	ENTRY(mercury____Index___rl_analyse__confluence_2_0),
	ENTRY(mercury____Compare___rl_analyse__confluence_2_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_confluence_2,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_confluence_2,
	MR_string_const("rl_analyse", 10),
	MR_string_const("confluence", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_direction_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_analyse__direction_0_0),
	ENTRY(mercury____Index___rl_analyse__direction_0_0),
	ENTRY(mercury____Compare___rl_analyse__direction_0_0),
	(Integer) 0,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_direction_0,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_direction_0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("direction", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_equal_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___rl_analyse__equal_2_0),
	ENTRY(mercury____Index___rl_analyse__equal_2_0),
	ENTRY(mercury____Compare___rl_analyse__equal_2_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_equal_2,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_equal_2,
	MR_string_const("rl_analyse", 10),
	MR_string_const("equal", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_gen_kill_data_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_analyse__gen_kill_data_0_0),
	ENTRY(mercury____Index___rl_analyse__gen_kill_data_0_0),
	ENTRY(mercury____Compare___rl_analyse__gen_kill_data_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_0,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("gen_kill_data", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_gen_kill_data_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_analyse__gen_kill_data_map_0_0),
	ENTRY(mercury____Index___rl_analyse__gen_kill_data_map_0_0),
	ENTRY(mercury____Compare___rl_analyse__gen_kill_data_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_map_0,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_map_0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("gen_kill_data_map", 17),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_int_set_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_analyse__int_set_0_0),
	ENTRY(mercury____Index___rl_analyse__int_set_0_0),
	ENTRY(mercury____Compare___rl_analyse__int_set_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_int_set_0,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_int_set_0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("int_set", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_rl_analysis_3 = {
	(Integer) 3,
	ENTRY(mercury____Unify___rl_analyse__rl_analysis_3_0),
	ENTRY(mercury____Index___rl_analyse__rl_analysis_3_0),
	ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_rl_analysis_3,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_rl_analysis_3,
	MR_string_const("rl_analyse", 10),
	MR_string_const("rl_analysis", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_analyse__type_ctor_info_write_3 = {
	(Integer) 3,
	ENTRY(mercury____Unify___rl_analyse__write_3_0),
	ENTRY(mercury____Index___rl_analyse__write_3_0),
	ENTRY(mercury____Compare___rl_analyse__write_3_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_analyse__type_ctor_functors_write_3,
	(Word *) &mercury_data_rl_analyse__type_ctor_layout_write_3,
	MR_string_const("rl_analyse", 10),
	MR_string_const("write", 5),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_relation__type_ctor_info_relation_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_rl_analyse__common_0_struct mercury_data_rl_analyse__common_0 = {
	(Word *) &mercury_data_relation__type_ctor_info_relation_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_relation__type_ctor_info_relation_key_0;
static const struct mercury_data_rl_analyse__common_1_struct mercury_data_rl_analyse__common_1 = {
	(Word *) &mercury_data_relation__type_ctor_info_relation_key_0
};

static const struct mercury_data_rl_analyse__common_2_struct mercury_data_rl_analyse__common_2 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_analyse__common_3_struct mercury_data_rl_analyse__common_3 = {
	(Integer) 0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("rl_analyse", 10),
	MR_string_const("IntroducedFrom__pred__blocks__171__1", 36),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_2)
};

static const struct mercury_data_rl_analyse__common_4_struct mercury_data_rl_analyse__common_4 = {
	2,
	32,
	48
};

static const struct mercury_data_rl_analyse__common_5_struct mercury_data_rl_analyse__common_5 = {
	(Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2,
	(Integer) 1,
	(Integer) 2
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_rl_analyse__common_6_struct mercury_data_rl_analyse__common_6 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_private_builtin__type_ctor_info_type_info_1;
static const struct mercury_data_rl_analyse__common_7_struct mercury_data_rl_analyse__common_7 = {
	(Word *) &mercury_data_private_builtin__type_ctor_info_type_info_1,
	(Integer) 1
};

static const struct mercury_data_rl_analyse__common_8_struct mercury_data_rl_analyse__common_8 = {
	(Word *) &mercury_data_private_builtin__type_ctor_info_type_info_1,
	(Integer) 2
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_rl_analyse__common_9_struct mercury_data_rl_analyse__common_9 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Integer) 1
};

static const struct mercury_data_rl_analyse__common_10_struct mercury_data_rl_analyse__common_10 = {
	(Integer) 0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("rl_analyse", 10),
	MR_string_const("IntroducedFrom__pred__blocks__175__2", 36),
	5,
	0,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_4),
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_9)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_analyse__common_11_struct mercury_data_rl_analyse__common_11 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_analyse__common_12_struct mercury_data_rl_analyse__common_12 = {
	(Integer) 0,
	MR_string_const("io", 2),
	MR_string_const("io", 2),
	MR_string_const("write_int", 9),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_11)
};

Declare_entry(mercury__io__write_int_3_0);
static const struct mercury_data_rl_analyse__common_13_struct mercury_data_rl_analyse__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_12),
	ENTRY(mercury__io__write_int_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_analyse__common_14_struct mercury_data_rl_analyse__common_14 = {
	3,
	16,
	32,
	48
};

static const struct mercury_data_rl_analyse__common_15_struct mercury_data_rl_analyse__common_15 = {
	(Word *) &mercury_data_private_builtin__type_ctor_info_type_info_1,
	(Integer) 3
};

static const struct mercury_data_rl_analyse__common_16_struct mercury_data_rl_analyse__common_16 = {
	(Word *) &mercury_data_rl_analyse__type_ctor_info_rl_analysis_3,
	(Integer) 1,
	(Integer) 2,
	(Integer) 3
};

static const struct mercury_data_rl_analyse__common_17_struct mercury_data_rl_analyse__common_17 = {
	(Integer) 0,
	MR_string_const("rl_analyse", 10),
	MR_string_const("rl_analyse", 10),
	MR_string_const("dump_block_data", 15),
	6,
	0,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_14),
	9,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_15),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_16),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_6),
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_11)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_rl_analyse__common_18_struct mercury_data_rl_analyse__common_18 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_analyse__common_19_struct mercury_data_rl_analyse__common_19 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18)
};

static const struct mercury_data_rl_analyse__common_20_struct mercury_data_rl_analyse__common_20 = {
	(Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_19)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_pred_0;
static const struct mercury_data_rl_analyse__common_21_struct mercury_data_rl_analyse__common_21 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_5),
	(Integer) 3,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_analyse__common_22_struct mercury_data_rl_analyse__common_22 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_21)
};

static const struct mercury_data_rl_analyse__common_23_struct mercury_data_rl_analyse__common_23 = {
	(Word *) &mercury_data_rl_analyse__type_ctor_info_direction_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_rl_analyse__common_24_struct mercury_data_rl_analyse__common_24 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Integer) 1
};

static const struct mercury_data_rl_analyse__common_25_struct mercury_data_rl_analyse__common_25 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_24)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl_block__type_ctor_info_rl_opt_info_0;
static const struct mercury_data_rl_analyse__common_26_struct mercury_data_rl_analyse__common_26 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_25),
	(Integer) 1,
	(Integer) 3,
	(Integer) 3,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0
};

static const struct mercury_data_rl_analyse__common_27_struct mercury_data_rl_analyse__common_27 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 8,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_5),
	(Integer) 3,
	(Integer) 3,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0
};

static const struct mercury_data_rl_analyse__common_28_struct mercury_data_rl_analyse__common_28 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 3,
	(Integer) 1,
	(Integer) 1,
	(Integer) 3
};

static const struct mercury_data_rl_analyse__common_29_struct mercury_data_rl_analyse__common_29 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_27),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_28),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_21),
	MR_string_const("rl_analysis", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_analyse__common_30_struct mercury_data_rl_analyse__common_30 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18)
};

static const struct mercury_data_rl_analyse__common_31_struct mercury_data_rl_analyse__common_31 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20)
};

static const struct mercury_data_rl_analyse__common_32_struct mercury_data_rl_analyse__common_32 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_31)
};

static const struct mercury_data_rl_analyse__common_33_struct mercury_data_rl_analyse__common_33 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20)
};

static const struct mercury_data_rl_analyse__common_34_struct mercury_data_rl_analyse__common_34 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 3,
	(Integer) 1,
	(Integer) 1,
	(Integer) 2
};

static const struct mercury_data_rl_analyse__common_35_struct mercury_data_rl_analyse__common_35 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_34)
};

static const struct mercury_data_rl_analyse__common_36_struct mercury_data_rl_analyse__common_36 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("forward", 7),
	MR_string_const("backward", 8)
};

static const struct mercury_data_rl_analyse__common_37_struct mercury_data_rl_analyse__common_37 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_25),
	(Integer) 1,
	(Integer) 2,
	(Integer) 2,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0,
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0
};

static const struct mercury_data_rl_analyse__common_38_struct mercury_data_rl_analyse__common_38 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_37)
};

static const struct mercury_data_rl_analyse__common_39_struct mercury_data_rl_analyse__common_39 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_27)
};

static const struct mercury_data_rl_analyse__common_40_struct mercury_data_rl_analyse__common_40 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_6)
};

static const struct mercury_data_rl_analyse__common_41_struct mercury_data_rl_analyse__common_41 = {
	(Integer) 3,
	(Integer) 1,
	(Integer) 1,
	(Integer) 2,
	MR_string_const("block_data", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_analyse__type_ctor_functors_write_3_struct mercury_data_rl_analyse__type_ctor_functors_write_3 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_21)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_write_3_struct mercury_data_rl_analyse__type_ctor_layout_write_3 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_22),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_22)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_rl_analysis_3_struct mercury_data_rl_analyse__type_ctor_functors_rl_analysis_3 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_29)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_rl_analysis_3_struct mercury_data_rl_analyse__type_ctor_layout_rl_analysis_3 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_analyse__common_29),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_analyse__type_ctor_functors_int_set_0_struct mercury_data_rl_analyse__type_ctor_functors_int_set_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_int_set_0_struct mercury_data_rl_analyse__type_ctor_layout_int_set_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_30)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_map_0_struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_31)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_map_0_struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_32)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_0_struct mercury_data_rl_analyse__type_ctor_functors_gen_kill_data_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_0_struct mercury_data_rl_analyse__type_ctor_layout_gen_kill_data_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_33)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_equal_2_struct mercury_data_rl_analyse__type_ctor_functors_equal_2 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_34)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_equal_2_struct mercury_data_rl_analyse__type_ctor_layout_equal_2 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_35),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_35),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_35),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_35)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_direction_0_struct mercury_data_rl_analyse__type_ctor_functors_direction_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_36)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_direction_0_struct mercury_data_rl_analyse__type_ctor_layout_direction_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_36),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_36),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_36),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_36)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_confluence_2_struct mercury_data_rl_analyse__type_ctor_functors_confluence_2 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_37)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_confluence_2_struct mercury_data_rl_analyse__type_ctor_layout_confluence_2 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_38),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_38),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_38),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_38)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_block_update_3_struct mercury_data_rl_analyse__type_ctor_functors_block_update_3 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_27)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_block_update_3_struct mercury_data_rl_analyse__type_ctor_layout_block_update_3 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_39),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_39),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_39),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_39)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_block_data_map_2_struct mercury_data_rl_analyse__type_ctor_functors_block_data_map_2 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_6)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_block_data_map_2_struct mercury_data_rl_analyse__type_ctor_layout_block_data_map_2 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_analyse__common_40)
};

static const struct mercury_data_rl_analyse__type_ctor_functors_block_data_2_struct mercury_data_rl_analyse__type_ctor_functors_block_data_2 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_41)
};

static const struct mercury_data_rl_analyse__type_ctor_layout_block_data_2_struct mercury_data_rl_analyse__type_ctor_layout_block_data_2 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_analyse__common_41),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);

BEGIN_MODULE(rl_analyse_module0)
	init_entry(mercury__rl_analyse__do_io__ho3__ua0_3_0);
	init_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i2);
	init_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i3);
BEGIN_CODE

/* code for predicate 'do_io__ho3__ua0'/3 in mode 0 */
Define_static(mercury__rl_analyse__do_io__ho3__ua0_3_0);
	MR_incr_sp_push_msg(6, "rl_analyse:do_io__ho3__ua0/3");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(5) = r2;
	r2 = r1;
	r1 = (Integer) 28;
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__do_io__ho3__ua0_3_0_i2,
		STATIC(mercury__rl_analyse__do_io__ho3__ua0_3_0));
Define_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__do_io__ho3__ua0_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__do_io__ho3__ua0_3_0_i3);
	r6 = r2;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0),
		STATIC(mercury__rl_analyse__do_io__ho3__ua0_3_0));
Define_label(mercury__rl_analyse__do_io__ho3__ua0_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module1)
	init_entry(mercury____Index___rl_analyse__gen_kill_data_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_analyse__gen_kill_data_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_analyse__gen_kill_data_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module2)
	init_entry(mercury____Index___rl_analyse__block_data_2__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_analyse__block_data_2__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_analyse__block_data_2__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module3)
	init_entry(mercury____Index___rl_analyse__rl_analysis_3__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_analyse__rl_analysis_3__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_analyse__rl_analysis_3__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__do_call_closure);

BEGIN_MODULE(rl_analyse_module4)
	init_entry(mercury__rl_analyse__equal__ua0_4_0);
BEGIN_CODE

/* code for predicate 'equal__ua0'/4 in mode 0 */
Define_static(mercury__rl_analyse__equal__ua0_4_0);
	r6 = r4;
	r4 = r2;
	r5 = r3;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = (Integer) 3;
	r3 = (Integer) 0;
	tailcall(ENTRY(mercury__do_call_closure),
		STATIC(mercury__rl_analyse__equal__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module5)
	init_entry(mercury__rl_analyse__block_update__ua0_9_0);
BEGIN_CODE

/* code for predicate 'block_update__ua0'/9 in mode 0 */
Define_static(mercury__rl_analyse__block_update__ua0_9_0);
	r7 = r5;
	r8 = r6;
	r6 = r4;
	r4 = r2;
	r5 = r3;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r2 = (Integer) 5;
	r3 = (Integer) 3;
	tailcall(ENTRY(mercury__do_call_closure),
		STATIC(mercury__rl_analyse__block_update__ua0_9_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module6)
	init_entry(mercury__rl_analyse__direction__ua0_2_0);
BEGIN_CODE

/* code for predicate 'direction__ua0'/2 in mode 0 */
Define_static(mercury__rl_analyse__direction__ua0_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module7)
	init_entry(mercury__rl_analyse__confluence_list__ua0_8_0);
	init_label(mercury__rl_analyse__confluence_list__ua0_8_0_i1001);
	init_label(mercury__rl_analyse__confluence_list__ua0_8_0_i4);
	init_label(mercury__rl_analyse__confluence_list__ua0_8_0_i3);
BEGIN_CODE

/* code for predicate 'confluence_list__ua0'/8 in mode 0 */
Define_static(mercury__rl_analyse__confluence_list__ua0_8_0);
	MR_incr_sp_push_msg(4, "rl_analyse:confluence_list__ua0/8");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__rl_analyse__confluence_list__ua0_8_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_analyse__confluence_list__ua0_8_0_i3);
	r6 = r4;
	r7 = r5;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = (Integer) 4;
	r3 = (Integer) 3;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_analyse__confluence_list__ua0_8_0_i4,
		STATIC(mercury__rl_analyse__confluence_list__ua0_8_0));
Define_label(mercury__rl_analyse__confluence_list__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__confluence_list__ua0_8_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r5 = r2;
	r2 = MR_stackvar(2);
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_analyse__confluence_list__ua0_8_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_analyse__confluence_list__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r4 = r5;
	r5 = r6;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__rl_analyse__confluence_list__ua0_8_0_i1001);
	}
Define_label(mercury__rl_analyse__confluence_list__ua0_8_0_i3);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(rl_analyse_module8)
	init_entry(mercury__rl_analyse__dump_changed_data__ua0_7_0);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i2);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i3);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i4);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i5);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i6);
	init_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i7);
BEGIN_CODE

/* code for predicate 'dump_changed_data__ua0'/7 in mode 0 */
Define_static(mercury__rl_analyse__dump_changed_data__ua0_7_0);
	MR_incr_sp_push_msg(6, "rl_analyse:dump_changed_data__ua0/7");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const("Changed data for block ", 23);
	r2 = r6;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i2,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i3,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i4,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	r6 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 4);
	r2 = (Integer) 3;
	r3 = (Integer) 1;
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i5,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t==> ", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i6,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 4);
	r2 = (Integer) 3;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_analyse__dump_changed_data__ua0_7_0_i7,
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
Define_label(mercury__rl_analyse__dump_changed_data__ua0_7_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_changed_data__ua0_7_0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__rl_analyse__dump_changed_data__ua0_7_0));
END_MODULE

Declare_entry(mercury__map__lookup_3_0);

BEGIN_MODULE(rl_analyse_module9)
	init_entry(mercury__rl_analyse__dump_block_data__ua0_6_0);
	init_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i2);
	init_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i3);
	init_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i4);
	init_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i5);
	init_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i6);
BEGIN_CODE

/* code for predicate 'dump_block_data__ua0'/6 in mode 0 */
Define_static(mercury__rl_analyse__dump_block_data__ua0_6_0);
	MR_incr_sp_push_msg(5, "rl_analyse:dump_block_data__ua0/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__rl_analyse__dump_block_data__ua0_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	r3 = r4;
	r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r6;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_analyse__dump_block_data__ua0_6_0_i2,
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
	}
Define_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data__ua0_6_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("Block ", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__dump_block_data__ua0_6_0_i3,
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
Define_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data__ua0_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_analyse__dump_block_data__ua0_6_0_i4,
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
Define_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data__ua0_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__dump_block_data__ua0_6_0_i5,
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
Define_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data__ua0_6_0));
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(2);
	r6 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 4);
	r2 = (Integer) 3;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_analyse__dump_block_data__ua0_6_0_i6,
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
Define_label(mercury__rl_analyse__dump_block_data__ua0_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data__ua0_6_0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0));
END_MODULE

Declare_entry(mercury__rl_block__rl_opt_info_get_flow_graph_3_0);
Declare_entry(mercury__relation__lookup_element_3_0);
Declare_entry(mercury__relation__lookup_to_3_0);
Declare_entry(mercury__relation__lookup_from_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(rl_analyse_module10)
	init_entry(mercury__rl_analyse__blocks__ua0_12_0);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i1004);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i4);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i5);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i6);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i8);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i10);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i11);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i12);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i13);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i14);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i15);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i17);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i16);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i18);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i19);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i22);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i20);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i24);
	init_label(mercury__rl_analyse__blocks__ua0_12_0_i3);
BEGIN_CODE

/* code for predicate 'blocks__ua0'/12 in mode 0 */
Define_static(mercury__rl_analyse__blocks__ua0_12_0);
	MR_incr_sp_push_msg(13, "rl_analyse:blocks__ua0/12");
	MR_stackvar(13) = (Word) MR_succip;
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i1004);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i3);
	MR_stackvar(11) = r1;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = r9;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r8;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_flow_graph_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i4,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	MR_stackvar(10) = r2;
	r2 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__relation__lookup_element_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i5,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_analyse__direction__ua0_2_0),
		mercury__rl_analyse__blocks__ua0_12_0_i6,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i8);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__relation__lookup_to_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i10,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i8);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(9);
	call_localret(ENTRY(mercury__relation__lookup_from_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i10,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_analyse__blocks__ua0_12_0_i11,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_analyse__blocks__ua0_12_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_analyse__IntroducedFrom__pred__blocks__171__1_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i12,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__rl_analyse__blocks__ua0_12_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i13,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	r4 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__rl_analyse__blocks__ua0_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(11);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_std_util__type_ctor_info_pair_2;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_analyse__blocks__ua0_12_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_10);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(12);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i14,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_analyse__blocks__ua0_12_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(10);
	call_localret(STATIC(mercury__rl_analyse__confluence_list__ua0_8_0),
		mercury__rl_analyse__blocks__ua0_12_0_i15,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i17);
	r5 = r2;
	r6 = r3;
	r4 = MR_stackvar(8);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i16);
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i17);
	r5 = r2;
	r6 = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i16);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = r2;
	MR_stackvar(8) = r4;
	call_localret(STATIC(mercury__rl_analyse__block_update__ua0_9_0),
		mercury__rl_analyse__blocks__ua0_12_0_i18,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	r4 = MR_stackvar(2);
	r5 = r1;
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(4) = r2;
	MR_stackvar(10) = r3;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__rl_analyse__blocks__ua0_12_0, "origin_lost_in_value_number");
	r3 = r4;
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__rl_analyse__blocks__ua0_12_0_i19,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	MR_stackvar(9) = r1;
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(8), (Integer) 1);
	r1 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_analyse__equal__ua0_4_0),
		mercury__rl_analyse__blocks__ua0_12_0_i22,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i20);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	r7 = MR_stackvar(4);
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(3);
	r8 = MR_stackvar(5);
	r9 = MR_stackvar(10);
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i1004);
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i20);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_analyse__do_io__ho3__ua0_3_0),
		mercury__rl_analyse__blocks__ua0_12_0_i24,
		STATIC(mercury__rl_analyse__blocks__ua0_12_0));
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_analyse__blocks__ua0_12_0));
	r8 = r1;
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(9);
	r6 = (Integer) 1;
	r7 = MR_stackvar(4);
	r9 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(13);
	GOTO_LABEL(mercury__rl_analyse__blocks__ua0_12_0_i1004);
Define_label(mercury__rl_analyse__blocks__ua0_12_0_i3);
	r1 = r5;
	r2 = r6;
	r3 = r7;
	r4 = r8;
	r5 = r9;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module11)
	init_entry(mercury__rl_analyse__to_fixpoint__ua0_10_0);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i1003);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i2);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i5);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i3);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i6);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i7);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i8);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i11);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i14);
	init_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i12);
BEGIN_CODE

/* code for predicate 'to_fixpoint__ua0'/10 in mode 0 */
Define_static(mercury__rl_analyse__to_fixpoint__ua0_10_0);
	MR_incr_sp_push_msg(8, "rl_analyse:to_fixpoint__ua0/10");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i1003);
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	r1 = (Integer) 28;
	r2 = r7;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r8;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__to_fixpoint__ua0_10_0_i2,
		STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0));
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0_i3);
	r1 = (Word) MR_string_const("rl_analyse: starting new pass\n", 30);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__to_fixpoint__ua0_10_0_i5,
		STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0));
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0));
	r8 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = (Integer) 0;
	r7 = MR_stackvar(4);
	r9 = MR_stackvar(5);
	GOTO_LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0_i6);
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i3);
	r8 = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = (Integer) 0;
	r7 = MR_stackvar(4);
	r9 = MR_stackvar(5);
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i6);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	call_localret(STATIC(mercury__rl_analyse__blocks__ua0_12_0),
		mercury__rl_analyse__to_fixpoint__ua0_10_0_i7,
		STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0));
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0));
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0_i8);
	r8 = r5;
	r5 = r1;
	r6 = r3;
	r7 = r4;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0_i1003);
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i8);
	MR_stackvar(1) = r1;
	r1 = (Integer) 28;
	r2 = r4;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__to_fixpoint__ua0_10_0_i11,
		STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0));
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0_i12);
	r1 = (Word) MR_string_const("finished iterating\n", 19);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__to_fixpoint__ua0_10_0_i14,
		STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0));
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_analyse__to_fixpoint__ua0_10_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_analyse__to_fixpoint__ua0_10_0_i12);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_list_5_0);

BEGIN_MODULE(rl_analyse_module12)
	init_entry(mercury__rl_analyse__write_gen_kill_data__ua0_4_0);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i2);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i3);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i4);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i5);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i6);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i7);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i8);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i9);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i10);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i11);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i12);
	init_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i13);
BEGIN_CODE

/* code for predicate 'write_gen_kill_data__ua0'/4 in mode 0 */
Define_static(mercury__rl_analyse__write_gen_kill_data__ua0_4_0);
	MR_incr_sp_push_msg(5, "rl_analyse:write_gen_kill_data__ua0/4");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_string_const("<gen: [", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i2,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i3,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_13);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i4,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("] kill: [", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i5,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i6,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_13);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i7,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("] in: [", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i8,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i9,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_13);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i10,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("] out: [", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i11,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i12,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_13);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i13,
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
Define_label(mercury__rl_analyse__write_gen_kill_data__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]>\n", 3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module13)
	init_entry(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0);
	init_label(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__blocks__175__2'/5 in mode 0 */
Define_static(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0);
	MR_incr_sp_push_msg(2, "rl_analyse:IntroducedFrom__pred__blocks__175__2/5");
	MR_stackvar(2) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r3;
	r2 = MR_tempr1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0_i2,
		STATIC(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0));
	}
Define_label(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_analyse__IntroducedFrom__pred__blocks__175__2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__relation__lookup_key_3_0);

BEGIN_MODULE(rl_analyse_module14)
	init_entry(mercury__rl_analyse__IntroducedFrom__pred__blocks__171__1_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__blocks__171__1'/3 in mode 0 */
Define_static(mercury__rl_analyse__IntroducedFrom__pred__blocks__171__1_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__relation__lookup_key_3_0),
		STATIC(mercury__rl_analyse__IntroducedFrom__pred__blocks__171__1_3_0));
END_MODULE

Declare_entry(mercury__rl_block__rl_opt_info_get_rev_block_order_3_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__io__format_4_0);

BEGIN_MODULE(rl_analyse_module15)
	init_entry(mercury__rl_analyse__rl_analyse_10_0);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i2);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i3);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i4);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i7);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i5);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i9);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i12);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i10);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i13);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i14);
	init_label(mercury__rl_analyse__rl_analyse_10_0_i15);
BEGIN_CODE

/* code for predicate 'rl_analyse'/10 in mode 0 */
Define_entry(mercury__rl_analyse__rl_analyse_10_0);
	MR_incr_sp_push_msg(12, "rl_analyse:rl_analyse/10");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(7) = r1;
	r1 = r9;
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = r8;
	MR_stackvar(8) = r2;
	MR_stackvar(9) = r3;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_rev_block_order_3_0),
		mercury__rl_analyse__rl_analyse_10_0_i2,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	MR_stackvar(6) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_analyse__rl_analyse_10_0_i3,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Integer) 28;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__rl_analyse_10_0_i4,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__rl_analyse_10_0_i5);
	r1 = (Word) MR_string_const("Initial info\n", 13);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__io__format_4_0),
		mercury__rl_analyse__rl_analyse_10_0_i7,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 9, mercury__rl_analyse__rl_analyse_10_0, "origin_lost_in_value_number");
	r2 = r1;
	MR_stackvar(11) = r3;
	r1 = (Integer) 28;
	MR_stackvar(10) = (Word) MR_string_const("\n", 1);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 6;
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_analyse__dump_block_data_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_17);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(4);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__rl_analyse_10_0_i9,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i5);
	MR_stackvar(10) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 9, mercury__rl_analyse__rl_analyse_10_0, "origin_lost_in_value_number");
	MR_stackvar(11) = r3;
	r1 = (Integer) 28;
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 6;
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_analyse__dump_block_data_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_17);
	MR_field(MR_mktag(0), r3, (Integer) 8) = MR_stackvar(4);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__rl_analyse_10_0_i9,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__rl_analyse_10_0_i10);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(10);
	r4 = MR_stackvar(11);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_analyse__rl_analyse_10_0_i12,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	r7 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r8 = MR_stackvar(6);
	GOTO_LABEL(mercury__rl_analyse__rl_analyse_10_0_i13);
Define_label(mercury__rl_analyse__rl_analyse_10_0_i10);
	r7 = r2;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r8 = MR_stackvar(6);
Define_label(mercury__rl_analyse__rl_analyse_10_0_i13);
	MR_stackvar(2) = r3;
	MR_stackvar(7) = r1;
	MR_stackvar(8) = r2;
	call_localret(STATIC(mercury__rl_analyse__to_fixpoint__ua0_10_0),
		mercury__rl_analyse__rl_analyse_10_0_i14,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	MR_stackvar(3) = r4;
	r4 = MR_stackvar(2);
	r6 = r1;
	r7 = r2;
	r8 = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(9);
	r5 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_analyse__dump_block_data_map_6_0),
		mercury__rl_analyse__rl_analyse_10_0_i15,
		ENTRY(mercury__rl_analyse__rl_analyse_10_0));
Define_label(mercury__rl_analyse__rl_analyse_10_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_analyse__rl_analyse_10_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module16)
	init_entry(mercury__rl_analyse__write_gen_kill_data_4_0);
BEGIN_CODE

/* code for predicate 'write_gen_kill_data'/4 in mode 0 */
Define_entry(mercury__rl_analyse__write_gen_kill_data_4_0);
	r1 = r2;
	r2 = r4;
	tailcall(STATIC(mercury__rl_analyse__write_gen_kill_data__ua0_4_0),
		ENTRY(mercury__rl_analyse__write_gen_kill_data_4_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module17)
	init_entry(mercury__rl_analyse__dump_block_data_map_6_0);
	init_label(mercury__rl_analyse__dump_block_data_map_6_0_i2);
	init_label(mercury__rl_analyse__dump_block_data_map_6_0_i3);
BEGIN_CODE

/* code for predicate 'dump_block_data_map'/6 in mode 0 */
Define_static(mercury__rl_analyse__dump_block_data_map_6_0);
	MR_incr_sp_push_msg(3, "rl_analyse:dump_block_data_map/6");
	MR_stackvar(3) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 9, mercury__rl_analyse__dump_block_data_map_6_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	r1 = (Integer) 28;
	r2 = r8;
	MR_stackvar(1) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 7) = r6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_analyse__dump_block_data_6_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_17);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 8) = r7;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_analyse__dump_block_data_map_6_0_i2,
		STATIC(mercury__rl_analyse__dump_block_data_map_6_0));
	}
Define_label(mercury__rl_analyse__dump_block_data_map_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_analyse__dump_block_data_map_6_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_analyse__dump_block_data_map_6_0_i3);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const("\n", 1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_list_5_0),
		STATIC(mercury__rl_analyse__dump_block_data_map_6_0));
Define_label(mercury__rl_analyse__dump_block_data_map_6_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module18)
	init_entry(mercury__rl_analyse__dump_block_data_6_0);
BEGIN_CODE

/* code for predicate 'dump_block_data'/6 in mode 0 */
Define_static(mercury__rl_analyse__dump_block_data_6_0);
	r3 = r4;
	r4 = r5;
	r5 = r6;
	r6 = r7;
	r7 = r8;
	tailcall(STATIC(mercury__rl_analyse__dump_block_data__ua0_6_0),
		STATIC(mercury__rl_analyse__dump_block_data_6_0));
END_MODULE

Declare_entry(mercury__builtin_unify_pred_2_0);

BEGIN_MODULE(rl_analyse_module19)
	init_entry(mercury____Unify___rl_analyse__rl_analysis_3_0);
	init_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i2);
	init_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i4);
	init_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i6);
	init_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1005);
	init_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__rl_analysis_3_0);
	MR_incr_sp_push_msg(7, "rl_analyse:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), r4, (Integer) 0) != r3))
		GOTO_LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0_i1005);
	r2 = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r5, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r5, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r4, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___rl_analyse__rl_analysis_3_0_i2,
		ENTRY(mercury____Unify___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___rl_analyse__rl_analysis_3_0_i4,
		ENTRY(mercury____Unify___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__builtin_unify_pred_2_0),
		mercury____Unify___rl_analyse__rl_analysis_3_0_i6,
		ENTRY(mercury____Unify___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1005);
	r1 = FALSE;
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury____Unify___rl_analyse__rl_analysis_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module20)
	init_entry(mercury____Index___rl_analyse__rl_analysis_3_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__rl_analysis_3_0);
	tailcall(STATIC(mercury____Index___rl_analyse__rl_analysis_3__ua0_2_0),
		ENTRY(mercury____Index___rl_analyse__rl_analysis_3_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury__builtin_compare_pred_3_0);

BEGIN_MODULE(rl_analyse_module21)
	init_entry(mercury____Compare___rl_analyse__rl_analysis_3_0);
	init_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i3);
	init_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i7);
	init_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i11);
	init_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i15);
	init_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__rl_analysis_3_0);
	MR_incr_sp_push_msg(9, "rl_analyse:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r5, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r5, (Integer) 4);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_analyse__rl_analysis_3_0_i3,
		ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___rl_analyse__rl_analysis_3_0_i7,
		ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___rl_analyse__rl_analysis_3_0_i11,
		ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__builtin_compare_pred_3_0),
		mercury____Compare___rl_analyse__rl_analysis_3_0_i15,
		ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_analyse__rl_analysis_3_0));
Define_label(mercury____Compare___rl_analyse__rl_analysis_3_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(rl_analyse_module22)
	init_entry(mercury____Unify___rl_analyse__block_data_map_2_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__block_data_map_2_0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury____Unify___rl_analyse__block_data_map_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___rl_analyse__block_data_map_2_0));
	}
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(rl_analyse_module23)
	init_entry(mercury____Index___rl_analyse__block_data_map_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__block_data_map_2_0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury____Index___rl_analyse__block_data_map_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___rl_analyse__block_data_map_2_0));
	}
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(rl_analyse_module24)
	init_entry(mercury____Compare___rl_analyse__block_data_map_2_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__block_data_map_2_0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury____Compare___rl_analyse__block_data_map_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) (Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___rl_analyse__block_data_map_2_0));
	}
END_MODULE

Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(rl_analyse_module25)
	init_entry(mercury____Unify___rl_analyse__block_data_2_0);
	init_label(mercury____Unify___rl_analyse__block_data_2_0_i2);
	init_label(mercury____Unify___rl_analyse__block_data_2_0_i4);
	init_label(mercury____Unify___rl_analyse__block_data_2_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__block_data_2_0);
	MR_incr_sp_push_msg(7, "rl_analyse:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(6) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___rl_analyse__block_data_2_0_i2,
		ENTRY(mercury____Unify___rl_analyse__block_data_2_0));
Define_label(mercury____Unify___rl_analyse__block_data_2_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__block_data_2_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__block_data_2_0_i1);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___rl_analyse__block_data_2_0_i4,
		ENTRY(mercury____Unify___rl_analyse__block_data_2_0));
Define_label(mercury____Unify___rl_analyse__block_data_2_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__block_data_2_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__block_data_2_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___rl_analyse__block_data_2_0));
Define_label(mercury____Unify___rl_analyse__block_data_2_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module26)
	init_entry(mercury____Index___rl_analyse__block_data_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__block_data_2_0);
	tailcall(STATIC(mercury____Index___rl_analyse__block_data_2__ua0_2_0),
		ENTRY(mercury____Index___rl_analyse__block_data_2_0));
END_MODULE

Declare_entry(mercury__compare_3_3);

BEGIN_MODULE(rl_analyse_module27)
	init_entry(mercury____Compare___rl_analyse__block_data_2_0);
	init_label(mercury____Compare___rl_analyse__block_data_2_0_i3);
	init_label(mercury____Compare___rl_analyse__block_data_2_0_i7);
	init_label(mercury____Compare___rl_analyse__block_data_2_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__block_data_2_0);
	MR_incr_sp_push_msg(7, "rl_analyse:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(6) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___rl_analyse__block_data_2_0_i3,
		ENTRY(mercury____Compare___rl_analyse__block_data_2_0));
Define_label(mercury____Compare___rl_analyse__block_data_2_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__block_data_2_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__block_data_2_0_i12);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__compare_3_3),
		mercury____Compare___rl_analyse__block_data_2_0_i7,
		ENTRY(mercury____Compare___rl_analyse__block_data_2_0));
Define_label(mercury____Compare___rl_analyse__block_data_2_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_analyse__block_data_2_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_analyse__block_data_2_0_i12);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__compare_3_3),
		ENTRY(mercury____Compare___rl_analyse__block_data_2_0));
Define_label(mercury____Compare___rl_analyse__block_data_2_0_i12);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module28)
	init_entry(mercury____Unify___rl_analyse__direction_0_0);
	init_label(mercury____Unify___rl_analyse__direction_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__direction_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___rl_analyse__direction_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_analyse__direction_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module29)
	init_entry(mercury____Index___rl_analyse__direction_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__direction_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module30)
	init_entry(mercury____Compare___rl_analyse__direction_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__direction_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_analyse__direction_0_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module31)
	init_entry(mercury____Unify___rl_analyse__confluence_2_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__confluence_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_analyse__confluence_2_0));
END_MODULE

Declare_entry(mercury__builtin_index_pred_2_0);

BEGIN_MODULE(rl_analyse_module32)
	init_entry(mercury____Index___rl_analyse__confluence_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__confluence_2_0);
	r1 = r3;
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___rl_analyse__confluence_2_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module33)
	init_entry(mercury____Compare___rl_analyse__confluence_2_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__confluence_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_analyse__confluence_2_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module34)
	init_entry(mercury____Unify___rl_analyse__block_update_3_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__block_update_3_0);
	r1 = r4;
	r2 = r5;
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_analyse__block_update_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module35)
	init_entry(mercury____Index___rl_analyse__block_update_3_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__block_update_3_0);
	r1 = r4;
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___rl_analyse__block_update_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module36)
	init_entry(mercury____Compare___rl_analyse__block_update_3_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__block_update_3_0);
	r1 = r4;
	r2 = r5;
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_analyse__block_update_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module37)
	init_entry(mercury____Unify___rl_analyse__equal_2_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__equal_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_analyse__equal_2_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module38)
	init_entry(mercury____Index___rl_analyse__equal_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__equal_2_0);
	r1 = r3;
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___rl_analyse__equal_2_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module39)
	init_entry(mercury____Compare___rl_analyse__equal_2_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__equal_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_analyse__equal_2_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module40)
	init_entry(mercury____Unify___rl_analyse__write_3_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__write_3_0);
	r1 = r4;
	r2 = r5;
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_analyse__write_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module41)
	init_entry(mercury____Index___rl_analyse__write_3_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__write_3_0);
	r1 = r4;
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___rl_analyse__write_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module42)
	init_entry(mercury____Compare___rl_analyse__write_3_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__write_3_0);
	r1 = r4;
	r2 = r5;
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_analyse__write_3_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module43)
	init_entry(mercury____Unify___rl_analyse__gen_kill_data_0_0);
	init_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i2);
	init_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i4);
	init_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__gen_kill_data_0_0);
	MR_incr_sp_push_msg(7, "rl_analyse:__Unify__/2");
	MR_stackvar(7) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_19);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___rl_analyse__gen_kill_data_0_0_i2,
		ENTRY(mercury____Unify___rl_analyse__gen_kill_data_0_0));
Define_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__gen_kill_data_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__gen_kill_data_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__unify_2_0),
		mercury____Unify___rl_analyse__gen_kill_data_0_0_i4,
		ENTRY(mercury____Unify___rl_analyse__gen_kill_data_0_0));
Define_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_analyse__gen_kill_data_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_analyse__gen_kill_data_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___rl_analyse__gen_kill_data_0_0));
Define_label(mercury____Unify___rl_analyse__gen_kill_data_0_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_analyse_module44)
	init_entry(mercury____Index___rl_analyse__gen_kill_data_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__gen_kill_data_0_0);
	tailcall(STATIC(mercury____Index___rl_analyse__gen_kill_data_0__ua0_2_0),
		ENTRY(mercury____Index___rl_analyse__gen_kill_data_0_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module45)
	init_entry(mercury____Compare___rl_analyse__gen_kill_data_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__gen_kill_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_18);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_19);
	tailcall(STATIC(mercury____Compare___rl_analyse__block_data_2_0),
		ENTRY(mercury____Compare___rl_analyse__gen_kill_data_0_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module46)
	init_entry(mercury____Unify___rl_analyse__gen_kill_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__gen_kill_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___rl_analyse__gen_kill_data_map_0_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module47)
	init_entry(mercury____Index___rl_analyse__gen_kill_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__gen_kill_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___rl_analyse__gen_kill_data_map_0_0));
END_MODULE


BEGIN_MODULE(rl_analyse_module48)
	init_entry(mercury____Compare___rl_analyse__gen_kill_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__gen_kill_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_analyse__common_20);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___rl_analyse__gen_kill_data_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(rl_analyse_module49)
	init_entry(mercury____Unify___rl_analyse__int_set_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_analyse__int_set_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		ENTRY(mercury____Unify___rl_analyse__int_set_0_0));
END_MODULE

Declare_entry(mercury____Index___set__set_1_0);

BEGIN_MODULE(rl_analyse_module50)
	init_entry(mercury____Index___rl_analyse__int_set_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_analyse__int_set_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___set__set_1_0),
		ENTRY(mercury____Index___rl_analyse__int_set_0_0));
END_MODULE

Declare_entry(mercury____Compare___set__set_1_0);

BEGIN_MODULE(rl_analyse_module51)
	init_entry(mercury____Compare___rl_analyse__int_set_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_analyse__int_set_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		ENTRY(mercury____Compare___rl_analyse__int_set_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_analyse_maybe_bunch_0(void)
{
	rl_analyse_module0();
	rl_analyse_module1();
	rl_analyse_module2();
	rl_analyse_module3();
	rl_analyse_module4();
	rl_analyse_module5();
	rl_analyse_module6();
	rl_analyse_module7();
	rl_analyse_module8();
	rl_analyse_module9();
	rl_analyse_module10();
	rl_analyse_module11();
	rl_analyse_module12();
	rl_analyse_module13();
	rl_analyse_module14();
	rl_analyse_module15();
	rl_analyse_module16();
	rl_analyse_module17();
	rl_analyse_module18();
	rl_analyse_module19();
	rl_analyse_module20();
	rl_analyse_module21();
	rl_analyse_module22();
	rl_analyse_module23();
	rl_analyse_module24();
	rl_analyse_module25();
	rl_analyse_module26();
	rl_analyse_module27();
	rl_analyse_module28();
	rl_analyse_module29();
	rl_analyse_module30();
	rl_analyse_module31();
	rl_analyse_module32();
	rl_analyse_module33();
	rl_analyse_module34();
	rl_analyse_module35();
	rl_analyse_module36();
	rl_analyse_module37();
	rl_analyse_module38();
	rl_analyse_module39();
}

static void mercury__rl_analyse_maybe_bunch_1(void)
{
	rl_analyse_module40();
	rl_analyse_module41();
	rl_analyse_module42();
	rl_analyse_module43();
	rl_analyse_module44();
	rl_analyse_module45();
	rl_analyse_module46();
	rl_analyse_module47();
	rl_analyse_module48();
	rl_analyse_module49();
	rl_analyse_module50();
	rl_analyse_module51();
}

#endif

void mercury__rl_analyse__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_analyse__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_analyse_maybe_bunch_0();
		mercury__rl_analyse_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_block_data_2,
			rl_analyse__block_data_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_block_data_map_2,
			rl_analyse__block_data_map_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_block_update_3,
			rl_analyse__block_update_3_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_confluence_2,
			rl_analyse__confluence_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_direction_0,
			rl_analyse__direction_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_equal_2,
			rl_analyse__equal_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_gen_kill_data_0,
			rl_analyse__gen_kill_data_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_gen_kill_data_map_0,
			rl_analyse__gen_kill_data_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_int_set_0,
			rl_analyse__int_set_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_rl_analysis_3,
			rl_analyse__rl_analysis_3_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_analyse__type_ctor_info_write_3,
			rl_analyse__write_3_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
