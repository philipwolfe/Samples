/*
** Automatically generated from `rl_dump.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_dump__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__rl_dump__write_list__ho8__ua0_4_0);
Declare_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i3);
Declare_static(mercury__rl_dump__write_list__ho7__ua0_4_0);
Declare_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i3);
Declare_static(mercury__rl_dump__write_list__ho6__ua0_5_0);
Declare_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i2);
Declare_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i3);
Declare_static(mercury__rl_dump__write_list__ho2__ua0_4_0);
Declare_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i3);
Declare_static(mercury__rl_dump__write_project_output__ua0_5_0);
Declare_label(mercury__rl_dump__write_project_output__ua0_5_0_i2);
Declare_label(mercury__rl_dump__write_project_output__ua0_5_0_i3);
Declare_label(mercury__rl_dump__write_project_output__ua0_5_0_i4);
Declare_label(mercury__rl_dump__write_project_output__ua0_5_0_i5);
Declare_static(mercury__rl_dump__write_relation_id__ua0_4_0);
Declare_label(mercury__rl_dump__write_relation_id__ua0_4_0_i2);
Declare_static(mercury__rl_dump__write_output_rel__ua0_4_0);
Declare_label(mercury__rl_dump__write_output_rel__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_output_rel__ua0_4_0_i3);
Declare_label(mercury__rl_dump__write_output_rel__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_output_rel__ua0_4_0_i7);
Declare_label(mercury__rl_dump__write_output_rel__ua0_4_0_i9);
Declare_static(mercury__rl_dump__write_goto_cond__ua0_4_0);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i4);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i5);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i9);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i10);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i13);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i14);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i15);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i17);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i18);
Declare_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i19);
Declare_static(mercury__rl_dump__write_key_range__ua0_4_0);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i4);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i7);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i8);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i9);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i11);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i13);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i14);
Declare_label(mercury__rl_dump__write_key_range__ua0_4_0_i15);
Declare_static(mercury__rl_dump__write_insert_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_insert_type__ua0_4_0_i3);
Declare_label(mercury__rl_dump__write_insert_type__ua0_4_0_i5);
Declare_label(mercury__rl_dump__write_insert_type__ua0_4_0_i6);
Declare_static(mercury__rl_dump__write_union_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_union_type__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_union_type__ua0_4_0_i3);
Declare_static(mercury__rl_dump__write_project_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_project_type__ua0_4_0_i3);
Declare_label(mercury__rl_dump__write_project_type__ua0_4_0_i5);
Declare_label(mercury__rl_dump__write_project_type__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_project_type__ua0_4_0_i7);
Declare_label(mercury__rl_dump__write_project_type__ua0_4_0_i8);
Declare_static(mercury__rl_dump__write_difference_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_difference_type__ua0_4_0_i2);
Declare_label(mercury__rl_dump__write_difference_type__ua0_4_0_i3);
Declare_static(mercury__rl_dump__write_subtract_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i1006);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i10);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i11);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i12);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i13);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i4);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i5);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i7);
Declare_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i8);
Declare_static(mercury__rl_dump__write_join_type__ua0_4_0);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i1007);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i18);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i10);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i11);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i12);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i13);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i4);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i5);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i6);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i7);
Declare_label(mercury__rl_dump__write_join_type__ua0_4_0_i8);
Declare_static(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0);
Declare_static(mercury__rl_dump__IntroducedFrom__pred__write_sort_attr_list__508__3_3_0);
Declare_static(mercury__rl_dump__IntroducedFrom__pred__declare_relation__97__2_4_0);
Declare_static(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0);
Declare_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i2);
Declare_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i3);
Declare_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i4);
Declare_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i5);
Define_extern_entry(mercury__rl_dump__write_procedure_4_0);
Declare_label(mercury__rl_dump__write_procedure_4_0_i2);
Declare_label(mercury__rl_dump__write_procedure_4_0_i3);
Declare_label(mercury__rl_dump__write_procedure_4_0_i4);
Declare_label(mercury__rl_dump__write_procedure_4_0_i5);
Declare_label(mercury__rl_dump__write_procedure_4_0_i6);
Declare_label(mercury__rl_dump__write_procedure_4_0_i7);
Declare_label(mercury__rl_dump__write_procedure_4_0_i8);
Declare_label(mercury__rl_dump__write_procedure_4_0_i9);
Declare_label(mercury__rl_dump__write_procedure_4_0_i10);
Declare_label(mercury__rl_dump__write_procedure_4_0_i11);
Declare_label(mercury__rl_dump__write_procedure_4_0_i12);
Declare_label(mercury__rl_dump__write_procedure_4_0_i13);
Declare_label(mercury__rl_dump__write_procedure_4_0_i14);
Declare_label(mercury__rl_dump__write_procedure_4_0_i15);
Declare_label(mercury__rl_dump__write_procedure_4_0_i16);
Declare_label(mercury__rl_dump__write_procedure_4_0_i17);
Declare_label(mercury__rl_dump__write_procedure_4_0_i18);
Define_extern_entry(mercury__rl_dump__write_instruction_5_0);
Declare_label(mercury__rl_dump__write_instruction_5_0_i4);
Declare_label(mercury__rl_dump__write_instruction_5_0_i7);
Declare_label(mercury__rl_dump__write_instruction_5_0_i8);
Declare_label(mercury__rl_dump__write_instruction_5_0_i9);
Declare_label(mercury__rl_dump__write_instruction_5_0_i10);
Declare_label(mercury__rl_dump__write_instruction_5_0_i11);
Declare_label(mercury__rl_dump__write_instruction_5_0_i12);
Declare_label(mercury__rl_dump__write_instruction_5_0_i13);
Declare_label(mercury__rl_dump__write_instruction_5_0_i14);
Declare_label(mercury__rl_dump__write_instruction_5_0_i15);
Declare_label(mercury__rl_dump__write_instruction_5_0_i16);
Declare_label(mercury__rl_dump__write_instruction_5_0_i17);
Declare_label(mercury__rl_dump__write_instruction_5_0_i18);
Declare_label(mercury__rl_dump__write_instruction_5_0_i21);
Declare_label(mercury__rl_dump__write_instruction_5_0_i22);
Declare_label(mercury__rl_dump__write_instruction_5_0_i23);
Declare_label(mercury__rl_dump__write_instruction_5_0_i24);
Declare_label(mercury__rl_dump__write_instruction_5_0_i25);
Declare_label(mercury__rl_dump__write_instruction_5_0_i26);
Declare_label(mercury__rl_dump__write_instruction_5_0_i27);
Declare_label(mercury__rl_dump__write_instruction_5_0_i28);
Declare_label(mercury__rl_dump__write_instruction_5_0_i29);
Declare_label(mercury__rl_dump__write_instruction_5_0_i30);
Declare_label(mercury__rl_dump__write_instruction_5_0_i31);
Declare_label(mercury__rl_dump__write_instruction_5_0_i32);
Declare_label(mercury__rl_dump__write_instruction_5_0_i35);
Declare_label(mercury__rl_dump__write_instruction_5_0_i36);
Declare_label(mercury__rl_dump__write_instruction_5_0_i37);
Declare_label(mercury__rl_dump__write_instruction_5_0_i38);
Declare_label(mercury__rl_dump__write_instruction_5_0_i39);
Declare_label(mercury__rl_dump__write_instruction_5_0_i40);
Declare_label(mercury__rl_dump__write_instruction_5_0_i41);
Declare_label(mercury__rl_dump__write_instruction_5_0_i42);
Declare_label(mercury__rl_dump__write_instruction_5_0_i43);
Declare_label(mercury__rl_dump__write_instruction_5_0_i44);
Declare_label(mercury__rl_dump__write_instruction_5_0_i47);
Declare_label(mercury__rl_dump__write_instruction_5_0_i48);
Declare_label(mercury__rl_dump__write_instruction_5_0_i49);
Declare_label(mercury__rl_dump__write_instruction_5_0_i50);
Declare_label(mercury__rl_dump__write_instruction_5_0_i51);
Declare_label(mercury__rl_dump__write_instruction_5_0_i52);
Declare_label(mercury__rl_dump__write_instruction_5_0_i53);
Declare_label(mercury__rl_dump__write_instruction_5_0_i54);
Declare_label(mercury__rl_dump__write_instruction_5_0_i55);
Declare_label(mercury__rl_dump__write_instruction_5_0_i56);
Declare_label(mercury__rl_dump__write_instruction_5_0_i57);
Declare_label(mercury__rl_dump__write_instruction_5_0_i58);
Declare_label(mercury__rl_dump__write_instruction_5_0_i61);
Declare_label(mercury__rl_dump__write_instruction_5_0_i62);
Declare_label(mercury__rl_dump__write_instruction_5_0_i63);
Declare_label(mercury__rl_dump__write_instruction_5_0_i64);
Declare_label(mercury__rl_dump__write_instruction_5_0_i65);
Declare_label(mercury__rl_dump__write_instruction_5_0_i66);
Declare_label(mercury__rl_dump__write_instruction_5_0_i67);
Declare_label(mercury__rl_dump__write_instruction_5_0_i68);
Declare_label(mercury__rl_dump__write_instruction_5_0_i71);
Declare_label(mercury__rl_dump__write_instruction_5_0_i72);
Declare_label(mercury__rl_dump__write_instruction_5_0_i73);
Declare_label(mercury__rl_dump__write_instruction_5_0_i74);
Declare_label(mercury__rl_dump__write_instruction_5_0_i75);
Declare_label(mercury__rl_dump__write_instruction_5_0_i76);
Declare_label(mercury__rl_dump__write_instruction_5_0_i77);
Declare_label(mercury__rl_dump__write_instruction_5_0_i78);
Declare_label(mercury__rl_dump__write_instruction_5_0_i79);
Declare_label(mercury__rl_dump__write_instruction_5_0_i80);
Declare_label(mercury__rl_dump__write_instruction_5_0_i81);
Declare_label(mercury__rl_dump__write_instruction_5_0_i82);
Declare_label(mercury__rl_dump__write_instruction_5_0_i83);
Declare_label(mercury__rl_dump__write_instruction_5_0_i86);
Declare_label(mercury__rl_dump__write_instruction_5_0_i87);
Declare_label(mercury__rl_dump__write_instruction_5_0_i88);
Declare_label(mercury__rl_dump__write_instruction_5_0_i89);
Declare_label(mercury__rl_dump__write_instruction_5_0_i90);
Declare_label(mercury__rl_dump__write_instruction_5_0_i91);
Declare_label(mercury__rl_dump__write_instruction_5_0_i92);
Declare_label(mercury__rl_dump__write_instruction_5_0_i93);
Declare_label(mercury__rl_dump__write_instruction_5_0_i94);
Declare_label(mercury__rl_dump__write_instruction_5_0_i95);
Declare_label(mercury__rl_dump__write_instruction_5_0_i96);
Declare_label(mercury__rl_dump__write_instruction_5_0_i97);
Declare_label(mercury__rl_dump__write_instruction_5_0_i100);
Declare_label(mercury__rl_dump__write_instruction_5_0_i101);
Declare_label(mercury__rl_dump__write_instruction_5_0_i102);
Declare_label(mercury__rl_dump__write_instruction_5_0_i103);
Declare_label(mercury__rl_dump__write_instruction_5_0_i104);
Declare_label(mercury__rl_dump__write_instruction_5_0_i105);
Declare_label(mercury__rl_dump__write_instruction_5_0_i106);
Declare_label(mercury__rl_dump__write_instruction_5_0_i109);
Declare_label(mercury__rl_dump__write_instruction_5_0_i110);
Declare_label(mercury__rl_dump__write_instruction_5_0_i111);
Declare_label(mercury__rl_dump__write_instruction_5_0_i112);
Declare_label(mercury__rl_dump__write_instruction_5_0_i113);
Declare_label(mercury__rl_dump__write_instruction_5_0_i116);
Declare_label(mercury__rl_dump__write_instruction_5_0_i117);
Declare_label(mercury__rl_dump__write_instruction_5_0_i118);
Declare_label(mercury__rl_dump__write_instruction_5_0_i119);
Declare_label(mercury__rl_dump__write_instruction_5_0_i120);
Declare_label(mercury__rl_dump__write_instruction_5_0_i123);
Declare_label(mercury__rl_dump__write_instruction_5_0_i124);
Declare_label(mercury__rl_dump__write_instruction_5_0_i125);
Declare_label(mercury__rl_dump__write_instruction_5_0_i126);
Declare_label(mercury__rl_dump__write_instruction_5_0_i127);
Declare_label(mercury__rl_dump__write_instruction_5_0_i130);
Declare_label(mercury__rl_dump__write_instruction_5_0_i131);
Declare_label(mercury__rl_dump__write_instruction_5_0_i132);
Declare_label(mercury__rl_dump__write_instruction_5_0_i133);
Declare_label(mercury__rl_dump__write_instruction_5_0_i136);
Declare_label(mercury__rl_dump__write_instruction_5_0_i137);
Declare_label(mercury__rl_dump__write_instruction_5_0_i138);
Declare_label(mercury__rl_dump__write_instruction_5_0_i139);
Declare_label(mercury__rl_dump__write_instruction_5_0_i140);
Declare_label(mercury__rl_dump__write_instruction_5_0_i141);
Declare_label(mercury__rl_dump__write_instruction_5_0_i142);
Declare_label(mercury__rl_dump__write_instruction_5_0_i143);
Declare_label(mercury__rl_dump__write_instruction_5_0_i146);
Declare_label(mercury__rl_dump__write_instruction_5_0_i147);
Declare_label(mercury__rl_dump__write_instruction_5_0_i148);
Declare_label(mercury__rl_dump__write_instruction_5_0_i149);
Declare_label(mercury__rl_dump__write_instruction_5_0_i150);
Declare_label(mercury__rl_dump__write_instruction_5_0_i151);
Declare_label(mercury__rl_dump__write_instruction_5_0_i152);
Declare_label(mercury__rl_dump__write_instruction_5_0_i153);
Declare_label(mercury__rl_dump__write_instruction_5_0_i154);
Declare_label(mercury__rl_dump__write_instruction_5_0_i155);
Declare_label(mercury__rl_dump__write_instruction_5_0_i156);
Declare_label(mercury__rl_dump__write_instruction_5_0_i157);
Declare_label(mercury__rl_dump__write_instruction_5_0_i160);
Declare_label(mercury__rl_dump__write_instruction_5_0_i161);
Declare_label(mercury__rl_dump__write_instruction_5_0_i162);
Declare_label(mercury__rl_dump__write_instruction_5_0_i163);
Declare_label(mercury__rl_dump__write_instruction_5_0_i164);
Declare_label(mercury__rl_dump__write_instruction_5_0_i165);
Declare_label(mercury__rl_dump__write_instruction_5_0_i166);
Declare_label(mercury__rl_dump__write_instruction_5_0_i167);
Declare_label(mercury__rl_dump__write_instruction_5_0_i168);
Declare_label(mercury__rl_dump__write_instruction_5_0_i169);
Declare_label(mercury__rl_dump__write_instruction_5_0_i170);
Declare_label(mercury__rl_dump__write_instruction_5_0_i173);
Declare_label(mercury__rl_dump__write_instruction_5_0_i174);
Declare_label(mercury__rl_dump__write_instruction_5_0_i175);
Declare_label(mercury__rl_dump__write_instruction_5_0_i176);
Declare_label(mercury__rl_dump__write_instruction_5_0_i179);
Declare_label(mercury__rl_dump__write_instruction_5_0_i180);
Declare_label(mercury__rl_dump__write_instruction_5_0_i181);
Declare_label(mercury__rl_dump__write_instruction_5_0_i182);
Declare_label(mercury__rl_dump__write_instruction_5_0_i185);
Declare_label(mercury__rl_dump__write_instruction_5_0_i186);
Declare_label(mercury__rl_dump__write_instruction_5_0_i187);
Declare_label(mercury__rl_dump__write_instruction_5_0_i188);
Declare_label(mercury__rl_dump__write_instruction_5_0_i191);
Declare_label(mercury__rl_dump__write_instruction_5_0_i192);
Declare_label(mercury__rl_dump__write_instruction_5_0_i193);
Declare_label(mercury__rl_dump__write_instruction_5_0_i194);
Declare_label(mercury__rl_dump__write_instruction_5_0_i195);
Declare_label(mercury__rl_dump__write_instruction_5_0_i198);
Declare_label(mercury__rl_dump__write_instruction_5_0_i199);
Declare_label(mercury__rl_dump__write_instruction_5_0_i200);
Declare_label(mercury__rl_dump__write_instruction_5_0_i201);
Declare_label(mercury__rl_dump__write_instruction_5_0_i202);
Declare_label(mercury__rl_dump__write_instruction_5_0_i203);
Declare_label(mercury__rl_dump__write_instruction_5_0_i204);
Declare_label(mercury__rl_dump__write_instruction_5_0_i207);
Declare_label(mercury__rl_dump__write_instruction_5_0_i208);
Declare_label(mercury__rl_dump__write_instruction_5_0_i209);
Declare_label(mercury__rl_dump__write_instruction_5_0_i210);
Declare_label(mercury__rl_dump__write_instruction_5_0_i211);
Declare_label(mercury__rl_dump__write_instruction_5_0_i212);
Declare_static(mercury__rl_dump__declare_relation_5_0);
Declare_label(mercury__rl_dump__declare_relation_5_0_i2);
Declare_label(mercury__rl_dump__declare_relation_5_0_i3);
Declare_label(mercury__rl_dump__declare_relation_5_0_i4);
Declare_label(mercury__rl_dump__declare_relation_5_0_i5);
Declare_label(mercury__rl_dump__declare_relation_5_0_i8);
Declare_label(mercury__rl_dump__declare_relation_5_0_i9);
Declare_label(mercury__rl_dump__declare_relation_5_0_i10);
Declare_label(mercury__rl_dump__declare_relation_5_0_i11);
Declare_label(mercury__rl_dump__declare_relation_5_0_i12);
Declare_label(mercury__rl_dump__declare_relation_5_0_i13);
Declare_label(mercury__rl_dump__declare_relation_5_0_i7);
Declare_label(mercury__rl_dump__declare_relation_5_0_i15);
Declare_label(mercury__rl_dump__declare_relation_5_0_i16);
Declare_label(mercury__rl_dump__declare_relation_5_0_i17);
Declare_label(mercury__rl_dump__declare_relation_5_0_i18);
Declare_label(mercury__rl_dump__declare_relation_5_0_i19);
Declare_label(mercury__rl_dump__declare_relation_5_0_i20);
Declare_label(mercury__rl_dump__declare_relation_5_0_i21);
Declare_label(mercury__rl_dump__declare_relation_5_0_i22);
Declare_label(mercury__rl_dump__declare_relation_5_0_i23);
Declare_label(mercury__rl_dump__declare_relation_5_0_i24);
Declare_static(mercury__rl_dump__write_key_attr_pair_3_0);
Declare_label(mercury__rl_dump__write_key_attr_pair_3_0_i2);
Declare_label(mercury__rl_dump__write_key_attr_pair_3_0_i3);
Declare_static(mercury__rl_dump__write_key_attr_3_0);
Declare_label(mercury__rl_dump__write_key_attr_3_0_i4);
Declare_label(mercury__rl_dump__write_key_attr_3_0_i5);
Declare_label(mercury__rl_dump__write_key_attr_3_0_i6);
Declare_label(mercury__rl_dump__write_key_attr_3_0_i7);
Declare_static(mercury__rl_dump__write_sort_spec_3_0);
Declare_label(mercury__rl_dump__write_sort_spec_3_0_i4);
Declare_label(mercury__rl_dump__write_sort_spec_3_0_i5);
Declare_label(mercury__rl_dump__write_sort_spec_3_0_i3);
Declare_label(mercury__rl_dump__write_sort_spec_3_0_i7);
Declare_label(mercury__rl_dump__write_sort_spec_3_0_i8);
Declare_static(mercury__rl_dump__write_sort_attr_list_3_0);
Declare_label(mercury__rl_dump__write_sort_attr_list_3_0_i2);
Declare_label(mercury__rl_dump__write_sort_attr_list_3_0_i3);
Declare_static(mercury__rl_dump__write_comment_3_0);
Declare_label(mercury__rl_dump__write_comment_3_0_i2);
Declare_label(mercury__rl_dump__write_comment_3_0_i4);
Declare_static(mercury__rl_dump__write_output_rel_4_0);
Declare_static(mercury__rl_dump__write_relation_id_4_0);
Declare_static(mercury__rl_dump__write_project_output_5_0);
Declare_static(mercury__rl_dump__write_goal_4_0);
Declare_label(mercury__rl_dump__write_goal_4_0_i14);
Declare_label(mercury__rl_dump__write_goal_4_0_i15);
Declare_label(mercury__rl_dump__write_goal_4_0_i16);
Declare_label(mercury__rl_dump__write_goal_4_0_i17);
Declare_label(mercury__rl_dump__write_goal_4_0_i18);
Declare_label(mercury__rl_dump__write_goal_4_0_i19);
Declare_label(mercury__rl_dump__write_goal_4_0_i4);
Declare_label(mercury__rl_dump__write_goal_4_0_i5);
Declare_label(mercury__rl_dump__write_goal_4_0_i6);
Declare_label(mercury__rl_dump__write_goal_4_0_i7);
Declare_label(mercury__rl_dump__write_goal_4_0_i9);
Declare_label(mercury__rl_dump__write_goal_4_0_i26);
Declare_label(mercury__rl_dump__write_goal_4_0_i29);
Declare_label(mercury__rl_dump__write_goal_4_0_i30);
Declare_label(mercury__rl_dump__write_goal_4_0_i27);
Declare_static(mercury__rl_dump__write_bounds_5_0);
Declare_label(mercury__rl_dump__write_bounds_5_0_i2);
Declare_label(mercury__rl_dump__write_bounds_5_0_i3);
Declare_label(mercury__rl_dump__write_bounds_5_0_i4);
Declare_label(mercury__rl_dump__write_bounds_5_0_i5);
Declare_static(mercury__rl_dump__write_bound_pair_5_0);
Declare_label(mercury__rl_dump__write_bound_pair_5_0_i2);
Declare_label(mercury__rl_dump__write_bound_pair_5_0_i3);
Declare_label(mercury__rl_dump__write_bound_pair_5_0_i4);
Declare_label(mercury__rl_dump__write_bound_pair_5_0_i5);
Declare_static(mercury__rl_dump__write_key_term_5_0);
Declare_label(mercury__rl_dump__write_key_term_5_0_i4);
Declare_label(mercury__rl_dump__write_key_term_5_0_i5);
Declare_label(mercury__rl_dump__write_key_term_5_0_i8);
Declare_label(mercury__rl_dump__write_key_term_5_0_i3);
Declare_label(mercury__rl_dump__write_key_term_5_0_i11);
Declare_label(mercury__rl_dump__write_key_term_5_0_i12);
Declare_label(mercury__rl_dump__write_key_term_5_0_i13);
Declare_label(mercury__rl_dump__write_key_term_5_0_i14);
Declare_label(mercury__rl_dump__write_key_term_5_0_i15);
Declare_label(mercury__rl_dump__write_key_term_5_0_i16);
Declare_label(mercury__rl_dump__write_key_term_5_0_i17);
Declare_static(mercury__rl_dump__write_var_list_4_0);
Declare_label(mercury__rl_dump__write_var_list_4_0_i2);
Declare_label(mercury__rl_dump__write_var_list_4_0_i3);
Declare_static(mercury__rl_dump__comma_2_0);

static const struct mercury_data_rl_dump__common_0_struct {
	Word * f1;
}  mercury_data_rl_dump__common_0;

static const struct mercury_data_rl_dump__common_1_struct {
	Word * f1;
}  mercury_data_rl_dump__common_1;

static const struct mercury_data_rl_dump__common_2_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_dump__common_2;

static const struct mercury_data_rl_dump__common_3_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_dump__common_3;

static const struct mercury_data_rl_dump__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_4;

static const struct mercury_data_rl_dump__common_5_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_dump__common_5;

static const struct mercury_data_rl_dump__common_6_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_dump__common_6;

static const struct mercury_data_rl_dump__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_7;

static const struct mercury_data_rl_dump__common_8_struct {
	Word * f1;
}  mercury_data_rl_dump__common_8;

static const struct mercury_data_rl_dump__common_9_struct {
	Word * f1;
}  mercury_data_rl_dump__common_9;

static const struct mercury_data_rl_dump__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_dump__common_10;

static const struct mercury_data_rl_dump__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_11;

static const struct mercury_data_rl_dump__common_12_struct {
	Word * f1;
}  mercury_data_rl_dump__common_12;

static const struct mercury_data_rl_dump__common_13_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_dump__common_13;

static const struct mercury_data_rl_dump__common_14_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_14;

static const struct mercury_data_rl_dump__common_15_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_15;

static const struct mercury_data_rl_dump__common_16_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_16;

static const struct mercury_data_rl_dump__common_17_struct {
	String f1;
	Word * f2;
}  mercury_data_rl_dump__common_17;

static const struct mercury_data_rl_dump__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_18;

static const struct mercury_data_rl_dump__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_19;

static const struct mercury_data_rl_dump__common_20_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_20;

static const struct mercury_data_rl_dump__common_21_struct {
	Word * f1;
}  mercury_data_rl_dump__common_21;

static const struct mercury_data_rl_dump__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_dump__common_22;

static const struct mercury_data_rl_dump__common_23_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_23;

static const struct mercury_data_rl_dump__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_24;

static const struct mercury_data_rl_dump__common_25_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_dump__common_25;

static const struct mercury_data_rl_dump__common_26_struct {
	Word * f1;
}  mercury_data_rl_dump__common_26;

static const struct mercury_data_rl_dump__common_27_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_dump__common_27;

static const struct mercury_data_rl_dump__common_28_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_dump__common_28;

static const struct mercury_data_rl_dump__common_29_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_dump__common_29;

static const struct mercury_data_rl_dump__common_30_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_dump__common_30;

static const struct mercury_data_rl_dump__common_31_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_31;

static const struct mercury_data_rl_dump__common_32_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_32;

static const struct mercury_data_rl_dump__common_33_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_33;

static const struct mercury_data_rl_dump__common_34_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_34;

static const struct mercury_data_rl_dump__common_35_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_35;

static const struct mercury_data_rl_dump__common_36_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_dump__common_36;

static const struct mercury_data_rl_dump__common_37_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_37;

static const struct mercury_data_rl_dump__common_38_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_dump__common_38;

static const struct mercury_data_rl_dump__common_39_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_39;

static const struct mercury_data_rl_dump__common_40_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_dump__common_40;

static const struct mercury_data_rl_dump__common_41_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_dump__common_41;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_index_spec_0;
static const struct mercury_data_rl_dump__common_0_struct mercury_data_rl_dump__common_0 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_index_spec_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_dump__common_1_struct mercury_data_rl_dump__common_1 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_dump__common_2_struct mercury_data_rl_dump__common_2 = {
	(Integer) 0,
	MR_string_const("mercury_to_mercury", 18),
	MR_string_const("mercury_to_mercury", 18),
	MR_string_const("mercury_output_index_spec", 25),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

Declare_entry(mercury__mercury_to_mercury__mercury_output_index_spec_3_0);
static const struct mercury_data_rl_dump__common_3_struct mercury_data_rl_dump__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_2),
	ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_key_attr_0;
static const struct mercury_data_rl_dump__common_4_struct mercury_data_rl_dump__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl__type_ctor_info_key_attr_0
};

static const struct mercury_data_rl_dump__common_5_struct mercury_data_rl_dump__common_5 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_key_attr_pair", 19),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_6_struct mercury_data_rl_dump__common_6 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_5),
	STATIC(mercury__rl_dump__write_key_attr_pair_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_sort_dir_0;
static const struct mercury_data_rl_dump__common_7_struct mercury_data_rl_dump__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl__type_ctor_info_sort_dir_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_rl_dump__common_8_struct mercury_data_rl_dump__common_8 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_rl_dump__common_9_struct mercury_data_rl_dump__common_9 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_rl_dump__common_10_struct mercury_data_rl_dump__common_10 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("IntroducedFrom__pred__write_procedure__37__1", 44),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_relation_info_0;
static const struct mercury_data_rl_dump__common_11_struct mercury_data_rl_dump__common_11 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl__type_ctor_info_relation_info_0
};

static const struct mercury_data_rl_dump__common_12_struct mercury_data_rl_dump__common_12 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_dump__common_13_struct mercury_data_rl_dump__common_13 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_relation_id", 17),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_14_struct mercury_data_rl_dump__common_14 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("declare_relation", 16),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_rl_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_rl_dump__common_15_struct mercury_data_rl_dump__common_15 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_rl_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_rl_dump__common_16_struct mercury_data_rl_dump__common_16 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_instruction", 17),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_15),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_17_struct mercury_data_rl_dump__common_17 = {
	MR_string_const("\n%\n\n", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_output_rel_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_rl_goal_0;
static const struct mercury_data_rl_dump__common_18_struct mercury_data_rl_dump__common_18 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_output_rel_0,
	(Word *) &mercury_data_rl__type_ctor_info_rl_goal_0
};

static const struct mercury_data_rl_dump__common_19_struct mercury_data_rl_dump__common_19 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_project_output", 20),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_rl_dump__common_20_struct mercury_data_rl_dump__common_20 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_rl__type_ctor_info_output_rel_0
};

static const struct mercury_data_rl_dump__common_21_struct mercury_data_rl_dump__common_21 = {
	(Word *) &mercury_data_rl__type_ctor_info_output_rel_0
};

static const struct mercury_data_rl_dump__common_22_struct mercury_data_rl_dump__common_22 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_output_rel", 16),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_21),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_rl_dump__common_23_struct mercury_data_rl_dump__common_23 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_rl_dump__common_24_struct mercury_data_rl_dump__common_24 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_rl_dump__common_25_struct mercury_data_rl_dump__common_25 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("IntroducedFrom__pred__declare_relation__97__2", 45),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_24),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_23),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_26_struct mercury_data_rl_dump__common_26 = {
	(Word *) &mercury_data_rl__type_ctor_info_key_attr_0
};

static const struct mercury_data_rl_dump__common_27_struct mercury_data_rl_dump__common_27 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_key_attr", 14),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_26),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_28_struct mercury_data_rl_dump__common_28 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_27),
	STATIC(mercury__rl_dump__write_key_attr_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_dump__common_29_struct mercury_data_rl_dump__common_29 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("IntroducedFrom__pred__write_sort_attr_list__508__3", 50),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_30_struct mercury_data_rl_dump__common_30 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_29),
	STATIC(mercury__rl_dump__IntroducedFrom__pred__write_sort_attr_list__508__3_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_rl_dump__common_31_struct mercury_data_rl_dump__common_31 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_rl_dump__common_32_struct mercury_data_rl_dump__common_32 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_key_term_node_0;
static const struct mercury_data_rl_dump__common_33_struct mercury_data_rl_dump__common_33 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_key_term_node_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_32)
};

static const struct mercury_data_rl_dump__common_34_struct mercury_data_rl_dump__common_34 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_33),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_33)
};

static const struct mercury_data_rl_dump__common_35_struct mercury_data_rl_dump__common_35 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_34)
};

static const struct mercury_data_rl_dump__common_36_struct mercury_data_rl_dump__common_36 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_rl_dump__common_37_struct mercury_data_rl_dump__common_37 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_bounds", 12),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_38_struct mercury_data_rl_dump__common_38 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_34)
};

static const struct mercury_data_rl_dump__common_39_struct mercury_data_rl_dump__common_39 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_bound_pair", 16),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_38),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_40_struct mercury_data_rl_dump__common_40 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("write_key_term", 14),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_33),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

static const struct mercury_data_rl_dump__common_41_struct mercury_data_rl_dump__common_41 = {
	(Integer) 0,
	MR_string_const("rl_dump", 7),
	MR_string_const("rl_dump", 7),
	MR_string_const("IntroducedFrom__pred__write_var_list__686__4", 44),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_36),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_1)
};

Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_list_5_0);

BEGIN_MODULE(rl_dump_module0)
	init_entry(mercury__rl_dump__write_list__ho8__ua0_4_0);
	init_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_list__ho8__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_list__ho8__ua0_4_0);
	MR_incr_sp_push_msg(4, "rl_dump:write_list__ho8__ua0/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("[", 1);
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_list__ho8__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_list__ho8__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho8__ua0_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_list__ho8__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_list__ho8__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho8__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho8__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_list__ho8__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module1)
	init_entry(mercury__rl_dump__write_list__ho7__ua0_4_0);
	init_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_list__ho7__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_list__ho7__ua0_4_0);
	MR_incr_sp_push_msg(4, "rl_dump:write_list__ho7__ua0/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("[", 1);
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_list__ho7__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho7__ua0_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_list__ho7__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho7__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho7__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module2)
	init_entry(mercury__rl_dump__write_list__ho6__ua0_5_0);
	init_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i2);
	init_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i3);
BEGIN_CODE

/* code for predicate 'write_list__ho6__ua0'/5 in mode 0 */
Define_static(mercury__rl_dump__write_list__ho6__ua0_5_0);
	MR_incr_sp_push_msg(5, "rl_dump:write_list__ho6__ua0/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("[", 1);
	r2 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_list__ho6__ua0_5_0_i2,
		STATIC(mercury__rl_dump__write_list__ho6__ua0_5_0));
Define_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho6__ua0_5_0));
	r5 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_list__ho6__ua0_5_0_i3,
		STATIC(mercury__rl_dump__write_list__ho6__ua0_5_0));
Define_label(mercury__rl_dump__write_list__ho6__ua0_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho6__ua0_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_list__ho6__ua0_5_0));
END_MODULE


BEGIN_MODULE(rl_dump_module3)
	init_entry(mercury__rl_dump__write_list__ho2__ua0_4_0);
	init_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_list__ho2__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_list__ho2__ua0_4_0);
	MR_incr_sp_push_msg(4, "rl_dump:write_list__ho2__ua0/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("[", 1);
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_list__ho2__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_list__ho2__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho2__ua0_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_list__ho2__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_list__ho2__ua0_4_0));
Define_label(mercury__rl_dump__write_list__ho2__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_list__ho2__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_list__ho2__ua0_4_0));
END_MODULE

Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(rl_dump_module4)
	init_entry(mercury__rl_dump__write_project_output__ua0_5_0);
	init_label(mercury__rl_dump__write_project_output__ua0_5_0_i2);
	init_label(mercury__rl_dump__write_project_output__ua0_5_0_i3);
	init_label(mercury__rl_dump__write_project_output__ua0_5_0_i4);
	init_label(mercury__rl_dump__write_project_output__ua0_5_0_i5);
BEGIN_CODE

/* code for predicate 'write_project_output__ua0'/5 in mode 0 */
Define_static(mercury__rl_dump__write_project_output__ua0_5_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_project_output__ua0/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = r3;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_project_output__ua0_5_0_i2,
		STATIC(mercury__rl_dump__write_project_output__ua0_5_0));
Define_label(mercury__rl_dump__write_project_output__ua0_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_output__ua0_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" <- ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_project_output__ua0_5_0_i3,
		STATIC(mercury__rl_dump__write_project_output__ua0_5_0));
Define_label(mercury__rl_dump__write_project_output__ua0_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_output__ua0_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_project_output__ua0_5_0_i4,
		STATIC(mercury__rl_dump__write_project_output__ua0_5_0));
Define_label(mercury__rl_dump__write_project_output__ua0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_output__ua0_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_goal_4_0),
		mercury__rl_dump__write_project_output__ua0_5_0_i5,
		STATIC(mercury__rl_dump__write_project_output__ua0_5_0));
Define_label(mercury__rl_dump__write_project_output__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_output__ua0_5_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__rl_dump__write_project_output__ua0_5_0));
END_MODULE

Declare_entry(mercury__io__write_int_3_0);

BEGIN_MODULE(rl_dump_module5)
	init_entry(mercury__rl_dump__write_relation_id__ua0_4_0);
	init_label(mercury__rl_dump__write_relation_id__ua0_4_0_i2);
BEGIN_CODE

/* code for predicate 'write_relation_id__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_relation_id__ua0_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_relation_id__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Rel_", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_relation_id__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_relation_id__ua0_4_0));
Define_label(mercury__rl_dump__write_relation_id__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_relation_id__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_int_3_0),
		STATIC(mercury__rl_dump__write_relation_id__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module6)
	init_entry(mercury__rl_dump__write_output_rel__ua0_4_0);
	init_label(mercury__rl_dump__write_output_rel__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_output_rel__ua0_4_0_i3);
	init_label(mercury__rl_dump__write_output_rel__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_output_rel__ua0_4_0_i7);
	init_label(mercury__rl_dump__write_output_rel__ua0_4_0_i9);
BEGIN_CODE

/* code for predicate 'write_output_rel__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_output_rel__ua0_4_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_output_rel__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_string_const("Rel_", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_output_rel__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_output_rel__ua0_4_0));
Define_label(mercury__rl_dump__write_output_rel__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_output_rel__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_dump__write_output_rel__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_output_rel__ua0_4_0));
Define_label(mercury__rl_dump__write_output_rel__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_output_rel__ua0_4_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_output_rel__ua0_4_0_i9);
	r2 = r1;
	r1 = (Word) MR_string_const("[", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_output_rel__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_output_rel__ua0_4_0));
Define_label(mercury__rl_dump__write_output_rel__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_output_rel__ua0_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_index_spec_0;
	r2 = MR_stackvar(2);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_3);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_output_rel__ua0_4_0_i7,
		STATIC(mercury__rl_dump__write_output_rel__ua0_4_0));
Define_label(mercury__rl_dump__write_output_rel__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_output_rel__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_output_rel__ua0_4_0));
Define_label(mercury__rl_dump__write_output_rel__ua0_4_0_i9);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_dump_module7)
	init_entry(mercury__rl_dump__write_goto_cond__ua0_4_0);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i4);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i5);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i9);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i10);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i13);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i14);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i15);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i17);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i18);
	init_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i19);
BEGIN_CODE

/* code for predicate 'write_goto_cond__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_goto_cond__ua0_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_goto_cond__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i4) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i9) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i13) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i17));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_string_const("empty(", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i5,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Rel_", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i19,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	localcall(mercury__rl_dump__write_goto_cond__ua0_4_0,
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i10),
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i15,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i13);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	localcall(mercury__rl_dump__write_goto_cond__ua0_4_0,
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i14),
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ; ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i15,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i4) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i9) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i13) AND
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i17));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i17);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 0);
	r1 = (Word) MR_string_const("not(", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goto_cond__ua0_4_0_i18,
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	localcall(mercury__rl_dump__write_goto_cond__ua0_4_0,
		LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0_i19),
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
Define_label(mercury__rl_dump__write_goto_cond__ua0_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goto_cond__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module8)
	init_entry(mercury__rl_dump__write_key_range__ua0_4_0);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i4);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i7);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i8);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i9);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i11);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i13);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i14);
	init_label(mercury__rl_dump__write_key_range__ua0_4_0_i15);
BEGIN_CODE

/* code for predicate 'write_key_range__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_key_range__ua0_4_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_key_range__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_string_const("key_range(", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_key_range__ua0_4_0_i4);
	r2 = r1;
	r1 = (Word) MR_string_const("infinity", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i4);
	r2 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	r1 = (Word) MR_string_const("[", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_4);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_6);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i7,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i9,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_key_range__ua0_4_0_i11);
	r2 = r1;
	r1 = (Word) MR_string_const("infinity", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i15,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = r1;
	r1 = (Word) MR_string_const("[", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i13,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_4);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_6);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i14,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_range__ua0_4_0_i15,
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
Define_label(mercury__rl_dump__write_key_range__ua0_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_range__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_key_range__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module9)
	init_entry(mercury__rl_dump__write_insert_type__ua0_4_0);
	init_label(mercury__rl_dump__write_insert_type__ua0_4_0_i3);
	init_label(mercury__rl_dump__write_insert_type__ua0_4_0_i5);
	init_label(mercury__rl_dump__write_insert_type__ua0_4_0_i6);
BEGIN_CODE

/* code for predicate 'write_insert_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_insert_type__ua0_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_insert_type__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_insert_type__ua0_4_0_i3);
	r1 = (Word) MR_string_const("append", 6);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_insert_type__ua0_4_0));
Define_label(mercury__rl_dump__write_insert_type__ua0_4_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("index(", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_insert_type__ua0_4_0_i5,
		STATIC(mercury__rl_dump__write_insert_type__ua0_4_0));
Define_label(mercury__rl_dump__write_insert_type__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_insert_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
		mercury__rl_dump__write_insert_type__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_insert_type__ua0_4_0));
Define_label(mercury__rl_dump__write_insert_type__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_insert_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_insert_type__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module10)
	init_entry(mercury__rl_dump__write_union_type__ua0_4_0);
	init_label(mercury__rl_dump__write_union_type__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_union_type__ua0_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_union_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_union_type__ua0_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_union_type__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("sort_merge(", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_union_type__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_union_type__ua0_4_0));
Define_label(mercury__rl_dump__write_union_type__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_union_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_union_type__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_union_type__ua0_4_0));
Define_label(mercury__rl_dump__write_union_type__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_union_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_union_type__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module11)
	init_entry(mercury__rl_dump__write_project_type__ua0_4_0);
	init_label(mercury__rl_dump__write_project_type__ua0_4_0_i3);
	init_label(mercury__rl_dump__write_project_type__ua0_4_0_i5);
	init_label(mercury__rl_dump__write_project_type__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_project_type__ua0_4_0_i7);
	init_label(mercury__rl_dump__write_project_type__ua0_4_0_i8);
BEGIN_CODE

/* code for predicate 'write_project_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_project_type__ua0_4_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_project_type__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_project_type__ua0_4_0_i3);
	r1 = (Word) MR_string_const("filter", 6);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
Define_label(mercury__rl_dump__write_project_type__ua0_4_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("index(", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_project_type__ua0_4_0_i5,
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
Define_label(mercury__rl_dump__write_project_type__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
		mercury__rl_dump__write_project_type__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
Define_label(mercury__rl_dump__write_project_type__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_project_type__ua0_4_0_i7,
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
Define_label(mercury__rl_dump__write_project_type__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_key_range__ua0_4_0),
		mercury__rl_dump__write_project_type__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
Define_label(mercury__rl_dump__write_project_type__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_project_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_project_type__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module12)
	init_entry(mercury__rl_dump__write_difference_type__ua0_4_0);
	init_label(mercury__rl_dump__write_difference_type__ua0_4_0_i2);
	init_label(mercury__rl_dump__write_difference_type__ua0_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_difference_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_difference_type__ua0_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_difference_type__ua0/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("sort_merge(", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_difference_type__ua0_4_0_i2,
		STATIC(mercury__rl_dump__write_difference_type__ua0_4_0));
Define_label(mercury__rl_dump__write_difference_type__ua0_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_difference_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_difference_type__ua0_4_0_i3,
		STATIC(mercury__rl_dump__write_difference_type__ua0_4_0));
Define_label(mercury__rl_dump__write_difference_type__ua0_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_difference_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_difference_type__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module13)
	init_entry(mercury__rl_dump__write_subtract_type__ua0_4_0);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i1006);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i10);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i11);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i12);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i13);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i4);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i5);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i7);
	init_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i8);
BEGIN_CODE

/* code for predicate 'write_subtract_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_subtract_type__ua0_4_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_subtract_type__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0_i10);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0_i1006);
	r1 = (Word) MR_string_const("nested_loop", 11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i1006);
	r1 = (Word) MR_string_const("semi", 4);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = (Word) MR_string_const("index(", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i11,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i12,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i13,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_key_range__ua0_4_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("sort_merge(", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i5,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i7,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_subtract_type__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
Define_label(mercury__rl_dump__write_subtract_type__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_subtract_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module14)
	init_entry(mercury__rl_dump__write_join_type__ua0_4_0);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i1007);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i18);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i10);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i11);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i12);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i13);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i4);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i5);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i6);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i7);
	init_label(mercury__rl_dump__write_join_type__ua0_4_0_i8);
BEGIN_CODE

/* code for predicate 'write_join_type__ua0'/4 in mode 0 */
Define_static(mercury__rl_dump__write_join_type__ua0_4_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_join_type__ua0/4");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_dump__write_join_type__ua0_4_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_dump__write_join_type__ua0_4_0_i10);
	r3 = MR_unmkbody(r1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__rl_dump__write_join_type__ua0_4_0_i1007);
	r1 = (Word) MR_string_const("nested_loop", 11);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i1007);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__rl_dump__write_join_type__ua0_4_0_i18);
	r1 = (Word) MR_string_const("cross", 5);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i18);
	r1 = (Word) MR_string_const("semi", 4);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i10);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = (Word) MR_string_const("index(", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i11,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i12,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i13,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_key_range__ua0_4_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("sort_merge(", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i5,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i6,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i7,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_sort_spec_3_0),
		mercury__rl_dump__write_join_type__ua0_4_0_i8,
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
Define_label(mercury__rl_dump__write_join_type__ua0_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_join_type__ua0_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_join_type__ua0_4_0));
END_MODULE

Declare_entry(mercury__mercury_to_mercury__mercury_output_var_5_0);

BEGIN_MODULE(rl_dump_module15)
	init_entry(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_var_list__686__4'/4 in mode 0 */
Define_static(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0);
	r5 = r3;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = (Integer) 1;
	tailcall(ENTRY(mercury__mercury_to_mercury__mercury_output_var_5_0),
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0));
END_MODULE

Declare_entry(mercury__io__write_3_0);

BEGIN_MODULE(rl_dump_module16)
	init_entry(mercury__rl_dump__IntroducedFrom__pred__write_sort_attr_list__508__3_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_sort_attr_list__508__3'/3 in mode 0 */
Define_static(mercury__rl_dump__IntroducedFrom__pred__write_sort_attr_list__508__3_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_7);
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_sort_attr_list__508__3_3_0));
END_MODULE

Declare_entry(mercury__term_io__write_term_4_0);

BEGIN_MODULE(rl_dump_module17)
	init_entry(mercury__rl_dump__IntroducedFrom__pred__declare_relation__97__2_4_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__declare_relation__97__2'/4 in mode 0 */
Define_static(mercury__rl_dump__IntroducedFrom__pred__declare_relation__97__2_4_0);
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	tailcall(ENTRY(mercury__term_io__write_term_4_0),
		STATIC(mercury__rl_dump__IntroducedFrom__pred__declare_relation__97__2_4_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);

BEGIN_MODULE(rl_dump_module18)
	init_entry(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0);
	init_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i2);
	init_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i3);
	init_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i4);
	init_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i5);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_procedure__37__1'/4 in mode 0 */
Define_static(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0);
	MR_incr_sp_push_msg(2, "rl_dump:IntroducedFrom__pred__write_procedure__37__1/4");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i2,
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
Define_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i3,
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
Define_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("%\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i4,
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
Define_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i5,
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
Define_label(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0));
END_MODULE

Declare_entry(mercury__list__foldl_4_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__rl__proc_name_to_string_2_0);
Declare_entry(mercury__map__keys_2_0);

BEGIN_MODULE(rl_dump_module19)
	init_entry(mercury__rl_dump__write_procedure_4_0);
	init_label(mercury__rl_dump__write_procedure_4_0_i2);
	init_label(mercury__rl_dump__write_procedure_4_0_i3);
	init_label(mercury__rl_dump__write_procedure_4_0_i4);
	init_label(mercury__rl_dump__write_procedure_4_0_i5);
	init_label(mercury__rl_dump__write_procedure_4_0_i6);
	init_label(mercury__rl_dump__write_procedure_4_0_i7);
	init_label(mercury__rl_dump__write_procedure_4_0_i8);
	init_label(mercury__rl_dump__write_procedure_4_0_i9);
	init_label(mercury__rl_dump__write_procedure_4_0_i10);
	init_label(mercury__rl_dump__write_procedure_4_0_i11);
	init_label(mercury__rl_dump__write_procedure_4_0_i12);
	init_label(mercury__rl_dump__write_procedure_4_0_i13);
	init_label(mercury__rl_dump__write_procedure_4_0_i14);
	init_label(mercury__rl_dump__write_procedure_4_0_i15);
	init_label(mercury__rl_dump__write_procedure_4_0_i16);
	init_label(mercury__rl_dump__write_procedure_4_0_i17);
	init_label(mercury__rl_dump__write_procedure_4_0_i18);
BEGIN_CODE

/* code for predicate 'write_procedure'/4 in mode 0 */
Define_entry(mercury__rl_dump__write_procedure_4_0);
	MR_incr_sp_push_msg(9, "rl_dump:write_procedure/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) MR_string_const("% Procedure for\n", 16);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i2,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_procedure_4_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r4 = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_dump__IntroducedFrom__pred__write_procedure__37__1_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_10);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_dump__write_procedure_4_0_i3,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("% Memoed relations ", 19);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i4,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_dump__write_procedure_4_0_i5,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = MR_stackvar(5);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_procedure_4_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_relation_id_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_13);
	call_localret(STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0),
		mercury__rl_dump__write_procedure_4_0_i6,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\nPROCEDURE ", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i7,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__rl__proc_name_to_string_2_0),
		mercury__rl_dump__write_procedure_4_0_i8,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i9,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i10,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0),
		mercury__rl_dump__write_procedure_4_0_i11,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i12,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0),
		mercury__rl_dump__write_procedure_4_0_i13,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")\n{\n", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_procedure_4_0_i14,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__rl_dump__write_procedure_4_0_i15,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_procedure_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_14);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_dump__declare_relation_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(6);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_dump__write_procedure_4_0_i16,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_procedure_4_0_i17,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_15);
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_procedure_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_16);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__rl_dump__write_instruction_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(6);
	r5 = r4;
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_dump__write_procedure_4_0_i18,
		ENTRY(mercury__rl_dump__write_procedure_4_0));
Define_label(mercury__rl_dump__write_procedure_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_procedure_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("}\n\n\n\n", 5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__rl_dump__write_procedure_4_0));
END_MODULE

Declare_entry(mercury__io__write_strings_3_0);
Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);
Declare_entry(mercury__rl__label_id_to_string_2_0);

BEGIN_MODULE(rl_dump_module20)
	init_entry(mercury__rl_dump__write_instruction_5_0);
	init_label(mercury__rl_dump__write_instruction_5_0_i4);
	init_label(mercury__rl_dump__write_instruction_5_0_i7);
	init_label(mercury__rl_dump__write_instruction_5_0_i8);
	init_label(mercury__rl_dump__write_instruction_5_0_i9);
	init_label(mercury__rl_dump__write_instruction_5_0_i10);
	init_label(mercury__rl_dump__write_instruction_5_0_i11);
	init_label(mercury__rl_dump__write_instruction_5_0_i12);
	init_label(mercury__rl_dump__write_instruction_5_0_i13);
	init_label(mercury__rl_dump__write_instruction_5_0_i14);
	init_label(mercury__rl_dump__write_instruction_5_0_i15);
	init_label(mercury__rl_dump__write_instruction_5_0_i16);
	init_label(mercury__rl_dump__write_instruction_5_0_i17);
	init_label(mercury__rl_dump__write_instruction_5_0_i18);
	init_label(mercury__rl_dump__write_instruction_5_0_i21);
	init_label(mercury__rl_dump__write_instruction_5_0_i22);
	init_label(mercury__rl_dump__write_instruction_5_0_i23);
	init_label(mercury__rl_dump__write_instruction_5_0_i24);
	init_label(mercury__rl_dump__write_instruction_5_0_i25);
	init_label(mercury__rl_dump__write_instruction_5_0_i26);
	init_label(mercury__rl_dump__write_instruction_5_0_i27);
	init_label(mercury__rl_dump__write_instruction_5_0_i28);
	init_label(mercury__rl_dump__write_instruction_5_0_i29);
	init_label(mercury__rl_dump__write_instruction_5_0_i30);
	init_label(mercury__rl_dump__write_instruction_5_0_i31);
	init_label(mercury__rl_dump__write_instruction_5_0_i32);
	init_label(mercury__rl_dump__write_instruction_5_0_i35);
	init_label(mercury__rl_dump__write_instruction_5_0_i36);
	init_label(mercury__rl_dump__write_instruction_5_0_i37);
	init_label(mercury__rl_dump__write_instruction_5_0_i38);
	init_label(mercury__rl_dump__write_instruction_5_0_i39);
	init_label(mercury__rl_dump__write_instruction_5_0_i40);
	init_label(mercury__rl_dump__write_instruction_5_0_i41);
	init_label(mercury__rl_dump__write_instruction_5_0_i42);
	init_label(mercury__rl_dump__write_instruction_5_0_i43);
	init_label(mercury__rl_dump__write_instruction_5_0_i44);
	init_label(mercury__rl_dump__write_instruction_5_0_i47);
	init_label(mercury__rl_dump__write_instruction_5_0_i48);
	init_label(mercury__rl_dump__write_instruction_5_0_i49);
	init_label(mercury__rl_dump__write_instruction_5_0_i50);
	init_label(mercury__rl_dump__write_instruction_5_0_i51);
	init_label(mercury__rl_dump__write_instruction_5_0_i52);
	init_label(mercury__rl_dump__write_instruction_5_0_i53);
	init_label(mercury__rl_dump__write_instruction_5_0_i54);
	init_label(mercury__rl_dump__write_instruction_5_0_i55);
	init_label(mercury__rl_dump__write_instruction_5_0_i56);
	init_label(mercury__rl_dump__write_instruction_5_0_i57);
	init_label(mercury__rl_dump__write_instruction_5_0_i58);
	init_label(mercury__rl_dump__write_instruction_5_0_i61);
	init_label(mercury__rl_dump__write_instruction_5_0_i62);
	init_label(mercury__rl_dump__write_instruction_5_0_i63);
	init_label(mercury__rl_dump__write_instruction_5_0_i64);
	init_label(mercury__rl_dump__write_instruction_5_0_i65);
	init_label(mercury__rl_dump__write_instruction_5_0_i66);
	init_label(mercury__rl_dump__write_instruction_5_0_i67);
	init_label(mercury__rl_dump__write_instruction_5_0_i68);
	init_label(mercury__rl_dump__write_instruction_5_0_i71);
	init_label(mercury__rl_dump__write_instruction_5_0_i72);
	init_label(mercury__rl_dump__write_instruction_5_0_i73);
	init_label(mercury__rl_dump__write_instruction_5_0_i74);
	init_label(mercury__rl_dump__write_instruction_5_0_i75);
	init_label(mercury__rl_dump__write_instruction_5_0_i76);
	init_label(mercury__rl_dump__write_instruction_5_0_i77);
	init_label(mercury__rl_dump__write_instruction_5_0_i78);
	init_label(mercury__rl_dump__write_instruction_5_0_i79);
	init_label(mercury__rl_dump__write_instruction_5_0_i80);
	init_label(mercury__rl_dump__write_instruction_5_0_i81);
	init_label(mercury__rl_dump__write_instruction_5_0_i82);
	init_label(mercury__rl_dump__write_instruction_5_0_i83);
	init_label(mercury__rl_dump__write_instruction_5_0_i86);
	init_label(mercury__rl_dump__write_instruction_5_0_i87);
	init_label(mercury__rl_dump__write_instruction_5_0_i88);
	init_label(mercury__rl_dump__write_instruction_5_0_i89);
	init_label(mercury__rl_dump__write_instruction_5_0_i90);
	init_label(mercury__rl_dump__write_instruction_5_0_i91);
	init_label(mercury__rl_dump__write_instruction_5_0_i92);
	init_label(mercury__rl_dump__write_instruction_5_0_i93);
	init_label(mercury__rl_dump__write_instruction_5_0_i94);
	init_label(mercury__rl_dump__write_instruction_5_0_i95);
	init_label(mercury__rl_dump__write_instruction_5_0_i96);
	init_label(mercury__rl_dump__write_instruction_5_0_i97);
	init_label(mercury__rl_dump__write_instruction_5_0_i100);
	init_label(mercury__rl_dump__write_instruction_5_0_i101);
	init_label(mercury__rl_dump__write_instruction_5_0_i102);
	init_label(mercury__rl_dump__write_instruction_5_0_i103);
	init_label(mercury__rl_dump__write_instruction_5_0_i104);
	init_label(mercury__rl_dump__write_instruction_5_0_i105);
	init_label(mercury__rl_dump__write_instruction_5_0_i106);
	init_label(mercury__rl_dump__write_instruction_5_0_i109);
	init_label(mercury__rl_dump__write_instruction_5_0_i110);
	init_label(mercury__rl_dump__write_instruction_5_0_i111);
	init_label(mercury__rl_dump__write_instruction_5_0_i112);
	init_label(mercury__rl_dump__write_instruction_5_0_i113);
	init_label(mercury__rl_dump__write_instruction_5_0_i116);
	init_label(mercury__rl_dump__write_instruction_5_0_i117);
	init_label(mercury__rl_dump__write_instruction_5_0_i118);
	init_label(mercury__rl_dump__write_instruction_5_0_i119);
	init_label(mercury__rl_dump__write_instruction_5_0_i120);
	init_label(mercury__rl_dump__write_instruction_5_0_i123);
	init_label(mercury__rl_dump__write_instruction_5_0_i124);
	init_label(mercury__rl_dump__write_instruction_5_0_i125);
	init_label(mercury__rl_dump__write_instruction_5_0_i126);
	init_label(mercury__rl_dump__write_instruction_5_0_i127);
	init_label(mercury__rl_dump__write_instruction_5_0_i130);
	init_label(mercury__rl_dump__write_instruction_5_0_i131);
	init_label(mercury__rl_dump__write_instruction_5_0_i132);
	init_label(mercury__rl_dump__write_instruction_5_0_i133);
	init_label(mercury__rl_dump__write_instruction_5_0_i136);
	init_label(mercury__rl_dump__write_instruction_5_0_i137);
	init_label(mercury__rl_dump__write_instruction_5_0_i138);
	init_label(mercury__rl_dump__write_instruction_5_0_i139);
	init_label(mercury__rl_dump__write_instruction_5_0_i140);
	init_label(mercury__rl_dump__write_instruction_5_0_i141);
	init_label(mercury__rl_dump__write_instruction_5_0_i142);
	init_label(mercury__rl_dump__write_instruction_5_0_i143);
	init_label(mercury__rl_dump__write_instruction_5_0_i146);
	init_label(mercury__rl_dump__write_instruction_5_0_i147);
	init_label(mercury__rl_dump__write_instruction_5_0_i148);
	init_label(mercury__rl_dump__write_instruction_5_0_i149);
	init_label(mercury__rl_dump__write_instruction_5_0_i150);
	init_label(mercury__rl_dump__write_instruction_5_0_i151);
	init_label(mercury__rl_dump__write_instruction_5_0_i152);
	init_label(mercury__rl_dump__write_instruction_5_0_i153);
	init_label(mercury__rl_dump__write_instruction_5_0_i154);
	init_label(mercury__rl_dump__write_instruction_5_0_i155);
	init_label(mercury__rl_dump__write_instruction_5_0_i156);
	init_label(mercury__rl_dump__write_instruction_5_0_i157);
	init_label(mercury__rl_dump__write_instruction_5_0_i160);
	init_label(mercury__rl_dump__write_instruction_5_0_i161);
	init_label(mercury__rl_dump__write_instruction_5_0_i162);
	init_label(mercury__rl_dump__write_instruction_5_0_i163);
	init_label(mercury__rl_dump__write_instruction_5_0_i164);
	init_label(mercury__rl_dump__write_instruction_5_0_i165);
	init_label(mercury__rl_dump__write_instruction_5_0_i166);
	init_label(mercury__rl_dump__write_instruction_5_0_i167);
	init_label(mercury__rl_dump__write_instruction_5_0_i168);
	init_label(mercury__rl_dump__write_instruction_5_0_i169);
	init_label(mercury__rl_dump__write_instruction_5_0_i170);
	init_label(mercury__rl_dump__write_instruction_5_0_i173);
	init_label(mercury__rl_dump__write_instruction_5_0_i174);
	init_label(mercury__rl_dump__write_instruction_5_0_i175);
	init_label(mercury__rl_dump__write_instruction_5_0_i176);
	init_label(mercury__rl_dump__write_instruction_5_0_i179);
	init_label(mercury__rl_dump__write_instruction_5_0_i180);
	init_label(mercury__rl_dump__write_instruction_5_0_i181);
	init_label(mercury__rl_dump__write_instruction_5_0_i182);
	init_label(mercury__rl_dump__write_instruction_5_0_i185);
	init_label(mercury__rl_dump__write_instruction_5_0_i186);
	init_label(mercury__rl_dump__write_instruction_5_0_i187);
	init_label(mercury__rl_dump__write_instruction_5_0_i188);
	init_label(mercury__rl_dump__write_instruction_5_0_i191);
	init_label(mercury__rl_dump__write_instruction_5_0_i192);
	init_label(mercury__rl_dump__write_instruction_5_0_i193);
	init_label(mercury__rl_dump__write_instruction_5_0_i194);
	init_label(mercury__rl_dump__write_instruction_5_0_i195);
	init_label(mercury__rl_dump__write_instruction_5_0_i198);
	init_label(mercury__rl_dump__write_instruction_5_0_i199);
	init_label(mercury__rl_dump__write_instruction_5_0_i200);
	init_label(mercury__rl_dump__write_instruction_5_0_i201);
	init_label(mercury__rl_dump__write_instruction_5_0_i202);
	init_label(mercury__rl_dump__write_instruction_5_0_i203);
	init_label(mercury__rl_dump__write_instruction_5_0_i204);
	init_label(mercury__rl_dump__write_instruction_5_0_i207);
	init_label(mercury__rl_dump__write_instruction_5_0_i208);
	init_label(mercury__rl_dump__write_instruction_5_0_i209);
	init_label(mercury__rl_dump__write_instruction_5_0_i210);
	init_label(mercury__rl_dump__write_instruction_5_0_i211);
	init_label(mercury__rl_dump__write_instruction_5_0_i212);
BEGIN_CODE

/* code for predicate 'write_instruction'/5 in mode 0 */
Define_entry(mercury__rl_dump__write_instruction_5_0);
	MR_incr_sp_push_msg(8, "rl_dump:write_instruction/5");
	MR_stackvar(8) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r5),
		LABEL(mercury__rl_dump__write_instruction_5_0_i4) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i7) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i21) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i35));
Define_label(mercury__rl_dump__write_instruction_5_0_i4);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_dump__write_instruction_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\n%\n% ", 5);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_dump__write_instruction_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_dump__common_17);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i7);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r5, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r5, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i8,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = join(", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i9,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i10,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i11,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i12,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i13,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_join_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i14,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i15,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i16,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_dump__write_goal_4_0),
		mercury__rl_dump__write_instruction_5_0_i17,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\t", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i18,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i21);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r5, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r5, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i22,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = subtract(", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i23,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i24,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i25,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i26,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i27,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_subtract_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i28,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i29,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i30,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_dump__write_goal_4_0),
		mercury__rl_dump__write_instruction_5_0_i31,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i31);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\t", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i32,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i35);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r5, (Integer) 0),
		LABEL(mercury__rl_dump__write_instruction_5_0_i36) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i47) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i61) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i71) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i86) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i100) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i109) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i116) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i123) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i130) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i136) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i146) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i160) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i173) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i179) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i185) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i191) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i198) AND
		LABEL(mercury__rl_dump__write_instruction_5_0_i207));
Define_label(mercury__rl_dump__write_instruction_5_0_i36);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i37,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i37);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = difference(", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i38,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i38);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i39,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i39);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i40,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i40);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i41,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i41);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i42,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i42);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_difference_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i43,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i43);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\t", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i44,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i44);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i47);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r5, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i48,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i48);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = project(", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i49,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i49);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i50,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i50);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i51,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i51);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_dump__write_project_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i52,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i52);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i53,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i53);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_goal_4_0),
		mercury__rl_dump__write_instruction_5_0_i54,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i54);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i55,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i55);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i56,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i56);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_18);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_string_const(",\n", 2);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_instruction_5_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_19);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_project_output_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_instruction_5_0_i57,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i57);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i58,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i58);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i61);
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i62,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i62);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = union(", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i63,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i63);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_instruction_5_0, "origin_lost_in_value_number");
	r5 = r3;
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_relation_id_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_13);
	call_localret(STATIC(mercury__rl_dump__write_list__ho6__ua0_5_0),
		mercury__rl_dump__write_instruction_5_0_i64,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i64);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i65,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i65);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i66,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i66);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_union_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i67,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i67);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i68,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i68);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i71);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i72,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i72);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = union_diff(", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i73,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i73);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i74,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i74);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" => ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i75,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i75);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i76,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i76);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i77,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i77);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i78,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i78);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i79,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i79);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_index_spec_3_0),
		mercury__rl_dump__write_instruction_5_0_i80,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i80);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i81,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i81);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_20);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__rl_dump__write_instruction_5_0_i82,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i82);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i83,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i83);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i86);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("insert(", 7);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i87,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i87);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i88,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i88);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" => ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i89,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i89);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i90,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i90);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i91,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i91);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i92,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i92);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i93,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i93);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_insert_type__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i94,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i94);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i95,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i95);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_20);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__rl_dump__write_instruction_5_0_i96,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i96);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i97,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i97);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i100);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i101,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i101);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = sort(", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i102,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i102);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i103,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i103);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i104,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i104);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_sort_attr_list_3_0),
		mercury__rl_dump__write_instruction_5_0_i105,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i105);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i106,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i106);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i109);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i110,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i110);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i111,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i111);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i112,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i112);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i113,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i113);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i116);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i117,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i117);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = copy(", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i118,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i118);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i119,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i119);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i120,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i120);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i123);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i124,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i124);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = make_unique(", 15);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i125,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i125);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i126,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i126);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i127,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i127);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i130);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("init(", 5);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i131,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i131);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i132,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i132);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i133,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i133);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i136);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i137,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i137);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = insert_tuple(", 16);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i138,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i138);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i139,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i139);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i140,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i140);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i141,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i141);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_goal_4_0),
		mercury__rl_dump__write_instruction_5_0_i142,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i142);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i143,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i143);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i146);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("call(", 5);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i147,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i147);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl__proc_name_to_string_2_0),
		mercury__rl_dump__write_instruction_5_0_i148,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i148);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i149,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i149);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i150,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i150);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_instruction_5_0, "origin_lost_in_value_number");
	r4 = r1;
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_relation_id_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_13);
	call_localret(STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i151,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i151);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i152,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i152);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_output_rel_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_instruction_5_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_22);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_output_rel_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(2);
	r4 = r3;
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_dump__write_list__ho8__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i153,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i153);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i154,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i154);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_dump__write_instruction_5_0_i155,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i155);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_list__ho7__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i156,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i156);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\n\t", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i157,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i157);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i160);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r5, (Integer) 4);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r5, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i161,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i161);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" = aggregate(", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i162,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i162);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i163,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i163);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i164,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i164);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_instruction_5_0_i165,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i165);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i166,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i166);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r4 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__rl_dump__write_instruction_5_0_i167,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
	}
Define_label(mercury__rl_dump__write_instruction_5_0_i167);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i168,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i168);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r4 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__rl_dump__write_instruction_5_0_i169,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
	}
Define_label(mercury__rl_dump__write_instruction_5_0_i169);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i170,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i170);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i173);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("add_index(", 10);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i174,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i174);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i175,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i175);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i176,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i176);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i179);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("clear(", 6);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i180,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i180);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i181,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i181);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i182,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i182);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i185);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("unset(", 6);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i186,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i186);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i187,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i187);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i188,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i188);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i191);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("\nlabel(", 7);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i192,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i192);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl__label_id_to_string_2_0),
		mercury__rl_dump__write_instruction_5_0_i193,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i193);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i194,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i194);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i195,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i195);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i198);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("conditional_goto(", 17);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i199,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i199);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_dump__write_goto_cond__ua0_4_0),
		mercury__rl_dump__write_instruction_5_0_i200,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i200);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	call_localret(STATIC(mercury__rl_dump__comma_2_0),
		mercury__rl_dump__write_instruction_5_0_i201,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i201);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__rl__label_id_to_string_2_0),
		mercury__rl_dump__write_instruction_5_0_i202,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i202);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i203,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i203);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i204,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i204);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i207);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_string_const("goto(", 5);
	r2 = r4;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i208,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i208);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl__label_id_to_string_2_0),
		mercury__rl_dump__write_instruction_5_0_i209,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i209);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i210,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i210);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_instruction_5_0_i211,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i211);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_comment_3_0),
		mercury__rl_dump__write_instruction_5_0_i212,
		ENTRY(mercury__rl_dump__write_instruction_5_0));
Define_label(mercury__rl_dump__write_instruction_5_0_i212);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_instruction_5_0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__io__nl_2_0),
		ENTRY(mercury__rl_dump__write_instruction_5_0));
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_relation_state_0;
Declare_entry(mercury__varset__init_1_0);

BEGIN_MODULE(rl_dump_module21)
	init_entry(mercury__rl_dump__declare_relation_5_0);
	init_label(mercury__rl_dump__declare_relation_5_0_i2);
	init_label(mercury__rl_dump__declare_relation_5_0_i3);
	init_label(mercury__rl_dump__declare_relation_5_0_i4);
	init_label(mercury__rl_dump__declare_relation_5_0_i5);
	init_label(mercury__rl_dump__declare_relation_5_0_i8);
	init_label(mercury__rl_dump__declare_relation_5_0_i9);
	init_label(mercury__rl_dump__declare_relation_5_0_i10);
	init_label(mercury__rl_dump__declare_relation_5_0_i11);
	init_label(mercury__rl_dump__declare_relation_5_0_i12);
	init_label(mercury__rl_dump__declare_relation_5_0_i13);
	init_label(mercury__rl_dump__declare_relation_5_0_i7);
	init_label(mercury__rl_dump__declare_relation_5_0_i15);
	init_label(mercury__rl_dump__declare_relation_5_0_i16);
	init_label(mercury__rl_dump__declare_relation_5_0_i17);
	init_label(mercury__rl_dump__declare_relation_5_0_i18);
	init_label(mercury__rl_dump__declare_relation_5_0_i19);
	init_label(mercury__rl_dump__declare_relation_5_0_i20);
	init_label(mercury__rl_dump__declare_relation_5_0_i21);
	init_label(mercury__rl_dump__declare_relation_5_0_i22);
	init_label(mercury__rl_dump__declare_relation_5_0_i23);
	init_label(mercury__rl_dump__declare_relation_5_0_i24);
BEGIN_CODE

/* code for predicate 'declare_relation'/5 in mode 0 */
Define_static(mercury__rl_dump__declare_relation_5_0);
	MR_incr_sp_push_msg(6, "rl_dump:declare_relation/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(4) = r4;
	r4 = r3;
	MR_stackvar(3) = r3;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_dump__declare_relation_5_0_i2,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_dump__declare_relation_5_0_i3,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i4,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" : ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i5,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_dump__declare_relation_5_0_i7);
	r2 = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0), (Integer) 0);
	r1 = (Word) MR_string_const("base relation `", 15);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i8,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__rl_dump__declare_relation_5_0_i9,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_dump__declare_relation_5_0_i10,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__rl_dump__declare_relation_5_0_i11,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i12,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("'/", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i13,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_dump__declare_relation_5_0_i17,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = r1;
	r1 = (Word) MR_string_const("temporary (", 11);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i15,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_state_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__rl_dump__declare_relation_5_0_i16,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i17,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__rl_dump__declare_relation_5_0_i18,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const(" ", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i19,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_dump__declare_relation_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r2 = r1;
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("[", 1);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_23);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_dump__IntroducedFrom__pred__declare_relation__97__2_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i20,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__declare_relation_5_0_i21,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i22,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" : ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__declare_relation_5_0_i23,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_index_spec_0;
	r2 = MR_stackvar(5);
	r3 = (Word) MR_string_const(" ", 1);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_3);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__declare_relation_5_0_i24,
		STATIC(mercury__rl_dump__declare_relation_5_0));
Define_label(mercury__rl_dump__declare_relation_5_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_dump__declare_relation_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__declare_relation_5_0));
END_MODULE


BEGIN_MODULE(rl_dump_module22)
	init_entry(mercury__rl_dump__write_key_attr_pair_3_0);
	init_label(mercury__rl_dump__write_key_attr_pair_3_0_i2);
	init_label(mercury__rl_dump__write_key_attr_pair_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_key_attr_pair'/3 in mode 0 */
Define_static(mercury__rl_dump__write_key_attr_pair_3_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_key_attr_pair/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_dump__write_key_attr_pair_3_0_i2,
		STATIC(mercury__rl_dump__write_key_attr_pair_3_0));
Define_label(mercury__rl_dump__write_key_attr_pair_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_attr_pair_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" - ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_attr_pair_3_0_i3,
		STATIC(mercury__rl_dump__write_key_attr_pair_3_0));
Define_label(mercury__rl_dump__write_key_attr_pair_3_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_attr_pair_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__rl_dump__write_key_attr_3_0),
		STATIC(mercury__rl_dump__write_key_attr_pair_3_0));
END_MODULE

Declare_entry(mercury__hlds_out__write_cons_id_3_0);

BEGIN_MODULE(rl_dump_module23)
	init_entry(mercury__rl_dump__write_key_attr_3_0);
	init_label(mercury__rl_dump__write_key_attr_3_0_i4);
	init_label(mercury__rl_dump__write_key_attr_3_0_i5);
	init_label(mercury__rl_dump__write_key_attr_3_0_i6);
	init_label(mercury__rl_dump__write_key_attr_3_0_i7);
BEGIN_CODE

/* code for predicate 'write_key_attr'/3 in mode 0 */
Define_static(mercury__rl_dump__write_key_attr_3_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_key_attr/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_dump__write_key_attr_3_0_i4);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_dump__write_key_attr_3_0));
Define_label(mercury__rl_dump__write_key_attr_3_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_out__write_cons_id_3_0),
		mercury__rl_dump__write_key_attr_3_0_i5,
		STATIC(mercury__rl_dump__write_key_attr_3_0));
Define_label(mercury__rl_dump__write_key_attr_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_attr_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_attr_3_0_i6,
		STATIC(mercury__rl_dump__write_key_attr_3_0));
Define_label(mercury__rl_dump__write_key_attr_3_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_attr_3_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_28);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_key_attr_3_0_i7,
		STATIC(mercury__rl_dump__write_key_attr_3_0));
Define_label(mercury__rl_dump__write_key_attr_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_attr_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_key_attr_3_0));
END_MODULE


BEGIN_MODULE(rl_dump_module24)
	init_entry(mercury__rl_dump__write_sort_spec_3_0);
	init_label(mercury__rl_dump__write_sort_spec_3_0_i4);
	init_label(mercury__rl_dump__write_sort_spec_3_0_i5);
	init_label(mercury__rl_dump__write_sort_spec_3_0_i3);
	init_label(mercury__rl_dump__write_sort_spec_3_0_i7);
	init_label(mercury__rl_dump__write_sort_spec_3_0_i8);
BEGIN_CODE

/* code for predicate 'write_sort_spec'/3 in mode 0 */
Define_static(mercury__rl_dump__write_sort_spec_3_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_sort_spec/3");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_dump__write_sort_spec_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_string_const("sort_var(", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_sort_spec_3_0_i4,
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
Define_label(mercury__rl_dump__write_sort_spec_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_spec_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_dump__write_sort_spec_3_0_i5,
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
Define_label(mercury__rl_dump__write_sort_spec_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_spec_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
Define_label(mercury__rl_dump__write_sort_spec_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("[", 1);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_sort_spec_3_0_i7,
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
Define_label(mercury__rl_dump__write_sort_spec_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_spec_3_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_30);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_sort_spec_3_0_i8,
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
Define_label(mercury__rl_dump__write_sort_spec_3_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_spec_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_sort_spec_3_0));
END_MODULE


BEGIN_MODULE(rl_dump_module25)
	init_entry(mercury__rl_dump__write_sort_attr_list_3_0);
	init_label(mercury__rl_dump__write_sort_attr_list_3_0_i2);
	init_label(mercury__rl_dump__write_sort_attr_list_3_0_i3);
BEGIN_CODE

/* code for predicate 'write_sort_attr_list'/3 in mode 0 */
Define_static(mercury__rl_dump__write_sort_attr_list_3_0);
	MR_incr_sp_push_msg(3, "rl_dump:write_sort_attr_list/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("[", 1);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_sort_attr_list_3_0_i2,
		STATIC(mercury__rl_dump__write_sort_attr_list_3_0));
Define_label(mercury__rl_dump__write_sort_attr_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_attr_list_3_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_30);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_sort_attr_list_3_0_i3,
		STATIC(mercury__rl_dump__write_sort_attr_list_3_0));
Define_label(mercury__rl_dump__write_sort_attr_list_3_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_sort_attr_list_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_sort_attr_list_3_0));
END_MODULE


BEGIN_MODULE(rl_dump_module26)
	init_entry(mercury__rl_dump__write_comment_3_0);
	init_label(mercury__rl_dump__write_comment_3_0_i2);
	init_label(mercury__rl_dump__write_comment_3_0_i4);
BEGIN_CODE

/* code for predicate 'write_comment'/3 in mode 0 */
Define_static(mercury__rl_dump__write_comment_3_0);
	MR_incr_sp_push_msg(2, "rl_dump:write_comment/3");
	MR_stackvar(2) = (Word) MR_succip;
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("", 0)) != 0))
		GOTO_LABEL(mercury__rl_dump__write_comment_3_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_dump__write_comment_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("% ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_comment_3_0_i4,
		STATIC(mercury__rl_dump__write_comment_3_0));
Define_label(mercury__rl_dump__write_comment_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_comment_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_comment_3_0));
END_MODULE


BEGIN_MODULE(rl_dump_module27)
	init_entry(mercury__rl_dump__write_output_rel_4_0);
BEGIN_CODE

/* code for predicate 'write_output_rel'/4 in mode 0 */
Define_static(mercury__rl_dump__write_output_rel_4_0);
	r1 = r2;
	r2 = r3;
	tailcall(STATIC(mercury__rl_dump__write_output_rel__ua0_4_0),
		STATIC(mercury__rl_dump__write_output_rel_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module28)
	init_entry(mercury__rl_dump__write_relation_id_4_0);
BEGIN_CODE

/* code for predicate 'write_relation_id'/4 in mode 0 */
Define_static(mercury__rl_dump__write_relation_id_4_0);
	r1 = r2;
	r2 = r3;
	tailcall(STATIC(mercury__rl_dump__write_relation_id__ua0_4_0),
		STATIC(mercury__rl_dump__write_relation_id_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module29)
	init_entry(mercury__rl_dump__write_project_output_5_0);
BEGIN_CODE

/* code for predicate 'write_project_output'/5 in mode 0 */
Define_static(mercury__rl_dump__write_project_output_5_0);
	r2 = r3;
	r3 = r4;
	tailcall(STATIC(mercury__rl_dump__write_project_output__ua0_5_0),
		STATIC(mercury__rl_dump__write_project_output_5_0));
END_MODULE

Declare_entry(mercury__hlds_out__write_goal_list_9_0);

BEGIN_MODULE(rl_dump_module30)
	init_entry(mercury__rl_dump__write_goal_4_0);
	init_label(mercury__rl_dump__write_goal_4_0_i14);
	init_label(mercury__rl_dump__write_goal_4_0_i15);
	init_label(mercury__rl_dump__write_goal_4_0_i16);
	init_label(mercury__rl_dump__write_goal_4_0_i17);
	init_label(mercury__rl_dump__write_goal_4_0_i18);
	init_label(mercury__rl_dump__write_goal_4_0_i19);
	init_label(mercury__rl_dump__write_goal_4_0_i4);
	init_label(mercury__rl_dump__write_goal_4_0_i5);
	init_label(mercury__rl_dump__write_goal_4_0_i6);
	init_label(mercury__rl_dump__write_goal_4_0_i7);
	init_label(mercury__rl_dump__write_goal_4_0_i9);
	init_label(mercury__rl_dump__write_goal_4_0_i26);
	init_label(mercury__rl_dump__write_goal_4_0_i29);
	init_label(mercury__rl_dump__write_goal_4_0_i30);
	init_label(mercury__rl_dump__write_goal_4_0_i27);
BEGIN_CODE

/* code for predicate 'write_goal'/4 in mode 0 */
Define_static(mercury__rl_dump__write_goal_4_0);
	MR_incr_sp_push_msg(8, "rl_dump:write_goal/4");
	MR_stackvar(8) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	if ((MR_tag(r4) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_dump__write_goal_4_0_i4);
	if ((MR_tag(r4) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_dump__write_goal_4_0_i14);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) MR_string_const("\n", 1);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i26,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i14);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r4, (Integer) 1);
	r1 = (Word) MR_string_const("\tinputs: ", 9);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i15,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_dump__write_var_list_4_0),
		mercury__rl_dump__write_goal_4_0_i16,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" ", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i17,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_dump__write_var_list_4_0),
		mercury__rl_dump__write_goal_4_0_i18,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i19,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_goal_4_0_i9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_goal_4_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_35);
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_bounds_5_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_37);
	call_localret(STATIC(mercury__rl_dump__write_list__ho2__ua0_4_0),
		mercury__rl_dump__write_goal_4_0_i9,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = (Word) MR_string_const("\tinputs: ", 9);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i5,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_dump__write_var_list_4_0),
		mercury__rl_dump__write_goal_4_0_i6,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i7,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_goal_4_0_i9);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_35);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_goal_4_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_37);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_bounds_5_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(2);
	r4 = r3;
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_dump__write_list__ho2__ua0_4_0),
		mercury__rl_dump__write_goal_4_0_i9,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i26,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	if (((Integer) MR_stackvar(3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_goal_4_0_i27);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_stackvar(3), (Integer) 0);
	r2 = r1;
	r1 = (Word) MR_string_const("\toutputs: ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_goal_4_0_i29,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_dump__write_var_list_4_0),
		mercury__rl_dump__write_goal_4_0_i30,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_dump__write_goal_4_0_i27,
		STATIC(mercury__rl_dump__write_goal_4_0));
Define_label(mercury__rl_dump__write_goal_4_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_goal_4_0));
	r8 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = (Integer) 1;
	r5 = (Integer) 2;
	r6 = (Word) MR_string_const(",\n", 2);
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__hlds_out__write_goal_list_9_0),
		STATIC(mercury__rl_dump__write_goal_4_0));
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(rl_dump_module31)
	init_entry(mercury__rl_dump__write_bounds_5_0);
	init_label(mercury__rl_dump__write_bounds_5_0_i2);
	init_label(mercury__rl_dump__write_bounds_5_0_i3);
	init_label(mercury__rl_dump__write_bounds_5_0_i4);
	init_label(mercury__rl_dump__write_bounds_5_0_i5);
BEGIN_CODE

/* code for predicate 'write_bounds'/5 in mode 0 */
Define_static(mercury__rl_dump__write_bounds_5_0);
	MR_incr_sp_push_msg(4, "rl_dump:write_bounds/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_34);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__rl_dump__write_bounds_5_0_i2,
		STATIC(mercury__rl_dump__write_bounds_5_0));
Define_label(mercury__rl_dump__write_bounds_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bounds_5_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("\n\t[", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_bounds_5_0_i3,
		STATIC(mercury__rl_dump__write_bounds_5_0));
Define_label(mercury__rl_dump__write_bounds_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bounds_5_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_bounds_5_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_38);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("\n\t", 2);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_bound_pair_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_39);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_bounds_5_0_i4,
		STATIC(mercury__rl_dump__write_bounds_5_0));
Define_label(mercury__rl_dump__write_bounds_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bounds_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t]", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_bounds_5_0_i5,
		STATIC(mercury__rl_dump__write_bounds_5_0));
Define_label(mercury__rl_dump__write_bounds_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bounds_5_0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__nl_2_0),
		STATIC(mercury__rl_dump__write_bounds_5_0));
END_MODULE


BEGIN_MODULE(rl_dump_module32)
	init_entry(mercury__rl_dump__write_bound_pair_5_0);
	init_label(mercury__rl_dump__write_bound_pair_5_0_i2);
	init_label(mercury__rl_dump__write_bound_pair_5_0_i3);
	init_label(mercury__rl_dump__write_bound_pair_5_0_i4);
	init_label(mercury__rl_dump__write_bound_pair_5_0_i5);
BEGIN_CODE

/* code for predicate 'write_bound_pair'/5 in mode 0 */
Define_static(mercury__rl_dump__write_bound_pair_5_0);
	MR_incr_sp_push_msg(5, "rl_dump:write_bound_pair/5");
	MR_stackvar(5) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r3 = MR_stackvar(2);
	r5 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r4 = (Integer) 1;
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_var_5_0),
		mercury__rl_dump__write_bound_pair_5_0_i2,
		STATIC(mercury__rl_dump__write_bound_pair_5_0));
	}
Define_label(mercury__rl_dump__write_bound_pair_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bound_pair_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" -> ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_bound_pair_5_0_i3,
		STATIC(mercury__rl_dump__write_bound_pair_5_0));
Define_label(mercury__rl_dump__write_bound_pair_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bound_pair_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_dump__write_key_term_5_0),
		mercury__rl_dump__write_bound_pair_5_0_i4,
		STATIC(mercury__rl_dump__write_bound_pair_5_0));
Define_label(mercury__rl_dump__write_bound_pair_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bound_pair_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" - ", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_bound_pair_5_0_i5,
		STATIC(mercury__rl_dump__write_bound_pair_5_0));
Define_label(mercury__rl_dump__write_bound_pair_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_bound_pair_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_dump__write_key_term_5_0),
		STATIC(mercury__rl_dump__write_bound_pair_5_0));
END_MODULE


BEGIN_MODULE(rl_dump_module33)
	init_entry(mercury__rl_dump__write_key_term_5_0);
	init_label(mercury__rl_dump__write_key_term_5_0_i4);
	init_label(mercury__rl_dump__write_key_term_5_0_i5);
	init_label(mercury__rl_dump__write_key_term_5_0_i8);
	init_label(mercury__rl_dump__write_key_term_5_0_i3);
	init_label(mercury__rl_dump__write_key_term_5_0_i11);
	init_label(mercury__rl_dump__write_key_term_5_0_i12);
	init_label(mercury__rl_dump__write_key_term_5_0_i13);
	init_label(mercury__rl_dump__write_key_term_5_0_i14);
	init_label(mercury__rl_dump__write_key_term_5_0_i15);
	init_label(mercury__rl_dump__write_key_term_5_0_i16);
	init_label(mercury__rl_dump__write_key_term_5_0_i17);
BEGIN_CODE

/* code for predicate 'write_key_term'/5 in mode 0 */
Define_static(mercury__rl_dump__write_key_term_5_0);
	MR_incr_sp_push_msg(5, "rl_dump:write_key_term/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_key_term_5_0_i3);
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31);
	MR_stackvar(1) = r4;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_dump__write_key_term_5_0_i4,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_dump__write_key_term_5_0_i5);
	r1 = (Word) MR_string_const("infinity", 8);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i5);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("var", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_term_5_0_i8,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_dump__write_var_list_4_0),
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	call_localret(ENTRY(mercury__hlds_out__write_cons_id_3_0),
		mercury__rl_dump__write_key_term_5_0_i11,
		STATIC(mercury__rl_dump__write_key_term_5_0));
	}
Define_label(mercury__rl_dump__write_key_term_5_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("(", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_term_5_0_i12,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 5, mercury__rl_dump__write_key_term_5_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_33);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const(", ", 2);
	MR_field(MR_mktag(0), r4, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_dump__write_key_term_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_40);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_key_term_5_0_i13,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(")", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_term_5_0_i14,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_dump__write_key_term_5_0_i15,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_key_term_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	r1 = (Word) MR_string_const("[", 1);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_41);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_key_term_5_0_i16,
		STATIC(mercury__rl_dump__write_key_term_5_0));
	}
Define_label(mercury__rl_dump__write_key_term_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_key_term_5_0_i17,
		STATIC(mercury__rl_dump__write_key_term_5_0));
Define_label(mercury__rl_dump__write_key_term_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_key_term_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_key_term_5_0));
END_MODULE


BEGIN_MODULE(rl_dump_module34)
	init_entry(mercury__rl_dump__write_var_list_4_0);
	init_label(mercury__rl_dump__write_var_list_4_0_i2);
	init_label(mercury__rl_dump__write_var_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_var_list'/4 in mode 0 */
Define_static(mercury__rl_dump__write_var_list_4_0);
	MR_incr_sp_push_msg(4, "rl_dump:write_var_list/4");
	MR_stackvar(4) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__rl_dump__write_var_list_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	r1 = (Word) MR_string_const("[", 1);
	r2 = r3;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_31);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_dump__IntroducedFrom__pred__write_var_list__686__4_4_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_dump__common_41);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_dump__write_var_list_4_0_i2,
		STATIC(mercury__rl_dump__write_var_list_4_0));
	}
Define_label(mercury__rl_dump__write_var_list_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_var_list_4_0));
	r5 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_dump__write_var_list_4_0_i3,
		STATIC(mercury__rl_dump__write_var_list_4_0));
Define_label(mercury__rl_dump__write_var_list_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_dump__write_var_list_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("]", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__write_var_list_4_0));
END_MODULE


BEGIN_MODULE(rl_dump_module35)
	init_entry(mercury__rl_dump__comma_2_0);
BEGIN_CODE

/* code for predicate 'comma'/2 in mode 0 */
Define_static(mercury__rl_dump__comma_2_0);
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_dump__comma_2_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_dump_maybe_bunch_0(void)
{
	rl_dump_module0();
	rl_dump_module1();
	rl_dump_module2();
	rl_dump_module3();
	rl_dump_module4();
	rl_dump_module5();
	rl_dump_module6();
	rl_dump_module7();
	rl_dump_module8();
	rl_dump_module9();
	rl_dump_module10();
	rl_dump_module11();
	rl_dump_module12();
	rl_dump_module13();
	rl_dump_module14();
	rl_dump_module15();
	rl_dump_module16();
	rl_dump_module17();
	rl_dump_module18();
	rl_dump_module19();
	rl_dump_module20();
	rl_dump_module21();
	rl_dump_module22();
	rl_dump_module23();
	rl_dump_module24();
	rl_dump_module25();
	rl_dump_module26();
	rl_dump_module27();
	rl_dump_module28();
	rl_dump_module29();
	rl_dump_module30();
	rl_dump_module31();
	rl_dump_module32();
	rl_dump_module33();
	rl_dump_module34();
	rl_dump_module35();
}

#endif

void mercury__rl_dump__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_dump__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_dump_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
