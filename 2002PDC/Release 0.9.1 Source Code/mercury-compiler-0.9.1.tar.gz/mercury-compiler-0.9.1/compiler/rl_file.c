/*
** Automatically generated from `rl_file.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_file__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___rl_file__expression_0__ua0_2_0);
Declare_static(mercury____Index___rl_file__procedure_0__ua0_2_0);
Declare_static(mercury____Index___rl_file__variable_0__ua0_2_0);
Declare_static(mercury____Index___rl_file__relation_0__ua0_2_0);
Declare_static(mercury____Index___rl_file__rl_file_0__ua0_2_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_exprn_2__508__7_3_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_proc__469__6_3_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0);
Declare_label(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0_i2);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_text__409__4_3_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_text__402__3_3_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_text__395__2_3_0);
Declare_static(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0);
Declare_label(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0_i2);
Define_extern_entry(mercury__rl_file__write_binary_5_0);
Declare_label(mercury__rl_file__write_binary_5_0_i2);
Define_extern_entry(mercury__rl_file__write_text_3_0);
Declare_label(mercury__rl_file__write_text_3_0_i2);
Declare_label(mercury__rl_file__write_text_3_0_i3);
Declare_label(mercury__rl_file__write_text_3_0_i4);
Declare_label(mercury__rl_file__write_text_3_0_i5);
Declare_label(mercury__rl_file__write_text_3_0_i6);
Declare_label(mercury__rl_file__write_text_3_0_i7);
Declare_label(mercury__rl_file__write_text_3_0_i8);
Declare_label(mercury__rl_file__write_text_3_0_i9);
Declare_label(mercury__rl_file__write_text_3_0_i10);
Declare_label(mercury__rl_file__write_text_3_0_i11);
Declare_label(mercury__rl_file__write_text_3_0_i12);
Declare_label(mercury__rl_file__write_text_3_0_i13);
Declare_label(mercury__rl_file__write_text_3_0_i14);
Declare_label(mercury__rl_file__write_text_3_0_i15);
Declare_label(mercury__rl_file__write_text_3_0_i16);
Declare_label(mercury__rl_file__write_text_3_0_i17);
Declare_label(mercury__rl_file__write_text_3_0_i18);
Declare_label(mercury__rl_file__write_text_3_0_i19);
Declare_label(mercury__rl_file__write_text_3_0_i20);
Declare_label(mercury__rl_file__write_text_3_0_i21);
Declare_label(mercury__rl_file__write_text_3_0_i22);
Declare_label(mercury__rl_file__write_text_3_0_i23);
Declare_label(mercury__rl_file__write_text_3_0_i24);
Declare_label(mercury__rl_file__write_text_3_0_i25);
Declare_label(mercury__rl_file__write_text_3_0_i26);
Declare_label(mercury__rl_file__write_text_3_0_i27);
Declare_label(mercury__rl_file__write_text_3_0_i28);
Declare_label(mercury__rl_file__write_text_3_0_i29);
Declare_label(mercury__rl_file__write_text_3_0_i30);
Declare_label(mercury__rl_file__write_text_3_0_i31);
Declare_label(mercury__rl_file__write_text_3_0_i32);
Declare_label(mercury__rl_file__write_text_3_0_i33);
Declare_label(mercury__rl_file__write_text_3_0_i34);
Declare_label(mercury__rl_file__write_text_3_0_i35);
Declare_label(mercury__rl_file__write_text_3_0_i36);
Declare_label(mercury__rl_file__write_text_3_0_i37);
Declare_label(mercury__rl_file__write_text_3_0_i38);
Declare_label(mercury__rl_file__write_text_3_0_i39);
Declare_static(mercury__rl_file__write_binary_2_4_0);
Declare_label(mercury__rl_file__write_binary_2_4_0_i2);
Declare_label(mercury__rl_file__write_binary_2_4_0_i3);
Declare_label(mercury__rl_file__write_binary_2_4_0_i4);
Declare_label(mercury__rl_file__write_binary_2_4_0_i5);
Declare_label(mercury__rl_file__write_binary_2_4_0_i6);
Declare_label(mercury__rl_file__write_binary_2_4_0_i7);
Declare_label(mercury__rl_file__write_binary_2_4_0_i8);
Declare_label(mercury__rl_file__write_binary_2_4_0_i9);
Declare_label(mercury__rl_file__write_binary_2_4_0_i10);
Declare_label(mercury__rl_file__write_binary_2_4_0_i11);
Declare_label(mercury__rl_file__write_binary_2_4_0_i12);
Declare_label(mercury__rl_file__write_binary_2_4_0_i13);
Declare_label(mercury__rl_file__write_binary_2_4_0_i14);
Declare_label(mercury__rl_file__write_binary_2_4_0_i15);
Declare_label(mercury__rl_file__write_binary_2_4_0_i16);
Declare_label(mercury__rl_file__write_binary_2_4_0_i17);
Declare_label(mercury__rl_file__write_binary_2_4_0_i18);
Declare_label(mercury__rl_file__write_binary_2_4_0_i19);
Declare_label(mercury__rl_file__write_binary_2_4_0_i20);
Declare_label(mercury__rl_file__write_binary_2_4_0_i21);
Declare_label(mercury__rl_file__write_binary_2_4_0_i22);
Declare_label(mercury__rl_file__write_binary_2_4_0_i23);
Declare_label(mercury__rl_file__write_binary_2_4_0_i24);
Declare_label(mercury__rl_file__write_binary_2_4_0_i25);
Declare_label(mercury__rl_file__write_binary_2_4_0_i26);
Declare_label(mercury__rl_file__write_binary_2_4_0_i27);
Declare_label(mercury__rl_file__write_binary_2_4_0_i28);
Declare_static(mercury__rl_file__write_char_4_0);
Declare_label(mercury__rl_file__write_char_4_0_i2);
Declare_static(mercury__rl_file__write_relation_4_0);
Declare_label(mercury__rl_file__write_relation_4_0_i2);
Declare_label(mercury__rl_file__write_relation_4_0_i3);
Declare_static(mercury__rl_file__write_variable_4_0);
Declare_label(mercury__rl_file__write_variable_4_0_i2);
Declare_label(mercury__rl_file__write_variable_4_0_i3);
Declare_label(mercury__rl_file__write_variable_4_0_i4);
Declare_static(mercury__rl_file__generate_const_table_entry_4_0);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i14);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i15);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i16);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i9);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i10);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i11);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i12);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i4);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i5);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i6);
Declare_label(mercury__rl_file__generate_const_table_entry_4_0_i7);
Declare_static(mercury__rl_file__write_proc_bytecode_4_0);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i2);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i3);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i4);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i5);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i6);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i7);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i8);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i9);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i10);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i11);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i12);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i13);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i14);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i15);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i16);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i17);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i18);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i19);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i20);
Declare_label(mercury__rl_file__write_proc_bytecode_4_0_i21);
Declare_static(mercury__rl_file__write_exprn_bytecode_4_0);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i2);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i3);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i4);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i5);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i6);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i8);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i9);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i10);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i11);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i12);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i13);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i14);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i15);
Declare_label(mercury__rl_file__write_exprn_bytecode_4_0_i16);
Declare_static(mercury__rl_file__output_bytecodes_4_0);
Declare_static(mercury__rl_file__write_proc_4_0);
Declare_label(mercury__rl_file__write_proc_4_0_i2);
Declare_label(mercury__rl_file__write_proc_4_0_i3);
Declare_label(mercury__rl_file__write_proc_4_0_i5);
Declare_label(mercury__rl_file__write_proc_4_0_i7);
Declare_label(mercury__rl_file__write_proc_4_0_i8);
Declare_label(mercury__rl_file__write_proc_4_0_i9);
Declare_label(mercury__rl_file__write_proc_4_0_i10);
Declare_label(mercury__rl_file__write_proc_4_0_i11);
Declare_label(mercury__rl_file__write_proc_4_0_i12);
Declare_label(mercury__rl_file__write_proc_4_0_i13);
Declare_label(mercury__rl_file__write_proc_4_0_i14);
Declare_label(mercury__rl_file__write_proc_4_0_i15);
Declare_label(mercury__rl_file__write_proc_4_0_i16);
Declare_label(mercury__rl_file__write_proc_4_0_i17);
Declare_label(mercury__rl_file__write_proc_4_0_i18);
Declare_label(mercury__rl_file__write_proc_4_0_i19);
Declare_label(mercury__rl_file__write_proc_4_0_i20);
Declare_label(mercury__rl_file__write_proc_4_0_i21);
Declare_label(mercury__rl_file__write_proc_4_0_i22);
Declare_label(mercury__rl_file__write_proc_4_0_i23);
Declare_label(mercury__rl_file__write_proc_4_0_i26);
Declare_label(mercury__rl_file__write_proc_4_0_i27);
Declare_label(mercury__rl_file__write_proc_4_0_i24);
Declare_label(mercury__rl_file__write_proc_4_0_i29);
Declare_label(mercury__rl_file__write_proc_4_0_i30);
Declare_label(mercury__rl_file__write_proc_4_0_i31);
Declare_label(mercury__rl_file__write_proc_4_0_i32);
Declare_static(mercury__rl_file__write_exprn_5_0);
Declare_label(mercury__rl_file__write_exprn_5_0_i2);
Declare_label(mercury__rl_file__write_exprn_5_0_i3);
Declare_label(mercury__rl_file__write_exprn_5_0_i4);
Declare_label(mercury__rl_file__write_exprn_5_0_i5);
Declare_label(mercury__rl_file__write_exprn_5_0_i6);
Declare_label(mercury__rl_file__write_exprn_5_0_i7);
Declare_label(mercury__rl_file__write_exprn_5_0_i8);
Declare_label(mercury__rl_file__write_exprn_5_0_i9);
Declare_label(mercury__rl_file__write_exprn_5_0_i10);
Declare_label(mercury__rl_file__write_exprn_5_0_i11);
Declare_label(mercury__rl_file__write_exprn_5_0_i12);
Declare_label(mercury__rl_file__write_exprn_5_0_i13);
Declare_label(mercury__rl_file__write_exprn_5_0_i14);
Declare_label(mercury__rl_file__write_exprn_5_0_i15);
Declare_label(mercury__rl_file__write_exprn_5_0_i16);
Declare_label(mercury__rl_file__write_exprn_5_0_i17);
Declare_label(mercury__rl_file__write_exprn_5_0_i18);
Declare_label(mercury__rl_file__write_exprn_5_0_i19);
Declare_label(mercury__rl_file__write_exprn_5_0_i20);
Declare_label(mercury__rl_file__write_exprn_5_0_i21);
Declare_label(mercury__rl_file__write_exprn_5_0_i22);
Declare_label(mercury__rl_file__write_exprn_5_0_i23);
Declare_static(mercury__rl_file__write_exprn_2_4_0);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i2);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i3);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i4);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i5);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i6);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i7);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i8);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i9);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i10);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i11);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i12);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i13);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i14);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i15);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i16);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i17);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i18);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i19);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i20);
Declare_label(mercury__rl_file__write_exprn_2_4_0_i21);
Define_extern_entry(mercury____Unify___rl_file__byte_writer_0_0);
Define_extern_entry(mercury____Index___rl_file__byte_writer_0_0);
Define_extern_entry(mercury____Compare___rl_file__byte_writer_0_0);
Define_extern_entry(mercury____Unify___rl_file__rl_file_0_0);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i2);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i4);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i6);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i8);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i1017);
Declare_label(mercury____Unify___rl_file__rl_file_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__rl_file_0_0);
Define_extern_entry(mercury____Compare___rl_file__rl_file_0_0);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i3);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i7);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i11);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i15);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i19);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i23);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i27);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i31);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i35);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i39);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i43);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i47);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i51);
Declare_label(mercury____Compare___rl_file__rl_file_0_0_i67);
Define_extern_entry(mercury____Unify___rl_file__constant_pool_0_0);
Define_extern_entry(mercury____Index___rl_file__constant_pool_0_0);
Define_extern_entry(mercury____Compare___rl_file__constant_pool_0_0);
Define_extern_entry(mercury____Unify___rl_file__rl_const_0_0);
Declare_label(mercury____Unify___rl_file__rl_const_0_0_i6);
Declare_label(mercury____Unify___rl_file__rl_const_0_0_i4);
Declare_label(mercury____Unify___rl_file__rl_const_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__rl_const_0_0);
Declare_label(mercury____Index___rl_file__rl_const_0_0_i5);
Declare_label(mercury____Index___rl_file__rl_const_0_0_i4);
Define_extern_entry(mercury____Compare___rl_file__rl_const_0_0);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i5);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i4);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i2);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i9);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i8);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i6);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i10);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i11);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i19);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i16);
Declare_label(mercury____Compare___rl_file__rl_const_0_0_i1019);
Define_extern_entry(mercury____Unify___rl_file__relations_0_0);
Define_extern_entry(mercury____Index___rl_file__relations_0_0);
Define_extern_entry(mercury____Compare___rl_file__relations_0_0);
Define_extern_entry(mercury____Unify___rl_file__relation_0_0);
Declare_label(mercury____Unify___rl_file__relation_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__relation_0_0);
Define_extern_entry(mercury____Compare___rl_file__relation_0_0);
Declare_label(mercury____Compare___rl_file__relation_0_0_i3);
Declare_label(mercury____Compare___rl_file__relation_0_0_i7);
Declare_label(mercury____Compare___rl_file__relation_0_0_i11);
Declare_label(mercury____Compare___rl_file__relation_0_0_i17);
Define_extern_entry(mercury____Unify___rl_file__variable_0_0);
Declare_label(mercury____Unify___rl_file__variable_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__variable_0_0);
Define_extern_entry(mercury____Compare___rl_file__variable_0_0);
Declare_label(mercury____Compare___rl_file__variable_0_0_i3);
Declare_label(mercury____Compare___rl_file__variable_0_0_i7);
Define_extern_entry(mercury____Unify___rl_file__procedure_0_0);
Declare_label(mercury____Unify___rl_file__procedure_0_0_i2);
Declare_label(mercury____Unify___rl_file__procedure_0_0_i4);
Declare_label(mercury____Unify___rl_file__procedure_0_0_i1014);
Declare_label(mercury____Unify___rl_file__procedure_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__procedure_0_0);
Define_extern_entry(mercury____Compare___rl_file__procedure_0_0);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i3);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i7);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i11);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i15);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i19);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i23);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i27);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i31);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i35);
Declare_label(mercury____Compare___rl_file__procedure_0_0_i47);
Define_extern_entry(mercury____Unify___rl_file__expression_0_0);
Declare_label(mercury____Unify___rl_file__expression_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__expression_0_0);
Define_extern_entry(mercury____Compare___rl_file__expression_0_0);
Declare_label(mercury____Compare___rl_file__expression_0_0_i3);
Declare_label(mercury____Compare___rl_file__expression_0_0_i7);
Declare_label(mercury____Compare___rl_file__expression_0_0_i11);
Declare_label(mercury____Compare___rl_file__expression_0_0_i15);
Declare_label(mercury____Compare___rl_file__expression_0_0_i19);
Declare_label(mercury____Compare___rl_file__expression_0_0_i23);
Declare_label(mercury____Compare___rl_file__expression_0_0_i27);
Declare_label(mercury____Compare___rl_file__expression_0_0_i37);
Define_extern_entry(mercury____Unify___rl_file__exprn_mode_0_0);
Declare_label(mercury____Unify___rl_file__exprn_mode_0_0_i1);
Define_extern_entry(mercury____Index___rl_file__exprn_mode_0_0);
Define_extern_entry(mercury____Compare___rl_file__exprn_mode_0_0);
Declare_static(mercury____Unify___rl_file__rl_state_0_0);
Declare_static(mercury____Index___rl_file__rl_state_0_0);
Declare_static(mercury____Compare___rl_file__rl_state_0_0);
Declare_static(mercury____Unify___rl_file__writer_0_0);
Declare_static(mercury____Index___rl_file__writer_0_0);
Declare_static(mercury____Compare___rl_file__writer_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_byte_writer_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_constant_pool_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_expression_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_exprn_mode_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_procedure_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_relation_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_relations_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_const_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_file_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_state_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_variable_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_writer_0;

static const struct mercury_data_rl_file__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_file__common_0;

static const struct mercury_data_rl_file__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_file__common_1;

static const struct mercury_data_rl_file__common_2_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_file__common_2;

static const struct mercury_data_rl_file__common_3_struct {
	Word * f1;
}  mercury_data_rl_file__common_3;

static const struct mercury_data_rl_file__common_4_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_4;

static const struct mercury_data_rl_file__common_5_struct {
	Word * f1;
}  mercury_data_rl_file__common_5;

static const struct mercury_data_rl_file__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_6;

static const struct mercury_data_rl_file__common_7_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_7;

static const struct mercury_data_rl_file__common_8_struct {
	Word * f1;
}  mercury_data_rl_file__common_8;

static const struct mercury_data_rl_file__common_9_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_9;

static const struct mercury_data_rl_file__common_10_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_10;

static const struct mercury_data_rl_file__common_11_struct {
	Word * f1;
}  mercury_data_rl_file__common_11;

static const struct mercury_data_rl_file__common_12_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_12;

static const struct mercury_data_rl_file__common_13_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_13;

static const struct mercury_data_rl_file__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_14;

static const struct mercury_data_rl_file__common_15_struct {
	Word * f1;
}  mercury_data_rl_file__common_15;

static const struct mercury_data_rl_file__common_16_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_16;

static const struct mercury_data_rl_file__common_17_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_file__common_17;

static const struct mercury_data_rl_file__common_18_struct {
	Word * f1;
}  mercury_data_rl_file__common_18;

static const struct mercury_data_rl_file__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_19;

static const struct mercury_data_rl_file__common_20_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_20;

static const struct mercury_data_rl_file__common_21_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_21;

static const struct mercury_data_rl_file__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_22;

static const struct mercury_data_rl_file__common_23_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_23;

static const struct mercury_data_rl_file__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_24;

static const struct mercury_data_rl_file__common_25_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_rl_file__common_25;

static const struct mercury_data_rl_file__common_26_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_26;

static const struct mercury_data_rl_file__common_27_struct {
	Word * f1;
}  mercury_data_rl_file__common_27;

static const struct mercury_data_rl_file__common_28_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_28;

static const struct mercury_data_rl_file__common_29_struct {
	Word * f1;
}  mercury_data_rl_file__common_29;

static const struct mercury_data_rl_file__common_30_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_file__common_30;

static const struct mercury_data_rl_file__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_31;

static const struct mercury_data_rl_file__common_32_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_32;

static const struct mercury_data_rl_file__common_33_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_file__common_33;

static const struct mercury_data_rl_file__common_34_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_34;

static const struct mercury_data_rl_file__common_35_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_35;

static const struct mercury_data_rl_file__common_36_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_36;

static const struct mercury_data_rl_file__common_37_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_file__common_37;

static const struct mercury_data_rl_file__common_38_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_file__common_38;

static const struct mercury_data_rl_file__common_39_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_file__common_39;

static const struct mercury_data_rl_file__common_40_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__common_40;

static const struct mercury_data_rl_file__common_41_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_rl_file__common_41;

static const struct mercury_data_rl_file__common_42_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__common_42;

static const struct mercury_data_rl_file__common_43_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_43;

static const struct mercury_data_rl_file__common_44_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_44;

static const struct mercury_data_rl_file__common_45_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_45;

static const struct mercury_data_rl_file__common_46_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	String f16;
	Word * f17;
	Integer f18;
	Integer f19;
}  mercury_data_rl_file__common_46;

static const struct mercury_data_rl_file__common_47_struct {
	Word * f1;
}  mercury_data_rl_file__common_47;

static const struct mercury_data_rl_file__common_48_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_file__common_48;

static const struct mercury_data_rl_file__common_49_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_file__common_49;

static const struct mercury_data_rl_file__common_50_struct {
	Word * f1;
}  mercury_data_rl_file__common_50;

static const struct mercury_data_rl_file__common_51_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_file__common_51;

static const struct mercury_data_rl_file__common_52_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_52;

static const struct mercury_data_rl_file__common_53_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__common_53;

static const struct mercury_data_rl_file__common_54_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_rl_file__common_54;

static const struct mercury_data_rl_file__common_55_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_55;

static const struct mercury_data_rl_file__common_56_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_file__common_56;

static const struct mercury_data_rl_file__common_57_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	String f12;
	Word * f13;
	Integer f14;
	Integer f15;
}  mercury_data_rl_file__common_57;

static const struct mercury_data_rl_file__common_58_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_data_rl_file__common_58;

static const struct mercury_data_rl_file__common_59_struct {
	Word * f1;
}  mercury_data_rl_file__common_59;

static const struct mercury_data_rl_file__common_60_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	String f10;
	Word * f11;
	Integer f12;
	Integer f13;
}  mercury_data_rl_file__common_60;

static const struct mercury_data_rl_file__common_61_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__common_61;

static const struct mercury_data_rl_file__common_62_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__common_62;

static const struct mercury_data_rl_file__type_ctor_functors_writer_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_writer_0;

static const struct mercury_data_rl_file__type_ctor_layout_writer_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_writer_0;

static const struct mercury_data_rl_file__type_ctor_functors_variable_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_file__type_ctor_functors_variable_0;

static const struct mercury_data_rl_file__type_ctor_layout_variable_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_variable_0;

static const struct mercury_data_rl_file__type_ctor_functors_rl_state_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_rl_state_0;

static const struct mercury_data_rl_file__type_ctor_layout_rl_state_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_rl_state_0;

static const struct mercury_data_rl_file__type_ctor_functors_rl_file_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_file__type_ctor_functors_rl_file_0;

static const struct mercury_data_rl_file__type_ctor_layout_rl_file_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_rl_file_0;

static const struct mercury_data_rl_file__type_ctor_functors_rl_const_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_file__type_ctor_functors_rl_const_0;

static const struct mercury_data_rl_file__type_ctor_layout_rl_const_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_rl_const_0;

static const struct mercury_data_rl_file__type_ctor_functors_relations_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_relations_0;

static const struct mercury_data_rl_file__type_ctor_layout_relations_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_relations_0;

static const struct mercury_data_rl_file__type_ctor_functors_relation_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_file__type_ctor_functors_relation_0;

static const struct mercury_data_rl_file__type_ctor_layout_relation_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_relation_0;

static const struct mercury_data_rl_file__type_ctor_functors_procedure_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_file__type_ctor_functors_procedure_0;

static const struct mercury_data_rl_file__type_ctor_layout_procedure_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_procedure_0;

static const struct mercury_data_rl_file__type_ctor_functors_exprn_mode_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_exprn_mode_0;

static const struct mercury_data_rl_file__type_ctor_layout_exprn_mode_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_exprn_mode_0;

static const struct mercury_data_rl_file__type_ctor_functors_expression_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_file__type_ctor_functors_expression_0;

static const struct mercury_data_rl_file__type_ctor_layout_expression_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_expression_0;

static const struct mercury_data_rl_file__type_ctor_functors_constant_pool_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_constant_pool_0;

static const struct mercury_data_rl_file__type_ctor_layout_constant_pool_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_constant_pool_0;

static const struct mercury_data_rl_file__type_ctor_functors_byte_writer_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_file__type_ctor_functors_byte_writer_0;

static const struct mercury_data_rl_file__type_ctor_layout_byte_writer_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_file__type_ctor_layout_byte_writer_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_byte_writer_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__byte_writer_0_0),
	ENTRY(mercury____Index___rl_file__byte_writer_0_0),
	ENTRY(mercury____Compare___rl_file__byte_writer_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_file__type_ctor_functors_byte_writer_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_byte_writer_0,
	MR_string_const("rl_file", 7),
	MR_string_const("byte_writer", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_constant_pool_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__constant_pool_0_0),
	ENTRY(mercury____Index___rl_file__constant_pool_0_0),
	ENTRY(mercury____Compare___rl_file__constant_pool_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_file__type_ctor_functors_constant_pool_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_constant_pool_0,
	MR_string_const("rl_file", 7),
	MR_string_const("constant_pool", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_expression_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__expression_0_0),
	ENTRY(mercury____Index___rl_file__expression_0_0),
	ENTRY(mercury____Compare___rl_file__expression_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_expression_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_expression_0,
	MR_string_const("rl_file", 7),
	MR_string_const("expression", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_exprn_mode_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__exprn_mode_0_0),
	ENTRY(mercury____Index___rl_file__exprn_mode_0_0),
	ENTRY(mercury____Compare___rl_file__exprn_mode_0_0),
	(Integer) 0,
	(Word *) &mercury_data_rl_file__type_ctor_functors_exprn_mode_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_exprn_mode_0,
	MR_string_const("rl_file", 7),
	MR_string_const("exprn_mode", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_procedure_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__procedure_0_0),
	ENTRY(mercury____Index___rl_file__procedure_0_0),
	ENTRY(mercury____Compare___rl_file__procedure_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_procedure_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_procedure_0,
	MR_string_const("rl_file", 7),
	MR_string_const("procedure", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_relation_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__relation_0_0),
	ENTRY(mercury____Index___rl_file__relation_0_0),
	ENTRY(mercury____Compare___rl_file__relation_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_relation_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_relation_0,
	MR_string_const("rl_file", 7),
	MR_string_const("relation", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_relations_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__relations_0_0),
	ENTRY(mercury____Index___rl_file__relations_0_0),
	ENTRY(mercury____Compare___rl_file__relations_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_file__type_ctor_functors_relations_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_relations_0,
	MR_string_const("rl_file", 7),
	MR_string_const("relations", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_const_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__rl_const_0_0),
	ENTRY(mercury____Index___rl_file__rl_const_0_0),
	ENTRY(mercury____Compare___rl_file__rl_const_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_rl_const_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_rl_const_0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_const", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_file_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__rl_file_0_0),
	ENTRY(mercury____Index___rl_file__rl_file_0_0),
	ENTRY(mercury____Compare___rl_file__rl_file_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_rl_file_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_rl_file_0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_rl_state_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_file__rl_state_0_0),
	STATIC(mercury____Index___rl_file__rl_state_0_0),
	STATIC(mercury____Compare___rl_file__rl_state_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_file__type_ctor_functors_rl_state_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_rl_state_0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_state", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_variable_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_file__variable_0_0),
	ENTRY(mercury____Index___rl_file__variable_0_0),
	ENTRY(mercury____Compare___rl_file__variable_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_file__type_ctor_functors_variable_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_variable_0,
	MR_string_const("rl_file", 7),
	MR_string_const("variable", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_file__type_ctor_info_writer_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_file__writer_0_0),
	STATIC(mercury____Index___rl_file__writer_0_0),
	STATIC(mercury____Compare___rl_file__writer_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_file__type_ctor_functors_writer_0,
	(Word *) &mercury_data_rl_file__type_ctor_layout_writer_0,
	MR_string_const("rl_file", 7),
	MR_string_const("writer", 6),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_file__common_0_struct mercury_data_rl_file__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_file__common_1_struct mercury_data_rl_file__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl_file__type_ctor_info_rl_const_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_pred_0;
static const struct mercury_data_rl_file__common_2_struct mercury_data_rl_file__common_2 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 3,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0,
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_file__common_3_struct mercury_data_rl_file__common_3 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_file__common_4_struct mercury_data_rl_file__common_4 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_binary__131__1", 42),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_5_struct mercury_data_rl_file__common_5 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_file__common_6_struct mercury_data_rl_file__common_6 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_text__395__2", 40),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_7_struct mercury_data_rl_file__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_6),
	STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__395__2_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_8_struct mercury_data_rl_file__common_8 = {
	(Word *) &mercury_data_rl_file__type_ctor_info_relation_0
};

static const struct mercury_data_rl_file__common_9_struct mercury_data_rl_file__common_9 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_text__402__3", 40),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_10_struct mercury_data_rl_file__common_10 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_9),
	STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__402__3_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_11_struct mercury_data_rl_file__common_11 = {
	(Word *) &mercury_data_rl_file__type_ctor_info_variable_0
};

static const struct mercury_data_rl_file__common_12_struct mercury_data_rl_file__common_12 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_text__409__4", 40),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_13_struct mercury_data_rl_file__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_12),
	STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__409__4_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_rl_file__common_14_struct mercury_data_rl_file__common_14 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1)
};

static const struct mercury_data_rl_file__common_15_struct mercury_data_rl_file__common_15 = {
	(Word *) &mercury_data_rl_file__type_ctor_info_procedure_0
};

static const struct mercury_data_rl_file__common_16_struct mercury_data_rl_file__common_16 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_proc", 10),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_15),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_17_struct mercury_data_rl_file__common_17 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 3,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_character_0;
static const struct mercury_data_rl_file__common_18_struct mercury_data_rl_file__common_18 = {
	(Word *) &mercury_data___type_ctor_info_character_0
};

static const struct mercury_data_rl_file__common_19_struct mercury_data_rl_file__common_19 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_char", 10),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_20_struct mercury_data_rl_file__common_20 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("generate_const_table_entry", 26),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_21_struct mercury_data_rl_file__common_21 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_relation", 14),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_22_struct mercury_data_rl_file__common_22 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_variable", 14),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_23_struct mercury_data_rl_file__common_23 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_proc_bytecode", 19),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_15),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_24_struct mercury_data_rl_file__common_24 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_file__common_25_struct mercury_data_rl_file__common_25 = {
	(Integer) 0,
	MR_string_const("rl_code", 7),
	MR_string_const("rl_code", 7),
	MR_string_const("int16_to_bytecode", 17),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_24)
};

Declare_entry(mercury__rl_code__int16_to_bytecode_2_0);
static const struct mercury_data_rl_file__common_26_struct mercury_data_rl_file__common_26 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_25),
	ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_27_struct mercury_data_rl_file__common_27 = {
	(Word *) &mercury_data_rl_file__type_ctor_info_expression_0
};

static const struct mercury_data_rl_file__common_28_struct mercury_data_rl_file__common_28 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_exprn_bytecode", 20),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl_code__type_ctor_info_bytecode_0;
static const struct mercury_data_rl_file__common_29_struct mercury_data_rl_file__common_29 = {
	(Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0
};

static const struct mercury_data_rl_file__common_30_struct mercury_data_rl_file__common_30 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__output_bytecodes__352__5", 46),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_29),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_31_struct mercury_data_rl_file__common_31 = {
	(Integer) 0,
	MR_string_const("io", 2),
	MR_string_const("io", 2),
	MR_string_const("write_int", 9),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

Declare_entry(mercury__io__write_int_3_0);
static const struct mercury_data_rl_file__common_32_struct mercury_data_rl_file__common_32 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_31),
	ENTRY(mercury__io__write_int_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_33_struct mercury_data_rl_file__common_33 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("write_exprn", 11),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_34_struct mercury_data_rl_file__common_34 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_33),
	STATIC(mercury__rl_file__write_exprn_5_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_35_struct mercury_data_rl_file__common_35 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_proc__469__6", 40),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_29),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_36_struct mercury_data_rl_file__common_36 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_35),
	STATIC(mercury__rl_file__IntroducedFrom__pred__write_proc__469__6_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_37_struct mercury_data_rl_file__common_37 = {
	(Integer) 0,
	MR_string_const("rl_file", 7),
	MR_string_const("rl_file", 7),
	MR_string_const("IntroducedFrom__pred__write_exprn_2__508__7", 43),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_29),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_5)
};

static const struct mercury_data_rl_file__common_38_struct mercury_data_rl_file__common_38 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_37),
	STATIC(mercury__rl_file__IntroducedFrom__pred__write_exprn_2__508__7_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_file__common_39_struct mercury_data_rl_file__common_39 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl_file__type_ctor_info_relation_0
};

static const struct mercury_data_rl_file__common_40_struct mercury_data_rl_file__common_40 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17)
};

static const struct mercury_data_rl_file__common_41_struct mercury_data_rl_file__common_41 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_string_const("variable", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_42_struct mercury_data_rl_file__common_42 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__common_43_struct mercury_data_rl_file__common_43 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_file__type_ctor_info_relation_0
};

static const struct mercury_data_rl_file__common_44_struct mercury_data_rl_file__common_44 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_file__type_ctor_info_variable_0
};

static const struct mercury_data_rl_file__common_45_struct mercury_data_rl_file__common_45 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_file__type_ctor_info_procedure_0
};

static const struct mercury_data_rl_file__common_46_struct mercury_data_rl_file__common_46 = {
	(Integer) 14,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_43),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_44),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_45),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_string_const("rl_file", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_float_0;
static const struct mercury_data_rl_file__common_47_struct mercury_data_rl_file__common_47 = {
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_rl_file__common_48_struct mercury_data_rl_file__common_48 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_47),
	MR_string_const("float", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_49_struct mercury_data_rl_file__common_49 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_string_const("int", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_rl_file__common_50_struct mercury_data_rl_file__common_50 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_rl_file__common_51_struct mercury_data_rl_file__common_51 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_50),
	MR_string_const("string", 6),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_52_struct mercury_data_rl_file__common_52 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_39)
};

static const struct mercury_data_rl_file__common_53_struct mercury_data_rl_file__common_53 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_52)
};

static const struct mercury_data_rl_file__common_54_struct mercury_data_rl_file__common_54 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_string_const("relation", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_55_struct mercury_data_rl_file__common_55 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_file__type_ctor_info_expression_0
};

static const struct mercury_data_rl_file__common_56_struct mercury_data_rl_file__common_56 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0
};

static const struct mercury_data_rl_file__common_57_struct mercury_data_rl_file__common_57 = {
	(Integer) 10,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_56),
	MR_string_const("procedure", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_58_struct mercury_data_rl_file__common_58 = {
	(Integer) 1,
	(Integer) 4,
	MR_string_const("void", 4),
	MR_string_const("test", 4),
	MR_string_const("generate", 8),
	MR_string_const("generate2", 9)
};

static const struct mercury_data_rl_file__common_59_struct mercury_data_rl_file__common_59 = {
	(Word *) &mercury_data_rl_file__type_ctor_info_exprn_mode_0
};

static const struct mercury_data_rl_file__common_60_struct mercury_data_rl_file__common_60 = {
	(Integer) 8,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_59),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_56),
	MR_string_const("expression", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_file__common_61_struct mercury_data_rl_file__common_61 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_14)
};

static const struct mercury_data_rl_file__common_62_struct mercury_data_rl_file__common_62 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_2)
};

static const struct mercury_data_rl_file__type_ctor_functors_writer_0_struct mercury_data_rl_file__type_ctor_functors_writer_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_17)
};

static const struct mercury_data_rl_file__type_ctor_layout_writer_0_struct mercury_data_rl_file__type_ctor_layout_writer_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_40),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_40)
};

static const struct mercury_data_rl_file__type_ctor_functors_variable_0_struct mercury_data_rl_file__type_ctor_functors_variable_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_41)
};

static const struct mercury_data_rl_file__type_ctor_layout_variable_0_struct mercury_data_rl_file__type_ctor_layout_variable_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_41),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_rl_state_0_struct mercury_data_rl_file__type_ctor_functors_rl_state_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0)
};

static const struct mercury_data_rl_file__type_ctor_layout_rl_state_0_struct mercury_data_rl_file__type_ctor_layout_rl_state_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_42),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_42)
};

static const struct mercury_data_rl_file__type_ctor_functors_rl_file_0_struct mercury_data_rl_file__type_ctor_functors_rl_file_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_46)
};

static const struct mercury_data_rl_file__type_ctor_layout_rl_file_0_struct mercury_data_rl_file__type_ctor_layout_rl_file_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_46),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_rl_const_0_struct mercury_data_rl_file__type_ctor_functors_rl_const_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_48),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_49),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_51)
};

static const struct mercury_data_rl_file__type_ctor_layout_rl_const_0_struct mercury_data_rl_file__type_ctor_layout_rl_const_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_49),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_48),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_51),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_relations_0_struct mercury_data_rl_file__type_ctor_functors_relations_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_52)
};

static const struct mercury_data_rl_file__type_ctor_layout_relations_0_struct mercury_data_rl_file__type_ctor_layout_relations_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_53)
};

static const struct mercury_data_rl_file__type_ctor_functors_relation_0_struct mercury_data_rl_file__type_ctor_functors_relation_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_54)
};

static const struct mercury_data_rl_file__type_ctor_layout_relation_0_struct mercury_data_rl_file__type_ctor_layout_relation_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_54),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_procedure_0_struct mercury_data_rl_file__type_ctor_functors_procedure_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_57)
};

static const struct mercury_data_rl_file__type_ctor_layout_procedure_0_struct mercury_data_rl_file__type_ctor_layout_procedure_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_57),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_exprn_mode_0_struct mercury_data_rl_file__type_ctor_functors_exprn_mode_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_58)
};

static const struct mercury_data_rl_file__type_ctor_layout_exprn_mode_0_struct mercury_data_rl_file__type_ctor_layout_exprn_mode_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_58),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_58)
};

static const struct mercury_data_rl_file__type_ctor_functors_expression_0_struct mercury_data_rl_file__type_ctor_functors_expression_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_60)
};

static const struct mercury_data_rl_file__type_ctor_layout_expression_0_struct mercury_data_rl_file__type_ctor_layout_expression_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_file__common_60),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_file__type_ctor_functors_constant_pool_0_struct mercury_data_rl_file__type_ctor_functors_constant_pool_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_14)
};

static const struct mercury_data_rl_file__type_ctor_layout_constant_pool_0_struct mercury_data_rl_file__type_ctor_layout_constant_pool_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_61),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_61),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_61),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_61)
};

static const struct mercury_data_rl_file__type_ctor_functors_byte_writer_0_struct mercury_data_rl_file__type_ctor_functors_byte_writer_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_2)
};

static const struct mercury_data_rl_file__type_ctor_layout_byte_writer_0_struct mercury_data_rl_file__type_ctor_layout_byte_writer_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_62),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_file__common_62)
};


BEGIN_MODULE(rl_file_module0)
	init_entry(mercury____Index___rl_file__expression_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_file__expression_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_file__expression_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module1)
	init_entry(mercury____Index___rl_file__procedure_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_file__procedure_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_file__procedure_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module2)
	init_entry(mercury____Index___rl_file__variable_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_file__variable_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_file__variable_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module3)
	init_entry(mercury____Index___rl_file__relation_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_file__relation_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_file__relation_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module4)
	init_entry(mercury____Index___rl_file__rl_file_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_file__rl_file_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_file__rl_file_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__io__write_3_0);

BEGIN_MODULE(rl_file_module5)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_exprn_2__508__7_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_exprn_2__508__7'/3 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_exprn_2__508__7_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_exprn_2__508__7_3_0));
END_MODULE


BEGIN_MODULE(rl_file_module6)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_proc__469__6_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_proc__469__6'/3 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_proc__469__6_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_proc__469__6_3_0));
END_MODULE

Declare_entry(mercury__rl_code__bytecode_to_intlist_2_0);
Declare_entry(mercury__list__foldl_4_0);

BEGIN_MODULE(rl_file_module7)
	init_entry(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0);
	init_label(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__output_bytecodes__352__5'/4 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0);
	MR_incr_sp_push_msg(3, "rl_file:IntroducedFrom__pred__output_bytecodes__352__5/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl_code__bytecode_to_intlist_2_0),
		mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0_i2,
		STATIC(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0));
Define_label(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0));
END_MODULE


BEGIN_MODULE(rl_file_module8)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_text__409__4_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_text__409__4'/3 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_text__409__4_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_variable_0;
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__409__4_3_0));
END_MODULE


BEGIN_MODULE(rl_file_module9)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_text__402__3_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_text__402__3'/3 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_text__402__3_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_relation_0;
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__402__3_3_0));
END_MODULE


BEGIN_MODULE(rl_file_module10)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_text__395__2_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_text__395__2'/3 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_text__395__2_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	tailcall(ENTRY(mercury__io__write_3_0),
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_text__395__2_3_0));
END_MODULE

Declare_entry(mercury__do_call_closure);

BEGIN_MODULE(rl_file_module11)
	init_entry(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0);
	init_label(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__write_binary__131__1'/4 in mode 0 */
Define_static(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0);
	MR_incr_sp_push_msg(2, "rl_file:IntroducedFrom__pred__write_binary__131__1/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = ((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 0) + (Integer) 1);
	r4 = r2;
	r5 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0_i2,
		STATIC(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0));
Define_label(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module12)
	init_entry(mercury__rl_file__write_binary_5_0);
	init_label(mercury__rl_file__write_binary_5_0_i2);
BEGIN_CODE

/* code for predicate 'write_binary'/5 in mode 0 */
Define_entry(mercury__rl_file__write_binary_5_0);
	MR_incr_sp_push_msg(1, "rl_file:write_binary/5");
	MR_stackvar(1) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	r1 = MR_tempr1;
	r4 = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_file__IntroducedFrom__pred__write_binary__131__1_4_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_file__write_binary_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r4;
	call_localret(STATIC(mercury__rl_file__write_binary_2_4_0),
		mercury__rl_file__write_binary_5_0_i2,
		ENTRY(mercury__rl_file__write_binary_5_0));
	}
Define_label(mercury__rl_file__write_binary_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_5_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_list_5_0);

BEGIN_MODULE(rl_file_module13)
	init_entry(mercury__rl_file__write_text_3_0);
	init_label(mercury__rl_file__write_text_3_0_i2);
	init_label(mercury__rl_file__write_text_3_0_i3);
	init_label(mercury__rl_file__write_text_3_0_i4);
	init_label(mercury__rl_file__write_text_3_0_i5);
	init_label(mercury__rl_file__write_text_3_0_i6);
	init_label(mercury__rl_file__write_text_3_0_i7);
	init_label(mercury__rl_file__write_text_3_0_i8);
	init_label(mercury__rl_file__write_text_3_0_i9);
	init_label(mercury__rl_file__write_text_3_0_i10);
	init_label(mercury__rl_file__write_text_3_0_i11);
	init_label(mercury__rl_file__write_text_3_0_i12);
	init_label(mercury__rl_file__write_text_3_0_i13);
	init_label(mercury__rl_file__write_text_3_0_i14);
	init_label(mercury__rl_file__write_text_3_0_i15);
	init_label(mercury__rl_file__write_text_3_0_i16);
	init_label(mercury__rl_file__write_text_3_0_i17);
	init_label(mercury__rl_file__write_text_3_0_i18);
	init_label(mercury__rl_file__write_text_3_0_i19);
	init_label(mercury__rl_file__write_text_3_0_i20);
	init_label(mercury__rl_file__write_text_3_0_i21);
	init_label(mercury__rl_file__write_text_3_0_i22);
	init_label(mercury__rl_file__write_text_3_0_i23);
	init_label(mercury__rl_file__write_text_3_0_i24);
	init_label(mercury__rl_file__write_text_3_0_i25);
	init_label(mercury__rl_file__write_text_3_0_i26);
	init_label(mercury__rl_file__write_text_3_0_i27);
	init_label(mercury__rl_file__write_text_3_0_i28);
	init_label(mercury__rl_file__write_text_3_0_i29);
	init_label(mercury__rl_file__write_text_3_0_i30);
	init_label(mercury__rl_file__write_text_3_0_i31);
	init_label(mercury__rl_file__write_text_3_0_i32);
	init_label(mercury__rl_file__write_text_3_0_i33);
	init_label(mercury__rl_file__write_text_3_0_i34);
	init_label(mercury__rl_file__write_text_3_0_i35);
	init_label(mercury__rl_file__write_text_3_0_i36);
	init_label(mercury__rl_file__write_text_3_0_i37);
	init_label(mercury__rl_file__write_text_3_0_i38);
	init_label(mercury__rl_file__write_text_3_0_i39);
BEGIN_CODE

/* code for predicate 'write_text'/3 in mode 0 */
Define_entry(mercury__rl_file__write_text_3_0);
	MR_incr_sp_push_msg(15, "rl_file:write_text/3");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	r1 = (Word) MR_string_const("rl_file(\n", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i2,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i3,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% minor version\n", 18);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i4,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i5,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% major version\n", 18);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i6,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("%==============const table====================================================%\n", 80);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i7,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i8,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% const table size\n", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i9,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t[\n\t", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i10,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	r2 = MR_stackvar(4);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_7);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_text_3_0_i11,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t],\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i12,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("%==============permanent relations============================================%\n", 80);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i13,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i14,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% number of permanent relations\n", 34);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i15,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t[\n\t", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i16,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_relation_0;
	r2 = MR_stackvar(6);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_10);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_text_3_0_i17,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t],\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i18,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("%==============var table======================================================%\n", 80);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i19,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i20,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% number of variables\n", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i21,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t[\n\t", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i22,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_variable_0;
	r2 = MR_stackvar(8);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_13);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_text_3_0_i23,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t],\n", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i24,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("%==============proc table=====================================================%\n", 80);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i25,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i26,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% number of procedures\n", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i27,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t[\n\t", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i28,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__rl_file__write_text_3_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_procedure_0;
	r2 = MR_stackvar(10);
	r3 = (Word) MR_string_const(",\n\t", 3);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_proc_4_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_16);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_text_3_0_i29,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n]\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i30,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("%=============================================================================%\n", 80);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i31,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i31);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i32,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(11);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i33,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i33);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i34,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i34);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i35,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i36,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i37,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i37);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_text_3_0_i38,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i38);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_text_3_0_i39,
		ENTRY(mercury__rl_file__write_text_3_0));
Define_label(mercury__rl_file__write_text_3_0_i39);
	update_prof_current_proc(LABEL(mercury__rl_file__write_text_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(").\n", 3);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__rl_file__write_text_3_0));
END_MODULE

Declare_entry(mercury__string__foldl_4_1);

BEGIN_MODULE(rl_file_module14)
	init_entry(mercury__rl_file__write_binary_2_4_0);
	init_label(mercury__rl_file__write_binary_2_4_0_i2);
	init_label(mercury__rl_file__write_binary_2_4_0_i3);
	init_label(mercury__rl_file__write_binary_2_4_0_i4);
	init_label(mercury__rl_file__write_binary_2_4_0_i5);
	init_label(mercury__rl_file__write_binary_2_4_0_i6);
	init_label(mercury__rl_file__write_binary_2_4_0_i7);
	init_label(mercury__rl_file__write_binary_2_4_0_i8);
	init_label(mercury__rl_file__write_binary_2_4_0_i9);
	init_label(mercury__rl_file__write_binary_2_4_0_i10);
	init_label(mercury__rl_file__write_binary_2_4_0_i11);
	init_label(mercury__rl_file__write_binary_2_4_0_i12);
	init_label(mercury__rl_file__write_binary_2_4_0_i13);
	init_label(mercury__rl_file__write_binary_2_4_0_i14);
	init_label(mercury__rl_file__write_binary_2_4_0_i15);
	init_label(mercury__rl_file__write_binary_2_4_0_i16);
	init_label(mercury__rl_file__write_binary_2_4_0_i17);
	init_label(mercury__rl_file__write_binary_2_4_0_i18);
	init_label(mercury__rl_file__write_binary_2_4_0_i19);
	init_label(mercury__rl_file__write_binary_2_4_0_i20);
	init_label(mercury__rl_file__write_binary_2_4_0_i21);
	init_label(mercury__rl_file__write_binary_2_4_0_i22);
	init_label(mercury__rl_file__write_binary_2_4_0_i23);
	init_label(mercury__rl_file__write_binary_2_4_0_i24);
	init_label(mercury__rl_file__write_binary_2_4_0_i25);
	init_label(mercury__rl_file__write_binary_2_4_0_i26);
	init_label(mercury__rl_file__write_binary_2_4_0_i27);
	init_label(mercury__rl_file__write_binary_2_4_0_i28);
BEGIN_CODE

/* code for predicate 'write_binary_2'/4 in mode 0 */
Define_static(mercury__rl_file__write_binary_2_4_0);
	MR_incr_sp_push_msg(17, "rl_file:write_binary_2/4");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_2_4_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = (Word) MR_string_const(".rlo", 4);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_char_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_19);
	call_localret(ENTRY(mercury__string__foldl_4_1),
		mercury__rl_file__write_binary_2_4_0_i2,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i3,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i4,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(16);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i5,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i6,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i7,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i8,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 86;
	call_localret(STATIC(mercury__rl_file__write_char_4_0),
		mercury__rl_file__write_binary_2_4_0_i9,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_2_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_20);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__generate_const_table_entry_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = r4;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i10,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i11,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i12,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_relation_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_2_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_21);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_relation_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = r4;
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i13,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i14,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i15,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_variable_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_2_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_22);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_variable_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = r4;
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i16,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i17,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i18,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_procedure_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_binary_2_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_23);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_proc_bytecode_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	r5 = r4;
	r4 = MR_stackvar(11);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i19,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i20,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i21,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i22,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i23,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i24,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i25,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i26,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_binary_2_4_0_i27,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(15);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_binary_2_4_0_i28,
		STATIC(mercury__rl_file__write_binary_2_4_0));
Define_label(mercury__rl_file__write_binary_2_4_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_file__write_binary_2_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__write_binary_2_4_0));
END_MODULE

Declare_entry(mercury__char__to_int_2_0);

BEGIN_MODULE(rl_file_module15)
	init_entry(mercury__rl_file__write_char_4_0);
	init_label(mercury__rl_file__write_char_4_0_i2);
BEGIN_CODE

/* code for predicate 'write_char'/4 in mode 0 */
Define_static(mercury__rl_file__write_char_4_0);
	MR_incr_sp_push_msg(3, "rl_file:write_char/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__rl_file__write_char_4_0_i2,
		STATIC(mercury__rl_file__write_char_4_0));
Define_label(mercury__rl_file__write_char_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_char_4_0));
	r4 = r1;
	r5 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__do_call_closure),
		STATIC(mercury__rl_file__write_char_4_0));
END_MODULE

Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__condense_2_0);

BEGIN_MODULE(rl_file_module16)
	init_entry(mercury__rl_file__write_relation_4_0);
	init_label(mercury__rl_file__write_relation_4_0_i2);
	init_label(mercury__rl_file__write_relation_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_relation'/4 in mode 0 */
Define_static(mercury__rl_file__write_relation_4_0);
	MR_incr_sp_push_msg(3, "rl_file:write_relation/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_file__write_relation_4_0, "origin_lost_in_value_number");
	r5 = r2;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_24);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_26);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__rl_file__write_relation_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__rl_file__write_relation_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_const_field(MR_mktag(0), r5, (Integer) 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_file__write_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r5, (Integer) 3);
	MR_field(MR_mktag(1), r4, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_file__write_relation_4_0_i2,
		STATIC(mercury__rl_file__write_relation_4_0));
	}
Define_label(mercury__rl_file__write_relation_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_relation_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_file__write_relation_4_0_i3,
		STATIC(mercury__rl_file__write_relation_4_0));
Define_label(mercury__rl_file__write_relation_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_relation_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__write_relation_4_0));
END_MODULE


BEGIN_MODULE(rl_file_module17)
	init_entry(mercury__rl_file__write_variable_4_0);
	init_label(mercury__rl_file__write_variable_4_0_i2);
	init_label(mercury__rl_file__write_variable_4_0_i3);
	init_label(mercury__rl_file__write_variable_4_0_i4);
BEGIN_CODE

/* code for predicate 'write_variable'/4 in mode 0 */
Define_static(mercury__rl_file__write_variable_4_0);
	MR_incr_sp_push_msg(4, "rl_file:write_variable/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_variable_4_0_i2,
		STATIC(mercury__rl_file__write_variable_4_0));
Define_label(mercury__rl_file__write_variable_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_variable_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_variable_4_0_i3,
		STATIC(mercury__rl_file__write_variable_4_0));
Define_label(mercury__rl_file__write_variable_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_variable_4_0));
	r5 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_variable_4_0_i4,
		STATIC(mercury__rl_file__write_variable_4_0));
Define_label(mercury__rl_file__write_variable_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_variable_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__write_variable_4_0));
END_MODULE

Declare_entry(mercury__rl_code__aInt_to_bytecode_2_0);
Declare_entry(mercury__rl_code__aDouble_to_bytecode_2_0);

BEGIN_MODULE(rl_file_module18)
	init_entry(mercury__rl_file__generate_const_table_entry_4_0);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i14);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i15);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i16);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i9);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i10);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i11);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i12);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i4);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i5);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i6);
	init_label(mercury__rl_file__generate_const_table_entry_4_0_i7);
BEGIN_CODE

/* code for predicate 'generate_const_table_entry'/4 in mode 0 */
Define_static(mercury__rl_file__generate_const_table_entry_4_0);
	MR_incr_sp_push_msg(4, "rl_file:generate_const_table_entry/4");
	MR_stackvar(4) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if ((MR_tag(r4) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_file__generate_const_table_entry_4_0_i4);
	if ((MR_tag(r4) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_file__generate_const_table_entry_4_0_i9);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r1 = (Integer) 73;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__rl_file__generate_const_table_entry_4_0_i14,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = r1;
	r5 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_file__generate_const_table_entry_4_0_i15,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__rl_code__aInt_to_bytecode_2_0),
		mercury__rl_file__generate_const_table_entry_4_0_i16,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i9);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	r1 = (Integer) 83;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__rl_file__generate_const_table_entry_4_0_i10,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = r1;
	r5 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_file__generate_const_table_entry_4_0_i11,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_file__generate_const_table_entry_4_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_char_4_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_19);
	call_localret(ENTRY(mercury__string__foldl_4_1),
		mercury__rl_file__generate_const_table_entry_4_0_i12,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = (Integer) 0;
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__do_call_closure),
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = (Integer) 68;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__char__to_int_2_0),
		mercury__rl_file__generate_const_table_entry_4_0_i5,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = r1;
	r5 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	r2 = (Integer) 2;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__rl_file__generate_const_table_entry_4_0_i6,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__rl_code__aDouble_to_bytecode_2_0),
		mercury__rl_file__generate_const_table_entry_4_0_i7,
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
Define_label(mercury__rl_file__generate_const_table_entry_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__generate_const_table_entry_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__generate_const_table_entry_4_0));
END_MODULE

Declare_entry(mercury__rl_code__int32_to_bytecode_2_0);

BEGIN_MODULE(rl_file_module19)
	init_entry(mercury__rl_file__write_proc_bytecode_4_0);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i2);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i3);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i4);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i5);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i6);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i7);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i8);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i9);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i10);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i11);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i12);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i13);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i14);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i15);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i16);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i17);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i18);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i19);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i20);
	init_label(mercury__rl_file__write_proc_bytecode_4_0_i21);
BEGIN_CODE

/* code for predicate 'write_proc_bytecode'/4 in mode 0 */
Define_static(mercury__rl_file__write_proc_bytecode_4_0);
	MR_incr_sp_push_msg(12, "rl_file:write_proc_bytecode/4");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i2,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i3,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i4,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i5,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i6,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i7,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(10);
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__rl_code__int32_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i8,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r4 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_24);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_26);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_file__write_proc_bytecode_4_0_i9,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i10,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i11,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i12,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i13,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i14,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i15,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i16,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i17,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_proc_bytecode_4_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_expression_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r4 = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__write_exprn_bytecode_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_28);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i18,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i19,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	call_localret(STATIC(mercury__rl_file__output_bytecodes_4_0),
		mercury__rl_file__write_proc_bytecode_4_0_i20,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_proc_bytecode_4_0_i21,
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
Define_label(mercury__rl_file__write_proc_bytecode_4_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_bytecode_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__write_proc_bytecode_4_0));
END_MODULE

static const struct mercury_const_215_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
}  mercury_const_215 = {
	(Integer) 0,
	(Integer) 1,
	(Integer) 2,
	(Integer) 3
};

BEGIN_MODULE(rl_file_module20)
	init_entry(mercury__rl_file__write_exprn_bytecode_4_0);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i2);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i3);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i4);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i5);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i6);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i8);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i9);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i10);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i11);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i12);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i13);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i14);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i15);
	init_label(mercury__rl_file__write_exprn_bytecode_4_0_i16);
BEGIN_CODE

/* code for predicate 'write_exprn_bytecode'/4 in mode 0 */
Define_static(mercury__rl_file__write_exprn_bytecode_4_0);
	MR_incr_sp_push_msg(10, "rl_file:write_exprn_bytecode/4");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i2,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i3,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i4,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__rl_code__int32_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i5,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__rl_code__int32_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i6,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_215), r2);
	call_localret(ENTRY(mercury__rl_code__int16_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i8,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__rl_code__int32_to_bytecode_2_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i9,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i10,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i11,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i12,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i13,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i14,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i15,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_0),
		mercury__rl_file__write_exprn_bytecode_4_0_i16,
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
Define_label(mercury__rl_file__write_exprn_bytecode_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_bytecode_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__write_exprn_bytecode_4_0, "origin_lost_in_value_number");
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	r4 = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_30);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__write_exprn_bytecode_4_0));
END_MODULE


BEGIN_MODULE(rl_file_module21)
	init_entry(mercury__rl_file__output_bytecodes_4_0);
BEGIN_CODE

/* code for predicate 'output_bytecodes'/4 in mode 0 */
Define_static(mercury__rl_file__output_bytecodes_4_0);
	r5 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_file__output_bytecodes_4_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_file__IntroducedFrom__pred__output_bytecodes__352__5_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_30);
	tailcall(ENTRY(mercury__list__foldl_4_0),
		STATIC(mercury__rl_file__output_bytecodes_4_0));
END_MODULE

Declare_entry(mercury__list__index1_det_3_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__list__foldl2_6_4);

BEGIN_MODULE(rl_file_module22)
	init_entry(mercury__rl_file__write_proc_4_0);
	init_label(mercury__rl_file__write_proc_4_0_i2);
	init_label(mercury__rl_file__write_proc_4_0_i3);
	init_label(mercury__rl_file__write_proc_4_0_i5);
	init_label(mercury__rl_file__write_proc_4_0_i7);
	init_label(mercury__rl_file__write_proc_4_0_i8);
	init_label(mercury__rl_file__write_proc_4_0_i9);
	init_label(mercury__rl_file__write_proc_4_0_i10);
	init_label(mercury__rl_file__write_proc_4_0_i11);
	init_label(mercury__rl_file__write_proc_4_0_i12);
	init_label(mercury__rl_file__write_proc_4_0_i13);
	init_label(mercury__rl_file__write_proc_4_0_i14);
	init_label(mercury__rl_file__write_proc_4_0_i15);
	init_label(mercury__rl_file__write_proc_4_0_i16);
	init_label(mercury__rl_file__write_proc_4_0_i17);
	init_label(mercury__rl_file__write_proc_4_0_i18);
	init_label(mercury__rl_file__write_proc_4_0_i19);
	init_label(mercury__rl_file__write_proc_4_0_i20);
	init_label(mercury__rl_file__write_proc_4_0_i21);
	init_label(mercury__rl_file__write_proc_4_0_i22);
	init_label(mercury__rl_file__write_proc_4_0_i23);
	init_label(mercury__rl_file__write_proc_4_0_i26);
	init_label(mercury__rl_file__write_proc_4_0_i27);
	init_label(mercury__rl_file__write_proc_4_0_i24);
	init_label(mercury__rl_file__write_proc_4_0_i29);
	init_label(mercury__rl_file__write_proc_4_0_i30);
	init_label(mercury__rl_file__write_proc_4_0_i31);
	init_label(mercury__rl_file__write_proc_4_0_i32);
BEGIN_CODE

/* code for predicate 'write_proc'/4 in mode 0 */
Define_static(mercury__rl_file__write_proc_4_0);
	MR_incr_sp_push_msg(12, "rl_file:write_proc/4");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	call_localret(ENTRY(mercury__list__index1_det_3_0),
		mercury__rl_file__write_proc_4_0_i2,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_file__write_proc_4_0_i3);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0);
	r1 = (Word) MR_string_const("procedure(\t% ", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i7,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i3);
	r1 = (Word) MR_string_const("rl_file__write_proc", 19);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_file__write_proc_4_0_i5,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i7,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i8,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i9,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i10,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% user\n\t", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i11,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i12,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% module\n\t", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i13,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i14,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% name\n\t", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i15,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i16,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% schema\n\t", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i17,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i18,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% number of args\n\t[", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i19,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(7);
	r3 = (Word) MR_string_const(", ", 2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_32);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_proc_4_0_i20,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("],\t% arguments\n\t", 16);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i21,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i22,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% number of expressions\n\t[\n\t", 30);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i23,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	if (((Integer) MR_stackvar(9) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_file__write_proc_4_0_i24);
	r3 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(9);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__rl_file__write_exprn_2_4_0),
		mercury__rl_file__write_proc_4_0_i26,
		STATIC(mercury__rl_file__write_proc_4_0));
	}
Define_label(mercury__rl_file__write_proc_4_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r7 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_expression_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_34);
	r5 = MR_stackvar(1);
	r6 = (Integer) 1;
	call_localret(ENTRY(mercury__list__foldl2_6_4),
		mercury__rl_file__write_proc_4_0_i27,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r1 = (Word) MR_string_const("],\n\n\t", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i29,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i24);
	r2 = r1;
	r1 = (Word) MR_string_const("],\n\n\t", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i29,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_proc_4_0_i30,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\t% code length\n\t[\n\t", 20);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_proc_4_0_i31,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i31);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(11);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_36);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_proc_4_0_i32,
		STATIC(mercury__rl_file__write_proc_4_0));
Define_label(mercury__rl_file__write_proc_4_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_file__write_proc_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t]\n)", 5);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_file__write_proc_4_0));
END_MODULE

Declare_entry(mercury__io__nl_2_0);

BEGIN_MODULE(rl_file_module23)
	init_entry(mercury__rl_file__write_exprn_5_0);
	init_label(mercury__rl_file__write_exprn_5_0_i2);
	init_label(mercury__rl_file__write_exprn_5_0_i3);
	init_label(mercury__rl_file__write_exprn_5_0_i4);
	init_label(mercury__rl_file__write_exprn_5_0_i5);
	init_label(mercury__rl_file__write_exprn_5_0_i6);
	init_label(mercury__rl_file__write_exprn_5_0_i7);
	init_label(mercury__rl_file__write_exprn_5_0_i8);
	init_label(mercury__rl_file__write_exprn_5_0_i9);
	init_label(mercury__rl_file__write_exprn_5_0_i10);
	init_label(mercury__rl_file__write_exprn_5_0_i11);
	init_label(mercury__rl_file__write_exprn_5_0_i12);
	init_label(mercury__rl_file__write_exprn_5_0_i13);
	init_label(mercury__rl_file__write_exprn_5_0_i14);
	init_label(mercury__rl_file__write_exprn_5_0_i15);
	init_label(mercury__rl_file__write_exprn_5_0_i16);
	init_label(mercury__rl_file__write_exprn_5_0_i17);
	init_label(mercury__rl_file__write_exprn_5_0_i18);
	init_label(mercury__rl_file__write_exprn_5_0_i19);
	init_label(mercury__rl_file__write_exprn_5_0_i20);
	init_label(mercury__rl_file__write_exprn_5_0_i21);
	init_label(mercury__rl_file__write_exprn_5_0_i22);
	init_label(mercury__rl_file__write_exprn_5_0_i23);
BEGIN_CODE

/* code for predicate 'write_exprn'/5 in mode 0 */
Define_static(mercury__rl_file__write_exprn_5_0);
	MR_incr_sp_push_msg(11, "rl_file:write_exprn/5");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_string_const(",\n\n\t", 4);
	r2 = r3;
	MR_stackvar(3) = ((Integer) MR_stackvar(2) + (Integer) 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i2,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r3 = MR_stackvar(1);
	r2 = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_string_const("% expression ", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i3,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i4,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_file__write_exprn_5_0_i5,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("expression(\n", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i6,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i7,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i8,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i9,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i10,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i11,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i12,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i13,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i14,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i15,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i16,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i17,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_exprn_mode_0;
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__rl_file__write_exprn_5_0_i18,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i19,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_5_0_i20,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\n\t[\n\t", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i21,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(10);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_38);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_exprn_5_0_i22,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t]\n)", 5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_5_0_i23,
		STATIC(mercury__rl_file__write_exprn_5_0));
Define_label(mercury__rl_file__write_exprn_5_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module24)
	init_entry(mercury__rl_file__write_exprn_2_4_0);
	init_label(mercury__rl_file__write_exprn_2_4_0_i2);
	init_label(mercury__rl_file__write_exprn_2_4_0_i3);
	init_label(mercury__rl_file__write_exprn_2_4_0_i4);
	init_label(mercury__rl_file__write_exprn_2_4_0_i5);
	init_label(mercury__rl_file__write_exprn_2_4_0_i6);
	init_label(mercury__rl_file__write_exprn_2_4_0_i7);
	init_label(mercury__rl_file__write_exprn_2_4_0_i8);
	init_label(mercury__rl_file__write_exprn_2_4_0_i9);
	init_label(mercury__rl_file__write_exprn_2_4_0_i10);
	init_label(mercury__rl_file__write_exprn_2_4_0_i11);
	init_label(mercury__rl_file__write_exprn_2_4_0_i12);
	init_label(mercury__rl_file__write_exprn_2_4_0_i13);
	init_label(mercury__rl_file__write_exprn_2_4_0_i14);
	init_label(mercury__rl_file__write_exprn_2_4_0_i15);
	init_label(mercury__rl_file__write_exprn_2_4_0_i16);
	init_label(mercury__rl_file__write_exprn_2_4_0_i17);
	init_label(mercury__rl_file__write_exprn_2_4_0_i18);
	init_label(mercury__rl_file__write_exprn_2_4_0_i19);
	init_label(mercury__rl_file__write_exprn_2_4_0_i20);
	init_label(mercury__rl_file__write_exprn_2_4_0_i21);
BEGIN_CODE

/* code for predicate 'write_exprn_2'/4 in mode 0 */
Define_static(mercury__rl_file__write_exprn_2_4_0);
	MR_incr_sp_push_msg(10, "rl_file:write_exprn_2/4");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	r1 = (Word) MR_string_const("% expression ", 13);
	r2 = r3;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i2,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i3,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__rl_file__write_exprn_2_4_0_i4,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("expression(\n", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i5,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t\t", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i6,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i7,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i8,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i9,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i10,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i11,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i12,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i13,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i14,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i15,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i16,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_exprn_mode_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__io__write_3_0),
		mercury__rl_file__write_exprn_2_4_0_i17,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(", ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i18,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__io__write_int_3_0),
		mercury__rl_file__write_exprn_2_4_0_i19,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(",\n\t[\n\t", 6);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_file__write_exprn_2_4_0_i20,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(9);
	r3 = (Word) MR_string_const(",\n\t", 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_38);
	call_localret(ENTRY(mercury__io__write_list_5_0),
		mercury__rl_file__write_exprn_2_4_0_i21,
		STATIC(mercury__rl_file__write_exprn_2_4_0));
Define_label(mercury__rl_file__write_exprn_2_4_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_file__write_exprn_2_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n\t]\n)", 5);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_file__write_exprn_2_4_0));
END_MODULE

Declare_entry(mercury__builtin_unify_pred_2_0);

BEGIN_MODULE(rl_file_module25)
	init_entry(mercury____Unify___rl_file__byte_writer_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__byte_writer_0_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___rl_file__byte_writer_0_0));
END_MODULE

Declare_entry(mercury__builtin_index_pred_2_0);

BEGIN_MODULE(rl_file_module26)
	init_entry(mercury____Index___rl_file__byte_writer_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__byte_writer_0_0);
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___rl_file__byte_writer_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_pred_3_0);

BEGIN_MODULE(rl_file_module27)
	init_entry(mercury____Compare___rl_file__byte_writer_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__byte_writer_0_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___rl_file__byte_writer_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(rl_file_module28)
	init_entry(mercury____Unify___rl_file__rl_file_0_0);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i2);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i4);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i6);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i8);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i1017);
	init_label(mercury____Unify___rl_file__rl_file_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__rl_file_0_0);
	MR_incr_sp_push_msg(21, "rl_file:__Unify__/2");
	MR_stackvar(21) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1017);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1017);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 2) != MR_const_field(MR_mktag(0), r2, (Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1017);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__rl_file_0_0_i2,
		ENTRY(mercury____Unify___rl_file__rl_file_0_0));
Define_label(mercury____Unify___rl_file__rl_file_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__rl_file_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(11)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_relation_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__rl_file_0_0_i4,
		ENTRY(mercury____Unify___rl_file__rl_file_0_0));
Define_label(mercury____Unify___rl_file__rl_file_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__rl_file_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(13)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_variable_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__rl_file_0_0_i6,
		ENTRY(mercury____Unify___rl_file__rl_file_0_0));
Define_label(mercury____Unify___rl_file__rl_file_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__rl_file_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(15)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_procedure_0;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__rl_file_0_0_i8,
		ENTRY(mercury____Unify___rl_file__rl_file_0_0));
Define_label(mercury____Unify___rl_file__rl_file_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__rl_file_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(7) != MR_stackvar(17)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(8) != MR_stackvar(18)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(9) != MR_stackvar(19)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	if ((MR_stackvar(10) != MR_stackvar(20)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_file_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
Define_label(mercury____Unify___rl_file__rl_file_0_0_i1017);
	r1 = FALSE;
	MR_decr_sp_pop_msg(21);
	proceed();
Define_label(mercury____Unify___rl_file__rl_file_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module29)
	init_entry(mercury____Index___rl_file__rl_file_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__rl_file_0_0);
	tailcall(STATIC(mercury____Index___rl_file__rl_file_0__ua0_2_0),
		ENTRY(mercury____Index___rl_file__rl_file_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(rl_file_module30)
	init_entry(mercury____Compare___rl_file__rl_file_0_0);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i3);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i7);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i11);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i15);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i19);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i23);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i27);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i31);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i35);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i39);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i43);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i47);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i51);
	init_label(mercury____Compare___rl_file__rl_file_0_0_i67);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__rl_file_0_0);
	MR_incr_sp_push_msg(27, "rl_file:__Compare__/3");
	MR_stackvar(27) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i3,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(14);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i7,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i11,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__rl_file_0_0_i15,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(17);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i19,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_relation_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(18);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__rl_file_0_0_i23,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i27,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_variable_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__rl_file_0_0_i31,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(21);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i35,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_procedure_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(22);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__rl_file_0_0_i39,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(23);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i43,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(24);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i47,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__rl_file_0_0_i51,
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__rl_file_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__rl_file_0_0_i67);
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(26);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_file__rl_file_0_0));
Define_label(mercury____Compare___rl_file__rl_file_0_0_i67);
	MR_succip = (Code *) MR_stackvar(27);
	MR_decr_sp_pop_msg(27);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module31)
	init_entry(mercury____Unify___rl_file__constant_pool_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__constant_pool_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_file__constant_pool_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(rl_file_module32)
	init_entry(mercury____Index___rl_file__constant_pool_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__constant_pool_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___rl_file__constant_pool_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module33)
	init_entry(mercury____Compare___rl_file__constant_pool_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__constant_pool_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_1);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_file__constant_pool_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module34)
	init_entry(mercury____Unify___rl_file__rl_const_0_0);
	init_label(mercury____Unify___rl_file__rl_const_0_0_i6);
	init_label(mercury____Unify___rl_file__rl_const_0_0_i4);
	init_label(mercury____Unify___rl_file__rl_const_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__rl_const_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__rl_const_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(2), r1, (Integer) 0), (char *)MR_const_field(MR_mktag(2), r2, (Integer) 0)) != 0))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__rl_const_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != word_to_float(MR_const_field(MR_mktag(1), r2, (Integer) 0))))
		GOTO_LABEL(mercury____Unify___rl_file__rl_const_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__rl_const_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module35)
	init_entry(mercury____Index___rl_file__rl_const_0_0);
	init_label(mercury____Index___rl_file__rl_const_0_0_i5);
	init_label(mercury____Index___rl_file__rl_const_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__rl_const_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___rl_file__rl_const_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___rl_file__rl_const_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___rl_file__rl_const_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___rl_file__rl_const_0_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_string_3_0);
Declare_entry(mercury__builtin_compare_float_3_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(rl_file_module36)
	init_entry(mercury____Compare___rl_file__rl_const_0_0);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i5);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i4);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i2);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i9);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i8);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i6);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i10);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i11);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i19);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i16);
	init_label(mercury____Compare___rl_file__rl_const_0_0_i1019);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__rl_const_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i5);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i2);
Define_label(mercury____Compare___rl_file__rl_const_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i2);
Define_label(mercury____Compare___rl_file__rl_const_0_0_i4);
	r3 = (Integer) 1;
Define_label(mercury____Compare___rl_file__rl_const_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i9);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i6);
	}
Define_label(mercury____Compare___rl_file__rl_const_0_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i6);
Define_label(mercury____Compare___rl_file__rl_const_0_0_i8);
	r4 = (Integer) 1;
Define_label(mercury____Compare___rl_file__rl_const_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___rl_file__rl_const_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___rl_file__rl_const_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i1019);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_file__rl_const_0_0));
Define_label(mercury____Compare___rl_file__rl_const_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i1019);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_string_3_0),
		ENTRY(mercury____Compare___rl_file__rl_const_0_0));
Define_label(mercury____Compare___rl_file__rl_const_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_file__rl_const_0_0_i1019);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_float_3_0),
		ENTRY(mercury____Compare___rl_file__rl_const_0_0));
Define_label(mercury____Compare___rl_file__rl_const_0_0_i1019);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___rl_file__rl_const_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module37)
	init_entry(mercury____Unify___rl_file__relations_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__relations_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_39);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_file__relations_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module38)
	init_entry(mercury____Index___rl_file__relations_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__relations_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_39);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___rl_file__relations_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module39)
	init_entry(mercury____Compare___rl_file__relations_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__relations_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_file__common_39);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_file__relations_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module40)
	init_entry(mercury____Unify___rl_file__relation_0_0);
	init_label(mercury____Unify___rl_file__relation_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__relation_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__relation_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__relation_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 2) != MR_const_field(MR_mktag(0), r2, (Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__relation_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 3) != MR_const_field(MR_mktag(0), r2, (Integer) 3)))
		GOTO_LABEL(mercury____Unify___rl_file__relation_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__relation_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module41)
	init_entry(mercury____Index___rl_file__relation_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__relation_0_0);
	tailcall(STATIC(mercury____Index___rl_file__relation_0__ua0_2_0),
		ENTRY(mercury____Index___rl_file__relation_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module42)
	init_entry(mercury____Compare___rl_file__relation_0_0);
	init_label(mercury____Compare___rl_file__relation_0_0_i3);
	init_label(mercury____Compare___rl_file__relation_0_0_i7);
	init_label(mercury____Compare___rl_file__relation_0_0_i11);
	init_label(mercury____Compare___rl_file__relation_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__relation_0_0);
	MR_incr_sp_push_msg(7, "rl_file:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__relation_0_0_i3,
		ENTRY(mercury____Compare___rl_file__relation_0_0));
Define_label(mercury____Compare___rl_file__relation_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__relation_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__relation_0_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__relation_0_0_i7,
		ENTRY(mercury____Compare___rl_file__relation_0_0));
Define_label(mercury____Compare___rl_file__relation_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__relation_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__relation_0_0_i17);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__relation_0_0_i11,
		ENTRY(mercury____Compare___rl_file__relation_0_0));
Define_label(mercury____Compare___rl_file__relation_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__relation_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__relation_0_0_i17);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_file__relation_0_0));
Define_label(mercury____Compare___rl_file__relation_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module43)
	init_entry(mercury____Unify___rl_file__variable_0_0);
	init_label(mercury____Unify___rl_file__variable_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__variable_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__variable_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__variable_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__variable_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module44)
	init_entry(mercury____Index___rl_file__variable_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__variable_0_0);
	tailcall(STATIC(mercury____Index___rl_file__variable_0__ua0_2_0),
		ENTRY(mercury____Index___rl_file__variable_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module45)
	init_entry(mercury____Compare___rl_file__variable_0_0);
	init_label(mercury____Compare___rl_file__variable_0_0_i3);
	init_label(mercury____Compare___rl_file__variable_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__variable_0_0);
	MR_incr_sp_push_msg(3, "rl_file:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__variable_0_0_i3,
		ENTRY(mercury____Compare___rl_file__variable_0_0));
Define_label(mercury____Compare___rl_file__variable_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__variable_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__variable_0_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_file__variable_0_0));
Define_label(mercury____Compare___rl_file__variable_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module46)
	init_entry(mercury____Unify___rl_file__procedure_0_0);
	init_label(mercury____Unify___rl_file__procedure_0_0_i2);
	init_label(mercury____Unify___rl_file__procedure_0_0_i4);
	init_label(mercury____Unify___rl_file__procedure_0_0_i1014);
	init_label(mercury____Unify___rl_file__procedure_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__procedure_0_0);
	MR_incr_sp_push_msg(9, "rl_file:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1014);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1014);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 2) != MR_const_field(MR_mktag(0), r2, (Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1014);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 3) != MR_const_field(MR_mktag(0), r2, (Integer) 3)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1014);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 4) != MR_const_field(MR_mktag(0), r2, (Integer) 4)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1014);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__procedure_0_0_i2,
		ENTRY(mercury____Unify___rl_file__procedure_0_0));
Define_label(mercury____Unify___rl_file__procedure_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__procedure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(5)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_expression_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_file__procedure_0_0_i4,
		ENTRY(mercury____Unify___rl_file__procedure_0_0));
Define_label(mercury____Unify___rl_file__procedure_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_file__procedure_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(7)))
		GOTO_LABEL(mercury____Unify___rl_file__procedure_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_file__procedure_0_0));
Define_label(mercury____Unify___rl_file__procedure_0_0_i1014);
	r1 = FALSE;
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___rl_file__procedure_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module47)
	init_entry(mercury____Index___rl_file__procedure_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__procedure_0_0);
	tailcall(STATIC(mercury____Index___rl_file__procedure_0__ua0_2_0),
		ENTRY(mercury____Index___rl_file__procedure_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module48)
	init_entry(mercury____Compare___rl_file__procedure_0_0);
	init_label(mercury____Compare___rl_file__procedure_0_0_i3);
	init_label(mercury____Compare___rl_file__procedure_0_0_i7);
	init_label(mercury____Compare___rl_file__procedure_0_0_i11);
	init_label(mercury____Compare___rl_file__procedure_0_0_i15);
	init_label(mercury____Compare___rl_file__procedure_0_0_i19);
	init_label(mercury____Compare___rl_file__procedure_0_0_i23);
	init_label(mercury____Compare___rl_file__procedure_0_0_i27);
	init_label(mercury____Compare___rl_file__procedure_0_0_i31);
	init_label(mercury____Compare___rl_file__procedure_0_0_i35);
	init_label(mercury____Compare___rl_file__procedure_0_0_i47);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__procedure_0_0);
	MR_incr_sp_push_msg(19, "rl_file:__Compare__/3");
	MR_stackvar(19) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i3,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i7,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i11,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i15,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i19,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(14);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__procedure_0_0_i23,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(15);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i27,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = (Word) (Word *) &mercury_data_rl_file__type_ctor_info_expression_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(16);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_file__procedure_0_0_i31,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(17);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__procedure_0_0_i35,
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__procedure_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__procedure_0_0_i47);
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(18);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_file__procedure_0_0));
Define_label(mercury____Compare___rl_file__procedure_0_0_i47);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module49)
	init_entry(mercury____Unify___rl_file__expression_0_0);
	init_label(mercury____Unify___rl_file__expression_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__expression_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 2) != MR_const_field(MR_mktag(0), r2, (Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 3) != MR_const_field(MR_mktag(0), r2, (Integer) 3)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 4) != MR_const_field(MR_mktag(0), r2, (Integer) 4)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 5) != MR_const_field(MR_mktag(0), r2, (Integer) 5)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 6) != MR_const_field(MR_mktag(0), r2, (Integer) 6)))
		GOTO_LABEL(mercury____Unify___rl_file__expression_0_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_file__expression_0_0));
Define_label(mercury____Unify___rl_file__expression_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module50)
	init_entry(mercury____Index___rl_file__expression_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__expression_0_0);
	tailcall(STATIC(mercury____Index___rl_file__expression_0__ua0_2_0),
		ENTRY(mercury____Index___rl_file__expression_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module51)
	init_entry(mercury____Compare___rl_file__expression_0_0);
	init_label(mercury____Compare___rl_file__expression_0_0_i3);
	init_label(mercury____Compare___rl_file__expression_0_0_i7);
	init_label(mercury____Compare___rl_file__expression_0_0_i11);
	init_label(mercury____Compare___rl_file__expression_0_0_i15);
	init_label(mercury____Compare___rl_file__expression_0_0_i19);
	init_label(mercury____Compare___rl_file__expression_0_0_i23);
	init_label(mercury____Compare___rl_file__expression_0_0_i27);
	init_label(mercury____Compare___rl_file__expression_0_0_i37);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__expression_0_0);
	MR_incr_sp_push_msg(15, "rl_file:__Compare__/3");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i3,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i7,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i11,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i15,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i19,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i23,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_file__expression_0_0_i27,
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___rl_file__expression_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_file__expression_0_0_i37);
	r1 = (Word) (Word *) &mercury_data_rl_code__type_ctor_info_bytecode_0;
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_file__expression_0_0));
Define_label(mercury____Compare___rl_file__expression_0_0_i37);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module52)
	init_entry(mercury____Unify___rl_file__exprn_mode_0_0);
	init_label(mercury____Unify___rl_file__exprn_mode_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_file__exprn_mode_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___rl_file__exprn_mode_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_file__exprn_mode_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module53)
	init_entry(mercury____Index___rl_file__exprn_mode_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_file__exprn_mode_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(rl_file_module54)
	init_entry(mercury____Compare___rl_file__exprn_mode_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_file__exprn_mode_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_file__exprn_mode_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(rl_file_module55)
	init_entry(mercury____Unify___rl_file__rl_state_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_file__rl_state_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___rl_file__rl_state_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(rl_file_module56)
	init_entry(mercury____Index___rl_file__rl_state_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_file__rl_state_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		STATIC(mercury____Index___rl_file__rl_state_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(rl_file_module57)
	init_entry(mercury____Compare___rl_file__rl_state_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_file__rl_state_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___rl_file__rl_state_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module58)
	init_entry(mercury____Unify___rl_file__writer_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_file__writer_0_0);
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		STATIC(mercury____Unify___rl_file__writer_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module59)
	init_entry(mercury____Index___rl_file__writer_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_file__writer_0_0);
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		STATIC(mercury____Index___rl_file__writer_0_0));
END_MODULE


BEGIN_MODULE(rl_file_module60)
	init_entry(mercury____Compare___rl_file__writer_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_file__writer_0_0);
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		STATIC(mercury____Compare___rl_file__writer_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_file_maybe_bunch_0(void)
{
	rl_file_module0();
	rl_file_module1();
	rl_file_module2();
	rl_file_module3();
	rl_file_module4();
	rl_file_module5();
	rl_file_module6();
	rl_file_module7();
	rl_file_module8();
	rl_file_module9();
	rl_file_module10();
	rl_file_module11();
	rl_file_module12();
	rl_file_module13();
	rl_file_module14();
	rl_file_module15();
	rl_file_module16();
	rl_file_module17();
	rl_file_module18();
	rl_file_module19();
	rl_file_module20();
	rl_file_module21();
	rl_file_module22();
	rl_file_module23();
	rl_file_module24();
	rl_file_module25();
	rl_file_module26();
	rl_file_module27();
	rl_file_module28();
	rl_file_module29();
	rl_file_module30();
	rl_file_module31();
	rl_file_module32();
	rl_file_module33();
	rl_file_module34();
	rl_file_module35();
	rl_file_module36();
	rl_file_module37();
	rl_file_module38();
	rl_file_module39();
}

static void mercury__rl_file_maybe_bunch_1(void)
{
	rl_file_module40();
	rl_file_module41();
	rl_file_module42();
	rl_file_module43();
	rl_file_module44();
	rl_file_module45();
	rl_file_module46();
	rl_file_module47();
	rl_file_module48();
	rl_file_module49();
	rl_file_module50();
	rl_file_module51();
	rl_file_module52();
	rl_file_module53();
	rl_file_module54();
	rl_file_module55();
	rl_file_module56();
	rl_file_module57();
	rl_file_module58();
	rl_file_module59();
	rl_file_module60();
}

#endif

void mercury__rl_file__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_file__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_file_maybe_bunch_0();
		mercury__rl_file_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_byte_writer_0,
			rl_file__byte_writer_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_constant_pool_0,
			rl_file__constant_pool_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_expression_0,
			rl_file__expression_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_exprn_mode_0,
			rl_file__exprn_mode_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_procedure_0,
			rl_file__procedure_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_relation_0,
			rl_file__relation_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_relations_0,
			rl_file__relations_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_rl_const_0,
			rl_file__rl_const_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_rl_file_0,
			rl_file__rl_file_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_rl_state_0,
			rl_file__rl_state_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_variable_0,
			rl_file__variable_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_file__type_ctor_info_writer_0,
			rl_file__writer_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
