/*
** Automatically generated from `rl_info.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_info__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___rl_info__rl_info_0__ua0_2_0);
Define_extern_entry(mercury__rl_info__rl_info_init_3_0);
Declare_label(mercury__rl_info__rl_info_init_3_0_i2);
Declare_label(mercury__rl_info__rl_info_init_3_0_i3);
Declare_label(mercury__rl_info__rl_info_init_3_0_i4);
Declare_label(mercury__rl_info__rl_info_init_3_0_i5);
Declare_label(mercury__rl_info__rl_info_init_3_0_i6);
Declare_label(mercury__rl_info__rl_info_init_3_0_i7);
Declare_label(mercury__rl_info__rl_info_init_3_0_i8);
Define_extern_entry(mercury__rl_info__rl_info_get_io_state_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_io_state_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_module_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_module_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_pred_info_3_0);
Declare_label(mercury__rl_info__rl_info_get_pred_info_3_0_i2);
Declare_label(mercury__rl_info__rl_info_get_pred_info_3_0_i4);
Define_extern_entry(mercury__rl_info__rl_info_set_pred_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_proc_info_3_0);
Declare_label(mercury__rl_info__rl_info_get_proc_info_3_0_i2);
Declare_label(mercury__rl_info__rl_info_get_proc_info_3_0_i4);
Define_extern_entry(mercury__rl_info__rl_info_set_proc_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_scc_list_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_scc_list_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_relation_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_relation_info_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_next_label_id_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_next_relation_id_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_pred_proc_id_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_pred_proc_id_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_is_highest_scc_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_is_highest_scc_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_scc_entry_points_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_scc_entry_points_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_scc_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_scc_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_var_rels_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_var_rels_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_rule_number_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_rule_number_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_scc_list_args_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_scc_list_args_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_var_status_map_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_var_stats_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_var_status_4_0);
Declare_label(mercury__rl_info__rl_info_get_var_status_4_0_i3);
Declare_label(mercury__rl_info__rl_info_get_var_status_4_0_i2);
Define_extern_entry(mercury__rl_info__rl_info_get_delayed_diffs_3_0);
Define_extern_entry(mercury__rl_info__rl_info_set_delayed_diffs_3_0);
Define_extern_entry(mercury__rl_info__rl_info_get_new_temporary_4_0);
Declare_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i2);
Declare_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i3);
Declare_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i4);
Declare_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i5);
Declare_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i6);
Define_extern_entry(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i8);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i9);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i10);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i11);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i12);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i1004);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i4);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i5);
Declare_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i6);
Define_extern_entry(mercury__rl_info__rl_info_lookup_relation_4_0);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i3);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i2);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i5);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i6);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i7);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i8);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i11);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i13);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i9);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i14);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i15);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i17);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i18);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i19);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i20);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i21);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i22);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i23);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i24);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i25);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i26);
Declare_label(mercury__rl_info__rl_info_lookup_relation_4_0_i27);
Define_extern_entry(mercury__rl_info__rl_info_get_relation_schema_4_0);
Declare_label(mercury__rl_info__rl_info_get_relation_schema_4_0_i2);
Define_extern_entry(mercury__rl_info__rl_info_set_var_status_4_0);
Declare_label(mercury__rl_info__rl_info_set_var_status_4_0_i2);
Define_extern_entry(mercury__rl_info__rl_info_make_vars_equivalent_4_0);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i3);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i5);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i2);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i6);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i8);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i10);
Declare_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i1005);
Define_extern_entry(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i2);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i5);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i6);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i9);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i10);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i11);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i12);
Define_extern_entry(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i2);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i4);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i5);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i6);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i7);
Declare_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i8);
Define_extern_entry(mercury__rl_info__rl_info_get_proc_schema_4_0);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i2);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i3);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i4);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i6);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i5);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i8);
Declare_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i1003);
Define_extern_entry(mercury__rl_info__rl_info_partition_call_args_6_0);
Declare_label(mercury__rl_info__rl_info_partition_call_args_6_0_i2);
Declare_label(mercury__rl_info__rl_info_partition_call_args_6_0_i3);
Declare_label(mercury__rl_info__rl_info_partition_call_args_6_0_i4);
Define_extern_entry(mercury__rl_info__rl_info_get_var_type_4_0);
Declare_label(mercury__rl_info__rl_info_get_var_type_4_0_i2);
Declare_label(mercury__rl_info__rl_info_get_var_type_4_0_i5);
Declare_label(mercury__rl_info__rl_info_get_var_type_4_0_i6);
Declare_label(mercury__rl_info__rl_info_get_var_type_4_0_i7);
Define_extern_entry(mercury__rl_info__rl_info_bind_var_to_relation_4_0);
Declare_label(mercury__rl_info__rl_info_bind_var_to_relation_4_0_i2);
Define_extern_entry(mercury__rl_info__rl_info_lookup_var_relation_4_0);
Declare_label(mercury__rl_info__rl_info_lookup_var_relation_4_0_i2);
Define_extern_entry(mercury__rl_info__comment_3_0);
Declare_label(mercury__rl_info__comment_3_0_i2);
Declare_label(mercury__rl_info__comment_3_0_i5);
Declare_label(mercury__rl_info__comment_3_0_i6);
Declare_label(mercury__rl_info__comment_3_0_i7);
Define_extern_entry(mercury__rl_info__rl_info_write_message_4_0);
Declare_label(mercury__rl_info__rl_info_write_message_4_0_i2);
Declare_label(mercury__rl_info__rl_info_write_message_4_0_i5);
Declare_label(mercury__rl_info__rl_info_write_message_4_0_i6);
Declare_label(mercury__rl_info__rl_info_write_message_4_0_i7);
Declare_label(mercury__rl_info__rl_info_write_message_4_0_i1003);
Declare_static(mercury__rl_info__rl_info_set_relation_map_3_0);
Define_extern_entry(mercury____Unify___rl_info__rl_info_0_0);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i2);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i4);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i6);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i8);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i10);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i12);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i14);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i16);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i18);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i20);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i22);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i24);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i26);
Declare_label(mercury____Unify___rl_info__rl_info_0_0_i1);
Define_extern_entry(mercury____Index___rl_info__rl_info_0_0);
Define_extern_entry(mercury____Compare___rl_info__rl_info_0_0);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i3);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i7);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i11);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i15);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i19);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i23);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i27);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i31);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i35);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i39);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i43);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i47);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i51);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i55);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i59);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i63);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i67);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i71);
Declare_label(mercury____Compare___rl_info__rl_info_0_0_i92);
Define_extern_entry(mercury____Unify___rl_info__rl_tree_0_0);
Define_extern_entry(mercury____Index___rl_info__rl_tree_0_0);
Define_extern_entry(mercury____Compare___rl_info__rl_tree_0_0);
Define_extern_entry(mercury____Unify___rl_info__relation_spec_0_0);
Define_extern_entry(mercury____Index___rl_info__relation_spec_0_0);
Define_extern_entry(mercury____Compare___rl_info__relation_spec_0_0);
Define_extern_entry(mercury____Unify___rl_info__proc_relation_type_0_0);
Declare_label(mercury____Unify___rl_info__proc_relation_type_0_0_i1);
Define_extern_entry(mercury____Index___rl_info__proc_relation_type_0_0);
Define_extern_entry(mercury____Compare___rl_info__proc_relation_type_0_0);
Define_extern_entry(mercury____Unify___rl_info__var_status_0_0);
Declare_label(mercury____Unify___rl_info__var_status_0_0_i1008);
Declare_label(mercury____Unify___rl_info__var_status_0_0_i4);
Declare_label(mercury____Unify___rl_info__var_status_0_0_i9);
Declare_label(mercury____Unify___rl_info__var_status_0_0_i1009);
Declare_label(mercury____Unify___rl_info__var_status_0_0_i1);
Define_extern_entry(mercury____Index___rl_info__var_status_0_0);
Declare_label(mercury____Index___rl_info__var_status_0_0_i5);
Declare_label(mercury____Index___rl_info__var_status_0_0_i4);
Define_extern_entry(mercury____Compare___rl_info__var_status_0_0);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i5);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i4);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i2);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i9);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i8);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i6);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i10);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i11);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i17);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i16);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i22);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i1020);
Declare_label(mercury____Compare___rl_info__var_status_0_0_i30);
Define_extern_entry(mercury____Unify___rl_info__relation_schema_0_0);
Declare_label(mercury____Unify___rl_info__relation_schema_0_0_i6);
Declare_label(mercury____Unify___rl_info__relation_schema_0_0_i4);
Declare_label(mercury____Unify___rl_info__relation_schema_0_0_i1);
Define_extern_entry(mercury____Index___rl_info__relation_schema_0_0);
Declare_label(mercury____Index___rl_info__relation_schema_0_0_i5);
Declare_label(mercury____Index___rl_info__relation_schema_0_0_i4);
Define_extern_entry(mercury____Compare___rl_info__relation_schema_0_0);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i5);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i4);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i2);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i9);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i8);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i6);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i10);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i11);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i19);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i16);
Declare_label(mercury____Compare___rl_info__relation_schema_0_0_i1019);
Declare_static(mercury____Unify___rl_info__relation_map_0_0);
Declare_static(mercury____Index___rl_info__relation_map_0_0);
Declare_static(mercury____Compare___rl_info__relation_map_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_proc_relation_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_schema_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_spec_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_rl_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_rl_tree_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_var_status_0;

static const struct mercury_data_rl_info__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_0;

static const struct mercury_data_rl_info__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_1;

static const struct mercury_data_rl_info__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_2;

static const struct mercury_data_rl_info__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_3;

static const struct mercury_data_rl_info__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_4;

static const struct mercury_data_rl_info__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_5;

static const struct mercury_data_rl_info__common_6_struct {
	Word * f1;
}  mercury_data_rl_info__common_6;

static const struct mercury_data_rl_info__common_7_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_rl_info__common_7;

static const struct mercury_data_rl_info__common_8_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_rl_info__common_8;

static const struct mercury_data_rl_info__common_9_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_rl_info__common_9;

static const struct mercury_data_rl_info__common_10_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_rl_info__common_10;

static const struct mercury_data_rl_info__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_11;

static const struct mercury_data_rl_info__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__common_12;

static const struct mercury_data_rl_info__common_13_struct {
	Word * f1;
}  mercury_data_rl_info__common_13;

static const struct mercury_data_rl_info__common_14_struct {
	Word * f1;
}  mercury_data_rl_info__common_14;

static const struct mercury_data_rl_info__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_15;

static const struct mercury_data_rl_info__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_16;

static const struct mercury_data_rl_info__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_17;

static const struct mercury_data_rl_info__common_18_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_18;

static const struct mercury_data_rl_info__common_19_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_19;

static const struct mercury_data_rl_info__common_20_struct {
	Word * f1;
}  mercury_data_rl_info__common_20;

static const struct mercury_data_rl_info__common_21_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_21;

static const struct mercury_data_rl_info__common_22_struct {
	Word * f1;
}  mercury_data_rl_info__common_22;

static const struct mercury_data_rl_info__common_23_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_23;

static const struct mercury_data_rl_info__common_24_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_info__common_24;

static const struct mercury_data_rl_info__common_25_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_25;

static const struct mercury_data_rl_info__common_26_struct {
	Word * f1;
}  mercury_data_rl_info__common_26;

static const struct mercury_data_rl_info__common_27_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
	Word * f17;
	Word * f18;
	Word * f19;
	Word * f20;
	String f21;
	Word * f22;
	Integer f23;
	Integer f24;
}  mercury_data_rl_info__common_27;

static const struct mercury_data_rl_info__common_28_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__common_28;

static const struct mercury_data_rl_info__common_29_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_info__common_29;

static const struct mercury_data_rl_info__common_30_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_info__common_30;

static const struct mercury_data_rl_info__common_31_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_info__common_31;

static const struct mercury_data_rl_info__common_32_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_info__common_32;

static const struct mercury_data_rl_info__common_33_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__common_33;

static const struct mercury_data_rl_info__common_34_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_data_rl_info__common_34;

static const struct mercury_data_rl_info__type_ctor_functors_var_status_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_info__type_ctor_functors_var_status_0;

static const struct mercury_data_rl_info__type_ctor_layout_var_status_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_var_status_0;

static const struct mercury_data_rl_info__type_ctor_functors_rl_tree_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__type_ctor_functors_rl_tree_0;

static const struct mercury_data_rl_info__type_ctor_layout_rl_tree_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_rl_tree_0;

static const struct mercury_data_rl_info__type_ctor_functors_rl_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_info__type_ctor_functors_rl_info_0;

static const struct mercury_data_rl_info__type_ctor_layout_rl_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_rl_info_0;

static const struct mercury_data_rl_info__type_ctor_functors_relation_spec_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__type_ctor_functors_relation_spec_0;

static const struct mercury_data_rl_info__type_ctor_layout_relation_spec_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_relation_spec_0;

static const struct mercury_data_rl_info__type_ctor_functors_relation_schema_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_info__type_ctor_functors_relation_schema_0;

static const struct mercury_data_rl_info__type_ctor_layout_relation_schema_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_relation_schema_0;

static const struct mercury_data_rl_info__type_ctor_functors_relation_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__type_ctor_functors_relation_map_0;

static const struct mercury_data_rl_info__type_ctor_layout_relation_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_relation_map_0;

static const struct mercury_data_rl_info__type_ctor_functors_proc_relation_type_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_info__type_ctor_functors_proc_relation_type_0;

static const struct mercury_data_rl_info__type_ctor_layout_proc_relation_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_info__type_ctor_layout_proc_relation_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_proc_relation_type_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__proc_relation_type_0_0),
	ENTRY(mercury____Index___rl_info__proc_relation_type_0_0),
	ENTRY(mercury____Compare___rl_info__proc_relation_type_0_0),
	(Integer) 0,
	(Word *) &mercury_data_rl_info__type_ctor_functors_proc_relation_type_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_proc_relation_type_0,
	MR_string_const("rl_info", 7),
	MR_string_const("proc_relation_type", 18),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_info__relation_map_0_0),
	STATIC(mercury____Index___rl_info__relation_map_0_0),
	STATIC(mercury____Compare___rl_info__relation_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_info__type_ctor_functors_relation_map_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_relation_map_0,
	MR_string_const("rl_info", 7),
	MR_string_const("relation_map", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_schema_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__relation_schema_0_0),
	ENTRY(mercury____Index___rl_info__relation_schema_0_0),
	ENTRY(mercury____Compare___rl_info__relation_schema_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_info__type_ctor_functors_relation_schema_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_relation_schema_0,
	MR_string_const("rl_info", 7),
	MR_string_const("relation_schema", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_relation_spec_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__relation_spec_0_0),
	ENTRY(mercury____Index___rl_info__relation_spec_0_0),
	ENTRY(mercury____Compare___rl_info__relation_spec_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_info__type_ctor_functors_relation_spec_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_relation_spec_0,
	MR_string_const("rl_info", 7),
	MR_string_const("relation_spec", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_rl_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__rl_info_0_0),
	ENTRY(mercury____Index___rl_info__rl_info_0_0),
	ENTRY(mercury____Compare___rl_info__rl_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_info__type_ctor_functors_rl_info_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_rl_info_0,
	MR_string_const("rl_info", 7),
	MR_string_const("rl_info", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_rl_tree_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__rl_tree_0_0),
	ENTRY(mercury____Index___rl_info__rl_tree_0_0),
	ENTRY(mercury____Compare___rl_info__rl_tree_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_info__type_ctor_functors_rl_tree_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_rl_tree_0,
	MR_string_const("rl_info", 7),
	MR_string_const("rl_tree", 7),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_info__type_ctor_info_var_status_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___rl_info__var_status_0_0),
	ENTRY(mercury____Index___rl_info__var_status_0_0),
	ENTRY(mercury____Compare___rl_info__var_status_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_info__type_ctor_functors_var_status_0,
	(Word *) &mercury_data_rl_info__type_ctor_layout_var_status_0,
	MR_string_const("rl_info", 7),
	MR_string_const("var_status", 10),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_rl_info__common_0_struct mercury_data_rl_info__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl_info__type_ctor_info_proc_relation_type_0,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_rl_info__common_1_struct mercury_data_rl_info__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_rl_info__common_2_struct mercury_data_rl_info__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_rl_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_rl_info__common_3_struct mercury_data_rl_info__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_rl_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_rl_info__common_4_struct mercury_data_rl_info__common_4 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_3)
};

static const struct mercury_data_rl_info__common_5_struct mercury_data_rl_info__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1)
};

static const struct mercury_data_rl_info__common_6_struct mercury_data_rl_info__common_6 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_rl_info__common_7_struct mercury_data_rl_info__common_7 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_6),
	MR_string_const("closure_pred", 12),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_8_struct mercury_data_rl_info__common_8 = {
	(Integer) 0,
	MR_string_const("input_closure", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_9_struct mercury_data_rl_info__common_9 = {
	(Integer) 0,
	MR_string_const("normal", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_10_struct mercury_data_rl_info__common_10 = {
	(Integer) 0,
	(Integer) 2,
	MR_string_const("normal", 6),
	MR_string_const("input_closure", 13)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree__type_ctor_info_tree_1;
static const struct mercury_data_rl_info__common_11_struct mercury_data_rl_info__common_11 = {
	(Word *) &mercury_data_tree__type_ctor_info_tree_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_4)
};

static const struct mercury_data_rl_info__common_12_struct mercury_data_rl_info__common_12 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_11)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_info__common_13_struct mercury_data_rl_info__common_13 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_rl_info__common_14_struct mercury_data_rl_info__common_14 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
static const struct mercury_data_rl_info__common_15_struct mercury_data_rl_info__common_15 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
static const struct mercury_data_rl_info__common_16_struct mercury_data_rl_info__common_16 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0
};

static const struct mercury_data_rl_info__common_17_struct mercury_data_rl_info__common_17 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_rl_info__common_18_struct mercury_data_rl_info__common_18 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0),
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_relation_info_0;
static const struct mercury_data_rl_info__common_19_struct mercury_data_rl_info__common_19 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl__type_ctor_info_relation_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_unit_0;
static const struct mercury_data_rl_info__common_20_struct mercury_data_rl_info__common_20 = {
	(Word *) &mercury_data_std_util__type_ctor_info_unit_0
};

static const struct mercury_data_rl_info__common_21_struct mercury_data_rl_info__common_21 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1),
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_info__common_22_struct mercury_data_rl_info__common_22 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_info__common_23_struct mercury_data_rl_info__common_23 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_info__common_24_struct mercury_data_rl_info__common_24 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1),
	(Word *) &mercury_data_rl_info__type_ctor_info_var_status_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_rl_info__common_25_struct mercury_data_rl_info__common_25 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_rl_info__common_26_struct mercury_data_rl_info__common_26 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_rl_info__common_27_struct mercury_data_rl_info__common_27 = {
	(Integer) 19,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_17),
	MR_string_const("rl_info", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_28_struct mercury_data_rl_info__common_28 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0)
};

static const struct mercury_data_rl_info__common_29_struct mercury_data_rl_info__common_29 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_6),
	MR_string_const("same_as_pred", 12),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_30_struct mercury_data_rl_info__common_30 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_22),
	MR_string_const("same_as_relation", 16),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_31_struct mercury_data_rl_info__common_31 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2)
};

static const struct mercury_data_rl_info__common_32_struct mercury_data_rl_info__common_32 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_31),
	MR_string_const("schema", 6),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_info__common_33_struct mercury_data_rl_info__common_33 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_18)
};

static const struct mercury_data_rl_info__common_34_struct mercury_data_rl_info__common_34 = {
	(Integer) 1,
	(Integer) 4,
	MR_string_const("diff", 4),
	MR_string_const("new_diff", 8),
	MR_string_const("acc_diff", 8),
	MR_string_const("full", 4)
};

static const struct mercury_data_rl_info__type_ctor_functors_var_status_0_struct mercury_data_rl_info__type_ctor_functors_var_status_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_9)
};

static const struct mercury_data_rl_info__type_ctor_layout_var_status_0_struct mercury_data_rl_info__type_ctor_layout_var_status_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_10),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_info__common_7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_info__type_ctor_functors_rl_tree_0_struct mercury_data_rl_info__type_ctor_functors_rl_tree_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_11)
};

static const struct mercury_data_rl_info__type_ctor_layout_rl_tree_0_struct mercury_data_rl_info__type_ctor_layout_rl_tree_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_12)
};

static const struct mercury_data_rl_info__type_ctor_functors_rl_info_0_struct mercury_data_rl_info__type_ctor_functors_rl_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_27)
};

static const struct mercury_data_rl_info__type_ctor_layout_rl_info_0_struct mercury_data_rl_info__type_ctor_layout_rl_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_info__common_27),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_info__type_ctor_functors_relation_spec_0_struct mercury_data_rl_info__type_ctor_functors_relation_spec_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0)
};

static const struct mercury_data_rl_info__type_ctor_layout_relation_spec_0_struct mercury_data_rl_info__type_ctor_layout_relation_spec_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_28)
};

static const struct mercury_data_rl_info__type_ctor_functors_relation_schema_0_struct mercury_data_rl_info__type_ctor_functors_relation_schema_0 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_29),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_30),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_32)
};

static const struct mercury_data_rl_info__type_ctor_layout_relation_schema_0_struct mercury_data_rl_info__type_ctor_layout_relation_schema_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_info__common_29),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_info__common_30),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_info__common_32),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_info__type_ctor_functors_relation_map_0_struct mercury_data_rl_info__type_ctor_functors_relation_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_18)
};

static const struct mercury_data_rl_info__type_ctor_layout_relation_map_0_struct mercury_data_rl_info__type_ctor_layout_relation_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_33),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_info__common_33)
};

static const struct mercury_data_rl_info__type_ctor_functors_proc_relation_type_0_struct mercury_data_rl_info__type_ctor_functors_proc_relation_type_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_34)
};

static const struct mercury_data_rl_info__type_ctor_layout_proc_relation_type_0_struct mercury_data_rl_info__type_ctor_layout_proc_relation_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_34),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_34)
};


BEGIN_MODULE(rl_info_module0)
	init_entry(mercury____Index___rl_info__rl_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_info__rl_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_info__rl_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__hlds_pred__invalid_pred_id_1_0);
Declare_entry(mercury__hlds_pred__invalid_proc_id_1_0);

BEGIN_MODULE(rl_info_module1)
	init_entry(mercury__rl_info__rl_info_init_3_0);
	init_label(mercury__rl_info__rl_info_init_3_0_i2);
	init_label(mercury__rl_info__rl_info_init_3_0_i3);
	init_label(mercury__rl_info__rl_info_init_3_0_i4);
	init_label(mercury__rl_info__rl_info_init_3_0_i5);
	init_label(mercury__rl_info__rl_info_init_3_0_i6);
	init_label(mercury__rl_info__rl_info_init_3_0_i7);
	init_label(mercury__rl_info__rl_info_init_3_0_i8);
BEGIN_CODE

/* code for predicate 'rl_info_init'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_init_3_0);
	MR_incr_sp_push_msg(9, "rl_info:rl_info_init/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_info__rl_info_init_3_0_i2,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_info__rl_info_init_3_0_i3,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_info__rl_info_init_3_0_i4,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_info__rl_info_init_3_0_i5,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_info__rl_info_init_3_0_i6,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__invalid_pred_id_1_0),
		mercury__rl_info__rl_info_init_3_0_i7,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__invalid_proc_id_1_0),
		mercury__rl_info__rl_info_init_3_0_i8,
		ENTRY(mercury__rl_info__rl_info_init_3_0));
Define_label(mercury__rl_info__rl_info_init_3_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_init_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_init_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 7) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 10) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 11) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 12) = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_info__rl_info_init_3_0, "hlds_pred:pred_proc_id/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 13) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 14) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 17) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 18) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module2)
	init_entry(mercury__rl_info__rl_info_get_io_state_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_io_state'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_io_state_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module3)
	init_entry(mercury__rl_info__rl_info_set_io_state_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_io_state'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_io_state_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_io_state_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module4)
	init_entry(mercury__rl_info__rl_info_get_module_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_module_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_module_info_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module5)
	init_entry(mercury__rl_info__rl_info_set_module_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_module_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_module_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_module_info_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(rl_info_module6)
	init_entry(mercury__rl_info__rl_info_get_pred_info_3_0);
	init_label(mercury__rl_info__rl_info_get_pred_info_3_0_i2);
	init_label(mercury__rl_info__rl_info_get_pred_info_3_0_i4);
BEGIN_CODE

/* code for predicate 'rl_info_get_pred_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_pred_info_3_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_get_pred_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_pred_info_3_0_i2);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 2), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_info__rl_info_get_pred_info_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_pred_info_3_0_i4,
		ENTRY(mercury__rl_info__rl_info_get_pred_info_3_0));
Define_label(mercury__rl_info__rl_info_get_pred_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_pred_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module7)
	init_entry(mercury__rl_info__rl_info_set_pred_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_pred_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_pred_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_pred_info_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_set_pred_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_info_module8)
	init_entry(mercury__rl_info__rl_info_get_proc_info_3_0);
	init_label(mercury__rl_info__rl_info_get_proc_info_3_0_i2);
	init_label(mercury__rl_info__rl_info_get_proc_info_3_0_i4);
BEGIN_CODE

/* code for predicate 'rl_info_get_proc_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_proc_info_3_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_get_proc_info/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_proc_info_3_0_i2);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 3), (Integer) 0);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_info__rl_info_get_proc_info_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_proc_info_3_0_i4,
		ENTRY(mercury__rl_info__rl_info_get_proc_info_3_0));
Define_label(mercury__rl_info__rl_info_get_proc_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_info_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module9)
	init_entry(mercury__rl_info__rl_info_set_proc_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_proc_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_proc_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_proc_info_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_set_proc_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_info_module10)
	init_entry(mercury__rl_info__rl_info_get_scc_list_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_scc_list'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_scc_list_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module11)
	init_entry(mercury__rl_info__rl_info_set_scc_list_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_scc_list'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_scc_list_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_scc_list_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module12)
	init_entry(mercury__rl_info__rl_info_get_relation_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_relation_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_relation_info_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module13)
	init_entry(mercury__rl_info__rl_info_set_relation_info_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_relation_info'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_relation_info_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_relation_info_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module14)
	init_entry(mercury__rl_info__rl_info_get_next_label_id_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_next_label_id'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_next_label_id_3_0);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_get_next_label_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_field(MR_mktag(0), r2, (Integer) 17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_field(MR_mktag(0), r2, (Integer) 16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_field(MR_mktag(0), r2, (Integer) 15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_field(MR_mktag(0), r2, (Integer) 14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = ((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 11) + (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 11) = r1;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module15)
	init_entry(mercury__rl_info__rl_info_get_next_relation_id_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_next_relation_id'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_next_relation_id_3_0);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_get_next_relation_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_field(MR_mktag(0), r2, (Integer) 17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_field(MR_mktag(0), r2, (Integer) 16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_field(MR_mktag(0), r2, (Integer) 15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_field(MR_mktag(0), r2, (Integer) 14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = ((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 12) + (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 12) = r1;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module16)
	init_entry(mercury__rl_info__rl_info_get_pred_proc_id_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_pred_proc_id'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_pred_proc_id_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module17)
	init_entry(mercury__rl_info__rl_info_set_pred_proc_id_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_pred_proc_id'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_pred_proc_id_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_pred_proc_id_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module18)
	init_entry(mercury__rl_info__rl_info_get_is_highest_scc_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_is_highest_scc'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_is_highest_scc_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module19)
	init_entry(mercury__rl_info__rl_info_set_is_highest_scc_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_is_highest_scc'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_is_highest_scc_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_is_highest_scc_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module20)
	init_entry(mercury__rl_info__rl_info_get_scc_entry_points_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_scc_entry_points'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_scc_entry_points_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module21)
	init_entry(mercury__rl_info__rl_info_set_scc_entry_points_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_scc_entry_points'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_scc_entry_points_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_scc_entry_points_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = r3;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module22)
	init_entry(mercury__rl_info__rl_info_get_scc_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_scc'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_scc_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module23)
	init_entry(mercury__rl_info__rl_info_set_scc_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_scc'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_scc_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_scc_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module24)
	init_entry(mercury__rl_info__rl_info_get_var_rels_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_var_rels'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_var_rels_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module25)
	init_entry(mercury__rl_info__rl_info_set_var_rels_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_var_rels'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_var_rels_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_var_rels_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module26)
	init_entry(mercury__rl_info__rl_info_get_rule_number_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_rule_number'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_rule_number_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module27)
	init_entry(mercury__rl_info__rl_info_set_rule_number_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_rule_number'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_rule_number_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_rule_number_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module28)
	init_entry(mercury__rl_info__rl_info_get_scc_list_args_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_scc_list_args'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_scc_list_args_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module29)
	init_entry(mercury__rl_info__rl_info_set_scc_list_args_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_scc_list_args'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_scc_list_args_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_scc_list_args_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module30)
	init_entry(mercury__rl_info__rl_info_get_var_status_map_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_var_status_map'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_var_status_map_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module31)
	init_entry(mercury__rl_info__rl_info_set_var_stats_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_var_stats'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_var_stats_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_var_stats_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);

BEGIN_MODULE(rl_info_module32)
	init_entry(mercury__rl_info__rl_info_get_var_status_4_0);
	init_label(mercury__rl_info__rl_info_get_var_status_4_0_i3);
	init_label(mercury__rl_info__rl_info_get_var_status_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_info_get_var_status'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_var_status_4_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_get_var_status/4");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	r4 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_info__rl_info_get_var_status_4_0_i3,
		ENTRY(mercury__rl_info__rl_info_get_var_status_4_0));
Define_label(mercury__rl_info__rl_info_get_var_status_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_var_status_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_get_var_status_4_0_i2);
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_info__rl_info_get_var_status_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module33)
	init_entry(mercury__rl_info__rl_info_get_delayed_diffs_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_get_delayed_diffs'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_delayed_diffs_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module34)
	init_entry(mercury__rl_info__rl_info_set_delayed_diffs_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_delayed_diffs'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_delayed_diffs_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_delayed_diffs_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE

Declare_entry(mercury__rl__relation_id_to_string_2_0);
Declare_entry(mercury__rl__default_temporary_state_2_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(rl_info_module35)
	init_entry(mercury__rl_info__rl_info_get_new_temporary_4_0);
	init_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i2);
	init_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i3);
	init_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i4);
	init_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i5);
	init_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i6);
BEGIN_CODE

/* code for predicate 'rl_info_get_new_temporary'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_new_temporary_4_0);
	MR_incr_sp_push_msg(6, "rl_info:rl_info_get_new_temporary/4");
	MR_stackvar(6) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = ((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 12) + (Integer) 1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(5) = r3;
	MR_tempr2 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_get_new_temporary_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 18) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 18);
	MR_field(MR_mktag(0), r2, (Integer) 17) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 17);
	MR_field(MR_mktag(0), r2, (Integer) 16) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 16);
	MR_field(MR_mktag(0), r2, (Integer) 15) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 15);
	MR_field(MR_mktag(0), r2, (Integer) 14) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 14);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 11) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 11);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 8);
	MR_field(MR_mktag(0), r2, (Integer) 6) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_tempr1;
	call_localret(STATIC(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0),
		mercury__rl_info__rl_info_get_new_temporary_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0));
	}
Define_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_new_temporary_4_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__rl__relation_id_to_string_2_0),
		mercury__rl_info__rl_info_get_new_temporary_4_0_i3,
		ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0));
Define_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_new_temporary_4_0));
	MR_stackvar(3) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 1);
	call_localret(ENTRY(mercury__rl__default_temporary_state_2_0),
		mercury__rl_info__rl_info_get_new_temporary_4_0_i4,
		ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0));
Define_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_new_temporary_4_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 4, mercury__rl_info__rl_info_get_new_temporary_4_0, "rl:relation_info/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_get_new_temporary_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_info__rl_info_get_new_temporary_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0));
	}
Define_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_new_temporary_4_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_info__rl_info_set_relation_info_3_0),
		mercury__rl_info__rl_info_get_new_temporary_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0));
Define_label(mercury__rl_info__rl_info_get_new_temporary_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_new_temporary_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_arg_types_2_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__mode_util__partition_args_5_0);
Declare_entry(mercury__map__lookup_3_0);

BEGIN_MODULE(rl_info_module36)
	init_entry(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i8);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i9);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i10);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i11);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i12);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i1004);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i4);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i5);
	init_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i6);
BEGIN_CODE

/* code for predicate 'rl_info_relation_schema_to_type_list'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0);
	MR_incr_sp_push_msg(5, "rl_info:rl_info_relation_schema_to_type_list/4");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i1004);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i8,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i9,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(4) = r1;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i10,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	}
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i11,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_util__partition_args_5_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i12,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i1004);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r2;
	call_localret(STATIC(mercury__rl_info__rl_info_get_relation_info_3_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	r4 = MR_stackvar(1);
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
Define_label(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_is_base_relation_1_0);
Declare_entry(mercury__hlds_pred__pred_info_get_indexes_2_0);
static const struct mercury_const_33_struct {
	String f1;
	String f2;
	String f3;
	String f4;
}  mercury_const_33 = {
	MR_string_const("Diff", 4),
	MR_string_const("NewDiff", 7),
	MR_string_const("AccDiff", 7),
	MR_string_const("Full", 4)
};
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_arity_2_0);
Declare_entry(mercury__string__format_3_0);

BEGIN_MODULE(rl_info_module37)
	init_entry(mercury__rl_info__rl_info_lookup_relation_4_0);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i3);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i2);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i5);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i6);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i7);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i8);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i11);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i13);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i9);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i14);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i15);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i17);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i18);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i19);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i20);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i21);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i22);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i23);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i24);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i25);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i26);
	init_label(mercury__rl_info__rl_info_lookup_relation_4_0_i27);
BEGIN_CODE

/* code for predicate 'rl_info_lookup_relation'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_lookup_relation_4_0);
	MR_incr_sp_push_msg(14, "rl_info:rl_info_lookup_relation/4");
	MR_stackvar(14) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(3) = r3;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_info__rl_info_lookup_relation_4_0_i3,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_lookup_relation_4_0_i2);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i2);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__rl_info__rl_info_get_proc_schema_4_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	call_localret(STATIC(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(STATIC(mercury__rl_info__rl_info_get_module_info_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i7,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(13) = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i8,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_base_relation_1_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i11,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_lookup_relation_4_0_i9);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_stackvar(8) = r2;
	r1 = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_indexes_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i13,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(7);
	GOTO_LABEL(mercury__rl_info__rl_info_lookup_relation_4_0_i15);
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i9);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__rl__default_temporary_state_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i14,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_stackvar(8) = r3;
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i15);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_33), MR_stackvar(4));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i17,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i18,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i19,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arity_2_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i20,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(13);
	call_localret(STATIC(mercury__rl_info__rl_info_get_next_relation_id_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i21,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(10);
	r5 = r1;
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("%s-%s.%s/%i-%i", 14);
	MR_stackvar(10) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_info__rl_info_lookup_relation_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__rl_info__rl_info_lookup_relation_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r3;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__rl_info__rl_info_lookup_relation_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(11);
	MR_field(MR_mktag(1), r8, (Integer) 0) = r3;
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__rl_info__rl_info_lookup_relation_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(1), r9, (Integer) 0) = r3;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__rl_info__rl_info_lookup_relation_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r10, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i22,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
	}
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r2 = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_info__rl_info_lookup_relation_4_0, "origin_lost_in_value_number");
	MR_stackvar(8) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(10);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	call_localret(STATIC(mercury__rl_info__rl_info_get_relation_info_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i23,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r5 = MR_stackvar(8);
	r3 = r1;
	MR_stackvar(8) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i24,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_info__rl_info_set_relation_info_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i25,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i26,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_info__rl_info_set_relation_map_3_0),
		mercury__rl_info__rl_info_lookup_relation_4_0_i27,
		ENTRY(mercury__rl_info__rl_info_lookup_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_relation_4_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_relation_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module38)
	init_entry(mercury__rl_info__rl_info_get_relation_schema_4_0);
	init_label(mercury__rl_info__rl_info_get_relation_schema_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_info_get_relation_schema'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_relation_schema_4_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_get_relation_schema/4");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r4 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_info__rl_info_get_relation_schema_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_get_relation_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_relation_schema_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_relation_schema_4_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(rl_info_module39)
	init_entry(mercury__rl_info__rl_info_set_var_status_4_0);
	init_label(mercury__rl_info__rl_info_set_var_status_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_info_set_var_status'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_set_var_status_4_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_set_var_status/4");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = r1;
	r5 = r2;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_info__rl_info_set_var_status_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_set_var_status_4_0));
Define_label(mercury__rl_info__rl_info_set_var_status_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_set_var_status_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_var_status_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 15) = r1;
	r1 = r2;
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r2, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r2, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r2, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r2, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module40)
	init_entry(mercury__rl_info__rl_info_make_vars_equivalent_4_0);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i3);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i5);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i2);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i6);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i8);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i10);
	init_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i1005);
BEGIN_CODE

/* code for predicate 'rl_info_make_vars_equivalent'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_make_vars_equivalent_4_0);
	MR_incr_sp_push_msg(23, "rl_info:rl_info_make_vars_equivalent/4");
	MR_stackvar(23) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_stackvar(11) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_info__rl_info_make_vars_equivalent_4_0_i3,
		ENTRY(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i2);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(11);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_info__rl_info_make_vars_equivalent_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(18);
	MR_stackvar(22) = r1;
	GOTO_LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i6);
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i2);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(18);
	MR_stackvar(22) = MR_stackvar(11);
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i6);
	MR_stackvar(18) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_info__rl_info_make_vars_equivalent_4_0_i8,
		ENTRY(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i1005);
	r5 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	r3 = MR_stackvar(18);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_info__rl_info_make_vars_equivalent_4_0_i10,
		ENTRY(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_make_vars_equivalent_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_make_vars_equivalent_4_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(22);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_stackvar(14);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_stackvar(15);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_stackvar(16);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_stackvar(17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_stackvar(19);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_stackvar(20);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_stackvar(21);
	MR_succip = (Code *) MR_stackvar(23);
	MR_decr_sp_pop_msg(23);
	proceed();
Define_label(mercury__rl_info__rl_info_make_vars_equivalent_4_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_make_vars_equivalent_4_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_stackvar(10);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_stackvar(22);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_stackvar(12);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_stackvar(13);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_stackvar(14);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_stackvar(15);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_stackvar(16);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_stackvar(17);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_stackvar(18);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_stackvar(19);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_stackvar(20);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_stackvar(21);
	MR_succip = (Code *) MR_stackvar(23);
	MR_decr_sp_pop_msg(23);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module41)
	init_entry(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i2);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i5);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i6);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i9);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i10);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i11);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i12);
BEGIN_CODE

/* code for predicate 'rl_info_get_current_proc_output_schema'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0);
	MR_incr_sp_push_msg(3, "rl_info:rl_info_get_current_proc_output_schema/3");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	GOTO_LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i5);
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i2);
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i5,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i6);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i10,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i6);
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i9,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i10,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i11,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
	r4 = r1;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_util__partition_args_5_0),
		mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i12,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_schema_3_0));
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_get_current_proc_output_schema_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);

BEGIN_MODULE(rl_info_module42)
	init_entry(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i2);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i4);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i5);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i6);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i7);
	init_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i8);
BEGIN_CODE

/* code for predicate 'rl_info_get_current_proc_output_vars'/3 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0);
	MR_incr_sp_push_msg(3, "rl_info:rl_info_get_current_proc_output_vars/3");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i5);
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i4,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
	r1 = MR_stackvar(2);
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i5);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i6,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i7,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
	r3 = r1;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_util__partition_args_5_0),
		mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i8,
		ENTRY(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
Define_label(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_current_proc_output_vars_3_0));
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_get_markers_2_0);
Declare_entry(mercury__hlds_pred__check_marker_2_0);

BEGIN_MODULE(rl_info_module43)
	init_entry(mercury__rl_info__rl_info_get_proc_schema_4_0);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i2);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i3);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i4);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i6);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i5);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i8);
	init_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i1003);
BEGIN_CODE

/* code for predicate 'rl_info_get_proc_schema'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_proc_schema_4_0);
	MR_incr_sp_push_msg(5, "rl_info:rl_info_get_proc_schema/4");
	MR_stackvar(5) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r1;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
	}
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_arg_types_2_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i3,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_markers_2_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i4,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	r2 = (Integer) 8;
	call_localret(ENTRY(mercury__hlds_pred__check_marker_2_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_get_proc_schema_4_0, "rl_info:relation_schema/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i5);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i8,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__mode_util__partition_args_5_0),
		mercury__rl_info__rl_info_get_proc_schema_4_0_i1003,
		ENTRY(mercury__rl_info__rl_info_get_proc_schema_4_0));
Define_label(mercury__rl_info__rl_info_get_proc_schema_4_0_i1003);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_proc_schema_4_0));
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_info__rl_info_get_proc_schema_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module44)
	init_entry(mercury__rl_info__rl_info_partition_call_args_6_0);
	init_label(mercury__rl_info__rl_info_partition_call_args_6_0_i2);
	init_label(mercury__rl_info__rl_info_partition_call_args_6_0_i3);
	init_label(mercury__rl_info__rl_info_partition_call_args_6_0_i4);
BEGIN_CODE

/* code for predicate 'rl_info_partition_call_args'/6 in mode 0 */
Define_entry(mercury__rl_info__rl_info_partition_call_args_6_0);
	MR_incr_sp_push_msg(5, "rl_info:rl_info_partition_call_args/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r1;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__rl_info__rl_info_partition_call_args_6_0_i2,
		ENTRY(mercury__rl_info__rl_info_partition_call_args_6_0));
Define_label(mercury__rl_info__rl_info_partition_call_args_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_partition_call_args_6_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__rl_info__rl_info_partition_call_args_6_0_i3,
		ENTRY(mercury__rl_info__rl_info_partition_call_args_6_0));
Define_label(mercury__rl_info__rl_info_partition_call_args_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_partition_call_args_6_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_util__partition_args_5_0),
		mercury__rl_info__rl_info_partition_call_args_6_0_i4,
		ENTRY(mercury__rl_info__rl_info_partition_call_args_6_0));
Define_label(mercury__rl_info__rl_info_partition_call_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_partition_call_args_6_0));
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);

BEGIN_MODULE(rl_info_module45)
	init_entry(mercury__rl_info__rl_info_get_var_type_4_0);
	init_label(mercury__rl_info__rl_info_get_var_type_4_0_i2);
	init_label(mercury__rl_info__rl_info_get_var_type_4_0_i5);
	init_label(mercury__rl_info__rl_info_get_var_type_4_0_i6);
	init_label(mercury__rl_info__rl_info_get_var_type_4_0_i7);
BEGIN_CODE

/* code for predicate 'rl_info_get_var_type'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_get_var_type_4_0);
	MR_incr_sp_push_msg(3, "rl_info:rl_info_get_var_type/4");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__rl_info_get_var_type_4_0_i2);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 3), (Integer) 0);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__rl_info__rl_info_get_var_type_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_get_var_type_4_0));
Define_label(mercury__rl_info__rl_info_get_var_type_4_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__rl_info_get_var_type_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_get_var_type_4_0));
Define_label(mercury__rl_info__rl_info_get_var_type_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_var_type_4_0));
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__rl_info__rl_info_get_var_type_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_get_var_type_4_0));
Define_label(mercury__rl_info__rl_info_get_var_type_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_var_type_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_info__rl_info_get_var_type_4_0_i7,
		ENTRY(mercury__rl_info__rl_info_get_var_type_4_0));
Define_label(mercury__rl_info__rl_info_get_var_type_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_get_var_type_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module46)
	init_entry(mercury__rl_info__rl_info_bind_var_to_relation_4_0);
	init_label(mercury__rl_info__rl_info_bind_var_to_relation_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_info_bind_var_to_relation'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_bind_var_to_relation_4_0);
	MR_incr_sp_push_msg(3, "rl_info:rl_info_bind_var_to_relation/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	r5 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_info__rl_info_bind_var_to_relation_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_bind_var_to_relation_4_0));
Define_label(mercury__rl_info__rl_info_bind_var_to_relation_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_bind_var_to_relation_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_bind_var_to_relation_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 8) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 18) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 18);
	MR_field(MR_mktag(0), r3, (Integer) 17) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 17);
	MR_field(MR_mktag(0), r3, (Integer) 16) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 16);
	MR_field(MR_mktag(0), r3, (Integer) 15) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 15);
	MR_field(MR_mktag(0), r3, (Integer) 14) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 14);
	MR_field(MR_mktag(0), r3, (Integer) 13) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 13);
	MR_field(MR_mktag(0), r3, (Integer) 12) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 12);
	MR_field(MR_mktag(0), r3, (Integer) 11) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 11);
	MR_field(MR_mktag(0), r3, (Integer) 10) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 10);
	MR_field(MR_mktag(0), r3, (Integer) 9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 9);
	MR_field(MR_mktag(0), r3, (Integer) 7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 7);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 6);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 5);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__rl_info__rl_info_set_var_status_4_0),
		ENTRY(mercury__rl_info__rl_info_bind_var_to_relation_4_0));
	}
END_MODULE


BEGIN_MODULE(rl_info_module47)
	init_entry(mercury__rl_info__rl_info_lookup_var_relation_4_0);
	init_label(mercury__rl_info__rl_info_lookup_var_relation_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_info_lookup_var_relation'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_lookup_var_relation_4_0);
	MR_incr_sp_push_msg(2, "rl_info:rl_info_lookup_var_relation/4");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	r4 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_info__rl_info_lookup_var_relation_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_lookup_var_relation_4_0));
Define_label(mercury__rl_info__rl_info_lookup_var_relation_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_lookup_var_relation_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module48)
	init_entry(mercury__rl_info__comment_3_0);
	init_label(mercury__rl_info__comment_3_0_i2);
	init_label(mercury__rl_info__comment_3_0_i5);
	init_label(mercury__rl_info__comment_3_0_i6);
	init_label(mercury__rl_info__comment_3_0_i7);
BEGIN_CODE

/* code for predicate 'comment'/3 in mode 0 */
Define_entry(mercury__rl_info__comment_3_0);
	MR_incr_sp_push_msg(3, "rl_info:comment/3");
	MR_stackvar(3) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_info__comment_3_0_i2);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_info__comment_3_0_i6,
		ENTRY(mercury__rl_info__comment_3_0));
Define_label(mercury__rl_info__comment_3_0_i2);
	r1 = (Word) MR_string_const("rl_info_get_pred_info: pred_info not set", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_info__comment_3_0_i5,
		ENTRY(mercury__rl_info__comment_3_0));
Define_label(mercury__rl_info__comment_3_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__comment_3_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_info__comment_3_0_i6,
		ENTRY(mercury__rl_info__comment_3_0));
Define_label(mercury__rl_info__comment_3_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__comment_3_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_info__comment_3_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_string_const("%s rule %i", 10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__rl_info__comment_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_info__comment_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_info__comment_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__rl_info__comment_3_0_i7,
		ENTRY(mercury__rl_info__comment_3_0));
	}
Define_label(mercury__rl_info__comment_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__comment_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__flush_output_2_0);

BEGIN_MODULE(rl_info_module49)
	init_entry(mercury__rl_info__rl_info_write_message_4_0);
	init_label(mercury__rl_info__rl_info_write_message_4_0_i2);
	init_label(mercury__rl_info__rl_info_write_message_4_0_i5);
	init_label(mercury__rl_info__rl_info_write_message_4_0_i6);
	init_label(mercury__rl_info__rl_info_write_message_4_0_i7);
	init_label(mercury__rl_info__rl_info_write_message_4_0_i1003);
BEGIN_CODE

/* code for predicate 'rl_info_write_message'/4 in mode 0 */
Define_entry(mercury__rl_info__rl_info_write_message_4_0);
	MR_incr_sp_push_msg(4, "rl_info:rl_info_write_message/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Integer) 27;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_info__rl_info_write_message_4_0_i2,
		ENTRY(mercury__rl_info__rl_info_write_message_4_0));
Define_label(mercury__rl_info__rl_info_write_message_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_write_message_4_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_info__rl_info_write_message_4_0_i1003);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__format_3_0),
		mercury__rl_info__rl_info_write_message_4_0_i5,
		ENTRY(mercury__rl_info__rl_info_write_message_4_0));
Define_label(mercury__rl_info__rl_info_write_message_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_write_message_4_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_info__rl_info_write_message_4_0_i6,
		ENTRY(mercury__rl_info__rl_info_write_message_4_0));
Define_label(mercury__rl_info__rl_info_write_message_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_write_message_4_0));
	call_localret(ENTRY(mercury__io__flush_output_2_0),
		mercury__rl_info__rl_info_write_message_4_0_i7,
		ENTRY(mercury__rl_info__rl_info_write_message_4_0));
Define_label(mercury__rl_info__rl_info_write_message_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_info__rl_info_write_message_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_write_message_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = r2;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r2, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r2, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r2, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r2, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r2, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r2, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r2, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r2, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r2, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r2, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_info__rl_info_write_message_4_0_i1003);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_write_message_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r3, (Integer) 18);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r3, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r3, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r3, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r3, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r3, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r3, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r3, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r3, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r3, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r3, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r3, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module50)
	init_entry(mercury__rl_info__rl_info_set_relation_map_3_0);
BEGIN_CODE

/* code for predicate 'rl_info_set_relation_map'/3 in mode 0 */
Define_static(mercury__rl_info__rl_info_set_relation_map_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 19, mercury__rl_info__rl_info_set_relation_map_3_0, "rl_info:rl_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_field(MR_mktag(0), r1, (Integer) 7) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_field(MR_mktag(0), r1, (Integer) 8) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_field(MR_mktag(0), r1, (Integer) 9) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_field(MR_mktag(0), r1, (Integer) 10) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_field(MR_mktag(0), r1, (Integer) 11) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_field(MR_mktag(0), r1, (Integer) 12) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_field(MR_mktag(0), r1, (Integer) 13) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_field(MR_mktag(0), r1, (Integer) 14) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_field(MR_mktag(0), r1, (Integer) 15) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_field(MR_mktag(0), r1, (Integer) 16) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_field(MR_mktag(0), r1, (Integer) 17) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_field(MR_mktag(0), r1, (Integer) 18) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___io__state_0_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___std_util__maybe_1_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);
Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(rl_info_module51)
	init_entry(mercury____Unify___rl_info__rl_info_0_0);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i2);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i4);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i6);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i8);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i10);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i12);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i14);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i16);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i18);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i20);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i22);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i24);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i26);
	init_label(mercury____Unify___rl_info__rl_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__rl_info_0_0);
	MR_incr_sp_push_msg(37, "rl_info:__Unify__/2");
	MR_stackvar(37) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(27) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(28) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(29) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(30) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(31) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(32) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(33) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(34) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(35) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(36) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___io__state_0_0),
		mercury____Unify___rl_info__rl_info_0_0_i2,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___rl_info__rl_info_0_0_i4,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i6,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i8,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(22);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i10,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_info__rl_info_0_0_i12,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i12);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_info__rl_info_0_0_i14,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	if ((MR_stackvar(7) != MR_stackvar(25)))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(26);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_info__rl_info_0_0_i16,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i16);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(27);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i18,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	if ((MR_stackvar(10) != MR_stackvar(28)))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	if ((MR_stackvar(11) != MR_stackvar(29)))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	if ((MR_stackvar(12) != MR_stackvar(30)))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(31);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___rl_info__rl_info_0_0_i20,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i20);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(32);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i22,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(33);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_info__rl_info_0_0_i24,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i24);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(16);
	r3 = MR_stackvar(34);
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___rl_info__rl_info_0_0_i26,
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__rl_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	if ((MR_stackvar(17) != MR_stackvar(35)))
		GOTO_LABEL(mercury____Unify___rl_info__rl_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(18);
	r3 = MR_stackvar(36);
	MR_succip = (Code *) MR_stackvar(37);
	MR_decr_sp_pop_msg(37);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_info__rl_info_0_0));
Define_label(mercury____Unify___rl_info__rl_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(37);
	MR_decr_sp_pop_msg(37);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module52)
	init_entry(mercury____Index___rl_info__rl_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__rl_info_0_0);
	tailcall(STATIC(mercury____Index___rl_info__rl_info_0__ua0_2_0),
		ENTRY(mercury____Index___rl_info__rl_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___io__state_0_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___std_util__maybe_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);
Declare_entry(mercury____Compare___set__set_1_0);

BEGIN_MODULE(rl_info_module53)
	init_entry(mercury____Compare___rl_info__rl_info_0_0);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i3);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i7);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i11);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i15);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i19);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i23);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i27);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i31);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i35);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i39);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i43);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i47);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i51);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i55);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i59);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i63);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i67);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i71);
	init_label(mercury____Compare___rl_info__rl_info_0_0_i92);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__rl_info_0_0);
	MR_incr_sp_push_msg(37, "rl_info:__Compare__/3");
	MR_stackvar(37) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 8);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 9);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r1, (Integer) 10);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r1, (Integer) 11);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r1, (Integer) 12);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), r1, (Integer) 13);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), r1, (Integer) 14);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), r1, (Integer) 15);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), r1, (Integer) 16);
	MR_stackvar(17) = MR_const_field(MR_mktag(0), r1, (Integer) 17);
	MR_stackvar(18) = MR_const_field(MR_mktag(0), r1, (Integer) 18);
	MR_stackvar(19) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(20) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(21) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(22) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(23) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(24) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(25) = MR_const_field(MR_mktag(0), r2, (Integer) 7);
	MR_stackvar(26) = MR_const_field(MR_mktag(0), r2, (Integer) 8);
	MR_stackvar(27) = MR_const_field(MR_mktag(0), r2, (Integer) 9);
	MR_stackvar(28) = MR_const_field(MR_mktag(0), r2, (Integer) 10);
	MR_stackvar(29) = MR_const_field(MR_mktag(0), r2, (Integer) 11);
	MR_stackvar(30) = MR_const_field(MR_mktag(0), r2, (Integer) 12);
	MR_stackvar(31) = MR_const_field(MR_mktag(0), r2, (Integer) 13);
	MR_stackvar(32) = MR_const_field(MR_mktag(0), r2, (Integer) 14);
	MR_stackvar(33) = MR_const_field(MR_mktag(0), r2, (Integer) 15);
	MR_stackvar(34) = MR_const_field(MR_mktag(0), r2, (Integer) 16);
	MR_stackvar(35) = MR_const_field(MR_mktag(0), r2, (Integer) 17);
	MR_stackvar(36) = MR_const_field(MR_mktag(0), r2, (Integer) 18);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___io__state_0_0),
		mercury____Compare___rl_info__rl_info_0_0_i3,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(19);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___rl_info__rl_info_0_0_i7,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(20);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i11,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(21);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i15,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(22);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i19,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(23);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_info__rl_info_0_0_i23,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(24);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_info__rl_info_0_0_i27,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i27);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(25);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_info__rl_info_0_0_i31,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i31);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(26);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_info__rl_info_0_0_i35,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i35);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(27);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i39,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i39);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(28);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_info__rl_info_0_0_i43,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(29);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_info__rl_info_0_0_i47,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i47);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(30);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_info__rl_info_0_0_i51,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(31);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___rl_info__rl_info_0_0_i55,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i55);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(32);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i59,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i59);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_var_status_0;
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(33);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_info__rl_info_0_0_i63,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i63);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(16);
	r3 = MR_stackvar(34);
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___rl_info__rl_info_0_0_i67,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i67);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = MR_stackvar(17);
	r2 = MR_stackvar(35);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___rl_info__rl_info_0_0_i71,
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i71);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__rl_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__rl_info_0_0_i92);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(18);
	r3 = MR_stackvar(36);
	MR_succip = (Code *) MR_stackvar(37);
	MR_decr_sp_pop_msg(37);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_info__rl_info_0_0));
Define_label(mercury____Compare___rl_info__rl_info_0_0_i92);
	MR_succip = (Code *) MR_stackvar(37);
	MR_decr_sp_pop_msg(37);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree__tree_1_0);

BEGIN_MODULE(rl_info_module54)
	init_entry(mercury____Unify___rl_info__rl_tree_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__rl_tree_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_4);
	tailcall(ENTRY(mercury____Unify___tree__tree_1_0),
		ENTRY(mercury____Unify___rl_info__rl_tree_0_0));
END_MODULE

Declare_entry(mercury____Index___tree__tree_1_0);

BEGIN_MODULE(rl_info_module55)
	init_entry(mercury____Index___rl_info__rl_tree_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__rl_tree_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_4);
	tailcall(ENTRY(mercury____Index___tree__tree_1_0),
		ENTRY(mercury____Index___rl_info__rl_tree_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree__tree_1_0);

BEGIN_MODULE(rl_info_module56)
	init_entry(mercury____Compare___rl_info__rl_tree_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__rl_tree_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_4);
	tailcall(ENTRY(mercury____Compare___tree__tree_1_0),
		ENTRY(mercury____Compare___rl_info__rl_tree_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(rl_info_module57)
	init_entry(mercury____Unify___rl_info__relation_spec_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__relation_spec_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_proc_relation_type_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___rl_info__relation_spec_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(rl_info_module58)
	init_entry(mercury____Index___rl_info__relation_spec_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__relation_spec_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_proc_relation_type_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___rl_info__relation_spec_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(rl_info_module59)
	init_entry(mercury____Compare___rl_info__relation_spec_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__relation_spec_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_info__type_ctor_info_proc_relation_type_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___rl_info__relation_spec_0_0));
END_MODULE


BEGIN_MODULE(rl_info_module60)
	init_entry(mercury____Unify___rl_info__proc_relation_type_0_0);
	init_label(mercury____Unify___rl_info__proc_relation_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__proc_relation_type_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___rl_info__proc_relation_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_info__proc_relation_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module61)
	init_entry(mercury____Index___rl_info__proc_relation_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__proc_relation_type_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module62)
	init_entry(mercury____Compare___rl_info__proc_relation_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__proc_relation_type_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_info__proc_relation_type_0_0));
END_MODULE


BEGIN_MODULE(rl_info_module63)
	init_entry(mercury____Unify___rl_info__var_status_0_0);
	init_label(mercury____Unify___rl_info__var_status_0_0_i1008);
	init_label(mercury____Unify___rl_info__var_status_0_0_i4);
	init_label(mercury____Unify___rl_info__var_status_0_0_i9);
	init_label(mercury____Unify___rl_info__var_status_0_0_i1009);
	init_label(mercury____Unify___rl_info__var_status_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__var_status_0_0);
	MR_incr_sp_push_msg(3, "rl_info:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i4);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i1008);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i1009);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___rl_info__var_status_0_0_i1008);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___rl_info__var_status_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___rl_info__var_status_0_0_i9,
		ENTRY(mercury____Unify___rl_info__var_status_0_0));
Define_label(mercury____Unify___rl_info__var_status_0_0_i9);
	update_prof_current_proc(LABEL(mercury____Unify___rl_info__var_status_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_info__var_status_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___rl_info__var_status_0_0));
Define_label(mercury____Unify___rl_info__var_status_0_0_i1009);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___rl_info__var_status_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module64)
	init_entry(mercury____Index___rl_info__var_status_0_0);
	init_label(mercury____Index___rl_info__var_status_0_0_i5);
	init_label(mercury____Index___rl_info__var_status_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__var_status_0_0);
	r2 = MR_tag(r1);
	if ((r2 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___rl_info__var_status_0_0_i4);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Index___rl_info__var_status_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___rl_info__var_status_0_0_i5);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___rl_info__var_status_0_0_i4);
	r1 = (Integer) 2;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(rl_info_module65)
	init_entry(mercury____Compare___rl_info__var_status_0_0);
	init_label(mercury____Compare___rl_info__var_status_0_0_i5);
	init_label(mercury____Compare___rl_info__var_status_0_0_i4);
	init_label(mercury____Compare___rl_info__var_status_0_0_i2);
	init_label(mercury____Compare___rl_info__var_status_0_0_i9);
	init_label(mercury____Compare___rl_info__var_status_0_0_i8);
	init_label(mercury____Compare___rl_info__var_status_0_0_i6);
	init_label(mercury____Compare___rl_info__var_status_0_0_i10);
	init_label(mercury____Compare___rl_info__var_status_0_0_i11);
	init_label(mercury____Compare___rl_info__var_status_0_0_i17);
	init_label(mercury____Compare___rl_info__var_status_0_0_i16);
	init_label(mercury____Compare___rl_info__var_status_0_0_i22);
	init_label(mercury____Compare___rl_info__var_status_0_0_i1020);
	init_label(mercury____Compare___rl_info__var_status_0_0_i30);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__var_status_0_0);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i4);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i5);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i2);
Define_label(mercury____Compare___rl_info__var_status_0_0_i5);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i2);
Define_label(mercury____Compare___rl_info__var_status_0_0_i4);
	r3 = (Integer) 2;
Define_label(mercury____Compare___rl_info__var_status_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i8);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i9);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i6);
Define_label(mercury____Compare___rl_info__var_status_0_0_i9);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i6);
Define_label(mercury____Compare___rl_info__var_status_0_0_i8);
	r4 = (Integer) 2;
Define_label(mercury____Compare___rl_info__var_status_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___rl_info__var_status_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___rl_info__var_status_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i16);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i17);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i1020);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___rl_info__var_status_0_0_i17);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i1020);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___rl_info__var_status_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i1020);
	MR_incr_sp_push_msg(3, "rl_info:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_1);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___rl_info__var_status_0_0_i22,
		ENTRY(mercury____Compare___rl_info__var_status_0_0));
Define_label(mercury____Compare___rl_info__var_status_0_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___rl_info__var_status_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_info__var_status_0_0_i30);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___rl_info__var_status_0_0));
Define_label(mercury____Compare___rl_info__var_status_0_0_i1020);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___rl_info__var_status_0_0));
Define_label(mercury____Compare___rl_info__var_status_0_0_i30);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module66)
	init_entry(mercury____Unify___rl_info__relation_schema_0_0);
	init_label(mercury____Unify___rl_info__relation_schema_0_0_i6);
	init_label(mercury____Unify___rl_info__relation_schema_0_0_i4);
	init_label(mercury____Unify___rl_info__relation_schema_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___rl_info__relation_schema_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___rl_info__relation_schema_0_0));
Define_label(mercury____Unify___rl_info__relation_schema_0_0_i6);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i1);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___rl_info__relation_schema_0_0));
Define_label(mercury____Unify___rl_info__relation_schema_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_info__relation_schema_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_info__relation_schema_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module67)
	init_entry(mercury____Index___rl_info__relation_schema_0_0);
	init_label(mercury____Index___rl_info__relation_schema_0_0_i5);
	init_label(mercury____Index___rl_info__relation_schema_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___rl_info__relation_schema_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___rl_info__relation_schema_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___rl_info__relation_schema_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___rl_info__relation_schema_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___rl_info__relation_schema_0_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(rl_info_module68)
	init_entry(mercury____Compare___rl_info__relation_schema_0_0);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i5);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i4);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i2);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i9);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i8);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i6);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i10);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i11);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i19);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i16);
	init_label(mercury____Compare___rl_info__relation_schema_0_0_i1019);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___rl_info__relation_schema_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i5);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i2);
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i2);
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i4);
	r3 = (Integer) 1;
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i9);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i6);
	}
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i6);
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i8);
	r4 = (Integer) 1;
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i10);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i1019);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___rl_info__relation_schema_0_0));
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i1019);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_2);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___rl_info__relation_schema_0_0));
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___rl_info__relation_schema_0_0_i1019);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___rl_info__relation_schema_0_0));
Define_label(mercury____Compare___rl_info__relation_schema_0_0_i1019);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___rl_info__relation_schema_0_0));
END_MODULE


BEGIN_MODULE(rl_info_module69)
	init_entry(mercury____Unify___rl_info__relation_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_info__relation_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___rl_info__relation_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(rl_info_module70)
	init_entry(mercury____Index___rl_info__relation_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_info__relation_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___rl_info__relation_map_0_0));
END_MODULE


BEGIN_MODULE(rl_info_module71)
	init_entry(mercury____Compare___rl_info__relation_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_info__relation_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_info__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___rl_info__relation_map_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_info_maybe_bunch_0(void)
{
	rl_info_module0();
	rl_info_module1();
	rl_info_module2();
	rl_info_module3();
	rl_info_module4();
	rl_info_module5();
	rl_info_module6();
	rl_info_module7();
	rl_info_module8();
	rl_info_module9();
	rl_info_module10();
	rl_info_module11();
	rl_info_module12();
	rl_info_module13();
	rl_info_module14();
	rl_info_module15();
	rl_info_module16();
	rl_info_module17();
	rl_info_module18();
	rl_info_module19();
	rl_info_module20();
	rl_info_module21();
	rl_info_module22();
	rl_info_module23();
	rl_info_module24();
	rl_info_module25();
	rl_info_module26();
	rl_info_module27();
	rl_info_module28();
	rl_info_module29();
	rl_info_module30();
	rl_info_module31();
	rl_info_module32();
	rl_info_module33();
	rl_info_module34();
	rl_info_module35();
	rl_info_module36();
	rl_info_module37();
	rl_info_module38();
	rl_info_module39();
}

static void mercury__rl_info_maybe_bunch_1(void)
{
	rl_info_module40();
	rl_info_module41();
	rl_info_module42();
	rl_info_module43();
	rl_info_module44();
	rl_info_module45();
	rl_info_module46();
	rl_info_module47();
	rl_info_module48();
	rl_info_module49();
	rl_info_module50();
	rl_info_module51();
	rl_info_module52();
	rl_info_module53();
	rl_info_module54();
	rl_info_module55();
	rl_info_module56();
	rl_info_module57();
	rl_info_module58();
	rl_info_module59();
	rl_info_module60();
	rl_info_module61();
	rl_info_module62();
	rl_info_module63();
	rl_info_module64();
	rl_info_module65();
	rl_info_module66();
	rl_info_module67();
	rl_info_module68();
	rl_info_module69();
	rl_info_module70();
	rl_info_module71();
}

#endif

void mercury__rl_info__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_info__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_info_maybe_bunch_0();
		mercury__rl_info_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_proc_relation_type_0,
			rl_info__proc_relation_type_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_relation_map_0,
			rl_info__relation_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_relation_schema_0,
			rl_info__relation_schema_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_relation_spec_0,
			rl_info__relation_spec_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_rl_info_0,
			rl_info__rl_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_rl_tree_0,
			rl_info__rl_tree_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_info__type_ctor_info_var_status_0,
			rl_info__var_status_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
