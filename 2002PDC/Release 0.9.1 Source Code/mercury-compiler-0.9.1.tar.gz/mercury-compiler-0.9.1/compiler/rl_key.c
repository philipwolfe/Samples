/*
** Automatically generated from `rl_key.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_key__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___rl_key__var_info_0__ua0_2_0);
Declare_static(mercury____Index___rl_key__var_map_0__ua0_2_0);
Declare_static(mercury____Index___rl_key__key_info_0__ua0_2_0);
Declare_static(mercury__rl_key__det_choose_cons_id__ua0_9_0);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i7);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i8);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i10);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i11);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i14);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i4);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i16);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1007);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i18);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1009);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i24);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i27);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i25);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
Declare_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i30);
Declare_static(mercury__rl_key__IntroducedFrom__pred__unify_term_2__868__8_4_0);
Declare_static(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i3);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i5);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i6);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i7);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i8);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i2);
Declare_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i10);
Declare_static(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i3);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i5);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i6);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i2);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i7);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i8);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i9);
Declare_static(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i3);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i5);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i6);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i7);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i2);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i1007);
Declare_static(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0_i2);
Declare_static(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0_i2);
Declare_static(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__171__2_3_0);
Declare_static(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0);
Declare_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i2);
Declare_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i4);
Declare_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i1);
Define_extern_entry(mercury__rl_key__extract_indexing_5_0);
Declare_label(mercury__rl_key__extract_indexing_5_0_i7);
Declare_label(mercury__rl_key__extract_indexing_5_0_i8);
Declare_label(mercury__rl_key__extract_indexing_5_0_i9);
Declare_label(mercury__rl_key__extract_indexing_5_0_i4);
Declare_label(mercury__rl_key__extract_indexing_5_0_i5);
Define_extern_entry(mercury__rl_key__get_select_key_ranges_6_0);
Declare_label(mercury__rl_key__get_select_key_ranges_6_0_i2);
Declare_label(mercury__rl_key__get_select_key_ranges_6_0_i4);
Declare_label(mercury__rl_key__get_select_key_ranges_6_0_i1);
Define_extern_entry(mercury__rl_key__get_join_key_ranges_7_0);
Declare_label(mercury__rl_key__get_join_key_ranges_7_0_i2);
Declare_label(mercury__rl_key__get_join_key_ranges_7_0_i4);
Declare_label(mercury__rl_key__get_join_key_ranges_7_0_i1);
Declare_static(mercury__rl_key__compute_var_bound_maps_4_0);
Declare_label(mercury__rl_key__compute_var_bound_maps_4_0_i2);
Declare_label(mercury__rl_key__compute_var_bound_maps_4_0_i3);
Declare_label(mercury__rl_key__compute_var_bound_maps_4_0_i4);
Declare_static(mercury__rl_key__compute_var_bounds_4_0);
Declare_label(mercury__rl_key__compute_var_bounds_4_0_i2);
Declare_label(mercury__rl_key__compute_var_bounds_4_0_i3);
Declare_label(mercury__rl_key__compute_var_bounds_4_0_i6);
Declare_label(mercury__rl_key__compute_var_bounds_4_0_i1);
Declare_static(mercury__rl_key__useful_bounds_3_0);
Declare_label(mercury__rl_key__useful_bounds_3_0_i2);
Declare_label(mercury__rl_key__useful_bounds_3_0_i3);
Declare_label(mercury__rl_key__useful_bounds_3_0_i9);
Declare_label(mercury__rl_key__useful_bounds_3_0_i11);
Declare_label(mercury__rl_key__useful_bounds_3_0_i8);
Declare_label(mercury__rl_key__useful_bounds_3_0_i5);
Declare_label(mercury__rl_key__useful_bounds_3_0_i15);
Declare_label(mercury__rl_key__useful_bounds_3_0_i17);
Declare_label(mercury__rl_key__useful_bounds_3_0_i4);
Declare_label(mercury__rl_key__useful_bounds_3_0_i1);
Declare_static(mercury__rl_key__remove_useless_info_3_0);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i3);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i4);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i1009);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i9);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i15);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i17);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i19);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i20);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i22);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i23);
Declare_label(mercury__rl_key__remove_useless_info_3_0_i5);
Declare_static(mercury__rl_key__bounds_to_key_range_6_0);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i4);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i2);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i5);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i6);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i8);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i10);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i11);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i12);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i13);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i1016);
Declare_label(mercury__rl_key__bounds_to_key_range_6_0_i1);
Declare_static(mercury__rl_key__convert_bound_3_0);
Declare_label(mercury__rl_key__convert_bound_3_0_i1042);
Declare_label(mercury__rl_key__convert_bound_3_0_i14);
Declare_label(mercury__rl_key__convert_bound_3_0_i1047);
Declare_label(mercury__rl_key__convert_bound_3_0_i1053);
Declare_label(mercury__rl_key__convert_bound_3_0_i1055);
Declare_label(mercury__rl_key__convert_bound_3_0_i4);
Declare_label(mercury__rl_key__convert_bound_3_0_i23);
Declare_label(mercury__rl_key__convert_bound_3_0_i30);
Declare_label(mercury__rl_key__convert_bound_3_0_i1067);
Declare_label(mercury__rl_key__convert_bound_3_0_i1073);
Declare_label(mercury__rl_key__convert_bound_3_0_i1079);
Declare_label(mercury__rl_key__convert_bound_3_0_i34);
Declare_label(mercury__rl_key__convert_bound_3_0_i35);
Declare_label(mercury__rl_key__convert_bound_3_0_i36);
Declare_label(mercury__rl_key__convert_bound_3_0_i37);
Declare_label(mercury__rl_key__convert_bound_3_0_i38);
Declare_label(mercury__rl_key__convert_bound_3_0_i20);
Declare_static(mercury__rl_key__convert_key_attr_3_0);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i7);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i8);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i9);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i11);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i5);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i3);
Declare_label(mercury__rl_key__convert_key_attr_3_0_i14);
Declare_static(mercury__rl_key__split_key_tuples_3_0);
Declare_label(mercury__rl_key__split_key_tuples_3_0_i4);
Declare_label(mercury__rl_key__split_key_tuples_3_0_i5);
Declare_label(mercury__rl_key__split_key_tuples_3_0_i2);
Declare_static(mercury__rl_key__merge_key_ranges_4_0);
Declare_label(mercury__rl_key__merge_key_ranges_4_0_i1002);
Declare_label(mercury__rl_key__merge_key_ranges_4_0_i4);
Declare_label(mercury__rl_key__merge_key_ranges_4_0_i5);
Declare_label(mercury__rl_key__merge_key_ranges_4_0_i3);
Declare_static(mercury__rl_key__merge_key_ranges_2_5_0);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i3);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i13);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i16);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i10);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i11);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i9);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i24);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i27);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i21);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i22);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i29);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i1030);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i8);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i35);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i38);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i32);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i33);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i31);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i46);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i49);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i43);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i44);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i51);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i52);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i6);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i53);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i54);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i1032);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i5);
Declare_label(mercury__rl_key__merge_key_ranges_2_5_0_i55);
Declare_static(mercury__rl_key__min_max_7_0);
Declare_label(mercury__rl_key__min_max_7_0_i8);
Declare_label(mercury__rl_key__min_max_7_0_i11);
Declare_label(mercury__rl_key__min_max_7_0_i5);
Declare_label(mercury__rl_key__min_max_7_0_i1008);
Declare_label(mercury__rl_key__min_max_7_0_i6);
Declare_label(mercury__rl_key__min_max_7_0_i3);
Declare_static(mercury__rl_key__key_tuple_less_or_equal_5_0);
Declare_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1005);
Declare_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i3);
Declare_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i6);
Declare_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
Declare_static(mercury__rl_key__key_term_less_or_equal_5_0);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i3);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i8);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i13);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i15);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i20);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i1049);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i1054);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i11);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i29);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i30);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i32);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i33);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i36);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i26);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i38);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i40);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i1029);
Declare_label(mercury__rl_key__key_term_less_or_equal_5_0_i1);
Declare_static(mercury__rl_key__get_var_bounds_4_0);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i3);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i5);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i6);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i7);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i8);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i9);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i10);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i11);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i2);
Declare_label(mercury__rl_key__get_var_bounds_4_0_i12);
Declare_static(mercury__rl_key__propagate_alias_bounds_2_6_0);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i3);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i6);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i7);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i8);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i5);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i12);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i14);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i10);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i15);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i16);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i17);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i18);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i21);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i23);
Declare_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i19);
Declare_static(mercury__rl_key__propagate_alias_bounds_list_6_0);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i3);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i9);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i10);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i11);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i12);
Declare_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i8);
Declare_static(mercury__rl_key__propagate_var_bounds_6_0);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i3);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i1000);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i2);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i5);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i7);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i10);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i11);
Declare_label(mercury__rl_key__propagate_var_bounds_6_0_i12);
Declare_static(mercury__rl_key__extract_key_range_3_0);
Declare_label(mercury__rl_key__extract_key_range_3_0_i2);
Declare_label(mercury__rl_key__extract_key_range_3_0_i5);
Declare_label(mercury__rl_key__extract_key_range_3_0_i8);
Declare_label(mercury__rl_key__extract_key_range_3_0_i13);
Declare_label(mercury__rl_key__extract_key_range_3_0_i11);
Declare_label(mercury__rl_key__extract_key_range_3_0_i16);
Declare_label(mercury__rl_key__extract_key_range_3_0_i17);
Declare_label(mercury__rl_key__extract_key_range_3_0_i18);
Declare_label(mercury__rl_key__extract_key_range_3_0_i19);
Declare_label(mercury__rl_key__extract_key_range_3_0_i20);
Declare_label(mercury__rl_key__extract_key_range_3_0_i21);
Declare_label(mercury__rl_key__extract_key_range_3_0_i14);
Declare_static(mercury__rl_key__extract_key_range_disj_6_0);
Declare_label(mercury__rl_key__extract_key_range_disj_6_0_i1001);
Declare_label(mercury__rl_key__extract_key_range_disj_6_0_i4);
Declare_label(mercury__rl_key__extract_key_range_disj_6_0_i5);
Declare_label(mercury__rl_key__extract_key_range_disj_6_0_i3);
Declare_static(mercury__rl_key__extract_key_range_switch_7_0);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i1001);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i7);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i10);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i11);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i5);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i12);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i13);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i14);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i15);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i4);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i17);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i18);
Declare_label(mercury__rl_key__extract_key_range_switch_7_0_i3);
Declare_static(mercury__rl_key__extract_key_range_call_5_0);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i2);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i3);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i4);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i5);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i7);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i8);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i11);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i14);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i15);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i12);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i19);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i20);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i17);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i24);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i25);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i22);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i29);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i30);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i27);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i34);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i35);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i10);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i37);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i41);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i38);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i6);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i46);
Declare_label(mercury__rl_key__extract_key_range_call_5_0_i45);
Declare_static(mercury__rl_key__update_compare_bounds_4_0);
Declare_label(mercury__rl_key__update_compare_bounds_4_0_i8);
Declare_label(mercury__rl_key__update_compare_bounds_4_0_i3);
Declare_label(mercury__rl_key__update_compare_bounds_4_0_i11);
Declare_label(mercury__rl_key__update_compare_bounds_4_0_i1011);
Declare_label(mercury__rl_key__update_compare_bounds_4_0_i12);
Declare_static(mercury__rl_key__update_compare_bounds_2_5_0);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i3);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i6);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i7);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i8);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i5);
Declare_label(mercury__rl_key__update_compare_bounds_2_5_0_i10);
Declare_static(mercury__rl_key__is_builtin_compare_pred_4_0);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i3);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1018);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i5);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i6);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i8);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i9);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i11);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i15);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i17);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i21);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i23);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i25);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i26);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i28);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i30);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i31);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i33);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i35);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i36);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1017);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i39);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i43);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i45);
Declare_label(mercury__rl_key__is_builtin_compare_pred_4_0_i49);
Declare_static(mercury__rl_key__extract_key_range_unify_3_0);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i1005);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i8);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i10);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i12);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i11);
Declare_label(mercury__rl_key__extract_key_range_unify_3_0_i13);
Declare_static(mercury__rl_key__unify_functor_5_0);
Declare_label(mercury__rl_key__unify_functor_5_0_i2);
Declare_label(mercury__rl_key__unify_functor_5_0_i3);
Declare_label(mercury__rl_key__unify_functor_5_0_i4);
Declare_label(mercury__rl_key__unify_functor_5_0_i5);
Declare_static(mercury__rl_key__unify_var_var_4_0);
Declare_label(mercury__rl_key__unify_var_var_4_0_i2);
Declare_static(mercury__rl_key__add_alias_4_0);
Declare_label(mercury__rl_key__add_alias_4_0_i3);
Declare_label(mercury__rl_key__add_alias_4_0_i5);
Declare_label(mercury__rl_key__add_alias_4_0_i6);
Declare_label(mercury__rl_key__add_alias_4_0_i2);
Declare_label(mercury__rl_key__add_alias_4_0_i7);
Declare_label(mercury__rl_key__add_alias_4_0_i9);
Declare_static(mercury__rl_key__add_equality_constraint_4_0);
Declare_label(mercury__rl_key__add_equality_constraint_4_0_i2);
Declare_static(mercury__rl_key__add_var_lower_bound_4_0);
Declare_label(mercury__rl_key__add_var_lower_bound_4_0_i2);
Declare_label(mercury__rl_key__add_var_lower_bound_4_0_i3);
Declare_label(mercury__rl_key__add_var_lower_bound_4_0_i4);
Declare_static(mercury__rl_key__add_var_upper_bound_4_0);
Declare_label(mercury__rl_key__add_var_upper_bound_4_0_i2);
Declare_label(mercury__rl_key__add_var_upper_bound_4_0_i3);
Declare_label(mercury__rl_key__add_var_upper_bound_4_0_i4);
Declare_static(mercury__rl_key__unify_term_5_0);
Declare_label(mercury__rl_key__unify_term_5_0_i2);
Declare_label(mercury__rl_key__unify_term_5_0_i3);
Declare_static(mercury__rl_key__unify_term_2_5_0);
Declare_label(mercury__rl_key__unify_term_2_5_0_i1008);
Declare_label(mercury__rl_key__unify_term_2_5_0_i3);
Declare_label(mercury__rl_key__unify_term_2_5_0_i7);
Declare_label(mercury__rl_key__unify_term_2_5_0_i10);
Declare_label(mercury__rl_key__unify_term_2_5_0_i12);
Declare_label(mercury__rl_key__unify_term_2_5_0_i13);
Declare_label(mercury__rl_key__unify_term_2_5_0_i8);
Declare_label(mercury__rl_key__unify_term_2_5_0_i14);
Declare_static(mercury__rl_key__choose_cons_id_2_5_0);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i1008);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i4);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i3);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i5);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i8);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i1002);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i6);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i14);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i1004);
Declare_label(mercury__rl_key__choose_cons_id_2_5_0_i13);
Declare_static(mercury__rl_key__key_info_get_constraints_3_0);
Declare_static(mercury__rl_key__key_info_set_constraints_3_0);
Declare_static(mercury____Unify___rl_key__upper_lower_0_0);
Declare_label(mercury____Unify___rl_key__upper_lower_0_0_i1);
Declare_static(mercury____Index___rl_key__upper_lower_0_0);
Declare_static(mercury____Compare___rl_key__upper_lower_0_0);
Declare_static(mercury____Unify___rl_key__compare_type_0_0);
Declare_label(mercury____Unify___rl_key__compare_type_0_0_i3);
Declare_label(mercury____Unify___rl_key__compare_type_0_0_i1);
Declare_static(mercury____Index___rl_key__compare_type_0_0);
Declare_label(mercury____Index___rl_key__compare_type_0_0_i3);
Declare_static(mercury____Compare___rl_key__compare_type_0_0);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i3);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i2);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i5);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i4);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i6);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i7);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i11);
Declare_label(mercury____Compare___rl_key__compare_type_0_0_i1014);
Declare_static(mercury____Unify___rl_key__key_info_0_0);
Declare_label(mercury____Unify___rl_key__key_info_0_0_i2);
Declare_label(mercury____Unify___rl_key__key_info_0_0_i4);
Declare_label(mercury____Unify___rl_key__key_info_0_0_i1);
Declare_static(mercury____Index___rl_key__key_info_0_0);
Declare_static(mercury____Compare___rl_key__key_info_0_0);
Declare_label(mercury____Compare___rl_key__key_info_0_0_i3);
Declare_label(mercury____Compare___rl_key__key_info_0_0_i7);
Declare_label(mercury____Compare___rl_key__key_info_0_0_i12);
Declare_static(mercury____Unify___rl_key__var_map_0_0);
Declare_label(mercury____Unify___rl_key__var_map_0_0_i2);
Declare_label(mercury____Unify___rl_key__var_map_0_0_i1);
Declare_static(mercury____Index___rl_key__var_map_0_0);
Declare_static(mercury____Compare___rl_key__var_map_0_0);
Declare_label(mercury____Compare___rl_key__var_map_0_0_i3);
Declare_label(mercury____Compare___rl_key__var_map_0_0_i7);
Declare_static(mercury____Unify___rl_key__var_info_0_0);
Declare_label(mercury____Unify___rl_key__var_info_0_0_i2);
Declare_label(mercury____Unify___rl_key__var_info_0_0_i1);
Declare_static(mercury____Index___rl_key__var_info_0_0);
Declare_static(mercury____Compare___rl_key__var_info_0_0);
Declare_label(mercury____Compare___rl_key__var_info_0_0_i3);
Declare_label(mercury____Compare___rl_key__var_info_0_0_i7);

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_compare_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_key_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_upper_lower_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_var_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_var_map_0;

static const struct mercury_data_rl_key__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_0;

static const struct mercury_data_rl_key__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_1;

static const struct mercury_data_rl_key__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_2;

static const struct mercury_data_rl_key__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_3;

static const struct mercury_data_rl_key__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_4;

static const struct mercury_data_rl_key__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_5;

static const struct mercury_data_rl_key__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_6;

static const struct mercury_data_rl_key__common_7_struct {
	Word * f1;
}  mercury_data_rl_key__common_7;

static const struct mercury_data_rl_key__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_8;

static const struct mercury_data_rl_key__common_9_struct {
	Word * f1;
}  mercury_data_rl_key__common_9;

static const struct mercury_data_rl_key__common_10_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_key__common_10;

static const struct mercury_data_rl_key__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_11;

static const struct mercury_data_rl_key__common_12_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_12;

static const struct mercury_data_rl_key__common_13_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_13;

static const struct mercury_data_rl_key__common_14_struct {
	Word * f1;
}  mercury_data_rl_key__common_14;

static const struct mercury_data_rl_key__common_15_struct {
	Word * f1;
}  mercury_data_rl_key__common_15;

static const struct mercury_data_rl_key__common_16_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_key__common_16;

static const struct mercury_data_rl_key__common_17_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_17;

static const struct mercury_data_rl_key__common_18_struct {
	Word * f1;
}  mercury_data_rl_key__common_18;

static const struct mercury_data_rl_key__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_key__common_19;

static const struct mercury_data_rl_key__common_20_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_key__common_20;

static const struct mercury_data_rl_key__common_21_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_21;

static const struct mercury_data_rl_key__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_key__common_22;

static const struct mercury_data_rl_key__common_23_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_key__common_23;

static const struct mercury_data_rl_key__common_24_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_key__common_24;

static const struct mercury_data_rl_key__common_25_struct {
	Word * f1;
}  mercury_data_rl_key__common_25;

static const struct mercury_data_rl_key__common_26_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_26;

static const struct mercury_data_rl_key__common_27_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_key__common_27;

static const struct mercury_data_rl_key__common_28_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_key__common_28;

static const struct mercury_data_rl_key__common_29_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_29;

static const struct mercury_data_rl_key__common_30_struct {
	Word * f1;
}  mercury_data_rl_key__common_30;

static const struct mercury_data_rl_key__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_key__common_31;

static const struct mercury_data_rl_key__common_32_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_32;

static const struct mercury_data_rl_key__common_33_struct {
	Word * f1;
}  mercury_data_rl_key__common_33;

static const struct mercury_data_rl_key__common_34_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_key__common_34;

static const struct mercury_data_rl_key__common_35_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_key__common_35;

static const struct mercury_data_rl_key__common_36_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_key__common_36;

static const struct mercury_data_rl_key__common_37_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_key__common_37;

static const struct mercury_data_rl_key__common_38_struct {
	String f1;
	String f2;
	String f3;
	String f4;
	Integer f5;
	String f6;
	String f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	String f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	String f30;
	Integer f31;
	String f32;
}  mercury_data_rl_key__common_38;

static const struct mercury_data_rl_key__common_39_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
	Integer f10;
	Integer f11;
	Integer f12;
	Integer f13;
	Integer f14;
	Integer f15;
	Integer f16;
	Integer f17;
	Integer f18;
	Integer f19;
	Integer f20;
	Integer f21;
	Integer f22;
	Integer f23;
	Integer f24;
	Integer f25;
	Integer f26;
	Integer f27;
	Integer f28;
	Integer f29;
	Integer f30;
	Integer f31;
	Integer f32;
}  mercury_data_rl_key__common_39;

static const struct mercury_data_rl_key__common_40_struct {
	Integer f1;
}  mercury_data_rl_key__common_40;

static const struct mercury_data_rl_key__common_41_struct {
	Integer f1;
}  mercury_data_rl_key__common_41;

static const struct mercury_data_rl_key__common_42_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_rl_key__common_42;

static const struct mercury_data_rl_key__common_43_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_key__common_43;

static const struct mercury_data_rl_key__common_44_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_key__common_44;

static const struct mercury_data_rl_key__common_45_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_key__common_45;

static const struct mercury_data_rl_key__common_46_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_46;

static const struct mercury_data_rl_key__common_47_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_47;

static const struct mercury_data_rl_key__common_48_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_key__common_48;

static const struct mercury_data_rl_key__common_49_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_rl_key__common_49;

static const struct mercury_data_rl_key__common_50_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_rl_key__common_50;

static const struct mercury_data_rl_key__common_51_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_rl_key__common_51;

static const struct mercury_data_rl_key__common_52_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_key__common_52;

static const struct mercury_data_rl_key__common_53_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_rl_key__common_53;

static const struct mercury_data_rl_key__common_54_struct {
	Word * f1;
}  mercury_data_rl_key__common_54;

static const struct mercury_data_rl_key__common_55_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_rl_key__common_55;

static const struct mercury_data_rl_key__common_56_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_rl_key__common_56;

static const struct mercury_data_rl_key__common_57_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_rl_key__common_57;

static const struct mercury_data_rl_key__type_ctor_functors_var_map_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_key__type_ctor_functors_var_map_0;

static const struct mercury_data_rl_key__type_ctor_layout_var_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_layout_var_map_0;

static const struct mercury_data_rl_key__type_ctor_functors_var_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_key__type_ctor_functors_var_info_0;

static const struct mercury_data_rl_key__type_ctor_layout_var_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_layout_var_info_0;

static const struct mercury_data_rl_key__type_ctor_functors_upper_lower_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_key__type_ctor_functors_upper_lower_0;

static const struct mercury_data_rl_key__type_ctor_layout_upper_lower_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_layout_upper_lower_0;

static const struct mercury_data_rl_key__type_ctor_functors_key_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_rl_key__type_ctor_functors_key_info_0;

static const struct mercury_data_rl_key__type_ctor_layout_key_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_layout_key_info_0;

static const struct mercury_data_rl_key__type_ctor_functors_compare_type_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_functors_compare_type_0;

static const struct mercury_data_rl_key__type_ctor_layout_compare_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_key__type_ctor_layout_compare_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_compare_type_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_key__compare_type_0_0),
	STATIC(mercury____Index___rl_key__compare_type_0_0),
	STATIC(mercury____Compare___rl_key__compare_type_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_key__type_ctor_functors_compare_type_0,
	(Word *) &mercury_data_rl_key__type_ctor_layout_compare_type_0,
	MR_string_const("rl_key", 6),
	MR_string_const("compare_type", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_key_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_key__key_info_0_0),
	STATIC(mercury____Index___rl_key__key_info_0_0),
	STATIC(mercury____Compare___rl_key__key_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_key__type_ctor_functors_key_info_0,
	(Word *) &mercury_data_rl_key__type_ctor_layout_key_info_0,
	MR_string_const("rl_key", 6),
	MR_string_const("key_info", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_upper_lower_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_key__upper_lower_0_0),
	STATIC(mercury____Index___rl_key__upper_lower_0_0),
	STATIC(mercury____Compare___rl_key__upper_lower_0_0),
	(Integer) 0,
	(Word *) &mercury_data_rl_key__type_ctor_functors_upper_lower_0,
	(Word *) &mercury_data_rl_key__type_ctor_layout_upper_lower_0,
	MR_string_const("rl_key", 6),
	MR_string_const("upper_lower", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_var_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_key__var_info_0_0),
	STATIC(mercury____Index___rl_key__var_info_0_0),
	STATIC(mercury____Compare___rl_key__var_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_key__type_ctor_functors_var_info_0,
	(Word *) &mercury_data_rl_key__type_ctor_layout_var_info_0,
	MR_string_const("rl_key", 6),
	MR_string_const("var_info", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_key__type_ctor_info_var_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_key__var_map_0_0),
	STATIC(mercury____Index___rl_key__var_map_0_0),
	STATIC(mercury____Compare___rl_key__var_map_0_0),
	(Integer) 2,
	(Word *) &mercury_data_rl_key__type_ctor_functors_var_map_0,
	(Word *) &mercury_data_rl_key__type_ctor_layout_var_map_0,
	MR_string_const("rl_key", 6),
	MR_string_const("var_map", 7),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_rl_key__common_0_struct mercury_data_rl_key__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_rl_key__common_1_struct mercury_data_rl_key__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_rl_key__common_2_struct mercury_data_rl_key__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_rl_key__common_3_struct mercury_data_rl_key__common_3 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_key_term_node_0;
static const struct mercury_data_rl_key__common_4_struct mercury_data_rl_key__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_key_term_node_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_3)
};

static const struct mercury_data_rl_key__common_5_struct mercury_data_rl_key__common_5 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_rl_key__common_6_struct mercury_data_rl_key__common_6 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_rl_key__common_7_struct mercury_data_rl_key__common_7 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_rl_key__common_8_struct mercury_data_rl_key__common_8 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1)
};

static const struct mercury_data_rl_key__common_9_struct mercury_data_rl_key__common_9 = {
	(Word *) &mercury_data_rl_key__type_ctor_info_var_map_0
};

static const struct mercury_data_rl_key__common_10_struct mercury_data_rl_key__common_10 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("compute_var_bounds", 18),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_rl_key__common_11_struct mercury_data_rl_key__common_11 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_8)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_rl_key__common_12_struct mercury_data_rl_key__common_12 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_rl_key__common_13_struct mercury_data_rl_key__common_13 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_index_spec_0;
static const struct mercury_data_rl_key__common_14_struct mercury_data_rl_key__common_14 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_index_spec_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_key_range_0;
static const struct mercury_data_rl_key__common_15_struct mercury_data_rl_key__common_15 = {
	(Word *) &mercury_data_rl__type_ctor_info_key_range_0
};

static const struct mercury_data_rl_key__common_16_struct mercury_data_rl_key__common_16 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("bounds_to_key_range", 19),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_14),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_15)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_rl_key__common_17_struct mercury_data_rl_key__common_17 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

static const struct mercury_data_rl_key__common_18_struct mercury_data_rl_key__common_18 = {
	(Word *) &mercury_data_rl_key__type_ctor_info_key_info_0
};

static const struct mercury_data_rl_key__common_19_struct mercury_data_rl_key__common_19 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("extract_key_range", 17),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_18)
};

static const struct mercury_data_rl_key__common_20_struct mercury_data_rl_key__common_20 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_19),
	STATIC(mercury__rl_key__extract_key_range_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_key__common_21_struct mercury_data_rl_key__common_21 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5)
};

static const struct mercury_data_rl_key__common_22_struct mercury_data_rl_key__common_22 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("get_var_bounds", 14),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21)
};

static const struct mercury_data_rl_key__common_23_struct mercury_data_rl_key__common_23 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("useful_bounds", 13),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21)
};

static const struct mercury_data_rl_key__common_24_struct mercury_data_rl_key__common_24 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("remove_useless_info", 19),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

static const struct mercury_data_rl_key__common_25_struct mercury_data_rl_key__common_25 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_rl_key__common_26_struct mercury_data_rl_key__common_26 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5)
};

static const struct mercury_data_rl_key__common_27_struct mercury_data_rl_key__common_27 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__bounds_to_key_range__166__1", 49),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_25),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_26)
};

static const struct mercury_data_rl_key__common_28_struct mercury_data_rl_key__common_28 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__bounds_to_key_range__171__2", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_8),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_25),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1)
};

static const struct mercury_data_rl_key__common_29_struct mercury_data_rl_key__common_29 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_key_attr_0;
static const struct mercury_data_rl_key__common_30_struct mercury_data_rl_key__common_30 = {
	(Word *) &mercury_data_rl__type_ctor_info_key_attr_0
};

static const struct mercury_data_rl_key__common_31_struct mercury_data_rl_key__common_31 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("convert_key_attr", 16),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_30)
};

static const struct mercury_data_rl_key__common_32_struct mercury_data_rl_key__common_32 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_key_attr_0,
	(Word *) &mercury_data_rl__type_ctor_info_key_attr_0
};

static const struct mercury_data_rl_key__common_33_struct mercury_data_rl_key__common_33 = {
	(Word *) &mercury_data_rl_key__type_ctor_info_upper_lower_0
};

static const struct mercury_data_rl_key__common_34_struct mercury_data_rl_key__common_34 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("propagate_var_bounds", 20),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_33),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

static const struct mercury_data_rl_key__common_35_struct mercury_data_rl_key__common_35 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__unify_var_var__731__6", 43),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9)
};

static const struct mercury_data_rl_key__common_36_struct mercury_data_rl_key__common_36 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__add_compare_result__608__3", 48),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9)
};

static const struct mercury_data_rl_key__common_37_struct mercury_data_rl_key__common_37 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__update_bounds__823__7", 43),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9)
};

static const struct mercury_data_rl_key__common_38_struct mercury_data_rl_key__common_38 = {
	MR_string_const("compare", 7),
	MR_string_const(">=", 2),
	MR_string_const("=<", 2),
	MR_string_const("builtin_compare_float", 21),
	(Integer) 0,
	MR_string_const("builtin_compare_string", 22),
	MR_string_const("builtin_compare_int", 19),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("__Compare__", 11),
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	(Integer) 0,
	MR_string_const("<", 1),
	(Integer) 0,
	MR_string_const(">", 1)
};

static const struct mercury_data_rl_key__common_39_struct mercury_data_rl_key__common_39 = {
	(Integer) -1,
	(Integer) -1,
	(Integer) -1,
	(Integer) 2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -2,
	(Integer) -1,
	(Integer) -2,
	(Integer) -1
};

static const struct mercury_data_rl_key__common_40_struct mercury_data_rl_key__common_40 = {
	(Integer) 2
};

static const struct mercury_data_rl_key__common_41_struct mercury_data_rl_key__common_41 = {
	(Integer) 1
};

static const struct mercury_data_rl_key__common_42_struct mercury_data_rl_key__common_42 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__unify_functor__696__4", 43),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

static const struct mercury_data_rl_key__common_43_struct mercury_data_rl_key__common_43 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_42),
	STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0),
	(Integer) 0
};

static const struct mercury_data_rl_key__common_44_struct mercury_data_rl_key__common_44 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__unify_functor__707__5", 43),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_9)
};

static const struct mercury_data_rl_key__common_45_struct mercury_data_rl_key__common_45 = {
	(Integer) 0,
	MR_string_const("rl_key", 6),
	MR_string_const("rl_key", 6),
	MR_string_const("IntroducedFrom__pred__unify_term_2__868__8", 42),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_33),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_rl_key__common_46_struct mercury_data_rl_key__common_46 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_string_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12)
};

static const struct mercury_data_rl_key__common_47_struct mercury_data_rl_key__common_47 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	(Word *) &mercury_data_rl_key__type_ctor_info_var_info_0
};

static const struct mercury_data_rl_key__common_48_struct mercury_data_rl_key__common_48 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_2)
};

static const struct mercury_data_rl_key__common_49_struct mercury_data_rl_key__common_49 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_47),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_48),
	MR_string_const("var_map", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_key__common_50_struct mercury_data_rl_key__common_50 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4),
	MR_string_const("var_info", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_key__common_51_struct mercury_data_rl_key__common_51 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("upper", 5),
	MR_string_const("lower", 5)
};

static const struct mercury_data_rl_key__common_52_struct mercury_data_rl_key__common_52 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_rl_key__type_ctor_info_var_map_0
};

static const struct mercury_data_rl_key__common_53_struct mercury_data_rl_key__common_53 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_7),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_13),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_52),
	MR_string_const("key_info", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_builtin__type_ctor_info_comparison_result_0;
static const struct mercury_data_rl_key__common_54_struct mercury_data_rl_key__common_54 = {
	(Word *) &mercury_data_builtin__type_ctor_info_comparison_result_0
};

static const struct mercury_data_rl_key__common_55_struct mercury_data_rl_key__common_55 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_54),
	MR_string_const("result", 6),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_key__common_56_struct mercury_data_rl_key__common_56 = {
	(Integer) 0,
	MR_string_const("unknown", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_rl_key__common_57_struct mercury_data_rl_key__common_57 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("unknown", 7)
};

static const struct mercury_data_rl_key__type_ctor_functors_var_map_0_struct mercury_data_rl_key__type_ctor_functors_var_map_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_49)
};

static const struct mercury_data_rl_key__type_ctor_layout_var_map_0_struct mercury_data_rl_key__type_ctor_layout_var_map_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_49),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_key__type_ctor_functors_var_info_0_struct mercury_data_rl_key__type_ctor_functors_var_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_50)
};

static const struct mercury_data_rl_key__type_ctor_layout_var_info_0_struct mercury_data_rl_key__type_ctor_layout_var_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_50),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_key__type_ctor_functors_upper_lower_0_struct mercury_data_rl_key__type_ctor_functors_upper_lower_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_51)
};

static const struct mercury_data_rl_key__type_ctor_layout_upper_lower_0_struct mercury_data_rl_key__type_ctor_layout_upper_lower_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_51)
};

static const struct mercury_data_rl_key__type_ctor_functors_key_info_0_struct mercury_data_rl_key__type_ctor_functors_key_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_53)
};

static const struct mercury_data_rl_key__type_ctor_layout_key_info_0_struct mercury_data_rl_key__type_ctor_layout_key_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_53),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_rl_key__type_ctor_functors_compare_type_0_struct mercury_data_rl_key__type_ctor_functors_compare_type_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_56)
};

static const struct mercury_data_rl_key__type_ctor_layout_compare_type_0_struct mercury_data_rl_key__type_ctor_layout_compare_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_57),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_55),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(rl_key_module0)
	init_entry(mercury____Index___rl_key__var_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_key__var_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_key__var_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module1)
	init_entry(mercury____Index___rl_key__var_map_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_key__var_map_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_key__var_map_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module2)
	init_entry(mercury____Index___rl_key__key_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___rl_key__key_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___rl_key__key_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_types_2_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(rl_key_module3)
	init_entry(mercury__rl_key__det_choose_cons_id__ua0_9_0);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i7);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i8);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i10);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i11);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i14);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i4);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i16);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1007);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i18);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1009);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i24);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i27);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i25);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	init_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i30);
BEGIN_CODE

/* code for predicate 'det_choose_cons_id__ua0'/9 in mode 0 */
Define_static(mercury__rl_key__det_choose_cons_id__ua0_9_0);
	MR_incr_sp_push_msg(7, "rl_key:det_choose_cons_id__ua0/9");
	MR_stackvar(7) = (Word) MR_succip;
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i4);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i4);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i7,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i8,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i10,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i11,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__rl_key__choose_cons_id_2_5_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i14,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	r1 = r2;
	r2 = MR_stackvar(3);
	GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i24);
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i4);
	MR_stackvar(1) = r2;
	r1 = r4;
	r2 = r6;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i16,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i18);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1009);
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1007);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i24);
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i18);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1007);
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i1009);
	r2 = MR_stackvar(3);
	r1 = r2;
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i24);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i27,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0_i25);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i25);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i3);
	r1 = (Word) MR_string_const("rl_key__det_choose_cons_id: invalid cons_id pair", 48);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_key__det_choose_cons_id__ua0_9_0_i30,
		STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0));
Define_label(mercury__rl_key__det_choose_cons_id__ua0_9_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_key__det_choose_cons_id__ua0_9_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module4)
	init_entry(mercury__rl_key__IntroducedFrom__pred__unify_term_2__868__8_4_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__unify_term_2__868__8'/4 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__unify_term_2__868__8_4_0);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	tailcall(STATIC(mercury__rl_key__unify_term_5_0),
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_term_2__868__8_4_0));
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__set__union_3_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(rl_key_module5)
	init_entry(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i3);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i5);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i6);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i7);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i8);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i2);
	init_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i10);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__update_bounds__823__7'/6 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	MR_incr_sp_push_msg(10, "rl_key:IntroducedFrom__pred__update_bounds__823__7/6");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(4) = r4;
	MR_stackvar(3) = r3;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(5) = r3;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i3,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i2);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_tempr2 = MR_stackvar(2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i5,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	r3 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(4);
	r2 = (Integer) 1;
	r4 = MR_stackvar(9);
	call_localret(STATIC(mercury__rl_key__unify_term_2_5_0),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i6,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(8);
	MR_tempr2 = MR_stackvar(7);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(7) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	MR_tempr3 = MR_stackvar(3);
	r3 = MR_const_field(MR_mktag(0), MR_tempr3, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i7,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	r2 = (Integer) 0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(9);
	call_localret(STATIC(mercury__rl_key__unify_term_2_5_0),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i8,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0, "rl_key:var_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i10,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i2);
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0, "rl_key:var_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i10,
		STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0, "rl_key:var_map/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__set__singleton_set_2_1);

BEGIN_MODULE(rl_key_module6)
	init_entry(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i3);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i5);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i6);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i2);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i7);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i8);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i9);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__unify_var_var__731__6'/4 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	MR_incr_sp_push_msg(7, "rl_key:IntroducedFrom__pred__unify_var_var__731__6/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i3,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i5,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_tempr2 = MR_stackvar(5);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i6,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "rl_key:var_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(5);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i8);
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i7,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "rl_key:var_info/0");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i8);
	MR_stackvar(1) = r4;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i9,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0, "rl_key:var_map/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__rl_key__add_alias_4_0),
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0));
END_MODULE


BEGIN_MODULE(rl_key_module7)
	init_entry(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i3);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i5);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i6);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i7);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i2);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i1007);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__unify_functor__707__5'/5 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0);
	MR_incr_sp_push_msg(9, "rl_key:IntroducedFrom__pred__unify_functor__707__5/5");
	MR_stackvar(9) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(3) = r3;
	r3 = MR_tempr1;
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i3,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i2);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_tempr2 = MR_stackvar(2);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i5,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	r3 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(3);
	r2 = (Integer) 1;
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_key__unify_term_2_5_0),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i6,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r2 = (Integer) 0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_key__unify_term_5_0),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i7,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i1007,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i2);
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i1007,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	}
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0_i1007);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0, "rl_key:var_map/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	r1 = TRUE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module8)
	init_entry(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__unify_functor__696__4'/2 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0);
	MR_incr_sp_push_msg(1, "rl_key:IntroducedFrom__pred__unify_functor__696__4/2");
	MR_stackvar(1) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0_i2,
		STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__unify_functor__696__4_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module9)
	init_entry(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__add_compare_result__608__3'/5 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0);
	MR_incr_sp_push_msg(2, "rl_key:IntroducedFrom__pred__add_compare_result__608__3/5");
	MR_stackvar(2) = (Word) MR_succip;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r3;
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r4 = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_2);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0_i2,
		STATIC(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0, "rl_key:var_map/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__index1_3_0);

BEGIN_MODULE(rl_key_module10)
	init_entry(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__171__2_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__bounds_to_key_range__171__2'/3 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__171__2_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	tailcall(ENTRY(mercury__list__index1_3_0),
		STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__171__2_3_0));
END_MODULE


BEGIN_MODULE(rl_key_module11)
	init_entry(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0);
	init_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i2);
	init_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i4);
	init_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__bounds_to_key_range__166__1'/4 in mode 0 */
Define_static(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0);
	MR_incr_sp_push_msg(3, "rl_key:IntroducedFrom__pred__bounds_to_key_range__166__1/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__list__index1_3_0),
		mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i2,
		STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i1);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i4,
		STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0));
Define_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__list__filter_map_3_0);

BEGIN_MODULE(rl_key_module12)
	init_entry(mercury__rl_key__extract_indexing_5_0);
	init_label(mercury__rl_key__extract_indexing_5_0_i7);
	init_label(mercury__rl_key__extract_indexing_5_0_i8);
	init_label(mercury__rl_key__extract_indexing_5_0_i9);
	init_label(mercury__rl_key__extract_indexing_5_0_i4);
	init_label(mercury__rl_key__extract_indexing_5_0_i5);
BEGIN_CODE

/* code for predicate 'extract_indexing'/5 in mode 0 */
Define_entry(mercury__rl_key__extract_indexing_5_0);
	MR_incr_sp_push_msg(4, "rl_key:extract_indexing/5");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__extract_indexing_5_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__rl_key__extract_indexing_5_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__extract_indexing_5_0_i7);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__rl_key__extract_indexing_5_0_i8,
		ENTRY(mercury__rl_key__extract_indexing_5_0));
Define_label(mercury__rl_key__extract_indexing_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_indexing_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_key__compute_var_bound_maps_4_0),
		mercury__rl_key__extract_indexing_5_0_i9,
		ENTRY(mercury__rl_key__extract_indexing_5_0));
	}
Define_label(mercury__rl_key__extract_indexing_5_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_indexing_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__extract_indexing_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__compute_var_bounds_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_10);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__filter_map_3_0),
		ENTRY(mercury__rl_key__extract_indexing_5_0));
Define_label(mercury__rl_key__extract_indexing_5_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r2;
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	call_localret(STATIC(mercury__rl_key__compute_var_bound_maps_4_0),
		mercury__rl_key__extract_indexing_5_0_i5,
		ENTRY(mercury__rl_key__extract_indexing_5_0));
Define_label(mercury__rl_key__extract_indexing_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_indexing_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__extract_indexing_5_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_10);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__compute_var_bounds_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__filter_map_3_0),
		ENTRY(mercury__rl_key__extract_indexing_5_0));
END_MODULE

Declare_entry(mercury__list__map_3_1);

BEGIN_MODULE(rl_key_module13)
	init_entry(mercury__rl_key__get_select_key_ranges_6_0);
	init_label(mercury__rl_key__get_select_key_ranges_6_0_i2);
	init_label(mercury__rl_key__get_select_key_ranges_6_0_i4);
	init_label(mercury__rl_key__get_select_key_ranges_6_0_i1);
BEGIN_CODE

/* code for predicate 'get_select_key_ranges'/6 in mode 0 */
Define_entry(mercury__rl_key__get_select_key_ranges_6_0);
	MR_incr_sp_push_msg(2, "rl_key:get_select_key_ranges/6");
	MR_stackvar(2) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 7, mercury__rl_key__get_select_key_ranges_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 6) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 5) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6);
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_range_0;
	r4 = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_key__bounds_to_key_range_6_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_16);
	call_localret(ENTRY(mercury__list__map_3_1),
		mercury__rl_key__get_select_key_ranges_6_0_i2,
		ENTRY(mercury__rl_key__get_select_key_ranges_6_0));
	}
Define_label(mercury__rl_key__get_select_key_ranges_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__get_select_key_ranges_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__get_select_key_ranges_6_0_i1);
	r1 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__rl_key__merge_key_ranges_4_0),
		mercury__rl_key__get_select_key_ranges_6_0_i4,
		ENTRY(mercury__rl_key__get_select_key_ranges_6_0));
Define_label(mercury__rl_key__get_select_key_ranges_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__get_select_key_ranges_6_0));
	r2 = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__get_select_key_ranges_6_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module14)
	init_entry(mercury__rl_key__get_join_key_ranges_7_0);
	init_label(mercury__rl_key__get_join_key_ranges_7_0_i2);
	init_label(mercury__rl_key__get_join_key_ranges_7_0_i4);
	init_label(mercury__rl_key__get_join_key_ranges_7_0_i1);
BEGIN_CODE

/* code for predicate 'get_join_key_ranges'/7 in mode 0 */
Define_entry(mercury__rl_key__get_join_key_ranges_7_0);
	MR_incr_sp_push_msg(2, "rl_key:get_join_key_ranges/7");
	MR_stackvar(2) = (Word) MR_succip;
	r8 = r2;
	r9 = r3;
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_key__get_join_key_ranges_7_0, "origin_lost_in_value_number");
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_6);
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_range_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__bounds_to_key_range_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_16);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_key__get_join_key_ranges_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_tempr1;
	r4 = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r3, (Integer) 6) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 5) = r8;
	call_localret(ENTRY(mercury__list__map_3_1),
		mercury__rl_key__get_join_key_ranges_7_0_i2,
		ENTRY(mercury__rl_key__get_join_key_ranges_7_0));
	}
Define_label(mercury__rl_key__get_join_key_ranges_7_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__get_join_key_ranges_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__get_join_key_ranges_7_0_i1);
	r1 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__rl_key__merge_key_ranges_4_0),
		mercury__rl_key__get_join_key_ranges_7_0_i4,
		ENTRY(mercury__rl_key__get_join_key_ranges_7_0));
Define_label(mercury__rl_key__get_join_key_ranges_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__get_join_key_ranges_7_0));
	r2 = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__get_join_key_ranges_7_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(rl_key_module15)
	init_entry(mercury__rl_key__compute_var_bound_maps_4_0);
	init_label(mercury__rl_key__compute_var_bound_maps_4_0_i2);
	init_label(mercury__rl_key__compute_var_bound_maps_4_0_i3);
	init_label(mercury__rl_key__compute_var_bound_maps_4_0_i4);
BEGIN_CODE

/* code for predicate 'compute_var_bound_maps'/4 in mode 0 */
Define_static(mercury__rl_key__compute_var_bound_maps_4_0);
	MR_incr_sp_push_msg(5, "rl_key:compute_var_bound_maps/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_key__compute_var_bound_maps_4_0_i2,
		STATIC(mercury__rl_key__compute_var_bound_maps_4_0));
Define_label(mercury__rl_key__compute_var_bound_maps_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bound_maps_4_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_key__compute_var_bound_maps_4_0_i3,
		STATIC(mercury__rl_key__compute_var_bound_maps_4_0));
Define_label(mercury__rl_key__compute_var_bound_maps_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bound_maps_4_0));
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_key_info_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_20);
	r4 = MR_stackvar(1);
	r6 = r1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__rl_key__compute_var_bound_maps_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_17);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__rl_key__compute_var_bound_maps_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__compute_var_bound_maps_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 2) = r7;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_key__compute_var_bound_maps_4_0_i4,
		STATIC(mercury__rl_key__compute_var_bound_maps_4_0));
	}
Define_label(mercury__rl_key__compute_var_bound_maps_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bound_maps_4_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__map__from_assoc_list_2_0);

BEGIN_MODULE(rl_key_module16)
	init_entry(mercury__rl_key__compute_var_bounds_4_0);
	init_label(mercury__rl_key__compute_var_bounds_4_0_i2);
	init_label(mercury__rl_key__compute_var_bounds_4_0_i3);
	init_label(mercury__rl_key__compute_var_bounds_4_0_i6);
	init_label(mercury__rl_key__compute_var_bounds_4_0_i1);
BEGIN_CODE

/* code for predicate 'compute_var_bounds'/4 in mode 0 */
Define_static(mercury__rl_key__compute_var_bounds_4_0);
	MR_incr_sp_push_msg(2, "rl_key:compute_var_bounds/4");
	MR_stackvar(2) = (Word) MR_succip;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 5, mercury__rl_key__compute_var_bounds_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 4) = r3;
	r3 = MR_tempr1;
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) STATIC(mercury__rl_key__get_var_bounds_4_0);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_22);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__compute_var_bounds_4_0_i2,
		STATIC(mercury__rl_key__compute_var_bounds_4_0));
	}
Define_label(mercury__rl_key__compute_var_bounds_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bounds_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_21);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__compute_var_bounds_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_23);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__useful_bounds_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__filter_map_3_0),
		mercury__rl_key__compute_var_bounds_4_0_i3,
		STATIC(mercury__rl_key__compute_var_bounds_4_0));
Define_label(mercury__rl_key__compute_var_bounds_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bounds_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__compute_var_bounds_4_0_i1);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5);
	call_localret(ENTRY(mercury__map__from_assoc_list_2_0),
		mercury__rl_key__compute_var_bounds_4_0_i6,
		STATIC(mercury__rl_key__compute_var_bounds_4_0));
Define_label(mercury__rl_key__compute_var_bounds_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__compute_var_bounds_4_0));
	r2 = r1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__compute_var_bounds_4_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__set__delete_3_0);
Declare_entry(mercury__set__empty_1_0);

BEGIN_MODULE(rl_key_module17)
	init_entry(mercury__rl_key__useful_bounds_3_0);
	init_label(mercury__rl_key__useful_bounds_3_0_i2);
	init_label(mercury__rl_key__useful_bounds_3_0_i3);
	init_label(mercury__rl_key__useful_bounds_3_0_i9);
	init_label(mercury__rl_key__useful_bounds_3_0_i11);
	init_label(mercury__rl_key__useful_bounds_3_0_i8);
	init_label(mercury__rl_key__useful_bounds_3_0_i5);
	init_label(mercury__rl_key__useful_bounds_3_0_i15);
	init_label(mercury__rl_key__useful_bounds_3_0_i17);
	init_label(mercury__rl_key__useful_bounds_3_0_i4);
	init_label(mercury__rl_key__useful_bounds_3_0_i1);
BEGIN_CODE

/* code for predicate 'useful_bounds'/3 in mode 0 */
Define_static(mercury__rl_key__useful_bounds_3_0);
	MR_incr_sp_push_msg(4, "rl_key:useful_bounds/3");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__rl_key__remove_useless_info_3_0),
		mercury__rl_key__useful_bounds_3_0_i2,
		STATIC(mercury__rl_key__useful_bounds_3_0));
Define_label(mercury__rl_key__useful_bounds_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_key__remove_useless_info_3_0),
		mercury__rl_key__useful_bounds_3_0_i3,
		STATIC(mercury__rl_key__useful_bounds_3_0));
Define_label(mercury__rl_key__useful_bounds_3_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__useful_bounds_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__useful_bounds_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__useful_bounds_3_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__rl_key__useful_bounds_3_0_i9,
		STATIC(mercury__rl_key__useful_bounds_3_0));
	}
Define_label(mercury__rl_key__useful_bounds_3_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__rl_key__useful_bounds_3_0_i11,
		STATIC(mercury__rl_key__useful_bounds_3_0));
Define_label(mercury__rl_key__useful_bounds_3_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	if (r1)
		GOTO_LABEL(mercury__rl_key__useful_bounds_3_0_i5);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__useful_bounds_3_0_i8);
	MR_stackvar(3) = r1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__useful_bounds_3_0_i5);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__useful_bounds_3_0_i4);
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__rl_key__useful_bounds_3_0_i15,
		STATIC(mercury__rl_key__useful_bounds_3_0));
Define_label(mercury__rl_key__useful_bounds_3_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__rl_key__useful_bounds_3_0_i17,
		STATIC(mercury__rl_key__useful_bounds_3_0));
Define_label(mercury__rl_key__useful_bounds_3_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_key__useful_bounds_3_0));
	if (r1)
		GOTO_LABEL(mercury__rl_key__useful_bounds_3_0_i1);
	r2 = MR_stackvar(1);
Define_label(mercury__rl_key__useful_bounds_3_0_i4);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_key__useful_bounds_3_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(do_redo);
Declare_entry(mercury__type_util__classify_type_3_0);

BEGIN_MODULE(rl_key_module18)
	init_entry(mercury__rl_key__remove_useless_info_3_0);
	init_label(mercury__rl_key__remove_useless_info_3_0_i3);
	init_label(mercury__rl_key__remove_useless_info_3_0_i4);
	init_label(mercury__rl_key__remove_useless_info_3_0_i1009);
	init_label(mercury__rl_key__remove_useless_info_3_0_i9);
	init_label(mercury__rl_key__remove_useless_info_3_0_i15);
	init_label(mercury__rl_key__remove_useless_info_3_0_i17);
	init_label(mercury__rl_key__remove_useless_info_3_0_i19);
	init_label(mercury__rl_key__remove_useless_info_3_0_i20);
	init_label(mercury__rl_key__remove_useless_info_3_0_i22);
	init_label(mercury__rl_key__remove_useless_info_3_0_i23);
	init_label(mercury__rl_key__remove_useless_info_3_0_i5);
BEGIN_CODE

/* code for predicate 'remove_useless_info'/3 in mode 0 */
Define_static(mercury__rl_key__remove_useless_info_3_0);
	MR_incr_sp_push_msg(9, "rl_key:remove_useless_info/3");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__remove_useless_info_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__rl_key__remove_useless_info_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r4 = r2;
	r5 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__remove_useless_info_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r4, (Integer) 0), (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__remove_useless_info_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_24);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__remove_useless_info_3_0_i4,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	MR_stackvar(6) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__remove_useless_info_3_0_i9);
	MR_stackvar(4) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__rl_key__remove_useless_info_3_0_i1009,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i1009);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(8);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
Define_label(mercury__rl_key__remove_useless_info_3_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	r1 = MR_stackvar(4);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(6);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(7);
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__rl_key__remove_useless_info_3_0_i15,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	if (((Integer) r1 != (Integer) 5))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i17);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__rl_key__remove_useless_info_3_0_i19,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i17);
	if (((Integer) r1 != (Integer) 7))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__rl_key__remove_useless_info_3_0_i19,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__rl_key__remove_useless_info_3_0_i20,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_key__remove_useless_info_3_0_i22,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__rl_key__remove_useless_info_3_0_i23,
		STATIC(mercury__rl_key__remove_useless_info_3_0));
Define_label(mercury__rl_key__remove_useless_info_3_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_key__remove_useless_info_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__remove_useless_info_3_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__remove_useless_info_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__rl_key__remove_useless_info_3_0_i5);
	r2 = MR_stackvar(4);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__remove_useless_info_3_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__rl_key__remove_useless_info_3_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__apply_to_list_3_0);

BEGIN_MODULE(rl_key_module19)
	init_entry(mercury__rl_key__bounds_to_key_range_6_0);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i4);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i2);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i5);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i6);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i8);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i10);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i11);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i12);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i13);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i1016);
	init_label(mercury__rl_key__bounds_to_key_range_6_0_i1);
BEGIN_CODE

/* code for predicate 'bounds_to_key_range'/6 in mode 0 */
Define_static(mercury__rl_key__bounds_to_key_range_6_0);
	MR_incr_sp_push_msg(6, "rl_key:bounds_to_key_range/6");
	MR_stackvar(6) = (Word) MR_succip;
	r6 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i2);
	r4 = r3;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__rl_key__bounds_to_key_range_6_0_i4,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_key__bounds_to_key_range_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_stackvar(4) = r3;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__bounds_to_key_range_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_27);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_26);
	GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i5);
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i2);
	r4 = r6;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__bounds_to_key_range_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__166__1_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_27);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_26);
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i5);
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__list__map_3_1),
		mercury__rl_key__bounds_to_key_range_6_0_i6,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i1);
	r5 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__bounds_to_key_range_6_0, "origin_lost_in_value_number");
	r4 = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__bounds_to_key_range__171__2_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_28);
	call_localret(ENTRY(mercury__list__map_3_1),
		mercury__rl_key__bounds_to_key_range_6_0_i8,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__rl_key__bounds_to_key_range_6_0_i10,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__rl_key__split_key_tuples_3_0),
		mercury__rl_key__bounds_to_key_range_6_0_i11,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_key__convert_bound_3_0),
		mercury__rl_key__bounds_to_key_range_6_0_i12,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_key__convert_bound_3_0),
		mercury__rl_key__bounds_to_key_range_6_0_i13,
		STATIC(mercury__rl_key__bounds_to_key_range_6_0));
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__bounds_to_key_range_6_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i1016);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__bounds_to_key_range_6_0_i1);
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i1016);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_key__bounds_to_key_range_6_0, "rl:key_range/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__rl_key__bounds_to_key_range_6_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__set__member_2_1);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__assoc_list__keys_2_0);
Declare_entry(mercury__assoc_list__values_2_0);
Declare_entry(mercury__assoc_list__from_corresponding_lists_3_0);

BEGIN_MODULE(rl_key_module20)
	init_entry(mercury__rl_key__convert_bound_3_0);
	init_label(mercury__rl_key__convert_bound_3_0_i1042);
	init_label(mercury__rl_key__convert_bound_3_0_i14);
	init_label(mercury__rl_key__convert_bound_3_0_i1047);
	init_label(mercury__rl_key__convert_bound_3_0_i1053);
	init_label(mercury__rl_key__convert_bound_3_0_i1055);
	init_label(mercury__rl_key__convert_bound_3_0_i4);
	init_label(mercury__rl_key__convert_bound_3_0_i23);
	init_label(mercury__rl_key__convert_bound_3_0_i30);
	init_label(mercury__rl_key__convert_bound_3_0_i1067);
	init_label(mercury__rl_key__convert_bound_3_0_i1073);
	init_label(mercury__rl_key__convert_bound_3_0_i1079);
	init_label(mercury__rl_key__convert_bound_3_0_i34);
	init_label(mercury__rl_key__convert_bound_3_0_i35);
	init_label(mercury__rl_key__convert_bound_3_0_i36);
	init_label(mercury__rl_key__convert_bound_3_0_i37);
	init_label(mercury__rl_key__convert_bound_3_0_i38);
	init_label(mercury__rl_key__convert_bound_3_0_i20);
BEGIN_CODE

/* code for predicate 'convert_bound'/3 in mode 0 */
Define_static(mercury__rl_key__convert_bound_3_0);
	MR_incr_sp_push_msg(10, "rl_key:convert_bound/3");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(5) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__convert_bound_3_0_i4);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_29);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__rl_key__convert_bound_3_0_i1042,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i1042);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO(ENTRY(do_redo));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i1055);
	MR_stackvar(7) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(9) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__convert_bound_3_0_i1053);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__rl_key__convert_bound_3_0_i14,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__rl_key__convert_bound_3_0_i1047,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i1047);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(9);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
	GOTO(ENTRY(do_redo));
Define_label(mercury__rl_key__convert_bound_3_0_i1053);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
Define_label(mercury__rl_key__convert_bound_3_0_i1055);
	MR_maxfr = (Word *) MR_stackvar(6);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(5);
	GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i20);
Define_label(mercury__rl_key__convert_bound_3_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_stackvar(4) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__convert_bound_3_0_i1079);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_29);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__rl_key__convert_bound_3_0_i23,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	MR_stackvar(7) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(8) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(9) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__convert_bound_3_0_i1073);
	r3 = MR_stackvar(1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i1073);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i1073);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__member_2_1),
		mercury__rl_key__convert_bound_3_0_i30,
		STATIC(mercury__rl_key__convert_bound_3_0));
	}
Define_label(mercury__rl_key__convert_bound_3_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__rl_key__convert_bound_3_0_i1067,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i1067);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(9);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
	GOTO(ENTRY(do_redo));
Define_label(mercury__rl_key__convert_bound_3_0_i1073);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(7);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(8);
	MR_maxfr = (Word *) MR_stackvar(6);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(5);
	GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i34);
Define_label(mercury__rl_key__convert_bound_3_0_i1079);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(4);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(5);
	GOTO_LABEL(mercury__rl_key__convert_bound_3_0_i20);
Define_label(mercury__rl_key__convert_bound_3_0_i34);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__assoc_list__keys_2_0),
		mercury__rl_key__convert_bound_3_0_i35,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	call_localret(ENTRY(mercury__assoc_list__values_2_0),
		mercury__rl_key__convert_bound_3_0_i36,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__convert_bound_3_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_31);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__convert_key_attr_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__convert_bound_3_0_i37,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i37);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__rl_key__convert_bound_3_0_i38,
		STATIC(mercury__rl_key__convert_bound_3_0));
Define_label(mercury__rl_key__convert_bound_3_0_i38);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_bound_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__rl_key__convert_bound_3_0, "rl:bounding_tuple/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__rl_key__convert_bound_3_0_i20);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__set__intersect_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__list__nth_member_search_3_0);

BEGIN_MODULE(rl_key_module21)
	init_entry(mercury__rl_key__convert_key_attr_3_0);
	init_label(mercury__rl_key__convert_key_attr_3_0_i7);
	init_label(mercury__rl_key__convert_key_attr_3_0_i8);
	init_label(mercury__rl_key__convert_key_attr_3_0_i9);
	init_label(mercury__rl_key__convert_key_attr_3_0_i11);
	init_label(mercury__rl_key__convert_key_attr_3_0_i5);
	init_label(mercury__rl_key__convert_key_attr_3_0_i3);
	init_label(mercury__rl_key__convert_key_attr_3_0_i14);
BEGIN_CODE

/* code for predicate 'convert_key_attr'/3 in mode 0 */
Define_static(mercury__rl_key__convert_key_attr_3_0);
	MR_incr_sp_push_msg(3, "rl_key:convert_key_attr/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_key_attr_3_0_i3);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_key_attr_3_0_i5);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_key__convert_key_attr_3_0_i7,
		STATIC(mercury__rl_key__convert_key_attr_3_0));
Define_label(mercury__rl_key__convert_key_attr_3_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_key_attr_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__rl_key__convert_key_attr_3_0_i8,
		STATIC(mercury__rl_key__convert_key_attr_3_0));
Define_label(mercury__rl_key__convert_key_attr_3_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_key_attr_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__convert_key_attr_3_0_i9,
		STATIC(mercury__rl_key__convert_key_attr_3_0));
Define_label(mercury__rl_key__convert_key_attr_3_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_key_attr_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__convert_key_attr_3_0_i5);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__nth_member_search_3_0),
		mercury__rl_key__convert_key_attr_3_0_i11,
		STATIC(mercury__rl_key__convert_key_attr_3_0));
Define_label(mercury__rl_key__convert_key_attr_3_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_key_attr_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__convert_key_attr_3_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_key__convert_key_attr_3_0, "rl:key_attr/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__rl_key__convert_key_attr_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__rl_key__convert_key_attr_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r5 = r1;
	r4 = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__convert_key_attr_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r4, (Integer) 0), (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 3) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__convert_key_attr_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_31);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__convert_key_attr_3_0_i14,
		STATIC(mercury__rl_key__convert_key_attr_3_0));
Define_label(mercury__rl_key__convert_key_attr_3_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__convert_key_attr_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 3, mercury__rl_key__convert_key_attr_3_0, "rl:key_attr/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module22)
	init_entry(mercury__rl_key__split_key_tuples_3_0);
	init_label(mercury__rl_key__split_key_tuples_3_0_i4);
	init_label(mercury__rl_key__split_key_tuples_3_0_i5);
	init_label(mercury__rl_key__split_key_tuples_3_0_i2);
BEGIN_CODE

/* code for predicate 'split_key_tuples'/3 in mode 0 */
Define_static(mercury__rl_key__split_key_tuples_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__split_key_tuples_3_0_i2);
	r5 = (Word) MR_sp;
Define_label(mercury__rl_key__split_key_tuples_3_0_i4);
	while (1) {
	MR_incr_sp_push_msg(2, "rl_key:split_key_tuples");
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__split_key_tuples_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(0), (Integer) 2, mercury__rl_key__split_key_tuples_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), MR_stackvar(2), (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(0), MR_stackvar(2), (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__rl_key__split_key_tuples_3_0_i5);
	while (1) {
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_key__split_key_tuples_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_key__split_key_tuples_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_decr_sp_pop_msg(2);
	if (((Integer) MR_sp > (Integer) r5))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__rl_key__split_key_tuples_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module23)
	init_entry(mercury__rl_key__merge_key_ranges_4_0);
	init_label(mercury__rl_key__merge_key_ranges_4_0_i1002);
	init_label(mercury__rl_key__merge_key_ranges_4_0_i4);
	init_label(mercury__rl_key__merge_key_ranges_4_0_i5);
	init_label(mercury__rl_key__merge_key_ranges_4_0_i3);
BEGIN_CODE

/* code for predicate 'merge_key_ranges'/4 in mode 0 */
Define_static(mercury__rl_key__merge_key_ranges_4_0);
	MR_incr_sp_push_msg(4, "rl_key:merge_key_ranges/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__rl_key__merge_key_ranges_4_0_i1002);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_4_0_i3);
	MR_stackvar(2) = r3;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__rl_key__merge_key_ranges_2_5_0),
		mercury__rl_key__merge_key_ranges_4_0_i4,
		STATIC(mercury__rl_key__merge_key_ranges_4_0));
Define_label(mercury__rl_key__merge_key_ranges_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_4_0));
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_4_0_i5);
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_key__merge_key_ranges_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_4_0_i1002);
Define_label(mercury__rl_key__merge_key_ranges_4_0_i5);
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_4_0_i1002);
Define_label(mercury__rl_key__merge_key_ranges_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module24)
	init_entry(mercury__rl_key__merge_key_ranges_2_5_0);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i3);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i13);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i16);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i10);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i11);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i9);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i24);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i27);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i21);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i22);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i29);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i1030);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i8);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i35);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i38);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i32);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i33);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i31);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i46);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i49);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i43);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i44);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i51);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i52);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i6);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i53);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i54);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i1032);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i5);
	init_label(mercury__rl_key__merge_key_ranges_2_5_0_i55);
BEGIN_CODE

/* code for predicate 'merge_key_ranges_2'/5 in mode 0 */
Define_static(mercury__rl_key__merge_key_ranges_2_5_0);
	MR_incr_sp_push_msg(12, "rl_key:merge_key_ranges_2/5");
	MR_stackvar(12) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i3);
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r5 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r6 = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	r7 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r8 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r9 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r10 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r11 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if (((Integer) r7 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i13);
	if (((Integer) 1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i11);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i9);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i13);
	if (((Integer) r10 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i11);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r4;
	r3 = MR_const_field(MR_mktag(1), r7, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r10, (Integer) 0);
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(1) = r1;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
	call_localret(STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i16,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i10);
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i9);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i10);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r11 = MR_stackvar(5);
	r10 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	r6 = MR_stackvar(10);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i11);
	if (((Integer) 0 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i8);
	if (((Integer) r10 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i8);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i9);
	if (((Integer) MR_stackvar(5) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i24);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i22);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(9);
	MR_stackvar(11) = r4;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i6);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i24);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(10);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i22);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(11) = r4;
	call_localret(STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i27,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
	}
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i21);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(9);
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i6);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i21);
	r1 = MR_stackvar(1);
	r4 = MR_stackvar(11);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i22);
	if (((Integer) r4 == (Integer) 0))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i29);
	MR_stackvar(1) = r1;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i1030);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i29);
	if (((Integer) MR_stackvar(10) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i52);
	MR_stackvar(1) = r1;
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i1030);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(10);
	r7 = MR_stackvar(9);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(6);
	r11 = MR_stackvar(5);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i8);
	if (((Integer) r11 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i35);
	if (((Integer) 1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i33);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i31);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i35);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i33);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r4;
	r5 = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r11, (Integer) 0);
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(1) = r1;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
	call_localret(STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i38,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i38);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i32);
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i31);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i32);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r11 = MR_stackvar(5);
	r10 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	r6 = MR_stackvar(10);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i33);
	if (((Integer) 0 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i5);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i5);
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r4;
	r2 = (Integer) 1;
	r4 = (Integer) 0;
	MR_stackvar(3) = r5;
	MR_stackvar(5) = r11;
	MR_stackvar(6) = r10;
	MR_stackvar(7) = r9;
	MR_stackvar(8) = r8;
	MR_stackvar(9) = r7;
	MR_stackvar(10) = r6;
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i31);
	if (((Integer) MR_stackvar(9) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i46);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i44);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(9);
	MR_stackvar(11) = r4;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i6);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i46);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(6);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i44);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(9), (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(11) = r4;
	call_localret(STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i49,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
	}
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i49);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i43);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(9);
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i6);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i43);
	r1 = MR_stackvar(1);
	r4 = MR_stackvar(11);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i44);
	if (((Integer) r4 == (Integer) 0))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i51);
	MR_stackvar(1) = r1;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i1032);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i51);
	if (((Integer) MR_stackvar(6) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i52);
	MR_stackvar(1) = r1;
	GOTO_LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i1032);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i52);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(9);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i6);
	MR_stackvar(1) = r1;
	r2 = (Integer) 1;
	r4 = (Integer) 1;
	call_localret(STATIC(mercury__rl_key__min_max_7_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i53,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i53);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = MR_stackvar(6);
	r4 = (Integer) 0;
	r5 = MR_stackvar(10);
	call_localret(STATIC(mercury__rl_key__min_max_7_0),
		mercury__rl_key__merge_key_ranges_2_5_0_i54,
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i54);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_key__merge_key_ranges_2_5_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_key__merge_key_ranges_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	r2 = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i1032);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(3);
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i5);
	MR_stackvar(3) = r5;
	r3 = r4;
	localcall(mercury__rl_key__merge_key_ranges_2_5_0,
		LABEL(mercury__rl_key__merge_key_ranges_2_5_0_i55),
		STATIC(mercury__rl_key__merge_key_ranges_2_5_0));
Define_label(mercury__rl_key__merge_key_ranges_2_5_0_i55);
	update_prof_current_proc(LABEL(mercury__rl_key__merge_key_ranges_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_key__merge_key_ranges_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module25)
	init_entry(mercury__rl_key__min_max_7_0);
	init_label(mercury__rl_key__min_max_7_0_i8);
	init_label(mercury__rl_key__min_max_7_0_i11);
	init_label(mercury__rl_key__min_max_7_0_i5);
	init_label(mercury__rl_key__min_max_7_0_i1008);
	init_label(mercury__rl_key__min_max_7_0_i6);
	init_label(mercury__rl_key__min_max_7_0_i3);
BEGIN_CODE

/* code for predicate 'min_max'/7 in mode 0 */
Define_static(mercury__rl_key__min_max_7_0);
	MR_incr_sp_push_msg(4, "rl_key:min_max/7");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i8);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i1008);
	r1 = r3;
	MR_stackvar(2) = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__min_max_7_0_i8);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i6);
	MR_stackvar(1) = r3;
	MR_stackvar(3) = r5;
	r5 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(2) = r4;
	call_localret(STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0),
		mercury__rl_key__min_max_7_0_i11,
		STATIC(mercury__rl_key__min_max_7_0));
Define_label(mercury__rl_key__min_max_7_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__min_max_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__min_max_7_0_i5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	GOTO_LABEL(mercury__rl_key__min_max_7_0_i6);
Define_label(mercury__rl_key__min_max_7_0_i1008);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i3);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i3);
	r1 = r3;
	r2 = r5;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__min_max_7_0_i6);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i3);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__min_max_7_0_i3);
	r1 = r3;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__min_max_7_0_i3);
	r1 = r5;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module26)
	init_entry(mercury__rl_key__key_tuple_less_or_equal_5_0);
	init_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1005);
	init_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i3);
	init_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i6);
	init_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
BEGIN_CODE

/* code for predicate 'key_tuple_less_or_equal'/5 in mode 0 */
Define_static(mercury__rl_key__key_tuple_less_or_equal_5_0);
	MR_incr_sp_push_msg(6, "rl_key:key_tuple_less_or_equal/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1005);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i3);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i3);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_tempr4 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0) != MR_const_field(MR_mktag(0), MR_tempr4, (Integer) 0)))
		GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	r5 = MR_const_field(MR_mktag(0), MR_tempr4, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__rl_key__key_term_less_or_equal_5_0),
		mercury__rl_key__key_tuple_less_or_equal_5_0_i6,
		STATIC(mercury__rl_key__key_tuple_less_or_equal_5_0));
	}
Define_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__rl_key__key_tuple_less_or_equal_5_0_i1005);
Define_label(mercury__rl_key__key_tuple_less_or_equal_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module27)
	init_entry(mercury__rl_key__key_term_less_or_equal_5_0);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i3);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i8);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i13);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i15);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i20);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i1049);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i1054);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i11);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i29);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i30);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i32);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i33);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i36);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i26);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i38);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i40);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i1029);
	init_label(mercury__rl_key__key_term_less_or_equal_5_0_i1);
BEGIN_CODE

/* code for predicate 'key_term_less_or_equal'/5 in mode 0 */
Define_static(mercury__rl_key__key_term_less_or_equal_5_0);
	MR_incr_sp_push_msg(12, "rl_key:key_term_less_or_equal/5");
	MR_stackvar(12) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i3);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1029);
	if ((MR_tag(r5) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1029);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i3);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i8);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i8);
	if ((MR_tag(r5) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	MR_stackvar(8) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r5, (Integer) 2);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i13,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i11);
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_attr_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i15,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	MR_stackvar(9) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(10) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(11) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1054);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_32);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__rl_key__key_term_less_or_equal_5_0_i20,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	localcall(mercury__rl_key__key_term_less_or_equal_5_0,
		LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1049),
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i1049);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if (r1)
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(11);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i1054);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(9);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(10);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i11);
	r6 = MR_stackvar(8);
	r8 = MR_stackvar(4);
	if ((MR_tag(r6) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i26);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i26);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i29,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i30,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i32,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i33,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i33);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Integer) 1;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_key__choose_cons_id_2_5_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i36,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r1 = r2;
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i26);
	MR_stackvar(4) = r8;
	MR_stackvar(8) = r6;
	r1 = r6;
	r2 = r8;
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury__rl_key__key_term_less_or_equal_5_0_i38,
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i38);
	update_prof_current_proc(LABEL(mercury__rl_key__key_term_less_or_equal_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i40);
	r2 = MR_stackvar(8);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i40);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		STATIC(mercury__rl_key__key_term_less_or_equal_5_0));
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i1029);
	r1 = FALSE;
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__rl_key__key_term_less_or_equal_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE

Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(rl_key_module28)
	init_entry(mercury__rl_key__get_var_bounds_4_0);
	init_label(mercury__rl_key__get_var_bounds_4_0_i3);
	init_label(mercury__rl_key__get_var_bounds_4_0_i5);
	init_label(mercury__rl_key__get_var_bounds_4_0_i6);
	init_label(mercury__rl_key__get_var_bounds_4_0_i7);
	init_label(mercury__rl_key__get_var_bounds_4_0_i8);
	init_label(mercury__rl_key__get_var_bounds_4_0_i9);
	init_label(mercury__rl_key__get_var_bounds_4_0_i10);
	init_label(mercury__rl_key__get_var_bounds_4_0_i11);
	init_label(mercury__rl_key__get_var_bounds_4_0_i2);
	init_label(mercury__rl_key__get_var_bounds_4_0_i12);
BEGIN_CODE

/* code for predicate 'get_var_bounds'/4 in mode 0 */
Define_static(mercury__rl_key__get_var_bounds_4_0);
	MR_incr_sp_push_msg(8, "rl_key:get_var_bounds/4");
	MR_stackvar(8) = (Word) MR_succip;
	r4 = r3;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__get_var_bounds_4_0_i3,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__get_var_bounds_4_0_i2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__get_var_bounds_4_0_i5,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(4) = r1;
	MR_stackvar(6) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__get_var_bounds_4_0_i6,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
	}
Define_label(mercury__rl_key__get_var_bounds_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__get_var_bounds_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_34);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__propagate_var_bounds_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(2);
	r5 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_key__get_var_bounds_4_0_i7,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 1;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0),
		mercury__rl_key__get_var_bounds_4_0_i8,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__get_var_bounds_4_0_i9,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
	}
Define_label(mercury__rl_key__get_var_bounds_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__get_var_bounds_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_34);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__propagate_var_bounds_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = (Integer) 0;
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(2);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_key__get_var_bounds_4_0_i10,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0),
		mercury__rl_key__get_var_bounds_4_0_i11,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__get_var_bounds_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__get_var_bounds_4_0_i12,
		STATIC(mercury__rl_key__get_var_bounds_4_0));
Define_label(mercury__rl_key__get_var_bounds_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__get_var_bounds_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__get_var_bounds_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__duplicate_3_0);

BEGIN_MODULE(rl_key_module29)
	init_entry(mercury__rl_key__propagate_alias_bounds_2_6_0);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i3);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i6);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i7);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i8);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i5);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i12);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i14);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i10);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i15);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i16);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i17);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i18);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i21);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i23);
	init_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i19);
BEGIN_CODE

/* code for predicate 'propagate_alias_bounds_2'/6 in mode 0 */
Define_static(mercury__rl_key__propagate_alias_bounds_2_6_0);
	MR_incr_sp_push_msg(11, "rl_key:propagate_alias_bounds_2/6");
	MR_stackvar(11) = (Word) MR_succip;
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0_i3);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i3);
	if (((Integer) MR_const_field(MR_mktag(0), r5, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0_i5);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 2);
	MR_stackvar(6) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i6,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i7,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_alias_bounds_2_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i8,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i14,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i5);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r4, (Integer) 2);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 2);
	MR_stackvar(7) = r1;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i12,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
	}
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0_i10);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i14,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_alias_bounds_2_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__rl_key__propagate_alias_bounds_2_6_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i10);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i15,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i16,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_alias_bounds_2_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = r4;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i17,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(7);
	r7 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i18,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r3 = r2;
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i21,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0_i19);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0),
		mercury__rl_key__propagate_alias_bounds_2_6_0_i23,
		STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_alias_bounds_2_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__rl_key__propagate_alias_bounds_2_6_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__rl_key__propagate_alias_bounds_2_6_0_i19);
	r2 = MR_stackvar(7);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_alias_bounds_2_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 3, mercury__rl_key__propagate_alias_bounds_2_6_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module30)
	init_entry(mercury__rl_key__propagate_alias_bounds_list_6_0);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i3);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i9);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i10);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i11);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i12);
	init_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i8);
BEGIN_CODE

/* code for predicate 'propagate_alias_bounds_list'/6 in mode 0 */
Define_static(mercury__rl_key__propagate_alias_bounds_list_6_0);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0_i3);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i3);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0_i8);
	MR_incr_sp_push_msg(8, "rl_key:propagate_alias_bounds_list/6");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__propagate_alias_bounds_list_6_0_i9,
		STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0));
	}
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__propagate_alias_bounds_list_6_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r5 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__propagate_var_bounds_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_34);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_key__propagate_alias_bounds_list_6_0_i10,
		STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(7);
	call_localret(STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0),
		mercury__rl_key__propagate_alias_bounds_list_6_0_i11,
		STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0));
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(5);
	localcall(mercury__rl_key__propagate_alias_bounds_list_6_0,
		LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0_i12),
		STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0));
	}
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_alias_bounds_list_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_key__propagate_alias_bounds_list_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__propagate_alias_bounds_list_6_0_i8);
	r1 = (Word) MR_string_const("rl_key__propagate_alias_bounds", 30);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__rl_key__propagate_alias_bounds_list_6_0));
END_MODULE

Declare_entry(mercury__set__member_2_0);

BEGIN_MODULE(rl_key_module31)
	init_entry(mercury__rl_key__propagate_var_bounds_6_0);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i3);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i1000);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i2);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i5);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i7);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i10);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i11);
	init_label(mercury__rl_key__propagate_var_bounds_6_0_i12);
BEGIN_CODE

/* code for predicate 'propagate_var_bounds'/6 in mode 0 */
Define_static(mercury__rl_key__propagate_var_bounds_6_0);
	MR_incr_sp_push_msg(8, "rl_key:propagate_var_bounds/6");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(1) = r1;
	r3 = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_stackvar(7) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = r4;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__rl_key__propagate_var_bounds_6_0_i3,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_var_bounds_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__propagate_var_bounds_6_0_i2);
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i1000);
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__rl_key__propagate_var_bounds_6_0_i5,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_var_bounds_6_0));
	r4 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__propagate_var_bounds_6_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__propagate_var_bounds_6_0_i7,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
	}
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_var_bounds_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__propagate_var_bounds_6_0_i1000);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__propagate_var_bounds_6_0_i10);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__propagate_var_bounds_6_0_i11,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i10);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_key__propagate_var_bounds_6_0_i11,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_var_bounds_6_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__propagate_var_bounds_6_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_34);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__propagate_var_bounds_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_key__propagate_var_bounds_6_0_i12,
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
Define_label(mercury__rl_key__propagate_var_bounds_6_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__propagate_var_bounds_6_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__rl_key__propagate_alias_bounds_2_6_0),
		STATIC(mercury__rl_key__propagate_var_bounds_6_0));
END_MODULE


BEGIN_MODULE(rl_key_module32)
	init_entry(mercury__rl_key__extract_key_range_3_0);
	init_label(mercury__rl_key__extract_key_range_3_0_i2);
	init_label(mercury__rl_key__extract_key_range_3_0_i5);
	init_label(mercury__rl_key__extract_key_range_3_0_i8);
	init_label(mercury__rl_key__extract_key_range_3_0_i13);
	init_label(mercury__rl_key__extract_key_range_3_0_i11);
	init_label(mercury__rl_key__extract_key_range_3_0_i16);
	init_label(mercury__rl_key__extract_key_range_3_0_i17);
	init_label(mercury__rl_key__extract_key_range_3_0_i18);
	init_label(mercury__rl_key__extract_key_range_3_0_i19);
	init_label(mercury__rl_key__extract_key_range_3_0_i20);
	init_label(mercury__rl_key__extract_key_range_3_0_i21);
	init_label(mercury__rl_key__extract_key_range_3_0_i14);
BEGIN_CODE

/* code for predicate 'extract_key_range'/3 in mode 0 */
Define_static(mercury__rl_key__extract_key_range_3_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i2);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	tailcall(STATIC(mercury__rl_key__extract_key_range_unify_3_0),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i2);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i5);
	r4 = r2;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	tailcall(STATIC(mercury__rl_key__extract_key_range_call_5_0),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i5);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i8);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i8);
	MR_incr_sp_push_msg(4, "rl_key:extract_key_range/3");
	MR_stackvar(4) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__rl_key__extract_key_range_disj_6_0),
		mercury__rl_key__extract_key_range_3_0_i13,
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i8);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i11);
	MR_incr_sp_push_msg(4, "rl_key:extract_key_range/3");
	MR_stackvar(4) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__rl_key__extract_key_range_switch_7_0),
		mercury__rl_key__extract_key_range_3_0_i13,
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__extract_key_range_3_0, "rl_key:key_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_key__extract_key_range_3_0_i11);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury__rl_key__extract_key_range_3_0_i14);
	MR_incr_sp_push_msg(4, "rl_key:extract_key_range/3");
	MR_stackvar(4) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 4);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	localcall(mercury__rl_key__extract_key_range_3_0,
		LABEL(mercury__rl_key__extract_key_range_3_0_i16),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	localcall(mercury__rl_key__extract_key_range_3_0,
		LABEL(mercury__rl_key__extract_key_range_3_0_i17),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_key__key_info_set_constraints_3_0),
		mercury__rl_key__extract_key_range_3_0_i18,
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__rl_key__extract_key_range_3_0,
		LABEL(mercury__rl_key__extract_key_range_3_0_i19),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	call_localret(STATIC(mercury__rl_key__key_info_get_constraints_3_0),
		mercury__rl_key__extract_key_range_3_0_i20,
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__rl_key__extract_key_range_3_0_i21,
		STATIC(mercury__rl_key__extract_key_range_3_0));
	}
Define_label(mercury__rl_key__extract_key_range_3_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__rl_key__key_info_set_constraints_3_0),
		STATIC(mercury__rl_key__extract_key_range_3_0));
Define_label(mercury__rl_key__extract_key_range_3_0_i14);
	r1 = r2;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module33)
	init_entry(mercury__rl_key__extract_key_range_disj_6_0);
	init_label(mercury__rl_key__extract_key_range_disj_6_0_i1001);
	init_label(mercury__rl_key__extract_key_range_disj_6_0_i4);
	init_label(mercury__rl_key__extract_key_range_disj_6_0_i5);
	init_label(mercury__rl_key__extract_key_range_disj_6_0_i3);
BEGIN_CODE

/* code for predicate 'extract_key_range_disj'/6 in mode 0 */
Define_static(mercury__rl_key__extract_key_range_disj_6_0);
	MR_incr_sp_push_msg(4, "rl_key:extract_key_range_disj/6");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__rl_key__extract_key_range_disj_6_0_i1001);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__extract_key_range_disj_6_0_i3);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__rl_key__extract_key_range_disj_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 2) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__rl_key__extract_key_range_3_0),
		mercury__rl_key__extract_key_range_disj_6_0_i4,
		STATIC(mercury__rl_key__extract_key_range_disj_6_0));
	}
Define_label(mercury__rl_key__extract_key_range_disj_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_disj_6_0));
	r3 = MR_stackvar(2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__rl_key__extract_key_range_disj_6_0_i5,
		STATIC(mercury__rl_key__extract_key_range_disj_6_0));
Define_label(mercury__rl_key__extract_key_range_disj_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_disj_6_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__rl_key__extract_key_range_disj_6_0_i1001);
Define_label(mercury__rl_key__extract_key_range_disj_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module34)
	init_entry(mercury__rl_key__extract_key_range_switch_7_0);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i1001);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i7);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i10);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i11);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i5);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i12);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i13);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i14);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i15);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i4);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i17);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i18);
	init_label(mercury__rl_key__extract_key_range_switch_7_0_i3);
BEGIN_CODE

/* code for predicate 'extract_key_range_switch'/7 in mode 0 */
Define_static(mercury__rl_key__extract_key_range_switch_7_0);
	MR_incr_sp_push_msg(10, "rl_key:extract_key_range_switch/7");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i1001);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__extract_key_range_switch_7_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r9 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 3, mercury__rl_key__extract_key_range_switch_7_0, "origin_lost_in_value_number");
	r8 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r7 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_const_field(MR_mktag(0), r5, (Integer) 1);
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	MR_field(MR_mktag(0), r6, (Integer) 2) = r1;
	COMPUTED_GOTO((Unsigned) MR_tag(r9),
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i7) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i11) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i11) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i10));
	}
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i7);
	MR_stackvar(3) = r4;
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r9, (Integer) 1);
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r8;
	MR_stackvar(5) = r9;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r6;
	GOTO_LABEL(mercury__rl_key__extract_key_range_switch_7_0_i5);
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r9, (Integer) 0),
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i11) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i4) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i4) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i4) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i4) AND
		LABEL(mercury__rl_key__extract_key_range_switch_7_0_i4));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i11);
	MR_stackvar(3) = r4;
	r4 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r8;
	MR_stackvar(5) = r9;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r6;
	MR_stackvar(8) = (Integer) 0;
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i5);
	MR_stackvar(2) = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(7), (Integer) 1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_key__extract_key_range_switch_7_0_i12,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__extract_key_range_switch_7_0_i13,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	r2 = MR_stackvar(8);
	r4 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__extract_key_range_switch_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = r4;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__rl_key__extract_key_range_switch_7_0_i14,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__extract_key_range_switch_7_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 3, mercury__rl_key__extract_key_range_switch_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_key__add_equality_constraint_4_0),
		mercury__rl_key__extract_key_range_switch_7_0_i15,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
	}
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_key__extract_key_range_3_0),
		mercury__rl_key__extract_key_range_switch_7_0_i17,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i4);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r7;
	r2 = r6;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r8;
	call_localret(STATIC(mercury__rl_key__extract_key_range_3_0),
		mercury__rl_key__extract_key_range_switch_7_0_i17,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	r3 = MR_stackvar(3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__rl_key__extract_key_range_switch_7_0_i18,
		STATIC(mercury__rl_key__extract_key_range_switch_7_0));
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_switch_7_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__rl_key__extract_key_range_switch_7_0_i1001);
Define_label(mercury__rl_key__extract_key_range_switch_7_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__in_in_unification_proc_id_1_0);
Declare_entry(mercury____Unify___hlds_pred__proc_id_0_0);
Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);
Declare_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(rl_key_module35)
	init_entry(mercury__rl_key__extract_key_range_call_5_0);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i2);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i3);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i4);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i5);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i7);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i8);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i11);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i14);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i15);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i12);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i19);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i20);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i17);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i24);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i25);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i22);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i29);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i30);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i27);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i34);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i35);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i10);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i37);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i41);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i38);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i6);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i46);
	init_label(mercury__rl_key__extract_key_range_call_5_0_i45);
BEGIN_CODE

/* code for predicate 'extract_key_range_call'/5 in mode 0 */
Define_static(mercury__rl_key__extract_key_range_call_5_0);
	MR_incr_sp_push_msg(7, "rl_key:extract_key_range_call/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__rl_key__extract_key_range_call_5_0_i2,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__rl_key__extract_key_range_call_5_0_i3,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__rl_key__extract_key_range_call_5_0_i4,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__rl_key__extract_key_range_call_5_0_i5,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i7,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__proc_id_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i8,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("__Unify__", 9)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i11);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i10);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i11);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("builtin_unify_character", 23)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i12);
	if (((Integer) MR_stackvar(6) != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i14,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i15,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i10);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i12);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("builtin_unify_float", 19)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i17);
	if (((Integer) MR_stackvar(6) != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i19,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i20,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i10);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i17);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("builtin_unify_int", 17)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i22);
	if (((Integer) MR_stackvar(6) != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i24,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i25,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i10);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i22);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("builtin_unify_string", 20)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i27);
	if (((Integer) MR_stackvar(6) != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i29,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i30,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	r2 = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i10);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i27);
	if ((strcmp((char *)MR_stackvar(5), (char *)(Word) MR_string_const("unify", 5)) != 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	if (((Integer) MR_stackvar(6) != (Integer) 3))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__rl_key__extract_key_range_call_5_0_i34,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i34);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__extract_key_range_call_5_0_i35,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i6);
	r2 = MR_stackvar(2);
Define_label(mercury__rl_key__extract_key_range_call_5_0_i10);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_key__extract_key_range_call_5_0_i37,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i37);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i38);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i38);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__extract_key_range_call_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_35);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__extract_key_range_call_5_0_i41,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
	}
Define_label(mercury__rl_key__extract_key_range_call_5_0_i41);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__extract_key_range_call_5_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__rl_key__extract_key_range_call_5_0_i38);
	r1 = (Word) MR_string_const("rl_key__extract_key_range_call: __Unify__", 41);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i6);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__rl_key__is_builtin_compare_pred_4_0),
		mercury__rl_key__extract_key_range_call_5_0_i46,
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i46);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_call_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__extract_key_range_call_5_0_i45);
	r1 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__rl_key__update_compare_bounds_4_0),
		STATIC(mercury__rl_key__extract_key_range_call_5_0));
Define_label(mercury__rl_key__extract_key_range_call_5_0_i45);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module36)
	init_entry(mercury__rl_key__update_compare_bounds_4_0);
	init_label(mercury__rl_key__update_compare_bounds_4_0_i8);
	init_label(mercury__rl_key__update_compare_bounds_4_0_i3);
	init_label(mercury__rl_key__update_compare_bounds_4_0_i11);
	init_label(mercury__rl_key__update_compare_bounds_4_0_i1011);
	init_label(mercury__rl_key__update_compare_bounds_4_0_i12);
BEGIN_CODE

/* code for predicate 'update_compare_bounds'/4 in mode 0 */
Define_static(mercury__rl_key__update_compare_bounds_4_0);
	MR_incr_sp_push_msg(3, "rl_key:update_compare_bounds/4");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i1011);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i1011);
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i1011);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__update_compare_bounds_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__add_compare_result__608__3_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_36);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__update_compare_bounds_4_0_i8,
		STATIC(mercury__rl_key__update_compare_bounds_4_0));
	}
Define_label(mercury__rl_key__update_compare_bounds_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__update_compare_bounds_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__rl_key__update_compare_bounds_4_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_key__update_compare_bounds_4_0_i11,
		STATIC(mercury__rl_key__update_compare_bounds_4_0));
Define_label(mercury__rl_key__update_compare_bounds_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i12);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_4_0_i12);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__rl_key__update_compare_bounds_2_5_0),
		STATIC(mercury__rl_key__update_compare_bounds_4_0));
	}
Define_label(mercury__rl_key__update_compare_bounds_4_0_i1011);
	r1 = (Word) MR_string_const("rl_key__update_compare_bounds", 29);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__rl_key__update_compare_bounds_4_0));
Define_label(mercury__rl_key__update_compare_bounds_4_0_i12);
	r1 = (Word) MR_string_const("rl_key__update_compare_bounds", 29);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__rl_key__update_compare_bounds_4_0));
END_MODULE


BEGIN_MODULE(rl_key_module37)
	init_entry(mercury__rl_key__update_compare_bounds_2_5_0);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i3);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i6);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i7);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i8);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i5);
	init_label(mercury__rl_key__update_compare_bounds_2_5_0_i10);
BEGIN_CODE

/* code for predicate 'update_compare_bounds_2'/5 in mode 0 */
Define_static(mercury__rl_key__update_compare_bounds_2_5_0);
	MR_incr_sp_push_msg(5, "rl_key:update_compare_bounds_2/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_2_5_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_key__unify_var_var_4_0),
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_key__update_compare_bounds_2_5_0_i5);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = r3;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__update_compare_bounds_2_5_0_i6,
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_2_5_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__update_compare_bounds_2_5_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__update_compare_bounds_2_5_0_i7,
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_2_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_key__update_compare_bounds_2_5_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_37);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__update_compare_bounds_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_tempr2 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__update_compare_bounds_2_5_0_i8,
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
	}
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__rl_key__update_compare_bounds_2_5_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_key__add_var_lower_bound_4_0),
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
	}
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i5);
	r1 = r2;
	MR_stackvar(1) = r2;
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	call_localret(STATIC(mercury__rl_key__add_var_lower_bound_4_0),
		mercury__rl_key__update_compare_bounds_2_5_0_i10,
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
Define_label(mercury__rl_key__update_compare_bounds_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__update_compare_bounds_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_key__add_var_upper_bound_4_0),
		STATIC(mercury__rl_key__update_compare_bounds_2_5_0));
END_MODULE


BEGIN_MODULE(rl_key_module38)
	init_entry(mercury__rl_key__is_builtin_compare_pred_4_0);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i3);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1018);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i5);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i6);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i8);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i9);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i11);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i15);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i17);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i21);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i23);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i25);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i26);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i28);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i30);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i31);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i33);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i35);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i36);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1017);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i39);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i43);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i45);
	init_label(mercury__rl_key__is_builtin_compare_pred_4_0_i49);
BEGIN_CODE

/* code for predicate 'is_builtin_compare_pred'/4 in mode 0 */
Define_static(mercury__rl_key__is_builtin_compare_pred_4_0);
	r4 = (hash_string(r2) & (Integer) 31);
	MR_incr_sp_push_msg(2, "rl_key:is_builtin_compare_pred/4");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_38))[(Integer) r4];
	if (!(MR_tempr1))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1018);
	if ((strcmp((char *)MR_tempr1, (char *)r2) == 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i5);
	}
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1018);
	r4 = (MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_39))[(Integer) r4];
	if (((Integer) r4 >= (Integer) 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i3);
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i5);
	COMPUTED_GOTO((Unsigned) r4,
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i6) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i11) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i17) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i23) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i28) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i33) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1017) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i39) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001) AND
		LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i45));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i6);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i8,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i9,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i11);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i15);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_40);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i15);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_40);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i17);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i21);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_41);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i21);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_41);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i23);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i25,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i26,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i28);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i30,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i31,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i31);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i33);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i35,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__rl_key__is_builtin_compare_pred_4_0_i36,
		STATIC(mercury__rl_key__is_builtin_compare_pred_4_0));
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_key__is_builtin_compare_pred_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i1017);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i39);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i43);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_41);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i43);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_41);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i45);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i49);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_40);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__is_builtin_compare_pred_4_0_i49);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__rl_key__is_builtin_compare_pred_4_0_i1001);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_key__common_40);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module39)
	init_entry(mercury__rl_key__extract_key_range_unify_3_0);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i1005);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i8);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i10);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i12);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i11);
	init_label(mercury__rl_key__extract_key_range_unify_3_0_i13);
BEGIN_CODE

/* code for predicate 'extract_key_range_unify'/3 in mode 0 */
Define_static(mercury__rl_key__extract_key_range_unify_3_0);
	MR_incr_sp_push_msg(2, "rl_key:extract_key_range_unify/3");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__rl_key__extract_key_range_unify_3_0_i1005) AND
		LABEL(mercury__rl_key__extract_key_range_unify_3_0_i1005) AND
		LABEL(mercury__rl_key__extract_key_range_unify_3_0_i8) AND
		LABEL(mercury__rl_key__extract_key_range_unify_3_0_i10));
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i1005);
	r4 = r2;
	r2 = MR_const_mask_field(r1, (Integer) 1);
	r3 = MR_const_mask_field(r1, (Integer) 2);
	r1 = MR_const_mask_field(r1, (Integer) 0);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__rl_key__unify_functor_5_0),
		STATIC(mercury__rl_key__extract_key_range_unify_3_0));
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__extract_key_range_unify_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_35);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__extract_key_range_unify_3_0_i12,
		STATIC(mercury__rl_key__extract_key_range_unify_3_0));
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i10);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__extract_key_range_unify_3_0_i11);
	r5 = r1;
	r4 = r2;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__extract_key_range_unify_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_35);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__extract_key_range_unify_3_0_i12,
		STATIC(mercury__rl_key__extract_key_range_unify_3_0));
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_unify_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__extract_key_range_unify_3_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i11);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("rl_key__extract_key_range_unify", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_key__extract_key_range_unify_3_0_i13,
		STATIC(mercury__rl_key__extract_key_range_unify_3_0));
Define_label(mercury__rl_key__extract_key_range_unify_3_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__extract_key_range_unify_3_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module40)
	init_entry(mercury__rl_key__unify_functor_5_0);
	init_label(mercury__rl_key__unify_functor_5_0_i2);
	init_label(mercury__rl_key__unify_functor_5_0_i3);
	init_label(mercury__rl_key__unify_functor_5_0_i4);
	init_label(mercury__rl_key__unify_functor_5_0_i5);
BEGIN_CODE

/* code for predicate 'unify_functor'/5 in mode 0 */
Define_static(mercury__rl_key__unify_functor_5_0);
	MR_incr_sp_push_msg(7, "rl_key:unify_functor/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	r4 = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_43);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__unify_functor_5_0_i2,
		STATIC(mercury__rl_key__unify_functor_5_0));
Define_label(mercury__rl_key__unify_functor_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_functor_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__unify_functor_5_0_i3,
		STATIC(mercury__rl_key__unify_functor_5_0));
Define_label(mercury__rl_key__unify_functor_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_functor_5_0));
	MR_stackvar(6) = r1;
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_key__unify_functor_5_0_i4,
		STATIC(mercury__rl_key__unify_functor_5_0));
Define_label(mercury__rl_key__unify_functor_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_functor_5_0));
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r4 = r1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__rl_key__unify_functor_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_functor__707__5_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_44);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__unify_functor_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 3, mercury__rl_key__unify_functor_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	r4 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 4) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__filter_map_3_0),
		mercury__rl_key__unify_functor_5_0_i5,
		STATIC(mercury__rl_key__unify_functor_5_0));
	}
Define_label(mercury__rl_key__unify_functor_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_functor_5_0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__rl_key__key_info_set_constraints_3_0),
		STATIC(mercury__rl_key__unify_functor_5_0));
END_MODULE


BEGIN_MODULE(rl_key_module41)
	init_entry(mercury__rl_key__unify_var_var_4_0);
	init_label(mercury__rl_key__unify_var_var_4_0_i2);
BEGIN_CODE

/* code for predicate 'unify_var_var'/4 in mode 0 */
Define_static(mercury__rl_key__unify_var_var_4_0);
	MR_incr_sp_push_msg(2, "rl_key:unify_var_var/4");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__unify_var_var_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_var_var__731__6_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_35);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__unify_var_var_4_0_i2,
		STATIC(mercury__rl_key__unify_var_var_4_0));
Define_label(mercury__rl_key__unify_var_var_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_var_var_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__unify_var_var_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module42)
	init_entry(mercury__rl_key__add_alias_4_0);
	init_label(mercury__rl_key__add_alias_4_0_i3);
	init_label(mercury__rl_key__add_alias_4_0_i5);
	init_label(mercury__rl_key__add_alias_4_0_i6);
	init_label(mercury__rl_key__add_alias_4_0_i2);
	init_label(mercury__rl_key__add_alias_4_0_i7);
	init_label(mercury__rl_key__add_alias_4_0_i9);
BEGIN_CODE

/* code for predicate 'add_alias'/4 in mode 0 */
Define_static(mercury__rl_key__add_alias_4_0);
	MR_incr_sp_push_msg(7, "rl_key:add_alias/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(3) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__rl_key__add_alias_4_0_i3,
		STATIC(mercury__rl_key__add_alias_4_0));
Define_label(mercury__rl_key__add_alias_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__add_alias_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__add_alias_4_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__rl_key__add_alias_4_0_i5,
		STATIC(mercury__rl_key__add_alias_4_0));
	}
Define_label(mercury__rl_key__add_alias_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__add_alias_4_0));
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_tempr2 = MR_stackvar(5);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__rl_key__add_alias_4_0_i6,
		STATIC(mercury__rl_key__add_alias_4_0));
	}
Define_label(mercury__rl_key__add_alias_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_key__add_alias_4_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "rl_key:var_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__add_alias_4_0_i9,
		STATIC(mercury__rl_key__add_alias_4_0));
	}
Define_label(mercury__rl_key__add_alias_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__add_alias_4_0_i7,
		STATIC(mercury__rl_key__add_alias_4_0));
Define_label(mercury__rl_key__add_alias_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_key__add_alias_4_0));
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "rl_key:var_info/0");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__rl_key__add_alias_4_0_i9,
		STATIC(mercury__rl_key__add_alias_4_0));
	}
Define_label(mercury__rl_key__add_alias_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_key__add_alias_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_alias_4_0, "rl_key:var_map/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module43)
	init_entry(mercury__rl_key__add_equality_constraint_4_0);
	init_label(mercury__rl_key__add_equality_constraint_4_0_i2);
BEGIN_CODE

/* code for predicate 'add_equality_constraint'/4 in mode 0 */
Define_static(mercury__rl_key__add_equality_constraint_4_0);
	MR_incr_sp_push_msg(2, "rl_key:add_equality_constraint/4");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_key__add_equality_constraint_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 5) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 4) = r2;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_37);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__add_equality_constraint_4_0_i2,
		STATIC(mercury__rl_key__add_equality_constraint_4_0));
Define_label(mercury__rl_key__add_equality_constraint_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__add_equality_constraint_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__add_equality_constraint_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module44)
	init_entry(mercury__rl_key__add_var_lower_bound_4_0);
	init_label(mercury__rl_key__add_var_lower_bound_4_0_i2);
	init_label(mercury__rl_key__add_var_lower_bound_4_0_i3);
	init_label(mercury__rl_key__add_var_lower_bound_4_0_i4);
BEGIN_CODE

/* code for predicate 'add_var_lower_bound'/4 in mode 0 */
Define_static(mercury__rl_key__add_var_lower_bound_4_0);
	MR_incr_sp_push_msg(4, "rl_key:add_var_lower_bound/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__add_var_lower_bound_4_0_i2,
		STATIC(mercury__rl_key__add_var_lower_bound_4_0));
Define_label(mercury__rl_key__add_var_lower_bound_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_lower_bound_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__add_var_lower_bound_4_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__add_var_lower_bound_4_0_i3,
		STATIC(mercury__rl_key__add_var_lower_bound_4_0));
Define_label(mercury__rl_key__add_var_lower_bound_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_lower_bound_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_key__add_var_lower_bound_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_37);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(3);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_var_lower_bound_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__add_var_lower_bound_4_0_i4,
		STATIC(mercury__rl_key__add_var_lower_bound_4_0));
	}
Define_label(mercury__rl_key__add_var_lower_bound_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_lower_bound_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__add_var_lower_bound_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module45)
	init_entry(mercury__rl_key__add_var_upper_bound_4_0);
	init_label(mercury__rl_key__add_var_upper_bound_4_0_i2);
	init_label(mercury__rl_key__add_var_upper_bound_4_0_i3);
	init_label(mercury__rl_key__add_var_upper_bound_4_0_i4);
BEGIN_CODE

/* code for predicate 'add_var_upper_bound'/4 in mode 0 */
Define_static(mercury__rl_key__add_var_upper_bound_4_0);
	MR_incr_sp_push_msg(4, "rl_key:add_var_upper_bound/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__rl_key__add_var_upper_bound_4_0_i2,
		STATIC(mercury__rl_key__add_var_upper_bound_4_0));
Define_label(mercury__rl_key__add_var_upper_bound_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_upper_bound_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__rl_key__add_var_upper_bound_4_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_key__add_var_upper_bound_4_0_i3,
		STATIC(mercury__rl_key__add_var_upper_bound_4_0));
Define_label(mercury__rl_key__add_var_upper_bound_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_upper_bound_4_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_key__add_var_upper_bound_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_37);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__update_bounds__823__7_6_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_key__add_var_upper_bound_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 6) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__add_var_upper_bound_4_0_i4,
		STATIC(mercury__rl_key__add_var_upper_bound_4_0));
	}
Define_label(mercury__rl_key__add_var_upper_bound_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__add_var_upper_bound_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__add_var_upper_bound_4_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module46)
	init_entry(mercury__rl_key__unify_term_5_0);
	init_label(mercury__rl_key__unify_term_5_0_i2);
	init_label(mercury__rl_key__unify_term_5_0_i3);
BEGIN_CODE

/* code for predicate 'unify_term'/5 in mode 0 */
Define_static(mercury__rl_key__unify_term_5_0);
	MR_incr_sp_push_msg(5, "rl_key:unify_term/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_key__unify_term_5_0_i2,
		STATIC(mercury__rl_key__unify_term_5_0));
Define_label(mercury__rl_key__unify_term_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_key__unify_term_2_5_0),
		mercury__rl_key__unify_term_5_0_i3,
		STATIC(mercury__rl_key__unify_term_5_0));
	}
Define_label(mercury__rl_key__unify_term_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_key__unify_term_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module47)
	init_entry(mercury__rl_key__unify_term_2_5_0);
	init_label(mercury__rl_key__unify_term_2_5_0_i1008);
	init_label(mercury__rl_key__unify_term_2_5_0_i3);
	init_label(mercury__rl_key__unify_term_2_5_0_i7);
	init_label(mercury__rl_key__unify_term_2_5_0_i10);
	init_label(mercury__rl_key__unify_term_2_5_0_i12);
	init_label(mercury__rl_key__unify_term_2_5_0_i13);
	init_label(mercury__rl_key__unify_term_2_5_0_i8);
	init_label(mercury__rl_key__unify_term_2_5_0_i14);
BEGIN_CODE

/* code for predicate 'unify_term_2'/5 in mode 0 */
Define_static(mercury__rl_key__unify_term_2_5_0);
	MR_incr_sp_push_msg(8, "rl_key:unify_term_2/5");
	MR_stackvar(8) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__unify_term_2_5_0_i3);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__unify_term_2_5_0_i1008);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__unify_term_2_5_0_i1008);
	r1 = r4;
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__unify_term_2_5_0_i3);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__unify_term_2_5_0_i7);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__unify_term_2_5_0_i7);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r4, (Integer) 2);
	MR_stackvar(3) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__unify_term_2_5_0_i10,
		STATIC(mercury__rl_key__unify_term_2_5_0));
Define_label(mercury__rl_key__unify_term_2_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__unify_term_2_5_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__assoc_list__from_corresponding_lists_3_0),
		mercury__rl_key__unify_term_2_5_0_i12,
		STATIC(mercury__rl_key__unify_term_2_5_0));
Define_label(mercury__rl_key__unify_term_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_2_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_key__unify_term_2_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_5);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_4);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_key__IntroducedFrom__pred__unify_term_2__868__8_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_45);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_key__unify_term_2_5_0_i13,
		STATIC(mercury__rl_key__unify_term_2_5_0));
Define_label(mercury__rl_key__unify_term_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 3, mercury__rl_key__unify_term_2_5_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__rl_key__unify_term_2_5_0_i8);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	call_localret(STATIC(mercury__rl_key__det_choose_cons_id__ua0_9_0),
		mercury__rl_key__unify_term_2_5_0_i14,
		STATIC(mercury__rl_key__unify_term_2_5_0));
Define_label(mercury__rl_key__unify_term_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__unify_term_2_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 3, mercury__rl_key__unify_term_2_5_0, "rl:key_term_node/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module48)
	init_entry(mercury__rl_key__choose_cons_id_2_5_0);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i1008);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i4);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i3);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i5);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i8);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i1002);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i6);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i14);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i1004);
	init_label(mercury__rl_key__choose_cons_id_2_5_0_i13);
BEGIN_CODE

/* code for predicate 'choose_cons_id_2'/5 in mode 0 */
Define_static(mercury__rl_key__choose_cons_id_2_5_0);
	MR_incr_sp_push_msg(6, "rl_key:choose_cons_id_2/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i1008);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i3);
	r1 = (Word) MR_string_const("rl_key__choose_cons_id_2: couldn't find ctor", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_key__choose_cons_id_2_5_0_i4,
		STATIC(mercury__rl_key__choose_cons_id_2_5_0));
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_key__choose_cons_id_2_5_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_46);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__rl_key__choose_cons_id_2_5_0_i5,
		STATIC(mercury__rl_key__choose_cons_id_2_5_0));
	}
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_key__choose_cons_id_2_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_key__choose_cons_id_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	r1 = r3;
	MR_stackvar(5) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__choose_cons_id_2_5_0_i8,
		STATIC(mercury__rl_key__choose_cons_id_2_5_0));
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_key__choose_cons_id_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i6);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i1004);
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i1002);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i6);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__rl_key__choose_cons_id_2_5_0_i14,
		STATIC(mercury__rl_key__choose_cons_id_2_5_0));
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_key__choose_cons_id_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i13);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i1002);
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i1004);
	r2 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__rl_key__choose_cons_id_2_5_0_i13);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__rl_key__choose_cons_id_2_5_0_i1008);
END_MODULE


BEGIN_MODULE(rl_key_module49)
	init_entry(mercury__rl_key__key_info_get_constraints_3_0);
BEGIN_CODE

/* code for predicate 'key_info_get_constraints'/3 in mode 0 */
Define_static(mercury__rl_key__key_info_get_constraints_3_0);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module50)
	init_entry(mercury__rl_key__key_info_set_constraints_3_0);
BEGIN_CODE

/* code for predicate 'key_info_set_constraints'/3 in mode 0 */
Define_static(mercury__rl_key__key_info_set_constraints_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_key__key_info_set_constraints_3_0, "rl_key:key_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r3;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module51)
	init_entry(mercury____Unify___rl_key__upper_lower_0_0);
	init_label(mercury____Unify___rl_key__upper_lower_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_key__upper_lower_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___rl_key__upper_lower_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_key__upper_lower_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module52)
	init_entry(mercury____Index___rl_key__upper_lower_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_key__upper_lower_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(rl_key_module53)
	init_entry(mercury____Compare___rl_key__upper_lower_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_key__upper_lower_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___rl_key__upper_lower_0_0));
END_MODULE


BEGIN_MODULE(rl_key_module54)
	init_entry(mercury____Unify___rl_key__compare_type_0_0);
	init_label(mercury____Unify___rl_key__compare_type_0_0_i3);
	init_label(mercury____Unify___rl_key__compare_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_key__compare_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___rl_key__compare_type_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___rl_key__compare_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_key__compare_type_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___rl_key__compare_type_0_0_i1);
	if ((MR_const_field(MR_mktag(1), r1, (Integer) 0) != MR_const_field(MR_mktag(1), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___rl_key__compare_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___rl_key__compare_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module55)
	init_entry(mercury____Index___rl_key__compare_type_0_0);
	init_label(mercury____Index___rl_key__compare_type_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_key__compare_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___rl_key__compare_type_0_0_i3);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___rl_key__compare_type_0_0_i3);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(rl_key_module56)
	init_entry(mercury____Compare___rl_key__compare_type_0_0);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i3);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i2);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i5);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i4);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i6);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i7);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i11);
	init_label(mercury____Compare___rl_key__compare_type_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_key__compare_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i3);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i2);
Define_label(mercury____Compare___rl_key__compare_type_0_0_i3);
	r3 = (Integer) 0;
Define_label(mercury____Compare___rl_key__compare_type_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i5);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i4);
Define_label(mercury____Compare___rl_key__compare_type_0_0_i5);
	r4 = (Integer) 0;
Define_label(mercury____Compare___rl_key__compare_type_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___rl_key__compare_type_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___rl_key__compare_type_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___rl_key__compare_type_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___rl_key__compare_type_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___rl_key__compare_type_0_0));
Define_label(mercury____Compare___rl_key__compare_type_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___rl_key__compare_type_0_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_module__module_info_0_0);
Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(rl_key_module57)
	init_entry(mercury____Unify___rl_key__key_info_0_0);
	init_label(mercury____Unify___rl_key__key_info_0_0_i2);
	init_label(mercury____Unify___rl_key__key_info_0_0_i4);
	init_label(mercury____Unify___rl_key__key_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_key__key_info_0_0);
	MR_incr_sp_push_msg(5, "rl_key:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		mercury____Unify___rl_key__key_info_0_0_i2,
		STATIC(mercury____Unify___rl_key__key_info_0_0));
Define_label(mercury____Unify___rl_key__key_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_key__key_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_key__key_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_key__key_info_0_0_i4,
		STATIC(mercury____Unify___rl_key__key_info_0_0));
Define_label(mercury____Unify___rl_key__key_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___rl_key__key_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_key__key_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___rl_key__key_info_0_0));
Define_label(mercury____Unify___rl_key__key_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module58)
	init_entry(mercury____Index___rl_key__key_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_key__key_info_0_0);
	tailcall(STATIC(mercury____Index___rl_key__key_info_0__ua0_2_0),
		STATIC(mercury____Index___rl_key__key_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___hlds_module__module_info_0_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(rl_key_module59)
	init_entry(mercury____Compare___rl_key__key_info_0_0);
	init_label(mercury____Compare___rl_key__key_info_0_0_i3);
	init_label(mercury____Compare___rl_key__key_info_0_0_i7);
	init_label(mercury____Compare___rl_key__key_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_key__key_info_0_0);
	MR_incr_sp_push_msg(5, "rl_key:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		mercury____Compare___rl_key__key_info_0_0_i3,
		STATIC(mercury____Compare___rl_key__key_info_0_0));
Define_label(mercury____Compare___rl_key__key_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_key__key_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_key__key_info_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_12);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_key__key_info_0_0_i7,
		STATIC(mercury____Compare___rl_key__key_info_0_0));
Define_label(mercury____Compare___rl_key__key_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___rl_key__key_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_key__key_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_map_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___rl_key__key_info_0_0));
Define_label(mercury____Compare___rl_key__key_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module60)
	init_entry(mercury____Unify___rl_key__var_map_0_0);
	init_label(mercury____Unify___rl_key__var_map_0_0_i2);
	init_label(mercury____Unify___rl_key__var_map_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_key__var_map_0_0);
	MR_incr_sp_push_msg(3, "rl_key:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___rl_key__var_map_0_0_i2,
		STATIC(mercury____Unify___rl_key__var_map_0_0));
Define_label(mercury____Unify___rl_key__var_map_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_key__var_map_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_key__var_map_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___rl_key__var_map_0_0));
Define_label(mercury____Unify___rl_key__var_map_0_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module61)
	init_entry(mercury____Index___rl_key__var_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_key__var_map_0_0);
	tailcall(STATIC(mercury____Index___rl_key__var_map_0__ua0_2_0),
		STATIC(mercury____Index___rl_key__var_map_0_0));
END_MODULE


BEGIN_MODULE(rl_key_module62)
	init_entry(mercury____Compare___rl_key__var_map_0_0);
	init_label(mercury____Compare___rl_key__var_map_0_0_i3);
	init_label(mercury____Compare___rl_key__var_map_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_key__var_map_0_0);
	MR_incr_sp_push_msg(3, "rl_key:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) (Word *) &mercury_data_rl_key__type_ctor_info_var_info_0;
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___rl_key__var_map_0_0_i3,
		STATIC(mercury____Compare___rl_key__var_map_0_0));
Define_label(mercury____Compare___rl_key__var_map_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_key__var_map_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_key__var_map_0_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___rl_key__var_map_0_0));
Define_label(mercury____Compare___rl_key__var_map_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(rl_key_module63)
	init_entry(mercury____Unify___rl_key__var_info_0_0);
	init_label(mercury____Unify___rl_key__var_info_0_0_i2);
	init_label(mercury____Unify___rl_key__var_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_key__var_info_0_0);
	MR_incr_sp_push_msg(3, "rl_key:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_term_node_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_3);
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury____Unify___rl_key__var_info_0_0_i2,
		STATIC(mercury____Unify___rl_key__var_info_0_0));
Define_label(mercury____Unify___rl_key__var_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___rl_key__var_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___rl_key__var_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_term_node_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury____Unify___rl_key__var_info_0_0));
Define_label(mercury____Unify___rl_key__var_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_key_module64)
	init_entry(mercury____Index___rl_key__var_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_key__var_info_0_0);
	tailcall(STATIC(mercury____Index___rl_key__var_info_0__ua0_2_0),
		STATIC(mercury____Index___rl_key__var_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(rl_key_module65)
	init_entry(mercury____Compare___rl_key__var_info_0_0);
	init_label(mercury____Compare___rl_key__var_info_0_0_i3);
	init_label(mercury____Compare___rl_key__var_info_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_key__var_info_0_0);
	MR_incr_sp_push_msg(3, "rl_key:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_term_node_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_3);
	call_localret(ENTRY(mercury____Compare___std_util__pair_2_0),
		mercury____Compare___rl_key__var_info_0_0_i3,
		STATIC(mercury____Compare___rl_key__var_info_0_0));
Define_label(mercury____Compare___rl_key__var_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___rl_key__var_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___rl_key__var_info_0_0_i7);
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_key_term_node_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_key__common_3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		STATIC(mercury____Compare___rl_key__var_info_0_0));
Define_label(mercury____Compare___rl_key__var_info_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_key_maybe_bunch_0(void)
{
	rl_key_module0();
	rl_key_module1();
	rl_key_module2();
	rl_key_module3();
	rl_key_module4();
	rl_key_module5();
	rl_key_module6();
	rl_key_module7();
	rl_key_module8();
	rl_key_module9();
	rl_key_module10();
	rl_key_module11();
	rl_key_module12();
	rl_key_module13();
	rl_key_module14();
	rl_key_module15();
	rl_key_module16();
	rl_key_module17();
	rl_key_module18();
	rl_key_module19();
	rl_key_module20();
	rl_key_module21();
	rl_key_module22();
	rl_key_module23();
	rl_key_module24();
	rl_key_module25();
	rl_key_module26();
	rl_key_module27();
	rl_key_module28();
	rl_key_module29();
	rl_key_module30();
	rl_key_module31();
	rl_key_module32();
	rl_key_module33();
	rl_key_module34();
	rl_key_module35();
	rl_key_module36();
	rl_key_module37();
	rl_key_module38();
	rl_key_module39();
}

static void mercury__rl_key_maybe_bunch_1(void)
{
	rl_key_module40();
	rl_key_module41();
	rl_key_module42();
	rl_key_module43();
	rl_key_module44();
	rl_key_module45();
	rl_key_module46();
	rl_key_module47();
	rl_key_module48();
	rl_key_module49();
	rl_key_module50();
	rl_key_module51();
	rl_key_module52();
	rl_key_module53();
	rl_key_module54();
	rl_key_module55();
	rl_key_module56();
	rl_key_module57();
	rl_key_module58();
	rl_key_module59();
	rl_key_module60();
	rl_key_module61();
	rl_key_module62();
	rl_key_module63();
	rl_key_module64();
	rl_key_module65();
}

#endif

void mercury__rl_key__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_key__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_key_maybe_bunch_0();
		mercury__rl_key_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_key__type_ctor_info_compare_type_0,
			rl_key__compare_type_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_key__type_ctor_info_key_info_0,
			rl_key__key_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_key__type_ctor_info_upper_lower_0,
			rl_key__upper_lower_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_key__type_ctor_info_var_info_0,
			rl_key__var_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_key__type_ctor_info_var_map_0,
			rl_key__var_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
