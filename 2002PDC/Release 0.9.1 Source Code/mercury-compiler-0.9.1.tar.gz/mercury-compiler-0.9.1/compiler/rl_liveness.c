/*
** Automatically generated from `rl_liveness.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_liveness__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__rl_liveness__update_block_creation__ua0_8_0);
Declare_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i2);
Declare_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i3);
Declare_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i4);
Declare_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i5);
Declare_static(mercury__rl_liveness__unify__ua0_3_0);
Declare_static(mercury__rl_liveness__confluence__ua0_7_0);
Declare_label(mercury__rl_liveness__confluence__ua0_7_0_i3);
Declare_label(mercury__rl_liveness__confluence__ua0_7_0_i4);
Declare_static(mercury__rl_liveness__update_block_liveness__ua0_8_0);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i2);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i3);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i4);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i7);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i8);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i5);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i9);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i10);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i11);
Declare_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i12);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__377__9_3_0);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0);
Declare_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i2);
Declare_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i3);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__359__7_3_0);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__331__6_3_0);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0);
Declare_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0_i2);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__318__4_3_0);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0);
Declare_label(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0_i2);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__81__2_4_0);
Declare_static(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__57__1_4_0);
Define_extern_entry(mercury__rl_liveness__rl_liveness_4_0);
Declare_label(mercury__rl_liveness__rl_liveness_4_0_i2);
Declare_static(mercury__rl_liveness__rl_liveness_2_4_0);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i2);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i3);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i4);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i5);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i6);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i7);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i8);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i9);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i10);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i11);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i12);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i13);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i14);
Declare_label(mercury__rl_liveness__rl_liveness_2_4_0_i15);
Declare_static(mercury__rl_liveness__init_block_liveness_6_0);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i2);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i3);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i4);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i5);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i6);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i7);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i10);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i8);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i12);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i13);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i15);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i14);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i17);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i19);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i22);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i23);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i20);
Declare_label(mercury__rl_liveness__init_block_liveness_6_0_i25);
Declare_static(mercury__rl_liveness__instr_use_before_def_5_0);
Declare_label(mercury__rl_liveness__instr_use_before_def_5_0_i2);
Declare_label(mercury__rl_liveness__instr_use_before_def_5_0_i3);
Declare_label(mercury__rl_liveness__instr_use_before_def_5_0_i4);
Declare_label(mercury__rl_liveness__instr_use_before_def_5_0_i5);
Declare_label(mercury__rl_liveness__instr_use_before_def_5_0_i6);
Declare_static(mercury__rl_liveness__instr_def_before_use_5_0);
Declare_label(mercury__rl_liveness__instr_def_before_use_5_0_i2);
Declare_label(mercury__rl_liveness__instr_def_before_use_5_0_i3);
Declare_label(mercury__rl_liveness__instr_def_before_use_5_0_i4);
Declare_label(mercury__rl_liveness__instr_def_before_use_5_0_i5);
Declare_label(mercury__rl_liveness__instr_def_before_use_5_0_i6);
Declare_static(mercury__rl_liveness__update_block_liveness_8_0);
Declare_static(mercury__rl_liveness__confluence_7_0);
Declare_static(mercury__rl_liveness__unify_3_0);
Declare_static(mercury__rl_liveness__init_block_creation_6_0);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i2);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i3);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i4);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i5);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i7);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i6);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i8);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i10);
Declare_label(mercury__rl_liveness__init_block_creation_6_0_i11);
Declare_static(mercury__rl_liveness__update_block_creation_8_0);
Declare_static(mercury__rl_liveness__insert_init_and_unset_instructions_7_0);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i2);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i3);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i4);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i5);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i6);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i7);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i8);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i9);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i10);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i11);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i12);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i13);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i14);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i15);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i17);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i18);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i19);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i20);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i21);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i22);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i23);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i24);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i25);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i26);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i27);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i28);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i29);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i30);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i32);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i33);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i34);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i35);
Declare_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i36);
Declare_static(mercury__rl_liveness__insert_unset_instructions_5_0);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i2);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i3);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i4);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i6);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i10);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i9);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i5);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i13);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i14);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i15);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i16);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i17);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i18);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i19);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i22);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1081);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i20);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i28);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1107);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i35);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1139);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
Declare_label(mercury__rl_liveness__insert_unset_instructions_5_0_i41);
Declare_static(mercury__rl_liveness__undroppable_instr_1_0);
Declare_label(mercury__rl_liveness__undroppable_instr_1_0_i2);
Declare_label(mercury__rl_liveness__undroppable_instr_1_0_i1);
Declare_static(mercury__rl_liveness__drop_rel_2_0);
Declare_static(mercury__rl_liveness__insert_init_instructions_6_0);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i2);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i3);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i4);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i5);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i6);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i7);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i8);
Declare_label(mercury__rl_liveness__insert_init_instructions_6_0_i9);
Declare_static(mercury__rl_liveness__init_rel_3_0);
Declare_label(mercury__rl_liveness__init_rel_3_0_i2);
Declare_label(mercury__rl_liveness__init_rel_3_0_i1);
Declare_static(mercury____Unify___rl_liveness__live_data_0_0);
Declare_static(mercury____Index___rl_liveness__live_data_0_0);
Declare_static(mercury____Compare___rl_liveness__live_data_0_0);
Declare_static(mercury____Unify___rl_liveness__live_data_map_0_0);
Declare_static(mercury____Index___rl_liveness__live_data_map_0_0);
Declare_static(mercury____Compare___rl_liveness__live_data_map_0_0);
Declare_static(mercury____Unify___rl_liveness__creation_data_0_0);
Declare_static(mercury____Index___rl_liveness__creation_data_0_0);
Declare_static(mercury____Compare___rl_liveness__creation_data_0_0);
Declare_static(mercury____Unify___rl_liveness__creation_data_map_0_0);
Declare_static(mercury____Index___rl_liveness__creation_data_map_0_0);
Declare_static(mercury____Compare___rl_liveness__creation_data_map_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_creation_data_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_creation_data_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_live_data_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_live_data_map_0;

static const struct mercury_data_rl_liveness__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_liveness__common_0;

static const struct mercury_data_rl_liveness__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_1;

static const struct mercury_data_rl_liveness__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_2;

static const struct mercury_data_rl_liveness__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_3;

static const struct mercury_data_rl_liveness__common_4_struct {
	Word * f1;
}  mercury_data_rl_liveness__common_4;

static const struct mercury_data_rl_liveness__common_5_struct {
	Word * f1;
}  mercury_data_rl_liveness__common_5;

static const struct mercury_data_rl_liveness__common_6_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_liveness__common_6;

static const struct mercury_data_rl_liveness__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_7;

static const struct mercury_data_rl_liveness__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_liveness__common_8;

static const struct mercury_data_rl_liveness__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_9;

static const struct mercury_data_rl_liveness__common_10_struct {
	Word * f1;
}  mercury_data_rl_liveness__common_10;

static const struct mercury_data_rl_liveness__common_11_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_rl_liveness__common_11;

static const struct mercury_data_rl_liveness__common_12_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_12;

static const struct mercury_data_rl_liveness__common_13_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
}  mercury_data_rl_liveness__common_13;

static const struct mercury_data_rl_liveness__common_14_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_14;

static const struct mercury_data_rl_liveness__common_15_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_15;

static const struct mercury_data_rl_liveness__common_16_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_16;

static const struct mercury_data_rl_liveness__common_17_struct {
	Word * f1;
}  mercury_data_rl_liveness__common_17;

static const struct mercury_data_rl_liveness__common_18_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_liveness__common_18;

static const struct mercury_data_rl_liveness__common_19_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_19;

static const struct mercury_data_rl_liveness__common_20_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_liveness__common_20;

static const struct mercury_data_rl_liveness__common_21_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_liveness__common_21;

static const struct mercury_data_rl_liveness__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
}  mercury_data_rl_liveness__common_22;

static const struct mercury_data_rl_liveness__common_23_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_23;

static const struct mercury_data_rl_liveness__common_24_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_liveness__common_24;

static const struct mercury_data_rl_liveness__common_25_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_25;

static const struct mercury_data_rl_liveness__common_26_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_rl_liveness__common_26;

static const struct mercury_data_rl_liveness__common_27_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_rl_liveness__common_27;

static const struct mercury_data_rl_liveness__common_28_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_28;

static const struct mercury_data_rl_liveness__common_29_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_liveness__common_29;

static const struct mercury_data_rl_liveness__common_30_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_30;

static const struct mercury_data_rl_liveness__common_31_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_liveness__common_31;

static const struct mercury_data_rl_liveness__common_32_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_32;

static const struct mercury_data_rl_liveness__common_33_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_33;

static const struct mercury_data_rl_liveness__common_34_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_34;

static const struct mercury_data_rl_liveness__common_35_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_liveness__common_35;

static const struct mercury_data_rl_liveness__common_36_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_liveness__common_36;

static const struct mercury_data_rl_liveness__common_37_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_37;

static const struct mercury_data_rl_liveness__common_38_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_liveness__common_38;

static const struct mercury_data_rl_liveness__common_39_struct {
	Word * f1;
}  mercury_data_rl_liveness__common_39;

static const struct mercury_data_rl_liveness__common_40_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_40;

static const struct mercury_data_rl_liveness__common_41_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_41;

static const struct mercury_data_rl_liveness__common_42_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_42;

static const struct mercury_data_rl_liveness__common_43_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_43;

static const struct mercury_data_rl_liveness__common_44_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_rl_liveness__common_44;

static const struct mercury_data_rl_liveness__common_45_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_45;

static const struct mercury_data_rl_liveness__common_46_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_rl_liveness__common_46;

static const struct mercury_data_rl_liveness__common_47_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
}  mercury_data_rl_liveness__common_47;

static const struct mercury_data_rl_liveness__common_48_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_48;

static const struct mercury_data_rl_liveness__common_49_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_rl_liveness__common_49;

static const struct mercury_data_rl_liveness__common_50_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_50;

static const struct mercury_data_rl_liveness__common_51_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_rl_liveness__common_51;

static const struct mercury_data_rl_liveness__common_52_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_rl_liveness__common_52;

static const struct mercury_data_rl_liveness__common_53_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__common_53;

static const struct mercury_data_rl_liveness__common_54_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__common_54;

static const struct mercury_data_rl_liveness__type_ctor_functors_live_data_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__type_ctor_functors_live_data_map_0;

static const struct mercury_data_rl_liveness__type_ctor_layout_live_data_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_liveness__type_ctor_layout_live_data_map_0;

static const struct mercury_data_rl_liveness__type_ctor_functors_live_data_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__type_ctor_functors_live_data_0;

static const struct mercury_data_rl_liveness__type_ctor_layout_live_data_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_liveness__type_ctor_layout_live_data_0;

static const struct mercury_data_rl_liveness__type_ctor_functors_creation_data_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__type_ctor_functors_creation_data_map_0;

static const struct mercury_data_rl_liveness__type_ctor_layout_creation_data_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_liveness__type_ctor_layout_creation_data_map_0;

static const struct mercury_data_rl_liveness__type_ctor_functors_creation_data_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_liveness__type_ctor_functors_creation_data_0;

static const struct mercury_data_rl_liveness__type_ctor_layout_creation_data_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_rl_liveness__type_ctor_layout_creation_data_0;

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_creation_data_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_liveness__creation_data_0_0),
	STATIC(mercury____Index___rl_liveness__creation_data_0_0),
	STATIC(mercury____Compare___rl_liveness__creation_data_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_liveness__type_ctor_functors_creation_data_0,
	(Word *) &mercury_data_rl_liveness__type_ctor_layout_creation_data_0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("creation_data", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_creation_data_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_liveness__creation_data_map_0_0),
	STATIC(mercury____Index___rl_liveness__creation_data_map_0_0),
	STATIC(mercury____Compare___rl_liveness__creation_data_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_liveness__type_ctor_functors_creation_data_map_0,
	(Word *) &mercury_data_rl_liveness__type_ctor_layout_creation_data_map_0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("creation_data_map", 17),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_live_data_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_liveness__live_data_0_0),
	STATIC(mercury____Index___rl_liveness__live_data_0_0),
	STATIC(mercury____Compare___rl_liveness__live_data_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_liveness__type_ctor_functors_live_data_0,
	(Word *) &mercury_data_rl_liveness__type_ctor_layout_live_data_0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("live_data", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_rl_liveness__type_ctor_info_live_data_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___rl_liveness__live_data_map_0_0),
	STATIC(mercury____Index___rl_liveness__live_data_map_0_0),
	STATIC(mercury____Compare___rl_liveness__live_data_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_rl_liveness__type_ctor_functors_live_data_map_0,
	(Word *) &mercury_data_rl_liveness__type_ctor_layout_live_data_map_0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("live_data_map", 13),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_rl_liveness__common_0_struct mercury_data_rl_liveness__common_0 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_rl_liveness__common_1_struct mercury_data_rl_liveness__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl_analyse__type_ctor_info_block_data_2;
static const struct mercury_data_rl_liveness__common_2_struct mercury_data_rl_liveness__common_2 = {
	(Word *) &mercury_data_rl_analyse__type_ctor_info_block_data_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_rl_liveness__common_3_struct mercury_data_rl_liveness__common_3 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2)
};

static const struct mercury_data_rl_liveness__common_4_struct mercury_data_rl_liveness__common_4 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl_block__type_ctor_info_rl_opt_info_0;
static const struct mercury_data_rl_liveness__common_5_struct mercury_data_rl_liveness__common_5 = {
	(Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0
};

static const struct mercury_data_rl_liveness__common_6_struct mercury_data_rl_liveness__common_6 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("init_block_liveness", 19),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

static const struct mercury_data_rl_liveness__common_7_struct mercury_data_rl_liveness__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
static const struct mercury_data_rl_liveness__common_8_struct mercury_data_rl_liveness__common_8 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_9_struct mercury_data_rl_liveness__common_9 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_8)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_unit_0;
static const struct mercury_data_rl_liveness__common_10_struct mercury_data_rl_liveness__common_10 = {
	(Word *) &mercury_data_std_util__type_ctor_info_unit_0
};

static const struct mercury_data_rl_liveness__common_11_struct mercury_data_rl_liveness__common_11 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("confluence", 10),
	7,
	0,
	0,
	7,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_9),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

static const struct mercury_data_rl_liveness__common_12_struct mercury_data_rl_liveness__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_11),
	STATIC(mercury__rl_liveness__confluence_7_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_13_struct mercury_data_rl_liveness__common_13 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("update_block_liveness", 21),
	8,
	0,
	0,
	8,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

static const struct mercury_data_rl_liveness__common_14_struct mercury_data_rl_liveness__common_14 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_13),
	STATIC(mercury__rl_liveness__update_block_liveness_8_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_15_struct mercury_data_rl_liveness__common_15 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("unify", 5),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10)
};

static const struct mercury_data_rl_liveness__common_16_struct mercury_data_rl_liveness__common_16 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_15),
	STATIC(mercury__rl_liveness__unify_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_liveness__common_17_struct mercury_data_rl_liveness__common_17 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_liveness__common_18_struct mercury_data_rl_liveness__common_18 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__rl_liveness_2__57__1", 42),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_17)
};

static const struct mercury_data_rl_liveness__common_19_struct mercury_data_rl_liveness__common_19 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_18),
	STATIC(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__57__1_4_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_20_struct mercury_data_rl_liveness__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_14),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_19)
};

static const struct mercury_data_rl_liveness__common_21_struct mercury_data_rl_liveness__common_21 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("init_block_creation", 19),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

static const struct mercury_data_rl_liveness__common_22_struct mercury_data_rl_liveness__common_22 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("update_block_creation", 21),
	8,
	0,
	0,
	8,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

static const struct mercury_data_rl_liveness__common_23_struct mercury_data_rl_liveness__common_23 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_22),
	STATIC(mercury__rl_liveness__update_block_creation_8_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_24_struct mercury_data_rl_liveness__common_24 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__rl_liveness_2__81__2", 42),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_10),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_17),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_17)
};

static const struct mercury_data_rl_liveness__common_25_struct mercury_data_rl_liveness__common_25 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_24),
	STATIC(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__81__2_4_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_26_struct mercury_data_rl_liveness__common_26 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_25)
};

static const struct mercury_data_rl_liveness__common_27_struct mercury_data_rl_liveness__common_27 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("insert_init_and_unset_instructions", 34),
	7,
	0,
	0,
	7,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_rl_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_rl_liveness__common_28_struct mercury_data_rl_liveness__common_28 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_rl__type_ctor_info_rl_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_rl_liveness__common_29_struct mercury_data_rl_liveness__common_29 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("instr_use_before_def", 20),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_30_struct mercury_data_rl_liveness__common_30 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_29),
	STATIC(mercury__rl_liveness__instr_use_before_def_5_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_31_struct mercury_data_rl_liveness__common_31 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("instr_def_before_use", 20),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_32_struct mercury_data_rl_liveness__common_32 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_31),
	STATIC(mercury__rl_liveness__instr_def_before_use_5_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_33_struct mercury_data_rl_liveness__common_33 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__init_block_creation__249__3", 49),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_34_struct mercury_data_rl_liveness__common_34 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_33),
	STATIC(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_rl_liveness__common_35_struct mercury_data_rl_liveness__common_35 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28)
};

static const struct mercury_data_rl_liveness__common_36_struct mercury_data_rl_liveness__common_36 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("insert_unset_instructions", 25),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_37_struct mercury_data_rl_liveness__common_37 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_36),
	STATIC(mercury__rl_liveness__insert_unset_instructions_5_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_relation__type_ctor_info_relation_1;
static const struct mercury_data_rl_liveness__common_38_struct mercury_data_rl_liveness__common_38 = {
	(Word *) &mercury_data_relation__type_ctor_info_relation_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_relation__type_ctor_info_relation_key_0;
static const struct mercury_data_rl_liveness__common_39_struct mercury_data_rl_liveness__common_39 = {
	(Word *) &mercury_data_relation__type_ctor_info_relation_key_0
};

static const struct mercury_data_rl_liveness__common_40_struct mercury_data_rl_liveness__common_40 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__318__4", 64),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_38),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_39),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4)
};

static const struct mercury_data_rl_liveness__common_41_struct mercury_data_rl_liveness__common_41 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__320__5", 64),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_42_struct mercury_data_rl_liveness__common_42 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__331__6", 64),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_43_struct mercury_data_rl_liveness__common_43 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_42),
	STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__331__6_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_44_struct mercury_data_rl_liveness__common_44 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("drop_rel", 8),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28)
};

static const struct mercury_data_rl_liveness__common_45_struct mercury_data_rl_liveness__common_45 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_44),
	STATIC(mercury__rl_liveness__drop_rel_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_relation_info_0;
static const struct mercury_data_rl_liveness__common_46_struct mercury_data_rl_liveness__common_46 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_rl__type_ctor_info_relation_info_0
};

static const struct mercury_data_rl_liveness__common_47_struct mercury_data_rl_liveness__common_47 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("insert_init_instructions", 24),
	6,
	0,
	0,
	6,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_46),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_48_struct mercury_data_rl_liveness__common_48 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__359__7", 64),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_38),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_39),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4)
};

static const struct mercury_data_rl_liveness__common_49_struct mercury_data_rl_liveness__common_49 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__361__8", 64),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_50_struct mercury_data_rl_liveness__common_50 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("IntroducedFrom__pred__insert_init_and_unset_instructions__377__9", 64),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0)
};

static const struct mercury_data_rl_liveness__common_51_struct mercury_data_rl_liveness__common_51 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_50),
	STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__377__9_3_0),
	(Integer) 0
};

static const struct mercury_data_rl_liveness__common_52_struct mercury_data_rl_liveness__common_52 = {
	(Integer) 0,
	MR_string_const("rl_liveness", 11),
	MR_string_const("rl_liveness", 11),
	MR_string_const("init_rel", 8),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_46),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28)
};

static const struct mercury_data_rl_liveness__common_53_struct mercury_data_rl_liveness__common_53 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3)
};

static const struct mercury_data_rl_liveness__common_54_struct mercury_data_rl_liveness__common_54 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2)
};

static const struct mercury_data_rl_liveness__type_ctor_functors_live_data_map_0_struct mercury_data_rl_liveness__type_ctor_functors_live_data_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3)
};

static const struct mercury_data_rl_liveness__type_ctor_layout_live_data_map_0_struct mercury_data_rl_liveness__type_ctor_layout_live_data_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53)
};

static const struct mercury_data_rl_liveness__type_ctor_functors_live_data_0_struct mercury_data_rl_liveness__type_ctor_functors_live_data_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2)
};

static const struct mercury_data_rl_liveness__type_ctor_layout_live_data_0_struct mercury_data_rl_liveness__type_ctor_layout_live_data_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54)
};

static const struct mercury_data_rl_liveness__type_ctor_functors_creation_data_map_0_struct mercury_data_rl_liveness__type_ctor_functors_creation_data_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3)
};

static const struct mercury_data_rl_liveness__type_ctor_layout_creation_data_map_0_struct mercury_data_rl_liveness__type_ctor_layout_creation_data_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_53)
};

static const struct mercury_data_rl_liveness__type_ctor_functors_creation_data_0_struct mercury_data_rl_liveness__type_ctor_functors_creation_data_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2)
};

static const struct mercury_data_rl_liveness__type_ctor_layout_creation_data_0_struct mercury_data_rl_liveness__type_ctor_layout_creation_data_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_rl_liveness__common_54)
};

Declare_entry(mercury__rl_block__rl_opt_info_get_first_block_id_3_0);
Declare_entry(mercury__set__union_3_0);

BEGIN_MODULE(rl_liveness_module0)
	init_entry(mercury__rl_liveness__update_block_creation__ua0_8_0);
	init_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i2);
	init_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i3);
	init_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i4);
	init_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i5);
BEGIN_CODE

/* code for predicate 'update_block_creation__ua0'/8 in mode 0 */
Define_static(mercury__rl_liveness__update_block_creation__ua0_8_0);
	MR_incr_sp_push_msg(4, "rl_liveness:update_block_creation__ua0/8");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_first_block_id_3_0),
		mercury__rl_liveness__update_block_creation__ua0_8_0_i2,
		STATIC(mercury__rl_liveness__update_block_creation__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_creation__ua0_8_0));
	if ((MR_stackvar(1) != r1))
		GOTO_LABEL(mercury__rl_liveness__update_block_creation__ua0_8_0_i3);
	r1 = MR_stackvar(3);
	r3 = r2;
	GOTO_LABEL(mercury__rl_liveness__update_block_creation__ua0_8_0_i5);
Define_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i3);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__update_block_creation__ua0_8_0_i4,
		STATIC(mercury__rl_liveness__update_block_creation__ua0_8_0));
	}
Define_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_creation__ua0_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_liveness__update_block_creation__ua0_8_0, "rl_analyse:block_data/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	r3 = MR_stackvar(1);
Define_label(mercury__rl_liveness__update_block_creation__ua0_8_0_i5);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(rl_liveness_module1)
	init_entry(mercury__rl_liveness__unify__ua0_3_0);
BEGIN_CODE

/* code for predicate 'unify__ua0'/3 in mode 0 */
Define_static(mercury__rl_liveness__unify__ua0_3_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		STATIC(mercury__rl_liveness__unify__ua0_3_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module2)
	init_entry(mercury__rl_liveness__confluence__ua0_7_0);
	init_label(mercury__rl_liveness__confluence__ua0_7_0_i3);
	init_label(mercury__rl_liveness__confluence__ua0_7_0_i4);
BEGIN_CODE

/* code for predicate 'confluence__ua0'/7 in mode 0 */
Define_static(mercury__rl_liveness__confluence__ua0_7_0);
	MR_incr_sp_push_msg(2, "rl_liveness:confluence__ua0/7");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__confluence__ua0_7_0_i3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__rl_liveness__confluence__ua0_7_0_i3);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__confluence__ua0_7_0_i4,
		STATIC(mercury__rl_liveness__confluence__ua0_7_0));
Define_label(mercury__rl_liveness__confluence__ua0_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__confluence__ua0_7_0));
	r2 = (Integer) 0;
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__rl_block__rl_opt_info_get_block_4_0);
Declare_entry(mercury__rl_block__rl_opt_info_get_last_block_id_3_0);
Declare_entry(mercury__rl__instr_relations_3_0);
Declare_entry(mercury__set__insert_list_3_0);
Declare_entry(mercury__set__difference_3_0);

BEGIN_MODULE(rl_liveness_module3)
	init_entry(mercury__rl_liveness__update_block_liveness__ua0_8_0);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i2);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i3);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i4);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i7);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i8);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i5);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i9);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i10);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i11);
	init_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i12);
BEGIN_CODE

/* code for predicate 'update_block_liveness__ua0'/8 in mode 0 */
Define_static(mercury__rl_liveness__update_block_liveness__ua0_8_0);
	MR_incr_sp_push_msg(6, "rl_liveness:update_block_liveness__ua0/8");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_block_4_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i2,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	MR_stackvar(4) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_last_block_id_3_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i3,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	if ((MR_stackvar(1) != r1))
		GOTO_LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0_i4);
	r1 = MR_stackvar(3);
	r3 = r2;
	GOTO_LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0_i12);
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i4);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 2);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0_i5);
	MR_stackvar(5) = r1;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 2), (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i7,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i8,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(4);
	GOTO_LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0_i9);
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i5);
	MR_stackvar(1) = r2;
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	MR_stackvar(3) = r4;
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i9);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i10,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__update_block_liveness__ua0_8_0_i11,
		STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0));
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_liveness__update_block_liveness__ua0_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__rl_liveness__update_block_liveness__ua0_8_0, "rl_analyse:block_data/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	r3 = MR_stackvar(1);
Define_label(mercury__rl_liveness__update_block_liveness__ua0_8_0_i12);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module4)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__377__9_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__377__9'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__377__9_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__set__union_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__377__9_3_0));
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__set__intersect_3_0);

BEGIN_MODULE(rl_liveness_module5)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0);
	init_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i2);
	init_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i3);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__361__8'/4 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0);
	MR_incr_sp_push_msg(3, "rl_liveness:IntroducedFrom__pred__insert_init_and_unset_instructions__361__8/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i2,
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0));
Define_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i3,
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0));
Define_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__set__intersect_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0));
END_MODULE

Declare_entry(mercury__relation__lookup_key_3_0);

BEGIN_MODULE(rl_liveness_module6)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__359__7_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__359__7'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__359__7_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__relation__lookup_key_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__359__7_3_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module7)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__331__6_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__331__6'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__331__6_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__set__union_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__331__6_3_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module8)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0);
	init_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__320__5'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0);
	MR_incr_sp_push_msg(1, "rl_liveness:IntroducedFrom__pred__insert_init_and_unset_instructions__320__5/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0_i2,
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0));
Define_label(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0));
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module9)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__318__4_3_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__insert_init_and_unset_instructions__318__4'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__318__4_3_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__relation__lookup_key_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__318__4_3_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module10)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0);
	init_label(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0_i2);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__init_block_creation__249__3'/3 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0);
	MR_incr_sp_push_msg(2, "rl_liveness:IntroducedFrom__pred__init_block_creation__249__3/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0_i2,
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0));
Define_label(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0));
	r3 = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__set__insert_list_3_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__init_block_creation__249__3_3_0));
END_MODULE

Declare_entry(mercury__rl_analyse__write_gen_kill_data_4_0);

BEGIN_MODULE(rl_liveness_module11)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__81__2_4_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__rl_liveness_2__81__2'/4 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__81__2_4_0);
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_unit_0;
	tailcall(ENTRY(mercury__rl_analyse__write_gen_kill_data_4_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__81__2_4_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module12)
	init_entry(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__57__1_4_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__rl_liveness_2__57__1'/4 in mode 0 */
Define_static(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__57__1_4_0);
	r4 = r3;
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_unit_0;
	tailcall(ENTRY(mercury__rl_analyse__write_gen_kill_data_4_0),
		STATIC(mercury__rl_liveness__IntroducedFrom__pred__rl_liveness_2__57__1_4_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module13)
	init_entry(mercury__rl_liveness__rl_liveness_4_0);
	init_label(mercury__rl_liveness__rl_liveness_4_0_i2);
BEGIN_CODE

/* code for predicate 'rl_liveness'/4 in mode 0 */
Define_entry(mercury__rl_liveness__rl_liveness_4_0);
	MR_incr_sp_push_msg(1, "rl_liveness:rl_liveness/4");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = r2;
	r2 = r3;
	call_localret(STATIC(mercury__rl_liveness__rl_liveness_2_4_0),
		mercury__rl_liveness__rl_liveness_4_0_i2,
		ENTRY(mercury__rl_liveness__rl_liveness_4_0));
Define_label(mercury__rl_liveness__rl_liveness_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_4_0));
	r3 = r1;
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__rl_block__rl_opt_info_get_input_relations_3_0);
Declare_entry(mercury__rl_block__rl_opt_info_get_output_relations_3_0);
Declare_entry(mercury__rl_block__rl_opt_info_get_memoed_relations_3_0);
Declare_entry(mercury__rl_block__rl_opt_info_get_rev_block_order_3_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__list__foldl2_6_0);
Declare_entry(mercury__rl_analyse__rl_analyse_10_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__list__foldl_4_1);

BEGIN_MODULE(rl_liveness_module14)
	init_entry(mercury__rl_liveness__rl_liveness_2_4_0);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i2);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i3);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i4);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i5);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i6);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i7);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i8);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i9);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i10);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i11);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i12);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i13);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i14);
	init_label(mercury__rl_liveness__rl_liveness_2_4_0_i15);
BEGIN_CODE

/* code for predicate 'rl_liveness_2'/4 in mode 0 */
Define_static(mercury__rl_liveness__rl_liveness_2_4_0);
	MR_incr_sp_push_msg(8, "rl_liveness:rl_liveness_2/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_input_relations_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i2,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_output_relations_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i3,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_memoed_relations_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i4,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r3 = MR_stackvar(2);
	MR_stackvar(4) = r2;
	r2 = r1;
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i5,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i6,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_rev_block_order_3_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i7,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i8,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__rl_liveness__rl_liveness_2_4_0, "origin_lost_in_value_number");
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3);
	r3 = (Word) (Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0;
	r5 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__init_block_liveness_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_6);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i9,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r6 = r1;
	r9 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	r3 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_unit_0;
	r4 = MR_stackvar(4);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_20);
	r7 = (Integer) 0;
	r8 = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_analyse__rl_analyse_10_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i10,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	MR_stackvar(5) = r3;
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i11,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_3);
	r3 = (Word) (Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__rl_liveness__rl_liveness_2_4_0, "closure");
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_21);
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__init_block_creation_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(2);
	r6 = r5;
	r5 = MR_stackvar(4);
	r7 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i12,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	MR_stackvar(7) = r2;
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_26);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i13,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r6 = MR_stackvar(4);
	r4 = r1;
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	r3 = (Word) (Word *) &mercury_data_std_util__type_ctor_info_unit_0;
	r5 = MR_stackvar(6);
	r7 = (Integer) 0;
	r8 = MR_stackvar(5);
	r9 = MR_stackvar(7);
	call_localret(ENTRY(mercury__rl_analyse__rl_analyse_10_0),
		mercury__rl_liveness__rl_liveness_2_4_0_i14,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r5 = MR_stackvar(1);
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_rl_block__type_ctor_info_rl_opt_info_0;
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 7, mercury__rl_liveness__rl_liveness_2_4_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_27);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 4;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 5) = r5;
	MR_field(MR_mktag(0), r3, (Integer) 6) = r6;
	r5 = r4;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__rl_liveness_2_4_0_i15,
		STATIC(mercury__rl_liveness__rl_liveness_2_4_0));
Define_label(mercury__rl_liveness__rl_liveness_2_4_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_liveness__rl_liveness_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(rl_liveness_module15)
	init_entry(mercury__rl_liveness__init_block_liveness_6_0);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i2);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i3);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i4);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i5);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i6);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i7);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i10);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i8);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i12);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i13);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i15);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i14);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i17);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i19);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i22);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i23);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i20);
	init_label(mercury__rl_liveness__init_block_liveness_6_0_i25);
BEGIN_CODE

/* code for predicate 'init_block_liveness'/6 in mode 0 */
Define_static(mercury__rl_liveness__init_block_liveness_6_0);
	MR_incr_sp_push_msg(10, "rl_liveness:init_block_liveness/6");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_block_4_0),
		mercury__rl_liveness__init_block_liveness_6_0_i2,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i3,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i4,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i5,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i6,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r6 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_30);
	r5 = MR_stackvar(4);
	r7 = MR_stackvar(8);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__init_block_liveness_6_0_i7,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__init_block_liveness_6_0_i8);
	r3 = r2;
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	call_localret(STATIC(mercury__rl_liveness__instr_use_before_def_5_0),
		mercury__rl_liveness__init_block_liveness_6_0_i10,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r5 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_32);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__init_block_liveness_6_0_i12,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i8);
	r5 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_32);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__init_block_liveness_6_0_i12,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_last_block_id_3_0),
		mercury__rl_liveness__init_block_liveness_6_0_i13,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	if ((MR_stackvar(2) != r1))
		GOTO_LABEL(mercury__rl_liveness__init_block_liveness_6_0_i14);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_stackvar(7) = MR_tempr1;
	MR_stackvar(1) = r2;
	r2 = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__init_block_liveness_6_0_i15,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
	}
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__init_block_liveness_6_0_i19,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i14);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i17,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_liveness_6_0_i19,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__init_block_liveness_6_0_i20);
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__init_block_liveness_6_0_i22,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__init_block_liveness_6_0_i23,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__rl_liveness__init_block_liveness_6_0, "rl_analyse:block_data/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__init_block_liveness_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_liveness__init_block_liveness_6_0_i25,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
	}
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i20);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__rl_liveness__init_block_liveness_6_0, "rl_analyse:block_data/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__init_block_liveness_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_liveness__init_block_liveness_6_0_i25,
		STATIC(mercury__rl_liveness__init_block_liveness_6_0));
	}
Define_label(mercury__rl_liveness__init_block_liveness_6_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_liveness_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__set__list_to_set_2_0);

BEGIN_MODULE(rl_liveness_module16)
	init_entry(mercury__rl_liveness__instr_use_before_def_5_0);
	init_label(mercury__rl_liveness__instr_use_before_def_5_0_i2);
	init_label(mercury__rl_liveness__instr_use_before_def_5_0_i3);
	init_label(mercury__rl_liveness__instr_use_before_def_5_0_i4);
	init_label(mercury__rl_liveness__instr_use_before_def_5_0_i5);
	init_label(mercury__rl_liveness__instr_use_before_def_5_0_i6);
BEGIN_CODE

/* code for predicate 'instr_use_before_def'/5 in mode 0 */
Define_static(mercury__rl_liveness__instr_use_before_def_5_0);
	MR_incr_sp_push_msg(4, "rl_liveness:instr_use_before_def/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__instr_use_before_def_5_0_i2,
		STATIC(mercury__rl_liveness__instr_use_before_def_5_0));
Define_label(mercury__rl_liveness__instr_use_before_def_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_use_before_def_5_0));
	MR_stackvar(3) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_liveness__instr_use_before_def_5_0_i3,
		STATIC(mercury__rl_liveness__instr_use_before_def_5_0));
Define_label(mercury__rl_liveness__instr_use_before_def_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_use_before_def_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__instr_use_before_def_5_0_i4,
		STATIC(mercury__rl_liveness__instr_use_before_def_5_0));
Define_label(mercury__rl_liveness__instr_use_before_def_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_use_before_def_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__instr_use_before_def_5_0_i5,
		STATIC(mercury__rl_liveness__instr_use_before_def_5_0));
Define_label(mercury__rl_liveness__instr_use_before_def_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_use_before_def_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__instr_use_before_def_5_0_i6,
		STATIC(mercury__rl_liveness__instr_use_before_def_5_0));
Define_label(mercury__rl_liveness__instr_use_before_def_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_use_before_def_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module17)
	init_entry(mercury__rl_liveness__instr_def_before_use_5_0);
	init_label(mercury__rl_liveness__instr_def_before_use_5_0_i2);
	init_label(mercury__rl_liveness__instr_def_before_use_5_0_i3);
	init_label(mercury__rl_liveness__instr_def_before_use_5_0_i4);
	init_label(mercury__rl_liveness__instr_def_before_use_5_0_i5);
	init_label(mercury__rl_liveness__instr_def_before_use_5_0_i6);
BEGIN_CODE

/* code for predicate 'instr_def_before_use'/5 in mode 0 */
Define_static(mercury__rl_liveness__instr_def_before_use_5_0);
	MR_incr_sp_push_msg(3, "rl_liveness:instr_def_before_use/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__instr_def_before_use_5_0_i2,
		STATIC(mercury__rl_liveness__instr_def_before_use_5_0));
Define_label(mercury__rl_liveness__instr_def_before_use_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_def_before_use_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__instr_def_before_use_5_0_i3,
		STATIC(mercury__rl_liveness__instr_def_before_use_5_0));
	}
Define_label(mercury__rl_liveness__instr_def_before_use_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_def_before_use_5_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_liveness__instr_def_before_use_5_0_i4,
		STATIC(mercury__rl_liveness__instr_def_before_use_5_0));
Define_label(mercury__rl_liveness__instr_def_before_use_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_def_before_use_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__instr_def_before_use_5_0_i5,
		STATIC(mercury__rl_liveness__instr_def_before_use_5_0));
Define_label(mercury__rl_liveness__instr_def_before_use_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_def_before_use_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__instr_def_before_use_5_0_i6,
		STATIC(mercury__rl_liveness__instr_def_before_use_5_0));
Define_label(mercury__rl_liveness__instr_def_before_use_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__instr_def_before_use_5_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module18)
	init_entry(mercury__rl_liveness__update_block_liveness_8_0);
BEGIN_CODE

/* code for predicate 'update_block_liveness'/8 in mode 0 */
Define_static(mercury__rl_liveness__update_block_liveness_8_0);
	r4 = r5;
	tailcall(STATIC(mercury__rl_liveness__update_block_liveness__ua0_8_0),
		STATIC(mercury__rl_liveness__update_block_liveness_8_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module19)
	init_entry(mercury__rl_liveness__confluence_7_0);
BEGIN_CODE

/* code for predicate 'confluence'/7 in mode 0 */
Define_static(mercury__rl_liveness__confluence_7_0);
	r3 = r4;
	tailcall(STATIC(mercury__rl_liveness__confluence__ua0_7_0),
		STATIC(mercury__rl_liveness__confluence_7_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module20)
	init_entry(mercury__rl_liveness__unify_3_0);
BEGIN_CODE

/* code for predicate 'unify'/3 in mode 0 */
Define_static(mercury__rl_liveness__unify_3_0);
	tailcall(STATIC(mercury__rl_liveness__unify__ua0_3_0),
		STATIC(mercury__rl_liveness__unify_3_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module21)
	init_entry(mercury__rl_liveness__init_block_creation_6_0);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i2);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i3);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i4);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i5);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i7);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i6);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i8);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i10);
	init_label(mercury__rl_liveness__init_block_creation_6_0_i11);
BEGIN_CODE

/* code for predicate 'init_block_creation'/6 in mode 0 */
Define_static(mercury__rl_liveness__init_block_creation_6_0);
	MR_incr_sp_push_msg(7, "rl_liveness:init_block_creation/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_block_4_0),
		mercury__rl_liveness__init_block_creation_6_0_i2,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_creation_6_0_i3,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_34);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__init_block_creation_6_0_i4,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_first_block_id_3_0),
		mercury__rl_liveness__init_block_creation_6_0_i5,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	if ((MR_stackvar(2) != r1))
		GOTO_LABEL(mercury__rl_liveness__init_block_creation_6_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(1) = r2;
	r2 = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__init_block_creation_6_0_i7,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
	}
Define_label(mercury__rl_liveness__init_block_creation_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_creation_6_0_i10,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i6);
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_creation_6_0_i8,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(6) = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__init_block_creation_6_0_i10,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
Define_label(mercury__rl_liveness__init_block_creation_6_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	r6 = r1;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__rl_liveness__init_block_creation_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_stackvar(5);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__init_block_creation_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__rl_liveness__init_block_creation_6_0_i11,
		STATIC(mercury__rl_liveness__init_block_creation_6_0));
	}
Define_label(mercury__rl_liveness__init_block_creation_6_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_block_creation_6_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module22)
	init_entry(mercury__rl_liveness__update_block_creation_8_0);
BEGIN_CODE

/* code for predicate 'update_block_creation'/8 in mode 0 */
Define_static(mercury__rl_liveness__update_block_creation_8_0);
	r4 = r5;
	tailcall(STATIC(mercury__rl_liveness__update_block_creation__ua0_8_0),
		STATIC(mercury__rl_liveness__update_block_creation_8_0));
END_MODULE

Declare_entry(mercury__rl_block__rl_opt_info_get_flow_graph_3_0);
Declare_entry(mercury__relation__lookup_element_3_0);
Declare_entry(mercury__relation__lookup_to_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__rl_block__rl_opt_info_get_relation_info_map_3_0);
Declare_entry(mercury__relation__lookup_from_3_0);
Declare_entry(mercury__list__filter_map_3_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__rl_block__rl_opt_info_set_block_4_0);

BEGIN_MODULE(rl_liveness_module23)
	init_entry(mercury__rl_liveness__insert_init_and_unset_instructions_7_0);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i2);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i3);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i4);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i5);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i6);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i7);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i8);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i9);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i10);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i11);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i12);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i13);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i14);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i15);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i17);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i18);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i19);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i20);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i21);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i22);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i23);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i24);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i25);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i26);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i27);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i28);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i29);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i30);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i32);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i33);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i34);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i35);
	init_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i36);
BEGIN_CODE

/* code for predicate 'insert_init_and_unset_instructions'/7 in mode 0 */
Define_static(mercury__rl_liveness__insert_init_and_unset_instructions_7_0);
	MR_incr_sp_push_msg(16, "rl_liveness:insert_init_and_unset_instructions/7");
	MR_stackvar(16) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r6;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_first_block_id_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i2,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_last_block_id_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i3,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_block_4_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i4,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(11) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i5,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i6,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r5 = MR_stackvar(10);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(10) = r7;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_37);
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i7,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r3 = r1;
	r1 = MR_stackvar(11);
	MR_stackvar(11) = r3;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_flow_graph_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i8,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(15) = r2;
	r2 = r1;
	MR_stackvar(13) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__relation__lookup_element_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i9,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r3 = r1;
	MR_stackvar(14) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__relation__lookup_to_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i10,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i11,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(13);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__318__4_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_40);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i12,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_41);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__320__5_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i13,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	if ((MR_stackvar(5) != MR_stackvar(6)))
		GOTO_LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i14);
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_43);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i17,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i14);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i15,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_43);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i17,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i18,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i19,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_45);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i20,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(15);
	call_localret(ENTRY(mercury__rl_block__rl_opt_info_get_relation_info_map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i21,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i21);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(6) = r1;
	MR_stackvar(15) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i22,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_35);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "origin_lost_in_value_number");
	r7 = MR_const_field(MR_mktag(0), r5, (Integer) 0);
	r5 = MR_stackvar(11);
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__insert_init_instructions_6_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_47);
	call_localret(ENTRY(mercury__list__foldl2_6_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i23,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	MR_stackvar(11) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i24,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r3 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__relation__lookup_from_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i25,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i25);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i26,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_relation__type_ctor_info_relation_key_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_48);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__359__7_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(13);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i27,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_49);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__IntroducedFrom__pred__insert_init_and_unset_instructions__361__8_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i28,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	if ((MR_stackvar(5) != MR_stackvar(7)))
		GOTO_LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i29);
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_51);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i32,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i29);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i30,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_51);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__foldl_4_1),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i32,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i33,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i33);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i34,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i34);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_52);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__init_rel_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__filter_map_3_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i35,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(14);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i36,
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	}
Define_label(mercury__rl_liveness__insert_init_and_unset_instructions_7_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "rl_block:block/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(9);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_init_and_unset_instructions_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_tempr1;
	r3 = MR_stackvar(15);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	tailcall(ENTRY(mercury__rl_block__rl_opt_info_set_block_4_0),
		STATIC(mercury__rl_liveness__insert_init_and_unset_instructions_7_0));
	}
END_MODULE

Declare_entry(mercury__set__empty_1_0);
Declare_entry(mercury__set__member_2_0);

BEGIN_MODULE(rl_liveness_module24)
	init_entry(mercury__rl_liveness__insert_unset_instructions_5_0);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i2);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i3);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i4);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i6);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i10);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i9);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i5);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i13);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i14);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i15);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i16);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i17);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i18);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i19);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i22);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1081);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i20);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i28);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1107);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i35);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1139);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
	init_label(mercury__rl_liveness__insert_unset_instructions_5_0_i41);
BEGIN_CODE

/* code for predicate 'insert_unset_instructions'/5 in mode 0 */
Define_static(mercury__rl_liveness__insert_unset_instructions_5_0);
	MR_incr_sp_push_msg(17, "rl_liveness:insert_unset_instructions/5");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i2,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i3,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i4,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__empty_1_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i6,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i5);
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_liveness__undroppable_instr_1_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i10,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i9);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i9);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i5);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i13,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	MR_stackvar(7) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i14,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	MR_stackvar(4) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i15,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i16,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i17,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i18,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_45);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i19,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i20);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 11))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i20);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	r3 = r2;
	r2 = MR_stackvar(5);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i22,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__set__intersect_3_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i1081,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1081);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 11;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i20);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 6) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
	r3 = MR_stackvar(3);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), r2, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r2, (Integer) 6), (Integer) 0);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i28,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i1107);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 7, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(16);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1107);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 7, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(16);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(9), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i24);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(10) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_stackvar(12) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_stackvar(14) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(15) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r2, (Integer) 5), (Integer) 0);
	MR_stackvar(1) = r1;
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(13) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i35,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_liveness__insert_unset_instructions_5_0_i1139);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(15), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(15), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1139);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(13);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(15), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(14);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(10);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(15), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i1153);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_unset_instructions_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__rl_liveness__insert_unset_instructions_5_0_i41,
		STATIC(mercury__rl_liveness__insert_unset_instructions_5_0));
	}
Define_label(mercury__rl_liveness__insert_unset_instructions_5_0_i41);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_unset_instructions_5_0));
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module25)
	init_entry(mercury__rl_liveness__undroppable_instr_1_0);
	init_label(mercury__rl_liveness__undroppable_instr_1_0_i2);
	init_label(mercury__rl_liveness__undroppable_instr_1_0_i1);
BEGIN_CODE

/* code for predicate 'undroppable_instr'/1 in mode 0 */
Define_static(mercury__rl_liveness__undroppable_instr_1_0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i1) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i2) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i2) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i2) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i2) AND
		LABEL(mercury__rl_liveness__undroppable_instr_1_0_i2));
Define_label(mercury__rl_liveness__undroppable_instr_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_liveness__undroppable_instr_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module26)
	init_entry(mercury__rl_liveness__drop_rel_2_0);
BEGIN_CODE

/* code for predicate 'drop_rel'/2 in mode 0 */
Define_static(mercury__rl_liveness__drop_rel_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__drop_rel_2_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__rl_liveness__drop_rel_2_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) MR_string_const("", 0);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(rl_liveness_module27)
	init_entry(mercury__rl_liveness__insert_init_instructions_6_0);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i2);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i3);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i4);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i5);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i6);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i7);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i8);
	init_label(mercury__rl_liveness__insert_init_instructions_6_0_i9);
BEGIN_CODE

/* code for predicate 'insert_init_instructions'/6 in mode 0 */
Define_static(mercury__rl_liveness__insert_init_instructions_6_0);
	MR_incr_sp_push_msg(7, "rl_liveness:insert_init_instructions/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__rl__instr_relations_3_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i2,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	MR_stackvar(5) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i3,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i4,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i5,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__rl_liveness__insert_init_instructions_6_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__rl_liveness__init_rel_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_52);
	call_localret(ENTRY(mercury__list__filter_map_3_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i6,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_28);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__rl_liveness__insert_init_instructions_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__rl_liveness__insert_init_instructions_6_0_i7,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i8,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__union_3_0),
		mercury__rl_liveness__insert_init_instructions_6_0_i9,
		STATIC(mercury__rl_liveness__insert_init_instructions_6_0));
Define_label(mercury__rl_liveness__insert_init_instructions_6_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_liveness__insert_init_instructions_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(rl_liveness_module28)
	init_entry(mercury__rl_liveness__init_rel_3_0);
	init_label(mercury__rl_liveness__init_rel_3_0_i2);
	init_label(mercury__rl_liveness__init_rel_3_0_i1);
BEGIN_CODE

/* code for predicate 'init_rel'/3 in mode 0 */
Define_static(mercury__rl_liveness__init_rel_3_0);
	MR_incr_sp_push_msg(2, "rl_liveness:init_rel/3");
	MR_stackvar(2) = (Word) MR_succip;
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(0), (Integer) 2, mercury__rl_liveness__init_rel_3_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__rl_liveness__init_rel_3_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 1) = (Word) MR_string_const("", 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_liveness__init_rel_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_relation_info_0;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__rl_liveness__init_rel_3_0_i2,
		STATIC(mercury__rl_liveness__init_rel_3_0));
	}
Define_label(mercury__rl_liveness__init_rel_3_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_liveness__init_rel_3_0));
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__rl_liveness__init_rel_3_0_i1);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = TRUE;
	proceed();
Define_label(mercury__rl_liveness__init_rel_3_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury____Unify___rl_analyse__block_data_2_0);

BEGIN_MODULE(rl_liveness_module29)
	init_entry(mercury____Unify___rl_liveness__live_data_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_liveness__live_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Unify___rl_analyse__block_data_2_0),
		STATIC(mercury____Unify___rl_liveness__live_data_0_0));
END_MODULE

Declare_entry(mercury____Index___rl_analyse__block_data_2_0);

BEGIN_MODULE(rl_liveness_module30)
	init_entry(mercury____Index___rl_liveness__live_data_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_liveness__live_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Index___rl_analyse__block_data_2_0),
		STATIC(mercury____Index___rl_liveness__live_data_0_0));
END_MODULE

Declare_entry(mercury____Compare___rl_analyse__block_data_2_0);

BEGIN_MODULE(rl_liveness_module31)
	init_entry(mercury____Compare___rl_liveness__live_data_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_liveness__live_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Compare___rl_analyse__block_data_2_0),
		STATIC(mercury____Compare___rl_liveness__live_data_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(rl_liveness_module32)
	init_entry(mercury____Unify___rl_liveness__live_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_liveness__live_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___rl_liveness__live_data_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(rl_liveness_module33)
	init_entry(mercury____Index___rl_liveness__live_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_liveness__live_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___rl_liveness__live_data_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(rl_liveness_module34)
	init_entry(mercury____Compare___rl_liveness__live_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_liveness__live_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___rl_liveness__live_data_map_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module35)
	init_entry(mercury____Unify___rl_liveness__creation_data_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_liveness__creation_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Unify___rl_analyse__block_data_2_0),
		STATIC(mercury____Unify___rl_liveness__creation_data_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module36)
	init_entry(mercury____Index___rl_liveness__creation_data_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_liveness__creation_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Index___rl_analyse__block_data_2_0),
		STATIC(mercury____Index___rl_liveness__creation_data_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module37)
	init_entry(mercury____Compare___rl_liveness__creation_data_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_liveness__creation_data_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_0);
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_1);
	tailcall(ENTRY(mercury____Compare___rl_analyse__block_data_2_0),
		STATIC(mercury____Compare___rl_liveness__creation_data_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module38)
	init_entry(mercury____Unify___rl_liveness__creation_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___rl_liveness__creation_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___rl_liveness__creation_data_map_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module39)
	init_entry(mercury____Index___rl_liveness__creation_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___rl_liveness__creation_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___rl_liveness__creation_data_map_0_0));
END_MODULE


BEGIN_MODULE(rl_liveness_module40)
	init_entry(mercury____Compare___rl_liveness__creation_data_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___rl_liveness__creation_data_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_liveness__common_2);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___rl_liveness__creation_data_map_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_liveness_maybe_bunch_0(void)
{
	rl_liveness_module0();
	rl_liveness_module1();
	rl_liveness_module2();
	rl_liveness_module3();
	rl_liveness_module4();
	rl_liveness_module5();
	rl_liveness_module6();
	rl_liveness_module7();
	rl_liveness_module8();
	rl_liveness_module9();
	rl_liveness_module10();
	rl_liveness_module11();
	rl_liveness_module12();
	rl_liveness_module13();
	rl_liveness_module14();
	rl_liveness_module15();
	rl_liveness_module16();
	rl_liveness_module17();
	rl_liveness_module18();
	rl_liveness_module19();
	rl_liveness_module20();
	rl_liveness_module21();
	rl_liveness_module22();
	rl_liveness_module23();
	rl_liveness_module24();
	rl_liveness_module25();
	rl_liveness_module26();
	rl_liveness_module27();
	rl_liveness_module28();
	rl_liveness_module29();
	rl_liveness_module30();
	rl_liveness_module31();
	rl_liveness_module32();
	rl_liveness_module33();
	rl_liveness_module34();
	rl_liveness_module35();
	rl_liveness_module36();
	rl_liveness_module37();
	rl_liveness_module38();
	rl_liveness_module39();
}

static void mercury__rl_liveness_maybe_bunch_1(void)
{
	rl_liveness_module40();
}

#endif

void mercury__rl_liveness__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_liveness__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_liveness_maybe_bunch_0();
		mercury__rl_liveness_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_liveness__type_ctor_info_creation_data_0,
			rl_liveness__creation_data_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_liveness__type_ctor_info_creation_data_map_0,
			rl_liveness__creation_data_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_liveness__type_ctor_info_live_data_0,
			rl_liveness__live_data_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_rl_liveness__type_ctor_info_live_data_map_0,
			rl_liveness__live_data_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
