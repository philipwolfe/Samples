/*
** Automatically generated from `rl_opt.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_opt__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__rl_opt__procs_5_0);
Declare_static(mercury__rl_opt__proc_5_0);
Declare_label(mercury__rl_opt__proc_5_0_i2);
Declare_label(mercury__rl_opt__proc_5_0_i3);
Declare_label(mercury__rl_opt__proc_5_0_i4);
Declare_label(mercury__rl_opt__proc_5_0_i5);
Declare_label(mercury__rl_opt__proc_5_0_i6);
Declare_label(mercury__rl_opt__proc_5_0_i7);
Declare_label(mercury__rl_opt__proc_5_0_i8);
Declare_label(mercury__rl_opt__proc_5_0_i9);
Declare_label(mercury__rl_opt__proc_5_0_i10);
Declare_label(mercury__rl_opt__proc_5_0_i11);
Declare_label(mercury__rl_opt__proc_5_0_i14);
Declare_label(mercury__rl_opt__proc_5_0_i15);
Declare_label(mercury__rl_opt__proc_5_0_i16);
Declare_label(mercury__rl_opt__proc_5_0_i17);
Declare_label(mercury__rl_opt__proc_5_0_i18);
Declare_label(mercury__rl_opt__proc_5_0_i19);
Declare_label(mercury__rl_opt__proc_5_0_i20);
Declare_label(mercury__rl_opt__proc_5_0_i12);
Declare_label(mercury__rl_opt__proc_5_0_i22);
Declare_label(mercury__rl_opt__proc_5_0_i23);
Declare_label(mercury__rl_opt__proc_5_0_i26);
Declare_label(mercury__rl_opt__proc_5_0_i27);
Declare_label(mercury__rl_opt__proc_5_0_i28);
Declare_label(mercury__rl_opt__proc_5_0_i29);
Declare_label(mercury__rl_opt__proc_5_0_i30);
Declare_label(mercury__rl_opt__proc_5_0_i31);
Declare_label(mercury__rl_opt__proc_5_0_i32);
Declare_label(mercury__rl_opt__proc_5_0_i33);
Declare_label(mercury__rl_opt__proc_5_0_i34);
Declare_label(mercury__rl_opt__proc_5_0_i35);
Declare_label(mercury__rl_opt__proc_5_0_i36);
Declare_label(mercury__rl_opt__proc_5_0_i37);
Declare_label(mercury__rl_opt__proc_5_0_i40);
Declare_label(mercury__rl_opt__proc_5_0_i41);
Declare_label(mercury__rl_opt__proc_5_0_i42);
Declare_label(mercury__rl_opt__proc_5_0_i24);
Declare_label(mercury__rl_opt__proc_5_0_i43);
Declare_label(mercury__rl_opt__proc_5_0_i44);
Declare_label(mercury__rl_opt__proc_5_0_i45);
Declare_label(mercury__rl_opt__proc_5_0_i46);
Declare_label(mercury__rl_opt__proc_5_0_i47);
Declare_label(mercury__rl_opt__proc_5_0_i48);
Declare_label(mercury__rl_opt__proc_5_0_i49);
Declare_label(mercury__rl_opt__proc_5_0_i50);
Declare_label(mercury__rl_opt__proc_5_0_i53);
Declare_label(mercury__rl_opt__proc_5_0_i54);
Declare_label(mercury__rl_opt__proc_5_0_i55);
Declare_label(mercury__rl_opt__proc_5_0_i56);
Declare_label(mercury__rl_opt__proc_5_0_i57);
Declare_label(mercury__rl_opt__proc_5_0_i51);
Declare_label(mercury__rl_opt__proc_5_0_i60);
Declare_label(mercury__rl_opt__proc_5_0_i63);
Declare_label(mercury__rl_opt__proc_5_0_i64);
Declare_label(mercury__rl_opt__proc_5_0_i65);
Declare_label(mercury__rl_opt__proc_5_0_i66);
Declare_label(mercury__rl_opt__proc_5_0_i67);
Declare_label(mercury__rl_opt__proc_5_0_i68);
Declare_label(mercury__rl_opt__proc_5_0_i61);
Declare_label(mercury__rl_opt__proc_5_0_i70);
Declare_static(mercury__rl_opt__maybe_dump_rl_7_0);
Declare_label(mercury__rl_opt__maybe_dump_rl_7_0_i3);
Declare_label(mercury__rl_opt__maybe_dump_rl_7_0_i4);
Declare_label(mercury__rl_opt__maybe_dump_rl_7_0_i5);
Declare_label(mercury__rl_opt__maybe_dump_rl_7_0_i6);

static const struct mercury_data_rl_opt__common_0_struct {
	Word * f1;
}  mercury_data_rl_opt__common_0;

static const struct mercury_data_rl_opt__common_1_struct {
	Word * f1;
}  mercury_data_rl_opt__common_1;

static const struct mercury_data_rl_opt__common_2_struct {
	Word * f1;
}  mercury_data_rl_opt__common_2;

static const struct mercury_data_rl_opt__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_rl_opt__common_3;

static const struct mercury_data_rl_opt__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_rl_opt__common_4;

static const struct mercury_data_rl_opt__common_5_struct {
	String f1;
	Word * f2;
}  mercury_data_rl_opt__common_5;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_rl_opt__common_0_struct mercury_data_rl_opt__common_0 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_rl__type_ctor_info_rl_proc_0;
static const struct mercury_data_rl_opt__common_1_struct mercury_data_rl_opt__common_1 = {
	(Word *) &mercury_data_rl__type_ctor_info_rl_proc_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_io__type_ctor_info_state_0;
static const struct mercury_data_rl_opt__common_2_struct mercury_data_rl_opt__common_2 = {
	(Word *) &mercury_data_io__type_ctor_info_state_0
};

static const struct mercury_data_rl_opt__common_3_struct mercury_data_rl_opt__common_3 = {
	(Integer) 0,
	MR_string_const("rl_opt", 6),
	MR_string_const("rl_opt", 6),
	MR_string_const("proc", 4),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_2)
};

static const struct mercury_data_rl_opt__common_4_struct mercury_data_rl_opt__common_4 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_rl_opt__common_5_struct mercury_data_rl_opt__common_5 = {
	MR_string_const("\n\n", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

Declare_entry(mercury__list__map_foldl_5_0);

BEGIN_MODULE(rl_opt_module0)
	init_entry(mercury__rl_opt__procs_5_0);
BEGIN_CODE

/* code for predicate 'procs'/5 in mode 0 */
Define_entry(mercury__rl_opt__procs_5_0);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__rl_opt__procs_5_0, "origin_lost_in_value_number");
	r5 = r2;
	r6 = r3;
	MR_field(MR_mktag(0), r4, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_rl__type_ctor_info_rl_proc_0;
	r2 = (Word) (Word *) &mercury_data_rl__type_ctor_info_rl_proc_0;
	r3 = (Word) (Word *) &mercury_data_io__type_ctor_info_state_0;
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__rl_opt__proc_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_opt__common_3);
	tailcall(ENTRY(mercury__list__map_foldl_5_0),
		ENTRY(mercury__rl_opt__procs_5_0));
END_MODULE

Declare_entry(mercury__rl__proc_name_to_string_2_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
Declare_entry(mercury__rl_block__create_flow_graph_6_0);
Declare_entry(mercury__rl_loop__shift_invariants_2_0);
Declare_entry(mercury__rl_liveness__rl_liveness_4_0);
Declare_entry(mercury__rl_block_opt__rl_block_opt_5_0);
Declare_entry(mercury__rl_sort__proc_4_0);
Declare_entry(mercury__rl_stream__detect_streams_2_0);
Declare_entry(mercury__rl_block__get_proc_4_0);

BEGIN_MODULE(rl_opt_module1)
	init_entry(mercury__rl_opt__proc_5_0);
	init_label(mercury__rl_opt__proc_5_0_i2);
	init_label(mercury__rl_opt__proc_5_0_i3);
	init_label(mercury__rl_opt__proc_5_0_i4);
	init_label(mercury__rl_opt__proc_5_0_i5);
	init_label(mercury__rl_opt__proc_5_0_i6);
	init_label(mercury__rl_opt__proc_5_0_i7);
	init_label(mercury__rl_opt__proc_5_0_i8);
	init_label(mercury__rl_opt__proc_5_0_i9);
	init_label(mercury__rl_opt__proc_5_0_i10);
	init_label(mercury__rl_opt__proc_5_0_i11);
	init_label(mercury__rl_opt__proc_5_0_i14);
	init_label(mercury__rl_opt__proc_5_0_i15);
	init_label(mercury__rl_opt__proc_5_0_i16);
	init_label(mercury__rl_opt__proc_5_0_i17);
	init_label(mercury__rl_opt__proc_5_0_i18);
	init_label(mercury__rl_opt__proc_5_0_i19);
	init_label(mercury__rl_opt__proc_5_0_i20);
	init_label(mercury__rl_opt__proc_5_0_i12);
	init_label(mercury__rl_opt__proc_5_0_i22);
	init_label(mercury__rl_opt__proc_5_0_i23);
	init_label(mercury__rl_opt__proc_5_0_i26);
	init_label(mercury__rl_opt__proc_5_0_i27);
	init_label(mercury__rl_opt__proc_5_0_i28);
	init_label(mercury__rl_opt__proc_5_0_i29);
	init_label(mercury__rl_opt__proc_5_0_i30);
	init_label(mercury__rl_opt__proc_5_0_i31);
	init_label(mercury__rl_opt__proc_5_0_i32);
	init_label(mercury__rl_opt__proc_5_0_i33);
	init_label(mercury__rl_opt__proc_5_0_i34);
	init_label(mercury__rl_opt__proc_5_0_i35);
	init_label(mercury__rl_opt__proc_5_0_i36);
	init_label(mercury__rl_opt__proc_5_0_i37);
	init_label(mercury__rl_opt__proc_5_0_i40);
	init_label(mercury__rl_opt__proc_5_0_i41);
	init_label(mercury__rl_opt__proc_5_0_i42);
	init_label(mercury__rl_opt__proc_5_0_i24);
	init_label(mercury__rl_opt__proc_5_0_i43);
	init_label(mercury__rl_opt__proc_5_0_i44);
	init_label(mercury__rl_opt__proc_5_0_i45);
	init_label(mercury__rl_opt__proc_5_0_i46);
	init_label(mercury__rl_opt__proc_5_0_i47);
	init_label(mercury__rl_opt__proc_5_0_i48);
	init_label(mercury__rl_opt__proc_5_0_i49);
	init_label(mercury__rl_opt__proc_5_0_i50);
	init_label(mercury__rl_opt__proc_5_0_i53);
	init_label(mercury__rl_opt__proc_5_0_i54);
	init_label(mercury__rl_opt__proc_5_0_i55);
	init_label(mercury__rl_opt__proc_5_0_i56);
	init_label(mercury__rl_opt__proc_5_0_i57);
	init_label(mercury__rl_opt__proc_5_0_i51);
	init_label(mercury__rl_opt__proc_5_0_i60);
	init_label(mercury__rl_opt__proc_5_0_i63);
	init_label(mercury__rl_opt__proc_5_0_i64);
	init_label(mercury__rl_opt__proc_5_0_i65);
	init_label(mercury__rl_opt__proc_5_0_i66);
	init_label(mercury__rl_opt__proc_5_0_i67);
	init_label(mercury__rl_opt__proc_5_0_i68);
	init_label(mercury__rl_opt__proc_5_0_i61);
	init_label(mercury__rl_opt__proc_5_0_i70);
BEGIN_CODE

/* code for predicate 'proc'/5 in mode 0 */
Define_static(mercury__rl_opt__proc_5_0);
	MR_incr_sp_push_msg(9, "rl_opt:proc/5");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	MR_stackvar(4) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl__proc_name_to_string_2_0),
		mercury__rl_opt__proc_5_0_i2,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Integer) 18;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i3,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	MR_stackvar(6) = r1;
	r1 = (Integer) 17;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i4,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	MR_stackvar(7) = r1;
	r1 = (Integer) 28;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i5,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r2;
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	r2 = (Word) MR_string_const("% Optimizing RL procedure ", 26);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i6,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i7,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i8,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__rl_opt__proc_5_0_i9,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r4 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__rl_block__create_flow_graph_6_0),
		mercury__rl_opt__proc_5_0_i10,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	MR_stackvar(1) = r1;
	r1 = (Integer) 212;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i11,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_opt__proc_5_0_i12);
	r1 = MR_stackvar(6);
	r3 = r2;
	r2 = (Word) MR_string_const("% Detecting loop invariants in ", 31);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i14,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i15,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i16,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__rl_opt__proc_5_0_i17,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl_loop__shift_invariants_2_0),
		mercury__rl_opt__proc_5_0_i18,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i19,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r6 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("10", 2);
	r4 = (Word) MR_string_const("invariants", 10);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i20,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = (Integer) 210;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i22,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i12);
	r1 = (Integer) 210;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i22,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	MR_stackvar(2) = r1;
	r1 = (Integer) 213;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i23,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__rl_opt__proc_5_0_i24);
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("% Detecting liveness in ", 24);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i26,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i26);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i27,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i27);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i28,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i28);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__rl_opt__proc_5_0_i29,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i29);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_liveness__rl_liveness_4_0),
		mercury__rl_opt__proc_5_0_i30,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i30);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i31,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i31);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r6 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("15", 2);
	r4 = (Word) MR_string_const("liveness1", 9);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i32,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i32);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("% Optimizing basic blocks in ", 29);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i33,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i33);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i34,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i34);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i35,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i35);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__rl_opt__proc_5_0_i36,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i36);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__rl_opt__proc_5_0_i37);
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_opt__common_4);
	call_localret(ENTRY(mercury__rl_block_opt__rl_block_opt_5_0),
		mercury__rl_opt__proc_5_0_i40,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i37);
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__rl_block_opt__rl_block_opt_5_0),
		mercury__rl_opt__proc_5_0_i40,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i40);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i41,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i41);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r6 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("20", 2);
	r4 = (Word) MR_string_const("block_opt", 9);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i42,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i42);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("% Detecting final liveness in ", 30);
	GOTO_LABEL(mercury__rl_opt__proc_5_0_i43);
Define_label(mercury__rl_opt__proc_5_0_i24);
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("% Detecting final liveness in ", 30);
Define_label(mercury__rl_opt__proc_5_0_i43);
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i44,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i44);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i45,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i45);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i46,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i46);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__rl_opt__proc_5_0_i47,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i47);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_liveness__rl_liveness_4_0),
		mercury__rl_opt__proc_5_0_i48,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i48);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r5 = r1;
	r6 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("30", 2);
	r4 = (Word) MR_string_const("liveness", 8);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i49,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i49);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i50,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i50);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__rl_opt__proc_5_0_i51);
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("% Optimizing sorting and indexing in ", 37);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i53,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i53);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i54,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i54);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i55,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i55);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_sort__proc_4_0),
		mercury__rl_opt__proc_5_0_i56,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i56);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i57,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i57);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r6 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("40", 2);
	r4 = (Word) MR_string_const("rl_sort", 7);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i51,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i51);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = (Integer) 214;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__rl_opt__proc_5_0_i60,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i60);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_opt__proc_5_0_i61);
	r1 = MR_stackvar(6);
	r3 = r2;
	r2 = (Word) MR_string_const("% Detecting streams in ", 23);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i63,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i63);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i64,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i64);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("...", 3);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i65,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i65);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__rl_stream__detect_streams_2_0),
		mercury__rl_opt__proc_5_0_i66,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i66);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("done.\n", 6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__rl_opt__proc_5_0_i67,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i67);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r6 = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_string_const("50", 2);
	r4 = (Word) MR_string_const("streams", 7);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__rl_opt__maybe_dump_rl_7_0),
		mercury__rl_opt__proc_5_0_i68,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i68);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__rl_block__get_proc_4_0),
		mercury__rl_opt__proc_5_0_i70,
		STATIC(mercury__rl_opt__proc_5_0));
	}
Define_label(mercury__rl_opt__proc_5_0_i61);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__rl_block__get_proc_4_0),
		mercury__rl_opt__proc_5_0_i70,
		STATIC(mercury__rl_opt__proc_5_0));
Define_label(mercury__rl_opt__proc_5_0_i70);
	update_prof_current_proc(LABEL(mercury__rl_opt__proc_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__io__write_strings_3_0);
Declare_entry(mercury__rl_block__dump_blocks_5_0);

BEGIN_MODULE(rl_opt_module2)
	init_entry(mercury__rl_opt__maybe_dump_rl_7_0);
	init_label(mercury__rl_opt__maybe_dump_rl_7_0_i3);
	init_label(mercury__rl_opt__maybe_dump_rl_7_0_i4);
	init_label(mercury__rl_opt__maybe_dump_rl_7_0_i5);
	init_label(mercury__rl_opt__maybe_dump_rl_7_0_i6);
BEGIN_CODE

/* code for predicate 'maybe_dump_rl'/7 in mode 0 */
Define_static(mercury__rl_opt__maybe_dump_rl_7_0);
	MR_incr_sp_push_msg(5, "rl_opt:maybe_dump_rl/7");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__rl_opt__maybe_dump_rl_7_0_i3);
	r1 = r6;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_opt__maybe_dump_rl_7_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("\n\n%********************************************\n", 48);
	r2 = r6;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__rl_opt__maybe_dump_rl_7_0_i4,
		STATIC(mercury__rl_opt__maybe_dump_rl_7_0));
Define_label(mercury__rl_opt__maybe_dump_rl_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_opt__maybe_dump_rl_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("% ", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("\t", 1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("\t", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_opt__maybe_dump_rl_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_rl_opt__common_5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_strings_3_0),
		mercury__rl_opt__maybe_dump_rl_7_0_i5,
		STATIC(mercury__rl_opt__maybe_dump_rl_7_0));
	}
Define_label(mercury__rl_opt__maybe_dump_rl_7_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_opt__maybe_dump_rl_7_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__rl_block__dump_blocks_5_0),
		mercury__rl_opt__maybe_dump_rl_7_0_i6,
		STATIC(mercury__rl_opt__maybe_dump_rl_7_0));
Define_label(mercury__rl_opt__maybe_dump_rl_7_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_opt__maybe_dump_rl_7_0));
	r1 = (Word) MR_string_const("%********************************************\n", 46);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		STATIC(mercury__rl_opt__maybe_dump_rl_7_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_opt_maybe_bunch_0(void)
{
	rl_opt_module0();
	rl_opt_module1();
	rl_opt_module2();
}

#endif

void mercury__rl_opt__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_opt__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_opt_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
