/*
** Automatically generated from `rl_relops.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__rl_relops__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__rl_relops__subtract__ua0_13_0);
Declare_label(mercury__rl_relops__subtract__ua0_13_0_i2);
Declare_label(mercury__rl_relops__subtract__ua0_13_0_i3);
Declare_label(mercury__rl_relops__subtract__ua0_13_0_i4);
Declare_label(mercury__rl_relops__subtract__ua0_13_0_i5);
Define_extern_entry(mercury__rl_relops__select_and_project_9_0);
Declare_label(mercury__rl_relops__select_and_project_9_0_i2);
Declare_label(mercury__rl_relops__select_and_project_9_0_i3);
Declare_label(mercury__rl_relops__select_and_project_9_0_i4);
Declare_label(mercury__rl_relops__select_and_project_9_0_i8);
Declare_label(mercury__rl_relops__select_and_project_9_0_i7);
Declare_label(mercury__rl_relops__select_and_project_9_0_i11);
Declare_label(mercury__rl_relops__select_and_project_9_0_i12);
Declare_label(mercury__rl_relops__select_and_project_9_0_i15);
Declare_label(mercury__rl_relops__select_and_project_9_0_i16);
Declare_label(mercury__rl_relops__select_and_project_9_0_i17);
Declare_label(mercury__rl_relops__select_and_project_9_0_i13);
Declare_label(mercury__rl_relops__select_and_project_9_0_i19);
Declare_label(mercury__rl_relops__select_and_project_9_0_i20);
Declare_label(mercury__rl_relops__select_and_project_9_0_i6);
Define_extern_entry(mercury__rl_relops__join_12_0);
Declare_label(mercury__rl_relops__join_12_0_i2);
Declare_label(mercury__rl_relops__join_12_0_i5);
Declare_label(mercury__rl_relops__join_12_0_i1003);
Define_extern_entry(mercury__rl_relops__diff_diff_join_14_0);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i2);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i3);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i5);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i7);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i4);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i9);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i10);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i11);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i12);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i13);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i14);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i1015);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i18);
Declare_label(mercury__rl_relops__diff_diff_join_14_0_i16);
Define_extern_entry(mercury__rl_relops__subtract_13_0);
Define_extern_entry(mercury__rl_relops__difference_6_0);
Declare_label(mercury__rl_relops__difference_6_0_i2);
Declare_label(mercury__rl_relops__difference_6_0_i3);
Define_extern_entry(mercury__rl_relops__union_8_0);
Declare_label(mercury__rl_relops__union_8_0_i4);
Declare_label(mercury__rl_relops__union_8_0_i3);
Declare_label(mercury__rl_relops__union_8_0_i7);
Declare_label(mercury__rl_relops__union_8_0_i6);
Declare_label(mercury__rl_relops__union_8_0_i12);
Declare_label(mercury__rl_relops__union_8_0_i11);
Declare_label(mercury__rl_relops__union_8_0_i16);
Declare_label(mercury__rl_relops__union_8_0_i17);
Declare_label(mercury__rl_relops__union_8_0_i14);
Declare_label(mercury__rl_relops__union_8_0_i19);
Declare_label(mercury__rl_relops__union_8_0_i20);
Define_extern_entry(mercury__rl_relops__sort_5_0);
Declare_label(mercury__rl_relops__sort_5_0_i2);
Declare_label(mercury__rl_relops__sort_5_0_i3);
Declare_label(mercury__rl_relops__sort_5_0_i5);
Declare_label(mercury__rl_relops__sort_5_0_i6);
Define_extern_entry(mercury__rl_relops__goal_7_0);
Declare_label(mercury__rl_relops__goal_7_0_i2);
Declare_label(mercury__rl_relops__goal_7_0_i3);
Declare_label(mercury__rl_relops__goal_7_0_i4);
Declare_label(mercury__rl_relops__goal_7_0_i5);
Declare_label(mercury__rl_relops__goal_7_0_i6);
Declare_label(mercury__rl_relops__goal_7_0_i7);
Declare_static(mercury__rl_relops__join_2_14_0);
Declare_label(mercury__rl_relops__join_2_14_0_i3);
Declare_label(mercury__rl_relops__join_2_14_0_i5);
Declare_label(mercury__rl_relops__join_2_14_0_i2);
Declare_label(mercury__rl_relops__join_2_14_0_i8);
Declare_label(mercury__rl_relops__join_2_14_0_i10);
Declare_label(mercury__rl_relops__join_2_14_0_i7);
Declare_label(mercury__rl_relops__join_2_14_0_i13);
Declare_label(mercury__rl_relops__join_2_14_0_i15);
Declare_label(mercury__rl_relops__join_2_14_0_i14);
Declare_label(mercury__rl_relops__join_2_14_0_i18);
Declare_label(mercury__rl_relops__join_2_14_0_i19);
Declare_label(mercury__rl_relops__join_2_14_0_i20);
Declare_label(mercury__rl_relops__join_2_14_0_i16);
Declare_label(mercury__rl_relops__join_2_14_0_i22);
Declare_label(mercury__rl_relops__join_2_14_0_i23);
Declare_label(mercury__rl_relops__join_2_14_0_i24);
Declare_static(mercury__rl_relops__sort_rels_5_0);
Declare_label(mercury__rl_relops__sort_rels_5_0_i4);
Declare_label(mercury__rl_relops__sort_rels_5_0_i5);
Declare_label(mercury__rl_relops__sort_rels_5_0_i3);

static const struct mercury_data_rl_relops__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_relops__common_0;

static const struct mercury_data_rl_relops__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_rl_relops__common_1;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_rl_relops__common_0_struct mercury_data_rl_relops__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_rl_relops__common_1_struct mercury_data_rl_relops__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

Declare_entry(mercury__rl_info__rl_info_get_new_temporary_4_0);
Declare_entry(mercury__rl_info__comment_3_0);

BEGIN_MODULE(rl_relops_module0)
	init_entry(mercury__rl_relops__subtract__ua0_13_0);
	init_label(mercury__rl_relops__subtract__ua0_13_0_i2);
	init_label(mercury__rl_relops__subtract__ua0_13_0_i3);
	init_label(mercury__rl_relops__subtract__ua0_13_0_i4);
	init_label(mercury__rl_relops__subtract__ua0_13_0_i5);
BEGIN_CODE

/* code for predicate 'subtract__ua0'/13 in mode 0 */
Define_static(mercury__rl_relops__subtract__ua0_13_0);
	MR_incr_sp_push_msg(8, "rl_relops:subtract__ua0/13");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__subtract__ua0_13_0, "origin_lost_in_value_number");
	r1 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r5;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r6;
	r5 = r9;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	call_localret(STATIC(mercury__rl_relops__goal_7_0),
		mercury__rl_relops__subtract__ua0_13_0_i2,
		STATIC(mercury__rl_relops__subtract__ua0_13_0));
Define_label(mercury__rl_relops__subtract__ua0_13_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__subtract__ua0_13_0));
	MR_stackvar(7) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__rl_relops__subtract__ua0_13_0, "rl_info:relation_schema/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__subtract__ua0_13_0_i3,
		STATIC(mercury__rl_relops__subtract__ua0_13_0));
Define_label(mercury__rl_relops__subtract__ua0_13_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__subtract__ua0_13_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r4 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(2), (Integer) 5, mercury__rl_relops__subtract__ua0_13_0, "rl:rl_instr/0");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__subtract__ua0_13_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_stackvar(2);
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = r2;
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 1) = r3;
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 2) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__rl_info__comment_3_0),
		mercury__rl_relops__subtract__ua0_13_0_i4,
		STATIC(mercury__rl_relops__subtract__ua0_13_0));
	}
Define_label(mercury__rl_relops__subtract__ua0_13_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_relops__subtract__ua0_13_0));
	r3 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__subtract__ua0_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = r3;
	r6 = r2;
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_relops__select_and_project_9_0),
		mercury__rl_relops__subtract__ua0_13_0_i5,
		STATIC(mercury__rl_relops__subtract__ua0_13_0));
	}
Define_label(mercury__rl_relops__subtract__ua0_13_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__subtract__ua0_13_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__subtract__ua0_13_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__rl_relops__subtract__ua0_13_0, "tree:tree/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_relops__subtract__ua0_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

Declare_entry(mercury__rl_info__rl_info_write_message_4_0);
Declare_entry(mercury__hlds_goal__goal_list_determinism_2_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__rl_info__rl_info_get_proc_info_3_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__map__apply_to_list_3_0);

BEGIN_MODULE(rl_relops_module1)
	init_entry(mercury__rl_relops__select_and_project_9_0);
	init_label(mercury__rl_relops__select_and_project_9_0_i2);
	init_label(mercury__rl_relops__select_and_project_9_0_i3);
	init_label(mercury__rl_relops__select_and_project_9_0_i4);
	init_label(mercury__rl_relops__select_and_project_9_0_i8);
	init_label(mercury__rl_relops__select_and_project_9_0_i7);
	init_label(mercury__rl_relops__select_and_project_9_0_i11);
	init_label(mercury__rl_relops__select_and_project_9_0_i12);
	init_label(mercury__rl_relops__select_and_project_9_0_i15);
	init_label(mercury__rl_relops__select_and_project_9_0_i16);
	init_label(mercury__rl_relops__select_and_project_9_0_i17);
	init_label(mercury__rl_relops__select_and_project_9_0_i13);
	init_label(mercury__rl_relops__select_and_project_9_0_i19);
	init_label(mercury__rl_relops__select_and_project_9_0_i20);
	init_label(mercury__rl_relops__select_and_project_9_0_i6);
BEGIN_CODE

/* code for predicate 'select_and_project'/9 in mode 0 */
Define_entry(mercury__rl_relops__select_and_project_9_0);
	MR_incr_sp_push_msg(9, "rl_relops:select_and_project/9");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	r1 = (Word) MR_string_const("Generating single call select+project\n", 38);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r6;
	MR_stackvar(5) = r4;
	MR_stackvar(6) = r5;
	call_localret(ENTRY(mercury__rl_info__rl_info_write_message_4_0),
		mercury__rl_relops__select_and_project_9_0_i2,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__goal_list_determinism_2_0),
		mercury__rl_relops__select_and_project_9_0_i3,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__rl_relops__select_and_project_9_0_i4,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__rl_relops__select_and_project_9_0_i8,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__select_and_project_9_0_i7);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__rl_relops__select_and_project_9_0_i6);
	r1 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = MR_stackvar(8);
	GOTO_LABEL(mercury__rl_relops__select_and_project_9_0_i11);
Define_label(mercury__rl_relops__select_and_project_9_0_i7);
	r1 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_relops__select_and_project_9_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	r5 = MR_stackvar(8);
Define_label(mercury__rl_relops__select_and_project_9_0_i11);
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__rl_relops__select_and_project_9_0, "rl:rl_goal_inputs/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(STATIC(mercury__rl_relops__goal_7_0),
		mercury__rl_relops__select_and_project_9_0_i12,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__select_and_project_9_0_i13);
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_proc_info_3_0),
		mercury__rl_relops__select_and_project_9_0_i15,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i15);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__rl_relops__select_and_project_9_0_i16,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__rl_relops__select_and_project_9_0_i17,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_relops__select_and_project_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__select_and_project_9_0_i19,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i13);
	MR_stackvar(7) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__rl_relops__select_and_project_9_0, "rl_info:relation_schema/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__select_and_project_9_0_i19,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_info__comment_3_0),
		mercury__rl_relops__select_and_project_9_0_i20,
		ENTRY(mercury__rl_relops__select_and_project_9_0));
Define_label(mercury__rl_relops__select_and_project_9_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_relops__select_and_project_9_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__rl_relops__select_and_project_9_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_relops__select_and_project_9_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_relops__select_and_project_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 6, mercury__rl_relops__select_and_project_9_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__select_and_project_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r6, (Integer) 1) = r3;
	r3 = r4;
	MR_field(MR_mktag(3), r7, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r7, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r7, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(3), r7, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
	}
Define_label(mercury__rl_relops__select_and_project_9_0_i6);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(rl_relops_module2)
	init_entry(mercury__rl_relops__join_12_0);
	init_label(mercury__rl_relops__join_12_0_i2);
	init_label(mercury__rl_relops__join_12_0_i5);
	init_label(mercury__rl_relops__join_12_0_i1003);
BEGIN_CODE

/* code for predicate 'join'/12 in mode 0 */
Define_entry(mercury__rl_relops__join_12_0);
	MR_incr_sp_push_msg(4, "rl_relops:join/12");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r5;
	MR_stackvar(2) = r6;
	MR_stackvar(3) = r7;
	call_localret(STATIC(mercury__rl_relops__join_2_14_0),
		mercury__rl_relops__join_12_0_i2,
		ENTRY(mercury__rl_relops__join_12_0));
Define_label(mercury__rl_relops__join_12_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_12_0));
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__rl_relops__join_12_0_i1003);
	{
	Word MR_tempr1;
	MR_tempr1 = r4;
	r4 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = r3;
	r6 = r5;
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__rl_relops__select_and_project_9_0),
		mercury__rl_relops__join_12_0_i5,
		ENTRY(mercury__rl_relops__join_12_0));
	}
Define_label(mercury__rl_relops__join_12_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_12_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__join_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__rl_relops__join_12_0_i1003);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__join_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(2), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___rl__join_type_0_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0);
Declare_entry(mercury__rl__ascending_sort_spec_2_0);

BEGIN_MODULE(rl_relops_module3)
	init_entry(mercury__rl_relops__diff_diff_join_14_0);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i2);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i3);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i5);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i7);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i4);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i9);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i10);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i11);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i12);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i13);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i14);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i1015);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i18);
	init_label(mercury__rl_relops__diff_diff_join_14_0_i16);
BEGIN_CODE

/* code for predicate 'diff_diff_join'/14 in mode 0 */
Define_entry(mercury__rl_relops__diff_diff_join_14_0);
	MR_incr_sp_push_msg(14, "rl_relops:diff_diff_join/14");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r2 = r4;
	r3 = r5;
	MR_stackvar(3) = r5;
	r4 = r6;
	MR_stackvar(4) = r6;
	r5 = r7;
	MR_stackvar(5) = r7;
	r6 = r8;
	MR_stackvar(6) = r8;
	r7 = r9;
	MR_stackvar(7) = r9;
	r8 = r10;
	r9 = r11;
	MR_stackvar(8) = r10;
	call_localret(STATIC(mercury__rl_relops__join_2_14_0),
		mercury__rl_relops__diff_diff_join_14_0_i2,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_tempr2 = r2;
	r2 = MR_stackvar(2);
	MR_tempr3 = r3;
	r3 = MR_stackvar(3);
	MR_tempr4 = r4;
	r4 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr4;
	MR_stackvar(3) = MR_tempr3;
	MR_stackvar(2) = MR_tempr2;
	MR_stackvar(1) = MR_tempr1;
	r9 = r5;
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	call_localret(STATIC(mercury__rl_relops__join_2_14_0),
		mercury__rl_relops__diff_diff_join_14_0_i3,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
	}
Define_label(mercury__rl_relops__diff_diff_join_14_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(10) = r3;
	MR_stackvar(11) = r4;
	MR_stackvar(12) = r5;
	call_localret(ENTRY(mercury____Unify___rl__join_type_0_0),
		mercury__rl_relops__diff_diff_join_14_0_i5,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__diff_diff_join_14_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__rl_relops__diff_diff_join_14_0_i7,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__diff_diff_join_14_0_i4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(12);
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 1) = r3;
	GOTO_LABEL(mercury__rl_relops__diff_diff_join_14_0_i10);
Define_label(mercury__rl_relops__diff_diff_join_14_0_i4);
	r1 = (Word) MR_string_const("rl_relops__diff_diff_join: different join types", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_relops__diff_diff_join_14_0_i9,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i9);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(12);
Define_label(mercury__rl_relops__diff_diff_join_14_0_i10);
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__diff_diff_join_14_0_i11,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	r3 = MR_stackvar(1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__rl_relops__sort_5_0),
		mercury__rl_relops__diff_diff_join_14_0_i12,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i12);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(9), (Integer) 0);
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(10) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__rl_relops__sort_5_0),
		mercury__rl_relops__diff_diff_join_14_0_i13,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
	}
Define_label(mercury__rl_relops__diff_diff_join_14_0_i13);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	r4 = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_stackvar(10) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(1), MR_stackvar(10), (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r4;
	MR_stackvar(13) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_stackvar(13), (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r2;
	r1 = MR_stackvar(8);
	r2 = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0),
		mercury__rl_relops__diff_diff_join_14_0_i14,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
	}
Define_label(mercury__rl_relops__diff_diff_join_14_0_i14);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__rl__ascending_sort_spec_2_0),
		mercury__rl_relops__diff_diff_join_14_0_i1015,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
Define_label(mercury__rl_relops__diff_diff_join_14_0_i1015);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__rl_relops__diff_diff_join_14_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__rl_relops__diff_diff_join_14_0, "rl:sort_spec/0");
	MR_field(MR_mktag(1), r7, (Integer) 0) = r1;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r3;
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__rl_relops__diff_diff_join_14_0_i16);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(9);
	call_localret(STATIC(mercury__rl_relops__select_and_project_9_0),
		mercury__rl_relops__diff_diff_join_14_0_i18,
		ENTRY(mercury__rl_relops__diff_diff_join_14_0));
	}
Define_label(mercury__rl_relops__diff_diff_join_14_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_relops__diff_diff_join_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__rl_relops__diff_diff_join_14_0_i16);
	r1 = MR_stackvar(1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__diff_diff_join_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_stackvar(9);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_relops_module4)
	init_entry(mercury__rl_relops__subtract_13_0);
BEGIN_CODE

/* code for predicate 'subtract'/13 in mode 0 */
Define_entry(mercury__rl_relops__subtract_13_0);
	r9 = r10;
	tailcall(STATIC(mercury__rl_relops__subtract__ua0_13_0),
		ENTRY(mercury__rl_relops__subtract_13_0));
END_MODULE

Declare_entry(mercury__rl_info__rl_info_get_relation_schema_4_0);

BEGIN_MODULE(rl_relops_module5)
	init_entry(mercury__rl_relops__difference_6_0);
	init_label(mercury__rl_relops__difference_6_0_i2);
	init_label(mercury__rl_relops__difference_6_0_i3);
BEGIN_CODE

/* code for predicate 'difference'/6 in mode 0 */
Define_entry(mercury__rl_relops__difference_6_0);
	MR_incr_sp_push_msg(5, "rl_relops:difference/6");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_relation_schema_4_0),
		mercury__rl_relops__difference_6_0_i2,
		ENTRY(mercury__rl_relops__difference_6_0));
Define_label(mercury__rl_relops__difference_6_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__difference_6_0));
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__rl__ascending_sort_spec_2_0),
		mercury__rl_relops__difference_6_0_i3,
		ENTRY(mercury__rl_relops__difference_6_0));
Define_label(mercury__rl_relops__difference_6_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__difference_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__rl_relops__difference_6_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__rl_relops__difference_6_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__rl_relops__difference_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 5, mercury__rl_relops__difference_6_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r5, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__difference_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_relops__difference_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_relops_module6)
	init_entry(mercury__rl_relops__union_8_0);
	init_label(mercury__rl_relops__union_8_0_i4);
	init_label(mercury__rl_relops__union_8_0_i3);
	init_label(mercury__rl_relops__union_8_0_i7);
	init_label(mercury__rl_relops__union_8_0_i6);
	init_label(mercury__rl_relops__union_8_0_i12);
	init_label(mercury__rl_relops__union_8_0_i11);
	init_label(mercury__rl_relops__union_8_0_i16);
	init_label(mercury__rl_relops__union_8_0_i17);
	init_label(mercury__rl_relops__union_8_0_i14);
	init_label(mercury__rl_relops__union_8_0_i19);
	init_label(mercury__rl_relops__union_8_0_i20);
BEGIN_CODE

/* code for predicate 'union'/8 in mode 0 */
Define_entry(mercury__rl_relops__union_8_0);
	MR_incr_sp_push_msg(5, "rl_relops:union/8");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__union_8_0_i3);
	r1 = (Word) MR_string_const("rl_relops__union: no relations to union", 39);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__rl_relops__union_8_0_i4,
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_relops__union_8_0_i3);
	r6 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__union_8_0_i6);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__rl_relops__union_8_0_i7);
	r1 = r2;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__rl_relops__sort_5_0),
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i7);
	r1 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__rl_relops__union_8_0_i6);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__union_8_0_i12);
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r5;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__union_8_0_i11,
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i12);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = r5;
	MR_stackvar(3) = r3;
Define_label(mercury__rl_relops__union_8_0_i11);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__rl_relops__union_8_0_i14);
	MR_stackvar(1) = r1;
	r3 = MR_stackvar(3);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(STATIC(mercury__rl_relops__sort_5_0),
		mercury__rl_relops__union_8_0_i16,
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i16);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(4) = r2;
	r2 = r3;
	call_localret(STATIC(mercury__rl_relops__sort_rels_5_0),
		mercury__rl_relops__union_8_0_i17,
		ENTRY(mercury__rl_relops__union_8_0));
	}
Define_label(mercury__rl_relops__union_8_0_i17);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	r6 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_relops__union_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	r1 = MR_stackvar(2);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__rl_relops__union_8_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r2 = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r6;
	call_localret(ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0),
		mercury__rl_relops__union_8_0_i19,
		ENTRY(mercury__rl_relops__union_8_0));
	}
Define_label(mercury__rl_relops__union_8_0_i14);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__rl_info__rl_info_relation_schema_to_type_list_4_0),
		mercury__rl_relops__union_8_0_i19,
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__rl__ascending_sort_spec_2_0),
		mercury__rl_relops__union_8_0_i20,
		ENTRY(mercury__rl_relops__union_8_0));
Define_label(mercury__rl_relops__union_8_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_relops__union_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__union_8_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__rl_relops__union_8_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__rl_relops__union_8_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__rl_relops__union_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 4, mercury__rl_relops__union_8_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r7, (Integer) 2) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__union_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__rl_relops__union_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r7, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_relops_module7)
	init_entry(mercury__rl_relops__sort_5_0);
	init_label(mercury__rl_relops__sort_5_0_i2);
	init_label(mercury__rl_relops__sort_5_0_i3);
	init_label(mercury__rl_relops__sort_5_0_i5);
	init_label(mercury__rl_relops__sort_5_0_i6);
BEGIN_CODE

/* code for predicate 'sort'/5 in mode 0 */
Define_entry(mercury__rl_relops__sort_5_0);
	MR_incr_sp_push_msg(4, "rl_relops:sort/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_relation_schema_4_0),
		mercury__rl_relops__sort_5_0_i2,
		ENTRY(mercury__rl_relops__sort_5_0));
Define_label(mercury__rl_relops__sort_5_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__sort_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__sort_5_0_i3);
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__rl_relops__sort_5_0_i3);
	MR_stackvar(2) = r1;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__rl_relops__sort_5_0, "rl_info:relation_schema/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__sort_5_0_i5,
		ENTRY(mercury__rl_relops__sort_5_0));
Define_label(mercury__rl_relops__sort_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__sort_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__rl__ascending_sort_spec_2_0),
		mercury__rl_relops__sort_5_0_i6,
		ENTRY(mercury__rl_relops__sort_5_0));
Define_label(mercury__rl_relops__sort_5_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_relops__sort_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__rl_relops__sort_5_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__rl_relops__sort_5_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__rl_relops__sort_5_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__rl_relops__sort_5_0, "rl:rl_instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__sort_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 3) = r3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
END_MODULE

Declare_entry(mercury__rl_info__rl_info_get_module_info_3_0);
Declare_entry(mercury__rl_info__rl_info_get_pred_proc_id_3_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__rl_key__extract_indexing_5_0);

BEGIN_MODULE(rl_relops_module8)
	init_entry(mercury__rl_relops__goal_7_0);
	init_label(mercury__rl_relops__goal_7_0_i2);
	init_label(mercury__rl_relops__goal_7_0_i3);
	init_label(mercury__rl_relops__goal_7_0_i4);
	init_label(mercury__rl_relops__goal_7_0_i5);
	init_label(mercury__rl_relops__goal_7_0_i6);
	init_label(mercury__rl_relops__goal_7_0_i7);
BEGIN_CODE

/* code for predicate 'goal'/7 in mode 0 */
Define_entry(mercury__rl_relops__goal_7_0);
	MR_incr_sp_push_msg(9, "rl_relops:goal/7");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_module_info_3_0),
		mercury__rl_relops__goal_7_0_i2,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i2);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_pred_proc_id_3_0),
		mercury__rl_relops__goal_7_0_i3,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_proc_info_3_0),
		mercury__rl_relops__goal_7_0_i4,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	MR_stackvar(5) = r2;
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__rl_relops__goal_7_0_i5,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__rl_relops__goal_7_0_i6,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i6);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	r3 = MR_stackvar(6);
	r4 = r1;
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__rl_key__extract_indexing_5_0),
		mercury__rl_relops__goal_7_0_i7,
		ENTRY(mercury__rl_relops__goal_7_0));
Define_label(mercury__rl_relops__goal_7_0_i7);
	update_prof_current_proc(LABEL(mercury__rl_relops__goal_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 8, mercury__rl_relops__goal_7_0, "rl:rl_goal/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_relops__goal_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 7) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(5);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__std_util__semidet_fail_0_0);

BEGIN_MODULE(rl_relops_module9)
	init_entry(mercury__rl_relops__join_2_14_0);
	init_label(mercury__rl_relops__join_2_14_0_i3);
	init_label(mercury__rl_relops__join_2_14_0_i5);
	init_label(mercury__rl_relops__join_2_14_0_i2);
	init_label(mercury__rl_relops__join_2_14_0_i8);
	init_label(mercury__rl_relops__join_2_14_0_i10);
	init_label(mercury__rl_relops__join_2_14_0_i7);
	init_label(mercury__rl_relops__join_2_14_0_i13);
	init_label(mercury__rl_relops__join_2_14_0_i15);
	init_label(mercury__rl_relops__join_2_14_0_i14);
	init_label(mercury__rl_relops__join_2_14_0_i18);
	init_label(mercury__rl_relops__join_2_14_0_i19);
	init_label(mercury__rl_relops__join_2_14_0_i20);
	init_label(mercury__rl_relops__join_2_14_0_i16);
	init_label(mercury__rl_relops__join_2_14_0_i22);
	init_label(mercury__rl_relops__join_2_14_0_i23);
	init_label(mercury__rl_relops__join_2_14_0_i24);
BEGIN_CODE

/* code for predicate 'join_2'/14 in mode 0 */
Define_static(mercury__rl_relops__join_2_14_0);
	MR_incr_sp_push_msg(17, "rl_relops:join_2/14");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(3) = r3;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r3 = r7;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r8;
	MR_stackvar(11) = r9;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__rl_relops__join_2_14_0_i3,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i3);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i2);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__rl_relops__join_2_14_0_i5,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i2);
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	MR_stackvar(10) = MR_stackvar(3);
	r1 = MR_stackvar(11);
	r2 = (Integer) 0;
	MR_stackvar(12) = MR_stackvar(1);
	MR_stackvar(13) = MR_stackvar(2);
	GOTO_LABEL(mercury__rl_relops__join_2_14_0_i13);
Define_label(mercury__rl_relops__join_2_14_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__rl_relops__join_2_14_0_i8,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i8);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i7);
	call_localret(ENTRY(mercury__std_util__semidet_fail_0_0),
		mercury__rl_relops__join_2_14_0_i10,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i10);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	if (!(r1))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i7);
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	MR_stackvar(10) = MR_stackvar(4);
	r1 = MR_stackvar(11);
	r2 = (Integer) 1;
	MR_stackvar(12) = MR_stackvar(2);
	MR_stackvar(13) = MR_stackvar(1);
	GOTO_LABEL(mercury__rl_relops__join_2_14_0_i13);
Define_label(mercury__rl_relops__join_2_14_0_i7);
	MR_stackvar(9) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(10) = MR_stackvar(7);
	r1 = MR_stackvar(11);
	r2 = (Integer) 0;
	MR_stackvar(12) = MR_stackvar(1);
	MR_stackvar(13) = MR_stackvar(2);
Define_label(mercury__rl_relops__join_2_14_0_i13);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i15);
	MR_stackvar(14) = MR_stackvar(3);
	MR_stackvar(15) = MR_stackvar(4);
	GOTO_LABEL(mercury__rl_relops__join_2_14_0_i14);
Define_label(mercury__rl_relops__join_2_14_0_i15);
	MR_stackvar(14) = MR_stackvar(4);
	MR_stackvar(15) = MR_stackvar(3);
Define_label(mercury__rl_relops__join_2_14_0_i14);
	if (((Integer) MR_stackvar(9) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury__rl_relops__join_2_14_0_i16);
	call_localret(ENTRY(mercury__rl_info__rl_info_get_proc_info_3_0),
		mercury__rl_relops__join_2_14_0_i18,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i18);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	MR_stackvar(16) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__rl_relops__join_2_14_0_i19,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i19);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_rl_relops__common_1);
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__rl_relops__join_2_14_0_i20,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i20);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(16);
	r6 = MR_stackvar(14);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__rl_relops__join_2_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(14) = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__join_2_14_0, "rl:rl_goal_inputs/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(15);
	call_localret(STATIC(mercury__rl_relops__goal_7_0),
		mercury__rl_relops__join_2_14_0_i22,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i16);
	r2 = r1;
	r6 = MR_stackvar(14);
	r1 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	MR_stackvar(14) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__rl_relops__join_2_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__join_2_14_0, "rl:rl_goal_inputs/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r6;
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(15);
	call_localret(STATIC(mercury__rl_relops__goal_7_0),
		mercury__rl_relops__join_2_14_0_i22,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i22);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	MR_stackvar(15) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__rl_info__comment_3_0),
		mercury__rl_relops__join_2_14_0_i23,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i23);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	r3 = r1;
	r1 = MR_stackvar(14);
	MR_stackvar(14) = r3;
	call_localret(ENTRY(mercury__rl_info__rl_info_get_new_temporary_4_0),
		mercury__rl_relops__join_2_14_0_i24,
		STATIC(mercury__rl_relops__join_2_14_0));
Define_label(mercury__rl_relops__join_2_14_0_i24);
	update_prof_current_proc(LABEL(mercury__rl_relops__join_2_14_0));
	r5 = r2;
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(10);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__rl_relops__join_2_14_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__rl_relops__join_2_14_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__rl_relops__join_2_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 5, mercury__rl_relops__join_2_14_0, "rl:rl_instr/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__rl_relops__join_2_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r8, (Integer) 4) = MR_stackvar(15);
	MR_field(MR_mktag(1), r8, (Integer) 3) = r2;
	MR_field(MR_mktag(1), r8, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(1), r8, (Integer) 2) = MR_stackvar(13);
	MR_field(MR_mktag(0), r7, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
END_MODULE


BEGIN_MODULE(rl_relops_module10)
	init_entry(mercury__rl_relops__sort_rels_5_0);
	init_label(mercury__rl_relops__sort_rels_5_0_i4);
	init_label(mercury__rl_relops__sort_rels_5_0_i5);
	init_label(mercury__rl_relops__sort_rels_5_0_i3);
BEGIN_CODE

/* code for predicate 'sort_rels'/5 in mode 0 */
Define_static(mercury__rl_relops__sort_rels_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__rl_relops__sort_rels_5_0_i3);
	MR_incr_sp_push_msg(3, "rl_relops:sort_rels/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__rl_relops__sort_5_0),
		mercury__rl_relops__sort_rels_5_0_i4,
		STATIC(mercury__rl_relops__sort_rels_5_0));
Define_label(mercury__rl_relops__sort_rels_5_0_i4);
	update_prof_current_proc(LABEL(mercury__rl_relops__sort_rels_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = r2;
	r2 = r3;
	localcall(mercury__rl_relops__sort_rels_5_0,
		LABEL(mercury__rl_relops__sort_rels_5_0_i5),
		STATIC(mercury__rl_relops__sort_rels_5_0));
	}
Define_label(mercury__rl_relops__sort_rels_5_0_i5);
	update_prof_current_proc(LABEL(mercury__rl_relops__sort_rels_5_0));
	r5 = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__rl_relops__sort_rels_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	r1 = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__rl_relops__sort_rels_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__rl_relops__sort_rels_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__rl_relops_maybe_bunch_0(void)
{
	rl_relops_module0();
	rl_relops_module1();
	rl_relops_module2();
	rl_relops_module3();
	rl_relops_module4();
	rl_relops_module5();
	rl_relops_module6();
	rl_relops_module7();
	rl_relops_module8();
	rl_relops_module9();
	rl_relops_module10();
}

#endif

void mercury__rl_relops__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__rl_relops__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__rl_relops_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
