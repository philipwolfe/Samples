/*
** Automatically generated from `special_pred.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__special_pred__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__special_pred__special_pred_mode_num__ua0_2_0);
Define_extern_entry(mercury__special_pred__special_pred_info_6_0);
Declare_label(mercury__special_pred__special_pred_info_6_0_i4);
Declare_label(mercury__special_pred__special_pred_info_6_0_i3);
Declare_label(mercury__special_pred__special_pred_info_6_0_i6);
Declare_label(mercury__special_pred__special_pred_info_6_0_i7);
Declare_label(mercury__special_pred__special_pred_info_6_0_i8);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1024);
Declare_label(mercury__special_pred__special_pred_info_6_0_i9);
Declare_label(mercury__special_pred__special_pred_info_6_0_i10);
Declare_label(mercury__special_pred__special_pred_info_6_0_i1029);
Declare_label(mercury__special_pred__special_pred_info_6_0_i12);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_0);
Declare_label(mercury__special_pred__special_pred_name_arity_4_0_i3);
Declare_label(mercury__special_pred__special_pred_name_arity_4_0_i4);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_1);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
Declare_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
Define_extern_entry(mercury__special_pred__special_pred_name_arity_4_2);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
Declare_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
Define_extern_entry(mercury__special_pred__special_pred_mode_num_2_0);
Define_extern_entry(mercury__special_pred__special_pred_list_1_0);
Define_extern_entry(mercury__special_pred__special_pred_get_type_3_0);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i4);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i3);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i7);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i6);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i11);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i10);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i14);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i13);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i17);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i16);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i21);
Declare_label(mercury__special_pred__special_pred_get_type_3_0_i1);
Define_extern_entry(mercury__special_pred__special_pred_description_2_0);
Declare_label(mercury__special_pred__special_pred_description_2_0_i3);
Declare_label(mercury__special_pred__special_pred_description_2_0_i4);
Define_extern_entry(mercury____Unify___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Index___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_map_0_0);
Define_extern_entry(mercury____Unify___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Index___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_0_0);
Define_extern_entry(mercury____Unify___special_pred__special_pred_id_0_0);
Declare_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
Define_extern_entry(mercury____Index___special_pred__special_pred_id_0_0);
Define_extern_entry(mercury____Compare___special_pred__special_pred_id_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_0;

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_id_0;

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_map_0;

static const struct mercury_data_special_pred__common_0_struct {
	String f1;
}  mercury_data_special_pred__common_0;

static const struct mercury_data_special_pred__common_1_struct {
	Word * f1;
	Integer f2;
}  mercury_data_special_pred__common_1;

static const struct mercury_data_special_pred__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__common_2;

static const struct mercury_data_special_pred__common_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__common_3;

static const struct mercury_data_special_pred__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__common_4;

static const struct mercury_data_special_pred__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_special_pred__common_5;

static const struct mercury_data_special_pred__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_special_pred__common_6;

static const struct mercury_data_special_pred__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_special_pred__common_7;

static const struct mercury_data_special_pred__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__common_8;

static const struct mercury_data_special_pred__common_9_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_special_pred__common_9;

static const struct mercury_data_special_pred__common_10_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__common_10;

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__type_ctor_functors_special_pred_map_0;

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_special_pred__type_ctor_layout_special_pred_map_0;

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_id_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__type_ctor_functors_special_pred_id_0;

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_id_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_special_pred__type_ctor_layout_special_pred_id_0;

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_special_pred__type_ctor_functors_special_pred_0;

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_special_pred__type_ctor_layout_special_pred_0;

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___special_pred__special_pred_0_0),
	ENTRY(mercury____Index___special_pred__special_pred_0_0),
	ENTRY(mercury____Compare___special_pred__special_pred_0_0),
	(Integer) 6,
	(Word *) &mercury_data_special_pred__type_ctor_functors_special_pred_0,
	(Word *) &mercury_data_special_pred__type_ctor_layout_special_pred_0,
	MR_string_const("special_pred", 12),
	MR_string_const("special_pred", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_id_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___special_pred__special_pred_id_0_0),
	ENTRY(mercury____Index___special_pred__special_pred_id_0_0),
	ENTRY(mercury____Compare___special_pred__special_pred_id_0_0),
	(Integer) 0,
	(Word *) &mercury_data_special_pred__type_ctor_functors_special_pred_id_0,
	(Word *) &mercury_data_special_pred__type_ctor_layout_special_pred_id_0,
	MR_string_const("special_pred", 12),
	MR_string_const("special_pred_id", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_special_pred__type_ctor_info_special_pred_map_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___special_pred__special_pred_map_0_0),
	ENTRY(mercury____Index___special_pred__special_pred_map_0_0),
	ENTRY(mercury____Compare___special_pred__special_pred_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_special_pred__type_ctor_functors_special_pred_map_0,
	(Word *) &mercury_data_special_pred__type_ctor_layout_special_pred_map_0,
	MR_string_const("special_pred", 12),
	MR_string_const("special_pred_map", 16),
	(Integer) 3
};

static const struct mercury_data_special_pred__common_0_struct mercury_data_special_pred__common_0 = {
	MR_string_const("int", 3)
};

static const struct mercury_data_special_pred__common_1_struct mercury_data_special_pred__common_1 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_0),
	(Integer) 0
};

static const struct mercury_data_special_pred__common_2_struct mercury_data_special_pred__common_2 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_special_pred__common_3_struct mercury_data_special_pred__common_3 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_special_pred__common_2)
};

static const struct mercury_data_special_pred__common_4_struct mercury_data_special_pred__common_4 = {
	(Integer) 0,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_special_pred__common_3)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_special_pred__common_5_struct mercury_data_special_pred__common_5 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_special_pred__common_6_struct mercury_data_special_pred__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_special_pred__common_7_struct mercury_data_special_pred__common_7 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6),
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_special_pred__common_8_struct mercury_data_special_pred__common_8 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_7)
};

static const struct mercury_data_special_pred__common_9_struct mercury_data_special_pred__common_9 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("unify", 5),
	MR_string_const("index", 5),
	MR_string_const("compare", 7)
};

static const struct mercury_data_special_pred__common_10_struct mercury_data_special_pred__common_10 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6)
};

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_map_0_struct mercury_data_special_pred__type_ctor_functors_special_pred_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_7)
};

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_map_0_struct mercury_data_special_pred__type_ctor_layout_special_pred_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_8),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_8)
};

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_id_0_struct mercury_data_special_pred__type_ctor_functors_special_pred_id_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_9)
};

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_id_0_struct mercury_data_special_pred__type_ctor_layout_special_pred_id_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_9)
};

static const struct mercury_data_special_pred__type_ctor_functors_special_pred_0_struct mercury_data_special_pred__type_ctor_functors_special_pred_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6)
};

static const struct mercury_data_special_pred__type_ctor_layout_special_pred_0_struct mercury_data_special_pred__type_ctor_layout_special_pred_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_10),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_special_pred__common_10)
};


BEGIN_MODULE(special_pred_module0)
	init_entry(mercury__special_pred__special_pred_mode_num__ua0_2_0);
BEGIN_CODE

/* code for predicate 'special_pred_mode_num__ua0'/2 in mode 0 */
Define_static(mercury__special_pred__special_pred_mode_num__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__mode_util__in_mode_1_0);
Declare_entry(mercury__type_util__construct_type_3_0);
Declare_entry(mercury__mode_util__out_mode_1_0);
Declare_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
Declare_entry(mercury__mode_util__uo_mode_1_0);

BEGIN_MODULE(special_pred_module1)
	init_entry(mercury__special_pred__special_pred_info_6_0);
	init_label(mercury__special_pred__special_pred_info_6_0_i4);
	init_label(mercury__special_pred__special_pred_info_6_0_i3);
	init_label(mercury__special_pred__special_pred_info_6_0_i6);
	init_label(mercury__special_pred__special_pred_info_6_0_i7);
	init_label(mercury__special_pred__special_pred_info_6_0_i8);
	init_label(mercury__special_pred__special_pred_info_6_0_i1024);
	init_label(mercury__special_pred__special_pred_info_6_0_i9);
	init_label(mercury__special_pred__special_pred_info_6_0_i10);
	init_label(mercury__special_pred__special_pred_info_6_0_i1029);
	init_label(mercury__special_pred__special_pred_info_6_0_i12);
BEGIN_CODE

/* code for predicate 'special_pred_info'/6 in mode 0 */
Define_entry(mercury__special_pred__special_pred_info_6_0);
	MR_incr_sp_push_msg(3, "special_pred:special_pred_info/6");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i4,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i4);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = r1;
	r1 = (Word) MR_string_const("__Unify__", 9);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r4 = (Integer) 1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__special_pred__special_pred_info_6_0_i1024);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i6,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i6);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_stackvar(1) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i7,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i7);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__mode_util__out_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i8,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i8);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = r1;
	r1 = (Word) MR_string_const("__Index__", 9);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r4 = (Integer) 0;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__special_pred__special_pred_info_6_0_i1024);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 1) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__special_pred__special_pred_info_6_0_i9,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i9);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_string_const("comparison_result", 17);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__special_pred__special_pred_info_6_0_i10,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i10);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i1029,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i1029);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = r2;
	call_localret(ENTRY(mercury__mode_util__uo_mode_1_0),
		mercury__special_pred__special_pred_info_6_0_i12,
		ENTRY(mercury__special_pred__special_pred_info_6_0));
Define_label(mercury__special_pred__special_pred_info_6_0_i12);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_info_6_0));
	r4 = r1;
	r1 = (Word) MR_string_const("__Compare__", 11);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__special_pred__special_pred_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	r4 = (Integer) 0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module2)
	init_entry(mercury__special_pred__special_pred_name_arity_4_0);
	init_label(mercury__special_pred__special_pred_name_arity_4_0_i3);
	init_label(mercury__special_pred__special_pred_name_arity_4_0_i4);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 0 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_0_i3);
	r1 = (Word) MR_string_const("unify", 5);
	r2 = (Word) MR_string_const("__Unify__", 9);
	r3 = (Integer) 2;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_0_i4);
	r1 = (Word) MR_string_const("index", 5);
	r2 = (Word) MR_string_const("__Index__", 9);
	r3 = (Integer) 2;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_0_i4);
	r1 = (Word) MR_string_const("compare", 7);
	r2 = (Word) MR_string_const("__Compare__", 11);
	r3 = (Integer) 3;
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module3)
	init_entry(mercury__special_pred__special_pred_name_arity_4_1);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
	init_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 1 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("compare", 7)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i3);
	if (((Integer) r2 != (Integer) 3))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = (Integer) 2;
	r3 = (Word) MR_string_const("__Compare__", 11);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("index", 5)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i5);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = (Integer) 1;
	r3 = (Word) MR_string_const("__Index__", 9);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i5);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("unify", 5)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r2 = (Integer) 0;
	r3 = (Word) MR_string_const("__Unify__", 9);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_1_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module4)
	init_entry(mercury__special_pred__special_pred_name_arity_4_2);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
	init_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
BEGIN_CODE

/* code for predicate 'special_pred_name_arity'/4 in mode 2 */
Define_entry(mercury__special_pred__special_pred_name_arity_4_2);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("__Compare__", 11)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i3);
	if (((Integer) r2 != (Integer) 3))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = (Integer) 2;
	r3 = (Word) MR_string_const("compare", 7);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i3);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("__Index__", 9)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i5);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = (Integer) 1;
	r3 = (Word) MR_string_const("index", 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i5);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("__Unify__", 9)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r2 = (Integer) 0;
	r3 = (Word) MR_string_const("unify", 5);
	r1 = TRUE;
	proceed();
Define_label(mercury__special_pred__special_pred_name_arity_4_2_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module5)
	init_entry(mercury__special_pred__special_pred_mode_num_2_0);
BEGIN_CODE

/* code for predicate 'special_pred_mode_num'/2 in mode 0 */
Define_entry(mercury__special_pred__special_pred_mode_num_2_0);
	tailcall(STATIC(mercury__special_pred__special_pred_mode_num__ua0_2_0),
		ENTRY(mercury__special_pred__special_pred_mode_num_2_0));
END_MODULE


BEGIN_MODULE(special_pred_module6)
	init_entry(mercury__special_pred__special_pred_list_1_0);
BEGIN_CODE

/* code for predicate 'special_pred_list'/1 in mode 0 */
Define_entry(mercury__special_pred__special_pred_list_1_0);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_special_pred__common_4);
	proceed();
END_MODULE

Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(special_pred_module7)
	init_entry(mercury__special_pred__special_pred_get_type_3_0);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i4);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i3);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i7);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i6);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i11);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i10);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i14);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i13);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i17);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i16);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i21);
	init_label(mercury__special_pred__special_pred_get_type_3_0_i1);
BEGIN_CODE

/* code for predicate 'special_pred_get_type'/3 in mode 0 */
Define_entry(mercury__special_pred__special_pred_get_type_3_0);
	MR_incr_sp_push_msg(1, "special_pred:special_pred_get_type/3");
	MR_stackvar(1) = (Word) MR_succip;
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("__Compare__", 11)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i3);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i4,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i4);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i3);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("__Index__", 9)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i6);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i7,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i7);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i6);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("__Unify__", 9)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i10);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i11,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i11);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i10);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("compare", 7)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i13);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i14,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i14);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i13);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("index", 5)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i16);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i17,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i17);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i16);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("unify", 5)) != 0))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = r3;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__special_pred__special_pred_get_type_3_0_i21,
		ENTRY(mercury__special_pred__special_pred_get_type_3_0));
Define_label(mercury__special_pred__special_pred_get_type_3_0_i21);
	update_prof_current_proc(LABEL(mercury__special_pred__special_pred_get_type_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__special_pred__special_pred_get_type_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__special_pred__special_pred_get_type_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module8)
	init_entry(mercury__special_pred__special_pred_description_2_0);
	init_label(mercury__special_pred__special_pred_description_2_0_i3);
	init_label(mercury__special_pred__special_pred_description_2_0_i4);
BEGIN_CODE

/* code for predicate 'special_pred_description'/2 in mode 0 */
Define_entry(mercury__special_pred__special_pred_description_2_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__special_pred__special_pred_description_2_0_i3);
	r1 = (Word) MR_string_const("unification predicate", 21);
	proceed();
Define_label(mercury__special_pred__special_pred_description_2_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__special_pred__special_pred_description_2_0_i4);
	r1 = (Word) MR_string_const("indexing predicate", 18);
	proceed();
Define_label(mercury__special_pred__special_pred_description_2_0_i4);
	r1 = (Word) MR_string_const("comparison predicate", 20);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(special_pred_module9)
	init_entry(mercury____Unify___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___special_pred__special_pred_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(special_pred_module10)
	init_entry(mercury____Index___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___special_pred__special_pred_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(special_pred_module11)
	init_entry(mercury____Compare___special_pred__special_pred_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_6);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___special_pred__special_pred_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(special_pred_module12)
	init_entry(mercury____Unify___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_5);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___special_pred__special_pred_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(special_pred_module13)
	init_entry(mercury____Index___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_5);
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___special_pred__special_pred_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(special_pred_module14)
	init_entry(mercury____Compare___special_pred__special_pred_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_special_pred__common_5);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___special_pred__special_pred_0_0));
END_MODULE


BEGIN_MODULE(special_pred_module15)
	init_entry(mercury____Unify___special_pred__special_pred_id_0_0);
	init_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___special_pred__special_pred_id_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___special_pred__special_pred_id_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___special_pred__special_pred_id_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(special_pred_module16)
	init_entry(mercury____Index___special_pred__special_pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___special_pred__special_pred_id_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(special_pred_module17)
	init_entry(mercury____Compare___special_pred__special_pred_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___special_pred__special_pred_id_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___special_pred__special_pred_id_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__special_pred_maybe_bunch_0(void)
{
	special_pred_module0();
	special_pred_module1();
	special_pred_module2();
	special_pred_module3();
	special_pred_module4();
	special_pred_module5();
	special_pred_module6();
	special_pred_module7();
	special_pred_module8();
	special_pred_module9();
	special_pred_module10();
	special_pred_module11();
	special_pred_module12();
	special_pred_module13();
	special_pred_module14();
	special_pred_module15();
	special_pred_module16();
	special_pred_module17();
}

#endif

void mercury__special_pred__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__special_pred__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__special_pred_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_special_pred__type_ctor_info_special_pred_0,
			special_pred__special_pred_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_special_pred__type_ctor_info_special_pred_id_0,
			special_pred__special_pred_id_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_special_pred__type_ctor_info_special_pred_map_0,
			special_pred__special_pred_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
