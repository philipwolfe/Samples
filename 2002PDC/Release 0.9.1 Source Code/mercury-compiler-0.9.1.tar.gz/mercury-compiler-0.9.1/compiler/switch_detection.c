/*
** Automatically generated from `switch_detection.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__switch_detection__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___switch_detection__again_0__ua0_2_0);
Declare_static(mercury__switch_detection__cases_to_switch__ua0_8_0);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i2);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i5);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i7);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i8);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i9);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i11);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i10);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i4);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i14);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i24);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i25);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i26);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i18);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i27);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i29);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i30);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i32);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i34);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i35);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i17);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i39);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i42);
Declare_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i41);
Declare_static(mercury__switch_detection__conj_find_bind_var__ua0_11_0);
Declare_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i3);
Declare_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i4);
Declare_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i5);
Declare_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i7);
Declare_static(mercury__switch_detection__find_bind_var__ua0_11_0);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i4);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i2);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i7);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i5);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i13);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i15);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i17);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i19);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i20);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i11);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i23);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i21);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i25);
Declare_label(mercury__switch_detection__find_bind_var__ua0_11_0_i8);
Declare_static(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i6);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
Declare_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i9);
Define_extern_entry(mercury__switch_detection__detect_switches_4_0);
Declare_label(mercury__switch_detection__detect_switches_4_0_i2);
Define_extern_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
Declare_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
Define_extern_entry(mercury__switch_detection__find_bind_var_8_0);
Declare_label(mercury__switch_detection__find_bind_var_8_0_i2);
Declare_label(mercury__switch_detection__find_bind_var_8_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_preds_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i8);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i13);
Declare_label(mercury__switch_detection__detect_switches_in_preds_5_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_procs_4_0);
Declare_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1001);
Declare_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_procs_4_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_goal_5_0);
Declare_static(mercury__switch_detection__detect_switches_in_goal_1_6_0);
Declare_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
Declare_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_goal_2_6_0);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i8);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i9);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i10);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i20);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i24);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i33);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i34);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1013);
Declare_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
Declare_static(mercury__switch_detection__detect_switches_in_disj_10_0);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i8);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i12);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i13);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i15);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i16);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i17);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i20);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i21);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i29);
Declare_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
Declare_static(mercury__switch_detection__select_best_switch_3_0);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i1002);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i5);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i6);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i4);
Declare_label(mercury__switch_detection__select_best_switch_3_0_i3);
Declare_static(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
Declare_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_cases_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_cases_5_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_par_conj_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i3);
Declare_static(mercury__switch_detection__detect_switches_in_conj_5_0);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i6);
Declare_label(mercury__switch_detection__detect_switches_in_conj_5_0_i3);
Declare_static(mercury__switch_detection__partition_disj_trial_6_0);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i1003);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i7);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
Declare_label(mercury__switch_detection__partition_disj_trial_6_0_i3);
Declare_static(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct_7_0);
Declare_static(mercury__switch_detection__fix_case_list_3_0);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i4);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i5);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i6);
Declare_label(mercury__switch_detection__fix_case_list_3_0_i3);
Define_extern_entry(mercury____Unify___switch_detection__process_unify_2_0);
Define_extern_entry(mercury____Index___switch_detection__process_unify_2_0);
Define_extern_entry(mercury____Compare___switch_detection__process_unify_2_0);
Declare_static(mercury____Unify___switch_detection__cases_0_0);
Declare_static(mercury____Index___switch_detection__cases_0_0);
Declare_static(mercury____Compare___switch_detection__cases_0_0);
Declare_static(mercury____Unify___switch_detection__sorted_case_list_0_0);
Declare_static(mercury____Index___switch_detection__sorted_case_list_0_0);
Declare_static(mercury____Compare___switch_detection__sorted_case_list_0_0);
Declare_static(mercury____Unify___switch_detection__again_0_0);
Declare_label(mercury____Unify___switch_detection__again_0_0_i2);
Declare_label(mercury____Unify___switch_detection__again_0_0_i4);
Declare_label(mercury____Unify___switch_detection__again_0_0_i1);
Declare_static(mercury____Index___switch_detection__again_0_0);
Declare_static(mercury____Compare___switch_detection__again_0_0);
Declare_label(mercury____Compare___switch_detection__again_0_0_i3);
Declare_label(mercury____Compare___switch_detection__again_0_0_i7);
Declare_label(mercury____Compare___switch_detection__again_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_again_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_cases_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_process_unify_2;

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_sorted_case_list_0;

static const struct mercury_data_switch_detection__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_0;

static const struct mercury_data_switch_detection__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_1;

static const struct mercury_data_switch_detection__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_switch_detection__common_2;

static const struct mercury_data_switch_detection__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_3;

static const struct mercury_data_switch_detection__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_switch_detection__common_4;

static const struct mercury_data_switch_detection__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_5;

static const struct mercury_data_switch_detection__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_6;

static const struct mercury_data_switch_detection__common_7_struct {
	Word * f1;
}  mercury_data_switch_detection__common_7;

static const struct mercury_data_switch_detection__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
}  mercury_data_switch_detection__common_8;

static const struct mercury_data_switch_detection__common_9_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_switch_detection__common_9;

static const struct mercury_data_switch_detection__common_10_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_detection__common_10;

static const struct mercury_data_switch_detection__common_11_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__common_11;

static const struct mercury_data_switch_detection__common_12_struct {
	Word * f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Integer f6;
	Integer f7;
	Integer f8;
	Integer f9;
}  mercury_data_switch_detection__common_12;

static const struct mercury_data_switch_detection__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__common_13;

static const struct mercury_data_switch_detection__common_14_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_switch_detection__common_14;

static const struct mercury_data_switch_detection__common_15_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__common_15;

static const struct mercury_data_switch_detection__common_16_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_switch_detection__common_16;

static const struct mercury_data_switch_detection__type_ctor_functors_sorted_case_list_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__type_ctor_functors_sorted_case_list_0;

static const struct mercury_data_switch_detection__type_ctor_layout_sorted_case_list_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_detection__type_ctor_layout_sorted_case_list_0;

static const struct mercury_data_switch_detection__type_ctor_functors_process_unify_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__type_ctor_functors_process_unify_2;

static const struct mercury_data_switch_detection__type_ctor_layout_process_unify_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_detection__type_ctor_layout_process_unify_2;

static const struct mercury_data_switch_detection__type_ctor_functors_cases_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_detection__type_ctor_functors_cases_0;

static const struct mercury_data_switch_detection__type_ctor_layout_cases_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_detection__type_ctor_layout_cases_0;

static const struct mercury_data_switch_detection__type_ctor_functors_again_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_switch_detection__type_ctor_functors_again_0;

static const struct mercury_data_switch_detection__type_ctor_layout_again_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_detection__type_ctor_layout_again_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_again_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___switch_detection__again_0_0),
	STATIC(mercury____Index___switch_detection__again_0_0),
	STATIC(mercury____Compare___switch_detection__again_0_0),
	(Integer) 2,
	(Word *) &mercury_data_switch_detection__type_ctor_functors_again_0,
	(Word *) &mercury_data_switch_detection__type_ctor_layout_again_0,
	MR_string_const("switch_detection", 16),
	MR_string_const("again", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_cases_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___switch_detection__cases_0_0),
	STATIC(mercury____Index___switch_detection__cases_0_0),
	STATIC(mercury____Compare___switch_detection__cases_0_0),
	(Integer) 6,
	(Word *) &mercury_data_switch_detection__type_ctor_functors_cases_0,
	(Word *) &mercury_data_switch_detection__type_ctor_layout_cases_0,
	MR_string_const("switch_detection", 16),
	MR_string_const("cases", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_process_unify_2 = {
	(Integer) 2,
	ENTRY(mercury____Unify___switch_detection__process_unify_2_0),
	ENTRY(mercury____Index___switch_detection__process_unify_2_0),
	ENTRY(mercury____Compare___switch_detection__process_unify_2_0),
	(Integer) 6,
	(Word *) &mercury_data_switch_detection__type_ctor_functors_process_unify_2,
	(Word *) &mercury_data_switch_detection__type_ctor_layout_process_unify_2,
	MR_string_const("switch_detection", 16),
	MR_string_const("process_unify", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_switch_detection__type_ctor_info_sorted_case_list_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___switch_detection__sorted_case_list_0_0),
	STATIC(mercury____Index___switch_detection__sorted_case_list_0_0),
	STATIC(mercury____Compare___switch_detection__sorted_case_list_0_0),
	(Integer) 6,
	(Word *) &mercury_data_switch_detection__type_ctor_functors_sorted_case_list_0,
	(Word *) &mercury_data_switch_detection__type_ctor_layout_sorted_case_list_0,
	MR_string_const("switch_detection", 16),
	MR_string_const("sorted_case_list", 16),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_switch_detection__common_0_struct mercury_data_switch_detection__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_switch_detection__common_1_struct mercury_data_switch_detection__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_switch_detection__common_2_struct mercury_data_switch_detection__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_switch_detection__common_3_struct mercury_data_switch_detection__common_3 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_switch_detection__common_4_struct mercury_data_switch_detection__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_switch_detection__common_5_struct mercury_data_switch_detection__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_switch_detection__common_6_struct mercury_data_switch_detection__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_unit_0;
static const struct mercury_data_switch_detection__common_7_struct mercury_data_switch_detection__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_unit_0
};

static const struct mercury_data_switch_detection__common_8_struct mercury_data_switch_detection__common_8 = {
	(Integer) 0,
	MR_string_const("switch_detection", 16),
	MR_string_const("switch_detection", 16),
	MR_string_const("find_bind_var_for_switch_in_deconstruct", 39),
	7,
	0,
	0,
	7,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_6),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_7)
};

static const struct mercury_data_switch_detection__common_9_struct mercury_data_switch_detection__common_9 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_8),
	STATIC(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct_7_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_case_0;
static const struct mercury_data_switch_detection__common_10_struct mercury_data_switch_detection__common_10 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_case_0
};

static const struct mercury_data_switch_detection__common_11_struct mercury_data_switch_detection__common_11 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_10)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_pred_0;
static const struct mercury_data_switch_detection__common_12_struct mercury_data_switch_detection__common_12 = {
	(Word *) &mercury_data___type_ctor_info_pred_0,
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5),
	(Integer) 1,
	(Integer) 1,
	(Integer) 2,
	(Integer) 2
};

static const struct mercury_data_switch_detection__common_13_struct mercury_data_switch_detection__common_13 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_12)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_switch_detection__common_14_struct mercury_data_switch_detection__common_14 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5)
};

static const struct mercury_data_switch_detection__common_15_struct mercury_data_switch_detection__common_15 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_14)
};

static const struct mercury_data_switch_detection__common_16_struct mercury_data_switch_detection__common_16 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_10),
	MR_string_const("again", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_switch_detection__type_ctor_functors_sorted_case_list_0_struct mercury_data_switch_detection__type_ctor_functors_sorted_case_list_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_10)
};

static const struct mercury_data_switch_detection__type_ctor_layout_sorted_case_list_0_struct mercury_data_switch_detection__type_ctor_layout_sorted_case_list_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_11)
};

static const struct mercury_data_switch_detection__type_ctor_functors_process_unify_2_struct mercury_data_switch_detection__type_ctor_functors_process_unify_2 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_12)
};

static const struct mercury_data_switch_detection__type_ctor_layout_process_unify_2_struct mercury_data_switch_detection__type_ctor_layout_process_unify_2 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_13)
};

static const struct mercury_data_switch_detection__type_ctor_functors_cases_0_struct mercury_data_switch_detection__type_ctor_functors_cases_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_14)
};

static const struct mercury_data_switch_detection__type_ctor_layout_cases_0_struct mercury_data_switch_detection__type_ctor_layout_cases_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_detection__common_15)
};

static const struct mercury_data_switch_detection__type_ctor_functors_again_0_struct mercury_data_switch_detection__type_ctor_functors_again_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_16)
};

static const struct mercury_data_switch_detection__type_ctor_layout_again_0_struct mercury_data_switch_detection__type_ctor_layout_again_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_switch_detection__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(switch_detection_module0)
	init_entry(mercury____Index___switch_detection__again_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___switch_detection__again_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___switch_detection__again_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__inst_match__inst_is_bound_to_functors_3_0);
Declare_entry(mercury__mode_util__functors_to_cons_ids_2_0);
Declare_entry(mercury__list__sort_2_0);
Declare_entry(mercury__det_util__delete_unreachable_cases_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_inst__type_ctor_info_bound_inst_0;
Declare_entry(mercury__list__same_length_2_2);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__char__max_char_value_1_0);
Declare_entry(mercury__char__min_char_value_1_0);
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;
Declare_entry(mercury__map__keys_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(switch_detection_module1)
	init_entry(mercury__switch_detection__cases_to_switch__ua0_8_0);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i2);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i5);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i7);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i8);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i9);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i11);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i10);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i4);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i14);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i24);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i25);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i26);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i18);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i27);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i29);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i30);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i32);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i34);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i35);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i17);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i39);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i42);
	init_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i41);
BEGIN_CODE

/* code for predicate 'cases_to_switch__ua0'/8 in mode 0 */
Define_static(mercury__switch_detection__cases_to_switch__ua0_8_0);
	MR_incr_sp_push_msg(9, "switch_detection:cases_to_switch__ua0/8");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i2,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_match__inst_is_bound_to_functors_3_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i5,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i4);
	MR_stackvar(7) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_util__functors_to_cons_ids_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i7,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	call_localret(ENTRY(mercury__list__sort_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i8,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__det_util__delete_unreachable_cases_3_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i9,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r3 = MR_stackvar(7);
	r4 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_inst__type_ctor_info_bound_inst_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i11,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i10);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r1 = MR_stackvar(7);
	MR_stackvar(8) = (Integer) 1;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i39,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i10);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r1 = MR_stackvar(7);
	MR_stackvar(8) = (Integer) 0;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i39,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i14,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i14);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("character", 9)) != 0))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	MR_stackvar(7) = MR_stackvar(1);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__char__max_char_value_1_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i24,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i24);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__char__min_char_value_1_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i25,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i25);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	MR_stackvar(8) = (((Integer) MR_stackvar(8) - (Integer) r1) + (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i26,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i26);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if ((MR_stackvar(8) != r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i18);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r1 = MR_stackvar(7);
	GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i17);
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i18);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_stackvar(7);
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i19);
	MR_stackvar(7) = MR_stackvar(1);
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i27,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	r1 = MR_stackvar(6);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i29,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i29);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i30,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i30);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i32,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i32);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i34,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i34);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__same_length_2_2),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i35,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i35);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r1 = MR_stackvar(7);
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i17);
	MR_stackvar(8) = (Integer) 1;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i39,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i15);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_stackvar(1) = r1;
	MR_stackvar(8) = (Integer) 0;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i39,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i39);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0_i41);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__cases_to_switch__ua0_8_0_i42,
		STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0));
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i42);
	update_prof_current_proc(LABEL(mercury__switch_detection__cases_to_switch__ua0_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__switch_detection__cases_to_switch__ua0_8_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__switch_detection__cases_to_switch__ua0_8_0_i41);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__switch_detection__cases_to_switch__ua0_8_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module2)
	init_entry(mercury__switch_detection__conj_find_bind_var__ua0_11_0);
	init_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i3);
	init_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i4);
	init_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i5);
	init_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i7);
BEGIN_CODE

/* code for predicate 'conj_find_bind_var__ua0'/11 in mode 0 */
Define_static(mercury__switch_detection__conj_find_bind_var__ua0_11_0);
	MR_incr_sp_push_msg(4, "switch_detection:conj_find_bind_var__ua0/11");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i3);
	r2 = r4;
	r3 = r5;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r6;
	r5 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__switch_detection__find_bind_var__ua0_11_0),
		mercury__switch_detection__conj_find_bind_var__ua0_11_0_i4,
		STATIC(mercury__switch_detection__conj_find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__conj_find_bind_var__ua0_11_0));
	if (((Integer) r5 != (Integer) 0))
		GOTO_LABEL(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__switch_detection__conj_find_bind_var__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	r5 = (Integer) 0;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i5);
	r6 = r4;
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r2;
	r5 = r3;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	localcall(mercury__switch_detection__conj_find_bind_var__ua0_11_0,
		LABEL(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i7),
		STATIC(mercury__switch_detection__conj_find_bind_var__ua0_11_0));
	}
Define_label(mercury__switch_detection__conj_find_bind_var__ua0_11_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__conj_find_bind_var__ua0_11_0));
	r6 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__conj_find_bind_var__ua0_11_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__term__apply_rec_substitution_3_0);
Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury__do_call_closure);
Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
Declare_entry(mercury__det_util__interpret_unify_4_0);

BEGIN_MODULE(switch_detection_module3)
	init_entry(mercury__switch_detection__find_bind_var__ua0_11_0);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i4);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i2);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i7);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i5);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i13);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i15);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i17);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i19);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i20);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i11);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i23);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i21);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i25);
	init_label(mercury__switch_detection__find_bind_var__ua0_11_0_i8);
BEGIN_CODE

/* code for predicate 'find_bind_var__ua0'/11 in mode 0 */
Define_static(mercury__switch_detection__find_bind_var__ua0_11_0);
	r7 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r8 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r8) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r8, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i2);
	MR_incr_sp_push_msg(11, "switch_detection:find_bind_var__ua0/11");
	MR_stackvar(11) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(3), r8, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	MR_stackvar(7) = r7;
	localcall(mercury__switch_detection__find_bind_var__ua0_11_0,
		LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i4),
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	r6 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__switch_detection__find_bind_var__ua0_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__switch_detection__find_bind_var__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i2);
	if ((MR_tag(r8) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i5);
	MR_incr_sp_push_msg(11, "switch_detection:find_bind_var__ua0/11");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(7) = r7;
	r3 = MR_const_field(MR_mktag(0), r8, (Integer) 0);
	call_localret(STATIC(mercury__switch_detection__conj_find_bind_var__ua0_11_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i7,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	r6 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__switch_detection__find_bind_var__ua0_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__switch_detection__find_bind_var__ua0_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r6;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i5);
	if ((MR_tag(r8) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i8);
	if (((Integer) MR_const_field(MR_mktag(3), r8, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i8);
	MR_incr_sp_push_msg(11, "switch_detection:find_bind_var__ua0/11");
	MR_stackvar(11) = (Word) MR_succip;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(3), r8, (Integer) 4);
	r9 = MR_const_field(MR_mktag(3), r8, (Integer) 2);
	r10 = MR_const_field(MR_mktag(3), r8, (Integer) 1);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i11);
	r11 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(10) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	MR_stackvar(8) = r10;
	MR_stackvar(9) = r9;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__switch_detection__find_bind_var__ua0_11_0, "origin_lost_in_value_number");
	r3 = r4;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r11;
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i13,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
	}
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
	r4 = MR_stackvar(10);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__switch_detection__find_bind_var__ua0_11_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i15,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i17,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i17);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r1 = MR_stackvar(2);
	r2 = (Integer) 4;
	r3 = (Integer) 3;
	call_localret(ENTRY(mercury__do_call_closure),
		mercury__switch_detection__find_bind_var__ua0_11_0_i19,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i19);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i20,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
	r5 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i10);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r10 = MR_stackvar(8);
	r9 = MR_stackvar(9);
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i11);
	MR_stackvar(1) = r3;
	r1 = r10;
	r2 = r9;
	r3 = r4;
	MR_stackvar(2) = r5;
	MR_stackvar(4) = r4;
	MR_stackvar(7) = r6;
	call_localret(ENTRY(mercury__det_util__interpret_unify_4_0),
		mercury__switch_detection__find_bind_var__ua0_11_0_i23,
		STATIC(mercury__switch_detection__find_bind_var__ua0_11_0));
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i23);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var__ua0_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i21);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
	GOTO_LABEL(mercury__switch_detection__find_bind_var__ua0_11_0_i25);
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i21);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i25);
	r5 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__switch_detection__find_bind_var__ua0_11_0_i8);
	r1 = r3;
	r2 = r4;
	r3 = r5;
	r4 = r6;
	r5 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(switch_detection_module4)
	init_entry(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0);
	init_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i6);
	init_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	init_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i9);
BEGIN_CODE

/* code for predicate 'find_bind_var_for_switch_in_deconstruct__ua0'/7 in mode 0 */
Define_static(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0);
	MR_incr_sp_push_msg(9, "switch_detection:find_bind_var_for_switch_in_deconstruct__ua0/7");
	MR_stackvar(9) = (Word) MR_succip;
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	MR_tempr3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 4);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	r2 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 5);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 3);
	r3 = MR_const_field(MR_mktag(1), MR_tempr3, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i6,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0));
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 6, mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r3, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), r3, (Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 5, mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = (Integer) 1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), r3, (Integer) 4) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	GOTO_LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i9);
	}
Define_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i3);
	r1 = (Word) MR_string_const("find_bind_var_for_switch_in_deconstruct", 39);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i9,
		STATIC(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0));
Define_label(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0));
	r3 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_predids_2_0);

BEGIN_MODULE(switch_detection_module5)
	init_entry(mercury__switch_detection__detect_switches_4_0);
	init_label(mercury__switch_detection__detect_switches_4_0_i2);
BEGIN_CODE

/* code for predicate 'detect_switches'/4 in mode 0 */
Define_entry(mercury__switch_detection__detect_switches_4_0);
	MR_incr_sp_push_msg(3, "switch_detection:detect_switches/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__switch_detection__detect_switches_4_0_i2,
		ENTRY(mercury__switch_detection__detect_switches_4_0));
Define_label(mercury__switch_detection__detect_switches_4_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_4_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_preds_5_0),
		ENTRY(mercury__switch_detection__detect_switches_4_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_get_initial_instmap_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(switch_detection_module6)
	init_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
	init_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
BEGIN_CODE

/* code for predicate 'detect_switches_in_proc'/4 in mode 0 */
Define_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
	MR_incr_sp_push_msg(10, "switch_detection:detect_switches_in_proc/4");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i2,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r3 = r1;
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i3,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i4,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i5,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i6,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i7,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_initial_instmap_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i8,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i9,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i10,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i11,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i12,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__switch_detection__detect_switches_in_proc_4_0_i13,
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
Define_label(mercury__switch_detection__detect_switches_in_proc_4_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_proc_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0));
END_MODULE


BEGIN_MODULE(switch_detection_module7)
	init_entry(mercury__switch_detection__find_bind_var_8_0);
	init_label(mercury__switch_detection__find_bind_var_8_0_i2);
	init_label(mercury__switch_detection__find_bind_var_8_0_i3);
BEGIN_CODE

/* code for predicate 'find_bind_var'/8 in mode 0 */
Define_entry(mercury__switch_detection__find_bind_var_8_0);
	MR_incr_sp_push_msg(6, "switch_detection:find_bind_var/8");
	MR_stackvar(6) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_3);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__find_bind_var_8_0_i2,
		ENTRY(mercury__switch_detection__find_bind_var_8_0));
Define_label(mercury__switch_detection__find_bind_var_8_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_8_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	call_localret(STATIC(mercury__switch_detection__find_bind_var__ua0_11_0),
		mercury__switch_detection__find_bind_var_8_0_i3,
		ENTRY(mercury__switch_detection__find_bind_var_8_0));
Define_label(mercury__switch_detection__find_bind_var_8_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_detection__find_bind_var_8_0));
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_non_imported_procids_2_0);
Declare_entry(mercury__passes_aux__write_pred_progress_message_5_0);

BEGIN_MODULE(switch_detection_module8)
	init_entry(mercury__switch_detection__detect_switches_in_preds_5_0);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i8);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i13);
	init_label(mercury__switch_detection__detect_switches_in_preds_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_preds'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_preds_5_0);
	MR_incr_sp_push_msg(7, "switch_detection:detect_switches_in_preds/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_preds_5_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i5,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_non_imported_procids_2_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i6,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_preds_5_0_i8);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_string_const("% Detecting switches in ", 24);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__passes_aux__write_pred_progress_message_5_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i11,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_procs_4_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i13,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i8);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_stackvar(5) = MR_stackvar(2);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_procs_4_0),
		mercury__switch_detection__detect_switches_in_preds_5_0_i13,
		STATIC(mercury__switch_detection__detect_switches_in_preds_5_0));
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_preds_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_preds_5_0_i1002);
Define_label(mercury__switch_detection__detect_switches_in_preds_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module9)
	init_entry(mercury__switch_detection__detect_switches_in_procs_4_0);
	init_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1001);
	init_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_procs_4_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_procs'/4 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_procs_4_0);
	MR_incr_sp_push_msg(3, "switch_detection:detect_switches_in_procs/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__switch_detection__detect_switches_in_procs_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_procs_4_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_proc_4_0),
		mercury__switch_detection__detect_switches_in_procs_4_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_procs_4_0));
Define_label(mercury__switch_detection__detect_switches_in_procs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_procs_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_procs_4_0_i1001);
Define_label(mercury__switch_detection__detect_switches_in_procs_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module10)
	init_entry(mercury__switch_detection__detect_switches_in_goal_5_0);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_5_0);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		STATIC(mercury__switch_detection__detect_switches_in_goal_5_0));
END_MODULE

Declare_entry(mercury__det_util__update_instmap_3_0);

BEGIN_MODULE(switch_detection_module11)
	init_entry(mercury__switch_detection__detect_switches_in_goal_1_6_0);
	init_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
	init_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal_1'/6 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_1_6_0);
	MR_incr_sp_push_msg(4, "switch_detection:detect_switches_in_goal_1/6");
	MR_stackvar(4) = (Word) MR_succip;
	r5 = r4;
	r4 = r3;
	r3 = r2;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = r2;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0),
		mercury__switch_detection__detect_switches_in_goal_1_6_0_i2,
		STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_1_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__switch_detection__detect_switches_in_goal_1_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(3);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__switch_detection__detect_switches_in_goal_1_6_0_i3,
		STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_1_6_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_1_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__instmap__pre_lambda_update_5_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(switch_detection_module12)
	init_entry(mercury__switch_detection__detect_switches_in_goal_2_6_0);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i8);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i9);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i10);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i20);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i24);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i33);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i34);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1013);
	init_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
BEGIN_CODE

/* code for predicate 'detect_switches_in_goal_2'/6 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_goal_2_6_0);
	MR_incr_sp_push_msg(15, "switch_detection:detect_switches_in_goal_2/6");
	MR_stackvar(15) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i4) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1013) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1013) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i8));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i4);
	r2 = r3;
	r3 = r4;
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_conj_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i5,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i9) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i24) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i33) AND
		LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i9);
	r2 = r3;
	r3 = r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r4 = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_cases_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i10,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i11);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(2), r2, (Integer) 5);
	MR_stackvar(3) = r4;
	r4 = r3;
	r3 = MR_tempr1;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(2), r2, (Integer) 2);
	MR_stackvar(10) = MR_const_field(MR_mktag(2), r2, (Integer) 3);
	MR_stackvar(12) = MR_tempr1;
	MR_stackvar(13) = MR_const_field(MR_mktag(2), r2, (Integer) 6);
	MR_stackvar(14) = MR_const_field(MR_mktag(2), r2, (Integer) 7);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 4);
	MR_stackvar(11) = r2;
	r1 = r5;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__instmap__pre_lambda_update_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i14,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i14);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i15,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 6, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 8, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:unify_rhs/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(2), r3, (Integer) 2) = MR_stackvar(9);
	MR_field(MR_mktag(2), r3, (Integer) 3) = MR_stackvar(10);
	MR_field(MR_mktag(2), r3, (Integer) 4) = MR_stackvar(11);
	MR_field(MR_mktag(2), r3, (Integer) 5) = MR_stackvar(12);
	MR_field(MR_mktag(2), r3, (Integer) 6) = MR_stackvar(13);
	MR_field(MR_mktag(2), r3, (Integer) 7) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i17);
	r6 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r7 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r7 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r1, (Integer) 2) = r6;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i18);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r6;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i20,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i21,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i21);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	r7 = r1;
	r8 = MR_stackvar(4);
	r9 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__switch_detection__detect_switches_in_disj_10_0),
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i24);
	r2 = r3;
	r3 = r4;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i25,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i25);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i26);
	r2 = r3;
	r3 = r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r4 = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i27,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i28);
	r2 = r3;
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(3) = r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r4 = r5;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i29,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i29);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i30,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i30);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i31,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i31);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 6, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 4) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i33);
	r2 = r3;
	r3 = r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = r5;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_par_conj_5_0),
		mercury__switch_detection__detect_switches_in_goal_2_6_0_i34,
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i34);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_goal_2_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__switch_detection__detect_switches_in_goal_2_6_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i35);
	r1 = (Word) MR_string_const("detect_switches_in_goal_2: unexpected bi_implication", 52);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0));
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i1013);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_goal_2_6_0_i2);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_to_disj_list_2_0);
Declare_entry(mercury__inst_match__inst_is_bound_2_0);
Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(switch_detection_module13)
	init_entry(mercury__switch_detection__detect_switches_in_disj_10_0);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i8);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i12);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i13);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i15);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i16);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i17);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i20);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i21);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i29);
	init_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
BEGIN_CODE

/* code for predicate 'detect_switches_in_disj'/10 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_disj_10_0);
	MR_incr_sp_push_msg(12, "switch_detection:detect_switches_in_disj/10");
	MR_stackvar(12) = (Word) MR_succip;
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	if (((Integer) r9 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	r1 = MR_const_field(MR_mktag(1), r9, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r9, (Integer) 0);
	call_localret(STATIC(mercury__switch_detection__select_best_switch_3_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i6,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i7,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r7 = MR_stackvar(6);
	r1 = r7;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r8 = MR_stackvar(7);
	r9 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__switch_detection__detect_switches_in_disj_10_0,
		LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i8),
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__switch_detection__detect_switches_in_disj_10_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_goal__goal_to_disj_list_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i9,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__switch_detection__detect_switches_in_disj_10_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_switches_in_disj_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__switch_detection__detect_switches_in_disj_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i5);
	r1 = r2;
	MR_stackvar(3) = r4;
	r2 = r5;
	r3 = r6;
	r4 = r8;
	call_localret(STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i27,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r2 = MR_tempr1;
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i12,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__inst_match__inst_is_bound_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i13,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i15,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__switch_detection__partition_disj_trial_6_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i16,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i16);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r3 = r2;
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i17,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i17);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__switch_detection__fix_case_list_3_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i20,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	if (((Integer) MR_stackvar(11) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i21);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	tailcall(STATIC(mercury__switch_detection__cases_to_switch__ua0_8_0),
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i23);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(7);
	call_localret(STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0),
		mercury__switch_detection__detect_switches_in_disj_10_0_i27,
		STATIC(mercury__switch_detection__detect_switches_in_disj_10_0));
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_disj_10_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__switch_detection__detect_switches_in_disj_10_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i21);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i29);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i29);
	r10 = r1;
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_switches_in_disj_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__switch_detection__detect_switches_in_disj_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r9, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r10;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
	}
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i29);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r1 = MR_stackvar(10);
	r9 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
Define_label(mercury__switch_detection__detect_switches_in_disj_10_0_i11);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(12);
	GOTO_LABEL(mercury__switch_detection__detect_switches_in_disj_10_0_i1009);
END_MODULE


BEGIN_MODULE(switch_detection_module14)
	init_entry(mercury__switch_detection__select_best_switch_3_0);
	init_label(mercury__switch_detection__select_best_switch_3_0_i1002);
	init_label(mercury__switch_detection__select_best_switch_3_0_i5);
	init_label(mercury__switch_detection__select_best_switch_3_0_i6);
	init_label(mercury__switch_detection__select_best_switch_3_0_i4);
	init_label(mercury__switch_detection__select_best_switch_3_0_i3);
BEGIN_CODE

/* code for predicate 'select_best_switch'/3 in mode 0 */
Define_static(mercury__switch_detection__select_best_switch_3_0);
	MR_incr_sp_push_msg(5, "switch_detection:select_best_switch/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__switch_detection__select_best_switch_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__select_best_switch_3_0_i5,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
Define_label(mercury__switch_detection__select_best_switch_3_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__select_best_switch_3_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_detection__select_best_switch_3_0_i6,
		STATIC(mercury__switch_detection__select_best_switch_3_0));
Define_label(mercury__switch_detection__select_best_switch_3_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__select_best_switch_3_0));
	if (((Integer) MR_stackvar(4) >= (Integer) r1))
		GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i1002);
Define_label(mercury__switch_detection__select_best_switch_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__switch_detection__select_best_switch_3_0_i1002);
Define_label(mercury__switch_detection__select_best_switch_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module15)
	init_entry(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
	init_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_sub_switches_in_disj'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_sub_switches_in_disj_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i3);
	MR_incr_sp_push_msg(5, "switch_detection:detect_sub_switches_in_disj/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4,
		STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	localcall(mercury__switch_detection__detect_sub_switches_in_disj_5_0,
		LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5),
		STATIC(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_sub_switches_in_disj_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_sub_switches_in_disj_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__switch_detection__detect_sub_switches_in_disj_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module16)
	init_entry(mercury__switch_detection__detect_switches_in_cases_5_0);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_cases_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_cases'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_cases_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_cases_5_0_i3);
	MR_incr_sp_push_msg(6, "switch_detection:detect_switches_in_cases/5");
	MR_stackvar(6) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_cases_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_cases_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_cases_5_0));
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__switch_detection__detect_switches_in_cases_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	localcall(mercury__switch_detection__detect_switches_in_cases_5_0,
		LABEL(mercury__switch_detection__detect_switches_in_cases_5_0_i5),
		STATIC(mercury__switch_detection__detect_switches_in_cases_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_cases_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_switches_in_cases_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_cases_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module17)
	init_entry(mercury__switch_detection__detect_switches_in_par_conj_5_0);
	init_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_par_conj'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_par_conj_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_par_conj_5_0_i3);
	MR_incr_sp_push_msg(5, "switch_detection:detect_switches_in_par_conj/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_1_6_0),
		mercury__switch_detection__detect_switches_in_par_conj_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_par_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_par_conj_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	localcall(mercury__switch_detection__detect_switches_in_par_conj_5_0,
		LABEL(mercury__switch_detection__detect_switches_in_par_conj_5_0_i5),
		STATIC(mercury__switch_detection__detect_switches_in_par_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_par_conj_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_switches_in_par_conj_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_par_conj_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module18)
	init_entry(mercury__switch_detection__detect_switches_in_conj_5_0);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i6);
	init_label(mercury__switch_detection__detect_switches_in_conj_5_0_i3);
BEGIN_CODE

/* code for predicate 'detect_switches_in_conj'/5 in mode 0 */
Define_static(mercury__switch_detection__detect_switches_in_conj_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__detect_switches_in_conj_5_0_i3);
	MR_incr_sp_push_msg(7, "switch_detection:detect_switches_in_conj/5");
	MR_stackvar(7) = (Word) MR_succip;
	r5 = r4;
	MR_stackvar(3) = r4;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = r2;
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__switch_detection__detect_switches_in_goal_2_6_0),
		mercury__switch_detection__detect_switches_in_conj_5_0_i4,
		STATIC(mercury__switch_detection__detect_switches_in_conj_5_0));
	}
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_conj_5_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__switch_detection__detect_switches_in_conj_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(6);
	call_localret(ENTRY(mercury__det_util__update_instmap_3_0),
		mercury__switch_detection__detect_switches_in_conj_5_0_i5,
		STATIC(mercury__switch_detection__detect_switches_in_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_conj_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	localcall(mercury__switch_detection__detect_switches_in_conj_5_0,
		LABEL(mercury__switch_detection__detect_switches_in_conj_5_0_i6),
		STATIC(mercury__switch_detection__detect_switches_in_conj_5_0));
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__detect_switches_in_conj_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__detect_switches_in_conj_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__switch_detection__detect_switches_in_conj_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(switch_detection_module19)
	init_entry(mercury__switch_detection__partition_disj_trial_6_0);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i1003);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i7);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
	init_label(mercury__switch_detection__partition_disj_trial_6_0_i3);
BEGIN_CODE

/* code for predicate 'partition_disj_trial'/6 in mode 0 */
Define_static(mercury__switch_detection__partition_disj_trial_6_0);
	MR_incr_sp_push_msg(7, "switch_detection:partition_disj_trial/6");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__switch_detection__partition_disj_trial_6_0_i4,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_9);
	r3 = MR_stackvar(4);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Integer) 0;
	call_localret(STATIC(mercury__switch_detection__find_bind_var__ua0_11_0),
		mercury__switch_detection__partition_disj_trial_6_0_i5,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__switch_detection__partition_disj_trial_6_0, "origin_lost_in_value_number");
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i1003);
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i7);
	MR_stackvar(6) = MR_stackvar(2);
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__switch_detection__partition_disj_trial_6_0_i9,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i8);
	r6 = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__switch_detection__partition_disj_trial_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__switch_detection__partition_disj_trial_6_0_i12,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i8);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__switch_detection__partition_disj_trial_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__switch_detection__partition_disj_trial_6_0_i12,
		STATIC(mercury__switch_detection__partition_disj_trial_6_0));
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_detection__partition_disj_trial_6_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__switch_detection__partition_disj_trial_6_0_i1003);
Define_label(mercury__switch_detection__partition_disj_trial_6_0_i3);
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module20)
	init_entry(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct_7_0);
BEGIN_CODE

/* code for predicate 'find_bind_var_for_switch_in_deconstruct'/7 in mode 0 */
Define_static(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct_7_0);
	r1 = r2;
	tailcall(STATIC(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct__ua0_7_0),
		STATIC(mercury__switch_detection__find_bind_var_for_switch_in_deconstruct_7_0));
END_MODULE

Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__hlds_goal__disj_list_to_goal_3_0);

BEGIN_MODULE(switch_detection_module21)
	init_entry(mercury__switch_detection__fix_case_list_3_0);
	init_label(mercury__switch_detection__fix_case_list_3_0_i4);
	init_label(mercury__switch_detection__fix_case_list_3_0_i5);
	init_label(mercury__switch_detection__fix_case_list_3_0_i6);
	init_label(mercury__switch_detection__fix_case_list_3_0_i3);
BEGIN_CODE

/* code for predicate 'fix_case_list'/3 in mode 0 */
Define_static(mercury__switch_detection__fix_case_list_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_detection__fix_case_list_3_0_i3);
	MR_incr_sp_push_msg(4, "switch_detection:fix_case_list/3");
	MR_stackvar(4) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__switch_detection__fix_case_list_3_0_i4,
		STATIC(mercury__switch_detection__fix_case_list_3_0));
Define_label(mercury__switch_detection__fix_case_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_detection__fix_case_list_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_goal__disj_list_to_goal_3_0),
		mercury__switch_detection__fix_case_list_3_0_i5,
		STATIC(mercury__switch_detection__fix_case_list_3_0));
Define_label(mercury__switch_detection__fix_case_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__switch_detection__fix_case_list_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__switch_detection__fix_case_list_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__switch_detection__fix_case_list_3_0,
		LABEL(mercury__switch_detection__fix_case_list_3_0_i6),
		STATIC(mercury__switch_detection__fix_case_list_3_0));
Define_label(mercury__switch_detection__fix_case_list_3_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_detection__fix_case_list_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_detection__fix_case_list_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__switch_detection__fix_case_list_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__builtin_unify_pred_2_0);

BEGIN_MODULE(switch_detection_module22)
	init_entry(mercury____Unify___switch_detection__process_unify_2_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___switch_detection__process_unify_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_unify_pred_2_0),
		ENTRY(mercury____Unify___switch_detection__process_unify_2_0));
END_MODULE

Declare_entry(mercury__builtin_index_pred_2_0);

BEGIN_MODULE(switch_detection_module23)
	init_entry(mercury____Index___switch_detection__process_unify_2_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___switch_detection__process_unify_2_0);
	r1 = r3;
	tailcall(ENTRY(mercury__builtin_index_pred_2_0),
		ENTRY(mercury____Index___switch_detection__process_unify_2_0));
END_MODULE

Declare_entry(mercury__builtin_compare_pred_3_0);

BEGIN_MODULE(switch_detection_module24)
	init_entry(mercury____Compare___switch_detection__process_unify_2_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___switch_detection__process_unify_2_0);
	r1 = r3;
	r2 = r4;
	tailcall(ENTRY(mercury__builtin_compare_pred_3_0),
		ENTRY(mercury____Compare___switch_detection__process_unify_2_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(switch_detection_module25)
	init_entry(mercury____Unify___switch_detection__cases_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___switch_detection__cases_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___switch_detection__cases_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(switch_detection_module26)
	init_entry(mercury____Index___switch_detection__cases_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___switch_detection__cases_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___switch_detection__cases_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(switch_detection_module27)
	init_entry(mercury____Compare___switch_detection__cases_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___switch_detection__cases_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_5);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___switch_detection__cases_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(switch_detection_module28)
	init_entry(mercury____Unify___switch_detection__sorted_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___switch_detection__sorted_case_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___switch_detection__sorted_case_list_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(switch_detection_module29)
	init_entry(mercury____Index___switch_detection__sorted_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___switch_detection__sorted_case_list_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___switch_detection__sorted_case_list_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(switch_detection_module30)
	init_entry(mercury____Compare___switch_detection__sorted_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___switch_detection__sorted_case_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___switch_detection__sorted_case_list_0_0));
END_MODULE


BEGIN_MODULE(switch_detection_module31)
	init_entry(mercury____Unify___switch_detection__again_0_0);
	init_label(mercury____Unify___switch_detection__again_0_0_i2);
	init_label(mercury____Unify___switch_detection__again_0_0_i4);
	init_label(mercury____Unify___switch_detection__again_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___switch_detection__again_0_0);
	MR_incr_sp_push_msg(5, "switch_detection:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury____Unify___switch_detection__again_0_0_i2,
		STATIC(mercury____Unify___switch_detection__again_0_0));
Define_label(mercury____Unify___switch_detection__again_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___switch_detection__again_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___switch_detection__again_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___switch_detection__again_0_0_i4,
		STATIC(mercury____Unify___switch_detection__again_0_0));
Define_label(mercury____Unify___switch_detection__again_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___switch_detection__again_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___switch_detection__again_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___switch_detection__again_0_0));
Define_label(mercury____Unify___switch_detection__again_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(switch_detection_module32)
	init_entry(mercury____Index___switch_detection__again_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___switch_detection__again_0_0);
	tailcall(STATIC(mercury____Index___switch_detection__again_0__ua0_2_0),
		STATIC(mercury____Index___switch_detection__again_0_0));
END_MODULE

Declare_entry(mercury____Compare___term__var_1_0);

BEGIN_MODULE(switch_detection_module33)
	init_entry(mercury____Compare___switch_detection__again_0_0);
	init_label(mercury____Compare___switch_detection__again_0_0_i3);
	init_label(mercury____Compare___switch_detection__again_0_0_i7);
	init_label(mercury____Compare___switch_detection__again_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___switch_detection__again_0_0);
	MR_incr_sp_push_msg(5, "switch_detection:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___term__var_1_0),
		mercury____Compare___switch_detection__again_0_0_i3,
		STATIC(mercury____Compare___switch_detection__again_0_0));
Define_label(mercury____Compare___switch_detection__again_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___switch_detection__again_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___switch_detection__again_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_detection__common_4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___switch_detection__again_0_0_i7,
		STATIC(mercury____Compare___switch_detection__again_0_0));
Define_label(mercury____Compare___switch_detection__again_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___switch_detection__again_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___switch_detection__again_0_0_i12);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_case_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___switch_detection__again_0_0));
Define_label(mercury____Compare___switch_detection__again_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__switch_detection_maybe_bunch_0(void)
{
	switch_detection_module0();
	switch_detection_module1();
	switch_detection_module2();
	switch_detection_module3();
	switch_detection_module4();
	switch_detection_module5();
	switch_detection_module6();
	switch_detection_module7();
	switch_detection_module8();
	switch_detection_module9();
	switch_detection_module10();
	switch_detection_module11();
	switch_detection_module12();
	switch_detection_module13();
	switch_detection_module14();
	switch_detection_module15();
	switch_detection_module16();
	switch_detection_module17();
	switch_detection_module18();
	switch_detection_module19();
	switch_detection_module20();
	switch_detection_module21();
	switch_detection_module22();
	switch_detection_module23();
	switch_detection_module24();
	switch_detection_module25();
	switch_detection_module26();
	switch_detection_module27();
	switch_detection_module28();
	switch_detection_module29();
	switch_detection_module30();
	switch_detection_module31();
	switch_detection_module32();
	switch_detection_module33();
}

#endif

void mercury__switch_detection__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__switch_detection__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__switch_detection_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_detection__type_ctor_info_again_0,
			switch_detection__again_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_detection__type_ctor_info_cases_0,
			switch_detection__cases_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_detection__type_ctor_info_process_unify_2,
			switch_detection__process_unify_2_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_detection__type_ctor_info_sorted_case_list_0,
			switch_detection__sorted_case_list_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
