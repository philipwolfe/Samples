/*
** Automatically generated from `switch_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__switch_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___switch_gen__extended_case_0__ua0_2_0);
Define_extern_entry(mercury__switch_gen__generate_switch_9_0);
Declare_label(mercury__switch_gen__generate_switch_9_0_i2);
Declare_label(mercury__switch_gen__generate_switch_9_0_i3);
Declare_label(mercury__switch_gen__generate_switch_9_0_i4);
Declare_label(mercury__switch_gen__generate_switch_9_0_i6);
Declare_label(mercury__switch_gen__generate_switch_9_0_i7);
Declare_label(mercury__switch_gen__generate_switch_9_0_i8);
Declare_label(mercury__switch_gen__generate_switch_9_0_i9);
Declare_label(mercury__switch_gen__generate_switch_9_0_i10);
Declare_label(mercury__switch_gen__generate_switch_9_0_i15);
Declare_label(mercury__switch_gen__generate_switch_9_0_i17);
Declare_label(mercury__switch_gen__generate_switch_9_0_i18);
Declare_label(mercury__switch_gen__generate_switch_9_0_i19);
Declare_label(mercury__switch_gen__generate_switch_9_0_i20);
Declare_label(mercury__switch_gen__generate_switch_9_0_i11);
Declare_label(mercury__switch_gen__generate_switch_9_0_i12);
Declare_label(mercury__switch_gen__generate_switch_9_0_i27);
Declare_label(mercury__switch_gen__generate_switch_9_0_i28);
Declare_label(mercury__switch_gen__generate_switch_9_0_i29);
Declare_label(mercury__switch_gen__generate_switch_9_0_i30);
Declare_label(mercury__switch_gen__generate_switch_9_0_i23);
Declare_label(mercury__switch_gen__generate_switch_9_0_i24);
Declare_label(mercury__switch_gen__generate_switch_9_0_i37);
Declare_label(mercury__switch_gen__generate_switch_9_0_i38);
Declare_label(mercury__switch_gen__generate_switch_9_0_i33);
Declare_label(mercury__switch_gen__generate_switch_9_0_i34);
Declare_label(mercury__switch_gen__generate_switch_9_0_i44);
Declare_label(mercury__switch_gen__generate_switch_9_0_i45);
Declare_label(mercury__switch_gen__generate_switch_9_0_i41);
Declare_label(mercury__switch_gen__generate_switch_9_0_i47);
Declare_label(mercury__switch_gen__generate_switch_9_0_i52);
Declare_static(mercury__switch_gen__lookup_tags_5_0);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i4);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i7);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i8);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i9);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i10);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i16);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i17);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i18);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i19);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i20);
Declare_label(mercury__switch_gen__lookup_tags_5_0_i3);
Declare_static(mercury__switch_gen__generate_all_cases_11_0);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i2);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i9);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i10);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i11);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i12);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i13);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i16);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i3);
Declare_label(mercury__switch_gen__generate_all_cases_11_0_i21);
Declare_static(mercury__switch_gen__generate_cases_11_0);
Declare_label(mercury__switch_gen__generate_cases_11_0_i4);
Declare_label(mercury__switch_gen__generate_cases_11_0_i8);
Declare_label(mercury__switch_gen__generate_cases_11_0_i7);
Declare_label(mercury__switch_gen__generate_cases_11_0_i11);
Declare_label(mercury__switch_gen__generate_cases_11_0_i12);
Declare_label(mercury__switch_gen__generate_cases_11_0_i13);
Declare_label(mercury__switch_gen__generate_cases_11_0_i14);
Declare_label(mercury__switch_gen__generate_cases_11_0_i6);
Declare_label(mercury__switch_gen__generate_cases_11_0_i15);
Declare_label(mercury__switch_gen__generate_cases_11_0_i16);
Declare_label(mercury__switch_gen__generate_cases_11_0_i17);
Declare_label(mercury__switch_gen__generate_cases_11_0_i19);
Declare_label(mercury__switch_gen__generate_cases_11_0_i20);
Declare_label(mercury__switch_gen__generate_cases_11_0_i3);
Declare_label(mercury__switch_gen__generate_cases_11_0_i23);
Declare_label(mercury__switch_gen__generate_cases_11_0_i21);
Define_extern_entry(mercury____Unify___switch_gen__extended_case_0_0);
Declare_label(mercury____Unify___switch_gen__extended_case_0_0_i2);
Declare_label(mercury____Unify___switch_gen__extended_case_0_0_i4);
Declare_label(mercury____Unify___switch_gen__extended_case_0_0_i1004);
Declare_label(mercury____Unify___switch_gen__extended_case_0_0_i1);
Define_extern_entry(mercury____Index___switch_gen__extended_case_0_0);
Define_extern_entry(mercury____Compare___switch_gen__extended_case_0_0);
Declare_label(mercury____Compare___switch_gen__extended_case_0_0_i3);
Declare_label(mercury____Compare___switch_gen__extended_case_0_0_i7);
Declare_label(mercury____Compare___switch_gen__extended_case_0_0_i11);
Declare_label(mercury____Compare___switch_gen__extended_case_0_0_i17);
Define_extern_entry(mercury____Unify___switch_gen__cases_list_0_0);
Define_extern_entry(mercury____Index___switch_gen__cases_list_0_0);
Define_extern_entry(mercury____Compare___switch_gen__cases_list_0_0);
Declare_static(mercury____Unify___switch_gen__switch_category_0_0);
Declare_label(mercury____Unify___switch_gen__switch_category_0_0_i1);
Declare_static(mercury____Index___switch_gen__switch_category_0_0);
Declare_static(mercury____Compare___switch_gen__switch_category_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_cases_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_extended_case_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_switch_category_0;

static const struct mercury_data_switch_gen__common_0_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_data_switch_gen__common_0;

static const struct mercury_data_switch_gen__common_1_struct {
	Word * f1;
}  mercury_data_switch_gen__common_1;

static const struct mercury_data_switch_gen__common_2_struct {
	Word * f1;
}  mercury_data_switch_gen__common_2;

static const struct mercury_data_switch_gen__common_3_struct {
	Word * f1;
}  mercury_data_switch_gen__common_3;

static const struct mercury_data_switch_gen__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_switch_gen__common_4;

static const struct mercury_data_switch_gen__common_5_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	String f6;
	Word * f7;
	Integer f8;
	Integer f9;
}  mercury_data_switch_gen__common_5;

static const struct mercury_data_switch_gen__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_switch_gen__common_6;

static const struct mercury_data_switch_gen__common_7_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_gen__common_7;

static const struct mercury_data_switch_gen__type_ctor_functors_switch_category_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_gen__type_ctor_functors_switch_category_0;

static const struct mercury_data_switch_gen__type_ctor_layout_switch_category_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_gen__type_ctor_layout_switch_category_0;

static const struct mercury_data_switch_gen__type_ctor_functors_extended_case_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_switch_gen__type_ctor_functors_extended_case_0;

static const struct mercury_data_switch_gen__type_ctor_layout_extended_case_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_gen__type_ctor_layout_extended_case_0;

static const struct mercury_data_switch_gen__type_ctor_functors_cases_list_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_switch_gen__type_ctor_functors_cases_list_0;

static const struct mercury_data_switch_gen__type_ctor_layout_cases_list_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_switch_gen__type_ctor_layout_cases_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_cases_list_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___switch_gen__cases_list_0_0),
	ENTRY(mercury____Index___switch_gen__cases_list_0_0),
	ENTRY(mercury____Compare___switch_gen__cases_list_0_0),
	(Integer) 6,
	(Word *) &mercury_data_switch_gen__type_ctor_functors_cases_list_0,
	(Word *) &mercury_data_switch_gen__type_ctor_layout_cases_list_0,
	MR_string_const("switch_gen", 10),
	MR_string_const("cases_list", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_extended_case_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___switch_gen__extended_case_0_0),
	ENTRY(mercury____Index___switch_gen__extended_case_0_0),
	ENTRY(mercury____Compare___switch_gen__extended_case_0_0),
	(Integer) 2,
	(Word *) &mercury_data_switch_gen__type_ctor_functors_extended_case_0,
	(Word *) &mercury_data_switch_gen__type_ctor_layout_extended_case_0,
	MR_string_const("switch_gen", 10),
	MR_string_const("extended_case", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_switch_gen__type_ctor_info_switch_category_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___switch_gen__switch_category_0_0),
	STATIC(mercury____Index___switch_gen__switch_category_0_0),
	STATIC(mercury____Compare___switch_gen__switch_category_0_0),
	(Integer) 0,
	(Word *) &mercury_data_switch_gen__type_ctor_functors_switch_category_0,
	(Word *) &mercury_data_switch_gen__type_ctor_layout_switch_category_0,
	MR_string_const("switch_gen", 10),
	MR_string_const("switch_category", 15),
	(Integer) 3
};

static const struct mercury_data_switch_gen__common_0_struct mercury_data_switch_gen__common_0 = {
	(Integer) 1,
	(Integer) 4,
	MR_string_const("atomic_switch", 13),
	MR_string_const("string_switch", 13),
	MR_string_const("tag_switch", 10),
	MR_string_const("other_switch", 12)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_switch_gen__common_1_struct mercury_data_switch_gen__common_1 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;
static const struct mercury_data_switch_gen__common_2_struct mercury_data_switch_gen__common_2 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_switch_gen__common_3_struct mercury_data_switch_gen__common_3 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_switch_gen__common_4_struct mercury_data_switch_gen__common_4 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

static const struct mercury_data_switch_gen__common_5_struct mercury_data_switch_gen__common_5 = {
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_4),
	MR_string_const("case", 4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_switch_gen__common_6_struct mercury_data_switch_gen__common_6 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0
};

static const struct mercury_data_switch_gen__common_7_struct mercury_data_switch_gen__common_7 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_6)
};

static const struct mercury_data_switch_gen__type_ctor_functors_switch_category_0_struct mercury_data_switch_gen__type_ctor_functors_switch_category_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_0)
};

static const struct mercury_data_switch_gen__type_ctor_layout_switch_category_0_struct mercury_data_switch_gen__type_ctor_layout_switch_category_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_0)
};

static const struct mercury_data_switch_gen__type_ctor_functors_extended_case_0_struct mercury_data_switch_gen__type_ctor_functors_extended_case_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_5)
};

static const struct mercury_data_switch_gen__type_ctor_layout_extended_case_0_struct mercury_data_switch_gen__type_ctor_layout_extended_case_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_switch_gen__common_5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_switch_gen__type_ctor_functors_cases_list_0_struct mercury_data_switch_gen__type_ctor_functors_cases_list_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_switch_gen__common_6)
};

static const struct mercury_data_switch_gen__type_ctor_layout_cases_list_0_struct mercury_data_switch_gen__type_ctor_layout_cases_list_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_gen__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_gen__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_gen__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_switch_gen__common_7)
};


BEGIN_MODULE(switch_gen_module0)
	init_entry(mercury____Index___switch_gen__extended_case_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___switch_gen__extended_case_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___switch_gen__extended_case_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__variable_type_4_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__type_util__classify_type_3_0);
static const struct mercury_const_1_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
}  mercury_const_1 = {
	(Integer) 0,
	(Integer) 0,
	(Integer) 1,
	(Integer) 3,
	(Integer) 3,
	(Integer) 0,
	(Integer) 3,
	(Integer) 2
};
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__list__sort_and_remove_dups_2_0);
Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__globals__lookup_bool_option_3_0);
Declare_entry(mercury__code_info__get_maybe_trace_info_3_0);
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__globals__lookup_int_option_3_0);
Declare_entry(mercury__lookup_switch__is_lookup_switch_15_0);
Declare_entry(mercury__lookup_switch__generate_14_0);
Declare_entry(mercury__dense_switch__is_dense_switch_9_0);
Declare_entry(mercury__dense_switch__generate_13_0);
Declare_entry(mercury__string_switch__generate_11_0);
Declare_entry(mercury__tag_switch__generate_11_0);
Declare_entry(mercury__code_info__after_all_branches_4_0);

BEGIN_MODULE(switch_gen_module1)
	init_entry(mercury__switch_gen__generate_switch_9_0);
	init_label(mercury__switch_gen__generate_switch_9_0_i2);
	init_label(mercury__switch_gen__generate_switch_9_0_i3);
	init_label(mercury__switch_gen__generate_switch_9_0_i4);
	init_label(mercury__switch_gen__generate_switch_9_0_i6);
	init_label(mercury__switch_gen__generate_switch_9_0_i7);
	init_label(mercury__switch_gen__generate_switch_9_0_i8);
	init_label(mercury__switch_gen__generate_switch_9_0_i9);
	init_label(mercury__switch_gen__generate_switch_9_0_i10);
	init_label(mercury__switch_gen__generate_switch_9_0_i15);
	init_label(mercury__switch_gen__generate_switch_9_0_i17);
	init_label(mercury__switch_gen__generate_switch_9_0_i18);
	init_label(mercury__switch_gen__generate_switch_9_0_i19);
	init_label(mercury__switch_gen__generate_switch_9_0_i20);
	init_label(mercury__switch_gen__generate_switch_9_0_i11);
	init_label(mercury__switch_gen__generate_switch_9_0_i12);
	init_label(mercury__switch_gen__generate_switch_9_0_i27);
	init_label(mercury__switch_gen__generate_switch_9_0_i28);
	init_label(mercury__switch_gen__generate_switch_9_0_i29);
	init_label(mercury__switch_gen__generate_switch_9_0_i30);
	init_label(mercury__switch_gen__generate_switch_9_0_i23);
	init_label(mercury__switch_gen__generate_switch_9_0_i24);
	init_label(mercury__switch_gen__generate_switch_9_0_i37);
	init_label(mercury__switch_gen__generate_switch_9_0_i38);
	init_label(mercury__switch_gen__generate_switch_9_0_i33);
	init_label(mercury__switch_gen__generate_switch_9_0_i34);
	init_label(mercury__switch_gen__generate_switch_9_0_i44);
	init_label(mercury__switch_gen__generate_switch_9_0_i45);
	init_label(mercury__switch_gen__generate_switch_9_0_i41);
	init_label(mercury__switch_gen__generate_switch_9_0_i47);
	init_label(mercury__switch_gen__generate_switch_9_0_i52);
BEGIN_CODE

/* code for predicate 'generate_switch'/9 in mode 0 */
Define_entry(mercury__switch_gen__generate_switch_9_0);
	MR_incr_sp_push_msg(14, "switch_gen:generate_switch/9");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r7;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__switch_gen__generate_switch_9_0_i2,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__switch_gen__generate_switch_9_0_i3,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i3);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__switch_gen__generate_switch_9_0_i4,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_1), r2);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__switch_gen__generate_switch_9_0_i6,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i6);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r3 = r2;
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__switch_gen__lookup_tags_5_0),
		mercury__switch_gen__generate_switch_9_0_i7,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i7);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__switch_gen__generate_switch_9_0_i8,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i8);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__switch_gen__generate_switch_9_0_i9,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(12) = r2;
	r2 = (Integer) 181;
	MR_stackvar(10) = r1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i10,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i12);
	if (((Integer) MR_stackvar(7) != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i12);
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__switch_gen__generate_switch_9_0_i15,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i11);
	MR_stackvar(13) = r2;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_gen__generate_switch_9_0_i17,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i17);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 185;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i18,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i18);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) MR_stackvar(4) < (Integer) r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i11);
	r1 = MR_stackvar(10);
	r2 = (Integer) 183;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i19,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i19);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r5 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(1);
	r7 = MR_stackvar(13);
	call_localret(ENTRY(mercury__lookup_switch__is_lookup_switch_15_0),
		mercury__switch_gen__generate_switch_9_0_i20,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i11);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r4;
	r4 = r2;
	r2 = r6;
	r6 = MR_tempr1;
	MR_tempr2 = r5;
	r5 = r3;
	r3 = r7;
	r7 = MR_tempr2;
	r11 = r9;
	r1 = MR_stackvar(2);
	r9 = MR_stackvar(5);
	r10 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__lookup_switch__generate_14_0),
		mercury__switch_gen__generate_switch_9_0_i47,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
	}
Define_label(mercury__switch_gen__generate_switch_9_0_i11);
	r1 = MR_stackvar(11);
Define_label(mercury__switch_gen__generate_switch_9_0_i12);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i24);
	if (((Integer) MR_stackvar(7) != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i24);
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_gen__generate_switch_9_0_i27,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i27);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 184;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i28,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i28);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) MR_stackvar(4) < (Integer) r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i23);
	r1 = MR_stackvar(10);
	r2 = (Integer) 182;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i29,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i29);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(12);
	call_localret(ENTRY(mercury__dense_switch__is_dense_switch_9_0),
		mercury__switch_gen__generate_switch_9_0_i30,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i30);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i23);
	r6 = r4;
	r10 = r5;
	r1 = MR_stackvar(9);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(1);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(8);
	r9 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__dense_switch__generate_13_0),
		mercury__switch_gen__generate_switch_9_0_i47,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i23);
	r1 = MR_stackvar(11);
Define_label(mercury__switch_gen__generate_switch_9_0_i24);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i34);
	if (((Integer) MR_stackvar(7) != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i34);
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_gen__generate_switch_9_0_i37,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i37);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 186;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i38,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i38);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) MR_stackvar(4) < (Integer) r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i33);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r8 = MR_stackvar(12);
	call_localret(ENTRY(mercury__string_switch__generate_11_0),
		mercury__switch_gen__generate_switch_9_0_i47,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i33);
	r1 = MR_stackvar(11);
Define_label(mercury__switch_gen__generate_switch_9_0_i34);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i41);
	if (((Integer) MR_stackvar(7) != (Integer) 2))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i41);
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__switch_gen__generate_switch_9_0_i44,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i44);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(10);
	r2 = (Integer) 187;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__switch_gen__generate_switch_9_0_i45,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i45);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	if (((Integer) MR_stackvar(4) < (Integer) r1))
		GOTO_LABEL(mercury__switch_gen__generate_switch_9_0_i41);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r8 = MR_stackvar(12);
	call_localret(ENTRY(mercury__tag_switch__generate_11_0),
		mercury__switch_gen__generate_switch_9_0_i47,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i41);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r8 = MR_stackvar(12);
	call_localret(STATIC(mercury__switch_gen__generate_all_cases_11_0),
		mercury__switch_gen__generate_switch_9_0_i47,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i47);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__after_all_branches_4_0),
		mercury__switch_gen__generate_switch_9_0_i52,
		ENTRY(mercury__switch_gen__generate_switch_9_0));
Define_label(mercury__switch_gen__generate_switch_9_0_i52);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_switch_9_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__cons_id_to_tag_5_0);

BEGIN_MODULE(switch_gen_module2)
	init_entry(mercury__switch_gen__lookup_tags_5_0);
	init_label(mercury__switch_gen__lookup_tags_5_0_i4);
	init_label(mercury__switch_gen__lookup_tags_5_0_i7);
	init_label(mercury__switch_gen__lookup_tags_5_0_i8);
	init_label(mercury__switch_gen__lookup_tags_5_0_i9);
	init_label(mercury__switch_gen__lookup_tags_5_0_i10);
	init_label(mercury__switch_gen__lookup_tags_5_0_i16);
	init_label(mercury__switch_gen__lookup_tags_5_0_i17);
	init_label(mercury__switch_gen__lookup_tags_5_0_i18);
	init_label(mercury__switch_gen__lookup_tags_5_0_i19);
	init_label(mercury__switch_gen__lookup_tags_5_0_i20);
	init_label(mercury__switch_gen__lookup_tags_5_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_tags'/5 in mode 0 */
Define_static(mercury__switch_gen__lookup_tags_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__lookup_tags_5_0_i3);
	MR_incr_sp_push_msg(5, "switch_gen:lookup_tags/5");
	MR_stackvar(5) = (Word) MR_succip;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_tempr1;
	r1 = r2;
	r2 = MR_tempr1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__switch_gen__lookup_tags_5_0_i4,
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_gen__lookup_tags_5_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__switch_gen__lookup_tags_5_0_i7) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i8) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i9) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i10));
Define_label(mercury__switch_gen__lookup_tags_5_0_i7);
	r3 = r2;
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 0;
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i8);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 5;
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i9);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__switch_gen__lookup_tags_5_0_i19) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i16) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i16) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i16) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i16) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i16) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i17) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i18) AND
		LABEL(mercury__switch_gen__lookup_tags_5_0_i19));
Define_label(mercury__switch_gen__lookup_tags_5_0_i16);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 6;
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i17);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i18);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 4;
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i19);
	r3 = r2;
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 4, mercury__switch_gen__lookup_tags_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r4;
	localcall(mercury__switch_gen__lookup_tags_5_0,
		LABEL(mercury__switch_gen__lookup_tags_5_0_i20),
		STATIC(mercury__switch_gen__lookup_tags_5_0));
	}
Define_label(mercury__switch_gen__lookup_tags_5_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_gen__lookup_tags_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_gen__lookup_tags_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__switch_gen__lookup_tags_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r3;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__produce_variable_5_0);
Declare_entry(mercury__code_info__get_pred_id_3_0);
Declare_entry(mercury__code_info__get_proc_id_3_0);
Declare_entry(mercury__code_util__count_recursive_calls_5_0);

BEGIN_MODULE(switch_gen_module3)
	init_entry(mercury__switch_gen__generate_all_cases_11_0);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i2);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i9);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i10);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i11);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i12);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i13);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i16);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i3);
	init_label(mercury__switch_gen__generate_all_cases_11_0_i21);
BEGIN_CODE

/* code for predicate 'generate_all_cases'/11 in mode 0 */
Define_static(mercury__switch_gen__generate_all_cases_11_0);
	MR_incr_sp_push_msg(15, "switch_gen:generate_all_cases/11");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = r8;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__switch_gen__generate_all_cases_11_0_i2,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i2);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i3);
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i3);
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i3);
	r4 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i3);
	MR_stackvar(8) = r1;
	r2 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	r1 = r3;
	MR_stackvar(9) = MR_tempr1;
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__code_info__get_pred_id_3_0),
		mercury__switch_gen__generate_all_cases_11_0_i9,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_all_cases_11_0_i9);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	MR_stackvar(13) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_id_3_0),
		mercury__switch_gen__generate_all_cases_11_0_i10,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i10);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	r3 = r1;
	r1 = MR_stackvar(11);
	MR_stackvar(11) = r3;
	MR_stackvar(14) = r2;
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_util__count_recursive_calls_5_0),
		mercury__switch_gen__generate_all_cases_11_0_i11,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	r3 = MR_stackvar(11);
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r2;
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_util__count_recursive_calls_5_0),
		mercury__switch_gen__generate_all_cases_11_0_i12,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	if (((Integer) MR_stackvar(12) != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i13);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i13);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_all_cases_11_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_all_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r8 = MR_stackvar(14);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__switch_gen__generate_cases_11_0),
		mercury__switch_gen__generate_all_cases_11_0_i21,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_all_cases_11_0_i13);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i16);
	if (((Integer) MR_stackvar(11) <= (Integer) 1))
		GOTO_LABEL(mercury__switch_gen__generate_all_cases_11_0_i16);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_all_cases_11_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_all_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r8 = MR_stackvar(14);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__switch_gen__generate_cases_11_0),
		mercury__switch_gen__generate_all_cases_11_0_i21,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_all_cases_11_0_i16);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	r1 = MR_stackvar(1);
	r8 = MR_stackvar(14);
	call_localret(STATIC(mercury__switch_gen__generate_cases_11_0),
		mercury__switch_gen__generate_all_cases_11_0_i21,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i3);
	r8 = r3;
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	r7 = MR_stackvar(7);
	call_localret(STATIC(mercury__switch_gen__generate_cases_11_0),
		mercury__switch_gen__generate_all_cases_11_0_i21,
		STATIC(mercury__switch_gen__generate_all_cases_11_0));
Define_label(mercury__switch_gen__generate_all_cases_11_0_i21);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_all_cases_11_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_all_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__unify_gen__generate_tag_test_7_0);
Declare_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);
Declare_entry(mercury__code_info__generate_failure_3_0);

BEGIN_MODULE(switch_gen_module4)
	init_entry(mercury__switch_gen__generate_cases_11_0);
	init_label(mercury__switch_gen__generate_cases_11_0_i4);
	init_label(mercury__switch_gen__generate_cases_11_0_i8);
	init_label(mercury__switch_gen__generate_cases_11_0_i7);
	init_label(mercury__switch_gen__generate_cases_11_0_i11);
	init_label(mercury__switch_gen__generate_cases_11_0_i12);
	init_label(mercury__switch_gen__generate_cases_11_0_i13);
	init_label(mercury__switch_gen__generate_cases_11_0_i14);
	init_label(mercury__switch_gen__generate_cases_11_0_i6);
	init_label(mercury__switch_gen__generate_cases_11_0_i15);
	init_label(mercury__switch_gen__generate_cases_11_0_i16);
	init_label(mercury__switch_gen__generate_cases_11_0_i17);
	init_label(mercury__switch_gen__generate_cases_11_0_i19);
	init_label(mercury__switch_gen__generate_cases_11_0_i20);
	init_label(mercury__switch_gen__generate_cases_11_0_i3);
	init_label(mercury__switch_gen__generate_cases_11_0_i23);
	init_label(mercury__switch_gen__generate_cases_11_0_i21);
BEGIN_CODE

/* code for predicate 'generate_cases'/11 in mode 0 */
Define_static(mercury__switch_gen__generate_cases_11_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_cases_11_0_i3);
	MR_incr_sp_push_msg(15, "switch_gen:generate_cases/11");
	MR_stackvar(15) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r1 = r8;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__switch_gen__generate_cases_11_0_i4,
		STATIC(mercury__switch_gen__generate_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_cases_11_0_i4);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	if (((Integer) MR_stackvar(9) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__switch_gen__generate_cases_11_0_i8);
	r4 = r2;
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__switch_gen__generate_cases_11_0_i7);
Define_label(mercury__switch_gen__generate_cases_11_0_i8);
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_cases_11_0_i6);
	r4 = r2;
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
Define_label(mercury__switch_gen__generate_cases_11_0_i7);
	MR_stackvar(1) = r1;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__unify_gen__generate_tag_test_7_0),
		mercury__switch_gen__generate_cases_11_0_i11,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i11);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	MR_stackvar(10) = r1;
	MR_stackvar(11) = r2;
	r1 = MR_stackvar(8);
	r2 = r3;
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__switch_gen__generate_cases_11_0_i12,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i12);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r3 = r2;
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__switch_gen__generate_cases_11_0_i13,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i13);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r3 = r2;
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__switch_gen__generate_cases_11_0_i14,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i14);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r5 = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(11);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(11) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = r2;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 1, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r13, MR_mktag(3), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "llds:instr/0");
	MR_field(MR_mktag(3), r13, (Integer) 0) = (Integer) 5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r12, (Integer) 1) = (Word) MR_string_const("skip to the end of the switch", 29);
	MR_field(MR_mktag(3), r13, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r12, (Integer) 0) = r13;
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r13, (Integer) 0) = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), MR_stackvar(11), (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(2), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("next case", 9);
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__switch_gen__generate_cases_11_0_i19,
		STATIC(mercury__switch_gen__generate_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_cases_11_0_i6);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__switch_gen__generate_cases_11_0_i15,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i15);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r3 = r2;
	r2 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__switch_gen__generate_cases_11_0_i16,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i16);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r3 = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__switch_gen__generate_cases_11_0_i17,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i17);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	MR_stackvar(11) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_stackvar(11), (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	r2 = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__switch_gen__generate_cases_11_0_i19,
		STATIC(mercury__switch_gen__generate_cases_11_0));
	}
Define_label(mercury__switch_gen__generate_cases_11_0_i19);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r8 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(10);
	localcall(mercury__switch_gen__generate_cases_11_0,
		LABEL(mercury__switch_gen__generate_cases_11_0_i20),
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i20);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(11);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__switch_gen__generate_cases_11_0_i3);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__switch_gen__generate_cases_11_0_i21);
	MR_incr_sp_push_msg(15, "switch_gen:generate_cases/11");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(5) = r6;
	MR_stackvar(1) = r7;
	r1 = r8;
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__switch_gen__generate_cases_11_0_i23,
		STATIC(mercury__switch_gen__generate_cases_11_0));
Define_label(mercury__switch_gen__generate_cases_11_0_i23);
	update_prof_current_proc(LABEL(mercury__switch_gen__generate_cases_11_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("end of switch", 13);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__switch_gen__generate_cases_11_0_i21);
	r1 = r7;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__switch_gen__generate_cases_11_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__switch_gen__generate_cases_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("end of switch", 13);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	r3 = r8;
	proceed();
	}
END_MODULE

Declare_entry(mercury____Unify___hlds_data__cons_tag_0_0);
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(switch_gen_module5)
	init_entry(mercury____Unify___switch_gen__extended_case_0_0);
	init_label(mercury____Unify___switch_gen__extended_case_0_0_i2);
	init_label(mercury____Unify___switch_gen__extended_case_0_0_i4);
	init_label(mercury____Unify___switch_gen__extended_case_0_0_i1004);
	init_label(mercury____Unify___switch_gen__extended_case_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___switch_gen__extended_case_0_0);
	MR_incr_sp_push_msg(5, "switch_gen:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != r3))
		GOTO_LABEL(mercury____Unify___switch_gen__extended_case_0_0_i1004);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_tag_0_0),
		mercury____Unify___switch_gen__extended_case_0_0_i2,
		ENTRY(mercury____Unify___switch_gen__extended_case_0_0));
Define_label(mercury____Unify___switch_gen__extended_case_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___switch_gen__extended_case_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___switch_gen__extended_case_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury____Unify___switch_gen__extended_case_0_0_i4,
		ENTRY(mercury____Unify___switch_gen__extended_case_0_0));
Define_label(mercury____Unify___switch_gen__extended_case_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___switch_gen__extended_case_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___switch_gen__extended_case_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___switch_gen__extended_case_0_0));
Define_label(mercury____Unify___switch_gen__extended_case_0_0_i1004);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___switch_gen__extended_case_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(switch_gen_module6)
	init_entry(mercury____Index___switch_gen__extended_case_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___switch_gen__extended_case_0_0);
	tailcall(STATIC(mercury____Index___switch_gen__extended_case_0__ua0_2_0),
		ENTRY(mercury____Index___switch_gen__extended_case_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___hlds_data__cons_tag_0_0);
Declare_entry(mercury____Compare___hlds_data__cons_id_0_0);
Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(switch_gen_module7)
	init_entry(mercury____Compare___switch_gen__extended_case_0_0);
	init_label(mercury____Compare___switch_gen__extended_case_0_0_i3);
	init_label(mercury____Compare___switch_gen__extended_case_0_0_i7);
	init_label(mercury____Compare___switch_gen__extended_case_0_0_i11);
	init_label(mercury____Compare___switch_gen__extended_case_0_0_i17);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___switch_gen__extended_case_0_0);
	MR_incr_sp_push_msg(7, "switch_gen:__Compare__/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___switch_gen__extended_case_0_0_i3,
		ENTRY(mercury____Compare___switch_gen__extended_case_0_0));
Define_label(mercury____Compare___switch_gen__extended_case_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___switch_gen__extended_case_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___switch_gen__extended_case_0_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_tag_0_0),
		mercury____Compare___switch_gen__extended_case_0_0_i7,
		ENTRY(mercury____Compare___switch_gen__extended_case_0_0));
Define_label(mercury____Compare___switch_gen__extended_case_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___switch_gen__extended_case_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___switch_gen__extended_case_0_0_i17);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___hlds_data__cons_id_0_0),
		mercury____Compare___switch_gen__extended_case_0_0_i11,
		ENTRY(mercury____Compare___switch_gen__extended_case_0_0));
Define_label(mercury____Compare___switch_gen__extended_case_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___switch_gen__extended_case_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___switch_gen__extended_case_0_0_i17);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___switch_gen__extended_case_0_0));
Define_label(mercury____Compare___switch_gen__extended_case_0_0_i17);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(switch_gen_module8)
	init_entry(mercury____Unify___switch_gen__cases_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___switch_gen__cases_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___switch_gen__cases_list_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(switch_gen_module9)
	init_entry(mercury____Index___switch_gen__cases_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___switch_gen__cases_list_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		ENTRY(mercury____Index___switch_gen__cases_list_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(switch_gen_module10)
	init_entry(mercury____Compare___switch_gen__cases_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___switch_gen__cases_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_switch_gen__type_ctor_info_extended_case_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___switch_gen__cases_list_0_0));
END_MODULE


BEGIN_MODULE(switch_gen_module11)
	init_entry(mercury____Unify___switch_gen__switch_category_0_0);
	init_label(mercury____Unify___switch_gen__switch_category_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___switch_gen__switch_category_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___switch_gen__switch_category_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___switch_gen__switch_category_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(switch_gen_module12)
	init_entry(mercury____Index___switch_gen__switch_category_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___switch_gen__switch_category_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(switch_gen_module13)
	init_entry(mercury____Compare___switch_gen__switch_category_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___switch_gen__switch_category_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___switch_gen__switch_category_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__switch_gen_maybe_bunch_0(void)
{
	switch_gen_module0();
	switch_gen_module1();
	switch_gen_module2();
	switch_gen_module3();
	switch_gen_module4();
	switch_gen_module5();
	switch_gen_module6();
	switch_gen_module7();
	switch_gen_module8();
	switch_gen_module9();
	switch_gen_module10();
	switch_gen_module11();
	switch_gen_module12();
	switch_gen_module13();
}

#endif

void mercury__switch_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__switch_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__switch_gen_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_gen__type_ctor_info_cases_list_0,
			switch_gen__cases_list_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_gen__type_ctor_info_extended_case_0,
			switch_gen__extended_case_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_switch_gen__type_ctor_info_switch_category_0,
			switch_gen__switch_category_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
