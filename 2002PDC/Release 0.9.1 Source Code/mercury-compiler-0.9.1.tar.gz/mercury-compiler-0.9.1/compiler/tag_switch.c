/*
** Automatically generated from `tag_switch.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__tag_switch__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i7);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i8);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i1039);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i3);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i14);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i2);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i19);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i20);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i21);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i22);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i23);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i24);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i25);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i26);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i27);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i28);
Declare_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i29);
Declare_static(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0);
Declare_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i3);
Declare_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i4);
Declare_static(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0);
Declare_label(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0_i1);
Declare_static(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0);
Declare_label(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0_i1);
Define_extern_entry(mercury__tag_switch__generate_11_0);
Declare_label(mercury__tag_switch__generate_11_0_i2);
Declare_label(mercury__tag_switch__generate_11_0_i3);
Declare_label(mercury__tag_switch__generate_11_0_i4);
Declare_label(mercury__tag_switch__generate_11_0_i5);
Declare_label(mercury__tag_switch__generate_11_0_i6);
Declare_label(mercury__tag_switch__generate_11_0_i7);
Declare_label(mercury__tag_switch__generate_11_0_i8);
Declare_label(mercury__tag_switch__generate_11_0_i9);
Declare_label(mercury__tag_switch__generate_11_0_i10);
Declare_label(mercury__tag_switch__generate_11_0_i11);
Declare_label(mercury__tag_switch__generate_11_0_i12);
Declare_label(mercury__tag_switch__generate_11_0_i13);
Declare_label(mercury__tag_switch__generate_11_0_i14);
Declare_label(mercury__tag_switch__generate_11_0_i15);
Declare_label(mercury__tag_switch__generate_11_0_i16);
Declare_label(mercury__tag_switch__generate_11_0_i17);
Declare_label(mercury__tag_switch__generate_11_0_i21);
Declare_label(mercury__tag_switch__generate_11_0_i22);
Declare_label(mercury__tag_switch__generate_11_0_i23);
Declare_label(mercury__tag_switch__generate_11_0_i28);
Declare_label(mercury__tag_switch__generate_11_0_i30);
Declare_label(mercury__tag_switch__generate_11_0_i1008);
Declare_label(mercury__tag_switch__generate_11_0_i32);
Declare_label(mercury__tag_switch__generate_11_0_i29);
Declare_label(mercury__tag_switch__generate_11_0_i24);
Declare_label(mercury__tag_switch__generate_11_0_i25);
Declare_label(mercury__tag_switch__generate_11_0_i38);
Declare_label(mercury__tag_switch__generate_11_0_i41);
Declare_label(mercury__tag_switch__generate_11_0_i40);
Declare_label(mercury__tag_switch__generate_11_0_i43);
Declare_label(mercury__tag_switch__generate_11_0_i44);
Declare_label(mercury__tag_switch__generate_11_0_i46);
Declare_label(mercury__tag_switch__generate_11_0_i47);
Declare_label(mercury__tag_switch__generate_11_0_i48);
Declare_label(mercury__tag_switch__generate_11_0_i54);
Declare_label(mercury__tag_switch__generate_11_0_i55);
Declare_label(mercury__tag_switch__generate_11_0_i56);
Declare_label(mercury__tag_switch__generate_11_0_i57);
Declare_label(mercury__tag_switch__generate_11_0_i58);
Declare_label(mercury__tag_switch__generate_11_0_i59);
Declare_static(mercury__tag_switch__generate_primary_try_me_else_chain_14_0);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i4);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i3);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i5);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i6);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i7);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i8);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i11);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i15);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i16);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1031);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i20);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i21);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1039);
Declare_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i10);
Declare_static(mercury__tag_switch__generate_primary_try_chain_16_0);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1004);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i4);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i3);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i5);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i6);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i7);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i8);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i11);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i15);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i16);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1040);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i20);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1044);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i10);
Declare_label(mercury__tag_switch__generate_primary_try_chain_16_0_i23);
Declare_static(mercury__tag_switch__generate_primary_jump_table_15_0);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i1015);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i2);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i9);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i10);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i11);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i13);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i16);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i14);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i17);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i18);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i19);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i21);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i7);
Declare_label(mercury__tag_switch__generate_primary_jump_table_15_0_i22);
Declare_static(mercury__tag_switch__generate_primary_binary_search_16_0);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i7);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i8);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i1038);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i3);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i12);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i13);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i14);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i2);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i20);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i21);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i22);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i23);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i24);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i25);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i26);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i27);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i28);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i29);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i30);
Declare_label(mercury__tag_switch__generate_primary_binary_search_16_0_i31);
Declare_static(mercury__tag_switch__generate_primary_tag_code_14_0);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i2);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i9);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i10);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i11);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i12);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i3);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i18);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i19);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i20);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i21);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i22);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i23);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i24);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i28);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i31);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i32);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i37);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i39);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i1014);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i41);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i38);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i33);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i34);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i46);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i48);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i47);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i51);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i53);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i54);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i55);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i56);
Declare_label(mercury__tag_switch__generate_primary_tag_code_14_0_i57);
Declare_static(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i4);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i3);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i8);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i11);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i14);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1035);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i19);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1049);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i6);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i21);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i22);
Declare_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i23);
Declare_static(mercury__tag_switch__generate_secondary_try_chain_14_0);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1004);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i4);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i3);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i8);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i11);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i14);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1046);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1058);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i6);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i21);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i22);
Declare_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i23);
Declare_static(mercury__tag_switch__generate_secondary_jump_table_13_0);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i1027);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i2);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i9);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i10);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i11);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i12);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i13);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i14);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i16);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i18);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i7);
Declare_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i19);
Declare_static(mercury__tag_switch__get_ptag_counts_4_0);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i4);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i2);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i6);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i8);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i9);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i10);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i11);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i14);
Declare_label(mercury__tag_switch__get_ptag_counts_4_0_i12);
Declare_static(mercury__tag_switch__get_ptag_counts_2_5_0);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i1009);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i6);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i8);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i7);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i4);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i15);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i17);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i19);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i21);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i23);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i16);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i13);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i29);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i31);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i33);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i35);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i37);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i30);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i27);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i41);
Declare_label(mercury__tag_switch__get_ptag_counts_2_5_0_i3);
Declare_static(mercury__tag_switch__group_cases_by_ptag_3_0);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i1009);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i7);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i6);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i10);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i11);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i4);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i17);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i19);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i21);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i23);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i16);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i25);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i26);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i14);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i32);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i34);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i36);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i38);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i31);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i40);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i41);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i29);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i44);
Declare_label(mercury__tag_switch__group_cases_by_ptag_3_0_i3);
Declare_static(mercury__tag_switch__order_ptags_by_count_3_0);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i1003);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i4);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i7);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i9);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i10);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i6);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i2);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i14);
Declare_label(mercury__tag_switch__order_ptags_by_count_3_0_i13);
Declare_static(mercury__tag_switch__select_frequent_ptag_4_0);
Declare_label(mercury__tag_switch__select_frequent_ptag_4_0_i4);
Declare_label(mercury__tag_switch__select_frequent_ptag_4_0_i3);
Declare_label(mercury__tag_switch__select_frequent_ptag_4_0_i1);
Declare_static(mercury__tag_switch__order_ptags_by_value_4_0);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i1003);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i4);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i6);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i7);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i3);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i2);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i11);
Declare_label(mercury__tag_switch__order_ptags_by_value_4_0_i10);
Declare_static(mercury__tag_switch__cons_list_to_tag_list_2_0);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i5);
Declare_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i2);
Declare_static(mercury____Unify___tag_switch__stag_loc_0_0);
Declare_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
Declare_static(mercury____Index___tag_switch__stag_loc_0_0);
Declare_static(mercury____Compare___tag_switch__stag_loc_0_0);
Declare_static(mercury____Unify___tag_switch__stag_goal_map_0_0);
Declare_static(mercury____Index___tag_switch__stag_goal_map_0_0);
Declare_static(mercury____Compare___tag_switch__stag_goal_map_0_0);
Declare_static(mercury____Unify___tag_switch__stag_goal_list_0_0);
Declare_static(mercury____Index___tag_switch__stag_goal_list_0_0);
Declare_static(mercury____Compare___tag_switch__stag_goal_list_0_0);
Declare_static(mercury____Unify___tag_switch__ptag_case_map_0_0);
Declare_static(mercury____Index___tag_switch__ptag_case_map_0_0);
Declare_static(mercury____Compare___tag_switch__ptag_case_map_0_0);
Declare_static(mercury____Unify___tag_switch__ptag_case_list_0_0);
Declare_static(mercury____Index___tag_switch__ptag_case_list_0_0);
Declare_static(mercury____Compare___tag_switch__ptag_case_list_0_0);
Declare_static(mercury____Unify___tag_switch__ptag_count_map_0_0);
Declare_static(mercury____Index___tag_switch__ptag_count_map_0_0);
Declare_static(mercury____Compare___tag_switch__ptag_count_map_0_0);
Declare_static(mercury____Unify___tag_switch__ptag_count_list_0_0);
Declare_static(mercury____Index___tag_switch__ptag_count_list_0_0);
Declare_static(mercury____Compare___tag_switch__ptag_count_list_0_0);
Declare_static(mercury____Unify___tag_switch__switch_method_0_0);
Declare_label(mercury____Unify___tag_switch__switch_method_0_0_i1);
Declare_static(mercury____Index___tag_switch__switch_method_0_0);
Declare_static(mercury____Compare___tag_switch__switch_method_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_case_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_case_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_count_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_count_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_goal_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_goal_map_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_loc_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_switch_method_0;

static const struct mercury_data_tag_switch__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_0;

static const struct mercury_data_tag_switch__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_1;

static const struct mercury_data_tag_switch__common_2_struct {
	Word * f1;
}  mercury_data_tag_switch__common_2;

static const struct mercury_data_tag_switch__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_tag_switch__common_3;

static const struct mercury_data_tag_switch__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_4;

static const struct mercury_data_tag_switch__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_5;

static const struct mercury_data_tag_switch__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_6;

static const struct mercury_data_tag_switch__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_7;

static const struct mercury_data_tag_switch__common_8_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_8;

static const struct mercury_data_tag_switch__common_9_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_9;

static const struct mercury_data_tag_switch__common_10_struct {
	Word * f1;
	String f2;
}  mercury_data_tag_switch__common_10;

static const struct mercury_data_tag_switch__common_11_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_11;

static const struct mercury_data_tag_switch__common_12_struct {
	Word * f1;
}  mercury_data_tag_switch__common_12;

static const struct mercury_data_tag_switch__common_13_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_13;

static const struct mercury_data_tag_switch__common_14_struct {
	String f1;
}  mercury_data_tag_switch__common_14;

static const struct mercury_data_tag_switch__common_15_struct {
	Word * f1;
	String f2;
}  mercury_data_tag_switch__common_15;

static const struct mercury_data_tag_switch__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_16;

static const struct mercury_data_tag_switch__common_17_struct {
	Word * f1;
}  mercury_data_tag_switch__common_17;

static const struct mercury_data_tag_switch__common_18_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_tag_switch__common_18;

static const struct mercury_data_tag_switch__common_19_struct {
	Integer f1;
}  mercury_data_tag_switch__common_19;

static const struct mercury_data_tag_switch__common_20_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_20;

static const struct mercury_data_tag_switch__common_21_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_21;

static const struct mercury_data_tag_switch__common_22_struct {
	Integer f1;
	Integer f2;
}  mercury_data_tag_switch__common_22;

static const struct mercury_data_tag_switch__common_23_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_23;

static const struct mercury_data_tag_switch__common_24_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
}  mercury_data_tag_switch__common_24;

static const struct mercury_data_tag_switch__common_25_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_tag_switch__common_25;

static const struct mercury_data_tag_switch__common_26_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_26;

static const struct mercury_data_tag_switch__common_27_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_27;

static const struct mercury_data_tag_switch__common_28_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_28;

static const struct mercury_data_tag_switch__common_29_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_29;

static const struct mercury_data_tag_switch__common_30_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_30;

static const struct mercury_data_tag_switch__common_31_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_31;

static const struct mercury_data_tag_switch__common_32_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_32;

static const struct mercury_data_tag_switch__common_33_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_tag_switch__common_33;

static const struct mercury_data_tag_switch__common_34_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_34;

static const struct mercury_data_tag_switch__common_35_struct {
	Word * f1;
	Word * f2;
}  mercury_data_tag_switch__common_35;

static const struct mercury_data_tag_switch__common_36_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__common_36;

static const struct mercury_data_tag_switch__type_ctor_functors_switch_method_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_switch_method_0;

static const struct mercury_data_tag_switch__type_ctor_layout_switch_method_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_switch_method_0;

static const struct mercury_data_tag_switch__type_ctor_functors_stag_loc_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_stag_loc_0;

static const struct mercury_data_tag_switch__type_ctor_layout_stag_loc_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_stag_loc_0;

static const struct mercury_data_tag_switch__type_ctor_functors_stag_goal_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_stag_goal_map_0;

static const struct mercury_data_tag_switch__type_ctor_layout_stag_goal_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_stag_goal_map_0;

static const struct mercury_data_tag_switch__type_ctor_functors_stag_goal_list_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_stag_goal_list_0;

static const struct mercury_data_tag_switch__type_ctor_layout_stag_goal_list_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_stag_goal_list_0;

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_count_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_ptag_count_map_0;

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_count_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_ptag_count_map_0;

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_count_list_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_ptag_count_list_0;

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_count_list_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_ptag_count_list_0;

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_case_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_ptag_case_map_0;

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_case_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_ptag_case_map_0;

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_case_list_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_tag_switch__type_ctor_functors_ptag_case_list_0;

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_case_list_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tag_switch__type_ctor_layout_ptag_case_list_0;

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_case_list_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__ptag_case_list_0_0),
	STATIC(mercury____Index___tag_switch__ptag_case_list_0_0),
	STATIC(mercury____Compare___tag_switch__ptag_case_list_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_ptag_case_list_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_ptag_case_list_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("ptag_case_list", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_case_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__ptag_case_map_0_0),
	STATIC(mercury____Index___tag_switch__ptag_case_map_0_0),
	STATIC(mercury____Compare___tag_switch__ptag_case_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_ptag_case_map_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_ptag_case_map_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("ptag_case_map", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_count_list_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__ptag_count_list_0_0),
	STATIC(mercury____Index___tag_switch__ptag_count_list_0_0),
	STATIC(mercury____Compare___tag_switch__ptag_count_list_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_ptag_count_list_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_ptag_count_list_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("ptag_count_list", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_ptag_count_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__ptag_count_map_0_0),
	STATIC(mercury____Index___tag_switch__ptag_count_map_0_0),
	STATIC(mercury____Compare___tag_switch__ptag_count_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_ptag_count_map_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_ptag_count_map_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("ptag_count_map", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_goal_list_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__stag_goal_list_0_0),
	STATIC(mercury____Index___tag_switch__stag_goal_list_0_0),
	STATIC(mercury____Compare___tag_switch__stag_goal_list_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_stag_goal_list_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_stag_goal_list_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("stag_goal_list", 14),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_goal_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__stag_goal_map_0_0),
	STATIC(mercury____Index___tag_switch__stag_goal_map_0_0),
	STATIC(mercury____Compare___tag_switch__stag_goal_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_stag_goal_map_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_stag_goal_map_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("stag_goal_map", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_stag_loc_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__stag_loc_0_0),
	STATIC(mercury____Index___tag_switch__stag_loc_0_0),
	STATIC(mercury____Compare___tag_switch__stag_loc_0_0),
	(Integer) 0,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_stag_loc_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_stag_loc_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("stag_loc", 8),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_tag_switch__type_ctor_info_switch_method_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___tag_switch__switch_method_0_0),
	STATIC(mercury____Index___tag_switch__switch_method_0_0),
	STATIC(mercury____Compare___tag_switch__switch_method_0_0),
	(Integer) 0,
	(Word *) &mercury_data_tag_switch__type_ctor_functors_switch_method_0,
	(Word *) &mercury_data_tag_switch__type_ctor_layout_switch_method_0,
	MR_string_const("tag_switch", 10),
	MR_string_const("switch_method", 13),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0;
static const struct mercury_data_tag_switch__common_0_struct mercury_data_tag_switch__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_expr_0,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_hlds_goal_info_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_tag_switch__common_1_struct mercury_data_tag_switch__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0)
};

static const struct mercury_data_tag_switch__common_2_struct mercury_data_tag_switch__common_2 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_tag_switch__common_3_struct mercury_data_tag_switch__common_3 = {
	(Integer) 0,
	MR_string_const("tag_switch", 10),
	MR_string_const("tag_switch", 10),
	MR_string_const("IntroducedFrom__pred__generate_secondary_binary_search__1068__2", 63),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_tag_switch__common_4_struct mercury_data_tag_switch__common_4 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_tag_switch__common_5_struct mercury_data_tag_switch__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_tag_switch__common_6_struct mercury_data_tag_switch__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_tag_switch__type_ctor_info_stag_loc_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_tag_switch__common_7_struct mercury_data_tag_switch__common_7 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0)
};

static const struct mercury_data_tag_switch__common_8_struct mercury_data_tag_switch__common_8 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_tag_switch__type_ctor_info_stag_loc_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_7)
};

static const struct mercury_data_tag_switch__common_9_struct mercury_data_tag_switch__common_9 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 15))
};

static const struct mercury_data_tag_switch__common_10_struct mercury_data_tag_switch__common_10 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_9),
	MR_string_const("oh-oh, det switch failed", 24)
};

static const struct mercury_data_tag_switch__common_11_struct mercury_data_tag_switch__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_tag_switch__common_12_struct mercury_data_tag_switch__common_12 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_11)
};

static const struct mercury_data_tag_switch__common_13_struct mercury_data_tag_switch__common_13 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8)
};

static const struct mercury_data_tag_switch__common_14_struct mercury_data_tag_switch__common_14 = {
	MR_string_const("fallthrough to last tag value", 29)
};

static const struct mercury_data_tag_switch__common_15_struct mercury_data_tag_switch__common_15 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_14),
	MR_string_const("", 0)
};

static const struct mercury_data_tag_switch__common_16_struct mercury_data_tag_switch__common_16 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_tag_switch__common_17_struct mercury_data_tag_switch__common_17 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_16)
};

static const struct mercury_data_tag_switch__common_18_struct mercury_data_tag_switch__common_18 = {
	(Integer) 0,
	MR_string_const("tag_switch", 10),
	MR_string_const("tag_switch", 10),
	MR_string_const("IntroducedFrom__pred__generate_primary_binary_search__610__1", 60),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13)
};

static const struct mercury_data_tag_switch__common_19_struct mercury_data_tag_switch__common_19 = {
	(Integer) 0
};

static const struct mercury_data_tag_switch__common_20_struct mercury_data_tag_switch__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_19)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
static const struct mercury_data_tag_switch__common_21_struct mercury_data_tag_switch__common_21 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_tag_switch__common_22_struct mercury_data_tag_switch__common_22 = {
	(Integer) 0,
	(Integer) -1
};

static const struct mercury_data_tag_switch__common_23_struct mercury_data_tag_switch__common_23 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6)
};

static const struct mercury_data_tag_switch__common_24_struct mercury_data_tag_switch__common_24 = {
	(Integer) 1,
	(Integer) 4,
	MR_string_const("try_me_else_chain", 17),
	MR_string_const("try_chain", 9),
	MR_string_const("jump_table", 10),
	MR_string_const("binary_search", 13)
};

static const struct mercury_data_tag_switch__common_25_struct mercury_data_tag_switch__common_25 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("none", 4),
	MR_string_const("local", 5),
	MR_string_const("remote", 6)
};

static const struct mercury_data_tag_switch__common_26_struct mercury_data_tag_switch__common_26 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_7)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_tag_switch__common_27_struct mercury_data_tag_switch__common_27 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1)
};

static const struct mercury_data_tag_switch__common_28_struct mercury_data_tag_switch__common_28 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_27)
};

static const struct mercury_data_tag_switch__common_29_struct mercury_data_tag_switch__common_29 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6)
};

static const struct mercury_data_tag_switch__common_30_struct mercury_data_tag_switch__common_30 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_29)
};

static const struct mercury_data_tag_switch__common_31_struct mercury_data_tag_switch__common_31 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_23)
};

static const struct mercury_data_tag_switch__common_32_struct mercury_data_tag_switch__common_32 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_31)
};

static const struct mercury_data_tag_switch__common_33_struct mercury_data_tag_switch__common_33 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8)
};

static const struct mercury_data_tag_switch__common_34_struct mercury_data_tag_switch__common_34 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_33)
};

static const struct mercury_data_tag_switch__common_35_struct mercury_data_tag_switch__common_35 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13)
};

static const struct mercury_data_tag_switch__common_36_struct mercury_data_tag_switch__common_36 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_35)
};

static const struct mercury_data_tag_switch__type_ctor_functors_switch_method_0_struct mercury_data_tag_switch__type_ctor_functors_switch_method_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_24)
};

static const struct mercury_data_tag_switch__type_ctor_layout_switch_method_0_struct mercury_data_tag_switch__type_ctor_layout_switch_method_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_24)
};

static const struct mercury_data_tag_switch__type_ctor_functors_stag_loc_0_struct mercury_data_tag_switch__type_ctor_functors_stag_loc_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_25)
};

static const struct mercury_data_tag_switch__type_ctor_layout_stag_loc_0_struct mercury_data_tag_switch__type_ctor_layout_stag_loc_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_25)
};

static const struct mercury_data_tag_switch__type_ctor_functors_stag_goal_map_0_struct mercury_data_tag_switch__type_ctor_functors_stag_goal_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_7)
};

static const struct mercury_data_tag_switch__type_ctor_layout_stag_goal_map_0_struct mercury_data_tag_switch__type_ctor_layout_stag_goal_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_26),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_26)
};

static const struct mercury_data_tag_switch__type_ctor_functors_stag_goal_list_0_struct mercury_data_tag_switch__type_ctor_functors_stag_goal_list_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_27)
};

static const struct mercury_data_tag_switch__type_ctor_layout_stag_goal_list_0_struct mercury_data_tag_switch__type_ctor_layout_stag_goal_list_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_28),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_28)
};

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_count_map_0_struct mercury_data_tag_switch__type_ctor_functors_ptag_count_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_29)
};

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_count_map_0_struct mercury_data_tag_switch__type_ctor_layout_ptag_count_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_30),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_30)
};

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_count_list_0_struct mercury_data_tag_switch__type_ctor_functors_ptag_count_list_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_31)
};

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_count_list_0_struct mercury_data_tag_switch__type_ctor_layout_ptag_count_list_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_32),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_32)
};

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_case_map_0_struct mercury_data_tag_switch__type_ctor_functors_ptag_case_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_33)
};

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_case_map_0_struct mercury_data_tag_switch__type_ctor_layout_ptag_case_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_34),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_34)
};

static const struct mercury_data_tag_switch__type_ctor_functors_ptag_case_list_0_struct mercury_data_tag_switch__type_ctor_functors_ptag_case_list_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_35)
};

static const struct mercury_data_tag_switch__type_ctor_layout_ptag_case_list_0_struct mercury_data_tag_switch__type_ctor_layout_ptag_case_list_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_36),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_36)
};

Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
Declare_entry(mercury__code_gen__generate_goal_5_0);
Declare_entry(mercury__code_info__generate_branch_end_6_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__list__filter_4_0);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);

BEGIN_MODULE(tag_switch_module0)
	init_entry(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i7);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i8);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i1039);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i3);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i12);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i13);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i14);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i2);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i18);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i19);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i20);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i21);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i22);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i23);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i24);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i25);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i26);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i27);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i28);
	init_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i29);
BEGIN_CODE

/* code for predicate 'generate_secondary_binary_search__ua0'/14 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0);
	MR_incr_sp_push_msg(18, "tag_switch:generate_secondary_binary_search__ua0/14");
	MR_stackvar(18) = (Word) MR_succip;
	if ((r2 != r3))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i3);
	if (((Integer) r6 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i1039);
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i7,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r2 = r1;
	r1 = (Word) MR_string_const("no code for ptag ", 17);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i8,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = MR_stackvar(8);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r3;
	r3 = MR_stackvar(9);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i1039);
	r1 = r9;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r10;
	MR_decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i3);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
	if ((r2 != MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
	MR_stackvar(4) = r5;
	MR_stackvar(6) = r7;
	MR_stackvar(8) = r9;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = r2;
	r2 = r10;
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i13,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i14,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i9);
	r1 = (Word) MR_string_const("goallist not singleton or empty when binary search ends", 55);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i2);
	r12 = r1;
	r14 = (((Integer) r2 + (Integer) r3) / (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r14;
	MR_stackvar(11) = ((Integer) r14 + (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	r3 = r12;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r14;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_3);
	call_localret(ENTRY(mercury__list__filter_4_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i18,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r3 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = r3;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i19,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(17) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i20,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i21,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(11);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i22,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i23,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r2 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("fallthrough for stags ", 22);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" to ", 4);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(15);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i24,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i24);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r2 = MR_stackvar(14);
	MR_stackvar(14) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("code for stags ", 15);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" to ", 4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i25,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i25);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r2 = MR_stackvar(13);
	tag_incr_hp_msg(MR_stackvar(13), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 22;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(3);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(13), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(MR_stackvar(14), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r3;
	r1 = MR_stackvar(17);
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(14), (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i26,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	}
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r10 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(10);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	localcall(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0,
		LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i27),
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i27);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(8) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i28,
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	}
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i28);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r10 = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(1);
	localcall(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0,
		LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i29),
		STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
Define_label(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0_i29);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_binary_search__ua0_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
END_MODULE


BEGIN_MODULE(tag_switch_module1)
	init_entry(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0);
	init_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i3);
	init_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i4);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__get_ptag_counts__1353__0'/5 in mode 0 */
Define_static(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0);
	MR_incr_sp_push_msg(4, "tag_switch:DeforestationIn__pred__get_ptag_counts__1353__0/5");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__tag_switch__cons_list_to_tag_list_2_0),
		mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i4,
		STATIC(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0));
Define_label(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__tag_switch__get_ptag_counts_2_5_0),
		STATIC(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0));
END_MODULE


BEGIN_MODULE(tag_switch_module2)
	init_entry(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0);
	init_label(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generate_secondary_binary_search__1068__2'/2 in mode 0 */
Define_static(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) > (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__tag_switch__IntroducedFrom__pred__generate_secondary_binary_search__1068__2_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module3)
	init_entry(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0);
	init_label(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__generate_primary_binary_search__610__1'/2 in mode 0 */
Define_static(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) > (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__code_info__get_proc_info_3_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__map__count_2_0);
Declare_entry(mercury__code_info__get_globals_3_0);
Declare_entry(mercury__globals__lookup_int_option_3_0);
Declare_entry(mercury__code_info__produce_variable_in_reg_5_0);
Declare_entry(mercury__code_info__acquire_reg_4_0);
Declare_entry(mercury__code_info__release_reg_3_0);
Declare_entry(mercury__code_info__generate_failure_3_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(tag_switch_module4)
	init_entry(mercury__tag_switch__generate_11_0);
	init_label(mercury__tag_switch__generate_11_0_i2);
	init_label(mercury__tag_switch__generate_11_0_i3);
	init_label(mercury__tag_switch__generate_11_0_i4);
	init_label(mercury__tag_switch__generate_11_0_i5);
	init_label(mercury__tag_switch__generate_11_0_i6);
	init_label(mercury__tag_switch__generate_11_0_i7);
	init_label(mercury__tag_switch__generate_11_0_i8);
	init_label(mercury__tag_switch__generate_11_0_i9);
	init_label(mercury__tag_switch__generate_11_0_i10);
	init_label(mercury__tag_switch__generate_11_0_i11);
	init_label(mercury__tag_switch__generate_11_0_i12);
	init_label(mercury__tag_switch__generate_11_0_i13);
	init_label(mercury__tag_switch__generate_11_0_i14);
	init_label(mercury__tag_switch__generate_11_0_i15);
	init_label(mercury__tag_switch__generate_11_0_i16);
	init_label(mercury__tag_switch__generate_11_0_i17);
	init_label(mercury__tag_switch__generate_11_0_i21);
	init_label(mercury__tag_switch__generate_11_0_i22);
	init_label(mercury__tag_switch__generate_11_0_i23);
	init_label(mercury__tag_switch__generate_11_0_i28);
	init_label(mercury__tag_switch__generate_11_0_i30);
	init_label(mercury__tag_switch__generate_11_0_i1008);
	init_label(mercury__tag_switch__generate_11_0_i32);
	init_label(mercury__tag_switch__generate_11_0_i29);
	init_label(mercury__tag_switch__generate_11_0_i24);
	init_label(mercury__tag_switch__generate_11_0_i25);
	init_label(mercury__tag_switch__generate_11_0_i38);
	init_label(mercury__tag_switch__generate_11_0_i41);
	init_label(mercury__tag_switch__generate_11_0_i40);
	init_label(mercury__tag_switch__generate_11_0_i43);
	init_label(mercury__tag_switch__generate_11_0_i44);
	init_label(mercury__tag_switch__generate_11_0_i46);
	init_label(mercury__tag_switch__generate_11_0_i47);
	init_label(mercury__tag_switch__generate_11_0_i48);
	init_label(mercury__tag_switch__generate_11_0_i54);
	init_label(mercury__tag_switch__generate_11_0_i55);
	init_label(mercury__tag_switch__generate_11_0_i56);
	init_label(mercury__tag_switch__generate_11_0_i57);
	init_label(mercury__tag_switch__generate_11_0_i58);
	init_label(mercury__tag_switch__generate_11_0_i59);
BEGIN_CODE

/* code for predicate 'generate'/11 in mode 0 */
Define_entry(mercury__tag_switch__generate_11_0);
	MR_incr_sp_push_msg(20, "tag_switch:generate/11");
	MR_stackvar(20) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r8;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	MR_stackvar(7) = r7;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__tag_switch__generate_11_0_i2,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i2);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__tag_switch__generate_11_0_i3,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i3);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__tag_switch__generate_11_0_i4,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_4);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_5);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__generate_11_0_i5,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__tag_switch__get_ptag_counts_4_0),
		mercury__tag_switch__generate_11_0_i6,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i6);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r3 = r2;
	MR_stackvar(8) = r1;
	MR_stackvar(9) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__generate_11_0_i7,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__generate_11_0_i8,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__tag_switch__group_cases_by_ptag_3_0),
		mercury__tag_switch__generate_11_0_i9,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r3 = r1;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	call_localret(ENTRY(mercury__map__count_2_0),
		mercury__tag_switch__generate_11_0_i10,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = r1;
	r1 = MR_stackvar(11);
	MR_stackvar(11) = r2;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__tag_switch__generate_11_0_i11,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(15) = r2;
	r2 = (Integer) 184;
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_11_0_i12,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(12);
	r2 = (Integer) 188;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_11_0_i13,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(12);
	r2 = (Integer) 189;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_11_0_i14,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	if (((Integer) MR_stackvar(11) < (Integer) MR_stackvar(13)))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i15);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(15);
	MR_stackvar(2) = (Integer) 2;
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_5_0),
		mercury__tag_switch__generate_11_0_i21,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i15);
	if (((Integer) MR_stackvar(11) < (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i16);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(15);
	MR_stackvar(2) = (Integer) 3;
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_5_0),
		mercury__tag_switch__generate_11_0_i21,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i16);
	if (((Integer) MR_stackvar(11) < (Integer) MR_stackvar(14)))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i17);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(15);
	MR_stackvar(2) = (Integer) 1;
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_5_0),
		mercury__tag_switch__generate_11_0_i21,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i17);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(15);
	MR_stackvar(2) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_5_0),
		mercury__tag_switch__generate_11_0_i21,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(13) = r1;
	MR_stackvar(14) = r2;
	r1 = (Integer) 0;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__tag_switch__generate_11_0_i22,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	MR_stackvar(15) = r1;
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__tag_switch__generate_11_0_i23,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	if (((Integer) MR_stackvar(2) == (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i25);
	if (((Integer) MR_stackvar(11) < (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i25);
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(12);
	r2 = (Integer) 124;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_11_0_i28,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i28);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i30);
	r1 = MR_stackvar(18);
	GOTO_LABEL(mercury__tag_switch__generate_11_0_i29);
Define_label(mercury__tag_switch__generate_11_0_i30);
	r2 = MR_stackvar(15);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i32);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i32);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) > (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i24);
Define_label(mercury__tag_switch__generate_11_0_i1008);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r1 = MR_stackvar(18);
	GOTO_LABEL(mercury__tag_switch__generate_11_0_i29);
Define_label(mercury__tag_switch__generate_11_0_i32);
	r1 = (Word) MR_string_const("improper reg in tag switch", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_11_0_i1008,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i29);
	tag_incr_hp_msg(MR_stackvar(11), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_11_0, "llds:instr/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_stackvar(15);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(14);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_string_const("compute tag to switch on", 24);
	MR_field(MR_mktag(3), r4, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(11), (Integer) 0) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_stackvar(12) = r2;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(15);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_11_0_i38,
		ENTRY(mercury__tag_switch__generate_11_0));
	}
Define_label(mercury__tag_switch__generate_11_0_i24);
	r1 = MR_stackvar(18);
Define_label(mercury__tag_switch__generate_11_0_i25);
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_stackvar(12) = r2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_11_0_i38,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i38);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i40);
	MR_stackvar(15) = r1;
	tag_incr_hp_msg(MR_stackvar(16), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(16), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("switch has failed", 17);
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__tag_switch__generate_11_0_i41,
		ENTRY(mercury__tag_switch__generate_11_0));
	}
Define_label(mercury__tag_switch__generate_11_0_i41);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r4 = r2;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(16);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r5;
	MR_stackvar(16) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(17), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	MR_stackvar(19) = r4;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("end of tag switch", 17);
	MR_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r1;
	COMPUTED_GOTO((Unsigned) MR_stackvar(2),
		LABEL(mercury__tag_switch__generate_11_0_i43) AND
		LABEL(mercury__tag_switch__generate_11_0_i46) AND
		LABEL(mercury__tag_switch__generate_11_0_i54) AND
		LABEL(mercury__tag_switch__generate_11_0_i57));
	}
Define_label(mercury__tag_switch__generate_11_0_i40);
	r4 = r2;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(1);
	MR_stackvar(15) = r1;
	tag_incr_hp_msg(MR_stackvar(16), MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), MR_stackvar(16), (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_12);
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("switch has failed", 17);
	MR_field(MR_mktag(2), MR_stackvar(16), (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(17), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	MR_stackvar(19) = r4;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("end of tag switch", 17);
	MR_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 0) = r1;
	COMPUTED_GOTO((Unsigned) MR_stackvar(2),
		LABEL(mercury__tag_switch__generate_11_0_i43) AND
		LABEL(mercury__tag_switch__generate_11_0_i46) AND
		LABEL(mercury__tag_switch__generate_11_0_i54) AND
		LABEL(mercury__tag_switch__generate_11_0_i57));
	}
Define_label(mercury__tag_switch__generate_11_0_i43);
	r1 = MR_stackvar(10);
	r2 = r3;
	call_localret(STATIC(mercury__tag_switch__order_ptags_by_count_3_0),
		mercury__tag_switch__generate_11_0_i44,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i44);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(14);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(15);
	r9 = MR_stackvar(9);
	r10 = MR_stackvar(7);
	r11 = MR_stackvar(19);
	call_localret(STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0),
		mercury__tag_switch__generate_11_0_i59,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i46);
	r1 = MR_stackvar(10);
	r2 = r3;
	call_localret(STATIC(mercury__tag_switch__order_ptags_by_count_3_0),
		mercury__tag_switch__generate_11_0_i47,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i47);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	if (((Integer) MR_stackvar(4) != (Integer) 1))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i48);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_11_0_i48);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__tag_switch__generate_11_0_i48,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i48);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r12 = MR_stackvar(7);
	r9 = MR_stackvar(9);
	r3 = MR_stackvar(14);
	r2 = MR_stackvar(12);
	r8 = MR_stackvar(15);
	r13 = MR_stackvar(19);
	r10 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r11 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__tag_switch__generate_primary_try_chain_16_0),
		mercury__tag_switch__generate_11_0_i59,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i54);
	MR_stackvar(8) = r2;
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__tag_switch__order_ptags_by_value_4_0),
		mercury__tag_switch__generate_11_0_i55,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i55);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = (Integer) 0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(14);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(15);
	r9 = MR_stackvar(9);
	r10 = MR_stackvar(7);
	r11 = MR_stackvar(19);
	call_localret(STATIC(mercury__tag_switch__generate_primary_jump_table_15_0),
		mercury__tag_switch__generate_11_0_i56,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i56);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_11_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_11_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_11_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("switch on primary tag", 21);
	MR_field(MR_mktag(2), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r11, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r7, (Integer) 1) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_succip = (Code *) MR_stackvar(20);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
Define_label(mercury__tag_switch__generate_11_0_i57);
	MR_stackvar(8) = r2;
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__tag_switch__order_ptags_by_value_4_0),
		mercury__tag_switch__generate_11_0_i58,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i58);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r2 = (Integer) 0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(12);
	r5 = MR_stackvar(14);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(4);
	r8 = MR_stackvar(5);
	r9 = MR_stackvar(6);
	r10 = MR_stackvar(15);
	r11 = MR_stackvar(9);
	r12 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r13 = MR_stackvar(19);
	call_localret(STATIC(mercury__tag_switch__generate_primary_binary_search_16_0),
		mercury__tag_switch__generate_11_0_i59,
		ENTRY(mercury__tag_switch__generate_11_0));
Define_label(mercury__tag_switch__generate_11_0_i59);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_11_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = r4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_11_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(16);
	MR_succip = (Code *) MR_stackvar(20);
	MR_decr_sp_pop_msg(20);
	proceed();
	}
END_MODULE


BEGIN_MODULE(tag_switch_module5)
	init_entry(mercury__tag_switch__generate_primary_try_me_else_chain_14_0);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i4);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i3);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i5);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i6);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i7);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i8);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i11);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i15);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i16);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1031);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i20);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i21);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1039);
	init_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i10);
BEGIN_CODE

/* code for predicate 'generate_primary_try_me_else_chain'/14 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_try_me_else_chain_14_0);
	MR_incr_sp_push_msg(19, "tag_switch:generate_primary_try_me_else_chain/14");
	MR_stackvar(19) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i3);
	MR_stackvar(1) = r11;
	r1 = (Word) MR_string_const("generate_primary_try_me_else_chain: empty switch", 48);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i4,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(12) = r4;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(11) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = r9;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i5,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if ((MR_stackvar(13) != r3))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i6);
	MR_stackvar(15) = r2;
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i8);
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i6);
	MR_stackvar(15) = r2;
	r1 = (Word) MR_string_const("secondary tag locations differ in generate_primary_try_me_else_chain", 68);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i7,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	r1 = MR_stackvar(10);
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i8);
	if (((Integer) MR_stackvar(11) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i11);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i10);
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i11);
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i15,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i15);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	MR_stackvar(16) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i16,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	MR_stackvar(17) = r1;
	tag_incr_hp_msg(MR_stackvar(18), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 13;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 2) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(9);
	r11 = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("test primary tag only", 21);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(12);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(18), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(13);
	r5 = MR_stackvar(2);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1031,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1031);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(18);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("handle next primary tag", 23);
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	if (((Integer) MR_stackvar(11) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1039);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(16);
	MR_stackvar(16) = MR_tempr1;
	r2 = r3;
	MR_stackvar(17) = r4;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i20,
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	r11 = r1;
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(16);
	localcall(mercury__tag_switch__generate_primary_try_me_else_chain_14_0,
		LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i21),
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(17);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i1039);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r4;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_me_else_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("primary tag with no code to handle it", 37);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_try_me_else_chain_14_0_i10);
	r11 = r1;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(13);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(19);
	MR_decr_sp_pop_msg(19);
	tailcall(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		STATIC(mercury__tag_switch__generate_primary_try_me_else_chain_14_0));
END_MODULE


BEGIN_MODULE(tag_switch_module6)
	init_entry(mercury__tag_switch__generate_primary_try_chain_16_0);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1004);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i4);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i3);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i5);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i6);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i7);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i8);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i11);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i15);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i16);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1040);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i20);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1044);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i10);
	init_label(mercury__tag_switch__generate_primary_try_chain_16_0_i23);
BEGIN_CODE

/* code for predicate 'generate_primary_try_chain'/16 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_try_chain_16_0);
	MR_incr_sp_push_msg(21, "tag_switch:generate_primary_try_chain/16");
	MR_stackvar(21) = (Word) MR_succip;
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i3);
	MR_stackvar(1) = r13;
	r1 = (Word) MR_string_const("empty list in generate_primary_try_chain", 40);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i4,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(14) = r4;
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(13) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(15) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_stackvar(16) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = r9;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r12;
	MR_stackvar(12) = r13;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i5,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i5);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if ((MR_stackvar(15) != r3))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i6);
	MR_stackvar(17) = r2;
	r1 = MR_stackvar(12);
	GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i8);
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i6);
	MR_stackvar(17) = r2;
	r1 = (Word) MR_string_const("secondary tag locations differ in generate_primary_try_chain", 60);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i7,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	r1 = MR_stackvar(12);
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i8);
	if (((Integer) MR_stackvar(13) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i11);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i10);
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i11);
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i15,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i15);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	MR_stackvar(18) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i16,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	tag_incr_hp_msg(MR_stackvar(19), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_try_chain_16_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_primary_try_chain_16_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_try_chain_16_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(14);
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 2) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("test primary tag only", 21);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(19), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(MR_stackvar(20), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "std_util:pair/2");
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(11);
	r11 = r2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("this primary tag", 16);
	r1 = MR_stackvar(16);
	r2 = MR_stackvar(14);
	MR_field(MR_mktag(1), MR_stackvar(20), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(17);
	r4 = MR_stackvar(15);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i1040,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1040);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 1) = MR_stackvar(10);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(20);
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(19);
	if (((Integer) MR_stackvar(13) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i1044);
	MR_tempr1 = r1;
	r1 = MR_stackvar(18);
	MR_stackvar(18) = MR_tempr1;
	r2 = r3;
	MR_stackvar(19) = r5;
	MR_stackvar(20) = r4;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i20,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
	}
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	r13 = r1;
	r1 = MR_stackvar(13);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(19);
	r11 = MR_stackvar(20);
	r12 = MR_stackvar(18);
	MR_succip = (Code *) MR_stackvar(21);
	GOTO_LABEL(mercury__tag_switch__generate_primary_try_chain_16_0_i1004);
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i1044);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("primary tag with no code to handle it", 37);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i10);
	r11 = r1;
	r1 = MR_stackvar(16);
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(17);
	r4 = MR_stackvar(15);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(11);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_17);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		mercury__tag_switch__generate_primary_try_chain_16_0_i23,
		STATIC(mercury__tag_switch__generate_primary_try_chain_16_0));
Define_label(mercury__tag_switch__generate_primary_try_chain_16_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_try_chain_16_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_tag_switch__common_17);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_try_chain_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r4;
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
	}
END_MODULE


BEGIN_MODULE(tag_switch_module7)
	init_entry(mercury__tag_switch__generate_primary_jump_table_15_0);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i1015);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i2);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i9);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i10);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i11);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i13);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i16);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i14);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i17);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i18);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i19);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i21);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i7);
	init_label(mercury__tag_switch__generate_primary_jump_table_15_0_i22);
BEGIN_CODE

/* code for predicate 'generate_primary_jump_table'/15 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_jump_table_15_0);
	MR_incr_sp_push_msg(17, "tag_switch:generate_primary_jump_table/15");
	MR_stackvar(17) = (Word) MR_succip;
	if (((Integer) r2 <= (Integer) r3))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i1015);
	r1 = r10;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r11;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i1015);
	r1 = (Word) MR_string_const("caselist not empty when reaching limiting primary tag", 53);
	MR_decr_sp_pop_msg(17);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i2);
	r12 = ((Integer) r2 + (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i7);
	r13 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((r2 != r13))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i7);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r4 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(12) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(13) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(14) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = r9;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r12;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i9,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
	}
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if ((MR_stackvar(13) != r3))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i10);
	MR_stackvar(15) = r2;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i13,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i10);
	MR_stackvar(15) = r2;
	r1 = (Word) MR_string_const("secondary tag locations differ in generate_primary_jump_table", 61);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i11,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i13,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_jump_table_15_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r6, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("start of a case in primary tag switch", 37);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	if (((Integer) MR_stackvar(12) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i14);
	r11 = r2;
	MR_stackvar(10) = r1;
	MR_stackvar(16) = r3;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(13);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(9);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i16,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r10 = r1;
	r11 = r3;
	MR_stackvar(9) = r2;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	localcall(mercury__tag_switch__generate_primary_jump_table_15_0,
		LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i21),
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i14);
	MR_stackvar(10) = r1;
	r1 = r2;
	MR_stackvar(16) = r3;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i17,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r11 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(14);
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(13);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(6);
	r9 = MR_stackvar(7);
	r10 = MR_stackvar(9);
	call_localret(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i18,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(9) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_primary_jump_table_15_0_i19,
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
	}
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r11 = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(1);
	localcall(mercury__tag_switch__generate_primary_jump_table_15_0,
		LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i21),
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(16);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i7);
	MR_stackvar(7) = r8;
	r2 = r12;
	localcall(mercury__tag_switch__generate_primary_jump_table_15_0,
		LABEL(mercury__tag_switch__generate_primary_jump_table_15_0_i22),
		STATIC(mercury__tag_switch__generate_primary_jump_table_15_0));
Define_label(mercury__tag_switch__generate_primary_jump_table_15_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_jump_table_15_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_jump_table_15_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module8)
	init_entry(mercury__tag_switch__generate_primary_binary_search_16_0);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i7);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i8);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i1038);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i3);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i12);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i13);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i14);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i2);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i20);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i21);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i22);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i23);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i24);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i25);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i26);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i27);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i28);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i29);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i30);
	init_label(mercury__tag_switch__generate_primary_binary_search_16_0_i31);
BEGIN_CODE

/* code for predicate 'generate_primary_binary_search'/16 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_binary_search_16_0);
	MR_incr_sp_push_msg(21, "tag_switch:generate_primary_binary_search/16");
	MR_stackvar(21) = (Word) MR_succip;
	if ((r2 != r3))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i3);
	if (((Integer) r7 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i1038);
	MR_stackvar(9) = r10;
	MR_stackvar(11) = r12;
	MR_stackvar(12) = r13;
	r1 = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i7,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r2 = r1;
	r1 = (Word) MR_string_const("no code for ptag ", 17);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__tag_switch__generate_primary_binary_search_16_0_i8,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r3;
	r3 = MR_stackvar(12);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i1038);
	r1 = r12;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r13;
	MR_decr_sp_pop_msg(21);
	proceed();
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i3);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
	if ((r2 != MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(11) = r12;
	MR_stackvar(12) = r13;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1), (Integer) 1);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r7 = r3;
	r3 = r11;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i12,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if ((MR_stackvar(2) != MR_const_field(MR_mktag(0), r1, (Integer) 0)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i13);
	r4 = MR_stackvar(2);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	r10 = MR_stackvar(11);
	r11 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i13);
	MR_stackvar(6) = r3;
	r1 = (Word) MR_string_const("secondary tag locations differ in generate_primary_jump_table", 61);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i14,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r2 = MR_stackvar(1);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(7);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	r10 = MR_stackvar(11);
	r11 = MR_stackvar(12);
	r4 = MR_stackvar(2);
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(STATIC(mercury__tag_switch__generate_primary_tag_code_14_0),
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i9);
	r1 = (Word) MR_string_const("caselist not singleton or empty when binary search ends", 55);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i2);
	r15 = r1;
	r17 = (((Integer) r2 + (Integer) r3) / (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r12;
	MR_stackvar(12) = r13;
	MR_stackvar(13) = r17;
	MR_stackvar(14) = ((Integer) r17 + (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	r3 = r15;
	MR_field(MR_mktag(0), r2, (Integer) 3) = r17;
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__tag_switch__IntroducedFrom__pred__generate_primary_binary_search__610__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_18);
	call_localret(ENTRY(mercury__list__filter_4_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i20,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r3 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = r3;
	MR_stackvar(15) = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i21,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(20) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i22,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i23,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	MR_stackvar(18) = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i24,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i24);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	MR_stackvar(19) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i25,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i25);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r2 = MR_stackvar(17);
	MR_stackvar(17) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("fallthrough for ptags ", 22);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" to ", 4);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(18);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i26,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r2 = MR_stackvar(17);
	MR_stackvar(17) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("code for ptags ", 15);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(19);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" to ", 4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i27,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i27);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r2 = MR_stackvar(16);
	tag_incr_hp_msg(MR_stackvar(16), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_binary_search_16_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_primary_binary_search_16_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = (Integer) 22;
	MR_field(MR_mktag(3), r6, (Integer) 2) = MR_stackvar(3);
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(3), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 3) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(17);
	MR_field(MR_mktag(3), r5, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(16), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	tag_incr_hp_msg(MR_stackvar(17), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_binary_search_16_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r3;
	r1 = MR_stackvar(20);
	MR_field(MR_mktag(3), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(17), (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i28,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
	}
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i28);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r13 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(12);
	r3 = MR_stackvar(13);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(11);
	localcall(mercury__tag_switch__generate_primary_binary_search_16_0,
		LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i29),
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i29);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(11) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_primary_binary_search_16_0_i30,
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
	}
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i30);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r13 = r1;
	r1 = MR_stackvar(15);
	r2 = MR_stackvar(14);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r9 = MR_stackvar(8);
	r10 = MR_stackvar(9);
	r11 = MR_stackvar(10);
	r12 = MR_stackvar(1);
	localcall(mercury__tag_switch__generate_primary_binary_search_16_0,
		LABEL(mercury__tag_switch__generate_primary_binary_search_16_0_i31),
		STATIC(mercury__tag_switch__generate_primary_binary_search_16_0));
Define_label(mercury__tag_switch__generate_primary_binary_search_16_0_i31);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_binary_search_16_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_binary_search_16_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(17);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
	}
END_MODULE

Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(tag_switch_module9)
	init_entry(mercury__tag_switch__generate_primary_tag_code_14_0);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i2);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i9);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i10);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i11);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i12);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i3);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i18);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i19);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i20);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i21);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i22);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i23);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i24);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i28);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i31);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i32);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i37);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i39);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i1014);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i41);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i38);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i33);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i34);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i46);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i48);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i47);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i51);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i53);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i54);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i55);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i56);
	init_label(mercury__tag_switch__generate_primary_tag_code_14_0_i57);
BEGIN_CODE

/* code for predicate 'generate_primary_tag_code'/14 in mode 0 */
Define_static(mercury__tag_switch__generate_primary_tag_code_14_0);
	MR_incr_sp_push_msg(15, "tag_switch:generate_primary_tag_code/14");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(10) = r11;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i2,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i2);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i3);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if (((Integer) r2 != (Integer) -1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(1) = r1;
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i9,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i10,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i11,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = r4;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("skip to end of primary tag switch", 33);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i5);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i12);
	r1 = (Word) MR_string_const("no goal for non-shared tag", 26);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i12);
	r1 = (Word) MR_string_const("more than one goal for non-shared tag", 37);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i3);
	r2 = r1;
	r1 = MR_stackvar(10);
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__code_info__get_globals_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i18,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	MR_stackvar(14) = r2;
	r2 = (Integer) 184;
	MR_stackvar(11) = r1;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i19,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(11);
	r2 = (Integer) 189;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i20,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i20);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(11);
	r2 = (Integer) 188;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i21,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	if (((Integer) MR_stackvar(2) < (Integer) MR_stackvar(12)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i22);
	r1 = (Integer) 2;
	r2 = MR_stackvar(14);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i22);
	if (((Integer) MR_stackvar(2) < (Integer) MR_stackvar(13)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i23);
	r1 = (Integer) 3;
	r2 = MR_stackvar(14);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i23);
	if (((Integer) MR_stackvar(2) < (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i24);
	r1 = (Integer) 1;
	r2 = MR_stackvar(14);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i24);
	r1 = (Integer) 0;
	r2 = MR_stackvar(14);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i27);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i28);
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(MR_stackvar(3), MR_mktag(0), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "llds:rval/0");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_primary_tag_code_14_0, "llds:lval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 7;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_tempr1;
	r1 = (Integer) 0;
	MR_stackvar(4) = (Word) MR_string_const("compute remote sec tag to switch on", 35);
	MR_field(MR_mktag(3), r4, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_tag_switch__common_20);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(3), (Integer) 0) = r4;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i31,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i28);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(4);
	r1 = (Integer) 0;
	MR_stackvar(4) = (Word) MR_string_const("compute local sec tag to switch on", 34);
	MR_field(MR_mktag(3), r3, (Integer) 1) = (Integer) 5;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i31,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i31);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i32,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i32);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	if (((Integer) MR_stackvar(1) == (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i34);
	if (((Integer) MR_stackvar(2) < (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i34);
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(11);
	r2 = (Integer) 124;
	call_localret(ENTRY(mercury__globals__lookup_int_option_3_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i37,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i37);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i39);
	r2 = MR_stackvar(10);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i38);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i39);
	r2 = MR_stackvar(12);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i41);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i41);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) > (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i33);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i1014);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r2 = MR_stackvar(10);
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i38);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i41);
	r1 = (Word) MR_string_const("improper reg in tag switch", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i1014,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i38);
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_stackvar(4), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(12);
	MR_stackvar(11) = r1;
	GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i46);
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i33);
	r1 = MR_stackvar(13);
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i34);
	r2 = MR_stackvar(10);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(11) = MR_stackvar(3);
	MR_stackvar(13) = r1;
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i46);
	MR_stackvar(10) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i48,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i48);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r2 = ((Integer) MR_stackvar(2) + (Integer) 1);
	if ((r2 != r1))
		GOTO_LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i47);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	r1 = MR_stackvar(10);
	r4 = MR_stackvar(11);
	r6 = (Integer) 1;
	r10 = MR_stackvar(13);
	COMPUTED_GOTO((Unsigned) MR_stackvar(1),
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i51) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i53) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i55) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i57));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i47);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(8);
	r9 = MR_stackvar(9);
	r1 = MR_stackvar(10);
	r4 = MR_stackvar(11);
	r6 = (Integer) 0;
	r10 = MR_stackvar(13);
	COMPUTED_GOTO((Unsigned) MR_stackvar(1),
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i51) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i53) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i55) AND
		LABEL(mercury__tag_switch__generate_primary_tag_code_14_0_i57));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i51);
	r2 = r4;
	r3 = r5;
	r4 = r6;
	r5 = r7;
	r6 = MR_stackvar(7);
	r7 = r8;
	r8 = r9;
	r9 = r10;
	call_localret(STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i54,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i53);
	r2 = r4;
	r3 = r5;
	r11 = r10;
	r5 = r7;
	r4 = r6;
	r7 = r8;
	r10 = r9;
	r6 = MR_stackvar(7);
	r8 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r9 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i54,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i54);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i55);
	MR_stackvar(11) = r4;
	r4 = r5;
	r5 = r7;
	r7 = r8;
	r8 = r9;
	r2 = (Integer) 0;
	r6 = MR_stackvar(7);
	r9 = r10;
	call_localret(STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0),
		mercury__tag_switch__generate_primary_tag_code_14_0_i56,
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i56);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_primary_tag_code_14_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_primary_tag_code_14_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_primary_tag_code_14_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_primary_tag_code_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(2), r2, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("switch on secondary tag", 23);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
	}
Define_label(mercury__tag_switch__generate_primary_tag_code_14_0_i57);
	r2 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	tailcall(STATIC(mercury__tag_switch__generate_secondary_binary_search__ua0_14_0),
		STATIC(mercury__tag_switch__generate_primary_tag_code_14_0));
END_MODULE


BEGIN_MODULE(tag_switch_module10)
	init_entry(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i4);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i3);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i8);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i11);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i12);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i13);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i14);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1035);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i18);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i19);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1049);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i6);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i21);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i22);
	init_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i23);
BEGIN_CODE

/* code for predicate 'generate_secondary_try_me_else_chain'/12 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0);
	MR_incr_sp_push_msg(16, "tag_switch:generate_secondary_try_me_else_chain/12");
	MR_stackvar(16) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i3);
	MR_stackvar(1) = r9;
	r1 = (Word) MR_string_const("generate_secondary_try_me_else_chain: empty switch", 50);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i4,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i3);
	r12 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r10 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r11 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if (((Integer) r12 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i8);
	MR_stackvar(9) = r12;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r10;
	r1 = r9;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i8);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i6);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	r1 = r9;
	MR_stackvar(9) = r12;
	MR_stackvar(10) = r11;
	MR_stackvar(11) = r10;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	MR_stackvar(12) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = MR_stackvar(10);
	MR_stackvar(10) = r1;
	tag_incr_hp_msg(MR_stackvar(13), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Integer) 13;
	MR_field(MR_mktag(3), r7, (Integer) 2) = MR_stackvar(1);
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 3) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 2) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(11);
	MR_field(MR_mktag(1), MR_stackvar(13), (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("test remote sec tag only", 24);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i13,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = r2;
	MR_stackvar(14) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i14,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = r2;
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1035,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1035);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(13);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(14);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = r2;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "list:list/1");
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r10, (Integer) 1) = (Word) MR_string_const("skip to end of secondary tag switch", 35);
	MR_field(MR_mktag(3), r11, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r10, (Integer) 0) = r11;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r12, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("handle next secondary tag", 25);
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	if (((Integer) MR_stackvar(9) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1049);
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(12);
	r2 = r3;
	MR_stackvar(12) = r4;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i18,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r9 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(10);
	localcall(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0,
		LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i19),
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i1049);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r4;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("secondary tag does not match", 28);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i6);
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(7) = r8;
	MR_stackvar(11) = r10;
	r1 = r10;
	r2 = r9;
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i21,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i22,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i23,
		STATIC(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
Define_label(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_me_else_chain_12_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = r4;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_me_else_chain_12_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("skip to end of secondary tag switch", 35);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
	}
END_MODULE


BEGIN_MODULE(tag_switch_module11)
	init_entry(mercury__tag_switch__generate_secondary_try_chain_14_0);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1004);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i4);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i3);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i8);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i11);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i12);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i13);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i14);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1046);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i18);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1058);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i6);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i21);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i22);
	init_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i23);
BEGIN_CODE

/* code for predicate 'generate_secondary_try_chain'/14 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_try_chain_14_0);
	MR_incr_sp_push_msg(18, "tag_switch:generate_secondary_try_chain/14");
	MR_stackvar(18) = (Word) MR_succip;
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0_i3);
	MR_stackvar(1) = r11;
	r1 = (Word) MR_string_const("generate_secondary_try_chain: empty switch", 42);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i4,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i3);
	r14 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r12 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r13 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	if (((Integer) r14 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0_i8);
	MR_stackvar(11) = r14;
	MR_stackvar(12) = r13;
	MR_stackvar(13) = r12;
	r1 = r11;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i8);
	if (((Integer) r4 != (Integer) 0))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0_i6);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r7;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	r1 = r11;
	MR_stackvar(11) = r14;
	MR_stackvar(12) = r13;
	MR_stackvar(13) = r12;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	MR_stackvar(14) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = MR_stackvar(12);
	tag_incr_hp_msg(MR_stackvar(12), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 3, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 4, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r7, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r7, (Integer) 2) = MR_stackvar(1);
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:rval/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 3) = r8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("test remote sec tag only", 24);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r3;
	MR_field(MR_mktag(1), MR_stackvar(12), (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(MR_stackvar(15), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r3;
	r1 = MR_stackvar(13);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(15), (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("handle next secondary tag", 25);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i13,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = r2;
	MR_stackvar(16) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i14,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = r2;
	MR_stackvar(17) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i1046,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1046);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(15);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(16);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(17);
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = r2;
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(2), r4, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("skip to end of secondary tag switch", 35);
	MR_field(MR_mktag(3), r12, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r11, (Integer) 0) = r12;
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(2), r5, (Integer) 1) = MR_stackvar(12);
	if (((Integer) MR_stackvar(11) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0_i1058);
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(14);
	r2 = r3;
	MR_stackvar(14) = r5;
	MR_stackvar(15) = r4;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i18,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
	}
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r11 = r1;
	r1 = MR_stackvar(11);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r7 = MR_stackvar(6);
	r8 = MR_stackvar(14);
	r9 = MR_stackvar(15);
	r10 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(18);
	GOTO_LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0_i1004);
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i1058);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r9, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r10, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(1), r8, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(0), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(0), r9, (Integer) 1) = (Word) MR_string_const("secondary tag with no code to handle it", 39);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i6);
	MR_stackvar(2) = r3;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r9;
	MR_stackvar(9) = r10;
	MR_stackvar(13) = r12;
	r1 = r12;
	r2 = r11;
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i21,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i22,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i22);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r3 = r2;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_try_chain_14_0_i23,
		STATIC(mercury__tag_switch__generate_secondary_try_chain_14_0));
Define_label(mercury__tag_switch__generate_secondary_try_chain_14_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_try_chain_14_0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r5, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r6, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r6, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = r4;
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "tree:tree/1");
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "list:list/1");
	tag_incr_hp_msg(r11, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "std_util:pair/2");
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_try_chain_14_0, "llds:instr/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_try_chain_14_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r12, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(2), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(2), r8, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r9, (Integer) 0) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(0), r11, (Integer) 1) = (Word) MR_string_const("skip to end of secondary tag switch", 35);
	MR_succip = (Code *) MR_stackvar(18);
	MR_decr_sp_pop_msg(18);
	proceed();
	}
END_MODULE


BEGIN_MODULE(tag_switch_module12)
	init_entry(mercury__tag_switch__generate_secondary_jump_table_13_0);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i1027);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i2);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i9);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i10);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i11);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i12);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i13);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i14);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i16);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i18);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i7);
	init_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i19);
BEGIN_CODE

/* code for predicate 'generate_secondary_jump_table'/13 in mode 0 */
Define_static(mercury__tag_switch__generate_secondary_jump_table_13_0);
	MR_incr_sp_push_msg(14, "tag_switch:generate_secondary_jump_table/13");
	MR_stackvar(14) = (Word) MR_succip;
	if (((Integer) r2 <= (Integer) r3))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i2);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i1027);
	r1 = r8;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r9;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i1027);
	r1 = (Word) MR_string_const("caselist not empty when reaching limiting secondary tag", 55);
	MR_decr_sp_pop_msg(14);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i2);
	r10 = ((Integer) r2 + (Integer) 1);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i7);
	r11 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	if ((r2 != r11))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i7);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r9;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r10;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i9,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	MR_stackvar(10) = r1;
	tag_incr_hp_msg(MR_stackvar(11), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r1 = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), MR_stackvar(11), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("start of case in secondary tag switch", 37);
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i10,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
	}
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i11,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	r3 = r2;
	r2 = MR_stackvar(8);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_gen__generate_goal_5_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i12,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i12);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	r3 = r2;
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__generate_branch_end_6_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i13,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i13);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	if (((Integer) MR_stackvar(9) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i14);
	r8 = r1;
	r11 = r3;
	MR_stackvar(13) = r2;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "list:list/1");
	tag_incr_hp_msg(r14, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "std_util:pair/2");
	tag_incr_hp_msg(r15, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "llds:instr/0");
	MR_field(MR_mktag(3), r15, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_jump_table_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r15, (Integer) 1) = MR_tempr1;
	r9 = r11;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(1), r13, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r14, (Integer) 0) = r15;
	MR_field(MR_mktag(0), r14, (Integer) 1) = (Word) MR_string_const("branch to end of tag switch", 27);
	localcall(mercury__tag_switch__generate_secondary_jump_table_13_0,
		LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i18),
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
	}
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i14);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(12);
	MR_stackvar(12) = MR_tempr1;
	MR_stackvar(13) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__tag_switch__generate_secondary_jump_table_13_0_i16,
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
	}
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i16);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	r9 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = MR_stackvar(12);
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "list:list/1");
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "std_util:pair/2");
	tag_incr_hp_msg(r13, MR_mktag(3), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "llds:instr/0");
	MR_field(MR_mktag(3), r13, (Integer) 0) = (Integer) 5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__tag_switch__generate_secondary_jump_table_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r13, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 0) = r12;
	MR_field(MR_mktag(1), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r12, (Integer) 1) = (Word) MR_string_const("branch to end of tag switch", 27);
	localcall(mercury__tag_switch__generate_secondary_jump_table_13_0,
		LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i18),
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
	}
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i18);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r7, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r7, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r8, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r8, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r9, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "tree:tree/1");
	MR_field(MR_mktag(2), r9, (Integer) 0) = MR_stackvar(13);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), r3, (Integer) 1) = r7;
	MR_field(MR_mktag(2), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i7);
	MR_stackvar(5) = r7;
	r2 = r10;
	localcall(mercury__tag_switch__generate_secondary_jump_table_13_0,
		LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0_i19),
		STATIC(mercury__tag_switch__generate_secondary_jump_table_13_0));
Define_label(mercury__tag_switch__generate_secondary_jump_table_13_0_i19);
	update_prof_current_proc(LABEL(mercury__tag_switch__generate_secondary_jump_table_13_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__tag_switch__generate_secondary_jump_table_13_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
END_MODULE

Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;

BEGIN_MODULE(tag_switch_module13)
	init_entry(mercury__tag_switch__get_ptag_counts_4_0);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i4);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i2);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i6);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i8);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i9);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i10);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i11);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i14);
	init_label(mercury__tag_switch__get_ptag_counts_4_0_i12);
BEGIN_CODE

/* code for predicate 'get_ptag_counts'/4 in mode 0 */
Define_static(mercury__tag_switch__get_ptag_counts_4_0);
	MR_incr_sp_push_msg(3, "tag_switch:get_ptag_counts/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__tag_switch__get_ptag_counts_4_0_i4,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_4_0_i2);
	r1 = MR_stackvar(1);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__tag_switch__get_ptag_counts_4_0_i8,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i2);
	r1 = (Word) MR_string_const("unknown type in tag_switch__get_ptag_counts", 43);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_ptag_counts_4_0_i6,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i6);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__tag_switch__get_ptag_counts_4_0_i8,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_21);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__tag_switch__get_ptag_counts_4_0_i9,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__tag_switch__get_ptag_counts_4_0_i10,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__get_ptag_counts_4_0_i11,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_4_0_i12);
	r3 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__tag_switch__get_ptag_counts_4_0_i14,
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
	}
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_4_0));
	r2 = MR_stackvar(2);
	r3 = (Integer) -1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__tag_switch__DeforestationIn__pred__get_ptag_counts__1353__0_5_0),
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
Define_label(mercury__tag_switch__get_ptag_counts_4_0_i12);
	r1 = (Word) MR_string_const("non-du type in tag_switch__get_ptag_counts", 42);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__get_ptag_counts_4_0));
END_MODULE

Declare_entry(mercury__int__max_3_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(tag_switch_module14)
	init_entry(mercury__tag_switch__get_ptag_counts_2_5_0);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i1009);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i6);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i8);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i7);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i4);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i15);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i17);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i19);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i21);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i23);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i16);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i13);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i29);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i31);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i33);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i35);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i37);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i30);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i27);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i41);
	init_label(mercury__tag_switch__get_ptag_counts_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'get_ptag_counts_2'/5 in mode 0 */
Define_static(mercury__tag_switch__get_ptag_counts_2_5_0);
	MR_incr_sp_push_msg(9, "tag_switch:get_ptag_counts_2/5");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i1009);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i3);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i4);
	r1 = r2;
	r2 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(3) = r2;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i6,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i6);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_ptag_counts_2_5_0_i8,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i7);
	r1 = (Word) MR_string_const("unshared tag is shared", 22);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i7);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_22);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i4);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i13);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i13);
	r1 = r2;
	r2 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(8) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i15,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_ptag_counts_2_5_0_i17,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i16);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i19);
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i23,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i19);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("remote tag is shared with non-remote", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i21,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i23,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__get_ptag_counts_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 2;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i16);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__get_ptag_counts_2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i13);
	if ((MR_tag(r5) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i27);
	if (((Integer) MR_const_field(MR_mktag(3), r5, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i27);
	r1 = r2;
	r2 = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_stackvar(6) = r2;
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i29,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i29);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__get_ptag_counts_2_5_0_i31,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i31);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i30);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i33);
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i37,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i33);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("local tag is shared with non-local", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i35,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i35);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i37,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i37);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__get_ptag_counts_2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i30);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__get_ptag_counts_2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i27);
	MR_stackvar(2) = r4;
	r1 = (Word) MR_string_const("non-du tag in tag_switch__get_ptag_counts_2", 43);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__get_ptag_counts_2_5_0_i41,
		STATIC(mercury__tag_switch__get_ptag_counts_2_5_0));
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i41);
	update_prof_current_proc(LABEL(mercury__tag_switch__get_ptag_counts_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__tag_switch__get_ptag_counts_2_5_0_i1009);
Define_label(mercury__tag_switch__get_ptag_counts_2_5_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module15)
	init_entry(mercury__tag_switch__group_cases_by_ptag_3_0);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i1009);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i7);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i6);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i10);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i11);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i4);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i17);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i19);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i21);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i23);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i16);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i25);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i26);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i14);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i32);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i34);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i36);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i38);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i31);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i40);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i41);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i29);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i44);
	init_label(mercury__tag_switch__group_cases_by_ptag_3_0_i3);
BEGIN_CODE

/* code for predicate 'group_cases_by_ptag'/3 in mode 0 */
Define_static(mercury__tag_switch__group_cases_by_ptag_3_0);
	MR_incr_sp_push_msg(9, "tag_switch:group_cases_by_ptag/3");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i1009);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 3);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i4);
	MR_stackvar(3) = r3;
	r3 = r2;
	MR_stackvar(1) = r2;
	r4 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(4) = r4;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	MR_stackvar(2) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_cases_by_ptag_3_0_i7,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i6);
	r1 = (Word) MR_string_const("unshared tag is shared", 22);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i6);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i10,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	r4 = (Integer) -1;
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i11,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__group_cases_by_ptag_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i4);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i14);
	MR_stackvar(3) = r3;
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	r3 = r2;
	MR_stackvar(1) = r2;
	r4 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(8) = r4;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	MR_stackvar(2) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_cases_by_ptag_3_0_i17,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i17);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i16);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i19);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i23,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i19);
	MR_stackvar(4) = r3;
	r1 = (Word) MR_string_const("remote tag is shared with non-remote", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i21,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i21);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r5 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i23,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i23);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__group_cases_by_ptag_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i16);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i25,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i25);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i26,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i26);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__group_cases_by_ptag_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i14);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i29);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i29);
	MR_stackvar(3) = r3;
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	r3 = r2;
	MR_stackvar(1) = r2;
	r4 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(6) = r4;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	MR_stackvar(2) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__group_cases_by_ptag_3_0_i32,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i32);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i31);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i34);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i38,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i34);
	MR_stackvar(4) = r3;
	r1 = (Word) MR_string_const("local tag is shared with non-local", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i36,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i36);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r5 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i38,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i38);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__group_cases_by_ptag_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i31);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i40,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i40);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i41,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i41);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__tag_switch__group_cases_by_ptag_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i29);
	MR_stackvar(2) = r5;
	r1 = (Word) MR_string_const("non-du tag in tag_switch__group_cases_by_ptag", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__tag_switch__group_cases_by_ptag_3_0_i44,
		STATIC(mercury__tag_switch__group_cases_by_ptag_3_0));
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i44);
	update_prof_current_proc(LABEL(mercury__tag_switch__group_cases_by_ptag_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__tag_switch__group_cases_by_ptag_3_0_i1009);
Define_label(mercury__tag_switch__group_cases_by_ptag_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__delete_3_1);
Declare_entry(mercury__map__is_empty_1_0);

BEGIN_MODULE(tag_switch_module16)
	init_entry(mercury__tag_switch__order_ptags_by_count_3_0);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i1003);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i4);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i7);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i9);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i10);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i6);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i2);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i14);
	init_label(mercury__tag_switch__order_ptags_by_count_3_0_i13);
BEGIN_CODE

/* code for predicate 'order_ptags_by_count'/3 in mode 0 */
Define_static(mercury__tag_switch__order_ptags_by_count_3_0);
	MR_incr_sp_push_msg(5, "tag_switch:order_ptags_by_count/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i1003);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__tag_switch__select_frequent_ptag_4_0),
		mercury__tag_switch__order_ptags_by_count_3_0_i4,
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_count_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_count_3_0_i2);
	MR_stackvar(3) = r4;
	r4 = r2;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__order_ptags_by_count_3_0_i7,
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_count_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_count_3_0_i6);
	MR_stackvar(4) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__tag_switch__order_ptags_by_count_3_0_i9,
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i9);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_count_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	localcall(mercury__tag_switch__order_ptags_by_count_3_0,
		LABEL(mercury__tag_switch__order_ptags_by_count_3_0_i10),
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i10);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_count_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__order_ptags_by_count_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__tag_switch__order_ptags_by_count_3_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i6);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__tag_switch__order_ptags_by_count_3_0_i1003);
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__tag_switch__order_ptags_by_count_3_0_i14,
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i14);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_count_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_count_3_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__tag_switch__order_ptags_by_count_3_0_i13);
	r1 = (Word) MR_string_const("PtagCaseMap0 is not empty in tag_switch__order_ptags_by_count", 61);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__order_ptags_by_count_3_0));
END_MODULE


BEGIN_MODULE(tag_switch_module17)
	init_entry(mercury__tag_switch__select_frequent_ptag_4_0);
	init_label(mercury__tag_switch__select_frequent_ptag_4_0_i4);
	init_label(mercury__tag_switch__select_frequent_ptag_4_0_i3);
	init_label(mercury__tag_switch__select_frequent_ptag_4_0_i1);
BEGIN_CODE

/* code for predicate 'select_frequent_ptag'/4 in mode 0 */
Define_static(mercury__tag_switch__select_frequent_ptag_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__select_frequent_ptag_4_0_i1);
	MR_incr_sp_push_msg(5, "tag_switch:select_frequent_ptag/4");
	MR_stackvar(5) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 1), (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	localcall(mercury__tag_switch__select_frequent_ptag_4_0,
		LABEL(mercury__tag_switch__select_frequent_ptag_4_0_i4),
		STATIC(mercury__tag_switch__select_frequent_ptag_4_0));
Define_label(mercury__tag_switch__select_frequent_ptag_4_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__select_frequent_ptag_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__select_frequent_ptag_4_0_i3);
	if (((Integer) r3 <= (Integer) MR_stackvar(4)))
		GOTO_LABEL(mercury__tag_switch__select_frequent_ptag_4_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__tag_switch__select_frequent_ptag_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	r4 = MR_tempr1;
	r1 = TRUE;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__tag_switch__select_frequent_ptag_4_0_i3);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__tag_switch__select_frequent_ptag_4_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module18)
	init_entry(mercury__tag_switch__order_ptags_by_value_4_0);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i1003);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i4);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i6);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i7);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i3);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i2);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i11);
	init_label(mercury__tag_switch__order_ptags_by_value_4_0_i10);
BEGIN_CODE

/* code for predicate 'order_ptags_by_value'/4 in mode 0 */
Define_static(mercury__tag_switch__order_ptags_by_value_4_0);
	MR_incr_sp_push_msg(6, "tag_switch:order_ptags_by_value/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i1003);
	if (((Integer) r2 < (Integer) r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_value_4_0_i2);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = ((Integer) r4 + (Integer) 1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__tag_switch__order_ptags_by_value_4_0_i4,
		STATIC(mercury__tag_switch__order_ptags_by_value_4_0));
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i4);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_value_4_0_i3);
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__delete_3_1),
		mercury__tag_switch__order_ptags_by_value_4_0_i6,
		STATIC(mercury__tag_switch__order_ptags_by_value_4_0));
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_value_4_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	localcall(mercury__tag_switch__order_ptags_by_value_4_0,
		LABEL(mercury__tag_switch__order_ptags_by_value_4_0_i7),
		STATIC(mercury__tag_switch__order_ptags_by_value_4_0));
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__order_ptags_by_value_4_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__tag_switch__order_ptags_by_value_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i3);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__tag_switch__order_ptags_by_value_4_0_i1003);
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__tag_switch__order_ptags_by_value_4_0_i11,
		STATIC(mercury__tag_switch__order_ptags_by_value_4_0));
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i11);
	update_prof_current_proc(LABEL(mercury__tag_switch__order_ptags_by_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__tag_switch__order_ptags_by_value_4_0_i10);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__tag_switch__order_ptags_by_value_4_0_i10);
	r1 = (Word) MR_string_const("PtagCaseMap0 is not empty in order_ptags_by_value", 49);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__tag_switch__order_ptags_by_value_4_0));
END_MODULE


BEGIN_MODULE(tag_switch_module19)
	init_entry(mercury__tag_switch__cons_list_to_tag_list_2_0);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i5);
	init_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i2);
BEGIN_CODE

/* code for predicate 'cons_list_to_tag_list'/2 in mode 0 */
Define_static(mercury__tag_switch__cons_list_to_tag_list_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tag_switch__cons_list_to_tag_list_2_0_i2);
	r3 = (Word) MR_sp;
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i4);
	while (1) {
	MR_incr_sp_push_msg(1, "tag_switch:cons_list_to_tag_list");
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	break; } /* end while */
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tag_switch__cons_list_to_tag_list_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_decr_sp_pop_msg(1);
	if (((Integer) MR_sp > (Integer) r3))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__tag_switch__cons_list_to_tag_list_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module20)
	init_entry(mercury____Unify___tag_switch__stag_loc_0_0);
	init_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__stag_loc_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___tag_switch__stag_loc_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___tag_switch__stag_loc_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module21)
	init_entry(mercury____Index___tag_switch__stag_loc_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__stag_loc_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(tag_switch_module22)
	init_entry(mercury____Compare___tag_switch__stag_loc_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__stag_loc_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___tag_switch__stag_loc_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(tag_switch_module23)
	init_entry(mercury____Unify___tag_switch__stag_goal_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__stag_goal_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___tag_switch__stag_goal_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(tag_switch_module24)
	init_entry(mercury____Index___tag_switch__stag_goal_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__stag_goal_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___tag_switch__stag_goal_map_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(tag_switch_module25)
	init_entry(mercury____Compare___tag_switch__stag_goal_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__stag_goal_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___tag_switch__stag_goal_map_0_0));
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(tag_switch_module26)
	init_entry(mercury____Unify___tag_switch__stag_goal_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__stag_goal_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___tag_switch__stag_goal_list_0_0));
END_MODULE

Declare_entry(mercury____Index___list__list_1_0);

BEGIN_MODULE(tag_switch_module27)
	init_entry(mercury____Index___tag_switch__stag_goal_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__stag_goal_list_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___tag_switch__stag_goal_list_0_0));
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);

BEGIN_MODULE(tag_switch_module28)
	init_entry(mercury____Compare___tag_switch__stag_goal_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__stag_goal_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_1);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___tag_switch__stag_goal_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module29)
	init_entry(mercury____Unify___tag_switch__ptag_case_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__ptag_case_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___tag_switch__ptag_case_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module30)
	init_entry(mercury____Index___tag_switch__ptag_case_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__ptag_case_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___tag_switch__ptag_case_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module31)
	init_entry(mercury____Compare___tag_switch__ptag_case_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__ptag_case_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_8);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___tag_switch__ptag_case_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module32)
	init_entry(mercury____Unify___tag_switch__ptag_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__ptag_case_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___tag_switch__ptag_case_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module33)
	init_entry(mercury____Index___tag_switch__ptag_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__ptag_case_list_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___tag_switch__ptag_case_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module34)
	init_entry(mercury____Compare___tag_switch__ptag_case_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__ptag_case_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_13);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___tag_switch__ptag_case_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module35)
	init_entry(mercury____Unify___tag_switch__ptag_count_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__ptag_count_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___tag_switch__ptag_count_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module36)
	init_entry(mercury____Index___tag_switch__ptag_count_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__ptag_count_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___tag_switch__ptag_count_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module37)
	init_entry(mercury____Compare___tag_switch__ptag_count_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__ptag_count_map_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_6);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___tag_switch__ptag_count_map_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module38)
	init_entry(mercury____Unify___tag_switch__ptag_count_list_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__ptag_count_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_23);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___tag_switch__ptag_count_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module39)
	init_entry(mercury____Index___tag_switch__ptag_count_list_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__ptag_count_list_0_0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_23);
	tailcall(ENTRY(mercury____Index___list__list_1_0),
		STATIC(mercury____Index___tag_switch__ptag_count_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module40)
	init_entry(mercury____Compare___tag_switch__ptag_count_list_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__ptag_count_list_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_tag_switch__common_23);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___tag_switch__ptag_count_list_0_0));
END_MODULE


BEGIN_MODULE(tag_switch_module41)
	init_entry(mercury____Unify___tag_switch__switch_method_0_0);
	init_label(mercury____Unify___tag_switch__switch_method_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___tag_switch__switch_method_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___tag_switch__switch_method_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___tag_switch__switch_method_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module42)
	init_entry(mercury____Index___tag_switch__switch_method_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___tag_switch__switch_method_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(tag_switch_module43)
	init_entry(mercury____Compare___tag_switch__switch_method_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___tag_switch__switch_method_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		STATIC(mercury____Compare___tag_switch__switch_method_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__tag_switch_maybe_bunch_0(void)
{
	tag_switch_module0();
	tag_switch_module1();
	tag_switch_module2();
	tag_switch_module3();
	tag_switch_module4();
	tag_switch_module5();
	tag_switch_module6();
	tag_switch_module7();
	tag_switch_module8();
	tag_switch_module9();
	tag_switch_module10();
	tag_switch_module11();
	tag_switch_module12();
	tag_switch_module13();
	tag_switch_module14();
	tag_switch_module15();
	tag_switch_module16();
	tag_switch_module17();
	tag_switch_module18();
	tag_switch_module19();
	tag_switch_module20();
	tag_switch_module21();
	tag_switch_module22();
	tag_switch_module23();
	tag_switch_module24();
	tag_switch_module25();
	tag_switch_module26();
	tag_switch_module27();
	tag_switch_module28();
	tag_switch_module29();
	tag_switch_module30();
	tag_switch_module31();
	tag_switch_module32();
	tag_switch_module33();
	tag_switch_module34();
	tag_switch_module35();
	tag_switch_module36();
	tag_switch_module37();
	tag_switch_module38();
	tag_switch_module39();
}

static void mercury__tag_switch_maybe_bunch_1(void)
{
	tag_switch_module40();
	tag_switch_module41();
	tag_switch_module42();
	tag_switch_module43();
}

#endif

void mercury__tag_switch__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__tag_switch__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__tag_switch_maybe_bunch_0();
		mercury__tag_switch_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_ptag_case_list_0,
			tag_switch__ptag_case_list_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_ptag_case_map_0,
			tag_switch__ptag_case_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_ptag_count_list_0,
			tag_switch__ptag_count_list_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_ptag_count_map_0,
			tag_switch__ptag_count_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_stag_goal_list_0,
			tag_switch__stag_goal_list_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_stag_goal_map_0,
			tag_switch__stag_goal_map_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_stag_loc_0,
			tag_switch__stag_loc_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tag_switch__type_ctor_info_switch_method_0,
			tag_switch__switch_method_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
