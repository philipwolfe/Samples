/*
** Automatically generated from `term_errors.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__term_errors__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__term_errors__IntroducedFrom__pred__description__375__7_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__371__6_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__330__5_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__273__4_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__313__3_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__420__2_2_0);
Declare_static(mercury__term_errors__IntroducedFrom__pred__description__291__1_2_0);
Define_extern_entry(mercury__term_errors__report_term_errors_5_0);
Declare_label(mercury__term_errors__report_term_errors_5_0_i2);
Declare_label(mercury__term_errors__report_term_errors_5_0_i6);
Declare_label(mercury__term_errors__report_term_errors_5_0_i7);
Declare_label(mercury__term_errors__report_term_errors_5_0_i3);
Declare_label(mercury__term_errors__report_term_errors_5_0_i8);
Declare_label(mercury__term_errors__report_term_errors_5_0_i9);
Declare_label(mercury__term_errors__report_term_errors_5_0_i10);
Declare_label(mercury__term_errors__report_term_errors_5_0_i13);
Declare_label(mercury__term_errors__report_term_errors_5_0_i12);
Declare_label(mercury__term_errors__report_term_errors_5_0_i17);
Declare_label(mercury__term_errors__report_term_errors_5_0_i18);
Declare_label(mercury__term_errors__report_term_errors_5_0_i16);
Declare_label(mercury__term_errors__report_term_errors_5_0_i20);
Declare_label(mercury__term_errors__report_term_errors_5_0_i21);
Declare_label(mercury__term_errors__report_term_errors_5_0_i22);
Define_extern_entry(mercury__term_errors__indirect_error_1_0);
Declare_label(mercury__term_errors__indirect_error_1_0_i4);
Declare_label(mercury__term_errors__indirect_error_1_0_i10);
Declare_label(mercury__term_errors__indirect_error_1_0_i2);
Declare_label(mercury__term_errors__indirect_error_1_0_i1);
Declare_static(mercury__term_errors__report_arg_size_errors_5_0);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i2);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i6);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i7);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i3);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i8);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i9);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i10);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i12);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i16);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i17);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i15);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i19);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i20);
Declare_label(mercury__term_errors__report_arg_size_errors_5_0_i21);
Declare_static(mercury__term_errors__output_errors_7_0);
Declare_label(mercury__term_errors__output_errors_7_0_i1001);
Declare_label(mercury__term_errors__output_errors_7_0_i4);
Declare_label(mercury__term_errors__output_errors_7_0_i3);
Declare_static(mercury__term_errors__output_error_7_0);
Declare_label(mercury__term_errors__output_error_7_0_i2);
Declare_label(mercury__term_errors__output_error_7_0_i5);
Declare_label(mercury__term_errors__output_error_7_0_i6);
Declare_label(mercury__term_errors__output_error_7_0_i3);
Declare_label(mercury__term_errors__output_error_7_0_i8);
Declare_label(mercury__term_errors__output_error_7_0_i11);
Declare_label(mercury__term_errors__output_error_7_0_i12);
Declare_label(mercury__term_errors__output_error_7_0_i18);
Declare_static(mercury__term_errors__description_5_0);
Declare_label(mercury__term_errors__description_5_0_i4);
Declare_label(mercury__term_errors__description_5_0_i5);
Declare_label(mercury__term_errors__description_5_0_i6);
Declare_label(mercury__term_errors__description_5_0_i7);
Declare_label(mercury__term_errors__description_5_0_i8);
Declare_label(mercury__term_errors__description_5_0_i9);
Declare_label(mercury__term_errors__description_5_0_i10);
Declare_label(mercury__term_errors__description_5_0_i11);
Declare_label(mercury__term_errors__description_5_0_i14);
Declare_label(mercury__term_errors__description_5_0_i13);
Declare_label(mercury__term_errors__description_5_0_i15);
Declare_label(mercury__term_errors__description_5_0_i16);
Declare_label(mercury__term_errors__description_5_0_i17);
Declare_label(mercury__term_errors__description_5_0_i20);
Declare_label(mercury__term_errors__description_5_0_i19);
Declare_label(mercury__term_errors__description_5_0_i21);
Declare_label(mercury__term_errors__description_5_0_i22);
Declare_label(mercury__term_errors__description_5_0_i23);
Declare_label(mercury__term_errors__description_5_0_i24);
Declare_label(mercury__term_errors__description_5_0_i27);
Declare_label(mercury__term_errors__description_5_0_i26);
Declare_label(mercury__term_errors__description_5_0_i28);
Declare_label(mercury__term_errors__description_5_0_i29);
Declare_label(mercury__term_errors__description_5_0_i30);
Declare_label(mercury__term_errors__description_5_0_i33);
Declare_label(mercury__term_errors__description_5_0_i32);
Declare_label(mercury__term_errors__description_5_0_i36);
Declare_label(mercury__term_errors__description_5_0_i34);
Declare_label(mercury__term_errors__description_5_0_i38);
Declare_label(mercury__term_errors__description_5_0_i40);
Declare_label(mercury__term_errors__description_5_0_i41);
Declare_label(mercury__term_errors__description_5_0_i42);
Declare_label(mercury__term_errors__description_5_0_i43);
Declare_label(mercury__term_errors__description_5_0_i44);
Declare_label(mercury__term_errors__description_5_0_i45);
Declare_label(mercury__term_errors__description_5_0_i47);
Declare_label(mercury__term_errors__description_5_0_i50);
Declare_label(mercury__term_errors__description_5_0_i49);
Declare_label(mercury__term_errors__description_5_0_i51);
Declare_label(mercury__term_errors__description_5_0_i52);
Declare_label(mercury__term_errors__description_5_0_i53);
Declare_label(mercury__term_errors__description_5_0_i57);
Declare_label(mercury__term_errors__description_5_0_i54);
Declare_label(mercury__term_errors__description_5_0_i58);
Declare_label(mercury__term_errors__description_5_0_i61);
Declare_label(mercury__term_errors__description_5_0_i62);
Declare_label(mercury__term_errors__description_5_0_i65);
Declare_label(mercury__term_errors__description_5_0_i66);
Declare_label(mercury__term_errors__description_5_0_i64);
Declare_label(mercury__term_errors__description_5_0_i67);
Declare_label(mercury__term_errors__description_5_0_i68);
Declare_static(mercury__term_errors__term_errors_var_bag_description_3_0);
Declare_label(mercury__term_errors__term_errors_var_bag_description_3_0_i2);
Declare_static(mercury__term_errors__term_errors_var_bag_description_2_4_0);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i3);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i4);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i6);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i7);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i5);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i10);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i13);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i16);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i14);
Declare_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i17);
Define_extern_entry(mercury____Unify___term_errors__termination_error_0_0);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i4);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i5);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i7);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i9);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i11);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i13);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i15);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i17);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i19);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i23);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i25);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i29);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i30);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i32);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i36);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i38);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i40);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i44);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i46);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i50);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i52);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i56);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i60);
Declare_label(mercury____Unify___term_errors__termination_error_0_0_i1);
Define_extern_entry(mercury____Index___term_errors__termination_error_0_0);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i4);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i5);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i6);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i7);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i8);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i9);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i10);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i11);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i12);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i13);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i14);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i15);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i16);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i17);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i18);
Declare_label(mercury____Index___term_errors__termination_error_0_0_i19);
Define_extern_entry(mercury____Compare___term_errors__termination_error_0_0);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i2);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i3);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i4);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i5);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i10);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i11);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i13);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i15);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i17);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i19);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i21);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i23);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i26);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i31);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i34);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i39);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i40);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i43);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i48);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i51);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i55);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i61);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i64);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i69);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i72);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i77);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i80);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i7);
Declare_label(mercury____Compare___term_errors__termination_error_0_0_i86);
Define_extern_entry(mercury____Unify___term_errors__error_0_0);
Define_extern_entry(mercury____Index___term_errors__error_0_0);
Define_extern_entry(mercury____Compare___term_errors__error_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_term_errors__type_ctor_info_error_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_errors__type_ctor_info_termination_error_0;

static const struct mercury_data_term_errors__common_0_struct {
	String f1;
}  mercury_data_term_errors__common_0;

static const struct mercury_data_term_errors__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_1;

static const struct mercury_data_term_errors__common_2_struct {
	String f1;
}  mercury_data_term_errors__common_2;

static const struct mercury_data_term_errors__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_3;

static const struct mercury_data_term_errors__common_4_struct {
	String f1;
}  mercury_data_term_errors__common_4;

static const struct mercury_data_term_errors__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_5;

static const struct mercury_data_term_errors__common_6_struct {
	String f1;
}  mercury_data_term_errors__common_6;

static const struct mercury_data_term_errors__common_7_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_7;

static const struct mercury_data_term_errors__common_8_struct {
	String f1;
}  mercury_data_term_errors__common_8;

static const struct mercury_data_term_errors__common_9_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_9;

static const struct mercury_data_term_errors__common_10_struct {
	Integer f1;
}  mercury_data_term_errors__common_10;

static const struct mercury_data_term_errors__common_11_struct {
	String f1;
}  mercury_data_term_errors__common_11;

static const struct mercury_data_term_errors__common_12_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_12;

static const struct mercury_data_term_errors__common_13_struct {
	String f1;
}  mercury_data_term_errors__common_13;

static const struct mercury_data_term_errors__common_14_struct {
	String f1;
}  mercury_data_term_errors__common_14;

static const struct mercury_data_term_errors__common_15_struct {
	String f1;
}  mercury_data_term_errors__common_15;

static const struct mercury_data_term_errors__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_16;

static const struct mercury_data_term_errors__common_17_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_17;

static const struct mercury_data_term_errors__common_18_struct {
	String f1;
}  mercury_data_term_errors__common_18;

static const struct mercury_data_term_errors__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_19;

static const struct mercury_data_term_errors__common_20_struct {
	String f1;
}  mercury_data_term_errors__common_20;

static const struct mercury_data_term_errors__common_21_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_21;

static const struct mercury_data_term_errors__common_22_struct {
	String f1;
	Word * f2;
}  mercury_data_term_errors__common_22;

static const struct mercury_data_term_errors__common_23_struct {
	String f1;
}  mercury_data_term_errors__common_23;

static const struct mercury_data_term_errors__common_24_struct {
	String f1;
}  mercury_data_term_errors__common_24;

static const struct mercury_data_term_errors__common_25_struct {
	String f1;
}  mercury_data_term_errors__common_25;

static const struct mercury_data_term_errors__common_26_struct {
	String f1;
}  mercury_data_term_errors__common_26;

static const struct mercury_data_term_errors__common_27_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_27;

static const struct mercury_data_term_errors__common_28_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_28;

static const struct mercury_data_term_errors__common_29_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_29;

static const struct mercury_data_term_errors__common_30_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_30;

static const struct mercury_data_term_errors__common_31_struct {
	String f1;
}  mercury_data_term_errors__common_31;

static const struct mercury_data_term_errors__common_32_struct {
	String f1;
}  mercury_data_term_errors__common_32;

static const struct mercury_data_term_errors__common_33_struct {
	String f1;
}  mercury_data_term_errors__common_33;

static const struct mercury_data_term_errors__common_34_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_34;

static const struct mercury_data_term_errors__common_35_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_35;

static const struct mercury_data_term_errors__common_36_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_36;

static const struct mercury_data_term_errors__common_37_struct {
	String f1;
}  mercury_data_term_errors__common_37;

static const struct mercury_data_term_errors__common_38_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_38;

static const struct mercury_data_term_errors__common_39_struct {
	String f1;
}  mercury_data_term_errors__common_39;

static const struct mercury_data_term_errors__common_40_struct {
	String f1;
}  mercury_data_term_errors__common_40;

static const struct mercury_data_term_errors__common_41_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_41;

static const struct mercury_data_term_errors__common_42_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_42;

static const struct mercury_data_term_errors__common_43_struct {
	String f1;
}  mercury_data_term_errors__common_43;

static const struct mercury_data_term_errors__common_44_struct {
	String f1;
}  mercury_data_term_errors__common_44;

static const struct mercury_data_term_errors__common_45_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_45;

static const struct mercury_data_term_errors__common_46_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_46;

static const struct mercury_data_term_errors__common_47_struct {
	String f1;
}  mercury_data_term_errors__common_47;

static const struct mercury_data_term_errors__common_48_struct {
	String f1;
}  mercury_data_term_errors__common_48;

static const struct mercury_data_term_errors__common_49_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_49;

static const struct mercury_data_term_errors__common_50_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_50;

static const struct mercury_data_term_errors__common_51_struct {
	String f1;
}  mercury_data_term_errors__common_51;

static const struct mercury_data_term_errors__common_52_struct {
	Word * f1;
}  mercury_data_term_errors__common_52;

static const struct mercury_data_term_errors__common_53_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_53;

static const struct mercury_data_term_errors__common_54_struct {
	String f1;
}  mercury_data_term_errors__common_54;

static const struct mercury_data_term_errors__common_55_struct {
	String f1;
}  mercury_data_term_errors__common_55;

static const struct mercury_data_term_errors__common_56_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_56;

static const struct mercury_data_term_errors__common_57_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_57;

static const struct mercury_data_term_errors__common_58_struct {
	String f1;
}  mercury_data_term_errors__common_58;

static const struct mercury_data_term_errors__common_59_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_59;

static const struct mercury_data_term_errors__common_60_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_60;

static const struct mercury_data_term_errors__common_61_struct {
	String f1;
}  mercury_data_term_errors__common_61;

static const struct mercury_data_term_errors__common_62_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_62;

static const struct mercury_data_term_errors__common_63_struct {
	String f1;
}  mercury_data_term_errors__common_63;

static const struct mercury_data_term_errors__common_64_struct {
	String f1;
}  mercury_data_term_errors__common_64;

static const struct mercury_data_term_errors__common_65_struct {
	String f1;
}  mercury_data_term_errors__common_65;

static const struct mercury_data_term_errors__common_66_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_66;

static const struct mercury_data_term_errors__common_67_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_67;

static const struct mercury_data_term_errors__common_68_struct {
	String f1;
}  mercury_data_term_errors__common_68;

static const struct mercury_data_term_errors__common_69_struct {
	Word * f1;
}  mercury_data_term_errors__common_69;

static const struct mercury_data_term_errors__common_70_struct {
	Word * f1;
}  mercury_data_term_errors__common_70;

static const struct mercury_data_term_errors__common_71_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_71;

static const struct mercury_data_term_errors__common_72_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_term_errors__common_72;

static const struct mercury_data_term_errors__common_73_struct {
	String f1;
}  mercury_data_term_errors__common_73;

static const struct mercury_data_term_errors__common_74_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_74;

static const struct mercury_data_term_errors__common_75_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_75;

static const struct mercury_data_term_errors__common_76_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_term_errors__common_76;

static const struct mercury_data_term_errors__common_77_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_77;

static const struct mercury_data_term_errors__common_78_struct {
	String f1;
}  mercury_data_term_errors__common_78;

static const struct mercury_data_term_errors__common_79_struct {
	String f1;
}  mercury_data_term_errors__common_79;

static const struct mercury_data_term_errors__common_80_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_80;

static const struct mercury_data_term_errors__common_81_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_81;

static const struct mercury_data_term_errors__common_82_struct {
	String f1;
}  mercury_data_term_errors__common_82;

static const struct mercury_data_term_errors__common_83_struct {
	String f1;
}  mercury_data_term_errors__common_83;

static const struct mercury_data_term_errors__common_84_struct {
	String f1;
}  mercury_data_term_errors__common_84;

static const struct mercury_data_term_errors__common_85_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_85;

static const struct mercury_data_term_errors__common_86_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_86;

static const struct mercury_data_term_errors__common_87_struct {
	String f1;
}  mercury_data_term_errors__common_87;

static const struct mercury_data_term_errors__common_88_struct {
	String f1;
}  mercury_data_term_errors__common_88;

static const struct mercury_data_term_errors__common_89_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_89;

static const struct mercury_data_term_errors__common_90_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_90;

static const struct mercury_data_term_errors__common_91_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_91;

static const struct mercury_data_term_errors__common_92_struct {
	String f1;
}  mercury_data_term_errors__common_92;

static const struct mercury_data_term_errors__common_93_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_93;

static const struct mercury_data_term_errors__common_94_struct {
	String f1;
}  mercury_data_term_errors__common_94;

static const struct mercury_data_term_errors__common_95_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_95;

static const struct mercury_data_term_errors__common_96_struct {
	Word * f1;
}  mercury_data_term_errors__common_96;

static const struct mercury_data_term_errors__common_97_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_errors__common_97;

static const struct mercury_data_term_errors__common_98_struct {
	String f1;
}  mercury_data_term_errors__common_98;

static const struct mercury_data_term_errors__common_99_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_99;

static const struct mercury_data_term_errors__common_100_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_100;

static const struct mercury_data_term_errors__common_101_struct {
	String f1;
	Word * f2;
}  mercury_data_term_errors__common_101;

static const struct mercury_data_term_errors__common_102_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_errors__common_102;

static const struct mercury_data_term_errors__common_103_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_errors__common_103;

static const struct mercury_data_term_errors__common_104_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_104;

static const struct mercury_data_term_errors__common_105_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_errors__common_105;

static const struct mercury_data_term_errors__common_106_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_errors__common_106;

static const struct mercury_data_term_errors__common_107_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_errors__common_107;

static const struct mercury_data_term_errors__common_108_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_108;

static const struct mercury_data_term_errors__common_109_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_109;

static const struct mercury_data_term_errors__common_110_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_errors__common_110;

static const struct mercury_data_term_errors__common_111_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_errors__common_111;

static const struct mercury_data_term_errors__common_112_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_errors__common_112;

static const struct mercury_data_term_errors__common_113_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_113;

static const struct mercury_data_term_errors__common_114_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_errors__common_114;

static const struct mercury_data_term_errors__common_115_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_term_errors__common_115;

static const struct mercury_data_term_errors__common_116_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_116;

static const struct mercury_data_term_errors__common_117_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_117;

static const struct mercury_data_term_errors__common_118_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_errors__common_118;

static const struct mercury_data_term_errors__common_119_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
}  mercury_data_term_errors__common_119;

static const struct mercury_data_term_errors__common_120_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
}  mercury_data_term_errors__common_120;

static const struct mercury_data_term_errors__common_121_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_errors__common_121;

static const struct mercury_data_term_errors__common_122_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_errors__common_122;

static const struct mercury_data_term_errors__type_ctor_functors_termination_error_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
	Word * f14;
	Word * f15;
	Word * f16;
}  mercury_data_term_errors__type_ctor_functors_termination_error_0;

static const struct mercury_data_term_errors__type_ctor_layout_termination_error_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_errors__type_ctor_layout_termination_error_0;

static const struct mercury_data_term_errors__type_ctor_functors_error_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_errors__type_ctor_functors_error_0;

static const struct mercury_data_term_errors__type_ctor_layout_error_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_errors__type_ctor_layout_error_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_errors__type_ctor_info_error_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_errors__error_0_0),
	ENTRY(mercury____Index___term_errors__error_0_0),
	ENTRY(mercury____Compare___term_errors__error_0_0),
	(Integer) 6,
	(Word *) &mercury_data_term_errors__type_ctor_functors_error_0,
	(Word *) &mercury_data_term_errors__type_ctor_layout_error_0,
	MR_string_const("term_errors", 11),
	MR_string_const("error", 5),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_errors__type_ctor_info_termination_error_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_errors__termination_error_0_0),
	ENTRY(mercury____Index___term_errors__termination_error_0_0),
	ENTRY(mercury____Compare___term_errors__termination_error_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_errors__type_ctor_functors_termination_error_0,
	(Word *) &mercury_data_term_errors__type_ctor_layout_termination_error_0,
	MR_string_const("term_errors", 11),
	MR_string_const("termination_error", 17),
	(Integer) 3
};

static const struct mercury_data_term_errors__common_0_struct mercury_data_term_errors__common_0 = {
	MR_string_const("Termination of", 14)
};

static const struct mercury_data_term_errors__common_1_struct mercury_data_term_errors__common_1 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_0),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_2_struct mercury_data_term_errors__common_2 = {
	MR_string_const("Termination of the mutually recursive procedures", 48)
};

static const struct mercury_data_term_errors__common_3_struct mercury_data_term_errors__common_3 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_4_struct mercury_data_term_errors__common_4 = {
	MR_string_const("not proven, for unknown reason(s).", 34)
};

static const struct mercury_data_term_errors__common_5_struct mercury_data_term_errors__common_5 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_4),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_6_struct mercury_data_term_errors__common_6 = {
	MR_string_const("not proven for the following reason:", 36)
};

static const struct mercury_data_term_errors__common_7_struct mercury_data_term_errors__common_7 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_8_struct mercury_data_term_errors__common_8 = {
	MR_string_const("not proven for the following reasons:", 37)
};

static const struct mercury_data_term_errors__common_9_struct mercury_data_term_errors__common_9 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_10_struct mercury_data_term_errors__common_10 = {
	(Integer) 1
};

static const struct mercury_data_term_errors__common_11_struct mercury_data_term_errors__common_11 = {
	MR_string_const("Termination constant of", 23)
};

static const struct mercury_data_term_errors__common_12_struct mercury_data_term_errors__common_12 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_13_struct mercury_data_term_errors__common_13 = {
	MR_string_const("set to infinity for the following", 33)
};

static const struct mercury_data_term_errors__common_14_struct mercury_data_term_errors__common_14 = {
	MR_string_const("Termination constants", 21)
};

static const struct mercury_data_term_errors__common_15_struct mercury_data_term_errors__common_15 = {
	MR_string_const("of the mutually recursive procedures", 36)
};

static const struct mercury_data_term_errors__common_16_struct mercury_data_term_errors__common_16 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_17_struct mercury_data_term_errors__common_17 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_14),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_16)
};

static const struct mercury_data_term_errors__common_18_struct mercury_data_term_errors__common_18 = {
	MR_string_const("reason:", 7)
};

static const struct mercury_data_term_errors__common_19_struct mercury_data_term_errors__common_19 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_18),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_20_struct mercury_data_term_errors__common_20 = {
	MR_string_const("reasons:", 8)
};

static const struct mercury_data_term_errors__common_21_struct mercury_data_term_errors__common_21 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_22_struct mercury_data_term_errors__common_22 = {
	MR_string_const(":", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_23_struct mercury_data_term_errors__common_23 = {
	MR_string_const("It depends on the properties of", 31)
};

static const struct mercury_data_term_errors__common_24_struct mercury_data_term_errors__common_24 = {
	MR_string_const("foreign language code included via a", 36)
};

static const struct mercury_data_term_errors__common_25_struct mercury_data_term_errors__common_25 = {
	MR_string_const("`:- pragma c_code'", 18)
};

static const struct mercury_data_term_errors__common_26_struct mercury_data_term_errors__common_26 = {
	MR_string_const("declaration.", 12)
};

static const struct mercury_data_term_errors__common_27_struct mercury_data_term_errors__common_27 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_26),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_28_struct mercury_data_term_errors__common_28 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_25),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_27)
};

static const struct mercury_data_term_errors__common_29_struct mercury_data_term_errors__common_29 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_24),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_28)
};

static const struct mercury_data_term_errors__common_30_struct mercury_data_term_errors__common_30 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_23),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_29)
};

static const struct mercury_data_term_errors__common_31_struct mercury_data_term_errors__common_31 = {
	MR_string_const("It contains one or more", 23)
};

static const struct mercury_data_term_errors__common_32_struct mercury_data_term_errors__common_32 = {
	MR_string_const("predicates and/or functions", 27)
};

static const struct mercury_data_term_errors__common_33_struct mercury_data_term_errors__common_33 = {
	MR_string_const("imported from another module.", 29)
};

static const struct mercury_data_term_errors__common_34_struct mercury_data_term_errors__common_34 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_33),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_35_struct mercury_data_term_errors__common_35 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_32),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_34)
};

static const struct mercury_data_term_errors__common_36_struct mercury_data_term_errors__common_36 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_31),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_35)
};

static const struct mercury_data_term_errors__common_37_struct mercury_data_term_errors__common_37 = {
	MR_string_const("It contains a higher order call.", 32)
};

static const struct mercury_data_term_errors__common_38_struct mercury_data_term_errors__common_38 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_37),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_39_struct mercury_data_term_errors__common_39 = {
	MR_string_const("The analysis was unable to form any constraints", 47)
};

static const struct mercury_data_term_errors__common_40_struct mercury_data_term_errors__common_40 = {
	MR_string_const("between the arguments of this group of procedures.", 50)
};

static const struct mercury_data_term_errors__common_41_struct mercury_data_term_errors__common_41 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_40),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_42_struct mercury_data_term_errors__common_42 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_39),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_41)
};

static const struct mercury_data_term_errors__common_43_struct mercury_data_term_errors__common_43 = {
	MR_string_const("There are too many execution paths", 34)
};

static const struct mercury_data_term_errors__common_44_struct mercury_data_term_errors__common_44 = {
	MR_string_const("for the analysis to process.", 28)
};

static const struct mercury_data_term_errors__common_45_struct mercury_data_term_errors__common_45 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_44),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_46_struct mercury_data_term_errors__common_46 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_43),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_45)
};

static const struct mercury_data_term_errors__common_47_struct mercury_data_term_errors__common_47 = {
	MR_string_const("The solver found the constraints produced", 41)
};

static const struct mercury_data_term_errors__common_48_struct mercury_data_term_errors__common_48 = {
	MR_string_const("by the analysis to be infeasible.", 33)
};

static const struct mercury_data_term_errors__common_49_struct mercury_data_term_errors__common_49 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_48),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_50_struct mercury_data_term_errors__common_50 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_47),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_49)
};

static const struct mercury_data_term_errors__common_51_struct mercury_data_term_errors__common_51 = {
	MR_string_const("calls", 5)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_term_errors__common_52_struct mercury_data_term_errors__common_52 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_term_errors__common_53_struct mercury_data_term_errors__common_53 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__291__1", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52)
};

static const struct mercury_data_term_errors__common_54_struct mercury_data_term_errors__common_54 = {
	MR_string_const("It", 2)
};

static const struct mercury_data_term_errors__common_55_struct mercury_data_term_errors__common_55 = {
	MR_string_const("which could not be proven to terminate.", 39)
};

static const struct mercury_data_term_errors__common_56_struct mercury_data_term_errors__common_56 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_55),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_57_struct mercury_data_term_errors__common_57 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__313__3", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52)
};

static const struct mercury_data_term_errors__common_58_struct mercury_data_term_errors__common_58 = {
	MR_string_const("with one or more higher order arguments.", 40)
};

static const struct mercury_data_term_errors__common_59_struct mercury_data_term_errors__common_59 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_58),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_60_struct mercury_data_term_errors__common_60 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__330__5", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52)
};

static const struct mercury_data_term_errors__common_61_struct mercury_data_term_errors__common_61 = {
	MR_string_const("which has a termination constant of infinity.", 45)
};

static const struct mercury_data_term_errors__common_62_struct mercury_data_term_errors__common_62 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_61),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_63_struct mercury_data_term_errors__common_63 = {
	MR_string_const("The set of output supplier variables of", 39)
};

static const struct mercury_data_term_errors__common_64_struct mercury_data_term_errors__common_64 = {
	MR_string_const("The set of", 10)
};

static const struct mercury_data_term_errors__common_65_struct mercury_data_term_errors__common_65 = {
	MR_string_const("its output supplier variables", 29)
};

static const struct mercury_data_term_errors__common_66_struct mercury_data_term_errors__common_66 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_65),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_67_struct mercury_data_term_errors__common_67 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_64),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_66)
};

static const struct mercury_data_term_errors__common_68_struct mercury_data_term_errors__common_68 = {
	MR_string_const("output supplier variables of", 28)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_term_errors__common_69_struct mercury_data_term_errors__common_69 = {
	(Word *) &mercury_data___type_ctor_info_string_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_error_util__type_ctor_info_format_component_0;
static const struct mercury_data_term_errors__common_70_struct mercury_data_term_errors__common_70 = {
	(Word *) &mercury_data_error_util__type_ctor_info_format_component_0
};

static const struct mercury_data_term_errors__common_71_struct mercury_data_term_errors__common_71 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__371__6", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_69),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_70)
};

static const struct mercury_data_term_errors__common_72_struct mercury_data_term_errors__common_72 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_71),
	STATIC(mercury__term_errors__IntroducedFrom__pred__description__371__6_2_0),
	(Integer) 0
};

static const struct mercury_data_term_errors__common_73_struct mercury_data_term_errors__common_73 = {
	MR_string_const("is not a subset of the head variables", 37)
};

static const struct mercury_data_term_errors__common_74_struct mercury_data_term_errors__common_74 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_73),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_75_struct mercury_data_term_errors__common_75 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__375__7", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_69),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_70)
};

static const struct mercury_data_term_errors__common_76_struct mercury_data_term_errors__common_76 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_75),
	STATIC(mercury__term_errors__IntroducedFrom__pred__description__375__7_2_0),
	(Integer) 0
};

static const struct mercury_data_term_errors__common_77_struct mercury_data_term_errors__common_77 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__273__4", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52)
};

static const struct mercury_data_term_errors__common_78_struct mercury_data_term_errors__common_78 = {
	MR_string_const("with an unbounded increase", 26)
};

static const struct mercury_data_term_errors__common_79_struct mercury_data_term_errors__common_79 = {
	MR_string_const("in the size of the input arguments.", 35)
};

static const struct mercury_data_term_errors__common_80_struct mercury_data_term_errors__common_80 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_79),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_81_struct mercury_data_term_errors__common_81 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_78),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_80)
};

static const struct mercury_data_term_errors__common_82_struct mercury_data_term_errors__common_82 = {
	MR_string_const("At the recursive call to", 24)
};

static const struct mercury_data_term_errors__common_83_struct mercury_data_term_errors__common_83 = {
	MR_string_const("the arguments are", 17)
};

static const struct mercury_data_term_errors__common_84_struct mercury_data_term_errors__common_84 = {
	MR_string_const("not guaranteed to decrease in size.", 35)
};

static const struct mercury_data_term_errors__common_85_struct mercury_data_term_errors__common_85 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_84),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_86_struct mercury_data_term_errors__common_86 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_83),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_85)
};

static const struct mercury_data_term_errors__common_87_struct mercury_data_term_errors__common_87 = {
	MR_string_const("In the recursive cycle", 22)
};

static const struct mercury_data_term_errors__common_88_struct mercury_data_term_errors__common_88 = {
	MR_string_const("through the calls to", 20)
};

static const struct mercury_data_term_errors__common_89_struct mercury_data_term_errors__common_89 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_88),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_90_struct mercury_data_term_errors__common_90 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_87),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_89)
};

static const struct mercury_data_term_errors__common_91_struct mercury_data_term_errors__common_91 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_86),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_92_struct mercury_data_term_errors__common_92 = {
	MR_string_const("It is a builtin predicate.", 26)
};

static const struct mercury_data_term_errors__common_93_struct mercury_data_term_errors__common_93 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_92),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_term_errors__common_94_struct mercury_data_term_errors__common_94 = {
	MR_string_const("There is a `:- pragma does_not_terminate' declaration for", 57)
};

static const struct mercury_data_term_errors__common_95_struct mercury_data_term_errors__common_95 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_94),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
static const struct mercury_data_term_errors__common_96_struct mercury_data_term_errors__common_96 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0
};

static const struct mercury_data_term_errors__common_97_struct mercury_data_term_errors__common_97 = {
	(Integer) 0,
	MR_string_const("term_errors", 11),
	MR_string_const("term_errors", 11),
	MR_string_const("IntroducedFrom__pred__description__420__2", 41),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_96),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_96)
};

static const struct mercury_data_term_errors__common_98_struct mercury_data_term_errors__common_98 = {
	MR_string_const("it.", 3)
};

static const struct mercury_data_term_errors__common_99_struct mercury_data_term_errors__common_99 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_98),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_term_errors__common_100_struct mercury_data_term_errors__common_100 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_term_errors__common_101_struct mercury_data_term_errors__common_101 = {
	MR_string_const("{}", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_term_errors__common_102_struct mercury_data_term_errors__common_102 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

static const struct mercury_data_term_errors__common_103_struct mercury_data_term_errors__common_103 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_string_const("can_loop_proc_called", 20),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_term_errors__common_104_struct mercury_data_term_errors__common_104 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_102)
};

static const struct mercury_data_term_errors__common_105_struct mercury_data_term_errors__common_105 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_104),
	MR_string_const("cycle", 5),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_106_struct mercury_data_term_errors__common_106 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_96),
	MR_string_const("does_not_term_pragma", 20),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 5)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_107_struct mercury_data_term_errors__common_107 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_string_const("horder_args", 11),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_108_struct mercury_data_term_errors__common_108 = {
	(Integer) 0,
	MR_string_const("horder_call", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_109_struct mercury_data_term_errors__common_109 = {
	(Integer) 0,
	MR_string_const("imported_pred", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_110_struct mercury_data_term_errors__common_110 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_string_const("inf_call", 8),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 2)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_111_struct mercury_data_term_errors__common_111 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_string_const("inf_termination_const", 21),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_112_struct mercury_data_term_errors__common_112 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_96),
	MR_string_const("is_builtin", 10),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_113_struct mercury_data_term_errors__common_113 = {
	(Integer) 0,
	MR_string_const("no_eqns", 7),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bag__type_ctor_info_bag_1;
static const struct mercury_data_term_errors__common_114_struct mercury_data_term_errors__common_114 = {
	(Word *) &mercury_data_bag__type_ctor_info_bag_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100)
};

static const struct mercury_data_term_errors__common_115_struct mercury_data_term_errors__common_115 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_52),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_114),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_114),
	MR_string_const("not_subset", 10),
	MR_mkword(MR_mktag(3), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_116_struct mercury_data_term_errors__common_116 = {
	(Integer) 0,
	MR_string_const("pragma_c_code", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_117_struct mercury_data_term_errors__common_117 = {
	(Integer) 0,
	MR_string_const("solver_failed", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_118_struct mercury_data_term_errors__common_118 = {
	(Integer) 0,
	MR_string_const("too_many_paths", 14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_errors__common_119_struct mercury_data_term_errors__common_119 = {
	(Integer) 0,
	(Integer) 6,
	MR_string_const("pragma_c_code", 13),
	MR_string_const("imported_pred", 13),
	MR_string_const("horder_call", 11),
	MR_string_const("no_eqns", 7),
	MR_string_const("too_many_paths", 14),
	MR_string_const("solver_failed", 13)
};

static const struct mercury_data_term_errors__common_120_struct mercury_data_term_errors__common_120 = {
	(Integer) 6,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_111),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_115),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_110),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_105),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_112),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_106)
};

static const struct mercury_data_term_errors__common_121_struct mercury_data_term_errors__common_121 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_term__type_ctor_info_context_0,
	(Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0
};

static const struct mercury_data_term_errors__common_122_struct mercury_data_term_errors__common_122 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_121)
};

static const struct mercury_data_term_errors__type_ctor_functors_termination_error_0_struct mercury_data_term_errors__type_ctor_functors_termination_error_0 = {
	(Integer) 0,
	(Integer) 14,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_103),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_105),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_106),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_107),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_108),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_109),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_110),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_111),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_112),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_113),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_115),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_116),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_117),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_118)
};

static const struct mercury_data_term_errors__type_ctor_layout_termination_error_0_struct mercury_data_term_errors__type_ctor_layout_termination_error_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_119),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_103),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_107),
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_120)
};

static const struct mercury_data_term_errors__type_ctor_functors_error_0_struct mercury_data_term_errors__type_ctor_functors_error_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_121)
};

static const struct mercury_data_term_errors__type_ctor_layout_error_0_struct mercury_data_term_errors__type_ctor_layout_error_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_errors__common_122),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_errors__common_122),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_errors__common_122),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_errors__common_122)
};


BEGIN_MODULE(term_errors_module0)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__375__7_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__375__7'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__375__7_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_errors__IntroducedFrom__pred__description__375__7_2_0, "error_util:format_component/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	proceed();
END_MODULE


BEGIN_MODULE(term_errors_module1)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__371__6_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__371__6'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__371__6_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_errors__IntroducedFrom__pred__description__371__6_2_0, "error_util:format_component/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	proceed();
END_MODULE

Declare_entry(mercury____Unify___hlds_pred__pred_proc_id_0_0);

BEGIN_MODULE(term_errors_module2)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__330__5_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__330__5'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__330__5_2_0);
	r3 = r1;
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		STATIC(mercury__term_errors__IntroducedFrom__pred__description__330__5_2_0));
END_MODULE


BEGIN_MODULE(term_errors_module3)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__273__4_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__273__4'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__273__4_2_0);
	r3 = r1;
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		STATIC(mercury__term_errors__IntroducedFrom__pred__description__273__4_2_0));
END_MODULE


BEGIN_MODULE(term_errors_module4)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__313__3_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__313__3'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__313__3_2_0);
	r3 = r1;
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		STATIC(mercury__term_errors__IntroducedFrom__pred__description__313__3_2_0));
END_MODULE

Declare_entry(mercury____Unify___hlds_pred__pred_id_0_0);

BEGIN_MODULE(term_errors_module5)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__420__2_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__420__2'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__420__2_2_0);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		STATIC(mercury__term_errors__IntroducedFrom__pred__description__420__2_2_0));
END_MODULE


BEGIN_MODULE(term_errors_module6)
	init_entry(mercury__term_errors__IntroducedFrom__pred__description__291__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__description__291__1'/2 in mode 0 */
Define_static(mercury__term_errors__IntroducedFrom__pred__description__291__1_2_0);
	r3 = r1;
	r1 = r2;
	r2 = r3;
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		STATIC(mercury__term_errors__IntroducedFrom__pred__description__291__1_2_0));
END_MODULE

Declare_entry(mercury__term_util__get_context_from_scc_3_0);
Declare_entry(mercury__error_util__describe_one_proc_name_3_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__error_util__describe_several_proc_names_3_0);
Declare_entry(mercury__error_util__write_error_pieces_5_0);

BEGIN_MODULE(term_errors_module7)
	init_entry(mercury__term_errors__report_term_errors_5_0);
	init_label(mercury__term_errors__report_term_errors_5_0_i2);
	init_label(mercury__term_errors__report_term_errors_5_0_i6);
	init_label(mercury__term_errors__report_term_errors_5_0_i7);
	init_label(mercury__term_errors__report_term_errors_5_0_i3);
	init_label(mercury__term_errors__report_term_errors_5_0_i8);
	init_label(mercury__term_errors__report_term_errors_5_0_i9);
	init_label(mercury__term_errors__report_term_errors_5_0_i10);
	init_label(mercury__term_errors__report_term_errors_5_0_i13);
	init_label(mercury__term_errors__report_term_errors_5_0_i12);
	init_label(mercury__term_errors__report_term_errors_5_0_i17);
	init_label(mercury__term_errors__report_term_errors_5_0_i18);
	init_label(mercury__term_errors__report_term_errors_5_0_i16);
	init_label(mercury__term_errors__report_term_errors_5_0_i20);
	init_label(mercury__term_errors__report_term_errors_5_0_i21);
	init_label(mercury__term_errors__report_term_errors_5_0_i22);
BEGIN_CODE

/* code for predicate 'report_term_errors'/5 in mode 0 */
Define_entry(mercury__term_errors__report_term_errors_5_0);
	MR_incr_sp_push_msg(7, "term_errors:report_term_errors/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__term_util__get_context_from_scc_3_0),
		mercury__term_errors__report_term_errors_5_0_i2,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i2);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_term_errors_5_0_i3);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_term_errors_5_0_i3);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(5) = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_1);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__report_term_errors_5_0_i6,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i6);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r2 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__report_term_errors_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__report_term_errors_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_term_errors_5_0_i7,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
	}
Define_label(mercury__term_errors__report_term_errors_5_0_i7);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r2 = r1;
	r3 = MR_stackvar(5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_errors__report_term_errors_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_stackvar(5) = r1;
	GOTO_LABEL(mercury__term_errors__report_term_errors_5_0_i10);
Define_label(mercury__term_errors__report_term_errors_5_0_i3);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_3);
	call_localret(ENTRY(mercury__error_util__describe_several_proc_names_3_0),
		mercury__term_errors__report_term_errors_5_0_i8,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i8);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_term_errors_5_0_i9,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i9);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r2 = r1;
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__term_errors__report_term_errors_5_0_i10);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_term_errors_5_0_i12);
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_term_errors_5_0_i13,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i13);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__error_util__write_error_pieces_5_0),
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i12);
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_term_errors_5_0_i16);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_7);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_term_errors_5_0_i17,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i17);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__report_term_errors_5_0_i18,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i18);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r6 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_errors__output_error_7_0),
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i16);
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_9);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_term_errors_5_0_i20,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i20);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__report_term_errors_5_0_i21,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
Define_label(mercury__term_errors__report_term_errors_5_0_i21);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r6 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_10);
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__term_errors__output_error_7_0),
		mercury__term_errors__report_term_errors_5_0_i22,
		ENTRY(mercury__term_errors__report_term_errors_5_0));
	}
Define_label(mercury__term_errors__report_term_errors_5_0_i22);
	update_prof_current_proc(LABEL(mercury__term_errors__report_term_errors_5_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = (Integer) 2;
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_errors__output_errors_7_0),
		ENTRY(mercury__term_errors__report_term_errors_5_0));
END_MODULE


BEGIN_MODULE(term_errors_module8)
	init_entry(mercury__term_errors__indirect_error_1_0);
	init_label(mercury__term_errors__indirect_error_1_0_i4);
	init_label(mercury__term_errors__indirect_error_1_0_i10);
	init_label(mercury__term_errors__indirect_error_1_0_i2);
	init_label(mercury__term_errors__indirect_error_1_0_i1);
BEGIN_CODE

/* code for predicate 'indirect_error'/1 in mode 0 */
Define_entry(mercury__term_errors__indirect_error_1_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__term_errors__indirect_error_1_0_i4) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i2) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i2) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i10));
Define_label(mercury__term_errors__indirect_error_1_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__term_errors__indirect_error_1_0_i2) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i2) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i2) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1));
Define_label(mercury__term_errors__indirect_error_1_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i1) AND
		LABEL(mercury__term_errors__indirect_error_1_0_i2));
Define_label(mercury__term_errors__indirect_error_1_0_i2);
	r1 = TRUE;
	proceed();
Define_label(mercury__term_errors__indirect_error_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(term_errors_module9)
	init_entry(mercury__term_errors__report_arg_size_errors_5_0);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i2);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i6);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i7);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i3);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i8);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i9);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i10);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i12);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i16);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i17);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i15);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i19);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i20);
	init_label(mercury__term_errors__report_arg_size_errors_5_0_i21);
BEGIN_CODE

/* code for predicate 'report_arg_size_errors'/5 in mode 0 */
Define_static(mercury__term_errors__report_arg_size_errors_5_0);
	MR_incr_sp_push_msg(7, "term_errors:report_arg_size_errors/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__term_util__get_context_from_scc_3_0),
		mercury__term_errors__report_arg_size_errors_5_0_i2,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i2);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_arg_size_errors_5_0_i3);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 1);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_arg_size_errors_5_0_i3);
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(5) = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_12);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__report_arg_size_errors_5_0_i6,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i6);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r2 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__report_arg_size_errors_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__report_arg_size_errors_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_arg_size_errors_5_0_i7,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
	}
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i7);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r2 = r1;
	r3 = MR_stackvar(5);
	r1 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_13);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__report_arg_size_errors_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_stackvar(5) = MR_tempr1;
	GOTO_LABEL(mercury__term_errors__report_arg_size_errors_5_0_i10);
	}
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i3);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_17);
	call_localret(ENTRY(mercury__error_util__describe_several_proc_names_3_0),
		mercury__term_errors__report_arg_size_errors_5_0_i8,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i8);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_arg_size_errors_5_0_i9,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i9);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_13);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i10);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_arg_size_errors_5_0_i12);
	r1 = (Word) MR_string_const("empty list of errors", 20);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i12);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__report_arg_size_errors_5_0_i15);
	r4 = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__report_arg_size_errors_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_19);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_arg_size_errors_5_0_i16,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i16);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__report_arg_size_errors_5_0_i17,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i17);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r6 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_errors__output_error_7_0),
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i15);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__report_arg_size_errors_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_21);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__report_arg_size_errors_5_0_i19,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i19);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__report_arg_size_errors_5_0_i20,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i20);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r6 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_10);
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	call_localret(STATIC(mercury__term_errors__output_error_7_0),
		mercury__term_errors__report_arg_size_errors_5_0_i21,
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
	}
Define_label(mercury__term_errors__report_arg_size_errors_5_0_i21);
	update_prof_current_proc(LABEL(mercury__term_errors__report_arg_size_errors_5_0));
	r6 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = (Integer) 2;
	r4 = (Integer) 0;
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_errors__output_errors_7_0),
		STATIC(mercury__term_errors__report_arg_size_errors_5_0));
END_MODULE


BEGIN_MODULE(term_errors_module10)
	init_entry(mercury__term_errors__output_errors_7_0);
	init_label(mercury__term_errors__output_errors_7_0_i1001);
	init_label(mercury__term_errors__output_errors_7_0_i4);
	init_label(mercury__term_errors__output_errors_7_0_i3);
BEGIN_CODE

/* code for predicate 'output_errors'/7 in mode 0 */
Define_static(mercury__term_errors__output_errors_7_0);
	MR_incr_sp_push_msg(6, "term_errors:output_errors/7");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__term_errors__output_errors_7_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__output_errors_7_0_i3);
	MR_stackvar(2) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__output_errors_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_tempr1;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__term_errors__output_error_7_0),
		mercury__term_errors__output_errors_7_0_i4,
		STATIC(mercury__term_errors__output_errors_7_0));
	}
Define_label(mercury__term_errors__output_errors_7_0_i4);
	update_prof_current_proc(LABEL(mercury__term_errors__output_errors_7_0));
	r6 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = ((Integer) MR_stackvar(2) + (Integer) 1);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__term_errors__output_errors_7_0_i1001);
Define_label(mercury__term_errors__output_errors_7_0_i3);
	r1 = r6;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__term_util__lookup_proc_arg_size_info_3_0);

BEGIN_MODULE(term_errors_module11)
	init_entry(mercury__term_errors__output_error_7_0);
	init_label(mercury__term_errors__output_error_7_0_i2);
	init_label(mercury__term_errors__output_error_7_0_i5);
	init_label(mercury__term_errors__output_error_7_0_i6);
	init_label(mercury__term_errors__output_error_7_0_i3);
	init_label(mercury__term_errors__output_error_7_0_i8);
	init_label(mercury__term_errors__output_error_7_0_i11);
	init_label(mercury__term_errors__output_error_7_0_i12);
	init_label(mercury__term_errors__output_error_7_0_i18);
BEGIN_CODE

/* code for predicate 'output_error'/7 in mode 0 */
Define_static(mercury__term_errors__output_error_7_0);
	MR_incr_sp_push_msg(7, "term_errors:output_error/7");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r3 = r5;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	call_localret(STATIC(mercury__term_errors__description_5_0),
		mercury__term_errors__output_error_7_0_i2,
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i2);
	update_prof_current_proc(LABEL(mercury__term_errors__output_error_7_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__output_error_7_0_i3);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(1) = r3;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__term_errors__output_error_7_0_i5,
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i5);
	update_prof_current_proc(LABEL(mercury__term_errors__output_error_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__output_error_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("Reason ", 7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__output_error_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_22);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__term_errors__output_error_7_0_i6,
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i6);
	update_prof_current_proc(LABEL(mercury__term_errors__output_error_7_0));
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__output_error_7_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__output_error_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__output_error_7_0_i8,
		STATIC(mercury__term_errors__output_error_7_0));
	}
Define_label(mercury__term_errors__output_error_7_0_i3);
	r3 = r1;
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__error_util__write_error_pieces_5_0),
		mercury__term_errors__output_error_7_0_i8,
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i8);
	update_prof_current_proc(LABEL(mercury__term_errors__output_error_7_0));
	if (((Integer) MR_stackvar(6) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__output_error_7_0_i18);
	MR_stackvar(2) = r1;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(6), (Integer) 0);
	MR_stackvar(1) = r2;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term_util__lookup_proc_arg_size_info_3_0),
		mercury__term_errors__output_error_7_0_i11,
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i11);
	update_prof_current_proc(LABEL(mercury__term_errors__output_error_7_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__output_error_7_0_i12);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__term_errors__output_error_7_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__output_error_7_0, "origin_lost_in_value_number");
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(STATIC(mercury__term_errors__report_arg_size_errors_5_0),
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i12);
	r1 = (Word) MR_string_const("inf arg size procedure does not have inf arg size", 49);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__term_errors__output_error_7_0));
Define_label(mercury__term_errors__output_error_7_0_i18);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__require__require_2_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_varset_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__list__condense_2_0);
Declare_entry(mercury__error_util__describe_one_call_site_3_0);
Declare_entry(mercury__error_util__describe_several_call_sites_3_0);
Declare_entry(mercury__error_util__describe_one_pred_name_3_0);
Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(term_errors_module12)
	init_entry(mercury__term_errors__description_5_0);
	init_label(mercury__term_errors__description_5_0_i4);
	init_label(mercury__term_errors__description_5_0_i5);
	init_label(mercury__term_errors__description_5_0_i6);
	init_label(mercury__term_errors__description_5_0_i7);
	init_label(mercury__term_errors__description_5_0_i8);
	init_label(mercury__term_errors__description_5_0_i9);
	init_label(mercury__term_errors__description_5_0_i10);
	init_label(mercury__term_errors__description_5_0_i11);
	init_label(mercury__term_errors__description_5_0_i14);
	init_label(mercury__term_errors__description_5_0_i13);
	init_label(mercury__term_errors__description_5_0_i15);
	init_label(mercury__term_errors__description_5_0_i16);
	init_label(mercury__term_errors__description_5_0_i17);
	init_label(mercury__term_errors__description_5_0_i20);
	init_label(mercury__term_errors__description_5_0_i19);
	init_label(mercury__term_errors__description_5_0_i21);
	init_label(mercury__term_errors__description_5_0_i22);
	init_label(mercury__term_errors__description_5_0_i23);
	init_label(mercury__term_errors__description_5_0_i24);
	init_label(mercury__term_errors__description_5_0_i27);
	init_label(mercury__term_errors__description_5_0_i26);
	init_label(mercury__term_errors__description_5_0_i28);
	init_label(mercury__term_errors__description_5_0_i29);
	init_label(mercury__term_errors__description_5_0_i30);
	init_label(mercury__term_errors__description_5_0_i33);
	init_label(mercury__term_errors__description_5_0_i32);
	init_label(mercury__term_errors__description_5_0_i36);
	init_label(mercury__term_errors__description_5_0_i34);
	init_label(mercury__term_errors__description_5_0_i38);
	init_label(mercury__term_errors__description_5_0_i40);
	init_label(mercury__term_errors__description_5_0_i41);
	init_label(mercury__term_errors__description_5_0_i42);
	init_label(mercury__term_errors__description_5_0_i43);
	init_label(mercury__term_errors__description_5_0_i44);
	init_label(mercury__term_errors__description_5_0_i45);
	init_label(mercury__term_errors__description_5_0_i47);
	init_label(mercury__term_errors__description_5_0_i50);
	init_label(mercury__term_errors__description_5_0_i49);
	init_label(mercury__term_errors__description_5_0_i51);
	init_label(mercury__term_errors__description_5_0_i52);
	init_label(mercury__term_errors__description_5_0_i53);
	init_label(mercury__term_errors__description_5_0_i57);
	init_label(mercury__term_errors__description_5_0_i54);
	init_label(mercury__term_errors__description_5_0_i58);
	init_label(mercury__term_errors__description_5_0_i61);
	init_label(mercury__term_errors__description_5_0_i62);
	init_label(mercury__term_errors__description_5_0_i65);
	init_label(mercury__term_errors__description_5_0_i66);
	init_label(mercury__term_errors__description_5_0_i64);
	init_label(mercury__term_errors__description_5_0_i67);
	init_label(mercury__term_errors__description_5_0_i68);
BEGIN_CODE

/* code for predicate 'description'/5 in mode 0 */
Define_static(mercury__term_errors__description_5_0);
	MR_incr_sp_push_msg(8, "term_errors:description/5");
	MR_stackvar(8) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__term_errors__description_5_0_i4) AND
		LABEL(mercury__term_errors__description_5_0_i11) AND
		LABEL(mercury__term_errors__description_5_0_i17) AND
		LABEL(mercury__term_errors__description_5_0_i23));
Define_label(mercury__term_errors__description_5_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__term_errors__description_5_0_i5) AND
		LABEL(mercury__term_errors__description_5_0_i6) AND
		LABEL(mercury__term_errors__description_5_0_i7) AND
		LABEL(mercury__term_errors__description_5_0_i8) AND
		LABEL(mercury__term_errors__description_5_0_i9) AND
		LABEL(mercury__term_errors__description_5_0_i10));
Define_label(mercury__term_errors__description_5_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_30);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_36);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_38);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_42);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_46);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i10);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_50);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i13);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i14,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i14);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i16,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i13);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__term_errors__description_5_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_53);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__term_errors__IntroducedFrom__pred__description__291__1_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Word) MR_string_const("caller outside this SCC", 23);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__term_errors__description_5_0_i15,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i15);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_54);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i16,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i16);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_56);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__term_errors__description_5_0_i17);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i19);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i20,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i20);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i22,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i19);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__term_errors__description_5_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_57);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__term_errors__IntroducedFrom__pred__description__313__3_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(2), r4, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Word) MR_string_const("caller outside this SCC", 23);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__term_errors__description_5_0_i21,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i21);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_54);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i22,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i22);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_59);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__term_errors__description_5_0_i23);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__term_errors__description_5_0_i24) AND
		LABEL(mercury__term_errors__description_5_0_i30) AND
		LABEL(mercury__term_errors__description_5_0_i47) AND
		LABEL(mercury__term_errors__description_5_0_i53) AND
		LABEL(mercury__term_errors__description_5_0_i61) AND
		LABEL(mercury__term_errors__description_5_0_i62));
Define_label(mercury__term_errors__description_5_0_i24);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i26);
	MR_stackvar(1) = r3;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_tempr2;
	MR_stackvar(3) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = MR_tempr1;
	r1 = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i27,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i27);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i29,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i26);
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	r4 = r1;
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__term_errors__description_5_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_60);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__term_errors__IntroducedFrom__pred__description__330__5_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Word) MR_string_const("caller outside this SCC", 23);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__term_errors__description_5_0_i28,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i28);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_54);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i29,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i29);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_62);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__term_errors__description_5_0_i30);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i32);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i33,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i33);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_63);
	MR_stackvar(5) = r3;
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_tempr2 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr4, (Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 1) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (Integer) 0) = MR_tempr4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_errors__description_5_0_i40,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i32);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury__term_errors__description_5_0_i36,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i36);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_errors__description_5_0_i34);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(1);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_67);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_errors__description_5_0_i40,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i34);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i38,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i38);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_64);
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_68);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4;
	MR_tempr1 = MR_stackvar(2);
	MR_tempr2 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_tempr3 = r3;
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(MR_tempr4, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr4, (Integer) 0) = MR_tempr2;
	MR_field(MR_mktag(1), MR_stackvar(5), (Integer) 1) = MR_tempr3;
	MR_field(MR_mktag(1), MR_tempr3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_errors__description_5_0_i40,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i40);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_varset_2_0),
		mercury__term_errors__description_5_0_i41,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i41);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__term_errors__term_errors_var_bag_description_3_0),
		mercury__term_errors__description_5_0_i42,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i42);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_72);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__term_errors__description_5_0_i43,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i43);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_74);
	call_localret(STATIC(mercury__term_errors__term_errors_var_bag_description_3_0),
		mercury__term_errors__description_5_0_i44,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i44);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_76);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__term_errors__description_5_0_i45,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i45);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_74);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__term_errors__description_5_0_i68,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i47);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i49);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i50,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i50);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i52,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i49);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__term_errors__description_5_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_77);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__term_errors__IntroducedFrom__pred__description__273__4_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = (Word) MR_string_const("caller outside this SCC", 23);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__term_errors__description_5_0_i51,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i51);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_54);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_51);
	call_localret(ENTRY(mercury__error_util__describe_one_proc_name_3_0),
		mercury__term_errors__description_5_0_i52,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i52);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_81);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__term_errors__description_5_0_i53);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i54);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i54);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = r3;
	call_localret(ENTRY(mercury__error_util__describe_one_call_site_3_0),
		mercury__term_errors__description_5_0_i57,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i57);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_term_errors__common_82);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_86);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__term_errors__description_5_0_i68);
	}
Define_label(mercury__term_errors__description_5_0_i54);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_90);
	r1 = r3;
	call_localret(ENTRY(mercury__error_util__describe_several_call_sites_3_0),
		mercury__term_errors__description_5_0_i58,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i58);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_90);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_91);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__term_errors__description_5_0_i68,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i61);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_93);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_errors__description_5_0_i62);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__description_5_0_i64);
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_95);
	call_localret(ENTRY(mercury__error_util__describe_one_pred_name_3_0),
		mercury__term_errors__description_5_0_i65,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i65);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = (Word) MR_string_const(".", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_errors__description_5_0_i66,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i66);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_errors__description_5_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__term_errors__description_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__description_5_0_i68,
		STATIC(mercury__term_errors__description_5_0));
	}
Define_label(mercury__term_errors__description_5_0_i64);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_95);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__term_errors__description_5_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_97);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__term_errors__IntroducedFrom__pred__description__420__2_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 0);
	r2 = (Word) MR_string_const("does not terminate pragma outside this SCC", 42);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__term_errors__description_5_0_i67,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i67);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_99);
	r1 = (Word) (Word *) &mercury_data_error_util__type_ctor_info_format_component_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_errors__description_5_0_i68,
		STATIC(mercury__term_errors__description_5_0));
Define_label(mercury__term_errors__description_5_0_i68);
	update_prof_current_proc(LABEL(mercury__term_errors__description_5_0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__bag__to_assoc_list_2_0);

BEGIN_MODULE(term_errors_module13)
	init_entry(mercury__term_errors__term_errors_var_bag_description_3_0);
	init_label(mercury__term_errors__term_errors_var_bag_description_3_0_i2);
BEGIN_CODE

/* code for predicate 'term_errors_var_bag_description'/3 in mode 0 */
Define_static(mercury__term_errors__term_errors_var_bag_description_3_0);
	MR_incr_sp_push_msg(2, "term_errors:term_errors_var_bag_description/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100);
	call_localret(ENTRY(mercury__bag__to_assoc_list_2_0),
		mercury__term_errors__term_errors_var_bag_description_3_0_i2,
		STATIC(mercury__term_errors__term_errors_var_bag_description_3_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_3_0_i2);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_3_0));
	r2 = MR_stackvar(1);
	r3 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0),
		STATIC(mercury__term_errors__term_errors_var_bag_description_3_0));
END_MODULE

Declare_entry(mercury__varset__lookup_name_3_0);

BEGIN_MODULE(term_errors_module14)
	init_entry(mercury__term_errors__term_errors_var_bag_description_2_4_0);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i3);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i4);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i6);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i7);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i5);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i10);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i13);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i16);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i14);
	init_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i17);
BEGIN_CODE

/* code for predicate 'term_errors_var_bag_description_2'/4 in mode 0 */
Define_static(mercury__term_errors__term_errors_var_bag_description_2_4_0);
	MR_incr_sp_push_msg(5, "term_errors:term_errors_var_bag_description_2/4");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_errors__common_101);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__varset__lookup_name_3_0),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i4,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	}
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	if (((Integer) MR_stackvar(3) <= (Integer) 1))
		GOTO_LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0_i5);
	r2 = (Word) MR_string_const("*", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i6,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i7,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i7);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i5,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	r2 = r1;
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0_i10);
	r1 = (Word) MR_string_const("{", 1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i13,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i10);
	r1 = r2;
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i13);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0_i14);
	r2 = (Word) MR_string_const("}.", 2);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__term_errors__term_errors_var_bag_description_2_4_0_i16,
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i16);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__term_errors_var_bag_description_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i14);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	localcall(mercury__term_errors__term_errors_var_bag_description_2_4_0,
		LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0_i17),
		STATIC(mercury__term_errors__term_errors_var_bag_description_2_4_0));
Define_label(mercury__term_errors__term_errors_var_bag_description_2_4_0_i17);
	update_prof_current_proc(LABEL(mercury__term_errors__term_errors_var_bag_description_2_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_errors__term_errors_var_bag_description_2_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___bag__bag_1_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(term_errors_module15)
	init_entry(mercury____Unify___term_errors__termination_error_0_0);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i4);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i5);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i7);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i9);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i11);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i13);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i15);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i17);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i19);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i23);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i25);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i29);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i30);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i32);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i36);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i38);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i40);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i44);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i46);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i50);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i52);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i56);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i60);
	init_label(mercury____Unify___term_errors__termination_error_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_errors__termination_error_0_0);
	MR_incr_sp_push_msg(5, "term_errors:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i4) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i17) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i23) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i29));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i5) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i7) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i9) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i11) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i13) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i15));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i5);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i7);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i9);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i13);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i15);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_errors__termination_error_0_0_i17);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i19,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i23);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i25,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i25);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i29);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i30) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i36) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i44) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i50) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i56) AND
		LABEL(mercury____Unify___term_errors__termination_error_0_0_i60));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i30);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i32,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i32);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i36);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i38,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i38);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___bag__bag_1_0),
		mercury____Unify___term_errors__termination_error_0_0_i40,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i40);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___bag__bag_1_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i44);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 2))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i46,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i46);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i50);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 3))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	call_localret(ENTRY(mercury____Unify___hlds_pred__pred_proc_id_0_0),
		mercury____Unify___term_errors__termination_error_0_0_i52,
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i52);
	update_prof_current_proc(LABEL(mercury____Unify___term_errors__termination_error_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_102);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i56);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i60);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r3 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	if (((Integer) r3 != (Integer) 5))
		GOTO_LABEL(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_pred__pred_id_0_0),
		ENTRY(mercury____Unify___term_errors__termination_error_0_0));
Define_label(mercury____Unify___term_errors__termination_error_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(term_errors_module16)
	init_entry(mercury____Index___term_errors__termination_error_0_0);
	init_label(mercury____Index___term_errors__termination_error_0_0_i4);
	init_label(mercury____Index___term_errors__termination_error_0_0_i5);
	init_label(mercury____Index___term_errors__termination_error_0_0_i6);
	init_label(mercury____Index___term_errors__termination_error_0_0_i7);
	init_label(mercury____Index___term_errors__termination_error_0_0_i8);
	init_label(mercury____Index___term_errors__termination_error_0_0_i9);
	init_label(mercury____Index___term_errors__termination_error_0_0_i10);
	init_label(mercury____Index___term_errors__termination_error_0_0_i11);
	init_label(mercury____Index___term_errors__termination_error_0_0_i12);
	init_label(mercury____Index___term_errors__termination_error_0_0_i13);
	init_label(mercury____Index___term_errors__termination_error_0_0_i14);
	init_label(mercury____Index___term_errors__termination_error_0_0_i15);
	init_label(mercury____Index___term_errors__termination_error_0_0_i16);
	init_label(mercury____Index___term_errors__termination_error_0_0_i17);
	init_label(mercury____Index___term_errors__termination_error_0_0_i18);
	init_label(mercury____Index___term_errors__termination_error_0_0_i19);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_errors__termination_error_0_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Index___term_errors__termination_error_0_0_i4) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i11) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i12) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i13));
Define_label(mercury____Index___term_errors__termination_error_0_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Index___term_errors__termination_error_0_0_i5) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i6) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i7) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i8) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i9) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i10));
Define_label(mercury____Index___term_errors__termination_error_0_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 4;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i8);
	r1 = (Integer) 9;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i9);
	r1 = (Integer) 10;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i10);
	r1 = (Integer) 11;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i11);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i12);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i13);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Index___term_errors__termination_error_0_0_i14) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i15) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i16) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i17) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i18) AND
		LABEL(mercury____Index___term_errors__termination_error_0_0_i19));
Define_label(mercury____Index___term_errors__termination_error_0_0_i14);
	r1 = (Integer) 5;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i15);
	r1 = (Integer) 6;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i16);
	r1 = (Integer) 7;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i17);
	r1 = (Integer) 8;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i18);
	r1 = (Integer) 12;
	proceed();
Define_label(mercury____Index___term_errors__termination_error_0_0_i19);
	r1 = (Integer) 13;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___hlds_pred__pred_proc_id_0_0);
Declare_entry(mercury____Compare___bag__bag_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___hlds_pred__pred_id_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(term_errors_module17)
	init_entry(mercury____Compare___term_errors__termination_error_0_0);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i2);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i3);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i4);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i5);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i10);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i11);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i13);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i15);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i17);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i19);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i21);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i23);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i26);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i31);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i34);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i39);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i40);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i43);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i48);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i51);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i55);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i61);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i64);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i69);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i72);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i77);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i80);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i7);
	init_label(mercury____Compare___term_errors__termination_error_0_0_i86);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_errors__termination_error_0_0);
	MR_incr_sp_push_msg(5, "term_errors:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury____Index___term_errors__termination_error_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i2,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury____Index___term_errors__termination_error_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i3,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) MR_stackvar(3) >= (Integer) r1))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i4);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i4);
	if (((Integer) MR_stackvar(3) <= (Integer) r1))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i5);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i5);
	r1 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i10) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i23) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i31) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i39));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i10);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i11) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i13) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i15) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i17) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i19) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i21));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i11);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i13);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i15);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i17);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i19);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i21);
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5))))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Compare___term_errors__termination_error_0_0_i23);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i26,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i26);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i31);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i34,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i34);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i39);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i40) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i48) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i61) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i69) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i77) AND
		LABEL(mercury____Compare___term_errors__termination_error_0_0_i80));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i40);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i43,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i43);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i48);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i51,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i51);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___bag__bag_1_0),
		mercury____Compare___term_errors__termination_error_0_0_i55,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i55);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_100);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___bag__bag_1_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i61);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i64,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i64);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i69);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	call_localret(ENTRY(mercury____Compare___hlds_pred__pred_proc_id_0_0),
		mercury____Compare___term_errors__termination_error_0_0_i72,
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i72);
	update_prof_current_proc(LABEL(mercury____Compare___term_errors__termination_error_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i86);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_errors__common_102);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i77);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i80);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 5))
		GOTO_LABEL(mercury____Compare___term_errors__termination_error_0_0_i7);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_pred__pred_id_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i7);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_errors__termination_error_0_0));
Define_label(mercury____Compare___term_errors__termination_error_0_0_i86);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(term_errors_module18)
	init_entry(mercury____Unify___term_errors__error_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_errors__error_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___term_errors__error_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(term_errors_module19)
	init_entry(mercury____Index___term_errors__error_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_errors__error_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r2 = (Word) (Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___term_errors__error_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(term_errors_module20)
	init_entry(mercury____Compare___term_errors__error_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_errors__error_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_context_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___term_errors__error_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__term_errors_maybe_bunch_0(void)
{
	term_errors_module0();
	term_errors_module1();
	term_errors_module2();
	term_errors_module3();
	term_errors_module4();
	term_errors_module5();
	term_errors_module6();
	term_errors_module7();
	term_errors_module8();
	term_errors_module9();
	term_errors_module10();
	term_errors_module11();
	term_errors_module12();
	term_errors_module13();
	term_errors_module14();
	term_errors_module15();
	term_errors_module16();
	term_errors_module17();
	term_errors_module18();
	term_errors_module19();
	term_errors_module20();
}

#endif

void mercury__term_errors__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__term_errors__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__term_errors_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_errors__type_ctor_info_error_0,
			term_errors__error_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_errors__type_ctor_info_termination_error_0,
			term_errors__termination_error_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
